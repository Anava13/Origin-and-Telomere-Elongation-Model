ORIGINS AND TELOMERES IN SACCHAROMYCES CEREVISIAE
One project for the replication initiation model and the telomere elongation
model. Sections 1 to 13 describe the replication side as it was built;
section 14 describes the unified project: the telomere workflow brought in,
the telomere side of the chromosome rule, and the telomere view.

Content follows Parker, Botchan and Berger (2017), Critical Reviews in
Biochemistry and Molecular Biology, and the primary work it cites. Every
factual claim in a caption carries its own citation.


1. WHAT THIS IS AND WHAT IT IS FOR
-----------------------------------------------------------------------------
Thirty-seven panels on one canvas, reached through three navigation charts.
Eleven sit on the main line and run from an ARS element on naked chromatin to
two replication forks travelling in opposite directions. Nineteen sit on a
second chart: five legends, five regulation panels, two competing accounts of
second-hexamer recruitment, and seven perturbations. Seven sit on a third
chart, the firing models for CST, which are proposals of the dissertation and
not findings from the literature; section 11 describes them.

The scope is budding yeast. Metazoan mechanisms are not drawn and not named.
An earlier build carried Geminin, the PCNA-dependent Cdt1 degron and vertebrate
Orc1 release as comparison routes; those are gone, along with the bibliography
entries that supported only them. The scope guard in the test suite fails the
build if they come back. That guard is also why ORC is never removed from the
substrate: eviction at firing is the metazoan behaviour, and this model does
not draw it.

The model is built to be read as an argument rather than viewed as a picture.
Every panel states what is established, what is proposed, and what is absent,
and it states each of those in a different visual idiom so a reader can tell
them apart without reading the caption first.


2. HOW TO RUN IT
-----------------------------------------------------------------------------
The distributable needs nothing:

    open dist/origins-and-telomeres.html

To work on it, build and test:

    python3 build.py                 # the whole pipeline, then dist/
    node tools/test_engine.js        # the behavioural suite, against dist/
    python3 tools/make_figures.py    # the dissertation figures, from dist/

    cd src && python3 -m http.server 8000

build.py runs the pipeline in the order it needs: tools/make_panels.py writes
src/panels/*.svg and the three charts, src/nav-*.svg; tools/make_shell.py
inlines the charts into src/index.html; then build.py inlines everything into
dist/. Each generator runs in its own interpreter and stops the build if it
fails, layout guard included. python3 build.py --inline-only skips the two
generators, for a build from src/ files that are already current. Every tool
reads and writes UTF-8 explicitly, so none of them depends on the Windows
default codec.

src/index.html loads panels and the bibliography with fetch, so opening it from
the file system gives empty panels. The page says so on screen when that
happens. dist/ carries panels, bibliography, stylesheet and scripts inline and
has no such requirement.

The test suite needs jsdom:

    npm install

Optional: python3 tools/render_panels.py writes style-inlined SVGs, and PNGs if
a rasteriser is on the path, to render/. Read the docstring first. Those images
are a rough offline check and not a preview.


3. THE THREE LAYERS
-----------------------------------------------------------------------------
Declared. Two tracks per substrate position, plus a kink state, a gate state, a
conformation, a presence state, effects and actor offsets. The strand track
<pos>-s holds duplex, melted, extruded or replicated. extruded says the two
parental strands are apart and the lagging template here is still bare, which
is what RPA binds; replicated says the region is behind the fork and being
copied on both templates. The two are separate values so that unwinding and
copying are separate events with a gap between them. Neither value decides on
its own what is drawn on the daughter strands: the leading pieces follow the
position, the lagging pieces are timed against the fork, and the section on the
substrate below says how. The complex track
<pos>-c holds
naked, orc, occm, mcm1, mcm2 or cmg. The kink state rides the strand group as
its own class family: kink-none, kink-transient or kink-fixed. The gate state
rides the complex group the same way: gate-na, gate-open, gate-closed or
gate-sealed, and so does the Mcm4 NSD: nsd-na, nsd-seated, nsd-displaced,
nsd-released or nsd-absent. Only a double hexamer carries an NSD value other
than nsd-na, every run carries one value, and the suite holds both. The NSD
state replaced an earlier conformation family (conf-slack, conf-compact),
which is gone from the engine, the generator and the stylesheet.
Presence rides both groups, and every effect wrapper: gone, fading, arriving or
present. These are the only facts a frame table may write.

An actor offset is either a number or a pair. A number is a slide along the
substrate. A pair is a move off it, which is what an arrival out of the
nucleoplasm needs, and the engine writes both components into one translate.

Kink is declared and not derived, because whether the bend relaxes is a claim.
ORC alone bends origin DNA transiently; the bend stops relaxing once Cdc6
seats. Deriving the kink from the presence of Cdc6 would collapse those into
one fact and lose the distinction the two forms exist to draw.

Gate is declared for the same reason. A hexamer arrives with the Mcm2-Mcm5 ring
open, threads DNA through the gap, and closes; occupancy is identical before and
after, so a derived gate would make loading a single event with no interior.
Sealed is a third value and not a synonym for closed, because Cdc45 and GINS
across the gate is a different claim from Mcm2 and Mcm5 in contact. Every
position in one run carries the same value and the test suite fails a run that
disagrees with itself.

Presence on the complex track is declared for a third instance of the same
reason. A position that holds ORC from step01 to step11 has one occupancy value
throughout, and somewhere in the middle the initiator stops being part of the
reaction: the double hexamer slides off it, CMG assembles without it, the forks
establish without it. Occupancy cannot say that and naked would say something
false, so presence says it. tools/make_panels.py writes the resting value into
the panel markup, the frame tables change it where a panel animates the change,
and paintDerived carries it from the track onto the glyph, exactly as it
carries gate and NSD.

Derived. Everything computable from the declared layer, recomputed on every
frame by paintDerived in src/animate.js and never written into a frame table:
zone tints, the position and presence of every ORC, OCCM, single-hexamer,
double-hexamer and CMG glyph, the fork marks, RPA, the four polymerases,
whether each nucleosome is still on the DNA, and all four status slots. A
nucleosome is off when anything covers its span or when a fork has reached it,
which is derived from both tracks and writes both ways, so scrubbing backward
restores what scrubbing forward removed. A frame table that named any of these
would give one fact two sources of truth. The test suite fails the build if one
does.

That rule has teeth. In step03 the arriving heptamer is a separate declared
actor and the assembled OCCM is derived from the complex track, because
animating the derived actor directly would have made arrival and engagement the
same event and given the OCCM position two authors.

Furniture. The status indicator frame, brackets, condition strips, free notes.
Present in every panel that draws a substrate, identical in position, carrying
no per-panel claim beyond its own text. Two panels, the Mcm2-7 legends,
draw no substrate, and they drop the status indicator with it: four slots
derived from tracks that are not on the page would be reporting on nothing. The
two travel together and the test suite holds them to it.

The status indicator sits on an opaque plate. A glyph travelling across the
canvas passes behind it and is occluded, which reads correctly; a glyph parked
behind it would simply be missing, so the generator fails the build on any
actor whose resting box lands there.

The declared quantity is occupancy and not strand presence. Asking what is
bound at a position gives one answer per position at every step, including
before anything melts. Asking which strand is where has no answer until
melting, which would leave two thirds of the model with an undefined track.


4. GEOMETRY AND THE ID SCHEME
-----------------------------------------------------------------------------
Canvas 880 by 300, identical in every panel. Forty-six drawn positions of 18
units each, starting at x = 26. One position stands for about 22 bp.

Every glyph dimension is set from the hexamer, which is drawn 54 units wide,
exactly three positions. That is what lets a reader still count positions to
read a footprint. The double hexamer is therefore six positions and lands
centred on the canvas at x = 440, which is what the fixed camera needs. The ARS
block and the ORC footprint are the same four positions, because ORC binding
the ARS is the claim step01 makes.

Positions are named in three families, each counted outward from its own start:
l14 through l01 for the left context, o01 through o18 for the origin region,
r01 through r14 for the right context. There is no l00, no o00 and no negative
index. chunk_id() in tools/make_panels.py and chunkId() in src/animate.js
implement the same mapping and the test suite compares them at both ends and at
both family boundaries.

Fixed positions used throughout: the ARS block and ORC occupy o03 through o06,
the first loaded hexamer o07 through o09, the second o10 through o12, and the
double hexamer o07 through o12. Nucleosomes span positions 1 to 7, 8 to 14, 33
to 39 and 40 to 46, so none lies inside the origin region. The nucleosome-free
region is drawn rather than narrated.

The daughter strands are emitted inside the strand groups, one bar against each
parental bar, so each rides the template it was copied from and opens with it.
Which one is continuous is a function of the position index: a polymerase reads
its template 3' to 5', so the leading template is the top strand on the left of
the origin and the bottom strand on the right, and the two forks are drawn as
mirror images. Lagging fragments are counted outward from the origin at eight
positions each, about 176 bp, with the primer at the fork-proximal end and the
nick on the inward edge of the next fragment. The boundaries are keyed to the
position and not to how far the fork has travelled.

When each piece is shown is a separate question from where it is drawn, and the
two strands answer it differently. A leading piece follows its own position,
because leading synthesis is continuous and travels with the helicase. A lagging
fragment is primed where the fork is and then extended backward toward the
origin, finishing about the time the fork has travelled one more fragment, so
the order the pieces are laid in is the reverse of the order the fork reaches
them. No per-position value can carry that, and paintLagging() in
src/animate.js derives it instead: a piece at index k within its fragment, k
counted from the origin end, is laid once the fork has reached d + 2 * (N - k),
where d is the position's distance from the origin. What that puts on the page
is a continuous strand running up to each fork, a stretch of bare lagging
template behind it where RPA sits, and the fragment in progress still unfinished
when the fork leaves the frame. Only panels that can declare a position replicated carry
the markup, because it costs about eight kilobytes a panel and would show
nothing in the twenty-eight that cannot.

Duplicated across the Python and JavaScript boundary, each with an assertion:
X0, CW, LEFT_CTX, ORIGIN_N, ARS_A, ARS_B, the id scheme, the status derivation,
PANEL_ORDER against KEYS, SCRIPTS across build.py and make_shell.py, and
CONTEXT_PARENT.


5. THE CAMERA
-----------------------------------------------------------------------------
The camera is fixed. There is no camera actor and no panning.

A bidirectional origin produces two objects that move apart at the same rate.
No single camera position can hold both. The alternatives were two panels, one
per fork, which would split an event that is one event; or a camera that tracks
one fork, which would assert that one fork is the subject and the other is
scenery. Instead the origin sits at the centre of the frame and the two forks
travel outward until they leave it. The last frames of step11 put the CMGs at
the edges of the drawn region with the substrate fully extruded. Leaving the
frame is the drawn form of the claim that the forks keep going.

It is also what carries the last statement the model makes about ORC. The
initiator holds x = 350 while the forks travel out past it, so what leaves the
picture is the reaction and not the protein. Panning to follow a fork would
have taken ORC off screen and read as departure.

The test suite asserts that the two derived CMG positions have opposite signs
in every frame of step11, that the left one only ever moves left and the right
one only ever moves right, and that both reach the edge.


6. THE SHAPE VOCABULARY AND THE COMPLEMENTARITY RULE
-----------------------------------------------------------------------------
Shape carries function. Where two proteins bind, the outline of one is cut to
receive the other, so an assembled complex reads as seated parts and a
disassembled one reads as parts that could seat.

This is a claim about the model and not decoration. A socket that no partner
fills is a statement that something is missing. A partner drawn beside a socket
it does not fit is a statement that the interaction is not the one being
depicted. Both are used: the unfilled ORC notch in offATP is how recruitment
failing under the Walker A mutant is drawn, and the empty adaptor clefts in
step07 are how "the mark is not read yet" is drawn.

Seven fits are drawn:

    ORC notch, between Orc1 and Orc2   <- Cdc6 triangle base
    Cdc6 upper flank                   <- Cdt1 arm origin-facing tip
    Cdt1 arm concave face              <- Mcm3 C-terminal point
    Cdc45 inner scallops               <- Mcm2 and Mcm5 body ends (two fits)
    Sld3 and Sld2 star clefts          <- phosphate stars
    Dpb11 domed socket                 <- Sld2 arch springing line
    Dpb11 knob socket                  <- free knob on the last GINS piece

Each half emits a zero-radius fit point carrying its name and its role. The
test suite pairs them by name, walks the ancestor translates of each, and fails
if a matched pair lands more than 0.6 units apart. It also fails on a seat with
no socket, because a partner drawn against nothing asserts an interaction the
panel has not drawn the other half of. A socket with no seat passes, because
that is the idiom.

GINS is four jigsaw pieces. Every piece carries a knob on its right edge and
the notch that receives it on its left, and both come out of one function, so
the joint between two pieces is one curve drawn twice and cannot drift. Both
ends of that curve are derived from the centre of the joint rather than handed
in by the caller, which is what keeps the neck the same width on the knob and
on the notch. An earlier version computed only the far end and let the notch be
drawn across half a neck: same radius, shorter chord, and a hole that came out
rounder than the knob meant to fill it. The
knob is a major arc, which makes it wider than the neck it grows out of: a
semicircular bump would locate the next piece across the bar and let it slide
along it, and holding in both directions is the whole point of the shape. What
is left over is a free notch at the left end of the bar and a free knob at the
right, which is the idiom for a chain that could go on. The knob on top of the
last piece is what Dpb11 takes hold of, and the Dpb11 socket is that same curve
cut into its underside rather than a square drawn near it.

Cdc6 is a triangle and only its base is cut, to the two circles it seats
between. Cdc45 seats on the outer C face of a hexamer and not on the seam face,
because in a double hexamer the seam side is occupied by the partner and
anything seated there would be drawn inside it.

Cdt1 has two conformations and the difference between them is the claim. A free
Cdt1 carrying a hexamer through the nucleoplasm is a straight rod, and an
ejected one is a straight rod again. The one seated between Cdc6 and Mcm3 is
bowed, which is the drawn form of the tension it holds while it levers Cdc6 out
of the notch, and the bowed form is the only one the stylesheet works. A
negative bow arches the arm the other way, which is how the second delivery
reaches a hexamer on the far side of one already loaded without being drawn
through it.

Two glyphs are constructed between their fit points rather than at a fixed
length. The Cdt1 arm is drawn from the Cdc6 flank to the Mcm3 point, and the
Cdc45 blob from the Mcm2 body end. Their assembled geometry therefore cannot
drift away from the claim, which is a stronger guarantee than an assertion
after the fact.

One fit is exempt from the last-frame check. Dpb11 has delivered GINS and left
by the end of step09, so that fit is asserted at the frame the delivery
happens instead. It is not left unasserted.

The MCM subunit. A narrow C-terminal point facing away from the seam, an AAA+
body, and an N-terminal flange ending in a tooth that points at the seam. The
two ends carry different profiles because head-to-head contact is N face to N
face: the tooth belongs on the N end and never on the C point. Every subunit
has its own hue.

One hexamer is that ring seen edge on. Ring order is Mcm2, Mcm6, Mcm4, Mcm7,
Mcm3, Mcm5, with the discontinuity between Mcm5 and Mcm2. Cutting the ring
along the plane of the page puts Mcm2, Mcm5 and Mcm3 on one arc and Mcm6, Mcm4
and Mcm7 on the other, three rows deep, one subunit from each arc in every row.
The near arc is drawn over the substrate and the far arc under it, in two
different layers, so the strand bars pass between the two walls of the ring
rather than behind both. The view sits a shade off the ring axis, so the far
arc rides above the near one instead of hiding behind it, and it runs shorter
and paler. Because the two arcs live in two layers, one hexamer is two actor
groups sharing one translate, and the test suite fails if the two ever differ.

The Mcm2-Mcm5 gate is the break in that near arc. Opening it swings the lower
two subunits of the gate arc away and uncovers the channel, which is what
admits DNA; closing brings them back and the ring encloses it. The open
positions live in the stylesheet rather than in the markup, because the gate is
a state the engine changes between frames.

A double hexamer is two of those meeting N face to N face. The right one is the
left one turned through 180 degrees about the vertical axis in the seam plane.
Row heights survive that and the two arcs swap, so the right hexamer shows
Mcm6, Mcm4 and Mcm7 to the viewer and carries its own gate on the far side.
Row for row the seam pairs Mcm2 with Mcm6, Mcm5 with Mcm4 and Mcm3 with Mcm7 on
the near side, and the same three pairs reversed on the far side. No subunit
faces itself. The seam is where DDK acts.

The teeth interlock exactly, and the geometry that makes them do so is worth
stating because it constrains three constants at once. Each flange is full
height where it meets its neighbour and tapers to a point at the row centre, so
the flanges of one arc join into a single triangular wave of period equal to
the row pitch. Two such waves are complements of each other when one is offset
by half a pitch: their heights sum to one at every y, so the gap between the
two faces is the same width all the way down. That requires the flange height
to equal the row pitch and the offset within a pair to be half of it. Any other
numbers give teeth that overlap or float apart, and the clearance left over is
MCM_SEAM_GAP, computed rather than eyeballed. The offset belongs to the pair,
so a lone hexamer carries none and stays centred on the DNA axis.

The far arc is inset at its C end only. Both walls of a ring meet the partner
in the same plane, so insetting the N end as well would have left the far teeth
floating short of each other while the near teeth met.

The consequence for the CMG is that the two helicases keep the orientation they
had in the pair, so the right one seals its gate on the far side. Cdc45 and GINS
therefore go into the far layer with it. Drawing the seal in front would put it
on the face it does not seal.

Free Mcm2-7 is drawn once, on ctxMCM, as six circles in an open C. That is the
only panel where the point is ring topology rather than position on DNA.

Colour marks family membership, not activity. The six MCM subunits take most of
the usable spread. ORC and Cdc6 share a teal family because both are AAA+ and
both make a ring. Cdc45, GINS and Dpb11 share cyan because all three are firing
factors, and within that family shape carries the difference: Cdc45 seals a
gate, GINS is a tetramer, Dpb11 is a transient scaffold. Drawing Cdc45 and
Dpb11 in one silhouette, as the reference does, would assert a shared job.

Two collisions were resolved rather than tolerated. ORC left purple, because
the reference uses purple for both ORC and Mcm7 and the two appear in the same
panel. The ARS block took amber brown rather than orange, because Mcm3 is
orange.

The ARS block is emitted in halves, per position, inside the strand groups, so
it separates with the strands where that region melts. A single rectangle
spanning four positions could sit inside none of them and could not split.


7. EPISTEMIC IDIOMS
-----------------------------------------------------------------------------
Settled mechanism. A phosphate star or a SUMO diamond on the target. The two
differ by shape and not by colour, so they survive greyscale printing. A mark
appears only where the modification is established.

Proposed mechanism. A labelled arrow and no mark on the target. Used for
whether Cdt1 is required for recruitment (step03), whether DDK and CDK act in a
fixed order (step08), and when melting happens relative to CMG assembly
(step10). The test suite asserts that no phosphate glyph appears in offMCM4N or
offBOB1.

Absence as a claim. Two forms, each meaning something different. The unfilled
socket, described in section 6, which step04 turns into a whole panel: the
notch stands empty between the two loads and the origin cannot load again until
Cdc6 fills it. And the missing node: no Cdt1 delivery glyph hangs under
altDH02, and the test fails if one appears.

Spent but present. A dimmed glyph, drawn where it has always been. Used for one
thing only: ORC from the double hexamer onward. It is not an absence idiom, and
it is not the same claim as a lost status slot. See section 10 for the state it
borrows and why.

Inhibition. A blunt bar, never an arrowhead. Every edge in the regulation set
is an inhibition. Drawing one as an arrow there would be a factual error and
not a styling choice, and the suite asserts that each regulation panel carries
at least one inhibition glyph.

Unresolved disagreement. A paired offshoot: two dashed nodes at one row joined
by a bracket whose label names the disagreement rather than an outcome. altDH01
and altDH02 are the two accounts of second-hexamer recruitment. Neither is a
route the cell selects between, so neither gets a decision diamond or a split
bar, and the suite asserts that no polygon and no split bar appears in either
chart.

Species. Several claims rest on structural work in other organisms. Every such
bibliography entry carries a species field, and the suite fails if a caption
cites one without naming the organism in the same caption. A reader is never
shown a claim without its source species.


8. THE STATUS INDICATOR
-----------------------------------------------------------------------------
Four slots in the same corner of every panel: Specification, Licensing,
Activation, Fork. Every panel declares all four, so a slot that reads "not
licensed" is making a statement and not sitting empty by accident.

Five states: on, thin, off, na, lost. Four of them are derived from the
declared layer on every frame. The fifth, lost, is declared, because absence of
a glyph cannot by itself distinguish a component that was lost from one that
was never drawn. offQC, offATP and offCDT1N declare a lost slot.

Each slot has its own word dictionary. The rungs have the same shape in all four
slots and do not mean the same thing, so the words differ: "single hexamer" in
Licensing, "marked, Cdc45" in Activation. The axis is epistemic. A slot reports
the highest level the evidence establishes at that step, not a molecular count.

Specification and Activation also read the visibility of three declared
effects: fx-cdc6, fx-phos and fx-cdc45. That is still derivation from the
declared layer, because each of those is the panel's single copy of the fact.

Neither implementation reads presence on the complex track, and that is
deliberate. A dimmed ORC is still bound to the ARS, so Specification still
reports ORC-Cdc6 or ORC alone from step06 to step11. The slot answers what the
evidence establishes at the origin; the dim answers whether the reaction is
still running through it. Wiring the two together would have made the panels
report a naked ARS or an evicted initiator, and neither is true.

derive_caps() in tools/make_panels.py and deriveCaps() in src/animate.js
implement the same rules. Python writes its result into each panel as data-rest,
and the suite compares it against what the engine computes at frame 0 for all
thirty-seven panels. If the two drift apart the build fails.


9. NAVIGATION
-----------------------------------------------------------------------------
Three charts, one visible at a time, chosen by a row of three tabs: Steps,
Additional context, Firing models for CST. The tab of the chart on show is
the one marked, for the eye and through aria-selected. The single toggle this
replaced named the page it went to, which stops working once there are two
other pages to go to.

The steps chart is a single column of eleven nodes. Each carries badges for the
context panels that hang off it, so a reader on step06 can reach the three DDK
bypass panels without going to the other chart first. CONTEXT_PARENT drives the
badges and is duplicated in tools/make_panels.py and src/data.js, with an
assertion that the two agree and that every parent names a real main-line key.
A second row of badges, in the CST blue and labelled M1 to M7, hangs each
firing model off the step it acts at. MODEL_PARENT drives it, duplicated and
asserted the same way. Context badges carry the class ctxb and model badges
modelb, so the figure exporter can print the chart with the model row alone,
which is the overview of where every model acts. A step with models carries
context badges on the upper row and models on the lower, because step06
alone carries seven badges and a row holds five.

The context chart is one column in four labelled groups: Legends, Regulation,
Alternatives, Perturbations. The disagreement bracket joining altDH01 and
altDH02 sits there and keeps its label.

Selecting a panel brings its chart forward, so a reader following a badge is
never left looking at a chart the selection is not on.

Phase is stated once, by the cell-cycle axis in the left margin, which appears
on both charts. There are no phase bands and no phase chip, and META carries no
phase field. The suite asserts all three.

The axis is a narrow strip beside the step column, and its four bands are
coloured: mauve for late M, green for G1, amber for G1/S, blue for S. It sat in
the right margin as a wide labelled band until the context badges grew: a step
with five of them ran under the axis and off the chart, so the badges kept the
right margin and the axis moved. Colour is the only thing on either chart that
carries a fact rather than a position, which is why the same phase takes the
same hue on both pages. The labels are rotated to fit the strip.


9a. THE LAYOUT GUARD
-----------------------------------------------------------------------------
Nothing in the generator used to know how big anything was, so no build-time
check could ask whether a label ran off the canvas or whether an actor came to
rest on the status indicator. Both had happened, in twenty places, and the
behavioural suite could not see either: it measures with getBBox, which reports
local user space and ignores every ancestor transform, and it runs under jsdom,
which has no text metrics at all.

So the generator measures its own output. tools/make_panels.py parses every
shape back out of the markup it just produced, measures text against an advance
table keyed by class, and fails the build on three things: a label outside the
canvas, two labels overlapping, and an actor whose resting box lands on the
status indicator. Actor boxes are widened by the full range of offsets the
frame tables give them, read straight out of src/anim-data.js, so a collision
that only happens on frame four fails as loudly as one at rest.

Free notes and in-panel labels wrap to a declared width rather than running
long, and a wrapped line that still does not fit is a build error.

Measuring the output rather than threading an extent through thirty
constructors keeps the constructors as they are and still leaves one place that
owns the answer. What it cannot see is real font metrics, since it works from a
table rather than from a rasteriser; the advance widths are set generously for
that reason.


10. FRAME TABLES AND KNOWN GAPS
-----------------------------------------------------------------------------
Seventeen panels animate. Each frame declares the complete state of every
element it touches rather than a delta, so any single frame renders correctly
on its own, which matters when a frame is pulled out as a static figure.

Frame 0 reproduces the panel markup. That rule is what makes the Python and
engine comparison in section 8 meaningful, and it is also why several panels
open on a state that looks mid-process: step04 opens on the OCCM, step05 on a
single loaded hexamer, step11 on a partly extruded substrate. It is also why
step01 opens on a naked ARS. That panel draws two initiators, the searching one
inside fx-search and the engaged one derived from the complex track, and
declaring the track occupied at rest put both on the page in the same frame.
The track is naked until the frame the initiator seats, which is what the
searching glyph is travelling toward.

The frame-table syntax departs from the handbook in one place. A position track
needs a value, a presence state and, on the strand track, a kink state at the
same time, and the handbook's map holds one value per id. Frame tables here
write compound strings:

    tracks: { "o08-c": "mcm2:arriving", "o05-s": "duplex:present:kink-fixed" }

Each token is matched against the family it belongs to, so order inside the
string does not matter and an unrecognised token is ignored rather than written
blindly as a class. fx and actors are separate maps.

One use of the presence family is not what the family usually means. From
step05 onward the ARS positions read orc:fading and stay there. Everywhere else
in the model fading means departing and resolves to gone within a few frames;
ORC's never does, and no frame in any panel takes an ORC run to gone. What the
dim carries is that the initiator has finished its job, not that it has left.
It loaded the pair, the pair slid off it onto DNA it no longer touches, and
nothing downstream passes back through it: Yeeles et al. assembled CMG and
established forks with ORC, Cdc6 and Cdt1 washed away entirely. Budding yeast
ORC stays on the origin through S and G2/M, so the glyph stays where it is and
goes quiet instead.

The flip lands on step05 frame 5, which is the frame fx-atp arrives. That is
the ORC ATPase firing, the event that releases the initiator from the pair it
has just built, so the cause of the dim is on the page in the frame the dim
happens. step06 through step09 and offDDK carry the state in their tables;
step10 and step11 name no ARS complex track and inherit it from the markup,
which is where the generator writes it for every panel that draws a spent
initiator, animated or not.

A reader who takes the dim for a departure has the wrong idea, so the captions
from step06 on say in words that ORC remains bound. The status indicator says
it too, by continuing to report ORC-Cdc6 in Specification.

Offsets carry meaning and are asserted. Cdc6 leaves the ring with a negative
offset and Cdt1 with a positive one, and Cdc6 leaves first, in both loads,
because that ordering is what the single-molecule work shows.

Arrivals come out of the nucleoplasm rather than sliding along the chromosome.
Both hexamers and the returning Cdc6 descend one arm of a parabola whose vertex
is the landing site, and the arriving actor is drawn at that site with the
frames carrying it back up the curve. That is why the two hexamer descents are
the same three numbers, which is the drawn form of the claim that one route
runs twice. The suite asserts that every descent loses height and closes on its
site at every step, that it ends on the site exactly, and that the second
delivery repeats the first.

ORC never carries an offset in any frame of any panel, because budding yeast
ORC stays bound. It is also never taken off the complex track, for the same
reason, and the two together are what keep the model inside the scope guard in
section 1.

Handoffs between consecutive panels are asserted numerically: ORC across step01
and step02, the double hexamer across step05 and step06, the CMGs across step09
and step10 and across step10 and step11, and the fork marks across step10 and
step11. A glyph that jumped between panels would read as motion that never
happened.

Known gaps:

- src/refs.bib carries no DOIs. Link resolution is DOI, then URL, then a
  Scholar title-and-author query, and every entry currently falls through to the
  third. Adding DOIs is a pure addition to the .bib file and needs no code
  change. Inventing them would have been worse than leaving them out.
- render_panels.py resolves plain and compound class selectors only. Most of
  the new glyph vocabulary is styled through descendant rules, so those images
  are missing more colour than they used to be. Read its docstring.
- The species field is populated by hand for the entries that needed it. An
  entry added later without one is not caught, because the guard only checks
  entries that have the field.
- Citation numbering is per panel (CITE_SCOPE in src/cite.js). Switching the
  string to "global" numbers each work once across the whole reading order; the
  code path exists and is not exercised by the current build.
- The cell-cycle axis on the context chart is one undivided band. The
  regulation nodes are placed against it but not resolved to a phase within it.
- Nothing yet asserts that ORC is never taken to gone, or that it reads as
  spent from step06 onward. Both are one loop in tools/test_engine.js and
  neither is written.


11. THE FIRING MODELS FOR CST
-----------------------------------------------------------------------------
The third chart draws the ways CST could act in origin firing that the
dissertation proposes, grouped by route:

    DDK-dependent      cstCONF  M1  Mcm2-7 conformation
                       cstCDC7  M2  Cdc7 retention
                       cstRIF1  M3  Rif1-PP1 inhibition
    DDK-independent    cstBOB1  M4  Mcm2-7 conformation without DDK
                       cstEJSS  M5  lagging-strand ejection, ssDNA binding
                       cstEJPR  M6  lagging-strand ejection, protein binding
                       cstPOLA  M7  Stn1 stimulation of Pol alpha

None of these is an established mechanism, and three things keep that visible.
They have a chart of their own, so the boundary between the literature and
the proposals is the first thing a reader sees there. Their kind is model,
with a chip in the CST blue that no other kind uses. And the standfirst says
it. M5 and M6 are competing accounts of one step and are paired under a
bracket naming what separates them, which Stn1 region acts at the gate, the
idiom altDH01 and altDH02 use.

Each model is set on a panel the reader has already met, and keeps that
panel's tracks: cstCONF and cstCDC7 on the docked, marked pair of step06,
cstRIF1 on regRIF1, cstBOB1 on offBOB1, the ejection pair on step10, cstPOLA
on the state step11 reaches in its fourth frame. The suite asserts the tracks
agree. ORC is left off every model panel, since each acts after the pair has
left it; it stays on the complex track, so the status indicator still reports
it.

CST. The glyph and the colours are the telomere figure's, because the reader
meets CST there first: Cdc13 the OB-fold wedge, Stn1 a box, Ten1 the smaller
box. The fills and edges are identical; the subunits are rearranged and the
size changes, so the complex can sit where the two-hybrid scores put it. All
three subunits score with Mcm2, and Stn1 and Ten1 also score with Mcm5. In
this projection Mcm2 and Mcm5 are the top two rows of the near arc of the left
hexamer, or of the left CMG, and the near face is the outer surface of those
subunits; their C-terminal ends are where Cdc45 seats. So in every model CST
lies on the face as a strip across the boundary between the Mcm2 and Mcm5
rows: Stn1 and Ten1 side by side, each covering both rows, and Cdc13 on the
Stn1 C half over the Mcm2 row alone, with its name above it. The strip is ten
units tall, which clears the subunit numbers above and below it. On a pair it
runs from just inside the C-terminal end of the bodies to the end of the
flange, short of the partner hexamer's tooth; on a CMG it starts three units
in, clear of Cdc45. cst_face() and cst_glyph() in tools/make_panels.py hold
all of it, and the suite asserts the placement in every model.

Stn1 is drawn as two halves. The C-terminal half binds Cdc13 and Pol12 and
sits against Cdc13; the N-terminal OB fold binds Ten1, and Ten1 sits against
it. Joined, the halves read as one box with a dashed seam. In the Pol alpha
model alone they are drawn apart, with a dashed linker, the drawn form of the
hundred or so residues between the Stn1 1-186 and 288-494 fragments: the N
half and Ten1 stay on the face and the C half and Cdc13 go to Pol alpha. CST
carries no fit point anywhere, because the scores give contacts and no
geometry.

Second partners. Where a model gives CST a second partner, the partner meets
CST. The ejected strand turns up into the gate under the Stn1 N half. Pol
alpha takes the Stn1 C half; the engine now puts each Pol alpha 70 units
behind its fork, not 58, in step11 as well, so the C half and Cdc13 fit
between the left CMG and its polymerase (POLA_DX in the generator, asserted
equal to the engine). Rif1-PP1 moved under the C-terminal end of the left
hexamer, in regRIF1 as well, so the inhibition bar from CST drops straight
onto it. DDK is the one partner that cannot reach the face, because it docks
above the seam and the burst is larger than the face, so the Stn1-Dbf4
contact in the Cdc7-retention model is a solid bond line from the Stn1 N half
to the burst.

Proposals. A proposed effect is a labelled arrow with no mark on its target,
as elsewhere. Where CST already touches what it acts on, an arrow would be a
stub, and the proposal is set in the arrow-label face on a leader instead,
the treatment offBOB1 uses. That face survives the figure export, which
drops pointer labels, because a proposal printed without its qualifier would
be a claim the panel does not make. No extra phosphate is drawn for a model
that predicts more marks per tail: more marks is the prediction, and a mark
is the idiom for a finding.

Ejection. step10 does not draw the lagging strand leaving the ring, because
no measurement follows the displaced strand, and it is unchanged. The
ssDNA-binding panel draws it, because there the strand is CST's partner: the
left CMG carries its Mcm2-Mcm5 gate on the near face, so its lagging template,
the bottom strand on that side, is drawn in front of the near arc from the
C-terminal end of the ring and turns up into the gate under the Stn1 N half.
Two copies ride the CMG's near group, fx-eject-melt and fx-eject-open, at the
heights the bottom bar has in the melted and extruded states, and the frame
table shows the one that matches the strand track. The drops are duplicated
from the stylesheet as EJECT_DROP and asserted equal. The right CMG ejects
through its far-side gate, which this projection cannot show without hiding
the strand, so the left CMG stands for both. The protein-binding panel runs
the same frames without the strand, because there CST holds the subunits and
not the strand. In both, CST arrives once the origin has opened, rides the
left CMG through passage, and leaves no later than Mcm10; the suite asserts
all three.

Figures. tools/make_figures.py prints each model beside the base frame it is
drawn on, base on the left and model on the right, with ORC dropped from the
base so the two differ by the model alone: fig-cst-ddk-dependent,
fig-cst-ddk-independent, fig-cst-ejection and fig-cst-pola. fig-cst-overview
is the steps chart with the context badges dropped. A part whose panel is
named nav- and a page is a chart, captured the same way a panel is.

Known gaps. src/refs.bib here is older than the captions. Keys cited by
existing captions (Lewis2022, herrera2015reconstituted, puhringer2026preic,
noguchi2026sld3, langston2017mcm10, henrikus2024unwinding,
langston2023mechanism) and by the model captions (abd2020antagonistic,
simon2016structure, sheu2016concerted, bhattacharjee2016stn1) are missing,
and the suite fails until the current dissertation bibliography is copied in.
The dissertation text cites noguchi2026structural and puhringer2026structure
where the figure cites noguchi2026sld3 and puhringer2026preic; if those are
the same works, one pair of keys should go.



12. THE CHROMOSOME VIEW
-----------------------------------------------------------------------------
The fourth chart, Chromosome, holds one live panel (chrLIVE): a 240 kb model
chromosome through one cell cycle, with six origins, a centromere and two
telomeres. Below the panel the reader picks a genotype (wild type, dbf4-1,
dbf4 deletion, rif1 deletion, dbf4-1 rif1 deletion), switches mcm5-bob1 and
hydroxyurea on or off, picks a checkpoint allele (intact, rad53-21, dbf4-m25
sld3-38A), switches the alleles dbf4-zn, mcm2-1 (standing for mcm3-1 and
mcm5-1 too), ctf19 deletion (standing for mcm21 deletion too), exo1 deletion
and dun1 deletion, picks a late artificial kinetochore site (none, vector,
ASK1-LacI), and draws a run. A slide strain menu sets the switches for one
strain of slides 2 to 6 of the Stn1 chapter deck and plays its median run
(section 12c). "New run" draws a fresh random run; "Replay this run"
plays the same seed again. The panel teaches one claim: limited supplies of
DDK, Rif1-PP1 and firing factors, shared among the origins still open, set
the order in which origins fire in S. No origin is labelled early or late.

The rule lives in src/chrom-rule.js and is the single source of truth. The
page runs it for every run and tools/test_engine.js runs it with fixed seeds.
The Python simulation (tools/make_timing.py, src/timing-data.js) is retired.
The rule, stated in full in that file's header:

  - DDK is 10 copies (dbf4-1: 6 active; dbf4 deletion: none). From G1/S the
    active copies are dealt to the open origins by recruiter weight (Ctf19
    complex 4, Fkh1/2 2, none 1). An origin that fires or is copied returns
    its copies, so DDK concentrates on the origins that are left.
  - Each telomere's Rap1 array captures 2 Rif1 copies, which act on the open
    origin within 30 kb. 6 free Rif1 copies are dealt evenly. rif1 deletes
    all of them.
  - Copies are whole; a copy that cannot be dealt fairly between equal
    origins stays in its reservoir.
  - Marks follow dm/dt = 0.588 a - 0.028 p m, solved exactly between events,
    so the simulation steps from event to event. An origin is ready at 20
    marks. With only L3 and R3 left open their marks still reach 20, slowly,
    which is what lets late origins fire in HU without the checkpoint.
  - bob1: each pair switches at random between shapes, a mean of 5 min in the
    permissive one and 145 min out of it. While permissive it is ready
    whatever its marks. The share and the slow switching were tuned so that
    bob1 alone keeps the Ctf19 pair first in most runs and ends S near wild
    type, while bob1 dbf4 deletion takes much longer with most of its
    origins copied passively (Hoang et al. 2007). A share of a fifth
    failed both. Rif1 has no effect on the switching, so the rule does not
    explain why late origins suffer more in bypass cells.
  - A ready origin fires when one of two firing-factor sets is free; when
    more are ready than sets are free, the set goes to one of them at random.
    A set returns 4 min after firing. A fork that reaches an origin first
    copies it.
  - Hydroxyurea: the run starts at G1/S in HU and runs until the cell
    attempts anaphase (judgeOutcome): every stretch copied, then anaphase;
    or premature extension, shown for extendShow (30) min, then stop; or
    still in S at huMax (240) min. A strain is scored at 60 min, taken as
    90 min after release from G1. The dNTP pool falls to 0.1 of normal and moving forks move at that
    share of 2 kb/min. Each moving fork gains RPA (single-stranded DNA left
    as the polymerases fall behind the helicase) at 0.1 levels per min times
    the dNTP shortfall, up to 3, drawn as RPA wedges on the fork. The Mec1
    signal is the RPA summed over forks still in progress; RPA tokens fly
    from each fork to the Mec1 gauge in the header. Rad53 comes on when the
    signal reaches 4.5 (Mec1-Ddc2 and Mrc1 drawn as one step), which in wild
    type falls just after the Fkh1/2 pair has fired, and acts on three
    targets: marked sets (Sld3) stay home, so nothing fires; marked DDK
    (Dbf4) goes home and stops marking; Dun1 raises the dNTP pool to 0.25.
  - Collapse: in HU every moving fork shares one hazard, collapseK times
    (load / collapseRef) ^ collapseN, where load is the moving forks, each
    weighted by the origins it stands for (early 1, late L3 and R3 2.4, from
    about 180 origins firing in HU with the checkpoint and 400 without it),
    times (HU pool / pool) ^ poolExp. A cell with Rad53 multiplies it by
    rad53Protect (0.36) at every fork. In a cell with Rad53 a collapsed fork
    restarts restartDelay (40) min later with a fresh clock; without Rad53 it
    never does. The delay keeps restarts after the centromere forks have met,
    so they let wild type finish without raising its extension at 60 min. Each fork draws one exponential clock
    at its start and collapses when its accumulated hazard reaches it, so the
    run stays exact from event to event. rad53-21 is drawn as no Rad53
    activity; dbf4-m25 sld3-38A removes the firing arms only; dun1 deletion,
    now an allele, removes the dNTP arm only.
  - Resection and kinetochores: Exo1 resects both ways from a collapsed fork
    at exoRate (exo1Rate without Exo1) up to resectReach kb. A kinetochore
    site is lost the first time a front reaches it. The CEN is always a site;
    the late artificial kinetochore (75 kb, 20 kb from L2) is one when
    present and holds only with ASK1-LacI.
  - Spindle: forms 30 min after G1/S, holds at 1.5 um while any active
    kinetochore holds, then extends in cycles to peaks of 4 to 7 um and
    breaks back to 3.2 um, inside the 3 to 7 um range Bachant et al. 2005 report; without HU it reaches 9 um once every stretch is
    copied. Peaks come from a second stream seeded from the run's seed, so
    they never change replication.
  - Alleles: dbf4-zn sets the Ctf19 weight to 1 and the active DDK copies to
    7 (6 without Rad53); ctf19 deletion sets the Ctf19 weight to 1; an mcm
    allele licenses each origin with probability 0.34.
  - All random draws come from one seeded generator (mulberry32), so a seed
    replays its run exactly.

src/chrom-frames.js turns a run into a frame table (fx states, actor offsets
and text) and src/chrom-live.js installs it as ANIM.chrLIVE, so the engine
plays a live run exactly as it plays a hand-written table. The engine gained
one capability for this: a frame may carry text, a map from element id to the
words that element shows (a firing time, the firing order, the clock's tick
numbers). tools/make_panels.py draws the panel once, holding every object any
run can show, and writes src/chrom-geom.js (CHROM_GEOM), the geometry the
frames place things with. The panel is audited at rest.

What the panel holds. Every origin has two forks and two copied strips; each
strip reaches the chromosome end it faces, hidden behind a fixed clip, and a
run slides it out only as far as its fork travels (offset = x_now -
x_origin), so strips that meet overlap in the same grey. Each origin carries
every glyph state any run needs: ORC alone (step 1), ORC with Cdc6 (step 2),
the licensed pair (step 5), the marked pair (step 6), the step 7 firing
picture, ORC spent, and the bob1 versions with the Mcm5 tooth blunted,
including mbob, the permissive shape drawn as offBOB1's released NSD. Each
fork's path is recorded wherever its speed changed, and the frames place the
fork and its strip along it; a collapsed fork is drawn faded. The header
carries the checkpoint circuit: the Mec1 signal gauge with its threshold
mark, an arrow to Rad53 (the kinase silhouette with a burnt-orange core,
faded until it comes on), the four outputs listed beside it, each lit when
it acts, a dNTP gauge, and a line naming the condition. Event words appear
where each event happens for three frames: "RPA on ssDNA", "forks held by
Rad53" or "fork collapses" under an origin, "Rad53 on: Mec1 signal from N
stalled forks" under Rad53 (or, without Rad53, that the signal reached its
mark with nothing to switch on), and the Dbf4 mark under the DDK reservoir.
The engine shows them through presence states and text, like everything
else. A Rad53 mark is the figure's gold phosphate star, shown on
each set and each active DDK copy that Rad53 holds at home. The
meter's dashed ceiling is an actor that drops to the floor while a bob1 pair
is permissive. Every DDK and Rif1-PP1 copy is an actor in a presence wrapper:
a run fades the inactive DDK copies, hides the Rif1 copies a rif1 deletion
removes, and moves the active copies to dock slots beside the meters (DDK on
the telomere side in rows of three, Rif1-PP1 on the centromere side in rows
of two). The firing-factor sets are the step 9 assembly without Cdc45 and
land with the clasp under the pair. A dbf4 deletion without bob1 cannot fire
any origin; the run stops at G1/S and the panel says the genotype is lethal.

The "Drawing note" under the caption states the rules in plain words and what
each allele changes, and names the gaps: the drawing values, the tuning of
the bob1 switching, the unexplained late-origin bias, and the untested effect
of Rif1 in bob1 cells. Every protein is a miniature of the glyph the origin
panels draw it with (mini() strips ids, fit points and text); the telomeres
carry the telomere figure's Rap1 units; Ku is left out because its orange
cannot be told from Mcm3; each origin's ORC sits on the centromere side; L1
and R1 sit at 108 and 132 kb.

The origin close-up. Under C1 in the navigation pane, tools/make_panels.py
draws src/chrom-inset.svg (build_inset_view), which tools/make_shell.py
places under the chromosome chart. It draws one origin with the step panels'
own glyph functions and labels (inset_clean keeps text and drops ids and fit
points), at CI_S about the pair: every pair state with and without bob1, the
firing picture, a set held by Rad53 (star on Sld3) or still busy, the two
CMGs once fired with RPA wedges behind each, the copied stretch, a meter
with a count, the DDK and Rif1-PP1 it holds as counts beside one labelled
glyph each, and three status lines. Every id there starts ci-. Clicking an
origin on the panel (a transparent hit area per origin, data-origin) selects
it; a dashed ring (id chrsel, untouched by the engine) moves to it. The
frame builder writes, per frame, an inset map of states, offsets and words
for the selected origin; chrom-live.js applies it whenever the frame
changes, chained onto onFrameChange, so the engine is unchanged. Selecting
another origin rebuilds the same run's frames and repaints the current one.

Following a fork. Once the selected origin has fired, the close-up can follow
its left or right fork (buttons above the close-up; right by default,
"origin" goes back). draw_fork_scene() draws, for each side, the replisome
fixed at CI_FX (the CMG with Pol eps from cmg_actor, Pol alpha, Ctf4), the
parental duplex ahead, the leading daughter behind as one continuous new
strand, the lagging daughter as Okazaki fragments with red primers at their
fork-proximal ends, and RPA on the bare lagging template (one wedge plus one
per RPA level). Strand roles follow step 11: the right fork's leading
template is the bottom strand. The DNA runs on a conveyor: strips of rungs
and fragments that a CSS animation slides one fragment length (CI_FRAG) per
cycle. chrom-live.js sets the cycle from the fork's speed (20 close-up units
per second per kb/min) and pauses it when the fork stops, collapses or
finishes; the frames carry the speed, and the status lines give the true
position and speed. The conveyor shows motion, not distance, because frames
are about 2 min apart and a normal fork moves about 4 kb in that time.

One drawing of DNA everywhere. The step panels, the chromosome view and the
close-up draw DNA the same way: unreplicated DNA is two parental strands
joined by base-pair rungs; melting breaks the rungs; a copied stretch is two
daughter duplexes, each a parental strand paired by rungs to a blue new
strand. In the step panels rung_pieces() adds two rungs per position: duplex
rungs, shown only on duplex positions, and daughter rungs that carry the
lead or lag and face classes of the daughter they pair and open with it
(lagging rungs wait for .laid through :has). NASC_GAP opens a rung's width
between each daughter bar and its template. The chromosome view draws the
same rows at CHR_STRAND_K of the step proportions (a pattern fills the rung
rows), and its copied stretches stay fixed to the chromosome while a sliding
clip, now the actor, reveals them behind each fork. The close-up draws the
step rows at CI_S. Its world group holds the origin scene and the two fork
scenes, each one close-up width to the side, and the camera pans between
them (CSS transition on #ci-world), so when an origin fires its DNA opens
into two daughter duplexes and the camera slides along the same strands to
the followed fork, where the conveyor takes over.

Firing in slow motion. When the selected origin fires, the frame builder
replaces that frame with one frame per step-panel frame from step 7 to step
11 (34 frames), each repeating the chromosome at the firing moment while the
close-up plays that step's frame: chrom-live.js copies the step panel into
the close-up once (renaming only its clip paths, patterns and markers),
crops it with CHROM_GEOM.ciStepView so its pair lands where the close-up
draws the origin, and paints it with the engine's own clearPanel, applyFrame
and paintDerived, which now take an optional root. So the close-up runs from
initiation into elongation without a cut: the clasp seats, S-CDK marks Sld2
and Sld3, Dpb11 delivers GINS and Cdc45 seats, Mcm10 arrives and the origin
melts, the replisome assembles and the forks leave, then the camera pans to
the followed fork.

Frames are keyframes. Every visual change between two frames is a CSS
transition, and matchTransitions() in src/animate.js stretches each panel's
fade, move and travel to exactly one frame interval of that panel's table
(1000 / fps), so a change runs from one frame to the next instead of moving
and then holding: the strategy the presentation player (tools/make_player.py)
uses by running the live engine. Travel is linear, so a glyph moving across
several frames keeps one speed through each keyframe. The close-up does the
same at the chromosome panel's rate, and it never swaps pictures abruptly:
the origin scene, the step-panel copies of the firing interlude and the
settling frame after it crossfade by opacity, and the camera pans by a
transition on the world group.

Vibration. A moving replisome jitters (CSS chrjitter on a .vib wrapper): in
the close-up while the conveyor runs, and on the chromosome on every fork
drawn present, which is exactly a fork that is moving.

Known gaps: the meters are a smooth fill rather than one slot per mark. The
storyboard and handoff docs describe the earlier, fixed four-panel version.


12b. The close-up as one drawing (October 2026)

The close-up shows only panels drawn by the step panels' functions:
ciorigin (origin before and after firing), copies of steps 7 to 11 (and
their bob1 versions, step07b to step11b, with bypass tables step07x to
step11x built at load), cielong-r/l (a fork carried past step 11, its strip
moved back one Okazaki fragment whenever the fork reaches the window's end),
and cipass-r/l (a fork from a neighbouring origin crossing an unfired one:
the CMG pushes the double hexamer, Rrm3 removes it). A switch of panel only
happens between two frames that show the same picture, and it is made at
once (.cisnap). Every protein on the main line arrives from off the page and
leaves off it. Each fork carries Mrc1 with Tof1-Csm3 and two dNTP streams.
In hydroxyurea the close-up draws the checkpoint at the fork: thin streams,
bare template coated by one RPA per position, Ddc2-Mec1 on the coat, the
mark on Mrc1, Rad53 docking, marked twice, one copy leaving for Dun1 and the
origins; without Rad53 the dock stays empty and the replisome later leaves.


12c. The spindle readout (October 2026)

The chromosome view reproduces the spindle phenotypes of slides 2 to 6 of the
Stn1 chapter deck (Julius et al. 2019; wild type from Gasparyan et al. 2022).
Excess Stn1 is left out until the firing models reach this view.

What is drawn. A green kinetochore microtubule comes down from under the
clock strip to the CEN kinetochore, which sits on the Ctf19 complex; the
spindle pole is out of frame. A late artificial kinetochore, when active,
takes its microtubule from the bottom edge, the other pole. When resection
reaches a kinetochore it fades and its microtubule slides out of its clip.
A collapsed fork carries an orange resected stretch on each side with an
Exo1 front, each revealed by a sliding clip. The spindle length is the gauge
in the header, with the 3 um line marked; its fill turns from green to red at
the line, and the words beside it give the length.

Slide strains. src/chrom-rule.js holds PRESETS: twelve strains, each with its
switches, its scoring time (90 min after release, or small or large buds for
slide 6) and the share the paper reports. medianRun(preset, n) simulates
seeds k times 7919 for k from 1 to n, takes the runs that end the most common
way (anaphase, premature, arrested), and returns the one whose spindle at the
scoring time is closest to their median, with the share extended. The page
calls it with n = 301 when a strain is chosen, which takes about a fifth of a
second; no generated file holds the seeds.

What the toy reproduces and what it does not. The tests hold the rule to the
relation each slide argues over 200 seeds: wild type short; rad53-21 between
30 and 70%; dbf4-zn, mcm2-1 and ctf19 deletion each below a third of
rad53-21; dbf4-m25 sld3-38A at least half of rad53-21 with Rad53 on, and
higher still with dun1 deletion; an active late kinetochore below a third of
its vector; rad53-21 flat between small and large buds; exo1 deletion below
a third in small buds and at least 0.6 of rad53-21 in large ones. Over 400
seeds the shares are: wild type 10%, rad53-21 40%, rad53-21 dbf4-zn 0%,
rad53-21 mcm2-1 8%, dbf4-m25 sld3-38A 31%, with dun1 deletion 47%, rad53-21
ctf19 deletion 5%, late kinetochore vector 40% and ASK1-LacI 0%, rad53-21
small buds 42% and large 40%, exo1 deletion small 0% and large 39%. The toy
runs low for rad53-21 and dbf4-m25 sld3-38A and high for wild type; dun1
deletion alone extends in about 19% of runs, which the paper does not report
as a percentage. A spindle spends part of each breakage cycle under the line,
which caps the share extended among cells that have lost their anchor.

Two changes made the relations possible. A shared hazard alone could not
separate dbf4-m25 sld3-38A from dun1 deletion, because the toy has only two
checked origins and they fire late; weighting late forks by the origins they
stand for, and letting the pool enter the load weakly, does. And resection
needed a reach: without one every rad53-21 run would lose its kinetochore
in time, which gives no plateau between small and large buds.

L1 and R1 moved to 110 and 130 kb, 10 kb from the CEN. Each origin's ORC
sits 22.5 units toward the CEN, so closer origins would put ORC on the CEN;
the resection reach is set for this distance. The Rif1-PP1 reservoir moved
left to clear the CEN microtubule.


12d. Anaphase and termination (October 2026)

Anaphase. Without HU the frames after S are G2 and four anaphase frames
(A1 to A3, then G2M). From G2 the copied strips are swapped for two sister
chromatids (fx-sisters), each drawn as 48 segments of 5 kb at the copied
strips' rows, so the swap is invisible. In anaphase each segment moves toward
its pole by CHR_ANA_DY times the anaphase fraction times 1 - 0.75 |x - CEN| /
CEN, so the sisters part in a V led by the centromere, by translation only.
The CEN kinetochore and the Ctf19 complex ride the top sister; the sister
kinetochore (fx-kt2-CEN, microtubule from the bottom pole) rides the bottom
one. The sister kinetochore appears once any fork has passed the CEN. Origin
glyphs leave the axis once the sisters part. The spindle follows the rule's
anaphase path and draws in the normal colour; red is kept for extension
before anaphase. HU runs end inside S, so they never part.

Termination. When the followed fork ends by meeting another, the frame
builder replaces the frame it meets on with twelve frames (insertTermination)
on the close-up's termination panel (citerm, citerm-b): the oncoming fork
enters, the gap closes two positions per fork per frame, the CMGs pass onto
double-stranded DNA, SCF-Dia2 binds and ubiquitylates Mcm7, Cdc48 binds and
extracts each CMG. Positions left of the meeting point carry the rightward
fork's daughters and positions right of it the leftward fork's, so each half
is painted by paintStrip as its own fork paints it. Every later frame that
showed the replisome leaving shows the finished stretch instead.

Test suite. The check that walked every frame of every panel for undefined
actor positions was removed: with the chromosome panel it took most of an
hour. The engine now resolves ids through a per-root index (findId in
src/animate.js), which cut a chromosome frame from about 7 s to about 0.4 s
under jsdom.


13. THE GUIDED LESSON
-----------------------------------------------------------------------------
    python3 build.py && python3 tools/make_tour.py

writes dist/origins-and-telomeres-tour.html: the whole viewer with a lesson
layer that hides the viewer's chrome and steps a reader through beats. The
layer is three files in tools/tour: tour.css (layout), tour.js (runtime) and
lesson-hu.js (the lesson, data only). make_tour.py checks that every viewer
function the runtime calls is present before it writes.

The slide list shows a preview of each slide when the pointer rests on its
dot, to the left of the list and level with the dot's row. The previews are
screenshots taken from the built tour by tools/make_thumbs.js and stored in
tools/tour/thumbs.json, which make_tour.py embeds. Each preview records its
slide's title, and a slide whose title has changed shows no preview until
the previews are taken again:

    python3 tools/make_tour.py && node tools/make_thumbs.js && python3 tools/make_tour.py

A beat names a condition, a stretch of frames, a layout (chrom, both, close
or compare), a zoom box and the boxes or element ids to keep lit, a caption
and, for some beats, a prediction asked before the beat plays. Stretches are
anchored on events read from the run (the first frame at a time into S, the
first frame matching a test on the close-up's view, a phase), so retuning the
rule moves the anchors with it. Each frame now carries its phase and its
minutes into S (t) for this. Conditions in HU play their slide strain's
typical run (medianRun); the others play seed 1. Beats without the close-up
skip the close-up's slow-motion frames as they play.

Cryo-EM structures. tools/structures/export_mcm_structure_assets.py runs in
ChimeraX, builds the scenes of the dissertation's structure figures and writes
their surfaces, colours, cameras and anchors to
tools/structures/mcm_structure_assets.zip. tools/structures/make_structures.py
(numpy and fast-simplification) reduces the scenes the lesson uses to
tools/structures/structures-lesson.json: surfaces welded, decimated and
smoothed, ChimeraX soft lighting baked as ambient occlusion per vertex, chains
named by subunit (and by side, .L or .R, in a double hexamer). make_tour.py
embeds that file as window.TOUR_STRUCTURES, and tools/tour/mol3d.js draws a
scene with WebGL2 wherever a figure carries a data-m3d box (figures.py,
m3d_slot): silhouettes from depth jumps, markers and labels on named chains,
a slow turn, drag to turn by hand. Rerun make_structures.py only when the
archive changes.

The proposed-model slides (routes in a beat) give each model a row: its
animated panel, its network (grn.py, ROUTES) and a late origin's DDK-mark
meter (figures.py, ROUTE_METERS), with one switch per slide for the cell with
or without HU.

The comparison layout copies the chromosome panel, renames its clip paths
and gradients, and paints it with the engine's applyFrame from a second run's
frame table (ANIM.chrCMP), at the same minute into S or at its run's end.

The HU lesson: wild type without HU (origin program, firing in close-up,
termination, biorientation, anaphase), rad53-21 without HU (no phenotype
without stress), wild type in HU (dNTPs, RPA and the Mec1-Rad53 signal at
one fork, Rad53's three targets, late origins held, S finished, anaphase),
rad53-21 in HU (late origins fire, forks collapse, Exo1 reaches the CEN, the
kinetochore lets go, premature extension), and the two HU runs side by side.
The slide 3 to 6 strains are left for a second lesson.


14. THE UNIFIED PROJECT AND THE TELOMERE SIDE
-----------------------------------------------------------------------------
Layout.

    src/, tools/, tour/      the replication viewer, as before, plus:
    telomere/                the telomere workflow, its own generator, engine
                             and standalone build (python3 telomere/build.py)
    tools/port_telomere.js   brings telomere/src into the viewer (build.py runs it)
    src/tw-panels/           the telomere panels, keys prefixed tw- (generated)
    src/telo-engine.js       the telomere engine closed over its own frame
                             tables, as TELO (generated)
    src/telo-style.css       the telomere glyph sheet scoped to .telo (generated)
    src/telo-refs.bib        telomere references src/refs.bib lacks (generated)
    src/nav-telomere.svg     the fifth chart, Telomere (generated)
    legacy/                  the two end-fate pages, untouched

    python3 build.py && python3 tools/make_tour.py
    -> dist/origins-and-telomeres.html, dist/origins-and-telomeres-tour.html

Two engines. The replication engine reads compound track strings; the
telomere engine paints strand halves and derives zones, Rap1 boxes and the cap
bar from them. clearPanel, applyFrame and paintDerived in src/animate.js hand
any tw- key to TELO, so each figure keeps the engine it was drawn for and the
shared transport, captions and citations serve both. Edit telomere panels in
telomere/ and rebuild; never edit the generated files.

The rule. src/chrom-rule.js now carries the telomere side (its header,
TELOMERES, gives every value and its source). In short: each end has a length
in bp and holds Rif1 in proportion to its Rap1 sites; Rif1 is the one protein
on RULE.crossing, so the copies the ends hold leave the origins' free pool;
a fork that reaches an end makes two daughter ends, sister 1 leading-made on
the left and lagging-made on the right; each daughter is processed through
the telomere workflow's steps; telomerase reaches it at random, with a hazard
solved from Teixeira et al. 2004 over the mean window of a wild-type end
(RULE.telWindowRef, measured over 1000 runs), and adds an exponential number
of nt (Chang et al. 2007); anaphase follows RULE.g2 min after S. Telomere
draws use a third seeded stream, so the origin side of a run with a given seed
is unchanged by them. New alleles: cdc13-2 and est2 deletion.

What changed on the origin side. Copying an end doubles its hold on Rif1, so
the free pool falls from 6 to 4 to 2 as the ends are copied. Across the
lesson's 24 conditions and 12 slide strains this moved one run: in the
stn1-OP dbf4-zn run, L3 now fires at 120 min, after the stretch the slide plays.
Anaphase now comes 20 min after S ends, which moves no slide strain's
scoring. The Rif1 reservoir holds up to 10 copies.

Known limits. The Rif1 pool is 10 whole copies, so the origin side answers
coarsely and not monotonically to length: a short left end fires L3 earlier
(Bianchi and Shore 2007), but so does a 600 bp end. Loss per cycle is the same
for leading- and lagging-made ends until Soudet et al. 2014's split is read.
The run is one cell cycle; there is no lineage across passages yet.

The view. The live panel holds both layers; data-view on the panel shows the
chromosome (.chrlayer) or the telomeres (.tvlayer). The telomere view draws
each end to length (TV_S units per bp) from its junction, sisters as rows,
the left end mirrored, with the free Rif1 and telomerase reservoirs in the
header band. Clicking an end puts it in the close-up, which plays the
telomere workflow panel of the step that end is at. Each view is audited
alone by the layout guard. A lesson beat shows the telomere view with
view: 'tel' and picks the close-up's end with telSite.
