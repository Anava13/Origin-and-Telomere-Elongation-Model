#!/usr/bin/env python3
"""Emit src/panels/*.svg, src/nav-steps.svg, src/nav-context.svg and
src/nav-models.svg.

Every glyph function takes coordinates and returns a string. No glyph function
writes a file, mutates state, or calls another glyph function except the
generic primitives and the fit-point helper. Composition happens in the panel
functions.

No fill or stroke literal appears in this file. Colour lives in src/style.css.

Shape carries function. Where two proteins bind, the outline of one is cut to
receive the other. Each such pair emits a matched fit point, socket on the
receiving glyph and seat on the arriving one, and the test suite asserts that
the two land on the same coordinate once every ancestor transform is applied.
"""

import os

# ===========================================================================
# GEOMETRY
# ---------------------------------------------------------------------------
# X0, CW, LEFT_CTX, ORIGIN_N, ARS_A and ARS_B are duplicated at the top of
# src/animate.js and compared by the test suite. They change together.
# ===========================================================================

VBW, VBH = 880, 300          # panel canvas, identical for every panel

X0 = 26                      # left edge of drawn position 1
CW = 18                      # width of one position, ~22 bp
LEFT_CTX = 14                # positions of left context
ORIGIN_N = 18                # positions of origin region
RIGHT_CTX = 14               # positions of right context
NPOS = LEFT_CTX + ORIGIN_N + RIGHT_CTX

ROW_T = 148                  # top strand bar, y
ROW_B = 159                  # bottom strand bar, y
BAR_H = 5
ZONE_Y, ZONE_H = 126, 62     # derived zone tint behind a position
CPX_Y, CPX_H = 212, 4        # complex-state track, below the glyph band

DNA_Y = (ROW_T + ROW_B + BAR_H) / 2.0       # 156.0

# Nucleosome spans, as inclusive linear index ranges. None inside the origin
# region: the nucleosome-free region is drawn, not narrated.
NUC_SPANS = [(1, 7), (8, 14), (33, 39), (40, 46)]

# Daughter-strand geometry. A nascent bar sits against the face of the
# parental bar it was copied from and takes the same translate, so it opens
# with its template and cannot drift away from it.
NASC_H = 4.0
NASC_GAP = 3.0                      # base-pair rungs between a daughter bar and its template
NASC_TOP_Y = ROW_T + BAR_H + NASC_GAP   # under the top bar
NASC_BOT_Y = ROW_B - NASC_H - NASC_GAP  # over the bottom bar
RUNG_DX = (CW / 4.0, 3.0 * CW / 4.0)    # two base-pair rungs per position
OKAZAKI_N = 8                       # positions per fragment, about 176 bp
PRIMER_W = 9.0                      # about 11 bp of RNA, at the drawn scale
NICK_W = 2.0                        # the gap left between two fragments
FORK_SPLIT = LEFT_CTX + ORIGIN_N // 2   # last position the left fork takes


def lin(pos_id):
    """Linear index 1..NPOS for a position id. Inverse of chunk_id."""
    fam, num = pos_id[0], int(pos_id[1:])
    if fam == 'l':
        return LEFT_CTX + 1 - num
    if fam == 'o':
        return LEFT_CTX + num
    return LEFT_CTX + ORIGIN_N + num


def chunk_id(i):
    """Position id for linear index i, 1..NPOS.

    Three families, each counted outward from its own start. No l00, no o00,
    no r00, no negative index. Duplicated as chunkId() in src/animate.js.
    """
    if i <= LEFT_CTX:
        return 'l%02d' % (LEFT_CTX + 1 - i)
    if i <= LEFT_CTX + ORIGIN_N:
        return 'o%02d' % (i - LEFT_CTX)
    return 'r%02d' % (i - LEFT_CTX - ORIGIN_N)


def cx(i):
    """Left edge x of linear index i."""
    return X0 + (i - 1) * CW


def mid(i):
    """Centre x of linear index i."""
    return cx(i) + CW / 2.0


def span_centre(a, b):
    """Centre x of the inclusive position span a..b, given as position ids."""
    return (cx(lin(a)) + cx(lin(b)) + CW) / 2.0


# ---------------------------------------------------------------------------
# Declared footprints.
#
# One MCM2-7 hexamer is drawn 54 units wide, which is exactly three positions,
# so a reader can still count positions to read a footprint. Every other
# footprint is set from that: the double hexamer is six positions and lands
# centred on the canvas at x = 440, which is what the fixed camera needs. The
# ARS block and the ORC footprint are the same four positions, because ORC
# binding the ARS is the claim step01 makes.
# ---------------------------------------------------------------------------

ARS_A, ARS_B = 'o03', 'o06'   # ARS block, ~88 bp, and the ORC footprint
ARS = (ARS_A, ARS_B)
OCCM = ('o07', 'o09')         # ORC-Cdc6-Cdt1-Mcm2-7 intermediate
H1 = ('o07', 'o09')           # first loaded hexamer
H2 = ('o10', 'o12')           # second loaded hexamer
DH = ('o07', 'o12')           # double hexamer, centred on the canvas

ARS_X = span_centre(*ARS)     # 350.0
OCCM_X = span_centre(*OCCM)   # 413.0
H1_X = span_centre(*H1)       # 413.0
H2_X = span_centre(*H2)       # 467.0
DH_X = span_centre(*DH)       # 440.0

# ===========================================================================
# LAYOUT GUARD
# ---------------------------------------------------------------------------
# Nothing in this file used to know how big anything was, so no build-time
# check could ask whether a label ran off the canvas or whether an actor came
# to rest on top of the status indicator. Both had happened, in twenty places,
# and the behavioural suite could not see either: it measures with getBBox,
# which reports local user space and ignores every ancestor transform, and it
# runs under jsdom, which has no text metrics at all.
#
# So the generator measures instead. Every emitted shape is parsed back out of
# the markup it just produced, text is measured against an advance table, and
# the build fails on an overflow or on an intrusion into the rectangle the
# status indicator occupies. Measuring the output rather than threading an
# extent through thirty constructors keeps the constructors as they are and
# still leaves one place that owns the answer.
#
# Actor boxes are widened by the full range of offsets the frame tables give
# them, read straight out of src/anim-data.js, so a parking position that only
# collides on frame four fails the build as loudly as one that collides at
# rest.
# ===========================================================================

import json
import math
import re

SAFE_PAD = 3.0                                  # canvas margin every box keeps
KEEPOUT = (VBW - 210.0, 14.0, VBW - 2.0, 136.0)  # the status indicator's corner

# Mean advance widths in units of 1/1000 em for the sans stack the page asks
# for. Generous by intent: a label that passes here and still overflows in a
# browser is worse than one rejected early.
_ADV_DEFAULT = 560
_ADV = {
    ' ': 278, '.': 278, ',': 278, ':': 278, ';': 278, '!': 278, '|': 260,
    "'": 200, '"': 355, '`': 333, '-': 340, '(': 333, ')': 333, '[': 278,
    ']': 278, '/': 278, '\\': 278, '?': 556, '*': 389, '+': 584, '=': 584,
    'i': 226, 'j': 226, 'l': 226, 't': 290, 'f': 290, 'r': 340, 'I': 278,
    'J': 500, 'm': 850, 'w': 730, 'M': 850, 'W': 950, 'A': 667, 'B': 667,
    'C': 722, 'D': 722, 'E': 667, 'F': 611, 'G': 778, 'H': 722, 'K': 667,
    'L': 556, 'N': 722, 'O': 778, 'P': 667, 'Q': 778, 'R': 722, 'S': 667,
    'T': 611, 'U': 722, 'V': 667, 'X': 667, 'Y': 667, 'Z': 611,
}

# Font size and anchor per text class, taken from src/style.css. A class that
# is not listed is a build error, because an unmeasured label is exactly the
# thing this guard exists to catch.
_TEXT_STYLE = {
    'notelab': (10.5, 'middle'), 'polelab': (10.0, 'middle'),
    'endlab': (9.0, 'middle'), 'arrowlab': (9.0, 'middle'),
    'brlab': (9.0, 'middle'), 'arslab': (8.0, 'middle'),
    'glyphlab': (10.0, 'middle'), 'dntplab': (7.5, 'middle'),
    'caplab': (9.5, 'start'), 'capname': (9.5, 'start'), 'capword': (8.5, 'middle'),
    'navtext': (10.0, 'start'), 'navnum': (9.0, 'start'),
    'navgrouplab': (9.5, 'start'), 'navbadgelab': (8.0, 'middle'),
    'cyclelab': (9.5, 'middle'), 'pairlab': (8.5, 'middle'),
    'chrlab': (11.0, 'start'), 'chrpar': (9.0, 'start'), 'chrtag': (8.0, 'middle'),
    'chrclock': (8.5, 'middle'), 'chrtick': (7.5, 'middle'), 'chrstate': (8.5, 'middle'),
    'chrout': (7.0, 'start'), 'chrev': (7.0, 'middle'),
    'tvtext': (8.0, 'start'), 'tvtexte': (8.0, 'end'), 'tvhead': (9.0, 'middle'),
    'tvglyph': (6.5, 'middle'), 'tvsis': (8.0, 'middle'),
    'tvstrandlab': (11.0, 'middle'),   # bold 10 px, measured wide
    'strandend': (6.0, 'start'), 'strandende': (6.0, 'end'),
}

# Size modifiers, which stack onto whichever base class the run carries.
_TEXT_MODS = {'sm': 8.5, 'xs': 7.0}


def text_width(s, size):
    """Advance width of one run of text at one font size."""
    return sum(_ADV.get(ch, _ADV_DEFAULT) for ch in s) / 1000.0 * size


def wrap_text(s, size, max_w):
    """Break one label into lines that each fit inside max_w."""
    words, lines, cur = s.split(' '), [], ''
    for w in words:
        trial = (cur + ' ' + w).strip()
        if cur and text_width(trial, size) > max_w:
            lines.append(cur)
            cur = w
        else:
            cur = trial
    if cur:
        lines.append(cur)
    return lines


def _text_box(cls, x, y, s):
    """Bounding box of one text run, as (x1, y1, x2, y2)."""
    parts = [c for c in cls.split() if c in _TEXT_STYLE or c in _TEXT_MODS]
    base = next((c for c in parts if c in _TEXT_STYLE), None)
    if base is None:
        raise ValueError('unmeasured text class %r' % cls)
    size, anchor = _TEXT_STYLE[base]
    for mod in parts:
        if mod in _TEXT_MODS:
            size = _TEXT_MODS[mod]
    w = text_width(s, size)
    x1 = x - w / 2.0 if anchor == 'middle' else (x - w if anchor == 'end' else x)
    return (x1, y - size * 0.82, x1 + w, y + size * 0.26)


_NUM = re.compile(r'-?\d*\.?\d+(?:[eE][-+]?\d+)?')
_CMD = re.compile(r'([MmLlHhVvCcSsQqTtAaZz])([^MmLlHhVvCcSsQqTtAaZz]*)')
_ARGC = {'M': 2, 'L': 2, 'H': 1, 'V': 1, 'C': 6, 'S': 4, 'Q': 4, 'T': 2, 'A': 7, 'Z': 0}


def path_points(d):
    """Every on-path point of one path, in user units.

    Arcs contribute their endpoint only. Radii and the two flags are not
    coordinates, and feeding them to a min/max would drag every box that
    contains an arc back towards the origin.
    """
    pts, cur, start = [], (0.0, 0.0), (0.0, 0.0)
    for cmd, body in _CMD.findall(d):
        up = cmd.upper()
        rel = cmd.islower()
        nums = [float(n) for n in _NUM.findall(body)]
        n = _ARGC[up]
        if up == 'Z':
            cur = start
            continue
        if n == 0 or not nums:
            continue
        for k in range(0, len(nums) - n + 1, n):
            a = nums[k:k + n]
            if up == 'H':
                x = cur[0] + a[0] if rel else a[0]
                cur = (x, cur[1])
            elif up == 'V':
                y = cur[1] + a[0] if rel else a[0]
                cur = (cur[0], y)
            else:
                dx, dy = a[-2], a[-1]
                cur = (cur[0] + dx, cur[1] + dy) if rel else (dx, dy)
            if up == 'M' and k == 0:
                start = cur
            pts.append(cur)
    return pts


_ATTR = re.compile(r'(\w[\w-]*)\s*=\s*"([^"]*)"')
_TAG = re.compile(r'<(/?)(\w+)([^>]*?)(/?)>')


def shape_box(tag, attrs):
    """Bounding box of one drawn element, or None if it draws nothing."""
    def f(name, default=0.0):
        try:
            return float(attrs.get(name, default))
        except ValueError:
            return default
    if tag == 'rect':
        x, y = f('x'), f('y')
        return (x, y, x + f('width'), y + f('height'))
    if tag == 'circle':
        r = f('r')
        if r <= 0:
            return None
        return (f('cx') - r, f('cy') - r, f('cx') + r, f('cy') + r)
    if tag == 'ellipse':
        return (f('cx') - f('rx'), f('cy') - f('ry'), f('cx') + f('rx'), f('cy') + f('ry'))
    if tag == 'path':
        pts = path_points(attrs.get('d', ''))
        if not pts:
            return None
        xs = [p[0] for p in pts]
        ys = [p[1] for p in pts]
        return (min(xs), min(ys), max(xs), max(ys))
    return None


def _union(a, b):
    if a is None:
        return b
    if b is None:
        return a
    return (min(a[0], b[0]), min(a[1], b[1]), max(a[2], b[2]), max(a[3], b[3]))


def markup_boxes(svg):
    """Every drawn box in one markup string, keyed by the enclosing actor id.

    Returns (per_actor, all_text). per_actor maps an actor id to the union of
    everything inside it; all_text is (class, box, string) for every text run.
    """
    per_actor, text_runs = {}, []
    stack, pos = [], 0
    while True:
        m = _TAG.search(svg, pos)
        if not m:
            break
        closing, tag, raw, selfclose = m.group(1), m.group(2), m.group(3), m.group(4)
        if closing:
            if stack:
                stack.pop()
            pos = m.end()
            continue
        attrs = dict(_ATTR.findall(raw))
        live = [i for i in stack if i]
        if tag == 'g' and 'mini' in attrs.get('class', '').split() and 'data-box' in attrs \
                and not selfclose:
            # A miniature is drawn scaled, which this parser does not apply, so
            # its declared box stands in for everything inside it.
            box = tuple(float(v) for v in attrs['data-box'].split())
            for ident in live:
                per_actor[ident] = _union(per_actor.get(ident), box)
            depth, k = 1, m.end()
            while depth:
                n = _TAG.search(svg, k)
                if n.group(2) == 'g' and not n.group(4):
                    depth += -1 if n.group(1) else 1
                k = n.end()
            pos = k
            continue
        if tag == 'text':
            end = svg.find('</text>', m.end())
            body = re.sub(r'<[^>]*>', '', svg[m.end():end if end >= 0 else len(svg)])
            if body.strip():
                box = _text_box(attrs.get('class', ''), float(attrs.get('x', 0)),
                                float(attrs.get('y', 0)), body)
                text_runs.append((attrs.get('class', ''), box, body))
                for ident in live:
                    per_actor[ident] = _union(per_actor.get(ident), box)
            pos = (end + 7) if end >= 0 else m.end()
            continue
        box = shape_box(tag, attrs)
        if box is not None:
            for ident in live:
                per_actor[ident] = _union(per_actor.get(ident), box)
        if not selfclose:
            ident = attrs.get('id', '')
            if ident.startswith('actor-'):
                stack.append(ident)
                per_actor.setdefault(ident, None)
            else:
                stack.append('')
        pos = m.end()
    return per_actor, text_runs


def overlaps(a, b):
    return a and b and a[0] < b[2] and a[2] > b[0] and a[1] < b[3] and a[3] > b[1]


def load_anim_table():
    """The frame tables in src/anim-data.js, parsed, or {} if there are none."""
    here = os.path.dirname(os.path.abspath(__file__))
    path = os.path.join(os.path.dirname(here), 'src', 'anim-data.js')
    if not os.path.exists(path):
        return {}
    # UTF-8 explicitly, as build.py reads it, so the parse does not depend on
    # the platform's default codec (cp1252 on Windows).
    with open(path, encoding='utf-8') as f:
        txt = f.read()
    start = txt.index('{', txt.index('var ANIM'))
    depth, end = 0, start
    for k in range(start, len(txt)):
        if txt[k] == '{':
            depth += 1
        elif txt[k] == '}':
            depth -= 1
            if depth == 0:
                end = k + 1
                break
    return json.loads(txt[start:end])


def load_frame_offsets():
    """Actor offset ranges per panel, read from the frame tables.

    A parking position that only collides on one frame has to fail the build as
    loudly as one that collides at rest, so the box a panel is checked against
    is the base box widened by every offset the frames give it.
    """
    return dict((key, table_offsets(tab)) for key, tab in load_anim_table().items())


def table_offsets(tab):
    """Offset range of every actor across one panel's frame table."""
    spans = {}
    for frame in tab.get('frames', []):
        for ident, off in (frame.get('actors') or {}).items():
            dx, dy = (off if isinstance(off, list) else (off, 0.0))
            x0, x1, y0, y1 = spans.get(ident, (0.0, 0.0, 0.0, 0.0))
            spans[ident] = (min(x0, float(dx)), max(x1, float(dx)),
                            min(y0, float(dy)), max(y1, float(dy)))
    return spans


def audit_panel(key, svg, offsets):
    """Fail the build on a label off the canvas or a glyph on the indicator."""
    bad = []
    per_actor, text_runs = markup_boxes(svg)
    lim = (SAFE_PAD, SAFE_PAD, VBW - SAFE_PAD, VBH - SAFE_PAD)
    for cls, box, body in text_runs:
        if box[0] < lim[0] or box[2] > lim[2] or box[1] < lim[1] or box[3] > lim[3]:
            bad.append('text off canvas: %r at %.1f..%.1f' % (body[:44], box[0], box[2]))
    # Two labels that overlap are as unreadable as one that runs off the edge,
    # and the browser suite cannot see either. Glyph labels sit inside their own
    # shapes and are checked against each other only, which is what catches two
    # glyphs coming to rest on the same spot.
    for a in range(len(text_runs)):
        for b in range(a + 1, len(text_runs)):
            ca, ba, sa = text_runs[a]
            cb, bb, sb = text_runs[b]
            if 'alt' in ca.split() and 'alt' in cb.split():
                # Two states of one label, written at one place on purpose;
                # the frames show exactly one of them at a time.
                continue
            if 'glyphlab' in ca and 'glyphlab' in cb:
                # Two labels inside two glyphs. Derived glyphs share a span on
                # purpose and only one of them is ever shown, so a pair of
                # these is not evidence of anything.
                continue
            if (min(ba[2], bb[2]) - max(ba[0], bb[0]) > 1.5
                    and min(ba[3], bb[3]) - max(ba[1], bb[1]) > 1.5):
                bad.append('labels overlap: %r and %r' % (sa[:32], sb[:32]))
    for ident, box in per_actor.items():
        if box is None:
            continue
        x0, x1, y0, y1 = offsets.get(key, {}).get(ident, (0.0, 0.0, 0.0, 0.0))
        wide = (box[0] + x0, box[1] + y0, box[2] + x1, box[3] + y1)
        # A chromosome fork reaching a telomere runs off the end of the chromosome,
        # which is the same claim CAMERA_EXIT makes for the origin panels' forks.
        # A live panel's copied strip waits off its clip until a run slides it
        # in, and only the clipped part is ever drawn; so do the spindle
        # gauge's fill and the clips that reveal a resected stretch.
        exempt = (ident in CAMERA_EXIT or ident in OFFSTAGE.get(key, ())
                  or ident.startswith('actor-chrfork-')
                  or (key == 'chrLIVE' and (ident.startswith('actor-copy-') or ident == 'actor-spl'
                                            or ident.startswith('actor-resclip-'))))
        if not exempt and (wide[0] < lim[0] or wide[2] > lim[2]
                           or wide[1] < lim[1] or wide[3] > lim[3]):
            bad.append('%s off canvas: x %.1f..%.1f y %.1f..%.1f'
                       % (ident, wide[0], wide[2], wide[1], wide[3]))
        # Resting positions must clear the indicator. Travel across it is
        # allowed and reads correctly, because the indicator sits on an opaque
        # plate: a glyph passing behind it is occluded, and a glyph parked
        # behind it would simply be missing.
        # A panel with no status indicator has no plate to park behind.
        if 'capbar' in svg and overlaps(box, KEEPOUT):
            bad.append('%s parks on the status indicator: %.1f..%.1f x %.1f..%.1f'
                       % (ident, box[0], box[2], box[1], box[3]))
    if bad:
        raise SystemExit('%s layout: \n  %s' % (key, '\n  '.join(bad)))


# The two forks and what rides them leave the frame on purpose, which is the
# drawn form of the claim that they keep going. Everything else that leaves it
# is a mistake.
CAMERA_EXIT = ('actor-cmg-l', 'actor-cmg-r', 'actor-cmg-l-b', 'actor-cmg-r-b',
               'actor-dntp-l', 'actor-dntp-r', 'actor-mrc-l', 'actor-mrc-r',
               'actor-pola-l', 'actor-pola-r', 'actor-pole-l', 'actor-pole-r',
               'actor-fork-l', 'actor-fork-r', 'actor-rpa-l', 'actor-rpa-r')

# An actor that starts outside the canvas and comes in. This is not the same
# permission CAMERA_EXIT gives and it is scoped to the panel that needs it: a
# factor arriving out of the nucleoplasm has somewhere to arrive from, and a
# glyph that begins on the page beside its target has already arrived. The
# resting box is still checked against the status indicator.
#
# Every factor on the main line now arrives this way and leaves this way, so
# the list is long: a protein never fades in where it acts or fades out where
# it acted. It travels from off the page and back off it.
OFFSTAGE = {
    'step01': ('actor-search',),
    'step02': ('actor-cdc6in',),
    'step03': ('actor-hept', 'actor-hept-b', 'actor-cdc6out', 'actor-cdt1out'),
    'step04': ('actor-cdc6in',),
    'step05': ('actor-mcm-2', 'actor-mcm-2-b', 'actor-cdc6out2', 'actor-cdt1out2'),
    'step06': ('actor-ddk',),
    'step07': ('actor-sld3', 'actor-sld3-b', 'actor-cdc45l', 'actor-cdc45r'),
    'step08': ('actor-scdk', 'actor-sld2free'),
    'step09': ('actor-dpb11', 'actor-ginsfree', 'actor-polefree', 'actor-ginsfree2',
               'actor-polefree2', 'actor-sld2c', 'actor-sld3', 'actor-sld3-b'),
    'step10': ('actor-mcm10',),
    'step11': ('actor-polain-l', 'actor-polain-r', 'actor-polein-l', 'actor-polein-r',
               'actor-rpain-l', 'actor-rpain-r', 'actor-mrcin-l', 'actor-mrcin-r',
               'actor-dntpein-l', 'actor-dntpein-r', 'actor-dntpain-l', 'actor-dntpain-r'),
    # The animated models bring their factors in from off the canvas as the
    # main-line panels they replay do.
    'cstCONF': ('actor-ddk',),
    'cstCDC7': ('actor-ddk',),
    'cstRIF1': ('actor-ddk',),
    'cstBOB1': ('actor-sld3', 'actor-sld3-b'),
    'cstPOLA': ('actor-polain-l', 'actor-polain-r'),
}


# ===========================================================================
# GENERIC PRIMITIVES
# ===========================================================================


def esc(s):
    return (s.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;'))


def fitpoint(name, role, x, y):
    """One half of a complementary fit.

    Zero-radius, so it draws nothing. The test suite pairs socket with seat by
    name, walks the ancestor translates of each, and fails if the two land more
    than 0.6 units apart.
    """
    return ('<circle class="fitpt" data-fit="%s" data-role="%s" cx="%.2f" '
            'cy="%.2f" r="0"/>' % (name, role, x, y))


def protein(x, y, w, label, cls, ident=None, h=22):
    """Labelled box. Used only where no complementary shape is claimed."""
    i = ' id="%s"' % ident if ident else ''
    out = ['<g class="prot %s"%s>' % (cls, i)]
    out.append('<rect class="protbox" x="%.1f" y="%.1f" width="%.1f" height="%d" rx="4"/>'
               % (x - w / 2.0, y - h / 2.0, w, h))
    out.append('<text class="glyphlab" x="%.1f" y="%.1f">%s</text>'
               % (x, y + 4, esc(label)))
    out.append('</g>')
    return ''.join(out)


def rif1_glyph(x, y, r=16.0):
    """VIEW: Rif1 as the telomere panels draw it, a lilac disc carrying its name (TERMINAL)

    One shape for Rif1 everywhere: bound to Rap1 at a telomere, as a copy in
    the chromosome panel's reservoir, and acting with PP1 at an origin.
    """
    return ('<g class="prot rif1glyph"><circle class="rif1" cx="%.1f" cy="%.1f" r="%.1f"/>'
            '<text class="glyphlab sm" x="%.1f" y="%.1f">Rif1</text></g>' % (x, y, r, x, y + 3.5))


def arrow(x1, y1, x2, y2, label='', curve=0, labelside='top', ident=None, key='',
          ctrl=None, proposed=False):
    """One causal step.

    curve lifts the control point of a quadratic off the midpoint. ctrl names
    the control point outright, for an arrow that has to go round something
    rather than over it; a label is not placed on such an arrow.

    proposed draws the step as a proposal: the heaviest line in the figure,
    dashed, in the CST blue, ending in an open chevron, with its label in the
    same blue. A proposal is what a reader of a printed figure has to find
    first, and the dash and the open head say it is not established.
    """
    i = ' id="%s"' % ident if ident else ''
    p = ' prop' if proposed else ''
    if ctrl is not None:
        d = 'M%.1f %.1f Q%.1f %.1f %.1f %.1f' % (x1, y1, ctrl[0], ctrl[1], x2, y2)
        label = ''
    elif curve:
        mx, my = (x1 + x2) / 2.0, (y1 + y2) / 2.0 - curve
        d = 'M%.1f %.1f Q%.1f %.1f %.1f %.1f' % (x1, y1, mx, my, x2, y2)
    else:
        d = 'M%.1f %.1f L%.1f %.1f' % (x1, y1, x2, y2)
    out = ['<g class="arr%s"%s>' % (p, i)]
    out.append('<path class="arrline%s" d="%s" marker-end="url(#%s-%s)"/>'
               % (p, d, 'ahp' if proposed else 'ah', key))
    if label:
        ly = min(y1, y2) - (curve or 0) - 5 if labelside == 'top' else max(y1, y2) + 13
        out.append('<text class="arrowlab%s" x="%.1f" y="%.1f">%s</text>'
                   % (p, (x1 + x2) / 2.0, ly, esc(label)))
    out.append('</g>')
    return ''.join(out)


def inhibit(x1, y1, x2, y2, label='', ident=None, proposed=False):
    """A blocked interaction. Blunt bar, never an arrowhead.

    proposed draws it in the proposal style arrow() uses: heavy, dashed and
    blue, with a solid blue bar at the end.
    """
    i = ' id="%s"' % ident if ident else ''
    p = ' prop' if proposed else ''
    dx, dy = x2 - x1, y2 - y1
    n = max((dx * dx + dy * dy) ** 0.5, 0.001)
    w = 7.0 if proposed else 5.0
    px, py = -dy / n * w, dx / n * w
    out = ['<g class="inh%s"%s>' % (p, i)]
    out.append('<path class="inhline%s" d="M%.1f %.1f L%.1f %.1f"/>' % (p, x1, y1, x2, y2))
    out.append('<path class="inhbar%s" d="M%.1f %.1f L%.1f %.1f"/>'
               % (p, x2 + px, y2 + py, x2 - px, y2 - py))
    if label:
        out.append('<text class="arrowlab%s" x="%.1f" y="%.1f">%s</text>'
                   % (p, (x1 + x2) / 2.0, min(y1, y2) - 5, esc(label)))
    out.append('</g>')
    return ''.join(out)


# The phosphorylation arrow. A kinase placing a phosphate is the one transfer
# the figure draws as an arrow of its own: a filled block in the phosphate
# yellow, outlined in black, from the edge of the kinase burst to the edge of
# the mark it places. It is shown on one frame only, the first on which the mark
# appears, so it reads as the event and not as a standing relation. The block
# shape keeps it apart from the line arrows that carry proposals, in greyscale
# as well as in colour.
KIN_SHAFT = 2.4               # half the width of the shaft
KIN_HEAD = 6.0                # half the width of the head at its base
KIN_HEAD_L = 8.5              # head length
KIN_TAIL_R = 29.0             # the tail sits on the spikes of a 30-unit burst
KIN_TIP_GAP = 7.0             # the tip stops this far from the mark centre


def kin_ends(burst, mark, ctrl=None):
    """MODEL: tail and tip of a phosphorylation arrow (TERMINAL).

    The tail leaves the burst toward the control point, or toward the mark when
    the arrow is straight, and the tip stops short of the mark along the line
    it arrives on, so the head points at the star without covering it.
    """
    import math
    aim = ctrl or mark
    dx, dy = aim[0] - burst[0], aim[1] - burst[1]
    n = math.hypot(dx, dy)
    tail = (burst[0] + dx / n * KIN_TAIL_R, burst[1] + dy / n * KIN_TAIL_R)
    src = ctrl or tail
    ex, ey = mark[0] - src[0], mark[1] - src[1]
    m = math.hypot(ex, ey)
    tip = (mark[0] - ex / m * KIN_TIP_GAP, mark[1] - ey / m * KIN_TIP_GAP)
    return tail, tip


def kin_arrow(x1, y1, x2, y2, ctrl=None):
    """A kinase placing a phosphate. One closed outline, shaft and head.

    ctrl bends the shaft through a quadratic, for an arrow that has to come at
    its mark from the side because another mark stands in the straight line.
    The outline is built from offsets of the centre line, so the shaft keeps its
    width round the bend.
    """
    import math
    n = 24 if ctrl else 2
    pts = []
    for k in range(n + 1):
        t = k / float(n)
        if ctrl:
            u = 1.0 - t
            pts.append((u * u * x1 + 2 * u * t * ctrl[0] + t * t * x2,
                        u * u * y1 + 2 * u * t * ctrl[1] + t * t * y2))
        else:
            pts.append((x1 + (x2 - x1) * t, y1 + (y2 - y1) * t))
    # Walk back from the tip one head length to find where the head starts.
    run, base, shaft = 0.0, pts[0], [pts[0]]
    for k in range(n, 0, -1):
        seg = math.hypot(pts[k][0] - pts[k - 1][0], pts[k][1] - pts[k - 1][1])
        if run + seg >= KIN_HEAD_L:
            f = (KIN_HEAD_L - run) / seg
            base = (pts[k][0] + (pts[k - 1][0] - pts[k][0]) * f,
                    pts[k][1] + (pts[k - 1][1] - pts[k][1]) * f)
            shaft = pts[:k] + [base]
            break
        run += seg
    left, right = [], []
    for k, p in enumerate(shaft):
        a = shaft[min(k + 1, len(shaft) - 1)]
        b = shaft[max(k - 1, 0)]
        tx, ty = a[0] - b[0], a[1] - b[1]
        tn = math.hypot(tx, ty) or 1.0
        nx, ny = -ty / tn, tx / tn
        left.append((p[0] + nx * KIN_SHAFT, p[1] + ny * KIN_SHAFT))
        right.append((p[0] - nx * KIN_SHAFT, p[1] - ny * KIN_SHAFT))
    hx, hy = x2 - base[0], y2 - base[1]
    hn = math.hypot(hx, hy) or 1.0
    nx, ny = -hy / hn, hx / hn
    ring = (left + [(base[0] + nx * KIN_HEAD, base[1] + ny * KIN_HEAD), (x2, y2),
                    (base[0] - nx * KIN_HEAD, base[1] - ny * KIN_HEAD)]
            + list(reversed(right)))
    d = 'M' + ' L'.join('%.1f %.1f' % p for p in ring) + ' Z'
    return '<g class="kinarr"><path class="kinarrbody" d="%s"/></g>' % d


def hourglass(x, y):
    """A delay. Marks an arrow whose effect comes after the state drawn.

    Two triangles meeting at a waist, between a cap and a base. It sits on the
    arrow it qualifies, so it reads as a property of that step and not of
    either end.
    """
    return ('<g class="hglass"><path class="hglassframe" d="M%.1f %.1f L%.1f %.1f '
            'M%.1f %.1f L%.1f %.1f"/><path class="hglassbody" d="M%.1f %.1f L%.1f %.1f '
            'L%.1f %.1f Z M%.1f %.1f L%.1f %.1f L%.1f %.1f Z"/></g>'
            % (x - 5.5, y - 7.5, x + 5.5, y - 7.5, x - 5.5, y + 7.5, x + 5.5, y + 7.5,
               x - 4.0, y - 7.0, x + 4.0, y - 7.0, x, y,
               x - 4.0, y + 7.0, x + 4.0, y + 7.0, x, y))


def note_marker(x, y, symbol):
    """A footnote mark on a glyph: a white disc with a black outline and one
    symbol in it, keyed in the caption.

    Used where a proposal sits on a surface CST already touches and the name of
    the proposal, set beside it, would need a leader to reach it. The disc
    carries the reference and the caption carries the name.
    """
    return ('<g class="notemark"><circle class="notemarkdisc" cx="%.1f" cy="%.1f" r="6"/>'
            '<text class="glyphlab sm" x="%.1f" y="%.1f">%s</text></g>'
            % (x, y, x, y + 4.5 if symbol == '*' else y + 3.0, esc(symbol)))


def link(x1, y1, x2, y2, ident=None):
    """Plain connector. Claims adjacency, no direction and no causality."""
    i = ' id="%s"' % ident if ident else ''
    return ('<path class="lnk" d="M%.1f %.1f L%.1f %.1f"%s/>' % (x1, y1, x2, y2, i))


def bracket(x1, x2, y, label):
    """Named span under the substrate."""
    return ('<g class="brk"><path class="brkline" d="M%.1f %.1f L%.1f %.1f L%.1f %.1f '
            'L%.1f %.1f"/><text class="brlab" x="%.1f" y="%.1f">%s</text></g>'
            % (x1, y - 4, x1, y, x2, y, x2, y - 4, (x1 + x2) / 2.0, y + 12, esc(label)))


def meter_h(x, y, w, frac, fill):
    """VIEW: a horizontal gauge, filled to frac, its dashed mark at the end (TERMINAL)

    The figures' drawing of the chromosome panel's Mec1 signal gauge.
    """
    return ('<rect class="chrmeter" x="%.1f" y="%.1f" width="%.1f" height="14"/>'
            '<rect class="%s" x="%.1f" y="%.1f" width="%.1f" height="14"/>'
            '<path class="chrtheta" d="M%.1f %.1f V%.1f"/>'
            % (x, y, w, fill, x, y, w * frac, x + w, y - 5, y + 19))


def wedge(x, y, r, cls, label='', ident=None):
    """Quarter disc. RPA and RPA-like ssDNA binders."""
    i = ' id="%s"' % ident if ident else ''
    d = 'M%.1f %.1f L%.1f %.1f A%.1f %.1f 0 0 1 %.1f %.1f Z' % (x, y, x + r, y, r, r, x, y - r)
    out = ['<g class="wdg %s"%s>' % (cls, i), '<path class="wdgpath" d="%s"/>' % d]
    if label:
        out.append('<text class="glyphlab sm" x="%.1f" y="%.1f">%s</text>'
                   % (x + r * 0.42, y - r * 0.35, esc(label)))
    out.append('</g>')
    return ''.join(out)


def fx(ident, body, pending=True, state=None):
    """Frame-addressable wrapper. Starts invisible unless pending is False.

    state names a resting presence outright, for the one static panel that
    draws a factor still on its way in: an arriving wrapper prints at half
    strength, which is the drawn form of present in the cell and not yet acting.
    """
    return '<g id="%s" class="fx %s">%s</g>' % (
        ident, state or ('gone' if pending else 'present'), body)


def actor(ident, body, basex=None):
    """Anything a frame or the derived layer translates."""
    b = ' data-basex="%.1f"' % basex if basex is not None else ''
    return '<g id="actor-%s" class="act"%s>%s</g>' % (ident, b, body)


NOTE_W = 840.0                # widest a free note may run before it wraps
LABEL_W = 320.0               # widest an in-panel label may run


def _lines(cls, x, y, text, max_w, lead):
    """One label as one or more lines, each measured before it is emitted.

    A label too wide for the space it sits in wraps here rather than running
    off the canvas, and the layout guard fails the build if a wrapped line is
    still too wide for where it was placed.
    """
    size = _TEXT_STYLE[cls.split()[0]][0]
    rows = wrap_text(esc(text), size, max_w)
    y0 = y - (len(rows) - 1) * lead
    return ''.join('<text class="%s" x="%.1f" y="%.1f">%s</text>'
                   % (cls, x, y0 + k * lead, row) for k, row in enumerate(rows))


def notelab(text, y=284, x=VBW / 2.0, max_w=NOTE_W):
    """Free note under the substrate."""
    return _lines('notelab', x, y, text, max_w, 13.0)


def polelab(x, y, text, max_w=LABEL_W):
    """In-panel pointer label. Names what a glyph is doing, not what it is."""
    return _lines('polelab', x, y, text, max_w, 12.0)


def endlab(x, y, text, max_w=LABEL_W):
    """Quiet label under a glyph."""
    return _lines('endlab', x, y, text, max_w, 11.0)


def condition_strip(ident, label, x=VBW / 2.0, pending=True):
    """Named condition covering the frames it is turned on for.

    pending=False shows it at rest, which is what a static panel whose whole
    content runs under the condition needs.
    """
    return fx(ident, '<g class="cond"><rect class="condbox" x="%.1f" y="8" width="250" '
              'height="18" rx="9"/><text class="glyphlab" x="%.1f" y="21">%s</text></g>'
              % (x - 125, x, esc(label)), pending=pending)


# ===========================================================================
# MODEL GLYPH VOCABULARY
# ---------------------------------------------------------------------------
# Silhouette carries identity and function. Where two glyphs bind, the outline
# of one is cut to receive the other, so an assembled complex reads as seated
# parts and a disassembled one reads as parts that could seat.
# ===========================================================================

# --- MCM2-7 ---------------------------------------------------------------
#
# One hexamer is a ring seen edge on. Three subunits face the viewer and three
# sit behind them, and the two arcs go into different layers, so the strand
# bars pass between them: the front arc is drawn over the substrate and the
# back arc under it.
#
# One subunit lies along the DNA axis. A narrow C-terminal point faces away
# from the seam, then the AAA+ body, then the N-terminal flange, which ends in
# a tooth pointing at the seam. Head-to-head contact is N face to N face, so
# the tooth sits on the N end and never on the C point. The two ends carry
# different profiles for that reason and not for decoration.
#
# Ring order is Mcm2, Mcm6, Mcm4, Mcm7, Mcm3, Mcm5, with the discontinuity
# between Mcm5 and Mcm2. Cutting that ring along the plane of the page puts
# Mcm2, Mcm5 and Mcm3 on one arc and Mcm6, Mcm4 and Mcm7 on the other, three
# rows deep, one subunit from each arc in every row.
#
# The right hexamer of a double hexamer is the left one turned through 180
# degrees about the vertical axis in the seam plane. Row heights survive that
# and the two arcs swap, so the right hexamer shows Mcm6, Mcm4 and Mcm7 to the
# viewer and carries its 2/5 gate on the far side. Row for row the seam pairs
# Mcm2 with Mcm6, Mcm5 with Mcm4 and Mcm3 with Mcm7 on the near side, and the
# same three pairs reversed on the far side. No subunit faces itself.
#
# The two hexamers are also offset by half a row, which is what lets the N
# teeth interleave instead of butting flat. That offset belongs to the pair, so
# a lone hexamer carries none and stays centred on the DNA axis.

MCM_W = 54.0                 # one hexamer, exactly three positions
MCM_HALF = MCM_W / 2.0

MCM_TIP_O = -27.0            # C-terminal point, outer end
MCM_TIP_I = -22.0
MCM_BODY_R = 14.0            # body to flange boundary
MCM_FLG_R = 23.0             # flange to tooth boundary
MCM_TOOTH_X = 30.0           # tooth apex, past the seam so the teeth interleave

# What is left between two interlocked N faces, the same at every height: twice
# the run from the seam plane back to the flange root, less the tooth.
MCM_SEAM_GAP = 2.0 * (27.0 - 23.0) - (30.0 - 23.0)

MCM_BODY_H = 16.0
MCM_BACK_H = 18.0
MCM_BACK_INSET = 5.0         # the back arc is shorter at its C end, so it reads
                             # further away. Its N end is not inset: both walls
                             # of the ring meet the partner in the same plane.

MCM_ROWS = (-18.0, 0.0, 18.0)
MCM_ROW_PITCH = MCM_ROWS[1] - MCM_ROWS[0]

# The N face is one triangular wave and not a row of separate teeth. Each
# flange is full height at the trough and tapers to a point at the row centre,
# so the flanges of one arc join into a continuous zigzag of period
# MCM_ROW_PITCH. Two of those interlock exactly when one is offset by half a
# pitch: the two waves are then complements of each other, their heights sum to
# one at every y, and the gap between them is the same width all the way down.
# That is why the flange height has to equal the row pitch and the offset
# within a pair has to be half of it. Any other numbers give teeth that either
# overlap or float apart.
MCM_FLANGE_H = MCM_ROW_PITCH
MCM_DH_SKEW = MCM_ROW_PITCH / 4.0    # applied both ways, so a pair differs by
                                     # half a pitch

# The view is a shade off the ring axis, so the far wall rides above the near
# one instead of hiding behind it. The lift is the same for both arcs of both
# hexamers, so it moves every row together and leaves the seam pairing exactly
# where it was: near face pairs Mcm2 with Mcm6, Mcm5 with Mcm4, Mcm3 with Mcm7,
# and the far face pairs the same three the other way round.
MCM_BACK_LIFT = -13.0
MCM_ARC_GATE = ('2', '5', '3')      # the arc carrying the Mcm2-Mcm5 gate
MCM_ARC_SOLID = ('6', '4', '7')

# Opening the gate swings the lower two subunits of the gate arc away, which is
# what admits DNA to the channel. Closing brings them back and the ring
# encloses it. The shift is written in CSS and not baked into the markup,
# because the gate is a declared state the engine changes between frames.
MCM_GATE_SHIFT = {'2': -10.0, '5': 16.0, '3': 16.0}
MCM_GATE_VALUES = ['gate-open', 'gate-closed', 'gate-sealed']

MCM_DDK_SUBS = ('2', '4', '6')      # the DDK targets, N-terminal tails
MCM_MIMIC_SUBS = ('4', '6')         # the phosphomimetic allele drawn in offPHOS

# The DDK marks are drawn in two groups because they appear at two different
# points in the model. The Mcm4 and Mcm6 marks land with the kinase in step 6:
# they relieve the NSD inhibition and they are the sites Sld3 reads. The Mcm2
# marks do not land until the clasp has seated in step 7. DDK phosphorylates
# Mcm2 in vitro on its own, but in vivo Mcm2 phosphorylation is undetectable
# in S phase in cells whose Sld3 cannot stimulate the kinase, so the mark is
# drawn arriving once Sld3 is on the pair. It rides its own wrapper, fx-mcm2p,
# so a frame can bring it in without touching the tail marks.
MCM_TAIL_SUBS = ('4', '6')          # placed by DDK alone, read by Sld3

# The four tail marks in the order a pair gains them as its DDK marks build.
# The origin's meter counts 20 marks to the line (RULE.theta in
# src/chrom-rule.js), and the pair draws one mark for each quarter of that:
# the left Mcm6 mark from 5, the right Mcm6 mark from 10, the left Mcm4 mark
# from 15. At the line the near Mcm4 mark lands on the NSD, which moves off its
# seat and lets Sld3 bind; below the line the NSD stays seated and blocks
# Sld3. Rif1-PP1 removing marks takes them off in the reverse order.
# src/chrom-frames.js reads the same order (MARK_ORDER) to pick each stage.
MCM_MARK_ORDER = ('l6', 'r6', 'l4', 'nsd')
MCM_GATE_MARK = ('2',)              # placed once Sld3 stimulates the kinase

# The Mcm4 NSD is the fifth declared quantity and rides the complex group as
# its own class family, for the same reason gate does. Whether the NSD sits on
# its seat, has been displaced from it, or has been deleted is a claim about
# the step and not a consequence of what occupies the position: the double
# hexamer is loaded with the NSD seated, DDK displaces it, and the Mcm4
# N-terminal deletion removes it. The two hexamers themselves never move
# relative to each other before CMG assembly.
#
# The seated NSD is drawn at the underside of the seam, across the half-row
# step, which is the surface the Sld3-Sld7 clasp takes. Displaced, it hangs off
# that surface and carries the Mcm4 mark into a cleft cut in the clasp floor.
# Both forms hang off the Mcm4 tooth of the near hexamer, which is the N end the
# NSD belongs to, and the one near-side glyph stands for the NSD of both
# hexamers. Every coordinate below is derived from the pair's own profile, so
# retuning the flange numbers moves the NSD with the surface it sits on.
#
# A third form, released, is off its seat with no mark on it. It is the
# figure's picture of the inhibition lifted without DDK, which is what the
# mcm5-bob1 panel needs: the displaced form is the DDK form, with its tail in
# the clasp cleft and the Mcm4 mark at its tip, and borrowing it would draw
# bob1 as reaching the state the kinase produces. The released block is the
# seated block turned about the seam join and folded flat against the near
# face of the pair, above the underside everywhere, so the clasp floor meets
# nothing. No structure shows this conformation; like the other two forms it
# is a projection, and the caption says so.
NSD_VALUES = ['nsd-na', 'nsd-seated', 'nsd-displaced', 'nsd-released', 'nsd-absent']

NSD_SEAT_BACK = 8.0          # how far the seat runs left of the seam join
NSD_SEAT_FWD = 5.0           # how far it runs right of the step foot
NSD_SEAT_DROP = 14.7         # deepest point of the angled face below the step
NSD_SEAT_HEEL = 6.5          # depth of the angled face at its left end
NSD_STAR_DX, NSD_STAR_DY = 8.0, 6.5   # the mark, from the step foot
NSD_TAIL_W = 3.0             # width of the NSD tail ribbon
NSD_REL_TURN = 95.0          # degrees the released block is turned, anticlockwise
NSD_REL_SHIFT = (8.0, -1.0)  # then moved clear of the underside, onto the Mcm7 row

# The bob1 tooth. Pro83 lies in the Mcm5 N-terminal domain near the interface
# between the hexamers, and the tooth is where the glyph draws that domain, so
# the allele is drawn as a blunted Mcm5 tooth. Only the outline changes; no fit
# is added to or removed from any wild-type panel.
BOB1_BLUNT = 4.0             # how far the Mcm5 tooth apex is cut back


def mcm_arcs(side):
    """(front, back) subunit triples for a hexamer facing one way.

    'left' shows the gate arc. 'right' is the same object turned about the
    vertical axis, so it shows the solid arc and carries its gate on the far
    side.
    """
    if side == 'right':
        return MCM_ARC_SOLID, MCM_ARC_GATE
    return MCM_ARC_GATE, MCM_ARC_SOLID


def mcm_gate_face(side):
    """Which of the two layers the 2/5 gate of this hexamer lands in."""
    return 'back' if side == 'right' else 'front'


def mcm_row(sub, side='left', skew=0.0, gate='closed'):
    """Row offset of one subunit, in panel units from the hexamer centre.

    gate is honoured only by callers that need the open position for a fixed
    annotation. Emitted subunit geometry is always the closed one.
    """
    front, back = mcm_arcs(side)
    in_front = sub in front
    arc = front if in_front else back
    dy = MCM_ROWS[arc.index(sub)] + skew
    if not in_front:
        dy += MCM_BACK_LIFT
    if gate == 'open' and sub in MCM_GATE_SHIFT:
        dy += MCM_GATE_SHIFT[sub]
    return dy


def mcm_seat(x, y, sub, side='left', skew=0.0):
    """Outer end of one subunit body, in panel coordinates.

    Where Cdc45 scallops onto the Mcm2 and Mcm5 bodies. The outer end is the C
    side, away from the seam, because in a double hexamer the seam side is
    occupied by the other hexamer and anything seated there would be drawn
    inside it. The row is the closed row.

    Cdc45 meets these points in two states. Before GINS arrives it is partly
    seated: its Mcm5 corner sits on the Mcm5 point and its Mcm2 corner is
    tilted CDC45_TILT_HOLD off the Mcm2 point, which is claimed as the cdc45p
    fit on a closed gate. Once GINS arrives it lies flat on both points, which
    is claimed as the cdc45 fits on a sealed gate, and the test suite asserts
    that pairing of fit and gate.
    """
    return (x - MCM_TIP_I if side == 'right' else x + MCM_TIP_I,
            y + mcm_row(sub, side, skew))


def mcm_tip(x, y, sub, side='left', skew=0.0):
    """C-terminal point of one subunit, in panel coordinates."""
    return (x - MCM_TIP_O if side == 'right' else x + MCM_TIP_O,
            y + mcm_row(sub, side, skew))


def mcm_tooth(x, y, sub, side='left', skew=0.0):
    """N-terminal tooth apex, in panel coordinates. The seam contact point."""
    return (x - MCM_TOOTH_X if side == 'right' else x + MCM_TOOTH_X,
            y + mcm_row(sub, side, skew))


def mcm_subunit(x, y, sub, face, side='left', blunt=False):
    """One Mcm subunit. C-terminal point, AAA+ body, N-terminal tooth.

    A back subunit is taller and shorter than a front one, so its outline shows
    past the front subunit in the same row without being mistaken for it.

    blunt cuts the tooth apex back by BOB1_BLUNT to a flat tip and adds the
    bob1 class, which is how the mcm5-bob1 allele is drawn.
    """
    def px(lx):
        return x - lx if side == 'right' else x + lx

    bh = (MCM_BACK_H if face == 'back' else MCM_BODY_H) / 2.0
    inset = MCM_BACK_INSET if face == 'back' else 0.0
    tipo, tipi = px(MCM_TIP_O + inset), px(MCM_TIP_I + inset)
    bodr, flgr, tooth = px(MCM_BODY_R), px(MCM_FLG_R), px(MCM_TOOTH_X)
    fh = MCM_FLANGE_H / 2.0
    bx, bw = min(tipi, bodr), abs(bodr - tipi)

    out = ['<g class="mcmsub %s m%s%s">' % (face, sub, ' bob1' if blunt else '')]
    out.append('<path class="mcmtip" d="M%.1f %.1f L%.1f %.1f L%.1f %.1f Z"/>'
               % (tipo, y, tipi, y - 4.5, tipi, y + 4.5))
    out.append('<rect class="mcmbody" x="%.1f" y="%.1f" width="%.1f" height="%.1f" rx="5"/>'
               % (bx, y - bh, bw, bh * 2))
    if blunt:
        cut = px(MCM_TOOTH_X - BOB1_BLUNT)
        # The cut follows the tooth's own flanks, so the flat tip is exactly as
        # wide as the triangle is at that depth and the rest of the outline is
        # unchanged.
        hy = fh * BOB1_BLUNT / (MCM_TOOTH_X - MCM_FLG_R)
        out.append('<path class="mcmflange" d="M%.1f %.1f L%.1f %.1f L%.1f %.1f '
                   'L%.1f %.1f L%.1f %.1f L%.1f %.1f Z"/>'
                   % (bodr, y - fh, flgr, y - fh, cut, y - hy, cut, y + hy,
                      flgr, y + fh, bodr, y + fh))
    else:
        out.append('<path class="mcmflange" d="M%.1f %.1f L%.1f %.1f L%.1f %.1f '
                   'L%.1f %.1f L%.1f %.1f Z"/>'
                   % (bodr, y - fh, flgr, y - fh, tooth, y, flgr, y + fh, bodr, y + fh))
    out.append('<text class="glyphlab sm mcmnum" x="%.1f" y="%.1f">%s</text>'
               % (px(-4.0), y + 3, sub))
    out.append('</g>')
    return ''.join(out)


def mcm_phos_marks(x, y, side='left', skew=0.0, subs=MCM_TAIL_SUBS, skip=(),
                   mimic=False):
    """Marks on the N-terminal tails, one per subunit in subs.

    They sit on the tooth side, which is the tier the kinase reaches, and come
    back as bare markup so one panel wraps one fx around all of them. The
    default is the Mcm4 and Mcm6 marks; the Mcm2 mark is asked for separately
    because it arrives later. skip leaves out a subunit whose mark is drawn
    somewhere else: the near Mcm4 mark rides the displaced NSD and not the
    tooth. mimic draws the outline star.
    """
    dx = 12.0 if side == 'right' else -12.0
    out = []
    for sub in subs:
        if sub in skip:
            continue
        tx, ty = mcm_tooth(x, y, sub, side, skew)
        out.append(phos_star(tx + dx, ty - 13.0, mimic=mimic))
    return ''.join(out)


def mcm_arc(x, y, subs, face, side='left', skew=0.0, gate='closed', fits=(), bob1=()):
    """One face of one hexamer.

    The two faces go into different layers, so they are built separately and
    never wrapped in one group. bob1 names the subunits drawn with the bob1
    tooth.
    """
    out = ['<g class="mcmarc %s gate-%s">' % (face, gate)]
    for sub in subs:
        dy = mcm_row(sub, side, skew)
        out.append('<g class="mcmslot s%s">' % sub)
        out.append(mcm_subunit(x, y + dy, sub, face, side, blunt=(sub in bob1)))
        out.append('</g>')
    if mcm_gate_face(side) == face:
        gy = y + (mcm_row('2', side, skew, 'open')
                  + mcm_row('5', side, skew, 'open')) / 2.0
        gx0 = x - MCM_HALF + 6.0
        out.append('<path class="mcmgap" d="M%.1f %.1f L%.1f %.1f"/>'
                   % (gx0, gy, gx0 + MCM_W - 12.0, gy))
    for name, sub in fits:
        if sub in subs:
            if name.startswith('cdt1-mcm3'):
                sx, sy = mcm_tip(x, y, sub, side, skew)
            else:
                sx, sy = mcm_seat(x, y, sub, side, skew)
            out.append(fitpoint(name, 'seat', sx, sy))
    out.append('</g>')
    return ''.join(out)


def mcm_hexamer(x, y, side='left', skew=0.0, gate='closed', fits=(), tag='', bob1=()):
    """One Mcm2-7 hexamer, as a (back, front) pair of markup strings.

    fits names the complementary fits this hexamer offers. 'cdt1' puts a seat
    on the Mcm3 C-terminal point, 'cdc45' puts one on each of the Mcm2 and Mcm5
    body ends, and 'cdc45p' puts one on the Mcm5 body end only, which is the
    partly seated Cdc45 the clasp holds before GINS arrives. A hexamer that
    offers no fit in a panel emits none, so an unpaired fit point never
    appears.

    tag distinguishes the two hexamers of a pair. Both offer a Cdc45 seat, and
    two seats and two sockets under one name would let the suite pair the left
    socket with the right seat and call the panel broken, or worse, pair them
    the other way and call a broken panel fine. The suffix is numeric because
    that is the form the suite already strips when it asks which fits the model
    draws at all.

    bob1 names the subunits drawn with the bob1 tooth, and is passed to both
    arcs, since the allele is in every copy of the subunit.
    """
    front, back = mcm_arcs(side)
    pairs = []
    if 'cdt1' in fits:
        pairs.append(('cdt1-mcm3', '3'))
    if 'cdc45' in fits:
        pairs.append(('cdc45-mcm2' + tag, '2'))
        pairs.append(('cdc45-mcm5' + tag, '5'))
    if 'cdc45p' in fits:
        pairs.append(('cdc45p-mcm5' + tag, '5'))
    return (mcm_arc(x, y, back, 'back', side, skew, gate, pairs, bob1),
            mcm_arc(x, y, front, 'front', side, skew, gate, pairs, bob1))


def mcm_bottom_profile(hx, y, side='left', skew=0.0):
    """Underside of one hexamer, outer end first and tooth apex last.

    Only the near arc is traced. The far arc rides MCM_BACK_LIFT above it and
    never reaches the bottom of the silhouette, so anything cut to this profile
    meets the wall of the ring the viewer can see.

    The points are the corners the subunit constructor already draws with: the
    outer end of the body, the body to flange step, the flange root and the
    tooth apex. Anything cut to them is cut to the glyph and not to a shape
    that happens to sit near it.
    """
    front, _ = mcm_arcs(side)
    sub = front[-1]
    yr = y + mcm_row(sub, side, skew)
    s = -1.0 if side == 'right' else 1.0

    def px(lx):
        return hx + s * lx

    return [(px(MCM_TIP_I), yr + MCM_BODY_H / 2.0),
            (px(MCM_BODY_R), yr + MCM_BODY_H / 2.0),
            (px(MCM_BODY_R), yr + MCM_FLANGE_H / 2.0),
            (px(MCM_FLG_R), yr + MCM_FLANGE_H / 2.0),
            (px(MCM_TOOTH_X), yr)]


def dh_bottom_profile(x, y):
    """Underside of a double hexamer, left outer end to right outer end.

    The two hexamers sit half a row apart, so one of them is lower than the
    other and the floor has a step in it. The step is not decoration: it is the
    same half-row offset that lets the teeth interleave, so a shape cut to this
    floor only goes on one way round.

    Where the step falls is set by the lower hexamer's tooth apex, because that
    is the leftmost point at which its underside takes over from its partner's.
    The tooth apex itself is not on the silhouette: it points into the
    interleave and the partner's flange hangs below it.

    Returned as [left outer end, body step, flange root, seam join, step foot,
    flange root, body step, right outer end].
    """
    lo = mcm_bottom_profile(x - MCM_HALF, y, 'left', -MCM_DH_SKEW)
    hi = mcm_bottom_profile(x + MCM_HALF, y, 'right', MCM_DH_SKEW)
    join = (hi[4][0], lo[3][1])
    return [lo[0], lo[1], lo[2], join, hi[3], hi[2], hi[1], hi[0]]


def profile_y(pts, px_):
    """Height of the pair's underside at one x, from dh_bottom_profile.

    Where the profile has a vertical riser the lower of its two ends answers,
    because that is the surface anything coming up from below meets first.
    """
    best = None
    for (x1, y1), (x2, y2) in zip(pts, pts[1:]):
        lo_x, hi_x = min(x1, x2), max(x1, x2)
        if lo_x - 1e-6 <= px_ <= hi_x + 1e-6:
            yy = max(y1, y2) if abs(x2 - x1) < 1e-6 else y1 + (y2 - y1) * (px_ - x1) / (x2 - x1)
            best = yy if best is None else max(best, yy)
    return best


# --- The Mcm4 NSD ---------------------------------------------------------
#
# The NSD is part of Mcm4, so it takes the Mcm4 subunit classes and is coloured
# with it. It hangs off the near Mcm4 tooth in two forms. Seated, a tail runs
# down the seam to an angled block lying against the underside of the pair
# across the half-row step: the block follows the profile on its upper face and
# stands proud of it on its lower one, so anything cut to the bare profile
# cannot take that surface. Displaced, the block is gone from the underside and
# the tail hangs clear of it, ending in the Mcm4 mark, which sits in the one
# place the clasp floor is cut to receive a star.
#
# Dbf4 displacing the segment from its seat on the Mcm4 N-terminal domain is
# the structural observation, and the vacated site is the one Sld3 binds.
# Drawing the seat at the underside of the seam, where the clasp docks, is this
# figure's projection of it.


def nsd_anchor(x, y):
    """Where the NSD leaves the pair: the tooth of the near Mcm4."""
    return mcm_tooth(x + MCM_HALF, y, '4', 'right', MCM_DH_SKEW)


def nsd_seat_poly(x, y):
    """The seated block, as a closed list of points.

    The upper face runs along the profile from left of the seam join, down the
    step and past its foot, so the block lies flush on the surface it occupies.
    The lower face is angled, deepest under the step, which is where the clasp
    floor carries its own step.
    """
    pts = dh_bottom_profile(x, y)
    join, foot = pts[3], pts[4]
    return [(join[0] - NSD_SEAT_BACK, join[1]), join, foot,
            (foot[0] + NSD_SEAT_FWD, foot[1]),
            (foot[0] + 1.0, foot[1] + NSD_SEAT_DROP),
            (join[0] - NSD_SEAT_BACK, join[1] + NSD_SEAT_HEEL)]


def nsd_release_poly(x, y):
    """The released block, as a closed list of points.

    The seated block turned NSD_REL_TURN degrees anticlockwise about the seam
    join and moved by NSD_REL_SHIFT. That lays it flat against the near face
    over the Mcm7 row, above the underside of the pair at every x, which
    audit_nsd asserts: the clasp floor is cut to the bare profile and has to
    meet nothing here.
    """
    import math
    jx, jy = dh_bottom_profile(x, y)[3]
    a = math.radians(-NSD_REL_TURN)
    c, s = math.cos(a), math.sin(a)
    dx, dy = NSD_REL_SHIFT
    return [(jx + (px_ - jx) * c - (py_ - jy) * s + dx,
             jy + (px_ - jx) * s + (py_ - jy) * c + dy)
            for px_, py_ in nsd_seat_poly(x, y)]


def nsd_star_point(x, y):
    """Centre of the Mcm4 mark on the displaced NSD, and of the clasp cleft."""
    foot = dh_bottom_profile(x, y)[4]
    return (foot[0] + NSD_STAR_DX, foot[1] + NSD_STAR_DY)


def _quad(p0, c, p1, n=12):
    return [((1 - t) ** 2 * p0[0] + 2 * (1 - t) * t * c[0] + t * t * p1[0],
             (1 - t) ** 2 * p0[1] + 2 * (1 - t) * t * c[1] + t * t * p1[1])
            for t in [k / float(n) for k in range(n + 1)]]


def nsd_tail_points(x, y, form):
    """Centre line of the NSD tail in one form, anchor first."""
    ax, ay = nsd_anchor(x, y)
    if form == 'seated':
        seat = nsd_seat_poly(x, y)
        end = (seat[0][0] + 4.0, seat[0][1])
        return _quad((ax, ay), (ax - 6.0, ay + 9.0), end)
    if form == 'released':
        end = nsd_release_poly(x, y)[3]
        return _quad((ax, ay), ((ax + end[0]) / 2.0, ay - 3.0), end)
    sx, sy = nsd_star_point(x, y)
    return _quad((ax, ay), (ax + 15.0, ay + 8.0), (sx, sy - PHOS_R / 2.0))


def ribbon(pts, w):
    """A filled strip of width w along a centre line, as path data."""
    half = w / 2.0
    left, right = [], []
    for k, (px_, py_) in enumerate(pts):
        a = pts[max(k - 1, 0)]
        b = pts[min(k + 1, len(pts) - 1)]
        dx, dy = b[0] - a[0], b[1] - a[1]
        n = max((dx * dx + dy * dy) ** 0.5, 1e-6)
        nx, ny = -dy / n * half, dx / n * half
        left.append((px_ + nx, py_ + ny))
        right.append((px_ - nx, py_ - ny))
    ring = left + list(reversed(right))
    return 'M%s Z' % ' L'.join('%.1f %.1f' % p for p in ring)


def nsd_glyph(x, y, form):
    """The NSD in one form, as markup on the near face."""
    out = ['<g class="mcmsub front m4 nsd">']
    out.append('<path class="mcmflange nsdtail" d="%s"/>'
               % ribbon(nsd_tail_points(x, y, form), NSD_TAIL_W))
    if form in ('seated', 'released'):
        poly = nsd_seat_poly(x, y) if form == 'seated' else nsd_release_poly(x, y)
        out.append('<path class="mcmflange nsdblock" d="M%s Z"/>'
                   % ' L'.join('%.1f %.1f' % p for p in poly))
        cxs = sum(p[0] for p in poly) / len(poly)
        cys = sum(p[1] for p in poly) / len(poly)
        out.append('<text class="glyphlab xs" x="%.1f" y="%.1f">NSD</text>'
                   % (cxs, cys + 2.5))
    out.append('</g>')
    return ''.join(out)


def nsd_markup(x, y, nsd, toggle):
    """The NSD as the pair carries it.

    toggle emits all three forms, each in a wrapper the engine shows or hides
    from the NSD value on the complex track, which is what a panel whose frames
    change that value needs. Without toggle only the form named by nsd is
    drawn, which is what a legend or a panel that never changes it needs.
    """
    if toggle:
        return ('<g id="nsdseat" class="fx nsdseat %s">%s</g>'
                '<g id="nsdfree" class="fx nsdfree %s">%s</g>'
                '<g id="nsdrel" class="fx nsdrel %s">%s</g>'
                % ('present' if nsd == 'seated' else 'gone', nsd_glyph(x, y, 'seated'),
                   'present' if nsd == 'displaced' else 'gone',
                   nsd_glyph(x, y, 'displaced'),
                   'present' if nsd == 'released' else 'gone',
                   nsd_glyph(x, y, 'released')))
    if nsd in ('seated', 'displaced', 'released'):
        return nsd_glyph(x, y, nsd)
    return ''


MCM2P_VALUES = ('none', 'pending', 'present')


def mcm_double(x, y, gate='closed', nsd='seated', phos=False, phos_pending=True,
               fits=(), fits_side='left', toggle=False, mimic=False, mcm2p='none',
               bob1=(), graded=False):
    """Head-to-head double hexamer, as a (back, front) pair.

    The two N faces abut at the centre and their teeth interleave, which is
    what the half-row offset is for. The direction the teeth point is what
    makes head-to-head orientation legible without a label, and the seam is the
    composite surface DDK acts on.

    nsd is 'seated', 'displaced', 'released' or 'absent'. The Mcm4 and Mcm6 marks go on the
    tooth side of both hexamers except for the near Mcm4, whose mark is drawn on
    the tip of the displaced NSD. mimic draws outline marks at the
    phosphomimetic sites only, for a pair no kinase has touched.

    mcm2p places the Mcm2 marks, which arrive later than the others and in their
    own wrapper: 'none' leaves them off, 'pending' emits them hidden for a frame
    to bring in, and 'present' shows them at rest. They are drawn only on a pair
    that already carries the tail marks, since the kinase that places them is
    the one that placed those.

    fits_side takes 'left', 'right' or 'both'. fits names the fits the pair
    offers: 'sld3' puts the two corner sockets on the underside and, when the
    NSD mark is drawn, a seat on that mark for the clasp cleft; 'cdc45p' puts a
    seat on the Mcm5 body end of each hexamer for the partly seated Cdc45 the
    clasp holds.

    bob1 names the subunits drawn with the bob1 tooth in both hexamers.

    phos is True for all four tail marks, or a count: the first that many of
    MCM_MARK_ORDER. graded wraps each of the four marks in its own wrapper,
    fx-pm-<site>, present at rest, so a panel holding one pair can show any
    count frame by frame.
    """
    left, right = x - MCM_HALF, x + MCM_HALF
    want_l = fits if fits_side in ('left', 'both') else ()
    want_r = fits if fits_side in ('right', 'both') else ()
    lb, lf = mcm_hexamer(left, y, 'left', -MCM_DH_SKEW, gate, want_l, '-0', bob1)
    rb, rf = mcm_hexamer(right, y, 'right', MCM_DH_SKEW, gate, want_r, '-1', bob1)
    seam = '<path class="dhseam" d="M%.1f %.1f L%.1f %.1f"/>' % (x, y - 46.0, x, y + 46.0)
    sx, sy = nsd_star_point(x, y)
    tipfit = 'sld3-nsd' if 'sld3' in fits else None
    marks = ''
    if phos:
        stars = {'l6': mcm_phos_marks(left, y, 'left', -MCM_DH_SKEW, subs=('6',)),
                 'r6': mcm_phos_marks(right, y, 'right', MCM_DH_SKEW, subs=('6',)),
                 'l4': mcm_phos_marks(left, y, 'left', -MCM_DH_SKEW, subs=('4',)),
                 'nsd': phos_star(sx, sy, fit=tipfit)}
        count = len(MCM_MARK_ORDER) if phos is True else int(phos)
        if graded:
            body = ''.join(fx('fx-pm-' + k, stars[k], pending=False) for k in MCM_MARK_ORDER)
        else:
            body = ''.join(stars[k] for k in MCM_MARK_ORDER[:count])
        marks = fx('fx-phos', body, pending=phos_pending)
        if mcm2p != 'none':
            marks += fx('fx-mcm2p',
                        mcm_phos_marks(left, y, 'left', -MCM_DH_SKEW, subs=MCM_GATE_MARK)
                        + mcm_phos_marks(right, y, 'right', MCM_DH_SKEW,
                                         subs=MCM_GATE_MARK),
                        pending=(mcm2p == 'pending'))
    elif mimic:
        marks = ('<g class="mimicmarks">%s%s%s</g>'
                 % (mcm_phos_marks(left, y, 'left', -MCM_DH_SKEW,
                                   subs=MCM_MIMIC_SUBS, mimic=True),
                    mcm_phos_marks(right, y, 'right', MCM_DH_SKEW,
                                   subs=MCM_MIMIC_SUBS, skip=('4',), mimic=True),
                    phos_star(sx, sy, fit=tipfit, mimic=True)))
    clasp = ''
    if 'sld3' in fits:
        pts = dh_bottom_profile(x, y)
        clasp = (fitpoint('sld3-dh-l', 'socket', *pts[0])
                 + fitpoint('sld3-dh-r', 'socket', *pts[-1]))
    return ('<g class="mcmdh back nsd-%s">%s%s</g>' % (nsd, lb, rb),
            '<g class="mcmdh front nsd-%s">%s%s%s%s%s%s</g>'
            % (nsd, seam, lf, rf, nsd_markup(x, y, nsd, toggle), marks, clasp))


def mcm_ring_open(x, y, r=34.0, ident=None):
    """Free Mcm2-7, ring topology only. Legend panel use.

    Six circles in an open C with the gap between Mcm2 and Mcm5. The only place
    the hexamer is drawn as a ring rather than as two arcs, because it is the
    only place the point is topology rather than position on DNA.
    """
    import math
    i = ' id="%s"' % ident if ident else ''
    order = ['2', '6', '4', '7', '3', '5']
    out = ['<g class="mcmring"%s>' % i]
    for k, sub in enumerate(order):
        ang = -110.0 + k * 58.0
        rad = ang * math.pi / 180.0
        sx = x + r * math.cos(rad)
        sy = y + r * math.sin(rad)
        out.append('<circle class="mcmringsub m%s" cx="%.1f" cy="%.1f" r="12"/>' % (sub, sx, sy))
        out.append('<text class="glyphlab sm mcmnum" x="%.1f" y="%.1f">%s</text>'
                   % (sx, sy + 3, sub))
    out.append(endlab(x, y + r + 20, 'Mcm2-Mcm5 gate'))
    out.append('</g>')
    return ''.join(out)


# --- ORC and Cdc6 ---------------------------------------------------------
#
# ORC is a C of six numbered circles opening downward. The notch between Orc1
# and Orc2 is the gap duplex DNA enters through, and it is scalloped to the
# circle radius so the Cdc6 wedge seats there and nowhere else.

ORC_R = 11.0
ORC_SEATS = [('1', -22.0, 26.0, 'aaa'), ('6', -36.0, -2.0, 'non'),
             ('5', -18.0, -28.0, 'aaa'), ('4', 14.0, -32.0, 'aaa'),
             ('3', 34.0, -8.0, 'deg'), ('2', 26.0, 22.0, 'deg')]
ORC_NOTCH_DX, ORC_NOTCH_DY = 2.0, 32.0      # centre of the Orc1-Orc2 gap


def orc_notch(x, y):
    """Panel coordinate of the ORC notch centre."""
    return (x + ORC_NOTCH_DX, y + ORC_NOTCH_DY)


def orc_ring(x, y, ident=None, cdc6=False, cdc6_pending=False, fits=True):
    """ORC. Orc1, Orc4 and Orc5 filled; Orc2 and Orc3 the same circle drawn as
    outline only, which is the claim that they are the same fold without the
    active site; Orc6 smaller and paler, since it has no AAA+ unit."""
    i = ' id="%s"' % ident if ident else ''
    out = ['<g class="orcring"%s>' % i]
    out.append('<path class="orcarc" d="M%.1f %.1f A38 38 0 1 1 %.1f %.1f"/>'
               % (x - 22.0, y + 26.0, x + 26.0, y + 22.0))
    for sub, dx, dy, kind in ORC_SEATS:
        r = ORC_R - 2.0 if kind == 'non' else ORC_R
        out.append('<circle class="orcsub %s o%s" cx="%.1f" cy="%.1f" r="%.1f"/>'
                   % (kind, sub, x + dx, y + dy, r))
        out.append('<text class="glyphlab sm" x="%.1f" y="%.1f">%s</text>'
                   % (x + dx, y + dy + 3, sub))
    nx, ny = orc_notch(x, y)
    out.append('<path class="orcnotch" d="M%.1f %.1f A%.1f %.1f 0 0 0 %.1f %.1f"/>'
               % (x - 22.0 + ORC_R, y + 26.0 + 4.0, 26.0, 14.0,
                  x + 26.0 - ORC_R, y + 22.0 + 4.0))
    if fits:
        out.append(fitpoint('cdc6-orc', 'socket', nx, ny))
    if cdc6:
        out.append(fx('fx-cdc6', cdc6_wedge(nx, ny), pending=cdc6_pending))
    out.append('</g>')
    return ''.join(out)


CDC6_BASE_W = 48.0
CDC6_H = 34.0
CDC6_SEAT_DX, CDC6_SEAT_DY = 14.0, -14.0     # where each scallop rejoins the edge
CDC6_FLANK_DY = -22.0                        # where Cdt1 meets the right edge
CDC6_FLANK_DX = (CDC6_BASE_W / 2.0) * (1.0 + CDC6_FLANK_DY / CDC6_H)


def cdc6_flank(x, y):
    """Panel coordinate of the Cdc6 upper right flank.

    Derived from the triangle rather than set beside it, so the Cdt1 arm meets
    the edge that is actually drawn however the triangle is resized.
    """
    return (x + CDC6_FLANK_DX, y + CDC6_FLANK_DY)


def cdc6_wedge(x, y, ident=None, fits=True):
    """Cdc6. A triangle, apex up into the ring interior.

    The base carries two concave scallops cut to the Orc1 and Orc2 circles, so
    it seats in the ORC notch and nowhere else. Straight edges elsewhere: the
    silhouette is the triangle and the scallops are the only cut in it.
    """
    i = ' id="%s"' % ident if ident else ''
    hw = CDC6_BASE_W / 2.0
    sx, sy = CDC6_SEAT_DX, CDC6_SEAT_DY
    d = ('M%.1f %.1f A%.1f %.1f 0 0 0 %.1f %.1f L%.1f %.1f L%.1f %.1f '
         'A%.1f %.1f 0 0 0 %.1f %.1f Z'
         % (x - hw, y, ORC_R, ORC_R, x - sx, y + sy,
            x, y - CDC6_H, x + sx, y + sy,
            ORC_R, ORC_R, x + hw, y))
    out = ['<g class="cdc6"%s>' % i]
    out.append('<path class="cdc6wedge" d="%s"/>' % d)
    out.append('<text class="glyphlab sm" x="%.1f" y="%.1f">Cdc6</text>' % (x, y - 8))
    if fits:
        out.append(fitpoint('cdc6-orc', 'seat', x, y))
        fxp, fyp = cdc6_flank(x, y)
        out.append(fitpoint('cdt1-cdc6', 'socket', fxp, fyp))
    out.append('</g>')
    return ''.join(out)


# --- Cdt1 -----------------------------------------------------------------

CDT1_FREE = 90.0              # tip to tip when Cdt1 is not seated on anything


CDT1_BOW = 22.0               # how far the seated arm bows off the chord


def cdt1_arm(x, y, mx, my, ident=None, fits=('cdc6', 'mcm3'), bend=CDT1_BOW):
    """Cdt1 as an arm drawn between the two points it binds.

    x, y is the origin-facing tip, cut at the angle of the Cdc6 flank. mx, my is
    the Mcm3 point its concave face cradles. The arm is drawn from one to the
    other rather than at a fixed length, so both fits hold by construction and
    the assembled geometry cannot drift away from the claim.

    bend separates the two conformations, and the difference is the claim. A
    free Cdt1 carrying a hexamer through the nucleoplasm is a straight rod, and
    an ejected one is a straight rod again. The one seated between Cdc6 and
    Mcm3 is bowed, which is the drawn form of the tension it holds while it
    levers Cdc6 out of the notch. Only the bowed form carries the pry class,
    and the stylesheet works it for the same reason. A negative bend arches the
    arm the other way, which is how it reaches a hexamer on the far side of one
    already loaded without being drawn through it.

    fits names which halves this arm emits. A free arm emits no Cdc6 seat,
    which leaves the ORC socket unfilled and says so.
    """
    i = ' id="%s"' % ident if ident else ''
    bx = (x + mx) / 2.0
    by = (min(y, my) + bend) if bend else (y + my) / 2.0
    d = ('M%.1f %.1f Q%.1f %.1f %.1f %.1f L%.1f %.1f Q%.1f %.1f %.1f %.1f Z'
         % (x, y - 6.0, bx, by - 6.0, mx, my - 6.0,
            mx, my + 6.0, bx, by + 6.0, x, y + 6.0))
    out = ['<g class="cdt1%s"%s>' % (' pry' if bend else '', i)]
    out.append('<path class="cdt1arm" d="%s"/>' % d)
    # On the curve, not on the control point. A lightly bowed arm barely tells
    # the two apart; an arm arching over a loaded hexamer puts the control
    # point well clear of anything drawn.
    my_mid = 0.25 * y + 0.5 * by + 0.25 * my
    out.append('<text class="glyphlab sm" x="%.1f" y="%.1f">Cdt1</text>'
               % (bx, my_mid + 3.0))
    if 'cdc6' in fits:
        out.append(fitpoint('cdt1-cdc6', 'seat', x, y))
    if 'mcm3' in fits:
        out.append(fitpoint('cdt1-mcm3', 'socket', mx, my))
    out.append('</g>')
    return ''.join(out)


# --- Kinases and marks ----------------------------------------------------

def kinase_burst(x, y, label, ident=None):
    """DDK and CDK. One silhouette for both, because they are the same kind of
    actor. A black starburst ring with a crimson core carrying the label."""
    import math
    i = ' id="%s"' % ident if ident else ''
    pts = []
    for k in range(40):
        r = 30.0 if k % 2 == 0 else 21.0
        a = k * math.pi / 20.0
        pts.append('%.1f %.1f' % (x + r * math.cos(a), y + r * math.sin(a)))
    out = ['<g class="kin"%s>' % i]
    out.append('<path class="kinburst" d="M%s Z"/>' % ' L'.join(pts))
    out.append('<circle class="kincore" cx="%.1f" cy="%.1f" r="19"/>' % (x, y))
    out.append('<text class="glyphlab sm kinlab" x="%.1f" y="%.1f">%s</text>'
               % (x, y + 3, esc(label)))
    out.append('</g>')
    return ''.join(out)


PHOS_R = 11.0                 # star tip to star tip
DDK_CLEFT = (0.0, -9.0)       # the Rad53 phosphate cutout on the Dbf4 core, from the glyph centre


def ddk_block(x, y):
    """VIEW: the Rad53 site of Dbf4 filled black, for dbf4-m25, which Rad53 cannot phosphorylate (TERMINAL)

    The fill has the cutout's shape and sits in it, so a blocked site reads as
    the same socket with nothing able to enter it.
    """
    return '<path class="ddkblock" d="%s"/>' % _star_path(x, y, PHOS_R, 2.2)


def ddk_glyph(x, y, label='DDK', ident=None):
    """DDK. The kinase burst in the cryo-EM colours: Cdc7 spokes around a Dbf4
    core. A star-shaped cutout in the core is the site Rad53 phosphorylates,
    so the Rad53 mark seats there and nowhere else on the kinase."""
    import math
    i = ' id="%s"' % ident if ident else ''
    pts = []
    for k in range(40):
        r = 30.0 if k % 2 == 0 else 21.0
        a = k * math.pi / 20.0
        pts.append('%.1f %.1f' % (x + r * math.cos(a), y + r * math.sin(a)))
    cx, cy = x + DDK_CLEFT[0], y + DDK_CLEFT[1]
    out = ['<g class="kin ddk"%s>' % i]
    out.append('<path class="kinburst ddkcdc7" d="M%s Z"/>' % ' L'.join(pts))
    out.append('<circle class="kincore ddkdbf4" cx="%.1f" cy="%.1f" r="19"/>' % (x, y))
    out.append('<path class="ddkcleft" d="%s"/>' % _star_path(cx, cy, PHOS_R, 2.2))
    out.append('<text class="glyphlab sm kinlab" x="%.1f" y="%.1f">%s</text>'
               % (x, y + 9, esc(label)))
    out.append('</g>')
    return ''.join(out)


def _star_path(x, y, r, inner):
    import math
    pts = []
    for k in range(8):
        rr = r / 2.0 if k % 2 == 0 else inner
        a = k * math.pi / 4.0 - math.pi / 2.0
        pts.append('%.1f %.1f' % (x + rr * math.cos(a), y + rr * math.sin(a)))
    return 'M%s Z' % ' L'.join(pts)


def phos_star(x, y, ident=None, fit=None, mimic=False):
    """Settled modification. A four-pointed gold star, so it differs from the
    SUMO diamond by shape and not by colour and survives greyscale.

    mimic draws the same star as an outline, which is a phosphomimetic residue:
    the same position and the same effect without the chemistry. Outline and
    fill differ by shape, so the two survive greyscale as well.
    """
    i = ' id="%s"' % ident if ident else ''
    out = ['<g class="phos%s"%s>' % (' mimic' if mimic else '', i)]
    out.append('<path class="phosstar" d="%s"/>' % _star_path(x, y, PHOS_R, 2.2))
    out.append('<text class="glyphlab xs" x="%.1f" y="%.1f">P</text>' % (x, y + 2.5))
    if fit:
        out.append(fitpoint(fit, 'seat', x, y))
    out.append('</g>')
    return ''.join(out)


def sumo_mark(x, y):
    """SUMO. A diamond. Context page only."""
    return ('<g class="sumo"><path class="sumodia" d="M%.1f %.1f l6 -6 l6 6 l-6 6 z"/>'
            '<text class="glyphlab xs" x="%.1f" y="%.1f">S</text></g>'
            % (x - 6, y, x, y + 3))


def nucleotide_burst(x, y, label='', alt=False):
    """A nucleotide event. A small disc marked ATP.

    One silhouette for every nucleotide event the model draws, because they are
    the same kind of event: Cdc6 ATP hydrolysis in step 5, the ADP to ATP
    exchange as CMG forms in step 9, and the ATP hydrolysis that drives
    unwinding in step 10. label says which of them this one is, under the disc,
    so the three share a shape without claiming to be one reaction. The disc
    alone is what step 5 has always drawn.
    """
    out = ['<g class="burst"><circle class="burstc" cx="%.1f" cy="%.1f" r="10"/>'
           '<text class="glyphlab xs" x="%.1f" y="%.1f">ATP</text></g>'
           % (x, y, x, y + 3)]
    if label:
        lab = endlab(x, y + 24.0, label)
        # alt marks one of two labels written at one place, of which a frame
        # shows only one: the burst a panel inherits and the one it adds.
        out.append(lab.replace('class="endlab"', 'class="endlab alt"') if alt else lab)
    return ''.join(out)


# --- Adaptors and firing factors ------------------------------------------

ARCH_W, ARCH_H = 34.0, 30.0


def adaptor_arch(x, y, label, ident=None, clefts=1, filled=(), fitbase='',
                 seatfit='', borne=0, bornefit='', borne_pending=None):
    """Sld2 and the free adaptors. A flat-bottomed arch, with a star-shaped
    cleft cut into the upper edge and dimensioned to the phosphate star exactly.

    A cleft is a place this protein reads somebody else's mark, and an empty
    one is a readable statement that the mark is not placed yet. A mark the
    protein carries is a different relation and takes a different position: it
    sits on the shoulder, outside the silhouette, and outside the arch group
    with it. Drawing both in the cleft made one shape say two things.

    clefts may be zero, which is what a protein that reads nothing gets.
    """
    i = ' id="%s"' % ident if ident else ''
    hw = ARCH_W / 2.0
    out = ['<g class="arch"%s>' % i]
    out.append('<path class="archbody" d="M%.1f %.1f L%.1f %.1f A%.1f %.1f 0 0 1 %.1f %.1f '
               'L%.1f %.1f Z"/>'
               % (x - hw, y + ARCH_H / 2.0, x - hw, y - 2.0, hw, hw, x + hw, y - 2.0,
                  x + hw, y + ARCH_H / 2.0))
    xs = [] if clefts == 0 else ([x] if clefts == 1 else [x - 9.0, x + 9.0])
    for k, sx in enumerate(xs):
        sy = y - ARCH_H / 2.0 + 4.0
        out.append('<path class="archcleft" d="%s"/>' % _star_path(sx, sy, PHOS_R, 2.2))
        if fitbase:
            out.append(fitpoint('%s-%d' % (fitbase, k), 'socket', sx, sy))
        if k in filled:
            out.append(phos_star(sx, sy, fit='%s-%d' % (fitbase, k) if fitbase else None))
    if seatfit:
        out.append(fitpoint(seatfit, 'seat', x, y - 2.0))
    out.append('<text class="glyphlab sm" x="%.1f" y="%.1f">%s</text>'
               % (x, y + ARCH_H / 2.0 - 3, esc(label)))
    out.append('</g>')
    marks = ''.join(phos_star(x + hw + 7.0 + k * 15.0, y + 4.0) for k in range(borne))
    if marks and bornefit:
        marks = fx(bornefit, marks, pending=bool(borne_pending))
    out.append(marks)
    return ''.join(out)


CDC45_W, CDC45_H = 46.0, 26.0

# Before GINS arrives Cdc45 is only partly associated with Mcm2-7: it sits
# against the Mcm2 and Mcm5 A domains but contacts Mcm5 far more than Mcm2,
# and GINS then pulls it into the fuller contacts it keeps in the CMG. The
# glyph draws that as a tilt about its Mcm5 corner, which stays on the Mcm5
# seat, while its Mcm2 corner swings CDC45_TILT_HOLD off the Mcm2 seat. The
# tilt is computed on the coordinates here and not written as an SVG rotate,
# because the fit test composes ancestor translates only.
CDC45_TILT_HOLD = 9.0


def cdc45_tilt_angle(side, hold=CDC45_TILT_HOLD):
    """MODEL: rotation that swings the Mcm2 corner off by hold (TERMINAL).

    The Mcm2 corner sits one row pitch above the Mcm5 corner, so a rotation
    of asin(hold / pitch) about the Mcm5 corner moves it hold units along x.
    The sign sends it away from the hexamer, which is the direction the blob
    already extends on that side.
    """
    import math
    s = -1.0 if side == 'left' else 1.0
    return math.asin(s * hold / MCM_ROW_PITCH)


def cdc45_tilt_point(px_, py_, pivot, angle):
    """MODEL: one point rotated about a pivot, in panel units (TERMINAL)."""
    import math
    c, s = math.cos(angle), math.sin(angle)
    dx, dy = px_ - pivot[0], py_ - pivot[1]
    return (pivot[0] + dx * c - dy * s, pivot[1] + dx * s + dy * c)


def cdc45_corner(x, y, side='left', partial=False):
    """MODEL: where the Mcm2 corner of a Cdc45 placed at x, y ends up (TERMINAL).

    x, y is the Mcm2 seat. A flat Cdc45 has its corner there; a partly seated
    one has it swung off about the Mcm5 corner below. The clasp arms end at
    this point, so they hold the corner that is free.
    """
    if not partial:
        return (x, y)
    return cdc45_tilt_point(x, y, (x, y + MCM_ROW_PITCH), cdc45_tilt_angle(side))


def cdc45_blob(x, y, side='left', ident=None, fits=True, tag='', partial=False):
    """Cdc45. A lobed blob whose inner edge carries two concave scallops cut to
    the ends of the Mcm2 and Mcm5 bodies, so it seats across the 2/5 gate and
    nowhere else.

    x, y is the Mcm2 seating corner. The blob runs down to the Mcm5 corner and
    away from the hexamer, on the C side, because the seam side of a hexamer in
    a double hexamer is occupied by its partner.

    partial draws Cdc45 before GINS: tilted about its Mcm5 corner so the Mcm5
    scallop stays on its seat and the Mcm2 scallop stands off. It then claims
    only the Mcm5 contact, as the cdc45p fit, because the Mcm2 contact is the
    one GINS completes. A flat Cdc45 claims both.
    """
    i = ' id="%s"' % ident if ident else ''
    dy = MCM_ROW_PITCH
    s = -1.0 if side == 'left' else 1.0
    ox = x + s * CDC45_W
    cxm, cym = x + s * CDC45_W / 2.0, y + dy / 2.0
    pivot = (x, y + dy)
    angle = cdc45_tilt_angle(side) if partial else 0.0

    def rp(px_, py_):
        return cdc45_tilt_point(px_, py_, pivot, angle) if partial else (px_, py_)

    p0, p1 = rp(x, y), rp(x, y + dy)
    c1, p2 = rp(ox, y + dy + 10.0), rp(ox, cym)
    c2 = rp(ox, y - 10.0)
    lab = rp(cxm + s * 6.0, cym)
    out = ['<g class="cdc45%s"%s>' % (' partial' if partial else '', i)]
    out.append('<path class="cdc45body" d="M%.1f %.1f A6 6 0 0 %d %.1f %.1f '
               'Q%.1f %.1f %.1f %.1f Q%.1f %.1f %.1f %.1f Z"/>'
               % (p0[0], p0[1], 1 if side == 'left' else 0, p1[0], p1[1],
                  c1[0], c1[1], p2[0], p2[1],
                  c2[0], c2[1], p0[0], p0[1]))
    out.append('<text class="glyphlab sm" x="%.1f" y="%.1f">Cdc45</text>'
               % (lab[0], lab[1] + 3))
    if fits:
        if partial:
            out.append(fitpoint('cdc45p-mcm5' + tag, 'socket', *p1))
        else:
            out.append(fitpoint('cdc45-mcm2' + tag, 'socket', *p0))
            out.append(fitpoint('cdc45-mcm5' + tag, 'socket', *p1))
    out.append('</g>')
    return ''.join(out)


# --- Sld3-Sld7, the clasp ---------------------------------------------------
#
# Sld3 and Sld7 are drawn as one dimeric clasp that takes the double hexamer
# from underneath. Its inner floor is cut from dh_bottom_profile, so it is the
# negative of the bare pair by construction and cannot drift when the flange
# numbers are retuned. One star-shaped cleft is cut into that floor under the
# step foot, where the displaced NSD brings the Mcm4 mark, so the clasp reads
# the mark and rests on the pair in the same fit.
#
# The claim the shape carries is a fit that fails while the NSD is seated. The
# seated block stands proud of the profile the floor is cut to, so the clasp
# stops short of the pair by the depth of that block. Nothing about that is
# left to the caption: it is asserted at build time, below, against the offDDK
# frame table.
#
# The floor also carries the half-row step, which is why the clasp only goes on
# one way round, and two arms that run up the outside of the pair towards the
# Mcm2 body ends. The arms carry Cdc45, one per hexamer, partly seated at the
# Mcm2-Mcm5 gate: its Mcm5 corner on Mcm5 and its Mcm2 corner tilted off,
# which is the state before GINS completes the seat. A third tether ends in the
# pad that takes the S-CDK mark on Sld3.
#
# In the structures each Sld3 binds Mcm4 on one hexamer and holds Cdc45 on the
# other. The clasp stands for the Sld3 dimer and one near-side NSD stands for
# both hexamers, so that pairing is stated in the caption and not drawn.

SLD_T = 14.0                  # wall thickness of the clasp
SLD_ARM_BOW = 21.0            # how far an arm stands off the C tips
SLD_PAD_R = 7.0               # the pad on the tether that takes the CDK mark
SLD_PAD_DX, SLD_PAD_DY = 36.0, -37.5


def sld_pad_point(x, y):
    """Panel coordinate of the Sld3 CDK site.

    Derived from the right Mcm2 seat rather than set beside it, so the pad
    follows the arm that carries it however the hexamer is resized.
    """
    sx, sy = mcm_seat(x + MCM_HALF, y, '2', 'right', MCM_DH_SKEW)
    return (sx + SLD_PAD_DX, sy + SLD_PAD_DY)


def sld_cradle(x, y, fits=True, nsd_fit=False, borne=False, borne_pending=True,
               bridge=False, cdc45=True, cdc45_pending=True):
    """Sld3-Sld7 as a (back, front) pair of markup strings.

    x, y is the centre of the double hexamer it is cut to.

    The clasp, both arms, the tether and the pad are near-side objects and go
    in front. The Cdc45 held for the right hexamer does not: that hexamer
    carries its Mcm2-Mcm5 gate on the far face, so its Cdc45 goes into the far
    layer, exactly as cmg_actor does it. Drawing it in front would put it on
    the face whose gate it does not reach.

    nsd_fit emits the socket in the floor cleft. It is set only where the pair
    carries the mark the cleft takes, so an empty cleft claims no fit.

    fits also decides whether the two partly seated Cdc45 claim their Mcm5
    contacts. A panel that emits them must give the pair the matching cdc45p
    seats, and a panel where the clasp claims nothing gives the pair none.

    The two lobes are labelled separately, which is what says dimer without a
    label that has to say so.
    """
    pts = dh_bottom_profile(x, y)
    d = ['M%.1f %.1f' % pts[0]]
    for p in pts[1:]:
        d.append('L%.1f %.1f' % p)
    for p in reversed(pts):
        d.append('L%.1f %.1f' % (p[0], p[1] + SLD_T))
    d.append('Z')

    front = ['<g class="sld">']
    front.append('<path class="sldbody" d="%s"/>' % ' '.join(d))
    cx_, cy_ = nsd_star_point(x, y)
    front.append('<path class="archcleft" d="%s"/>' % _star_path(cx_, cy_, PHOS_R, 2.2))

    seats = {}
    corners = {}
    arms = []
    for side, hx, skew, end, bow in (
            ('left', x - MCM_HALF, -MCM_DH_SKEW, pts[0], -SLD_ARM_BOW),
            ('right', x + MCM_HALF, MCM_DH_SKEW, pts[-1], SLD_ARM_BOW)):
        sx, sy = mcm_seat(hx, y, '2', side, skew)
        seats[side] = (sx, sy)
        tx, ty = cdc45_corner(sx, sy, side, partial=True)
        corners[side] = (tx, ty)
        ax, ay = end[0], end[1] + SLD_T / 2.0
        arm = ('M%.1f %.1f Q%.1f %.1f %.1f %.1f'
               % (ax, ay, ax + bow, (ay + ty) / 2.0, tx, ty))
        arms.append('<path class="sldarmedge" d="%s"/>' % arm)
        arms.append('<path class="sldarm" d="%s"/>' % arm)

    px_, py_ = sld_pad_point(x, y)
    rx, ry = corners['right']
    front.append('<path class="sldtetheredge" d="M%.1f %.1f Q%.1f %.1f %.1f %.1f"/>'
                 % (rx, ry, rx + SLD_PAD_DX * 0.62, ry - 13.0, px_, py_))
    front.append('<path class="sldtether" d="M%.1f %.1f Q%.1f %.1f %.1f %.1f"/>'
                 % (rx, ry, rx + SLD_PAD_DX * 0.62, ry - 13.0, px_, py_))
    front.append('<circle class="sldpad" cx="%.1f" cy="%.1f" r="%.1f"/>'
                 % (px_, py_, SLD_PAD_R))
    if fits:
        front.append(fitpoint('sld3-dh-l', 'seat', *pts[0]))
        front.append(fitpoint('sld3-dh-r', 'seat', *pts[-1]))
        front.append(fitpoint('sld3-cdk', 'socket', px_, py_))
        if nsd_fit:
            front.append(fitpoint('sld3-nsd', 'socket', cx_, cy_))

    # The two lobes take their names on the two floors of the clasp, so the
    # step that makes it one-way-round is also what separates the labels. The
    # Sld7 name sits on the outer part of its floor, clear of the cleft.
    front.append('<text class="glyphlab sm" x="%.1f" y="%.1f">Sld3</text>'
                 % ((pts[0][0] + pts[2][0]) / 2.0, pts[0][1] + SLD_T - 3.0))
    front.append('<text class="glyphlab sm" x="%.1f" y="%.1f">Sld7</text>'
                 % ((pts[5][0] + pts[7][0]) / 2.0, pts[7][1] + SLD_T - 3.0))
    if borne:
        mark = [phos_star(px_, py_, fit='sld3-cdk' if fits else None)]
        if bridge:
            # The same mark is what Dpb11 takes hold of. It is one star doing
            # two jobs, so it emits the second half of both fits and neither is
            # left as a partner drawn against nothing.
            mark.append(fitpoint('sld3-phos', 'seat', px_, py_))
        front.append(fx('fx-sld3p', ''.join(mark), pending=borne_pending))
    front.append('</g>')

    back = ''
    if cdc45:
        # Partly seated on the arm tips: the Mcm5 scallop sits on the Mcm5 body
        # end and the Mcm2 scallop is tilted CDC45_TILT_HOLD off the Mcm2 body
        # end. Only the Mcm5 contact is claimed; step 9 lays Cdc45 flat on the
        # gate when GINS arrives.
        lx, ly = seats['left']
        rx2, ry2 = seats['right']
        # Each half is its own actor inside the clasp, so a frame can bring
        # Cdc45 in from off the page onto the arm tip it seats on.
        front.append(actor('cdc45l', fx('fx-cdc45', cdc45_blob(lx, ly, 'left', fits=fits,
                                                                tag='-0', partial=True),
                                         pending=cdc45_pending), basex=lx))
        back = actor('cdc45r', fx('fx-cdc45-b', cdc45_blob(rx2, ry2, 'right', fits=fits,
                                                           tag='-1', partial=True),
                                  pending=cdc45_pending), basex=rx2)
    front.append('<g class="sld grip">%s</g>' % ''.join(arms))
    return (back, ''.join(front))


GINS_PC = 16.0                # one piece
GINS_W = GINS_PC * 4

# The pieces are jigsaw pieces and the knob is the fit. A knob wider than its
# neck is what makes the joint hold in both directions: a semicircular bump
# would locate the next piece across the bar and let it slide along it. The
# knob is one major arc, so the circle of radius GINS_KNOB_R bulges past the
# GINS_NECK opening it grows out of, and the notch on the next piece is the
# same arc traversed the other way. Both come out of one function for that
# reason, and a change to either shape is a change to both.
GINS_KNOB_R, GINS_NECK = 3.0, 2.0
GINS_SEAT_DX = GINS_PC * 3.5      # the free knob on top of the last piece
GINS_SEAT_DY = -9.0


def gins_ends(cx, cy, axis='x', out=True):
    """Where one joint curve starts and ends, given the centre of the joint.

    Both ends are derived from the same centre, so the neck is the same width
    on a knob and on the notch that takes it. An earlier version took the start
    point from the caller and computed only the end, which let the notch be
    drawn across half the neck: same radius, shorter chord, and a hole that
    came out rounder than the knob meant to fill it.
    """
    n = GINS_NECK
    if axis == 'x':
        return ((cx, cy - n), (cx, cy + n)) if out else ((cx, cy + n), (cx, cy - n))
    return ((cx - n, cy), (cx + n, cy)) if out else ((cx + n, cy), (cx - n, cy))


def gins_knob(cx, cy, axis='x', out=True):
    """One knob or the notch that receives it, as 'L start A ... end'.

    axis 'x' runs the joint down a vertical edge and the knob points right;
    axis 'y' runs it along a horizontal edge and the knob points up. out=False
    is the same curve traversed backwards, which is the notch: reversing a path
    direction flips the sweep flag, so the two are one shape and not two.
    """
    (sx, sy), (ex, ey) = gins_ends(cx, cy, axis, out)
    return ('L%.1f %.1f A%.1f %.1f 0 1 %d %.1f %.1f'
            % (sx, sy, GINS_KNOB_R, GINS_KNOB_R, 1 if out else 0, ex, ey))


def gins_seat(x, y):
    """Where Dpb11 takes hold of a free GINS bar whose left end is at x, y."""
    return (x + GINS_SEAT_DX, y + GINS_SEAT_DY)


def gins_bar(x, y, ident=None, fits=True):
    """GINS. Four jigsaw pieces that mesh exactly.

    Every piece carries a knob on its right edge and the notch that receives it
    on its left, both drawn from gins_knob, so the joint between two pieces is
    one curve drawn twice and cannot drift. That leaves a free notch at the
    left end of the bar and a free knob at the right, which is the idiom for a
    chain that could go on. The knob on top of the last piece is the one Dpb11
    takes hold of.

    x, y is the left end of the bar.
    """
    i = ' id="%s"' % ident if ident else ''
    top, bot = y - 9.0, y + 9.0
    out = ['<g class="gins"%s>' % i]
    for k, lab in enumerate('GINS'):
        px = x + k * GINS_PC
        # Round the outline once: top edge, then the knob on the right edge
        # going down, then the bottom edge, then the notch on the left edge
        # going back up. Both joints are centred on the edge they sit in, so a
        # knob and the notch beside it are the same curve.
        d = ['M%.1f %.1f' % (px, top)]
        if k == 3:
            d.append(gins_knob(px + GINS_PC / 2.0, top, 'y'))
        d.append('L%.1f %.1f' % (px + GINS_PC, top))
        d.append(gins_knob(px + GINS_PC, y))
        d.append('L%.1f %.1f L%.1f %.1f' % (px + GINS_PC, bot, px, bot))
        d.append(gins_knob(px, y, 'x', out=False))
        d.append('L%.1f %.1f Z' % (px, top))
        out.append('<path class="ginspiece g%d" d="%s"/>' % (k, ' '.join(d)))
        # Nudged clear of the notch, which sits on the left of every piece.
        out.append('<text class="glyphlab xs" x="%.1f" y="%.1f">%s</text>'
                   % (px + GINS_PC / 2.0 + 2.5, y + 3, lab))
    if fits:
        out.append(fitpoint('dpb11-gins', 'seat', *gins_seat(x, y)))
    out.append('</g>')
    return ''.join(out)


DPB11_W, DPB11_H = 140.0, 20.0
DPB11_SLD2_DX, DPB11_GINS_DX = -46.0, 45.0
DPB11_SLD3_DX = -DPB11_W / 2.0        # the end face, where the bridge starts


def dpb11_sld3_socket(x, y):
    """Panel coordinate of the mouth Dpb11 offers phosphorylated Sld3."""
    return (x + DPB11_SLD3_DX, y)


def dpb11_bar(x, y, ident=None, fits=True, sld3=True):
    """Dpb11. Two sockets on its underside: one domed, cut to the Sld2 arch,
    and one square with a blank cut to the GINS end tab. Both sockets filled is
    the assembled state; both empty is the recruiting state.

    The socket coordinates are the mouths of the two cuts, which is also where
    the Sld2 springing line and the free GINS tab sit, so the fits are one
    subtraction apart and cannot drift.

    A third cut sits on the end face and is star shaped, cut to the phosphate
    exactly, because what it takes is a mark and not an outline. That cut is
    what holds the whole Dpb11 module at the origin: without it the module is
    drawn beside the double hexamer touching nothing, which is a delivery the
    panel never shows being made.
    """
    i = ' id="%s"' % ident if ident else ''
    hw, hh = DPB11_W / 2.0, DPB11_H / 2.0
    sx, gx = x + DPB11_SLD2_DX, x + DPB11_GINS_DX
    out = ['<g class="dpb11"%s>' % i]
    out.append('<rect class="dpb11body" x="%.1f" y="%.1f" width="%.1f" height="%.1f" rx="5"/>'
               % (x - hw, y - hh, DPB11_W, DPB11_H))
    out.append('<path class="dpb11socket" d="M%.1f %.1f A%.1f %.1f 0 0 0 %.1f %.1f"/>'
               % (sx - ARCH_W / 2.0, y + hh, ARCH_W / 2.0, 9.0,
                  sx + ARCH_W / 2.0, y + hh))
    # The GINS socket is the same knob curve as the one on top of the last GINS
    # piece, so the cut is the shape of what fills it and not a square that
    # happens to sit nearby.
    gs = gins_ends(gx, y + hh, 'y')[0]
    out.append('<path class="dpb11socket" d="M%.1f %.1f %s"/>'
               % (gs[0], gs[1], gins_knob(gx, y + hh, 'y')))
    if sld3:
        bx, by = dpb11_sld3_socket(x, y)
        out.append('<path class="archcleft" d="%s"/>' % _star_path(bx, by, PHOS_R, 2.2))
    out.append('<text class="glyphlab sm" x="%.1f" y="%.1f">Dpb11</text>'
               % (x + 12.0, y + 3))
    if fits:
        out.append(fitpoint('dpb11-sld2', 'socket', sx, y + hh))
        out.append(fitpoint('dpb11-gins', 'socket', gx, y + hh))
        if sld3:
            out.append(fitpoint('sld3-phos', 'socket', *dpb11_sld3_socket(x, y)))
    out.append('</g>')
    return ''.join(out)


def polymerase(x, y, label, cls, ident=None):
    """Hand shape."""
    i = ' id="%s"' % ident if ident else ''
    return ('<g class="pol %s"%s><path class="polpath" d="M%.1f %.1f L%.1f %.1f L%.1f %.1f '
            'L%.1f %.1f L%.1f %.1f Z"/><text class="glyphlab sm" x="%.1f" y="%.1f">%s</text></g>'
            % (cls, i, x - 18, y - 10, x + 18, y - 10, x + 18, y + 4, x, y + 12, x - 18, y + 4,
               x, y + 2, esc(label)))


def rpa(x, y, ident=None):
    return wedge(x, y, 13, 'rpaglyph', 'RPA', ident)


# --- CST --------------------------------------------------------------------
#
# Cdc13-Stn1-Ten1 keeps the glyph and the colours the telomere figure gives
# it, because a reader meets CST there first and knows it by shape and colour
# together: Cdc13 the OB-fold wedge, Stn1 a box, Ten1 the smaller box against
# Stn1. The subunits are rearranged, and the size changes, so the complex can
# sit where the two-hybrid scores put it.
#
# Where that is. All three subunits score with Mcm2, and Stn1 and Ten1 also
# score with Mcm5. In this projection Mcm2 and Mcm5 are the top two rows of the
# near arc of the left hexamer, or of the left CMG once the pair has split, and
# the near face is the outer surface of those subunits. Their other free end,
# the C-terminal tips, is where Cdc45 seats, so the face is the one place every
# model can use. CST is laid on it as a strip across the boundary between the
# Mcm2 and Mcm5 rows: Stn1 and Ten1 side by side, each covering both rows, so
# each touches both subunits. Cdc13 sits on the Stn1 C half, the half that
# binds it, on the Mcm2 row alone. The strip is CST_H tall, which clears the
# two subunit numbers above and below it, and it runs from the C-terminal end
# of the face towards the seam, which keeps every piece off the DDK marks at
# the seam. Cdc13 is a quarter disc whose straight edges face the seam and the
# strip, so its curve faces the C-terminal end of the ring, the way the strip
# leads off the face. It is too small at this size to carry its name inside,
# so the name sits to its left, beyond the C-terminal end of the ring, where it
# lands on no glyph; on a CMG it rises to the apex of the wedge to clear Cdc45.
# The Pol alpha model keeps the name under the wedge, because the left fork
# mark and GINS stand to its left there.
#
# Stn1 is two halves. The C-terminal half holds the winged helix-turn-helix
# motifs that bind Cdc13 and Pol12, so it sits against Cdc13. The N-terminal
# half is the OB fold that binds Ten1, so Ten1 sits against it. Joined, the
# halves read as the one box the telomere figure draws, with a dashed seam.
# Where a model needs the C half somewhere else, the two are drawn apart with a
# dashed linker, the drawn form of the hundred or so residues between the
# Stn1 1-186 and 288-494 fragments, and the N half and Ten1 stay on the face.
#
# No fit point is emitted anywhere on CST. The two-hybrid scores give contacts
# and no geometry, so CST touches its partners and is cut to none of them,
# which is the treatment regRIF1 gives Rif1-PP1.

CST_R = 14.0          # Cdc13 wedge radius on the face
STN1_HW = 14.0        # one half of Stn1
TEN1_W = 16.0
CST_H = 10.0          # Stn1 and Ten1; clears the subunit numbers either side
# Where the strip starts, measured in from the hexamer centre. On a pair it
# runs from one unit inside the C-terminal end of the bodies to the end of
# the flange, so Ten1 stops short of the partner hexamer's tooth, which
# interleaves there, and Cdc13 stops short of the Mcm2 number. On a CMG the
# partner has gone and Cdc45 seats on the body ends, so the strip starts three
# units in, clear of Cdc45, and runs onto the CMG's own tooth.
CST_FACE_DX = {'pair': 21.0, 'cmg': 19.0}


def face_boundary(skew=0.0):
    """MODEL: the y of the boundary between the near Mcm2 and Mcm5 rows (TERMINAL).

    skew is the half-row offset the hexamer carries: -MCM_DH_SKEW for the left
    hexamer of a pair, zero for a CMG.
    """
    return DNA_Y + (mcm_row('2', 'left', skew) + mcm_row('5', 'left', skew)) / 2.0


CDC13_LAB_GAP = 9.0   # from the left edge of Cdc13 to the right end of its name


def cdc13_label_point(left, ymid):
    """MODEL: where the Cdc13 name is centred, to the left of the wedge (TERMINAL).

    left is the leftmost x of the wedge and ymid its vertical middle. The name
    is measured with the layout guard's advance table, so its right end stops
    CDC13_LAB_GAP short of the wedge whatever the face, and the baseline sits
    so the text is centred on the wedge.
    """
    w = text_width('Cdc13', _TEXT_MODS['sm'])
    return (left - CDC13_LAB_GAP - w / 2.0, ymid + 3.0)


def cst_face(c, yb, form='pair'):
    """MODEL: every CST piece laid on the near face of a hexamer (TERMINAL).

    c is the hexamer centre and yb the Mcm2-Mcm5 boundary. form is 'pair' for
    the left hexamer of a double hexamer and 'cmg' for the left CMG. Boxes come back as
    (x1, y1, x2, y2). Cdc13 comes back as the right-angle corner of its wedge,
    which sits on the top of the Stn1 C half and rises from it, curve to the
    left, with the point its name is centred on, left of the wedge.
    """
    top, bot = yb - CST_H / 2.0, yb + CST_H / 2.0
    x0 = c - CST_FACE_DX[form]
    # On a CMG, Cdc45 sits left of the strip with its top level with the middle
    # of the wedge, so the name rises to the apex of the wedge to clear it.
    ymid = top - CST_R / 2.0 if form == 'pair' else top - CST_R - 2.0
    return {'cdc13': {'corner': (x0 + CST_R, top), 'sx': -1.0, 'sy': -1.0,
                      'lab': cdc13_label_point(x0, ymid)},
            'stn1c': (x0, top, x0 + STN1_HW, bot),
            'stn1n': (x0 + STN1_HW, top, x0 + 2.0 * STN1_HW, bot),
            'ten1': (x0 + 2.0 * STN1_HW, top, x0 + 2.0 * STN1_HW + TEN1_W, bot)}


def cst_glyph(lay, pieces=('cdc13', 'stn1c', 'stn1n', 'ten1'), ident=None,
              linker=None):
    """CST from a layout cst_face() or a panel built. No fit point is emitted.

    pieces names what is drawn. The Stn1 halves carry one label across a
    dashed seam when they abut and one label each when they do not. linker,
    as (x1, y1, x2, y2), draws the dashed linker between halves drawn apart.
    """
    i = ' id="%s"' % ident if ident else ''
    out = ['<g class="cst"%s>' % i]
    if 'cdc13' in pieces:
        w = lay['cdc13']
        (x, y), sx, sy = w['corner'], w['sx'], w['sy']
        sweep = 1 if sx * sy > 0 else 0
        out.append('<g class="cstpiece cdc13"><path class="cstcdc13" d="M%.1f %.1f '
                   'L%.1f %.1f A%.1f %.1f 0 0 %d %.1f %.1f Z"/>'
                   % (x, y, x + sx * CST_R, y, CST_R, CST_R, sweep, x, y + sy * CST_R))
        out.append('<text class="glyphlab sm" x="%.1f" y="%.1f">Cdc13</text></g>'
                   % w['lab'])
    halves = [n for n in ('stn1c', 'stn1n') if n in pieces]
    joined = (len(halves) == 2 and (abs(lay['stn1c'][2] - lay['stn1n'][0]) < 0.01
                                    or abs(lay['stn1n'][2] - lay['stn1c'][0]) < 0.01))
    for name in halves:
        b = lay[name]
        out.append('<g class="cstpiece %s"><rect class="cststn1" x="%.1f" y="%.1f" '
                   'width="%.1f" height="%.1f" rx="1.5"/>'
                   % (name, b[0], b[1], b[2] - b[0], b[3] - b[1]))
        if not joined:
            out.append('<text class="glyphlab xs" x="%.1f" y="%.1f">Stn1</text>'
                       % ((b[0] + b[2]) / 2.0, b[1] + 7.5))
        out.append('</g>')
    if joined:
        c, n = lay['stn1c'], lay['stn1n']
        sxm = c[2] if abs(c[2] - n[0]) < 0.01 else c[0]
        out.append('<path class="cstseam" d="M%.1f %.1f L%.1f %.1f"/>'
                   % (sxm, c[1] + 1.5, sxm, c[3] - 1.5))
        out.append('<text class="glyphlab xs" x="%.1f" y="%.1f">Stn1</text>'
                   % (sxm, c[1] + 7.5))
    if linker:
        out.append('<path class="cstlinker" d="M%.1f %.1f L%.1f %.1f"/>' % linker)
    if 'ten1' in pieces:
        b = lay['ten1']
        out.append('<g class="cstpiece ten1"><rect class="cstten1" x="%.1f" y="%.1f" '
                   'width="%.1f" height="%.1f" rx="1.5"/>'
                   '<text class="glyphlab xs" x="%.1f" y="%.1f">Ten1</text></g>'
                   % (b[0], b[1], b[2] - b[0], b[3] - b[1],
                      (b[0] + b[2]) / 2.0, b[1] + 7.5))
    out.append('</g>')
    return ''.join(out)


def proposal(x, y, text, max_w=260.0):
    """A proposed relationship, stated beside the drawing.

    Set in the arrow-label face, which survives the figure export, because a
    proposal printed without its qualifier would be a claim the panel does not
    make. Used where an arrow between two glyphs that already touch would be a
    stub, the case offBOB1 handles with a leader and a label.
    """
    return _lines('arrowlab prop', x, y, text, max_w, 11.0)


def nucleosome(i0, i1, ident):
    """Histone octamer spanning positions i0..i1. Presence derives from the
    complex track over the whole span, so data-span holds both bounds."""
    x = (cx(i0) + cx(i1) + CW) / 2.0
    rx = (cx(i1) + CW - cx(i0)) / 2.0 - 2
    return ('<g id="%s" class="nuc" data-span="%s %s"><ellipse class="nucbody" cx="%.1f" '
            'cy="%.1f" rx="%.1f" ry="19"/><text class="glyphlab sm lt" x="%.1f" y="%.1f">'
            'nuc</text></g>' % (ident, chunk_id(i0), chunk_id(i1), x, DNA_Y, rx, x, DNA_Y + 3))


# ===========================================================================
# SUBSTRATE
# ---------------------------------------------------------------------------
# Two tracks per position. The strand track holds duplex, melted or extruded;
# the complex track holds naked, orc, occm, mcm1, mcm2 or cmg. A third declared
# quantity, kink, rides the strand group as its own class family, because
# whether the bend relaxes is a claim and not a consequence of anything else.
#
# The bars sit inside a kink wrapper, so the kink rotation and the melting
# translation apply to different elements and compose. Writing both on the bar
# would put two values on one transform property and silently drop one.
#
# The complex group also carries a presence state, which is the sixth field on
# a track row. It used to be written as a literal here, on the assumption that
# a position either holds something or holds naked and there is nothing in
# between. ORC is what breaks that. It binds the ARS in step01 and is still
# there in step11, and somewhere in the middle it stops being part of the
# reaction: the double hexamer slides off it, CMG assembles without it, and the
# forks establish without it. Occupancy cannot say that and neither can naked,
# so presence says it, the panels that draw a spent initiator declare it, and
# paintDerived carries it onto the glyph.
# ===========================================================================

# extruded and replicated are two different claims about one position and not
# two names for one. extruded says the parental strands are apart and single
# stranded, which is the state RPA sits on and the state a polymerase has not
# reached yet. replicated says a daughter strand has been laid against each of
# them. Collapsing the two would make synthesis happen in the same instant as
# unwinding and leave the polymerases with nothing to travel across.
STRAND_VALUES = ['duplex', 'melted', 'extruded', 'replicated']
CPX_VALUES = ['naked', 'orc', 'occm', 'mcm1', 'mcm2', 'cmg']
KINK_VALUES = ['kink-none', 'kink-transient', 'kink-fixed']

# Gate is the fourth declared quantity and rides the complex group as its own
# class family, for the same reason kink rides the strand group. Whether the
# Mcm2-Mcm5 ring is open is a claim about the step and not a consequence of
# what occupies the position: a hexamer arrives open, threads DNA, and closes,
# and deriving the gate from occupancy would collapse those into one fact.
# Sealed is separate from closed because Cdc45 and GINS across the gate is a
# different claim from Mcm2 and Mcm5 in contact.
GATE_VALUES = ['gate-na', 'gate-open', 'gate-closed', 'gate-sealed']

# The NSD is the fifth declared quantity and rides the complex group beside
# gate. See the note at NSD_VALUES for why it is declared and not derived:
# whether the Mcm4 NSD is seated, displaced or deleted is a claim about the
# step, and deriving it from the marks would make the Mcm4 N-terminal deletion
# indistinguishable from the unphosphorylated origin it bypasses.

# Presence is the sixth, and unlike the other five it is shared with the strand
# group and with every fx wrapper, because it is the one family the engine has
# always had. What is new is that a panel can now write it on the complex track
# at rest rather than taking present by default.
STATE_VALUES = ['gone', 'fading', 'arriving', 'present']


def tracks_default():
    """Every position duplex, naked, unkinked, no ring, no NSD, present.
    Panels edit from here."""
    return [['duplex', 'naked', 'kink-none', 'gate-na', 'nsd-na', 'present']
            for _ in range(NPOS)]


def set_cpx(t, a, b, value):
    for i in range(lin(a), lin(b) + 1):
        t[i - 1][1] = value


def set_strand(t, a, b, value):
    for i in range(lin(a), lin(b) + 1):
        t[i - 1][0] = value


def set_kink(t, a, b, value):
    for i in range(lin(a), lin(b) + 1):
        t[i - 1][2] = value


def set_gate(t, a, b, value):
    for i in range(lin(a), lin(b) + 1):
        t[i - 1][3] = value


def set_nsd(t, a, b, value):
    for i in range(lin(a), lin(b) + 1):
        t[i - 1][4] = value


def set_cpx_state(t, a, b, value):
    """Presence on the complex track.

    fading is used here for a complex that has not gone anywhere. Everywhere
    else in the model the state means departing and resolves to gone within a
    few frames; ORC's never does, and no frame in any panel takes an ORC run to
    gone. What the dim carries is that the initiator is finished, not that it
    has left, and the captions from step06 on say so in words.
    """
    for i in range(lin(a), lin(b) + 1):
        t[i - 1][5] = value


def ars_pieces(i):
    """The two halves of the ARS block at one position.

    The block is emitted per position and split at the DNA axis, so each half
    sits inside the strand group that carries it and separates with the strands
    when that region melts. A single rect across four positions could not do
    either.
    """
    half = 13.0
    out = ['<rect class="arsblock top" x="%.1f" y="%.1f" width="%d" height="%.1f"/>'
           % (cx(i) + 0.5, DNA_Y - half, CW - 1, half),
           '<rect class="arsblock bot" x="%.1f" y="%.1f" width="%d" height="%.1f"/>'
           % (cx(i) + 0.5, DNA_Y, CW - 1, half)]
    if i == lin(ARS_A) + 1:
        # Above the block and not inside it. Written inside a position group it
        # was painted over by the blocks of the positions that follow, which is
        # why it used to read as two letters.
        out.append('<text class="arslab top" x="%.1f" y="%.1f">ARS</text>'
                   % (cx(i) + CW, DNA_Y - half - 7.0))
    return ''.join(out)


def rung_pieces(i, nascent, split=None):
    """The base-pair rungs at one position.

    The duplex rungs join the two parental bars and show only while the
    position is duplex: melting breaks them. A daughter's rungs join it to
    the parental bar it was copied from, carry the same lead or lag and face
    classes as that daughter, and show and open with it, so a copied position
    reads as two daughter duplexes, the way the chromosome view and its
    close-up draw replication. They are emitted only on panels that draw
    daughters.
    """
    left = i <= (FORK_SPLIT if split is None else split)
    out = []
    for dx in RUNG_DX:
        x = cx(i) + dx
        out.append('<path class="rung dup" d="M%.1f %.1f V%.1f"/>' % (x, ROW_T + BAR_H, ROW_B))
        if nascent:
            out.append('<path class="rung %s top" d="M%.1f %.1f V%.1f"/>'
                       % ('lead' if left else 'lag', x, ROW_T + BAR_H, NASC_TOP_Y))
            out.append('<path class="rung %s bot" d="M%.1f %.1f V%.1f"/>'
                       % ('lag' if left else 'lead', x, NASC_BOT_Y + NASC_H, ROW_B))
    return ''.join(out)


def _nasc_rect(x0, x1, y, cls):
    """One piece of daughter strand, as a rect between two x coordinates."""
    return ('<rect class="nasc %s" x="%.1f" y="%.1f" width="%.1f" height="%.1f"/>'
            % (cls, x0, y, x1 - x0, NASC_H))


def nascent_pieces(i, split=None):
    """The two daughter strands at one position.

    Which of the two is continuous follows from the direction of the fork that
    made it. A polymerase reads its template 3' to 5', so on the left of the
    origin the leading template is the top strand and on the right of it the
    bottom one. That makes the assignment a function of the position index and
    of nothing else, and it is why the two forks are drawn as mirror images
    instead of copies.

    The lagging daughter is cut into fragments on boundaries counted outward
    from the origin, OKAZAKI_N positions each. Each fragment is primed at its
    fork-proximal end and extended back toward the origin, so the primer sits
    at the outward end of the outermost position of the fragment and the nick
    falls on the inward edge of the next one. The boundaries are keyed to the
    absolute position index and not to how far the fork has travelled, so a
    fragment appears whole as the fork clears it instead of growing a position
    at a time, which is what discontinuous synthesis looks like.

    Every piece is emitted here and none of them decides when it is shown. The
    leading pieces follow the position's own strand state, because leading
    synthesis keeps up with the fork. The lagging pieces are timed by
    paintLagging() in src/animate.js against how far the fork has gone, because
    a lagging fragment is laid in the opposite direction to fork travel and no
    per-position value can say that: the position the fork reaches first is the
    one that gets its piece first, and the positions behind it fill in later,
    after the fork has moved on.
    """
    # split names the origin the fork that copied this position came from;
    # a passing fork's origin lies off the page, so the close-up's passive
    # panels give one far to the side.
    sp = FORK_SPLIT if split is None else split
    left = i <= sp
    d = sp - i + 1 if left else i - sp
    lead_cls = 'top' if left else 'bot'
    lag_cls = 'bot' if left else 'top'
    lead_y = NASC_TOP_Y if left else NASC_BOT_Y
    lag_y = NASC_BOT_Y if left else NASC_TOP_Y
    x0, x1 = cx(i), cx(i) + CW
    out = []

    # Leading strand. One bar per position, drawn edge to edge so consecutive
    # positions abut and the strand reads as one piece. The single primer that
    # started it sits at the origin end of the first position.
    lead_cls = 'lead ' + lead_cls
    lag_cls = 'lag ' + lag_cls
    if d == 1:
        if left:
            out.append(_nasc_rect(x0, x1 - PRIMER_W, lead_y, 'dna ' + lead_cls))
            out.append(_nasc_rect(x1 - PRIMER_W, x1, lead_y, 'primer ' + lead_cls))
        else:
            out.append(_nasc_rect(x0, x0 + PRIMER_W, lead_y, 'primer ' + lead_cls))
            out.append(_nasc_rect(x0 + PRIMER_W, x1, lead_y, 'dna ' + lead_cls))
    else:
        out.append(_nasc_rect(x0, x1, lead_y, 'dna ' + lead_cls))

    # Lagging strand. k counts across one fragment, outward from the origin.
    k = (d - 1) % OKAZAKI_N + 1
    a, b = x0, x1
    if k == 1:
        # The inward edge of a fragment is where it meets the one before it.
        if left:
            b -= NICK_W
        else:
            a += NICK_W
    if k == OKAZAKI_N:
        if left:
            out.append(_nasc_rect(a, a + PRIMER_W, lag_y, 'primer ' + lag_cls))
            out.append(_nasc_rect(a + PRIMER_W, b, lag_y, 'dna ' + lag_cls))
        else:
            out.append(_nasc_rect(a, b - PRIMER_W, lag_y, 'dna ' + lag_cls))
            out.append(_nasc_rect(b - PRIMER_W, b, lag_y, 'primer ' + lag_cls))
    else:
        out.append(_nasc_rect(a, b, lag_y, 'dna ' + lag_cls))
    return ''.join(out)


def substrate(t, back='', nascent=False):
    """Draw the substrate. Zone tints carry no class here: paintDerived owns
    them, and a class written at build time would be a second source of truth.

    back is the far arc of every hexamer on the panel. It is emitted between
    the nucleosomes and the strand bars, so the bars are drawn over it and the
    DNA reads as passing through the ring rather than in front of it.

    nascent adds the two daughter strands to every position. They are drawn
    only for panels that can declare a position replicated, because the markup
    costs about eight kilobytes a panel and would show nothing in the
    twenty-nine panels that never reach that state.
    """
    a, b = lin(ARS_A), lin(ARS_B)
    out = ['<g class="substrate" data-left="%s" data-right="%s" data-n="%d" '
           'data-ars="%s %s">' % (chunk_id(1), chunk_id(NPOS), NPOS, ARS_A, ARS_B)]
    out.append('<g class="zonelayer">')
    for i in range(1, NPOS + 1):
        out.append('<rect id="%s-z" class="zone" x="%.1f" y="%d" width="%d" height="%d"/>'
                   % (chunk_id(i), cx(i), ZONE_Y, CW, ZONE_H))
    out.append('</g>')
    out.append('<g class="nuclayer">')
    for k, (n0, n1) in enumerate(NUC_SPANS):
        out.append(nucleosome(n0, n1, 'nuc%d' % (k + 1)))
    out.append('</g>')
    out.append('<g class="glyphlayer back">')
    out.append(back)
    out.append('</g>')
    out.append('<g class="strandlayer">')
    for i in range(1, NPOS + 1):
        pid = chunk_id(i)
        ctx = ' ctx' if (i <= LEFT_CTX or i > LEFT_CTX + ORIGIN_N) else ''
        out.append('<g id="%s-s" class="strand %s present %s%s">'
                   % (pid, t[i - 1][0], t[i - 1][2], ctx))
        out.append('<g class="kinkwrap">')
        out.append('<rect class="bar top" x="%.1f" y="%d" width="%d" height="%d"/>'
                   % (cx(i) + 0.5, ROW_T, CW - 1, BAR_H))
        out.append('<rect class="bar bot" x="%.1f" y="%d" width="%d" height="%d"/>'
                   % (cx(i) + 0.5, ROW_B, CW - 1, BAR_H))
        out.append(rung_pieces(i, nascent))
        if a <= i <= b:
            out.append(ars_pieces(i))
        if nascent:
            out.append(nascent_pieces(i))
        out.append('</g></g>')
    out.append('</g>')
    out.append('<g class="cpxlayer">')
    for i in range(1, NPOS + 1):
        pid = chunk_id(i)
        out.append('<g id="%s-c" class="cpx %s %s %s %s">'
                   '<rect class="cpxbar" x="%.1f" y="%d" width="%d" height="%d"/></g>'
                   % (pid, t[i - 1][1], t[i - 1][5], t[i - 1][3], t[i - 1][4],
                      cx(i) + 0.5, CPX_Y, CW - 1, CPX_H))
    out.append('</g>')
    out.append('</g>')
    return ''.join(out)


# ===========================================================================
# STATUS INDICATOR
# ---------------------------------------------------------------------------
# Four slots, same corner of every panel, every panel declares every slot.
# Four states are derived and lost is declared. The derivation below is
# mirrored exactly by deriveCaps() in src/animate.js, and the test suite
# compares the resting value computed here against the engine at frame 0.
#
# Presence on the complex track is deliberately not read here, and neither
# implementation reads it. A dimmed ORC is still bound to the ARS, so
# Specification still reports ORC-Cdc6 or ORC alone. The slot answers what the
# evidence establishes at the origin; the dim answers whether the reaction is
# still running through it, which is a different question.
# ===========================================================================

CAP_SLOTS = ['specification', 'licensing', 'activation', 'fork']
CAP_NAMES = {'specification': 'Specification', 'licensing': 'Licensing',
             'activation': 'Activation', 'fork': 'Fork'}


def derive_caps(t, cdc6=False, phos=False, cdc45=False, lost=()):
    vals = [row[1] for row in t]
    strands = [row[0] for row in t]
    nsds = [row[4] for row in t]
    has_orc = 'orc' in vals
    has_occm = 'occm' in vals
    has_m1 = 'mcm1' in vals
    has_m2 = 'mcm2' in vals
    has_cmg = 'cmg' in vals
    melted = 'melted' in strands
    # A replicated position is an extruded one that has been copied, so it
    # reports the same slot. The distinction the two values carry is about the
    # polymerases and not about what the fork slot answers.
    extruded = 'extruded' in strands or 'replicated' in strands
    # A pair is competent once the NSD inhibition is relieved or Cdc45 is on
    # the origin. A pair whose NSD has been deleted has nothing to relieve, so
    # it counts as competent with no mark on it; a displaced NSD alone does not,
    # because the inhibition is relieved by phosphorylation and not by Dbf4
    # binding. Reading the marks alone would report the Mcm4 N-terminal deletion
    # as an unactivated origin, which is the opposite of what that panel shows.
    # A released NSD counts the same way: it is the figure's picture of the
    # inhibition lifted without a mark. Mirrored in deriveCaps().
    relieved = 'nsd-absent' in nsds or 'nsd-released' in nsds
    out = {}
    out['specification'] = 'on' if (has_orc and cdc6) else ('thin' if has_orc else 'off')
    if has_m2 or has_cmg:
        out['licensing'] = 'on'
    elif has_m1 or has_occm:
        out['licensing'] = 'thin'
    elif has_orc:
        out['licensing'] = 'off'
    else:
        out['licensing'] = 'na'
    if has_cmg:
        out['activation'] = 'on'
    elif has_m2 and (relieved or phos or cdc45):
        out['activation'] = 'thin'
    elif has_m1 or has_m2 or has_occm:
        out['activation'] = 'off'
    else:
        out['activation'] = 'na'
    if extruded:
        out['fork'] = 'on'
    elif melted:
        out['fork'] = 'thin'
    elif has_cmg:
        out['fork'] = 'off'
    else:
        out['fork'] = 'na'
    for slot in lost:
        out[slot] = 'lost'
    return out


def capbar(t, cdc6=False, phos=False, cdc45=False, lost=(), lost_pending=()):
    rest = derive_caps(t, cdc6, phos, cdc45, lost)
    out = ['<g class="capbar">']
    out.append('<rect class="capplate" x="%.1f" y="%.1f" width="%.1f" height="%.1f" rx="6"/>'
               % (KEEPOUT[0], KEEPOUT[1], KEEPOUT[2] - KEEPOUT[0], KEEPOUT[3] - KEEPOUT[1]))
    out.append('<text class="caplab" x="%d" y="30">Origin state</text>' % (VBW - 196))
    for k, slot in enumerate(CAP_SLOTS):
        y = 44 + k * 21
        out.append('<g id="cap-%s" class="capslot %s" data-rest="%s">'
                   % (slot, rest[slot], rest[slot]))
        out.append('<text class="capname" x="%d" y="%d">%s</text>'
                   % (VBW - 196, y + 4, CAP_NAMES[slot]))
        out.append('<rect class="cappill" x="%d" y="%d" width="94" height="15" rx="7"/>'
                   % (VBW - 104, y - 8))
        out.append('<text class="capword" x="%d" y="%d"></text>' % (VBW - 57, y + 3))
        out.append('</g>')
    for slot in list(lost) + list(lost_pending):
        out.append(fx('fx-lost-%s' % slot,
                      '<g class="lostpill"><rect class="lostbox" x="%d" y="%d" width="94" '
                      'height="15" rx="7"/><text class="glyphlab sm" x="%d" y="%d">lost</text>'
                      '</g>' % (VBW - 104, 36 + CAP_SLOTS.index(slot) * 21,
                                VBW - 57, 47 + CAP_SLOTS.index(slot) * 21),
                      pending=(slot in lost_pending)))
    out.append('</g>')
    return ''.join(out)


# ===========================================================================
# PANEL WRAPPER
# ===========================================================================

def defs(key):
    """Per-panel markers. Every panel is inlined into one document, so a
    repeated marker id would make every reference resolve to the first match."""
    m = []
    for suffix, cls in (('', 'ahead'), ('g', 'ahead grey'), ('r', 'ahead red')):
        m.append('<marker id="ah%s-%s" viewBox="0 0 10 10" refX="9" refY="5" '
                 'markerWidth="6" markerHeight="6" orient="auto-start-reverse">'
                 '<path class="%s" d="M0 0 L10 5 L0 10 z"/></marker>' % (suffix, key, cls))
    # The proposal head is an open chevron sized in panel units, so the heavy
    # proposal line does not scale it up with its stroke width.
    m.append('<marker id="ahp-%s" viewBox="0 0 10 10" refX="8" refY="5" '
             'markerUnits="userSpaceOnUse" markerWidth="15" markerHeight="15" '
             'orient="auto-start-reverse"><path class="ahead prop" '
             'd="M1.5 1 L8.5 5 L1.5 9"/></marker>' % key)
    return '<defs>%s</defs>' % ''.join(m)


def panel(key, body):
    return ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 %d %d" '
            'class="panelsvg" data-key="%s">%s%s</svg>' % (VBW, VBH, key, defs(key), body))


def stage(key, t, glyphs='', back='', furniture='', cdc6=False, phos=False,
          cdc45=False, lost=(), lost_pending=(), note=None, brackets='',
          substrate_on=True, nascent=False):
    """Compose one panel.

    Layer order is zones, nucleosomes, the far arcs, the strand bars, the
    complex track, brackets, the near arcs and everything else, then the status
    indicator and the furniture.

    substrate_on=False drops the substrate and the status indicator together. A
    panel with no substrate has no tracks to derive four slots from, so a
    status indicator on it would be reporting on something that is not drawn.
    The two travel together and the test suite asserts it.
    """
    body = []
    if substrate_on:
        body.append(substrate(t, back, nascent))
    elif back:
        body.append('<g class="glyphlayer back">%s</g>' % back)
    body.append(brackets)
    body.append('<g class="glyphlayer front">%s</g>' % glyphs)
    if substrate_on:
        body.append(capbar(t, cdc6, phos, cdc45, lost, lost_pending))
    body.append(furniture)
    if note:
        body.append(notelab(note))
    return panel(key, ''.join(body))


# ===========================================================================
# DERIVED ACTOR SHELLS
# ---------------------------------------------------------------------------
# Every derived actor is drawn once at a base x and repositioned by
# paintDerived. Each carries data-basex so the reset can be undone, and each
# has a defined position in the empty state.
# ===========================================================================

ORC_Y = DNA_Y - 4.0


def split(parts):
    """Sort a panel's glyph list into the far layer and the near layer.

    A hexamer comes back as a (back, front) pair because its two arcs go into
    different layers. Everything else is one string and belongs in front.
    """
    back, front = [], []
    for part in parts:
        if isinstance(part, tuple):
            back.append(part[0])
            front.append(part[1])
        else:
            front.append(part)
    return ''.join(back), ''.join(front)


def orc_actor(cdc6=False, cdc6_pending=False, behind=False):
    """ORC at the ARS.

    behind puts the whole initiator in the far layer, which is what the firing
    panels use. Cdc6 ATPase has released the double hexamer from ORC by then and
    the pair has slid clear, so the two are no longer in one plane; drawn in one
    layer they collide, and the collision reads as contact that the model does
    not claim. Sending ORC back also clears the outer face of the left hexamer,
    which is where Cdc45 seats and where the clasp runs its arm.
    """
    g = actor('orc', orc_ring(ARS_X, ORC_Y, cdc6=cdc6, cdc6_pending=cdc6_pending),
              basex=ARS_X)
    return (g, '') if behind else g


def occm_actor(fits=('cdt1',)):
    """The assembled OCCM, as a (back, front) pair of actors.

    The two arcs of one hexamer sit in different layers, so one glyph needs two
    actor groups. They share a basex, paintDerived gives them one translate,
    and the test suite fails if the two ever differ.
    """
    nx, ny = orc_notch(ARS_X, ORC_Y)
    fxp, fyp = cdc6_flank(nx, ny)
    mx, my = mcm_tip(OCCM_X, DNA_Y, '3')
    b, f = mcm_hexamer(OCCM_X, DNA_Y, gate='open', fits=fits)
    return (actor('occm-b', b, basex=OCCM_X),
            actor('occm', f + cdt1_arm(fxp, fyp, mx, my), basex=OCCM_X))


def mcm1_actor():
    b, f = mcm_hexamer(H1_X, DNA_Y)
    return (actor('mcm1-b', b, basex=H1_X), actor('mcm1', f, basex=H1_X))


def dh_actor(phos=False, phos_pending=True, fits=(), fits_side='both',
             nsd='seated', mimic=False, mcm2p='none', bob1=(), graded=False):
    """The double hexamer as a derived actor.

    All three NSD forms are emitted and the engine shows one from the NSD value
    on the complex track, so a panel whose frames change that value animates
    the swing, and one that never changes it draws the form its markup
    declares. mcm2p, bob1 and graded are passed straight to mcm_double.
    """
    b, f = mcm_double(DH_X, DNA_Y, nsd=nsd, phos=phos, phos_pending=phos_pending,
                      fits=fits, fits_side=fits_side, toggle=True, mimic=mimic,
                      mcm2p=mcm2p, bob1=bob1, graded=graded)
    return (actor('dh-b', b, basex=DH_X), actor('dh', f, basex=DH_X))


def sld_actor(fits=True, nsd_fit=False, borne=False, borne_pending=True, bridge=False,
              cdc45=True, cdc45_pending=True, presence=''):
    """The Sld3-Sld7 clasp, as a (back, front) pair of actors.

    Declared and not derived: the clasp arrives, and where it is on the way in
    is a claim the frames make. It is split for the same reason a hexamer is,
    because the Cdc45 that seals the far hexamer belongs in the far layer, and
    the two halves share a basex so one frame entry moves both.
    """
    b, f = sld_cradle(DH_X, DNA_Y, fits=fits, nsd_fit=nsd_fit, borne=borne,
                      borne_pending=borne_pending, bridge=bridge,
                      cdc45=cdc45, cdc45_pending=cdc45_pending)
    if presence:
        # A panel where the clasp is released wraps it, so it can leave by
        # fading rather than by travelling to somewhere there is room for it.
        # Sliding a glyph this size off a fixed camera means parking it on top
        # of something else.
        f = fx(presence, f, pending=False)
        b = fx(presence + '-b', b, pending=False)
    return (actor('sld3-b', b, basex=DH_X), actor('sld3', f, basex=DH_X))


# Where Pol epsilon sits on a CMG: beside the GINS bar, on the outer side,
# which is the C-terminal face of the helicase it engages. Placed from the GINS
# bar rather than beside the hexamer, so it follows GINS if the seal is moved.
CMG_POLE_DX = 32.0            # from the outer end of GINS to the hand centre
CMG_POLE_DY = 43.0            # below the DNA axis, level with the GINS bar


# How far the bottom bar drops at each opened strand state. Duplicated from
# the translateY on .strand.melted .bar.bot and .strand.extruded .bar.bot in
# src/style.css, which is what actually moves the bar; the ejected strand has
# to land on the bar it stands for in both states.
EJECT_DROP = {'melt': 6.0, 'open': 13.0}


def ejected_strand(x, show=None):
    """The lagging template of the left CMG, leaving its ring through the gate.

    Each CMG ejects its lagging strand through its Mcm2-Mcm5 gate as the two
    helicases pass. The left CMG carries that gate on the near face, so the
    strand it ejects, the bottom one on this side of the origin, is drawn in
    front of the near arc, which in this projection is outside the ring. It
    runs in from the C-terminal end of the ring at the height of the bottom bar
    and turns up into the gate at the boundary between the Mcm2 and Mcm5 rows,
    under the middle of the Stn1 N half where cst_face() puts it, which is
    where the ssDNA-binding model has the N fold hold it. One copy per opened
    state, each in its own wrapper, so a frame shows the one that matches the
    strand track and the strand never leaves the line of the bars beside it.

    The right CMG ejects the top strand through its far-side gate, which this
    projection cannot show without hiding the strand, so the left CMG stands
    for both and the caption says so.

    show names the state drawn at rest, 'melt' or 'open', for a static panel
    that has no frame table to bring one in. None leaves both hidden.
    """
    exit_x = x - CST_FACE_DX['cmg'] + 1.5 * STN1_HW
    gate = face_boundary() + CST_H / 2.0
    out = []
    for state, drop in sorted(EJECT_DROP.items()):
        bar = ROW_B + drop
        # One outline for the whole L, so the turn into the gate has no seam.
        xl, h = x - MCM_HALF, BAR_H / 2.0
        out.append(fx('fx-eject-%s' % state,
                      '<path class="ejectbar" d="M%.1f %.1f L%.1f %.1f L%.1f %.1f '
                      'L%.1f %.1f L%.1f %.1f L%.1f %.1f Z"/>'
                      % (xl, bar, exit_x - h, bar, exit_x - h, gate, exit_x + h, gate,
                         exit_x + h, bar + BAR_H, xl, bar + BAR_H),
                      pending=(state != show)))
    return ''.join(out)


# How far each CMG stands off the pair once it has split and before its region
# opens: paintForkLayer puts the left one at the run centre less MCM_W / 2 + 3,
# and the shells are drawn at MCM_HALF, so each sits 3 units out from its shell.
CMG_SPLIT_DX = 3.0


def cmg_gins_pole(side):
    """MODEL: where one CMG draws its GINS bar and its Pol epsilon (TERMINAL).

    Returns (gins_left_x, gins_y, pole_x, pole_y) in shell coordinates, the
    numbers cmg_actor() draws with, so a free GINS or Pol epsilon can be sent to
    exactly the place the helicase will show it.
    """
    x = DH_X + (-MCM_HALF if side == 'l' else MCM_HALF)
    face = 'left' if side == 'l' else 'right'
    sx, sy = mcm_seat(x, DNA_Y, '2', face)
    gx = sx + (-CDC45_W / 2.0 if face == 'left' else CDC45_W / 2.0) - GINS_W / 2.0
    px_ = gx - CMG_POLE_DX if face == 'left' else gx + GINS_W + CMG_POLE_DX
    return gx, DNA_Y + 42.0, px_, DNA_Y + CMG_POLE_DY


def cmg_actor(side, fits=False, pole=False, eject=False, bob1=()):
    """One CMG, as a (back, front) pair. side is 'l' or 'r'.

    Side also fixes which way the hexamer faces, because the two CMGs come out
    of one double hexamer and keep the orientation they had in it. The right
    one therefore carries its 2/5 gate on the far side, and the Cdc45 that
    seals that gate goes into the far layer with it. Drawing the seal in front
    would put it on the face it does not seal.

    fits asserts the full Cdc45 seat on the gate. It is set in step 9, the
    panel in which GINS completes the seat Cdc45 began with Sld3, and nowhere
    else.

    pole adds Pol epsilon beside the GINS bar, which makes the drawn helicase
    CMGE. It is set in steps 9 and 10 only. Step 11 draws Pol epsilon at the
    fork on the leading template as its own actor, and setting it there as well
    would draw one polymerase twice. No fit is claimed, because no
    complementary shape between Pol epsilon and GINS is drawn.
    """
    x = DH_X + (-MCM_HALF if side == 'l' else MCM_HALF)
    face = 'left' if side == 'l' else 'right'
    tag = '-0' if side == 'l' else '-1'
    b, f = mcm_hexamer(x, DNA_Y, face, gate='sealed',
                       fits=('cdc45',) if fits else (), tag=tag, bob1=bob1)
    sx, sy = mcm_seat(x, DNA_Y, '2', face)
    gx, gy, px_, py_ = cmg_gins_pole(side)
    seal = (cdc45_blob(sx, sy, face, fits=fits, tag=tag)
            + gins_bar(gx, gy, fits=False))
    if pole:
        seal += polymerase(px_, py_, 'Pol eps', 'pole')
    if mcm_gate_face(face) == 'back':
        b += seal
    else:
        f += seal
    # eject draws the lagging template outside the ring, which only the CST
    # firing models do. It rides the near-layer group, so it moves with the
    # helicase, and only the CMG whose gate faces the viewer can show it. A
    # string names the opened state a static panel shows at rest.
    if eject and mcm_gate_face(face) == 'front':
        f += ejected_strand(x, show=eject if isinstance(eject, str) else None)
    return (actor('cmg-%s-b' % side, b, basex=x), actor('cmg-' + side, f, basex=x))


def rpa_actor(side, shake=None):
    """RPA on the unwound stretch behind one fork.

    Drawn between the two parental strands and not under them. What RPA binds
    is the single-stranded DNA the helicase has opened and the polymerase has
    not yet copied, which is exactly the gap the two bars leave when a position
    reads extruded, and paintDerived puts the glyph on the run of positions
    that carry that value. Drawn below the substrate it sat on the leading side
    of one fork and the lagging side of the other, which is a statement about
    strand choice that would have been wrong for one of the two.
    """
    x = DH_X + (-70 if side == 'l' else 70)
    body = (shake or (lambda b: b))(rpa(x, DNA_Y + 14))
    return actor('rpa-' + side, inner('rpain-' + side, body), basex=x)


def fork_mark(side):
    x = DH_X + (-50 if side == 'l' else 50)
    return actor('fork-' + side,
                 '<g class="forkmark"><path class="forkline" d="M%.1f %.1f L%.1f %.1f"/>'
                 '%s</g>'
                 % (x, DNA_Y - 52, x, DNA_Y + 52, endlab(x, DNA_Y + 66, 'fork')), basex=x)


# Where Ctf4 sits on Pol alpha: beside it on the helicase side, at its height,
# the trimer that ties the primase to the CMG at each fork.
CTF4_W = 36.0
CTF4_DX = 18.0 + 2.0 + CTF4_W / 2.0


def inner(ident, body):
    """A declared actor inside a derived one.

    The derived layer places the outer group on its fork every frame; a frame
    table moves this inner group, which is how a factor arrives at a fork from
    off the page and leaves it again without the fork's own position changing.
    It carries no basex, because the derived layer never writes it.
    """
    return '<g id="actor-%s" class="act">%s</g>' % (ident, body)


# The fork protection complex rides the front of the CMG, above it in this
# projection: Tof1-Csm3 on the parental duplex side, Mrc1 tying the helicase
# to Pol epsilon. Mrc1 is where Mec1 places the mark Rad53 docks on.
MRC_DY, TOF_DY = 64.0, 82.0


def fork_base(side):
    """MODEL: the base x every derived fork actor is drawn at (TERMINAL)"""
    return DH_X + (-MCM_HALF if side == 'l' else MCM_HALF)


def mrc_actor(side, shake=None):
    """Mrc1 with Tof1-Csm3, riding one fork above its CMG.

    Derived like the polymerases: paintForkLayer puts it on the fork, and an
    inner group lets a frame bring it in from off the page.
    """
    x = fork_base(side)
    toward = 1.0 if side == 'r' else -1.0
    # The mark Mec1 places on Mrc1 in hydroxyurea, hidden unless a close-up
    # frame shows it; Rad53 docks on it.
    body = (protein(x + toward * 8.0, DNA_Y - TOF_DY, 50, 'Tof1-Csm3', 'tof1', h=15)
            + protein(x, DNA_Y - MRC_DY, 34, 'Mrc1', 'mrc1', h=15)
            + fx('fx-mrcp-' + side, phos_star(x - toward * 20.0, DNA_Y - MRC_DY - 2.0)))
    body = (shake or (lambda b: b))(body)
    return actor('mrc-' + side, inner('mrcin-' + side, body), basex=x)


DNTP_N = 10                       # particles in one stream
DNTP_SPAN = 320.0                 # how far a stream runs, from off the page to its polymerase
DNTP_TIER = {0: 'a', 3: 'b', 6: 'b'}   # which particles each flow level keeps


def dntp_actor(side):
    """The dNTP streams feeding one fork: one to Pol epsilon, one to Pol alpha.

    Each stream is a column of particles running from off the page to its
    polymerase; the stylesheet moves them, and the class on the column sets
    how many flow: all of them at a normal pool, one in three when Rad53 has
    raised RNR in hydroxyurea, one in ten in hydroxyurea alone. Each column
    sits in its own inner group, so a frame can slide it in when synthesis
    starts and out when the fork stops.
    """
    x = fork_base(side)
    pe_x = x - 40.0 if side == 'l' else x + 40.0
    pa_x = x + 70.0 if side == 'l' else x - 70.0
    pe_above, pa_above = side == 'l', side == 'r'
    out = []
    for name, px_, above in (('dntpe', pe_x, pe_above), ('dntpa', pa_x, pa_above)):
        end = DNA_Y - 46 - 12 if above else DNA_Y + 42 + 12
        start = end - DNTP_SPAN if above else end + DNTP_SPAN
        parts = []
        for k in range(DNTP_N):
            y = start + (end - start) * k / float(DNTP_N)
            parts.append('<circle class="dnp t%s" cx="%.1f" cy="%.1f" r="2.4" style="animation-delay:-%.2fs"/>'
                         % (DNTP_TIER.get(k, 'c'), px_ + (2.0 if k % 2 else -2.0), start,
                            1.6 * k / DNTP_N))
        lab = ''
        out.append(inner('%sin-%s' % (name, side),
                         '<g class="dntp flow-full %s" data-span="%.1f">%s%s</g>'
                         % ('down' if above else 'up', DNTP_SPAN, ''.join(parts), lab)))
    return actor('dntp-' + side, ''.join(out), basex=x)


def fork_actors(step11=False, side=None, vib=False, bob1=()):
    """The machinery at the forks: CMG, fork mark, RPA, Pol epsilon, and Pol alpha
    with Ctf4.

    Step 11 draws both forks; the close-up's elongation panels draw one (side).
    The same functions at the same coordinates, so a fork looks the same in
    the step panel and in the close-up. vib wraps each glyph in a group the
    close-up shakes while the fork moves.
    """
    sides = ('l', 'r') if side is None else (side,)
    out = [orc_actor(behind=True)] if step11 else []
    shake = (lambda body: '<g class="vib">%s</g>' % body) if vib else (lambda body: body)
    for sd in sides:
        # RPA first, so the replisome is drawn over the single strand it coats.
        out.append(rpa_actor(sd, shake))
        b, f = cmg_actor(sd, bob1=bob1)
        out.append((vibrate(b), vibrate(f)) if vib else (b, f))
        out.append(fork_mark(sd))
        out.append(dntp_actor(sd))
        out.append(mrc_actor(sd, shake))
        out.append(pol_actor('pole', sd, 'Pol eps', 'pole', above=(sd == 'l'), shake=shake))
        out.append(pol_actor('pola', sd, 'Pol alpha', 'pola', above=(sd == 'r'), shake=shake))
    if step11:
        # The burst step 10 ended on, so it fades on this panel's first move.
        out.append(fx('fx-atph', nucleotide_burst(NTP_X, NTP_Y, 'ATP hydrolysis'), pending=False))
        # Present while no polymerase has reached the forks: the stylesheet then
        # hides every daughter strand, so the panel opens on the bare unwound
        # strands step 10 ended on and synthesis begins once Pol alpha and Pol
        # epsilon are in place.
        out.append(fx('fx-nosynth', '<g class="nosynth"></g>'))
    return out


def vibrate(actor_markup):
    """VIEW: put an actor's contents inside a .vib group (TERMINAL)"""
    head = actor_markup.index('>') + 1
    return actor_markup[:head] + '<g class="vib">' + actor_markup[head:-4] + '</g></g>'


def pol_actor(name, side, label, cls, above=True, shake=None):
    """One polymerase on one fork.

    above puts the glyph on the strand it copies. Each fork carries two: the
    leading template is the top strand on the left of the origin and the
    bottom strand on the right, because a polymerase reads its template 3' to
    5' and the two forks travel in opposite directions. One polymerase per fork
    would have drawn each fork missing half of its own machinery.
    """
    x = DH_X + (-110 if side == 'l' else 110)
    y = DNA_Y - 46 if above else DNA_Y + 42
    body = polymerase(x, y, label, cls)
    if name == 'pola':
        # Ctf4 rides Pol alpha, on the helicase side and further off the DNA.
        toward = 1.0 if side == 'r' else -1.0
        body = protein(x + toward * CTF4_DX, y, CTF4_W, 'Ctf4', 'ctf4', h=18) + body
    body = (shake or (lambda b: b))(body)
    return actor('%s-%s' % (name, side), inner('%sin-%s' % (name, side), body), basex=x)


# ===========================================================================
# PANEL FUNCTIONS: THE MAIN LINE
# ===========================================================================

def p_step01():
    """ORC binds the ARS.

    The ARS is naked at rest, and that is the fix for a panel that used to draw
    two initiators at once. The searching ORC lives inside fx-search and the
    engaged one is derived from the complex track, so declaring the track
    occupied here put both on the page in the same frame. It also declared a
    bend before there was anything to bend the DNA, since the transient kink is
    ORC's. Frames 1 and 2 of the table already had the track naked and were
    right; frame 0 did not and was not.

    The status indicator follows: Specification reads naked ARS and Licensing
    reads no ORC yet, until the frame the initiator seats.
    """
    t = tracks_default()
    br = bracket(cx(lin(ARS_A)), cx(lin(ARS_B)) + CW, 226, 'ARS, A element and B elements')
    bk, g = split([
        orc_actor(),
        actor('search', fx('fx-search', orc_ring(cx(4), ORC_Y, fits=False), pending=False),
              basex=float(cx(4))),
        fx('fx-searchlab', polelab(180, 70, 'one-dimensional linear search'), pending=False),
        fx('fx-kinklab', polelab(ARS_X, 206, 'ORC alone bends the DNA transiently'),
           pending=False)])
    return stage('step01', t, glyphs=g, back=bk, brackets=br,
                 note='The searching initiator and the engaged initiator are separate '
                      'elements. Engagement is a change of state at the ARS, not a move.')


def p_step02():
    """Cdc6 closes the ring."""
    t = tracks_default()
    set_cpx(t, ARS_A, ARS_B, 'orc')
    set_kink(t, ARS_A, ARS_B, 'kink-fixed')
    nx, ny = orc_notch(ARS_X, ORC_Y)
    bk, g = split([orc_actor(cdc6=True, cdc6_pending=True),
                   actor('cdc6in', fx('fx-cdc6in', cdc6_wedge(nx, ny, fits=False),
                                      pending=False), basex=nx),
                   polelab(ARS_X, 86, 'Cdc6 seats in the Orc1-Orc2 notch')])
    return stage('step02', t, glyphs=g, back=bk,
                 note='The triangle base is scalloped to the Orc1 and Orc2 circles, so it '
                      'seats in that notch and nowhere else. The bend stops relaxing once '
                      'it does.')


# The two hexamers arrive out of the nucleoplasm rather than sliding along the
# chromosome, so their frames sample one arm of a parabola with its vertex at
# the landing site: steep at the top, flat where it sets down. Each arriving
# actor is drawn at its landing site and the frames carry it back up the curve,
# which is why the two descents can be the same three numbers. The second
# arrival is then the first one translated right by exactly one hexamer,
# because the claim is that the same route runs twice.
HEPT_X, HEPT2_X = OCCM_X, DH_X + MCM_HALF


def p_step03():
    """Cdt1 delivers Mcm2-7, the first hexamer loads, Cdc6 and Cdt1 leave."""
    t = tracks_default()
    set_cpx(t, ARS_A, ARS_B, 'orc')
    set_kink(t, ARS_A, ARS_B, 'kink-fixed')
    hb, hf = mcm_hexamer(HEPT_X, DNA_Y, gate='open', fits=('cdt1',))
    rod = cdt1_arm(HEPT_X - 84.0, DNA_Y - 24.0, *mcm_tip(HEPT_X, DNA_Y, '3'),
                   fits=('mcm3',), bend=0.0)
    bk, g = split([
        orc_actor(cdc6=True), occm_actor(), mcm1_actor(),
        (actor('hept-b', fx('fx-heptin-b', hb, pending=False), basex=HEPT_X),
         actor('hept', fx('fx-heptin', hf + rod, pending=False), basex=HEPT_X)),
        actor('cdc6out', fx('fx-cdc6out', cdc6_wedge(250.0, DNA_Y - 74, fits=False)),
              basex=250.0),
        actor('cdt1out', fx('fx-cdt1out',
                            cdt1_arm(430.0, DNA_Y + 38, 430.0 + CDT1_FREE, DNA_Y + 44,
                                     fits=(), bend=0.0)), basex=430.0),
        fx('fx-openlab', polelab(180, 60, 'the ring arrives open at the Mcm2-Mcm5 gate',
                                 max_w=250), pending=False),
        polelab(250, 250, 'Cdc6 leaves before Cdt1, and the gate closes as it goes',
                max_w=300)])
    return stage('step03', t, glyphs=g, back=bk, cdc6=True,
                 note='Cdt1 carries the hexamer in as a straight rod and bows once it is '
                      'seated between Cdc6 and Mcm3. The bow is its tension while '
                      'it levers Cdc6 out of the notch, and the two ejection offsets carry '
                      'opposite signs because Cdc6 leaves first.')


def p_step04():
    """Cdc6 rebinds ORC before the second load."""
    t = tracks_default()
    set_cpx(t, ARS_A, ARS_B, 'orc')
    set_cpx(t, H1[0], H1[1], 'mcm1')
    set_kink(t, ARS_A, ARS_B, 'kink-fixed')
    set_gate(t, H1[0], H1[1], 'gate-closed')
    nx, ny = orc_notch(ARS_X, ORC_Y)
    bk, g = split([
        orc_actor(cdc6=True, cdc6_pending=True), mcm1_actor(),
        actor('cdc6in', fx('fx-cdc6in', cdc6_wedge(nx, ny, fits=False), pending=False),
              basex=nx),
        polelab(210, 236, 'the notch sits empty until Cdc6 comes back', max_w=250)])
    return stage('step04', t, glyphs=g, back=bk,
                 note='The route that loaded the first hexamer needs Cdc6 in the notch, and '
                      'Cdc6 left with it. An unfilled socket is how the panel says the '
                      'origin cannot load again until that is put right.')


def p_step05():
    """Cdt1 delivers the second hexamer, licensed origin.

    ORC is present here at rest and the frame table takes it to fading on the
    frame fx-atp arrives. That burst is Cdc6 ATP hydrolysis, which releases the
    loaded double hexamer from ORC, so the cause of the dim is on the page in
    the frame the dim happens. Cdc6 leaves in the same frame. ORC ATP
    hydrolysis, which resets the initiator, is reported in the caption and not
    drawn.
    """
    t = tracks_default()
    set_cpx(t, ARS_A, ARS_B, 'orc')
    set_cpx(t, H1[0], H1[1], 'mcm1')
    set_kink(t, ARS_A, ARS_B, 'kink-fixed')
    set_gate(t, H1[0], H1[1], 'gate-closed')
    sb, sf = mcm_hexamer(HEPT2_X, DNA_Y, 'right', gate='open', fits=('cdt1',))
    rod = cdt1_arm(HEPT2_X + 84.0, DNA_Y - 24.0,
                   *mcm_tip(HEPT2_X, DNA_Y, '3', 'right'), fits=('mcm3',), bend=0.0)
    fxp, fyp = cdc6_flank(*orc_notch(ARS_X, ORC_Y))
    mx2, my2 = mcm_tip(DH_X + MCM_HALF, DNA_Y, '3', 'right', MCM_DH_SKEW)
    bk, g = split([
        orc_actor(cdc6=True), mcm1_actor(), dh_actor(nsd='seated'),
        (actor('mcm-2-b', fx('fx-mcm2in-b', sb, pending=False), basex=HEPT2_X),
         actor('mcm-2', fx('fx-mcm2in', sf + rod, pending=False), basex=HEPT2_X)),
        # The arm asserts its Cdc6 seat and no more. Where it meets the second
        # hexamer is the contested part of this route, so it reaches without a
        # fit point rather than claiming a contact the panel is arguing about.
        fx('fx-cdt1pry', cdt1_arm(fxp, fyp, mx2, my2, fits=('cdc6',), bend=-143.0),
           pending=False),
        actor('cdc6out2', fx('fx-cdc6out2', cdc6_wedge(250.0, DNA_Y - 74, fits=False)),
              basex=250.0),
        actor('cdt1out2', fx('fx-cdt1out2',
                             cdt1_arm(430.0, DNA_Y + 38, 430.0 + CDT1_FREE, DNA_Y + 44,
                                      fits=(), bend=0.0)), basex=430.0),
        fx('fx-atp', nucleotide_burst(ARS_X - 52, ORC_Y - 40)),
        bracket(cx(lin(DH[0])), cx(lin(DH[1])) + CW, 226, 'double hexamer, salt stable')])
    return stage('step05', t, glyphs=g, back=bk, cdc6=True,
                 note='The second delivery is the first one run again and shifted right by '
                      'one hexamer. Cdt1 arches over the hexamer already loaded to reach the '
                      'Mcm3 point of the arriving one. The pair closes with the Mcm4 NSD '
                      'seated across the seam, which is the state DDK acts on next.')


def licensed_tracks(nsd):
    """Tracks for a licensed origin whose pair has not fired, with its NSD.

    Shared by every panel from step06 to step09 and by the perturbations that
    act on a loaded pair, so the only thing those panels declare differently at
    rest is the NSD value they name.
    """
    t = tracks_default()
    set_cpx(t, ARS_A, ARS_B, 'orc')
    set_cpx_state(t, ARS_A, ARS_B, 'fading')
    set_cpx(t, DH[0], DH[1], 'mcm2')
    set_kink(t, ARS_A, ARS_B, 'kink-fixed')
    set_gate(t, DH[0], DH[1], 'gate-closed')
    set_nsd(t, DH[0], DH[1], 'nsd-' + nsd)
    return t


DDK_X, DDK_Y = 600.0, 62.0     # where the kinase waits before it docks

# Where the nucleotide burst sits in the firing panels: above and left of the
# pair, clear of ORC below it, of Mcm10 over the seam and of the Dpb11 module
# on its way in, with room under it for the label that names the event.
NTP_X, NTP_Y = 300.0, 60.0


# Where DDK sits once it has docked over the seam. The frame table moves it there
# from DDK_X, so the offset it gives on the docking frames is DH_X - DDK_X.
DDK_DOCK = (DH_X, DDK_Y)

# The marks DDK places in step 6 that its two arrows end on, one per substrate.
# The Mcm6 arrow drops straight to the Mcm6 mark of the right hexamer, which
# nothing stands in front of. The Mcm4 mark of the left hexamer sits directly
# under the left Mcm6 mark, so that arrow leaves the burst on its lower left and
# bends in to the Mcm4 mark from the side. DDK_MCM4_CTRL is the bend.
DDK_MCM4_CTRL = (406.0, 120.0)


def ddk_marks():
    """MODEL: the left Mcm4 mark and the right Mcm6 mark (TERMINAL).

    The same placement mcm_phos_marks gives them, so the arrows follow the
    stars if the hexamer is resized.
    """
    lx, ly = mcm_tooth(DH_X - MCM_HALF, DNA_Y, '4', 'left', -MCM_DH_SKEW)
    rx, ry = mcm_tooth(DH_X + MCM_HALF, DNA_Y, '6', 'right', MCM_DH_SKEW)
    return {'4': (lx - 12.0, ly - 13.0), '6': (rx + 12.0, ry - 13.0)}


def ddk_arrows():
    """The two phosphorylation arrows of step 6, each in its own wrapper.

    Both are emitted hidden and shown on the one frame the tail marks arrive.
    """
    m = ddk_marks()
    t4, h4 = kin_ends(DDK_DOCK, m['4'], ctrl=DDK_MCM4_CTRL)
    t6, h6 = kin_ends(DDK_DOCK, m['6'])
    return (fx('fx-kin-ddk-4', kin_arrow(t4[0], t4[1], h4[0], h4[1], ctrl=DDK_MCM4_CTRL))
            + fx('fx-kin-ddk-6', kin_arrow(t6[0], t6[1], h6[0], h6[1])))


def p_step06():
    """DDK docks across the seam, Dbf4 displaces the NSD, Cdc7 marks the tails.

    The pair is loaded with the NSD seated and the frame table takes it to
    displaced in the frame the kinase lands, one frame before the marks. That
    order is the claim: displacement comes with Dbf4 binding, and the marks
    follow from the kinase it brings. Only the Mcm4 and Mcm6 marks land here;
    the Mcm2 marks wait for Sld3 in step 7. The frame the marks arrive also
    carries one phosphorylation arrow per substrate, from DDK to a mark on Mcm4
    and to a mark on Mcm6.
    """
    t = licensed_tracks('seated')
    bk, g = split([orc_actor(behind=True),
                   dh_actor(phos=True, phos_pending=True, nsd='seated'),
                   actor('ddk', ddk_glyph(DDK_X, DDK_Y), basex=DDK_X),
                   ddk_arrows()])
    g += polelab(200, 78, 'composite Mcm2-Mcm4 interface across the seam', max_w=260)
    g += fx('fx-nsdlab', polelab(230, 240, 'Dbf4 displaces the NSD from its seat',
                                 max_w=300))
    return stage('step06', t, glyphs=g, back=bk,
                 note='DDK acts on a double hexamer, because the interface only exists '
                      'across the seam. The NSD leaves its seat in the frame the kinase lands '
                      'and the marks follow in the next, with yellow arrows from the kinase. '
                      'ORC is drawn dim from here on: still bound at the ARS, but nothing '
                      'that follows runs through it.')


def p_step07(bob1=(), key=None):
    """Sld3-Sld7 clasps the pair, reads the NSD mark and partly seats Cdc45.

    The Mcm2 marks are emitted hidden and the frame table brings them in with
    Cdc45, after the clasp has seated, because in vivo DDK phosphorylation of
    Mcm2 depends on Sld3. The two arrive in one frame because no measurement
    orders them. Cdc45 arrives partly seated, on Mcm5 and tilted off Mcm2, and
    the pair offers the Mcm5 seats it takes.
    """
    t = licensed_tracks('displaced')
    bk, g = split([
        orc_actor(behind=True),
        # The clasp goes in before the pair so the NSD mark is drawn over the
        # cleft that takes it. A cleft is a hole and what fills it belongs on top.
        sld_actor(fits=True, nsd_fit=True, cdc45=True, cdc45_pending=True),
        dh_actor(phos=True, phos_pending=False, fits=('sld3', 'cdc45p'), bob1=bob1, nsd='displaced',
                 mcm2p='pending'),
        polelab(180, 66, 'the clasp is cut to the bare pair and its cleft to the NSD mark',
                max_w=300),
        polelab(190, 240, 'one arm to each hexamer, Cdc45 partly seated on Mcm5',
                max_w=300)])
    return stage(key or 'step07', t, glyphs=g, back=bk, phos=True,
                 note='Sld3 and Sld7 are drawn as one clasp taking the pair from underneath. '
                      'Its floor is cut from the profile the hexamers are drawn with, and one '
                      'star cleft in it takes the mark on the displaced NSD, so the clasp '
                      'reads the mark and rests on the pair in one fit. The seated NSD would '
                      'stand where that floor goes. Cdc45 rides the arms partly seated at the '
                      'Mcm2-Mcm5 gate, on Mcm5 and tilted off Mcm2, until GINS completes '
                      'the seat.')


# Where Sld2 waits in the nucleoplasm to be marked. It sits as close to the pair
# as the resting kinase allows, so a figure cropped to the pair keeps it in
# frame.
SLD2_FREE_X, SLD2_FREE_Y = 230.0, 68.0

# Where S-CDK rests, and the offsets the frame table gives it on the frame each
# mark arrives. The kinase travels to each substrate and stops a phosphorylation
# arrow's length short of it, so the transfer is drawn as an arrow from the
# burst to the mark. Duplicated in src/anim-data.js and checked by
# audit_kinase(), because an arrow drawn from where the kinase is not would be
# a transfer from nothing.
SCDK_BASE = (300.0, 56.0)
SCDK_AT_SLD2 = (12.0, -6.0)
SCDK_AT_SLD3 = (275.0, -1.0)


def scdk_arrows():
    """The two phosphorylation arrows of step 8, each in its own wrapper.

    The Sld2 mark rides the shoulder of the free arch, where adaptor_arch puts
    a carried mark, and the Sld3 mark sits on the pad of the clasp tether.
    Each arrow leaves the burst where the kinase stands on that mark's frame.
    """
    sld2 = (SLD2_FREE_X + ARCH_W / 2.0 + 7.0, SLD2_FREE_Y + 4.0)
    sld3 = sld_pad_point(DH_X, DNA_Y)
    at2 = (SCDK_BASE[0] + SCDK_AT_SLD2[0], SCDK_BASE[1] + SCDK_AT_SLD2[1])
    at3 = (SCDK_BASE[0] + SCDK_AT_SLD3[0], SCDK_BASE[1] + SCDK_AT_SLD3[1])
    t2, h2 = kin_ends(at2, sld2)
    t3, h3 = kin_ends(at3, sld3)
    return (fx('fx-kin-sld2', kin_arrow(t2[0], t2[1], h2[0], h2[1]))
            + fx('fx-kin-sld3', kin_arrow(t3[0], t3[1], h3[0], h3[1])))


def p_step08(bob1=(), key=None):
    """S-CDK marks Sld2 in the nucleoplasm and Sld3 where it sits."""
    t = licensed_tracks('displaced')
    bk, g = split([
        orc_actor(behind=True),
        # The kinase goes in before both of its substrates, so a mark is never
        # drawn under the burst. The clasp goes in before the pair, so the NSD
        # mark is drawn over the cleft that takes it.
        actor('scdk', kinase_burst(SCDK_BASE[0], SCDK_BASE[1], 'S-CDK'),
              basex=SCDK_BASE[0]),
        sld_actor(fits=True, nsd_fit=True, borne=True, borne_pending=True,
                  cdc45=True, cdc45_pending=False),
        dh_actor(phos=True, phos_pending=False, fits=('sld3', 'cdc45p'), bob1=bob1, nsd='displaced',
                 mcm2p='present'),
        actor('sld2free', adaptor_arch(SLD2_FREE_X, SLD2_FREE_Y, 'Sld2', clefts=0, borne=1,
                                       bornefit='fx-sld2p', borne_pending=True),
              basex=SLD2_FREE_X),
        arrow(404, 76, 462, 96, 'no fixed order with DDK', key='step08', proposed=True),
        scdk_arrows()])
    return stage(key or 'step08', t, glyphs=g, back=bk, phos=True, cdc45=True,
                 note='The kinase travels to each of its two substrates, and the frame each '
                      'mark arrives carries a yellow arrow from the burst to it. '
                      'The Sld3 that S-CDK marks is the one already on the origin, because '
                      'Sld3 loads without CDK activity and CDK cannot be what put it there. '
                      'A mark a protein carries sits on its shoulder and a mark it reads '
                      'sits in a cleft, so one shape no longer says both.')


# Where Pol epsilon rides in with the free GINS bar, from the left end of that
# bar: under its right half, clear of the strand bars below and of the status
# indicator to the right.
FREE_POLE_DX, FREE_POLE_DY = 46.0, 23.0


def p_step09(bob1=(), key=None):
    """Dpb11 bridges phospho-Sld3 to Sld2 and GINS, GINS completes the Cdc45
    seat and CMGE forms.

    The nucleotide burst is emitted hidden and the frame table brings it in on
    the frame the pair splits, which is the ADP to ATP exchange that goes with
    CMG formation. Pol epsilon travels in with the free GINS bar, inside the
    same wrapper, and is drawn with the GINS of each CMG once the pair splits.
    """
    t = licensed_tracks('displaced')
    # Placed from the mark it takes hold of rather than set beside it, so the
    # bridge holds however the clasp is resized.
    padx, pady = sld_pad_point(DH_X, DNA_Y)
    dx, dy = padx - DPB11_SLD3_DX, pady
    gfx = dx + DPB11_GINS_DX - GINS_SEAT_DX
    gfy = dy + DPB11_H / 2.0 - GINS_SEAT_DY
    gl, gly, pl, ply = cmg_gins_pole('l')
    bk, g = split([
        orc_actor(behind=True),
        actor('dpb11', fx('fx-dpb11out', dpb11_bar(dx, dy), pending=False), basex=dx),
        actor('sld2c',
              fx('fx-sld2out',
                 adaptor_arch(dx + DPB11_SLD2_DX, dy + DPB11_H / 2.0 + 2.0, 'Sld2',
                              clefts=0, borne=1, seatfit='dpb11-sld2'), pending=False),
              basex=dx + DPB11_SLD2_DX),
        # GINS and Pol epsilon are separate actors from here, because each goes
        # to its own place on the right CMG before the pair splits: the bar
        # under the hexamer, the polymerase outboard of it.
        actor('ginsfree', fx('fx-ginsfree', gins_bar(gfx, gfy), pending=False), basex=gfx),
        actor('polefree', fx('fx-polefree',
                             polymerase(gfx + FREE_POLE_DX, gfy + FREE_POLE_DY, 'Pol eps', 'pole'),
                             pending=False), basex=gfx + FREE_POLE_DX),
        # The left hexamer's GINS and Pol epsilon, drawn where the left CMG
        # will show them, so the frames only have to bring them in.
        actor('ginsfree2', fx('fx-ginsfree2', gins_bar(gl - CMG_SPLIT_DX, gly, fits=False),
                              pending=False), basex=gl - CMG_SPLIT_DX),
        actor('polefree2', fx('fx-polefree2', polymerase(pl - CMG_SPLIT_DX, ply, 'Pol eps', 'pole'),
                              pending=False), basex=pl - CMG_SPLIT_DX),
        # The clasp goes in after Dpb11 so the mark it carries is drawn over the
        # cut that takes it. A cut is a hole and what fills it belongs on top;
        # drawn the other way round the module read as covering the contact
        # rather than making it.
        #
        # The clasp asserts its fit in the two panels where it is the subject.
        # Here it leaves before the last frame, so it claims no fit it would
        # then be holding from somewhere else. It leaves after the CMGs have
        # formed, because Sld3 is released only once the two hexamers separate.
        sld_actor(fits=False, borne=True, borne_pending=False, bridge=True,
                  cdc45=True, cdc45_pending=False, presence='fx-sldout'),
        # The pair goes in after the clasp, so the NSD mark stays over the cleft.
        dh_actor(phos=True, phos_pending=False, nsd='displaced', mcm2p='present', bob1=bob1),
        cmg_actor('l', fits=True, pole=True, bob1=bob1), cmg_actor('r', fits=True, pole=True, bob1=bob1),
        fx('fx-atpx', nucleotide_burst(NTP_X, NTP_Y, 'ADP exchanged for ATP'))])
    return stage(key or 'step09', t, glyphs=g, back=bk, phos=True,
                 note='Cdc45 opens the panel partly seated and lies flat across the Mcm2-Mcm5 '
                      'gate in the frame GINS arrives, one seal in front of the DNA and one '
                      'behind it, on the face of each hexamer that carries its gate. Pol '
                      'epsilon comes in with GINS and stays beside it, which makes each '
                      'helicase CMGE. The pair splits in that frame into two CMGs whose teeth '
                      'meet without interleaving, and Sld3 leaves after the split. Dpb11 is '
                      'drawn with all three cuts filled; the star cut on its end face takes '
                      'the S-CDK mark on Sld3.')


MCM10_Y = 92.0     # above the N faces, clear of the fork marks, which start at 104


def p_step10(bob1=(), key=None):
    """Mcm10 arrives, the origin melts from the middle and the strands extrude.

    Mcm10 is drawn over the seam, above the N-terminal faces it binds, and not
    beside the pair. It arrives before melting and fades in the frame the
    region extrudes and the two CMGs complete their separation, because it is
    released once the forks pass. The nucleotide burst arrives with melting,
    which is the ATP hydrolysis that drives further unwinding, and stays. Each
    CMG still carries Pol epsilon beside its GINS, as in step 9.
    """
    t = tracks_default()
    set_cpx(t, ARS_A, ARS_B, 'orc')
    set_cpx_state(t, ARS_A, ARS_B, 'fading')
    set_cpx(t, DH[0], DH[1], 'cmg')
    set_kink(t, ARS_A, ARS_B, 'kink-fixed')
    set_gate(t, DH[0], DH[1], 'gate-sealed')
    # ORC stays in the far layer, as in steps 6 to 9, so nothing about it
    # changes at the step boundary. The burst step 9 ended on is drawn here as
    # well, so it can fade on this panel's first move instead of vanishing at
    # the cut. Mcm10 is an actor: it comes in from above and leaves upward.
    bk, g = split([
        orc_actor(behind=True), cmg_actor('l', pole=True, bob1=bob1), cmg_actor('r', pole=True, bob1=bob1),
        fork_mark('l'), fork_mark('r'),
        actor('mcm10', protein(DH_X, MCM10_Y, 62, 'Mcm10', 'mcm10'), basex=DH_X),
        fx('fx-atpx', nucleotide_burst(NTP_X, NTP_Y, 'ADP exchanged for ATP', alt=True),
           pending=False),
        fx('fx-atph', nucleotide_burst(NTP_X, NTP_Y, 'ATP hydrolysis', alt=True))])
    return stage(key or 'step10', t, glyphs=g, back=bk,
                 note='The two CMGs enter this panel split but still facing each other. Mcm10 '
                      'arrives over their N faces, melting starts in the middle of the pair in '
                      'the next frame, and the two CMGs separate completely as the region '
                      'extrudes, which is when Mcm10 is released.')


def p_step11(bob1=(), key=None):
    """Replisome and bidirectional fork."""
    t = tracks_default()
    set_cpx(t, ARS_A, ARS_B, 'orc')
    set_cpx_state(t, ARS_A, ARS_B, 'fading')
    set_cpx(t, DH[0], DH[1], 'cmg')
    set_kink(t, ARS_A, ARS_B, 'kink-fixed')
    set_gate(t, DH[0], DH[1], 'gate-sealed')
    # The panel opens on the origin already unwound and its core already
    # copied, which is the state step10 hands over plus the first stretch of
    # new DNA. The two positions nearest each fork stay extruded, because that
    # is the single-stranded template the polymerase is working on.
    set_strand(t, 'o07', 'o12', 'extruded')
    bk, g = split(fork_actors(step11=True, bob1=bob1))
    return stage(key or 'step11', t, glyphs=g, back=bk, nascent=True,
                 note='New DNA is drawn on the substrate as a fourth strand state, so what '
                      'the polymerases do is on the page and not in this note. The leading '
                      'template is the top strand on the left of the origin and the bottom '
                      'strand on the right, which is why the two forks are mirror images. '
                      'Leading pieces appear as their own position opens; a lagging '
                      'fragment is primed where the fork is and fills backward, so bare '
                      'template is left behind each fork and the fragment in progress is '
                      'unfinished when the fork leaves the frame. '
                      'The camera is fixed and the two forks leave the frame. No camera '
                      'position frames two objects moving apart at a constant rate. ORC does '
                      'not move and does not go: it stays on the ARS while the forks travel out '
                      'past it, and it stays bound through S and G2/M, which is where the '
                      'budding yeast initiator differs from the metazoan one.')


# ===========================================================================
# PANEL FUNCTIONS: THE CONTEXT PAGE
# ===========================================================================

def p_ctxARS():
    t = tracks_default()
    br = (bracket(cx(lin(ARS_A)), cx(lin(ARS_B)) + CW, 226, 'ARS block, four positions')
          + bracket(cx(lin('o01')), cx(lin('o18')) + CW, 244, 'origin region'))
    hb, hf = mcm_hexamer(600.0, DNA_Y)
    bk, g = split([
        polelab(400, 66, 'one drawn position stands for about 22 bp'),
        (hb, hf), endlab(600, 206, 'one hexamer, three positions')])
    return stage('ctxARS', t, glyphs=g, back=bk, brackets=br,
                 note='The 22 bp block was chosen so that ORC, a hexamer, a double hexamer '
                      'and a nucleosome come out at usable relative sizes against each other.')


def p_ctxORC():
    t = tracks_default()
    bk, g = split([
        orc_ring(230.0, 148.0, cdc6=False),
        orc_ring(560.0, 148.0, cdc6=True, cdc6_pending=False),
        polelab(230, 62, 'Orc2 and Orc3 outline only: the fold without the active site'),
        polelab(560, 62, 'Cdc6 seated in the Orc1-Orc2 notch'),
        endlab(230, 226, 'open ring'), endlab(560, 226, 'closed ring')])
    return stage('ctxORC', t, glyphs=g, back=bk,
                 note='Orc1, Orc4 and Orc5 are filled, Orc2 and Orc3 are the same circle drawn '
                      'as outline, Orc6 is smaller and paler because it has no AAA+ unit. '
                      'Cdc6 is a triangle whose base alone is cut, to the two circles it '
                      'seats between.')


def p_ctxMCM():
    """Mcm2-7 anatomy. The only panel that draws no substrate.

    The subject is the subunit and the ring, so the DNA and the nucleosomes are
    not drawn: they carry no claim here and the hexamer would be read against a
    position scale that is not the point. Dropping the substrate also drops the
    status indicator, because four slots derived from tracks that are not on
    the page would be reporting on nothing.
    """
    t = tracks_default()
    ob, of = mcm_hexamer(420.0, 186.0, gate='open')
    cb, cf = mcm_hexamer(700.0, 186.0, gate='closed')
    anat = (mcm_subunit(430.0, 58.0, '4', 'front')
            + arrow(330, 92, 398, 62, 'C-terminal point', key='ctxMCM',
                    labelside='bottom')
            + arrow(542, 92, 468, 60, 'N-terminal tooth', key='ctxMCM',
                    labelside='bottom')
            + endlab(430, 26, 'one subunit: C point, AAA+ body, N tooth'))
    bk, g = split([
        mcm_ring_open(140.0, 140.0),
        (ob, of), (cb, cf),
        anat,
        polelab(140, 78, 'ring topology, six subunits'),
        endlab(420, 244, 'gate open, DNA enters the channel'),
        endlab(700, 244, 'gate closed, the ring encloses it'),
        endlab(150, 236, 'near arc Mcm2, Mcm5, Mcm3'),
        endlab(150, 250, 'far arc Mcm6, Mcm4, Mcm7')])
    return stage('ctxMCM', t, glyphs=g, back=bk, substrate_on=False,
                 note='Head-to-head contact is N face to N face, so the tooth sits on the N '
                      'end and never on the C point.', brackets='')


def dh_state(x, y, label, gate='closed', nsd='seated', phos=False, seal=False,
             mcm2p='none'):
    """One double hexamer for the legend, with its label. Returns (back, front).

    Built from the same mcm_double the model uses, so a change to the glyph
    changes the legend in the same commit. A legend drawn by hand beside the
    thing it documents is a second source of truth.
    """
    b, f = mcm_double(x, y, gate=gate, nsd=nsd, phos=phos, phos_pending=False,
                      mcm2p=mcm2p)
    if seal:
        for side, hx in (('left', x - MCM_HALF), ('right', x + MCM_HALF)):
            skew = -MCM_DH_SKEW if side == 'left' else MCM_DH_SKEW
            sx, sy = mcm_seat(hx, y, '2', side, skew)
            gx = sx + (-CDC45_W / 2.0 if side == 'left' else CDC45_W / 2.0) - GINS_W / 2.0
            piece = (cdc45_blob(sx, sy, side, fits=False)
                     + gins_bar(gx, y + 44.0, fits=False))
            if mcm_gate_face(side) == 'back':
                b += piece
            else:
                f += piece
    return b, f + endlab(x, y + (92.0 if seal else 74.0), label, max_w=240)


def p_ctxDH():
    """The double hexamer in every state the model draws it in.

    There is no open double hexamer. Both rings close on DNA before the pair
    forms, so the gate arc is never drawn broken here, and the open form
    belongs to the single hexamer legend. Drawing one anyway would assert a
    state the model never reaches.

    The state after DDK carries the Mcm4 and Mcm6 marks only, and the CMG pair
    carries the Mcm2 marks as well, because the Mcm2 marks arrive once Sld3 is
    on the pair.
    """
    t = tracks_default()
    y = 148.0
    bk, g = split([
        dh_state(160.0, y, 'as loaded: gates closed, NSD seated across the seam',
                 nsd='seated'),
        dh_state(440.0, y, 'after DDK: NSD displaced, tails marked',
                 nsd='displaced', phos=True),
        dh_state(730.0, y, 'as a CMG pair: both gates sealed', gate='sealed',
                 nsd='displaced', phos=True, seal=True, mcm2p='present'),
        endlab(440.0, 32.0, 'the teeth of one N face fill the notches of the other')])
    return stage('ctxDH', t, glyphs=g, back=bk, substrate_on=False,
                 note='Each flange is full height where it meets its neighbour and tapers '
                      'to a point at the row centre, so one N face is one triangular wave, '
                      'and two of them interlock only when offset by half a row. The two '
                      'hexamers keep that interlock in every state; what changes is the Mcm4 '
                      'NSD.')


def p_ctxCHROM():
    t = tracks_default()
    br = (bracket(cx(lin('o01')), cx(lin('o18')) + CW, 226, 'nucleosome-free region')
          + bracket(cx(1), cx(LEFT_CTX) + CW, 244, 'phased nucleosomes')
          + bracket(cx(LEFT_CTX + ORIGIN_N + 1), cx(NPOS) + CW, 244, 'phased nucleosomes'))
    g = fx('fx-phasearr',
           arrow(cx(6), 96, cx(14), 96, 'phasing', key='ctxCHROM')
           + arrow(cx(NPOS - 13), 200, cx(NPOS - 5), 200, 'phasing', key='ctxCHROM',
                   labelside='bottom'),
           pending=False)
    return stage('ctxCHROM', t, glyphs=g, brackets=br,
                 note='Nucleosomes are drawn on both sides of the origin, because the claim is '
                      'relative. Drawing them only inside the region would say the opposite.')


def reg_stage(key, chain, note, lost=(), t=None, extra=''):
    if t is None:
        t = tracks_default()
        set_cpx(t, ARS_A, ARS_B, 'orc')
        set_cpx_state(t, ARS_A, ARS_B, 'fading')
        set_cpx(t, DH[0], DH[1], 'cmg')
        set_kink(t, ARS_A, ARS_B, 'kink-fixed')
        set_gate(t, DH[0], DH[1], 'gate-sealed')
    bk, g = split([orc_actor(), cmg_actor('l'), cmg_actor('r'), extra,
                   '<g class="chain">%s</g>' % chain])
    return stage(key, t, glyphs=g, back=bk, lost=lost, note=note)


def p_regCDK():
    chain = (kinase_burst(110, 58, 'S-CDK')
             + arrow(142, 70, 250, 88, 'activates helicase', key='regCDK')
             + inhibit(110, 90, 110, 126, '')
             + endlab(180, 112, 'blocks re-licensing'))
    return reg_stage('regCDK', chain,
                     'Both edges leave the same node, which is the whole design: activation '
                     'and re-licensing cannot coexist.')


def p_regCDC6():
    chain = (kinase_burst(110, 58, 'S-CDK')
             + inhibit(110, 90, 110, 112, '')
             + protein(110, 128, 62, 'Cdc6', 'cdc6prot')
             + arrow(150, 128, 236, 128, 'SCF proteolysis', key='regCDC6')
             + protein(288, 128, 66, 'degraded', 'gonebox'))
    return reg_stage('regCDC6', chain,
                     'This panel draws proteolysis only. CDK also restricts Cdc6 through '
                     'transcription, localization and a stable Cdc6-CDK complex, which are '
                     'named in the caption and not drawn.')


def p_regMCM():
    chain = (protein(110, 58, 74, 'Mcm2-7 pool', 'mcmpool')
             + inhibit(110, 74, 110, 112, '')
             + endlab(176, 96, 'nuclear export, S')
             + protein(110, 128, 74, 'cytoplasm', 'gonebox')
             + sumo_mark(300, 58)
             + inhibit(306, 74, 306, 112, '')
             + endlab(374, 96, 'SUMO, G1')
             + protein(306, 128, 84, 'no activation', 'gonebox'))
    return reg_stage('regMCM', chain,
                     'The SUMO diamond differs from the phosphate star by shape and not by '
                     'colour, so the two survive greyscale printing.')


def p_regCDT1():
    chain = (protein(110, 58, 60, 'Cdt1', 'cdt1prot')
             + inhibit(110, 72, 110, 108, '')
             + endlab(258, 92, 'export, and a CDK block on the Orc6 contact')
             + protein(110, 126, 92, 'no Orc6 contact', 'gonebox'))
    return reg_stage('regCDT1', chain,
                     'Budding yeast restricts Cdt1 by export and by blocking its contact with '
                     'Orc6. Both are inhibitions, so both take a bar.')


# Where Rif1-PP1 sits in regRIF1 and in the Rif1-PP1 model: below the
# C-terminal end of the left hexamer, clear of the strand bars above it and of
# the free note below it. Its bar leaves its right end and reaches the Mcm4
# mark on the displaced NSD under the pair, crossing nothing drawn. It used to
# sit right of the seam; it moved so the model's bar from CST, which lies on
# the face of the left hexamer, can drop straight onto it, and the base panel
# moved with it so the two stay one picture.
RIF1_X, RIF1_Y, RIF1_W = 380.0, 240.0, 78.0


def rif1_bar_from():
    """MODEL: where the Rif1-PP1 bar leaves the box, its right end (TERMINAL)."""
    return (RIF1_X + 18.0, RIF1_Y - 4.0)


def p_regRIF1():
    """CONTROLLER: Rif1-PP1 opposes the DDK marks on a licensed pair.

    The pair is drawn as step06 leaves it once the kinase has docked and the
    marks have landed: NSD displaced, Mcm4 and Mcm6 tails marked, DDK over the
    seam at the position its frame table docks it. One element is added,
    Rif1-PP1, with a blunt bar to the Mcm4 mark on the displaced NSD. Nothing
    on the pair changes, because the panel draws two activities on one
    substrate, and whether a dephosphorylated NSD returns to its seat has not
    been tested. reg_stage draws a CMG pair, so this panel composes its own
    stage from licensed_tracks.

    Python needs the nested functions defined before the calls that use them,
    so the model and view come first and the coordination is at the bottom.
    """

    # === MODEL AND VIEW ===

    def build_state():
        """MODEL: tracks and glyph coordinates for the panel (TERMINAL)"""
        sx, sy = nsd_star_point(DH_X, DNA_Y)
        return {'tracks': licensed_tracks('displaced'),
                'ddk': (DH_X, DDK_Y),
                'box': (RIF1_X, RIF1_Y),
                'bar_from': rif1_bar_from(),
                'bar_to': (sx + 3.0, sy + PHOS_R / 2.0 + 2.0)}

    def draw_panel(state):
        """VIEW: compose the panel markup (TERMINAL)"""
        (bx, by), (x1, y1), (x2, y2) = state['box'], state['bar_from'], state['bar_to']
        bk, g = split([
            orc_actor(behind=True),
            dh_actor(phos=True, phos_pending=False, nsd='displaced'),
            ddk_glyph(state['ddk'][0], state['ddk'][1]),
            rif1_glyph(bx, by),
            inhibit(x1, y1, x2, y2)])
        return stage('regRIF1', state['tracks'], glyphs=g, back=bk, phos=True,
                     note='DDK places the marks the clasp reads, and Rif1-PP1 removes the '
                          'same marks.')

    # === COORDINATE ===

    state = build_state()
    return draw_panel(state)


def p_altDH01():
    t = tracks_default()
    set_cpx(t, ARS_A, ARS_B, 'orc')
    set_cpx(t, H1[0], H1[1], 'mcm1')
    set_kink(t, ARS_A, ARS_B, 'kink-fixed')
    set_gate(t, H1[0], H1[1], 'gate-closed')
    sb, sf = mcm_hexamer(580.0, DNA_Y, 'right', gate='open', fits=('cdt1',))
    arm = cdt1_arm(580.0 + 58.0, DNA_Y + 40.0,
                   *mcm_tip(580.0, DNA_Y, '3', 'right'), fits=('mcm3',))
    bk, g = split([
        orc_actor(cdc6=True), mcm1_actor(),
        (actor('mcm-2-b', sb, basex=580.0), actor('mcm-2', sf + arm, basex=580.0)),
        arrow(560, 80, 380, 80, 'Mcm3 C-terminus to ORC-Cdc6, both loads',
              curve=28, key='altDH01', proposed=True)])
    return stage('altDH01', t, glyphs=g, back=bk, cdc6=True,
                 note='The long curved approach is the drawn form of the geometric objection. '
                      'Loading intermediates answer it, so this route and its partner describe '
                      'two halves of one mechanism.')


def p_altDH02():
    t = tracks_default()
    set_cpx(t, ARS_A, ARS_B, 'orc')
    set_cpx(t, H1[0], H1[1], 'mcm1')
    set_kink(t, ARS_A, ARS_B, 'kink-fixed')
    set_gate(t, H1[0], H1[1], 'gate-closed')
    sb, sf = mcm_hexamer(570.0, DNA_Y, 'right', gate='open')
    bk, g = split([
        orc_actor(), mcm1_actor(),
        (actor('mcm-2-b', sb, basex=570.0), actor('mcm-2', sf, basex=570.0)),
        arrow(534, DNA_Y - 58, 476, DNA_Y - 58, 'first hexamer templates the second',
              key='altDH02', proposed=True)])
    return stage('altDH02', t, glyphs=g, back=bk,
                 note='No Cdt1 delivery node hangs under this route, which is how the account '
                      'was stated. Each ring closing with the release of its own Cdt1 argues '
                      'against that omission.')


def p_offQC():
    t = tracks_default()
    set_cpx(t, ARS_A, ARS_B, 'orc')
    set_kink(t, ARS_A, ARS_B, 'kink-fixed')
    rb, rf = mcm_hexamer(600.0, DNA_Y - 78.0, gate='open')
    bk, g = split([
        orc_actor(cdc6=True), mcm1_actor(),
        (actor('reject-b', rb, basex=600.0), actor('reject', rf, basex=600.0)),
        fx('fx-qcnote', notelab('defective hexamer ejected, gate never closed', y=226,
                                x=600, max_w=300), pending=False)])
    return stage('offQC', t, glyphs=g, back=bk, cdc6=True, lost=('licensing',),
                 note='The ejected hexamer is drawn and the licensing slot is declared lost. '
                      'An absent glyph alone would not distinguish loss from never drawn.')


def p_offATP():
    t = tracks_default()
    set_cpx(t, ARS_A, ARS_B, 'orc')
    set_kink(t, ARS_A, ARS_B, 'kink-fixed')
    hb, hf = mcm_hexamer(600.0, DNA_Y, gate='open', fits=('cdt1',))
    arm = cdt1_arm(600.0 - 78.0, DNA_Y - 34.0, *mcm_tip(600.0, DNA_Y, '3'), fits=('mcm3',))
    bk, g = split([
        orc_actor(cdc6=True),
        (actor('cdt1mcm-b', hb, basex=600.0), actor('cdt1mcm', hf + arm, basex=600.0)),
        condition_strip('fx-cond-restrict', 'Mcm2 Walker A, Mcm6 arginine finger'),
        polelab(250, 86, 'recruitment and Cdt1 release both fail')])
    return stage('offATP', t, glyphs=g, back=bk, cdc6=True, lost=('licensing',),
                 note='Two conditions appear in one panel, so the condition strip names which '
                      'frames run under the mutant.')


def p_offCDT1N():
    t = tracks_default()
    set_cpx(t, ARS_A, ARS_B, 'orc')
    set_cpx_state(t, ARS_A, ARS_B, 'fading')
    set_cpx(t, DH[0], DH[1], 'mcm2')
    set_kink(t, ARS_A, ARS_B, 'kink-fixed')
    set_gate(t, DH[0], DH[1], 'gate-closed')
    set_nsd(t, DH[0], DH[1], 'nsd-seated')
    bk, g = split([
        orc_actor(behind=True), dh_actor(nsd='seated'),
        condition_strip('fx-cond-cdt1n', 'Cdt1 N-terminal deletion'),
        polelab(250, 86, 'double hexamer loads, activation fails')])
    return stage('offCDT1N', t, glyphs=g, back=bk, lost_pending=('activation',),
                 note='The substrate is identical on both sides of the condition boundary. '
                      'That non-change is the claim, and the assertion keeps it true.')


def p_offDDK():
    """No DDK. The NSD stays seated and the clasp stops short of the pair.

    Every other fit in the model either matches or is absent. This is the one
    place two outlines are drawn against each other and do not meet, which is
    the only way a claim about access can be made on the page rather than in a
    caption. The clasp comes up to the pair and stops against the seated NSD,
    one clearance short of the floor it would take, and the panel ends there.
    The stop claims that the Sld3 engagement at the Mcm4 site cannot form while
    the NSD is seated; it does not claim that Sld3 cannot bind the pair at all,
    which is why no frame takes the clasp away. It is emitted
    without its half of the fits, so the sockets on the pair stay unfilled and
    say so, and the stop itself is asserted numerically at build time, in
    audit_nsd, rather than by the behavioural suite, which is built to fail a
    fit that does not meet.
    """
    t = licensed_tracks('seated')
    bk, g = split([
        orc_actor(behind=True),
        sld_actor(fits=False, cdc45=False),
        dh_actor(phos=False, fits=('sld3',), fits_side='both', nsd='seated'),
        condition_strip('fx-cond-ddk', 'no DDK activity'),
        fx('fx-blocklab',
           polelab(200, 240, 'the seated NSD stops the clasp short of the pair',
                   max_w=300))])
    return stage('offDDK', t, glyphs=g, back=bk, lost_pending=('activation',),
                 note='The clasp and the pair are the same objects as in step 7, so nothing '
                      'here is drawn to fail. What differs is the NSD, which stays on its seat '
                      'across the seam and stops the clasp short of the floor it would take. '
                      'The activation slot is declared lost rather than left low, because an '
                      'origin that cannot be clasped is not one that is merely waiting.')


def bypass_panel(key, nsd, label, note, mimic=False, clasp=True, extra='', bob1=()):
    """One DDK bypass, drawn at rest with no kinase on the page.

    Each bypass is an origin that reaches Sld3-Cdc45 recruitment with no DDK
    activity, so the condition strip names that and no kinase glyph is drawn.
    What the three panels disagree about is the NSD value and what carries the
    Mcm4 mark, and those are the arguments. Where the clasp is drawn it carries
    Cdc45 partly seated as in step 7, so the pair offers the Mcm5 seats. bob1
    names the subunits drawn with the bob1 tooth.
    """
    t = licensed_tracks(nsd)
    carries_mark = mimic
    parts = [orc_actor(behind=True)]
    if clasp:
        # Before the pair, so a mark on the NSD is drawn over the cleft.
        parts.append(sld_actor(fits=True, nsd_fit=carries_mark, cdc45=True,
                               cdc45_pending=False))
    parts.append(dh_actor(phos=False, fits=('sld3', 'cdc45p') if clasp else (), nsd=nsd,
                          mimic=mimic, bob1=bob1))
    parts.append(condition_strip('fx-cond-noddk', 'no DDK activity', pending=False))
    parts.append(polelab(230, 240, label, max_w=320))
    bk, g = split(parts)
    return stage(key, t, glyphs=g + extra, back=bk, cdc45=True, note=note)


def p_offMCM4N():
    return bypass_panel(
        'offMCM4N', 'absent',
        'Mcm4 NSD deleted: the clasp seats with its cleft empty',
        'No NSD and no mark. The clasp seats on the pair through its floor alone, which '
        'is this figure\'s reading of the bypass: Sld3 reaches the site the NSD would have '
        'covered, which the structures map, although Sld3 binding there has not been '
        'tested in the deletion strain.')


def p_offPHOS():
    return bypass_panel(
        'offPHOS', 'displaced',
        'Mcm4 and Mcm6 phosphomimetic: outline marks at the substituted sites',
        'Outline stars are phosphomimetic residues, drawn at the substituted sites only: '
        'the same place and the same effect without the chemistry. With no kinase, the '
        'NSD is drawn off its seat as in step 7.',
        mimic=True)


# Where the bob1 pointer label sits: above the left hexamer and clear of ORC,
# so its leader crosses one Mcm2 flange on the way to the blunted Mcm5 tooth.
BOB1_LAB_X, BOB1_LAB_Y = 392.0, 92.0


def p_offBOB1():
    """CONTROLLER: mcm5-bob1, drawn as the NSD inhibition lifted without DDK.

    In bob1 cells the step the NSD blocks proceeds without the kinase: Cdc45
    loads with DDK and CDK off, and a reconstituted system recruits Cdc45,
    Sld3, Sld7 and Sld2 to bob1 Mcm2-7 without DDK. So the NSD is drawn in its
    released form, which is the figure's picture of lost inhibition and makes
    no claim about how bob1 gets there, and the clasp seats with Cdc45 on its
    arms as in the deletion panel. The Mcm5 tooth is blunted in both hexamers,
    which marks where Pro83 lies without adding any contact to the wild-type
    panels. The tooth and the NSD sit within a few units of each other at the
    seam, so an arrow between them would be a stub; the pointer label names the
    proposed relationship instead, and the caption carries it.

    Python needs the nested functions defined before the calls that use them,
    so the model and view come first and the coordination is at the bottom.
    """

    # === MODEL AND VIEW ===

    def locate_tooth():
        """MODEL: the tip of the blunted Mcm5 tooth on the near face (TERMINAL)"""
        lx = DH_X - MCM_HALF
        tx, ty = mcm_tooth(lx, DNA_Y, '5', 'left', -MCM_DH_SKEW)
        return (tx - BOB1_BLUNT, ty - 2.0)

    def draw_panel(tip):
        """VIEW: compose the panel markup (TERMINAL)"""
        extra = (link(tip[0], tip[1], BOB1_LAB_X + 8.0, BOB1_LAB_Y + 6.0)
                 + endlab(BOB1_LAB_X, BOB1_LAB_Y, 'bob1 in Mcm5: NSD released, proposed'))
        return bypass_panel(
            'offBOB1', 'released',
            'mcm5-bob1: the NSD is released and the clasp seats',
            'The Mcm5 tooth is blunted in both hexamers, the NSD is folded off the '
            'underside with no mark on it, and the clasp seats with its cleft empty. '
            'The released NSD pictures lost inhibition; how bob1 produces it is not '
            'known.',
            clasp=True, extra=extra, bob1=('5',))

    # === COORDINATE ===

    tip = locate_tooth()
    return draw_panel(tip)


# ===========================================================================
# PANEL FUNCTIONS: FIRING MODELS FOR CST
# ---------------------------------------------------------------------------
# Every panel on the third chart is a proposal of the dissertation's, set on a
# main-line or context panel the reader has already met. Each keeps its base
# panel's tracks and the glyphs the model works on, and adds CST and, where
# the model needs it, Rad53. Four rules hold across all seven:
#
#   CST sits where the two-hybrid scores put it, on the near face of the left
#   hexamer or the left CMG, across the boundary between the Mcm2 and Mcm5
#   rows, so Stn1 and Ten1 each touch both subunits and Cdc13 touches Mcm2
#   (cst_face). It is the same strip in every model, so a reader comparing two
#   models sees the second partner change and CST stay put.
#
#   Where a model gives CST a second partner, that partner meets CST: the
#   ejected strand turns up into the gate under the Stn1 N half, and Pol alpha
#   takes the Stn1 C half, drawn apart from the N half for the purpose. DDK is
#   the one partner that cannot reach the face, because it docks above the
#   seam, and its contact is drawn as a bond line from the Stn1 N half.
#
#   CST carries no fit point, because the scores give contacts and no
#   geometry. A proposed effect is a labelled arrow with no mark on its
#   target, or, where an arrow would be a stub, a proposal on a leader.
#
#   No extra phosphate is drawn for a model that predicts more marks per tail.
#   More marks is the prediction, and a mark is the idiom for a finding.
#
# ORC is left off every one of them. Each model acts after the pair has slid
# clear of the initiator. ORC stays on the complex track, so the status
# indicator still reports it.
# ===========================================================================

# Where a CMG sits while the pair is still facing, from DH_X. Duplicated from
# half in paintForkLayer() in src/animate.js, which derives the position: the
# CMGs stand three units clear of the hexamer footprint until the region
# extrudes. A CST strip that rides a CMG is placed from this, so it lands on
# the helicase the engine draws.
CMG_FACE_DX = MCM_HALF + 3.0

# How far behind its fork the engine puts each Pol alpha. Duplicated from
# paintForkLayer() in src/animate.js, and asserted equal by the test suite.
# Seventy, not the earlier fifty-eight, so the Stn1 C half and Cdc13 fit
# between the left CMG and its Pol alpha with the Cdc13 name clear of GINS.
POLA_DX = 70.0

RAD53_R = 30.0                # the burst radius, as kinase_burst draws it


def model_dh_face():
    """MODEL: CST on the near face of the left hexamer of a pair (TERMINAL)."""
    return cst_face(DH_X - MCM_HALF, face_boundary(-MCM_DH_SKEW))


def cdc13_arc_point(lay):
    """MODEL: a point on the curved edge of Cdc13, for a leader to end on
    (TERMINAL)."""
    (x, y), sx, sy = lay['cdc13']['corner'], lay['cdc13']['sx'], lay['cdc13']['sy']
    return (x + sx * CST_R * 0.71, y + sy * CST_R * 0.71)


def model_docking_pair():
    """MODEL: the parts of a licensed pair before DDK docks, as step 6 opens (TERMINAL).

    The animated DDK-dependent models replay step 6 with CST added: the NSD
    seated, the Mcm4 and Mcm6 marks pending, DDK waiting off the pair with its
    two phosphorylation arrows hidden. The frame table docks the kinase,
    displaces the NSD and brings in the marks as step 6 does.
    """
    return [dh_actor(phos=True, phos_pending=True, nsd='seated'),
            actor('ddk', ddk_glyph(DDK_X, DDK_Y), basex=DDK_X),
            ddk_arrows()]


def model_docked_pair():
    """MODEL: the parts of a licensed pair as step 6 leaves it (TERMINAL).

    NSD displaced, the Mcm4 and Mcm6 tails marked, DDK docked over the seam at
    the height regRIF1 draws it. The two DDK-dependent models act on exactly
    this state.
    """
    return [dh_actor(phos=True, phos_pending=False, nsd='displaced'),
            ddk_glyph(DH_X, DDK_Y)]


def p_cstCONF():
    """CONTROLLER: the Mcm2-7 conformation model, DDK-dependent form.

    CST bound to Mcm2-7 shifts the ring into a conformation in which Cdc7
    phosphorylates the Mcm4 NSD more readily. The pair is the docked pair of
    step 6 and is not reshaped, because the double-hexamer structures show no
    change after DDK phosphorylation, so the conformation this model needs is
    unidentified and there is nothing to draw it from. CST lies on the face of
    the left hexamer, and the proposal is stated on a leader.

    Python needs the nested functions defined before the calls that use them,
    so the model and view come first and the coordination is at the bottom.
    """

    # === MODEL AND VIEW ===

    def build_state():
        """MODEL: tracks, the CST layout and the leader ends (TERMINAL)"""
        lay = model_dh_face()
        return {'tracks': licensed_tracks('seated'), 'cst': lay,
                'lead_from': (300.0, 84.0), 'lead_to': cdc13_arc_point(lay)}

    def draw_panel(state):
        """VIEW: compose the panel markup (TERMINAL)"""
        (x1, y1), (x2, y2) = state['lead_from'], state['lead_to']
        bk, g = split(model_docking_pair() + [
            fx('fx-cst', cst_glyph(state['cst'], ident='cst')),
            fx('fx-prop', link(x1, y1, x2, y2)
               + proposal(290.0, 66.0, 'proposed: CST bound to Mcm2-7 lets Cdc7 mark '
                                       'the NSD more readily', max_w=160.0))])
        return stage('cstCONF', state['tracks'], glyphs=g, back=bk,
                     note='CST binds before DDK docks. The pair is not reshaped: no '
                          'structure shows the conformation this model needs.')

    # === COORDINATE ===

    state = build_state()
    return draw_panel(state)


def p_cstCDC7():
    """CONTROLLER: the Cdc7-retention model.

    CST bound beside the Dbf4 anchor holds Cdc7 against the Mcm4 NSD long
    enough for the kinase to mark more sites before it leaves. CST lies on the
    face as in every model. Stn1 binds Dbf4 through the part of the protein
    Stn1 288-494 lacks, so the contact leaves the Stn1 N half. DDK docks above
    the seam and cannot reach the face, so the contact is a bond line from the
    top of the N half to the nearest spike of the burst. Rad53 is drawn with a
    blunt bar to the kinase, because under replication stress Rad53 opposes
    DDK binding at the Mcm2 docking site, which puts CST and Rad53 at the same
    step. The condition strip names the stress the excess-Stn1 phenotypes are
    seen under.

    Python needs the nested functions defined before the calls that use them,
    so the model and view come first and the coordination is at the bottom.
    """

    # === MODEL AND VIEW ===

    def build_state():
        """MODEL: tracks, CST, the bond, Rad53 and the bar ends (TERMINAL)

        The bond runs from the middle of the top of the Stn1 N half to the
        spike of the burst at 135 degrees, the one that points down at the
        left hexamer.
        """
        import math
        lay = model_dh_face()
        n = lay['stn1n']
        a = math.radians(135.0)
        rx = DH_X + 118.0
        return {'tracks': licensed_tracks('seated'), 'cst': lay,
                'bond': ((n[0] + n[2]) / 2.0, n[1],
                         DH_X + RAD53_R * math.cos(a), DDK_Y + RAD53_R * math.sin(a)),
                'rad53': (rx, DDK_Y),
                'bar_from': (rx - RAD53_R - 2.0, DDK_Y),
                'bar_to': (DH_X + RAD53_R + 3.0, DDK_Y),
                'lead_from': (352.0, 112.0), 'lead_to': cdc13_arc_point(lay)}

    def draw_panel(state):
        """VIEW: compose the panel markup (TERMINAL)"""
        (rx, ry), (x1, y1), (x2, y2) = state['rad53'], state['bar_from'], state['bar_to']
        (l1, m1), (l2, m2) = state['lead_from'], state['lead_to']
        bk, g = split(model_docking_pair() + [
            fx('fx-cst', cst_glyph(state['cst'], ident='cst')),
            fx('fx-bond', '<path class="cstbond" d="M%.1f %.1f L%.1f %.1f"/>' % state['bond']),
            fx('fx-rad53', '<g class="rad53k">%s</g>' % kinase_burst(rx, ry, 'Rad53') + inhibit(x1, y1, x2, y2)
               + endlab(rx, ry + RAD53_R + 14.0, 'opposes DDK docking')),
            fx('fx-prop', link(l1, m1, l2, m2)
               + proposal(270.0, 104.0, 'proposed: CST on Dbf4 keeps Cdc7 on the NSD '
                                        'longer', max_w=170.0)),
            condition_strip('fx-cond-stress', 'replication stress (MMS)', pending=False)])
        return stage('cstCDC7', state['tracks'], glyphs=g, back=bk,
                     note='DDK docks above the seam, so the Stn1-Dbf4 contact is a bond '
                          'line. DDK stays docked while Rad53 opposes docking.')

    # === COORDINATE ===

    state = build_state()
    return draw_panel(state)


def p_cstRIF1():
    """CONTROLLER: the Rif1-PP1 inhibition model.

    regRIF1 again, with CST on the face and a blunt bar from CST down to
    Rif1-PP1, which sits under the C-terminal end of the left hexamer. The bar
    leaves the Stn1 C half and runs straight down past the C-terminal ends of
    Mcm5 and Mcm3. It is an inhibition, so it takes the bar and not an
    arrowhead, and it carries the proposed label because the inhibition is a
    proposal. The two stn1 1-186 results that argue against this route as the
    only one are genetic, so they are in the caption and not on the drawing.

    Python needs the nested functions defined before the calls that use them,
    so the model and view come first and the coordination is at the bottom.
    """

    # === MODEL AND VIEW ===

    def build_state():
        """MODEL: tracks, Rif1-PP1, CST and both bars (TERMINAL)"""
        lay = model_dh_face()
        sx, sy = nsd_star_point(DH_X, DNA_Y)
        bx = lay['stn1c'][0] + 4.0
        return {'tracks': licensed_tracks('seated'), 'cst': lay,
                'box': (RIF1_X, RIF1_Y),
                'bar_from': rif1_bar_from(), 'bar_to': (sx + 3.0, sy + PHOS_R / 2.0 + 2.0),
                'cst_from': (bx, lay['stn1c'][3] + 1.0),
                'cst_to': (bx, RIF1_Y - 13.0)}

    def draw_panel(state):
        """VIEW: compose the panel markup (TERMINAL)"""
        (bx, by), (x1, y1), (x2, y2) = state['box'], state['bar_from'], state['bar_to']
        (x3, y3), (x4, y4) = state['cst_from'], state['cst_to']
        bk, g = split(model_docking_pair() + [
            fx('fx-rif1', rif1_glyph(bx, by) + inhibit(x1, y1, x2, y2)),
            fx('fx-cst', cst_glyph(state['cst'], ident='cst')),
            fx('fx-prop', inhibit(x3, y3, x4, y4, proposed=True)
               + _lines('arrowlab prop', x3 - 22.0, 204.0, 'proposed', 60.0, 11.0))])
        return stage('cstRIF1', state['tracks'], glyphs=g, back=bk,
                     note='CST lowers Rif1-PP1 activity in this model; the phosphatase still '
                          'opposes the same marks, and it fades as CST acts.')

    # === COORDINATE ===

    state = build_state()
    return draw_panel(state)


# Where the clasp is held in the DDK-independent conformation panel: far enough
# below the bob1 pair that the gap reads as empty, but not so far that the Sld7
# lobe runs across the complex track. The stop offDDK draws is a different
# claim: there the clasp comes up against a seated NSD that fills the gap.
CLASP_HOLD_DY = 14.0

# Rad53 in that panel: below and left of the clasp, under the curve of the
# arrow that runs from CST round the end of the pair.
BOB1_RAD53 = (300.0, 242.0)

# The two activities this form of the model needs. The Sld3-delivery activity
# is named against its arrow, left of the curve where it swings out over the
# ARS. The Mcm5-surface activity acts on the face CST already lies on, so it is
# a dagger in a white disc below Ten1, keyed in the caption; an asterisk would
# be read as the ejection mark of the panel printed beside this one.
BOB1_SLD3_LAB = (255.0, 128.0)
BOB1_MARK_DY = 8.0


def p_cstBOB1():
    """CONTROLLER: the Mcm2-7 conformation model, DDK-independent form.

    The pair is the bob1 pair of offBOB1: Mcm5 tooth blunted in both
    hexamers, NSD released and unmarked. CST lies on the face as in the
    DDK-dependent form. Under HU, Rad53 phosphorylates the Sld3 segment that
    binds Mcm4 and keeps Sld3 off the pair, and that block persists in
    mcm5-bob1 cells, so the clasp is drawn held below the pair with its two
    Cdc45 and no fit, and carries the Rad53 mark. CST then needs two
    activities. Rad53 places its mark with a phosphorylation arrow, shown on the
    one frame the mark arrives. The
    Mcm5-surface activity is a dagger below Ten1, keyed in the caption; the
    frame table brings in the clasp, then Rad53 and its mark, then CST, the
    dagger and the delivery arrow, in that order. The
    Sld3-delivery activity is an arrow that leaves the apex of Cdc13, swings out
    over the Cdc13 name and the ARS, comes in to the end of the Sld3 lobe, and
    carries its name beside the curve. The Rad53 mark rides the
    underside of the Sld3 lobe, the shoulder the vocabulary keeps for a mark a
    protein carries, so its arrow and the Sld3 arrow land on the lobe well
    apart. The last frames carry the clasp, Rad53 mark and all, up into its
    seat on the pair: the step the Sld3-delivery activity would supply. Rad53
    is the orange burst of the chromosome panel and the checkpoint close-ups.

    Python needs the nested functions defined before the calls that use them,
    so the model and view come first and the coordination is at the bottom.
    """

    # === MODEL AND VIEW ===

    def build_state():
        """MODEL: tracks, CST, the held clasp, the Rad53 mark and the arrows
        (TERMINAL)

        The Rad53 arrow is a phosphorylation arrow, from the edge of the
        burst to the edge of the star along the line between their centres.
        """
        lay = model_dh_face()
        (cx_, cy_) = lay['cdc13']['corner']
        pts = dh_bottom_profile(DH_X, DNA_Y)
        top = pts[0][1] + CLASP_HOLD_DY
        star = (pts[0][0] + 34.0, top + SLD_T + PHOS_R / 2.0)
        rad_from, rad_to = kin_ends(BOB1_RAD53, star)
        return {'tracks': licensed_tracks('released'), 'cst': lay, 'star': star,
                'rad53': BOB1_RAD53, 'rad_from': rad_from, 'rad_to': rad_to,
                'mark': ((lay['ten1'][0] + lay['ten1'][2]) / 2.0,
                         lay['ten1'][3] + BOB1_MARK_DY),
                'sld_from': (cx_ - 1.0, cy_ - CST_R + 2.0),
                'sld_ctrl': (230.0, 92.0),
                'sld_to': (pts[0][0] - 6.0, top + SLD_T / 2.0)}

    def draw_panel(state):
        """VIEW: compose the panel markup (TERMINAL)"""
        (sx, sy), (rx, ry) = state['star'], state['rad53']
        b0, f0 = sld_cradle(DH_X, DNA_Y + CLASP_HOLD_DY, fits=False, cdc45=True,
                            cdc45_pending=False)
        (a1, a2), (d1, d2) = (state['rad_from'], state['rad_to']), \
            (state['sld_from'], state['sld_to'])
        mx, my = state['mark']
        bk, g = split([
            (actor('sld3-b', b0, basex=DH_X), actor('sld3', f0, basex=DH_X)),
            dh_actor(phos=False, fits=('sld3',), nsd='released', bob1=('5',)),
            actor('rad53mark', fx('fx-rad53mark', phos_star(sx, sy, ident='rad53mark')), basex=DH_X),
            fx('fx-rad53', '<g class="rad53k">%s</g>' % kinase_burst(rx, ry, 'Rad53')),
            fx('fx-kin-rad53', kin_arrow(a1[0], a1[1], a2[0], a2[1])),
            fx('fx-cst', cst_glyph(state['cst'], ident='cst')),
            fx('fx-dagger', note_marker(mx, my, '\u2020')),
            fx('fx-prop', arrow(d1[0], d1[1], d2[0], d2[1], key='cstBOB1', ctrl=state['sld_ctrl'],
                                proposed=True)
               + proposal(BOB1_SLD3_LAB[0], BOB1_SLD3_LAB[1], 'Sld3-delivery activity',
                          max_w=120.0)),
            condition_strip('fx-cond-bob1', 'mcm5-bob1 dbf4 deletion, in HU',
                            pending=False)])
        return stage('cstBOB1', state['tracks'], glyphs=g, back=bk, cdc45=True,
                     note='This form of the model needs two activities from CST: the '
                          'dagger marks the Mcm5-surface activity.')

    # === COORDINATE ===

    state = build_state()
    return draw_panel(state)


def ejection_tracks():
    """MODEL: the tracks the two ejection panels open on (TERMINAL).

    The state step10 opens on: two CMGs facing each other over the origin,
    gates sealed, the ARS still kinked under a spent ORC.
    """
    t = tracks_default()
    set_cpx(t, ARS_A, ARS_B, 'orc')
    set_cpx_state(t, ARS_A, ARS_B, 'fading')
    set_cpx(t, DH[0], DH[1], 'cmg')
    set_kink(t, ARS_A, ARS_B, 'kink-fixed')
    set_gate(t, DH[0], DH[1], 'gate-sealed')
    return t


def ejection_parts(eject):
    """MODEL: the glyphs both ejection panels share with step10 (TERMINAL).

    eject draws the left CMG's lagging strand leaving the ring, which only the
    ssDNA-binding panel needs: it is the partner that mechanism gives CST.
    Nothing else differs from the step10 set except that ORC is left off.
    """
    return [cmg_actor('l', pole=True, eject=eject), cmg_actor('r', pole=True),
            fork_mark('l'), fork_mark('r'),
            fx('fx-mcm10', protein(DH_X, MCM10_Y, 62, 'Mcm10', 'mcm10')),
            fx('fx-atph', nucleotide_burst(NTP_X, NTP_Y, 'ATP hydrolysis'))]


def model_cmg_face():
    """MODEL: CST on the near face of the left CMG while the pair still faces
    (TERMINAL)."""
    return cst_face(DH_X - CMG_FACE_DX, face_boundary(), 'cmg')


# The proposal in both ejection panels sits under the pair, between the two
# GINS bars, where the two CMGs leave the most room.
EJ_LABEL = (440.0, 250.0)


def p_cstEJSS():
    """CONTROLLER: lagging-strand ejection, the ssDNA-binding mechanism.

    The Stn1 N-terminal OB fold binds the lagging strand where it leaves the
    gate and holds it against reannealing while the two CMGs pass. The panel
    runs step10's sequence with the ejection drawn: once the origin has melted,
    the left CMG's lagging template runs in front of its near arc and turns up
    into the gate under the Stn1 N half. CST arrives in that frame, rides the
    helicase through passage, and leaves in the frame Mcm10 does. The label and
    its leader ride with CST, so the leader still ends on it after passage.

    Python needs the nested functions defined before the calls that use them,
    so the model and view come first and the coordination is at the bottom.
    """

    # === MODEL AND VIEW ===

    def build_state():
        """MODEL: the CST layout and the leader ends (TERMINAL)"""
        lay = model_cmg_face()
        t = lay['ten1']
        return {'tracks': ejection_tracks(), 'cst': lay,
                'lead_from': ((t[0] + t[2]) / 2.0, t[3] + 1.0),
                'lead_to': (EJ_LABEL[0] - 4.0, EJ_LABEL[1] - 18.0)}

    def draw_panel(state):
        """VIEW: compose the panel markup (TERMINAL)"""
        (x1, y1), (x2, y2) = state['lead_from'], state['lead_to']
        bk, g = split(ejection_parts(True) + [
            actor('cst', fx('fx-cst', cst_glyph(state['cst'])
                            + link(x1, y1, x2, y2)
                            + proposal(EJ_LABEL[0], EJ_LABEL[1],
                                       'proposed: the Stn1 N-terminal OB fold binds the '
                                       'lagging strand where it leaves the gate',
                                       max_w=260.0)),
                  basex=DH_X - CMG_FACE_DX)])
        return stage('cstEJSS', state['tracks'], glyphs=g, back=bk,
                     note='The left CMG stands for both: the right one ejects through its '
                          'far-side gate.')

    # === COORDINATE ===

    state = build_state()
    return draw_panel(state)


def p_cstEJPR():
    """CONTROLLER: lagging-strand ejection, the protein-binding mechanism.

    The Stn1 C-terminal region binds Mcm2 and Mcm5 directly. CST lies on the
    face as in every model, and the proposal names the C half. The ejected
    strand is not drawn here: in this mechanism CST holds the subunits and not
    the strand, so the strand is not its partner. The frames are the
    ssDNA-binding panel's otherwise, so the two mechanisms differ on the page
    in the strand and in which half of Stn1 the proposal names.

    Python needs the nested functions defined before the calls that use them,
    so the model and view come first and the coordination is at the bottom.
    """

    # === MODEL AND VIEW ===

    def build_state():
        """MODEL: the CST layout and the leader ends (TERMINAL)

        The leader leaves the bottom of the Stn1 C half and slants right as it
        drops, so it clears the end of the left GINS bar.
        """
        lay = model_cmg_face()
        c = lay['stn1c']
        return {'tracks': ejection_tracks(), 'cst': lay,
                'lead_from': ((c[0] + c[2]) / 2.0, c[3] + 1.0),
                'lead_to': (EJ_LABEL[0] - 10.0, EJ_LABEL[1] - 18.0)}

    def draw_panel(state):
        """VIEW: compose the panel markup (TERMINAL)"""
        (x1, y1), (x2, y2) = state['lead_from'], state['lead_to']
        bk, g = split(ejection_parts(False) + [
            actor('cst', fx('fx-cst', cst_glyph(state['cst'])
                            + link(x1, y1, x2, y2)
                            + proposal(EJ_LABEL[0], EJ_LABEL[1],
                                       'proposed: the Stn1 C-terminal half binds Mcm2 and '
                                       'Mcm5 at the gate', max_w=260.0)),
                  basex=DH_X - CMG_FACE_DX)])
        return stage('cstEJPR', state['tracks'], glyphs=g, back=bk,
                     note='CST binds the subunits here, and the strand is left '
                          'undrawn.')

    # === COORDINATE ===

    state = build_state()
    return draw_panel(state)


def p_cstPOLA():
    """CONTROLLER: Stn1 stimulation of polymerase alpha.

    Set at the state step11 reaches in its sixth frame (frame 5): forks established
    on both sides, the core copied, single strand at each fork. The frame table
    brings in the two Pol alpha, then the Stn1 N half and Ten1 on the face, then
    the C half with Cdc13 on the polymerase, then the proposal. The Stn1 N half
    and Ten1 lie on the face of the left CMG, across the Mcm2-Mcm5 boundary, as
    in every model. The Stn1 C half binds Pol12, so it is drawn apart from the
    N half, against the left side of the left fork's Pol alpha, with Cdc13 on
    it and the dashed linker back to the N half. Cdc13 hangs below the C half,
    curve to the left, away from the hand, with its name under it, clear of the
    fork mark and GINS to its left. The placement after unwinding
    is the claim: purified proteins unwind origins and load RPA without
    polymerase alpha.

    Python needs the nested functions defined before the calls that use them,
    so the model and view come first and the coordination is at the bottom.
    """

    # === MODEL AND VIEW ===

    def build_state():
        """MODEL: tracks, the face strip, the split C half, the linker and the
        leader (TERMINAL)

        The left CMG sits on the left edge of the open run, which is cx(o01),
        and its Pol alpha POLA_DX inside that, below the axis by 42 with the
        straight side of the hand running from 10 above that to 4 below. The C
        half stands against that side, inside its span, and Cdc13 hangs from
        the C half away from the hand.
        """
        t = tracks_default()
        set_cpx(t, ARS_A, ARS_B, 'orc')
        set_cpx_state(t, ARS_A, ARS_B, 'fading')
        set_cpx(t, DH[0], DH[1], 'cmg')
        set_kink(t, ARS_A, ARS_B, 'kink-fixed')
        set_gate(t, DH[0], DH[1], 'gate-sealed')
        set_strand(t, 'o01', 'o18', 'extruded')
        set_strand(t, 'o05', 'o14', 'replicated')
        xl = cx(lin('o01'))
        lay = cst_face(xl, face_boundary(), 'cmg')
        hand_left, hand_y = xl + POLA_DX - 18.0, DNA_Y + 42.0
        ctop = hand_y - 8.0
        lay['stn1c'] = (hand_left - STN1_HW, ctop, hand_left, ctop + CST_H)
        lay['cdc13'] = {'corner': (hand_left - STN1_HW, ctop), 'sx': -1.0, 'sy': 1.0,
                        'lab': (hand_left - STN1_HW - CST_R / 2.0, ctop + CST_R + 8.0)}
        n = lay['stn1n']
        c = lay['stn1c']
        return {'tracks': t, 'cst': lay,
                'linker': (n[2] - 2.0, n[3], c[0] + 2.0, c[1]),
                'lead_from': (hand_left - STN1_HW / 2.0, ctop + CST_H + 1.0),
                'lead_to': (400.0, 236.0)}

    def draw_panel(state):
        """VIEW: compose the panel markup (TERMINAL)"""
        (x1, y1), (x2, y2) = state['lead_from'], state['lead_to']
        bk, g = split([
            cmg_actor('l'), cmg_actor('r'), fork_mark('l'), fork_mark('r'),
            rpa_actor('l'), rpa_actor('r'),
            pol_actor('pole', 'l', 'Pol eps', 'pole', above=True),
            pol_actor('pola', 'l', 'Pol alpha', 'pola', above=False),
            pol_actor('pole', 'r', 'Pol eps', 'pole', above=False),
            pol_actor('pola', 'r', 'Pol alpha', 'pola', above=True),
            fx('fx-cst', cst_glyph(state['cst'], ident='cst', pieces=('stn1n', 'ten1'))),
            fx('fx-cstc', cst_glyph(state['cst'], pieces=('cdc13', 'stn1c'), linker=state['linker'])),
            fx('fx-prop', link(x1, y1, x2, y2)
               + proposal(440.0, 250.0, 'proposed: Stn1 stimulates Pol alpha-primase once '
                                        'the origin has unwound', max_w=240.0))])
        return stage('cstPOLA', state['tracks'], glyphs=g, back=bk, nascent=True,
                     note='The Stn1 C half is drawn apart so it can reach Pol alpha.')

    # === COORDINATE ===

    state = build_state()
    return draw_panel(state)


# The combined DDK-dependent panel. Three proposals leave the one CST strip,
# each carrying the name the dissertation gives its model, in the face the
# figure keeps for proposals: an arrow to DDK, an arrow to the Mcm4 mark on the
# displaced NSD, and a bar to Rif1-PP1. Each name is set against its own line
# with no leader: left of the retention shaft, right of the conformation
# arrowhead, and left of the Rif1-PP1 bar at its middle.
DDK_RET_LAB = (366.0, 96.0)      # Cdc7-retention model
DDK_CONF_LAB = (522.0, 196.0)    # Mcm2-7 conformation model
DDK_RIF1_LAB = (336.0, 190.0)    # Rif1-PP1 inhibition model


def p_cstDDK():
    """CONTROLLER: the three DDK-dependent models on one pair.

    The docked, marked pair of step 6 with CST on the face of the left hexamer
    and Rif1-PP1 under its C-terminal end, as cstRIF1 draws them. The three
    models act on one balance, the number of phosphorylated Mcm4 sites, and
    can act at once, so one CST carries all three:

      Cdc7-retention model: an arrow from the top of the Stn1 N half to DDK,
      on the line cstCDC7 draws as the Stn1-Dbf4 bond. Here it claims an
      effect on DDK and no contact, the form of the model that needs no
      Stn1-Dbf4 contact.

      Mcm2-7 conformation model: an arrow from the bottom of Ten1 to the Mcm4
      mark on the displaced NSD, which is the mark the Rif1-PP1 bar reaches as
      well, so two of the three proposals meet on the same site.

      Rif1-PP1 inhibition model: the bar cstRIF1 draws, from the Stn1 C half
      straight down to Rif1-PP1.

    No phosphorylation arrow is drawn, because the marks are the ones step 6
    left and nothing places them in this panel. No phosphate is added for the
    prediction of more marks, as in every model.

    Python needs the nested functions defined before the calls that use them,
    so the model and view come first and the coordination is at the bottom.
    """

    # === MODEL AND VIEW ===

    def build_state():
        """MODEL: tracks, CST, and the ends of every line and leader (TERMINAL)

        The retention arrow ends on the spike of the burst at 135 degrees, the
        one that points down at the left hexamer, as the cstCDC7 bond does.
        """
        import math
        lay = model_dh_face()
        n, c, t = lay['stn1n'], lay['stn1c'], lay['ten1']
        a = math.radians(135.0)
        sx, sy = nsd_star_point(DH_X, DNA_Y)
        ret_from = ((n[0] + n[2]) / 2.0, n[1] - 1.0)
        ret_to = (DH_X + RAD53_R * math.cos(a), DDK_Y + RAD53_R * math.sin(a) + 2.0)
        conf_from = ((t[0] + t[2]) / 2.0, t[3] + 1.0)
        conf_to = (sx - 3.0, sy - PHOS_R / 2.0 - 2.0)
        bx = c[0] + 4.0
        return {'tracks': licensed_tracks('displaced'), 'cst': lay,
                'ret': (ret_from, ret_to),
                'conf': (conf_from, conf_to),
                'rif1_box': (RIF1_X, RIF1_Y),
                'rif1_bar': (rif1_bar_from(), (sx + 3.0, sy + PHOS_R / 2.0 + 2.0)),
                'cst_bar': ((bx, c[3] + 1.0), (bx, RIF1_Y - 13.0))}

    def draw_panel(state):
        """VIEW: compose the panel markup (TERMINAL)"""
        (r1, r2), (c1, c2) = state['ret'], state['conf']
        (b1, b2), (k1, k2) = state['rif1_bar'], state['cst_bar']
        bx, by = state['rif1_box']
        bk, g = split(model_docked_pair() + [
            rif1_glyph(bx, by),
            inhibit(b1[0], b1[1], b2[0], b2[1]),
            cst_glyph(state['cst'], ident='cst'),
            arrow(r1[0], r1[1], r2[0], r2[1], key='cstDDK', proposed=True),
            arrow(c1[0], c1[1], c2[0], c2[1], key='cstDDK', proposed=True),
            inhibit(k1[0], k1[1], k2[0], k2[1], proposed=True),
            proposal(DDK_RET_LAB[0], DDK_RET_LAB[1], 'Cdc7-retention model', max_w=120.0),
            proposal(DDK_CONF_LAB[0], DDK_CONF_LAB[1], 'Mcm2-7 conformation model',
                     max_w=140.0),
            proposal(DDK_RIF1_LAB[0], DDK_RIF1_LAB[1], 'Rif1-PP1 inhibition model',
                     max_w=120.0)])
        return stage('cstDDK', state['tracks'], glyphs=g, back=bk, phos=True,
                     note='One CST carries all three DDK-dependent models, which act on '
                          'the same marks and can act at once.')

    # === COORDINATE ===

    state = build_state()
    return draw_panel(state)


# The composite downstream of the Rad53 block. The state is the melted origin
# cstEJSS reaches on the frame CST is fully on. ORC, Pol epsilon, the fork
# marks and the nucleotide burst are left off, because none of them is part of
# what the three models act on. Pol alpha is drawn arriving where Pol epsilon
# sat beside the left GINS bar: it is not at the origin in this state, and the
# hourglass on the arrow to it marks the delay.
DOWN_POLA = (300.0, 200.0)
DOWN_POLA_CTRL = (380.0, 186.0)  # bows the arrow under Cdc45 and over GINS
DOWN_POLA_LAB = (300.0, 232.0)
DOWN_MARK_DY = 8.0               # the ejection asterisk, this far below Ten1


def down_tracks():
    """MODEL: the tracks of the composite (TERMINAL).

    The ejection panels' opening tracks with the whole origin melted, which is
    the state cstEJSS holds on the frame CST is fully on.
    """
    t = ejection_tracks()
    set_strand(t, DH[0], DH[1], 'melted')
    return t


def p_cstDOWN():
    """CONTROLLER: the models downstream of the Rad53 block on one CMG pair.

    Static. The two CMGs face each other over a melted origin, Mcm10 is bound,
    and the left CMG's lagging template runs outside its ring and turns up into
    the gate under the Stn1 N half, as cstEJSS draws it. CST lies joined on the
    face of the left CMG, as in every model.

    The lagging-strand ejection model is marked by an asterisk in a white disc
    just below Ten1, keyed in the caption to its two alternative mechanisms,
    ssDNA binding and protein binding. CST already touches what both act on,
    so names set beside the strip would each need a leader to reach it.

    The polymerase alpha stimulation arrow leaves the bottom of the Stn1 C half
    and runs to a Pol alpha drawn arriving. The hourglass on it says the effect
    comes once the origin has unwound. CST stays joined: drawing the C half on
    Pol alpha, as cstPOLA does, would have the C half in two places at once.

    Python needs the nested functions defined before the calls that use them,
    so the model and view come first and the coordination is at the bottom.
    """

    # === MODEL AND VIEW ===

    def build_state():
        """MODEL: CST, the strand corner, and the ends of every line (TERMINAL)

        The Pol alpha arrow bows under Cdc45 and over the left GINS bar, and
        the hourglass sits sixty percent of the way along it, clear of the
        strand bars above it and the GINS bar below it.
        """
        lay = model_cmg_face()
        c, t = lay['stn1c'], lay['ten1']
        pola_from = (c[0] + 3.0, c[3] + 1.0)
        pola_to = (DOWN_POLA[0] + 20.0, DOWN_POLA[1] - 12.0)
        f, (qx, qy) = 0.6, DOWN_POLA_CTRL
        g = 1.0 - f
        return {'tracks': down_tracks(), 'cst': lay,
                'mark': ((t[0] + t[2]) / 2.0, t[3] + DOWN_MARK_DY),
                'pola': (pola_from, pola_to),
                'hglass': (g * g * pola_from[0] + 2 * g * f * qx + f * f * pola_to[0],
                           g * g * pola_from[1] + 2 * g * f * qy + f * f * pola_to[1])}

    def draw_panel(state):
        """VIEW: compose the panel markup (TERMINAL)"""
        (a1, a2), (hx, hy), (mx, my) = state['pola'], state['hglass'], state['mark']
        bk, g = split([
            cmg_actor('l', eject='melt'), cmg_actor('r'),
            fx('fx-mcm10', protein(DH_X, MCM10_Y, 62, 'Mcm10', 'mcm10'), pending=False),
            fx('fx-pola', polymerase(DOWN_POLA[0], DOWN_POLA[1], 'Pol alpha', 'pola'),
               state='arriving'),
            cst_glyph(state['cst'], ident='cst'),
            arrow(a1[0], a1[1], a2[0], a2[1], key='cstDOWN', ctrl=DOWN_POLA_CTRL,
                  proposed=True),
            hourglass(hx, hy),
            proposal(DOWN_POLA_LAB[0], DOWN_POLA_LAB[1], 'polymerase alpha stimulation',
                     max_w=150.0),
            note_marker(mx, my, '*')])
        return stage('cstDOWN', state['tracks'], glyphs=g, back=bk,
                     note='The asterisk marks the lagging-strand ejection model; polymerase '
                          'alpha stimulation comes after the origin unwinds.')

    # === COORDINATE ===

    state = build_state()
    return draw_panel(state)


PANEL_FNS = {
    'step01': p_step01, 'step02': p_step02, 'step03': p_step03, 'step04': p_step04,
    'step05': p_step05, 'step06': p_step06, 'step07': p_step07, 'step08': p_step08,
    'step09': p_step09, 'step10': p_step10, 'step11': p_step11,
    'ctxARS': p_ctxARS, 'ctxORC': p_ctxORC, 'ctxMCM': p_ctxMCM, 'ctxDH': p_ctxDH,
    'ctxCHROM': p_ctxCHROM,
    'regCDK': p_regCDK, 'regCDC6': p_regCDC6, 'regMCM': p_regMCM, 'regCDT1': p_regCDT1,
    'regRIF1': p_regRIF1,
    'altDH01': p_altDH01, 'altDH02': p_altDH02,
    'offQC': p_offQC, 'offATP': p_offATP, 'offCDT1N': p_offCDT1N, 'offDDK': p_offDDK,
    'offMCM4N': p_offMCM4N, 'offPHOS': p_offPHOS, 'offBOB1': p_offBOB1,
    'cstDDK': p_cstDDK, 'cstCONF': p_cstCONF, 'cstCDC7': p_cstCDC7,
    'cstRIF1': p_cstRIF1,
    'cstBOB1': p_cstBOB1, 'cstDOWN': p_cstDOWN, 'cstEJSS': p_cstEJSS,
    'cstEJPR': p_cstEJPR, 'cstPOLA': p_cstPOLA,
}

# ===========================================================================
# CHROMOSOME VIEW
# ---------------------------------------------------------------------------
# The fourth tab draws the whole model chromosome through one cell cycle in
# one live panel. The page computes each run itself (src/chrom-rule.js, the
# single source of truth for the biology) and builds its frames
# (src/chrom-frames.js), so the reader can pick a genotype, switch bob1 and
# draw a new random run. This generator draws the panel once, holding every
# object any run can show, and writes the geometry it used to
# src/chrom-geom.js so the frames place things to match. The engine needed one
# addition, text: a frame can write the words of a text element.
#
# Three idioms carry the motion with translations only.
#   Copied DNA. Each side of each origin owns a two-bar strip reaching to the
#   chromosome end it faces, drawn just behind the origin inside a fixed clip.
#   The frames slide the strip out only as far as its fork travels, so the
#   copied stretch grows behind the fork; two strips that meet overlap in the
#   same grey.
#   Mark meters. The fill is a full-height bar drawn below the meter inside the
#   meter's clip, slid up by the share of the threshold reached.
#   Firing factors. Two bundles rest in a tray, travel to the origin that takes
#   them and return when the schedule frees them.
#   DDK and Rif1-PP1 copies. Each copy rests in its reservoir and moves to a
#   dock slot beside an origin's meter for every marking segment that deals it
#   there, so the reader sees DDK concentrate on the origins that are left.
#
# One offset rule serves the strips and the fork marks: offset = x_now - x_origin,
# because both are drawn at the origin with their far end hidden.
#
# The markup is the state before anything has happened; the frames of every
# run write the complete state, so a run never inherits another's.
# ===========================================================================

CHR_X0, CHR_X1, CHR_KB = 40.0, 840.0, 240.0
CHR_DNA_Y = 176.0
CHR_BAR_H = 6.0
CHR_STRAND_K = 0.36          # step-panel substrate proportions at chromosome scale
CHR_SIS_H = 4.0              # one sister bar in a copied stretch
CHR_SIS_GAP = 5.0            # from the DNA axis to each sister bar's inner edge
CHR_METER_TOP, CHR_METER_H, CHR_METER_W = 100.0, 44.0, 8.0
CHR_HEX_W, CHR_HEX_H = 10.0, 14.0   # one hexamer of the mini double hexamer
CHR_CLOCK_Y, CHR_CLOCK_H = 14.0, 14.0
CHR_BANDS = [('late M to G1', 'g1', 40.0, 160.0), ('G1/S', 'g1s', 160.0, 200.0),
             ('S', 's', 200.0, 720.0), ('G2 to M', 'm', 720.0, 840.0)]
CHR_S_X0, CHR_S_X1 = 200.0, 720.0
CHR_S_MAX = 36.0             # minutes of S the clock strip shows at rest; a longer run rescales it
CHR_TICKS = [0.0, 0.25, 0.5, 0.75, 1.0]   # tick positions as shares of the S band
CHR_PLAYHEAD_X = 50.0        # where the playhead is drawn at rest
CHR_LABEL_Y, CHR_LABEL2_Y, CHR_LABEL3_Y = 206.0, 218.0, 232.0   # names, origin states, telomere states
CHR_FPS = 2.0

# Miniatures. Every token on these panels is the output of the glyph function
# the origin panels draw it with, cleaned and scaled, so a change to a glyph
# reaches both views and the inset will show the same shapes enlarged. The
# scales are set by the tightest spot each kind of glyph has to fit.
CHR_MINI = 0.25              # ORC, the pair, DDK, a CMG
CHR_MINI_BOX = 0.35          # the labelled boxes: Ctf19 complex, Fkh1/2, Rif1-PP1
CHR_MINI_TEL = 0.22          # the telomere figure's Rap1 units
CHR_ORC_GAP = (DH_X - ARS_X) * CHR_MINI   # ORC to its pair, as drawn in the origin panels
CHR_COPY_DDK = 0.15          # one DDK copy, in a reservoir or docked at an origin
CHR_COPY_RIF = 0.2           # one Rif1-PP1 copy
CHR_DDK_CELL, CHR_DDK_COLS = 10.0, 3            # dock grid for DDK at an origin
CHR_RIF_CELL_W, CHR_RIF_CELL_H, CHR_RIF_COLS = 13.0, 8.0, 2   # dock grid for Rif1-PP1
CHR_DOCK_TOP = 105.0         # centre of a dock's first row, beside the meter
CHR_COPY_RAD53 = 0.22        # the Rad53 kinase in the header
CHR_RAD53_X, CHR_RAD53_Y = 556.0, 55.0
CHR_SIG_X0, CHR_SIG_X1, CHR_SIG_Y, CHR_SIG_H = 468.0, 526.0, 52.0, 7.0   # Mec1 signal gauge
CHR_DNTP_X0, CHR_DNTP_X1, CHR_DNTP_Y, CHR_DNTP_H = 468.0, 526.0, 72.0, 7.0
CHR_OUT_X, CHR_OUT_Y, CHR_OUT_DY = 575.0, 48.0, 9.0   # the four outputs, one per line
CHR_COPY_RPA = 0.4           # one RPA wedge on the single-stranded DNA behind a fork
CHR_RPA_TRAIL, CHR_RPA_STEP = 9.0, 9.0   # first wedge behind the fork, and the spacing
CHR_COPY_TOKEN = 0.6         # one signal token, an RPA wedge flying to the Mec1 gauge
CHR_EV_Y = 197.0             # the line of event words under the chromosome
CHR_KMT_TOP = 42.0           # the CEN microtubule enters under the clock strip; its pole is out of frame
CHR_KT_Y = 144.0             # top of the CEN kinetochore, above the Ctf19 complex
CHR_AK_KB = 75.0             # the late artificial kinetochore site, equal to RULE.akSite
CHR_AK_KT_Y = 187.0          # top of the artificial kinetochore, under the DNA
CHR_KMT_BOT = 242.0          # its microtubule enters above the key from the other pole
CHR_KMT_GONE = 160.0         # how far a released microtubule retracts out of its clip
CHR_SPL_X0, CHR_SPL_Y, CHR_SPL_H = 48.0, 254.0, 6.0  # the spindle drawing: inner edge of the left pole, top, bundle height
CHR_SPL_UM = 18.0            # drawing units per um; the drawing runs to 10 um
CHR_SIS_SEG_KB = 5.0         # one segment of a sister chromatid in anaphase
CHR_ANA_DY = 20.0            # how far the centromere of each sister travels toward its pole in anaphase
CHR_KT2_Y = 184.0            # top of the sister kinetochore under the DNA, once the CEN is copied
CHR_RES_H = 3.5              # half height of a resected stretch about the DNA axis
CHR_RES_KB = 7.0             # kb each resected stretch is drawn to; at least RULE.resectReach

# The telomere view: the same live panel with the chromosome layer hidden and
# a one-origin chromosome drawn in its place (CHROM_RULE's oneOrigin run). The
# origin sits between two arms of interior DNA, drawn at a smaller scale, and
# each arm ends in a telomere drawn to length at TV_S panel units per bp from
# its junction (TV_JL, TV_JR) out to its tip. Strands are coloured by sequence
# and by age: grey for the interior, gold for the G-rich repeat strand, blue
# for the C-rich one, dark for a parental strand and light for a new one. The
# G-rich strand runs 5' to 3' toward each tip, so it is the top strand at the
# right end and the bottom strand at the left end. The parental duplex sits on
# the middle row; behind each fork the two sister duplexes sit on the rows
# above and below, sister 1 keeping the parental top strand and sister 2 the
# parental bottom strand. Every change is a clip or a group that slides.
TV_S = 0.42                  # panel units per bp of repeat
TV_MAXBP = 540               # longest end drawn; a longer one is drawn at this length
TV_JL, TV_JR = 268.0, 612.0  # junctions of the left and right repeat arrays with interior DNA
TV_ARMS = (5.0, 5.0)         # kb of interior DNA left and right of the origin; RULE.oneOrigin
TV_ORI = TV_JL + (TV_JR - TV_JL) * TV_ARMS[0] / (TV_ARMS[0] + TV_ARMS[1])
TV_Y = {'p': 162.0, 1: 134.0, 2: 190.0}   # the parental row and the two sisters' rows
TV_STRAND_H = 3.5            # one strand of a duplex
TV_INSET = 12.0              # the sisters' rows start this far behind their fork
TV_SLIDE = 40.0              # how far a replisome slides off the tip
TV_RAP1_W, TV_RAP1_H = 9.0, 5.0  # one Rap1 site
TV_RIF_SLOTS = 4             # Rif1 copies an end can be drawn holding
TV_RIF_DX = 17.0             # spacing of the Rif1 copies, from the junction outward
TV_TEXT_DY = {1: -34.0, 2: 36.0}  # an end's line of words, on its sister's outer side
TV_LAB_DX = 50.0             # a strand label's centre behind its fork
TV_RES_Y = 46.0              # top of the view's reservoirs, in the header band
TV_RIF_X = 366.0             # left edge of the free Rif1-PP1 reservoir, where the origin view keeps it
TV_TERT_X = 500.0            # centre of the telomerase reservoir
TW_CI_VIEW = '330 -100 550 412'   # a telomere workflow panel cropped to the end, for the close-up


def tv_box(x, y, w, h, label, cls):
    """VIEW: a small labelled protein box for the telomere view, centred on (x, y) (TERMINAL)

    The label is a glyph label, so two boxes that share a spot at different
    moments are not taken for overlapping words.
    """
    return ('<g class="tvprot %s"><rect class="tvbox" x="%.1f" y="%.1f" width="%.1f" height="%.1f" rx="2"/>'
            '<text class="glyphlab tvglyph" x="%.1f" y="%.1f">%s</text></g>'
            % (cls, x - w / 2.0, y - h / 2.0, w, h, x, y + 2.6, esc(label)))


# The origin close-up under C1: step-panel glyphs at CI_S, the pair at
# (CI_PX, CI_DNA_Y), a left column for the meter and the copies held.
CI_W, CI_H = 400, 300
CI_S = 0.65
CI_PX, CI_DNA_Y = 258.0, 205.0
CI_X0 = 70.0                 # where the drawn DNA starts, right of the left column
CI_METER_X, CI_METER_TOP, CI_METER_W, CI_METER_H = 12.0, 66.0, 10.0, 90.0
CI_COL_X = 54.0              # centre of the column of copies, clear of the meter
CI_DNTP_X = 31.0             # left edge of the dNTP column shown while a fork is followed
CI_FORK_OUT = 70.0           # step-panel units each CMG sits out from the pair once fired
CI_SET_DROP = 75.0           # a set that cannot come is drawn this far under the pair
CI_FX = 230.0                # where the followed fork sits in the close-up
CI_FRAG = OKAZAKI_N * CW * CI_S        # one Okazaki fragment, and the conveyor's period
CI_RUNG = CW / 2.0 * CI_S              # rung spacing, two per step-panel position
CI_NICK = NICK_W * CI_S
CI_PRIMER = PRIMER_W * CI_S
CI_LAG_GAP = 50.0            # bare lagging template between the newest fragment and the fork
# The close-up's DNA rows, in step-panel units about the axis: (dy, height, kind).
CI_ROWS_CLOSED = [(-8.0, 5.0, 'cistrand'), (-3.0, 6.0, 'rung'), (3.0, 5.0, 'cistrand')]
CI_ROWS_OPEN = [(-18.0, 5.0, 'cistrand'), (-13.0, 3.0, 'rung'), (-10.0, 4.0, 'cinew'),
                (9.0, 4.0, 'cinew'), (13.0, 3.0, 'rung'), (16.0, 5.0, 'cistrand')]




# --- shared functions: miniatures -------------------------------------------

def mini_clean(markup):
    """MODEL: a glyph's markup with everything a miniature must not carry (TERMINAL)

    Ids go, so neither the engine nor the tests take a miniature for the actor
    it copies; fit points go, because their ancestor walk ignores scale; text
    goes, because at a quarter size it is unreadable and the panel names its
    sites in its own labels.
    """
    out = re.sub(r'\s+id="[^"]*"', '', markup)
    out = re.sub(r'<circle class="fitpt"[^>]*/>', '', out)
    out = re.sub(r'<text\b[^>]*>.*?</text>', '', out, flags=re.S)
    # A glyph's own frame wrappers are static inside a miniature, so they take
    # a class the engine's reset does not visit.
    out = re.sub(r'class="fx ', 'class="mfx ', out)
    return out


def raw_box(markup):
    """MODEL: the union box of every shape in one markup string (TERMINAL)"""
    box = None
    for m in _TAG.finditer(markup):
        if m.group(1):
            continue
        b = shape_box(m.group(2), dict(_ATTR.findall(m.group(3))))
        if b is not None:
            box = b if box is None else (min(box[0], b[0]), min(box[1], b[1]),
                                         max(box[2], b[2]), max(box[3], b[3]))
    return box


def mini(markup, cx, cy, tx, ty, s, cls=''):
    """VIEW: one glyph drawn at scale s, its point (cx, cy) landing on (tx, ty) (TERMINAL)

    data-box carries the drawn extent in panel units, which is what the layout
    guard measures in place of the unscaled shapes inside.
    """
    body = mini_clean(markup)
    b = raw_box(body) or (cx, cy, cx, cy)
    box = (tx + (b[0] - cx) * s, ty + (b[1] - cy) * s,
           tx + (b[2] - cx) * s, ty + (b[3] - cy) * s)
    return ('<g class="mini %s" data-box="%.1f %.1f %.1f %.1f" '
            'transform="translate(%.2f %.2f) scale(%.3f) translate(%.2f %.2f)">%s</g>'
            % (cls, box[0], box[1], box[2], box[3], tx, ty, s, -cx, -cy, body))


def chr_orc_side(position):
    """MODEL: which side of its pair an origin's ORC sits on (TERMINAL)

    ORC sits on the centromere side. The origin panels draw it on the left of
    the pair, which is a projection and not a claim, and keeping that side for
    every origin would put the late origins' ORC on the telomere arrays and the
    centromere pair's on the centromere.
    """
    return 1.0 if position < 120.0 else -1.0


def tel_rap1_units(n, flip):
    """MODEL: n Rap1 units of the telomere figure, in its own coordinates (TERMINAL)

    Ported from rap1_array() in the telomere project: a Rap1 box on the duplex
    with Rif1 proximal and Rif2 distal on its C-terminus, and Sir2-3-4 on the
    most centromere-proximal unit. flip puts the centromere on the right, for
    the left telomere. Returns (base, rif1), so the Rif1 sockets can be shown or
    hidden with the genotype. Text is left out because the miniature drops it.
    """
    base, rif1 = [], []
    w = 76.0
    for k in range(n):
        x = 3.0 + 84.0 * k
        proximal = (k == n - 1) if flip else (k == 0)
        r1 = x + w - 14.0 if flip else x + 14.0
        r2 = x + 14.0 if flip else x + w - 14.0
        base.append('<rect class="telrap1box" x="%.1f" y="108" width="%.1f" height="24" rx="5"/>'
                    '<line class="telrct" x1="%.1f" y1="132" x2="%.1f" y2="139"/>'
                    '<circle class="telrif2" cx="%.1f" cy="97" r="12"/>'
                    % (x, w, x + w / 2.0, x + w / 2.0, r2))
        rif1.append('<circle class="telrif1" cx="%.1f" cy="97" r="12"/>' % r1)
        if proximal:
            base.append('<line class="telrct" x1="%.1f" y1="108" x2="%.1f" y2="78"/>'
                        '<rect class="telsir" x="%.1f" y="56" width="66" height="22" rx="5"/>'
                        % (x + w / 2.0, x + w / 2.0, x + w / 2.0 - 33.0))
    return ''.join(base), ''.join(rif1)




def chr_bundle_kit():
    """MODEL: one firing-factor set, assembled as step 9 assembles it (TERMINAL)

    The Sld3-Sld7 clasp as it seats under a pair at (DH_X, DNA_Y), and Dpb11
    and Sld2 where step 9 puts them: Dpb11's end face on the clasp's pad and
    Sld2 under Dpb11. Cdc45 is left out, because it leaves with the fork and
    is not reused; the origin draws its own Cdc45 when it fires. Anchored at
    the pair, so a set that lands on an origin puts its clasp exactly under
    that origin's pair.
    """
    clasp_b, clasp_f = sld_cradle(DH_X, DNA_Y, fits=False, cdc45=False)
    padx, pady = sld_pad_point(DH_X, DNA_Y)
    dx, dy = padx - DPB11_SLD3_DX, pady
    return (clasp_b + clasp_f + dpb11_bar(dx, dy, fits=False)
            + adaptor_arch(dx + DPB11_SLD2_DX, dy + DPB11_H / 2.0 + 2.0, 'Sld2', clefts=0))


def chr_tray_layout(kit):
    """MODEL: where the two sets rest in the tray, as the points their pair anchor lands on (TERMINAL)

    Returns the drawn box of one set relative to its anchor, and the two rest
    anchors, side by side and right-aligned, with the sets' tops at y 46, below
    the clock's tick labels.
    """
    b = raw_box(mini_clean(kit))
    s = CHR_MINI
    rel = ((b[0] - DH_X) * s, (b[1] - DNA_Y) * s, (b[2] - DH_X) * s, (b[3] - DNA_Y) * s)
    w = rel[2] - rel[0]
    ay = 46.0 - rel[1]
    right = CHR_X1 - 6.0
    rests = [(right - 2.0 * w - 8.0 - rel[0], ay), (right - w - rel[0], ay)]
    return rel, rests


def chr_copy_glyphs():
    """MODEL: one DDK copy and one Rif1-PP1 copy, each with the point it is centred on (TERMINAL)

    DDK is the step 6 kinase burst and Rif1-PP1 the labelled box the drain
    draws, so a copy in a reservoir or a dock is the same shape the origin
    panels use.
    """
    return ((ddk_glyph(DH_X, DDK_Y), DH_X, DDK_Y),
            (rif1_glyph(0.0, 60.0), 0.0, 60.0))


def chr_reservoir_layout(pools):
    """MODEL: the two reservoirs' boxes and the rest centre of every copy in them (TERMINAL)

    DDK sits in two rows of five, Rif1-PP1 in two rows of five (every copy the
    cell has, since shorter ends free more of them), both in the
    header band between the genotype readout and the firing-factor tray.
    Returns {'ddk': (box, centres), 'rif': (box, centres)}.
    """
    out = {}
    for kind, n, cols, cw, ch, x0, y0 in (
            ('ddk', pools['ddk_total'], 5, 11.0, 11.0, 300.0, 48.0),
            ('rif', max(pools['rif1_free'], 6), 5 if pools['rif1_free'] > 6 else 3, 14.0, 8.0, 366.0, 51.0)):
        rows = max(1, -(-n // cols))
        box = (x0, y0, x0 + cols * cw + 4.0, y0 + rows * ch + 4.0)
        centres = [(x0 + 2.0 + (k % cols + 0.5) * cw, y0 + 2.0 + (k // cols + 0.5) * ch)
                   for k in range(n)]
        out[kind] = (box, centres)
    return out


def sc_kb_global():
    """MODEL: panel units per kb on the live chromosome (TERMINAL)"""
    return (CHR_X1 - CHR_X0) / CHR_KB


def build_telomere_layer():
    """BASE CONTROLLER: the telomere view's layer of the live panel, and its geometry.

    A one-origin chromosome. Before the origin fires the parental duplex runs
    tip to tip on the middle row, with the origin's two CMGs side by side. Each
    fork is a replisome that slides out from the origin, through the end's
    repeat and off its tip; the parental duplex is clipped back to the fork,
    and the two sister duplexes are revealed behind it. The four daughter ends
    (tel-L-s1, tel-L-s2, tel-R-s1, tel-R-s2) then change in place: each strand
    is a clip that a run slides to its length, and the proteins at the end ride
    a group that moves with the tip.
    """

    # === SUB-CONTROLLERS ===

    def draw_heads():
        # VIEW: the view's two reservoirs in the header band (TERMINAL)
        # The origin side's header (DDK, the firing-factor sets, the checkpoint)
        # is hidden in this view. In its place: the free Rif1-PP1 copies, one
        # glyph per copy the ends leave free, and the telomerase copies.
        rif_glyph, rcx, rcy = chr_copy_glyphs()[1]
        out = ['<g data-feat="rif"><rect class="chrtray" x="%.1f" y="%.1f" width="%.1f" height="%.1f" rx="3"/>'
               '<text class="chrtag" x="%.1f" y="%.1f">free Rif1-PP1</text>'
               % (TV_RIF_X, TV_RES_Y, 5 * 15.0 + 4.0, 2 * 9.0 + 4.0, TV_RIF_X + (5 * 15.0 + 4.0) / 2.0,
                  TV_RES_Y + 2 * 9.0 + 13.0)]
        for c in range(10):
            out.append('<g id="fx-tvfree-%d" class="fx gone">%s</g>'
                       % (c + 1, mini(rif_glyph, rcx, rcy, TV_RIF_X + 2.0 + (c % 5 + 0.5) * 15.0,
                                      TV_RES_Y + 2.0 + (c // 5 + 0.5) * 9.0, CHR_COPY_RIF)))
        out.append('</g><g data-feat="telomerase"><rect class="chrtray" x="%.1f" y="%.1f" width="58.0" '
                   'height="%.1f" rx="3"/>' % (TV_TERT_X - 29.0, TV_RES_Y, 2 * 9.0 + 4.0))
        out.append('<g id="fx-tvtertlab" class="fx present"><text class="chrtag alt" x="%.1f" y="%.1f">'
                   'telomerase</text></g>' % (TV_TERT_X, TV_RES_Y + 2 * 9.0 + 13.0))
        out.append('<g id="fx-tvnotert" class="fx gone"><text class="chrtag alt" x="%.1f" y="%.1f">'
                   'no telomerase (est2Δ)</text></g>' % (TV_TERT_X, TV_RES_Y + 2 * 9.0 + 13.0))
        for k in (1, 2):
            out.append('<g id="fx-tvtert-%d" class="fx present">%s</g>'
                       % (k, tv_box(TV_TERT_X + (k - 1.5) * 26.0, TV_RES_Y + 11.0, 22.0, 9.0, 'TLC1', 'tvtert')))
        out.append('</g>')
        return ''.join(out)

    def draw_clips():
        # VIEW: the clips the forks move: the parental duplex outside the bubble, the sisters inside it (TERMINAL)
        # Each clip edge starts on the origin. The parental clip is two rects,
        # one ending at each fork; the bubble is two nested clips, one starting
        # behind each fork.
        big, y0, h = 1200.0, 60.0, 200.0
        return ('<clipPath id="cp-tvpar"><rect id="actor-tvparclip-l" class="act" x="%.1f" y="%.1f" width="%.1f" '
                'height="%.1f"/><rect id="actor-tvparclip-r" class="act" x="%.1f" y="%.1f" width="%.1f" '
                'height="%.1f"/></clipPath>'
                '<clipPath id="cp-tvbubl"><rect id="actor-tvbubclip-l" class="act" x="%.1f" y="%.1f" '
                'width="%.1f" height="%.1f"/></clipPath>'
                '<clipPath id="cp-tvbubr"><rect id="actor-tvbubclip-r" class="act" x="%.1f" y="%.1f" '
                'width="%.1f" height="%.1f"/></clipPath>'
                % (TV_ORI - big, y0, big, h, TV_ORI, y0, big, h,
                   TV_ORI, y0, big, h, TV_ORI - big, y0, big, h))

    def draw_row(y, ages, sites):
        # VIEW: one duplex row, interior and both ends, with each end's Rap1, Rif1 and end proteins (TERMINAL)
        # ages: the top and bottom strands' age, 'old' or 'new'. sites: the
        # left and right ends' ids. An end's G-rich strand is the top strand
        # at the right end and the bottom strand at the left end; telomerase's
        # repeats and the filled-in C-strand are new DNA whatever strand they
        # extend, so each strand carries a light piece that a run reveals.
        h = TV_STRAND_H
        maxpx = TV_MAXBP * TV_S
        rif_glyph, rcx, rcy = chr_copy_glyphs()[1]
        out = ['<rect class="tvstr I %s" x="%.1f" y="%.1f" width="%.1f" height="%.1f"/>'
               % (ages[0], TV_JL, y - h - 0.5, TV_JR - TV_JL, h),
               '<rect class="tvstr I %s" x="%.1f" y="%.1f" width="%.1f" height="%.1f"/>'
               % (ages[1], TV_JL, y + 0.5, TV_JR - TV_JL, h)]
        outer = 1.0 if y > TV_Y['p'] else -1.0      # the row's outer side: below for sister 2, above otherwise
        for side, site in zip(('L', 'R'), sites):
            sx = -1.0 if side == 'L' else 1.0
            j0 = TV_JL if side == 'L' else TV_JR
            x_rect = j0 - maxpx if side == 'L' else j0
            x_clip = j0 if side == 'L' else j0 - maxpx
            g_top = side == 'R'
            for strand in ('G', 'C'):
                top = g_top if strand == 'G' else not g_top
                sy = y - h - 0.5 if top else y + 0.5
                age = ages[0] if top else ages[1]
                out.append('<clipPath id="cp-tv%s-%s"><rect id="actor-tv%sclip-%s" class="act" x="%.1f" y="%.1f" '
                           'width="%.1f" height="%.1f"/></clipPath>'
                           % (strand, site, strand, site, x_clip, sy - 1.0, maxpx, h + 2.0))
                out.append('<g clip-path="url(#cp-tv%s-%s)"><rect class="tvstr %s %s" x="%.1f" y="%.1f" '
                           'width="%.1f" height="%.1f"/>'
                           % (strand, site, strand, age, x_rect, sy, maxpx, h))
                if not site.startswith('par'):
                    out.append('<g id="fx-tv%sadd-%s" class="fx gone"><g id="actor-tv%sadd-%s" class="act">'
                               '<rect class="tvstr %s new" x="%.1f" y="%.1f" width="%.1f" height="%.1f"/></g></g>'
                               % (strand, site, strand, site, strand, x_rect, sy, maxpx, h))
                out.append('</g>')
            for j in range(int(TV_MAXBP // 19)):
                x = j0 + sx * (j + 0.5) * 19.0 * TV_S
                ry = y - h - 2.0 - TV_RAP1_H if outer < 0 else y + h + 2.0
                out.append('<g id="fx-tvrap-%s-%d" class="fx gone" data-feat="telrap"><rect class="tvrap1" '
                           'x="%.1f" y="%.1f" width="%.1f" height="%.1f" rx="1"/></g>'
                           % (site, j, x - TV_RAP1_W / 2.0, ry, TV_RAP1_W, TV_RAP1_H))
            for j in range(TV_RIF_SLOTS):
                x = j0 + sx * (9.0 + j * TV_RIF_DX)
                out.append('<g id="fx-tvrif-%s-%d" class="fx gone" data-feat="rif">%s</g>'
                           % (site, j, mini(rif_glyph, rcx, rcy, x, y + outer * 21.0, CHR_COPY_RIF * 1.25)))
            gs = -1.0 if g_top else 1.0
            # The tip's proteins start 6 units past the tip, leaving room for the
            # two strand-end labels.
            spots = [('mrx', 19.0, 15.0 * gs, 18.0, 'MRX', 'tvmrx'), ('tel1', 39.0, 15.0 * gs, 18.0, 'Tel1', 'tvtel1'),
                     ('st', 28.0, 15.0 * gs, 40.0, 'Stn1-Ten1', 'tvst'), ('cdc13', 24.0, 0.0, 24.0, 'Cdc13', 'tvcdc13'),
                     ('tert', 28.0, -13.0 * gs, 38.0, 'telomerase', 'tvtert'),
                     ('pola', 21.0, -13.0 * gs, 24.0, 'Pol α', 'tvpola')]
            tip = ''.join('<g id="fx-tv%s-%s" class="fx gone">%s</g>'
                          % (n, site, tv_box(j0 + sx * dx, y + dy, w, 8.0, lab, cls))
                          for n, dx, dy, w, lab, cls in spots)
            # Strand ends: the G-rich strand runs 5' to 3' toward the tip, so its
            # tip is 3' and the C-rich strand's is 5'. Each label sits just past
            # its strand's tip, on that strand's side of the duplex, and rides
            # with the tip: the G label with the tip group, the C label with a
            # group the run moves to the C-strand's length.
            anchor = '' if side == 'R' else 'e'
            above, below = y - 1.6, y + 5.0
            tip += ('<text class="strandend%s" x="%.1f" y="%.1f">3′</text>'
                    % (anchor, j0 + sx * 1.0, above if g_top else below))
            out.append('<g id="actor-tvtip-%s" class="act">%s</g>' % (site, tip))
            out.append('<g id="actor-tvCend-%s" class="act"><text class="strandend%s" x="%.1f" y="%.1f">5′</text></g>'
                       % (site, anchor, j0 + sx * 1.0, below if g_top else above))
        return ''.join(out)

    def draw_fork(side):
        # VIEW: one replisome at rest on the origin, its far arc and its near side with the new strands' start, nicks and labels (TERMINAL)
        # d is the way the fork moves; the bubble, and everything the fork
        # leaves behind it, lies the other way. Sister 1 keeps the parental top
        # strand and makes a new bottom strand; sister 2 the reverse. The
        # leading strand runs 5' to 3' the way the fork moves: at the right
        # fork it is sister 2's new top strand, at the left fork sister 1's new
        # bottom strand. The other new strand is the lagging strand, drawn
        # with nicks between its Okazaki fragments.
        d = -1.0 if side == 'L' else 1.0
        x, yp, h2 = TV_ORI, TV_Y['p'], TV_STRAND_H / 2.0 + 0.5
        bx = x - d * TV_INSET
        diag = []
        for k, top_age, bot_age in ((1, 'old', 'new'), (2, 'new', 'old')):
            y = TV_Y[k]
            diag.append('<path class="tvdiag %s" d="M%.1f %.1f L%.1f %.1f"/>' % (top_age, x, yp - h2, bx, y - h2))
            diag.append('<path class="tvdiag %s" d="M%.1f %.1f L%.1f %.1f"/>' % (bot_age, x, yp + h2, bx, y + h2))
        b, f = cmg_actor('l' if side == 'L' else 'r', pole=True)
        gcx = DH_X + (-MCM_HALF if side == 'L' else MCM_HALF)
        tx = x + d * MCM_HALF * CHR_MINI
        lag_y = TV_Y[1] + 0.5 if side == 'R' else TV_Y[2] - TV_STRAND_H - 0.5
        nicks = ''.join('<path class="tvnick" d="M%.1f %.1f V%.1f"/>'
                        % (bx - d * (10.0 + 16.0 * k), lag_y - 1.5, lag_y + TV_STRAND_H + 1.5) for k in range(3))
        lead_row, lag_row = (2, 1) if side == 'R' else (1, 2)
        lab_y = {1: TV_Y[1] + 16.0, 2: TV_Y[2] - 9.0}
        cx = x - d * TV_LAB_DX
        labels = ('<g id="fx-tvslab-%s" class="fx gone"><text class="tvstrandlab" x="%.1f" y="%.1f">leading strand</text>'
                  '<text class="tvstrandlab" x="%.1f" y="%.1f">lagging strand</text></g>'
                  % (side, cx, lab_y[lead_row], cx, lab_y[lag_row]))
        # The CMG's far arc goes under the DNA and its near arc over it, as on
        # the chromosome view; the far arc is its own actor, moved with the fork.
        back = ('<g id="fx-tvforkb-%s" class="fx present"><g id="actor-tvforkb-%s" class="act">%s</g></g>'
                % (side, side, mini(b, gcx, DNA_Y, tx, yp, CHR_MINI)))
        front = ('<g id="fx-tvfork-%s" class="fx present"><g id="actor-tvfork-%s" class="act">'
                 '<g id="fx-tvdiag-%s" class="fx gone">%s</g>'
                 '<g id="fx-tvnick-%s" class="fx gone">%s</g>%s%s</g></g>'
                 % (side, side, side, ''.join(diag), side, nicks, mini(f, gcx, DNA_Y, tx, yp, CHR_MINI), labels))
        return back, front

    def draw_words():
        # VIEW: each end's line of words, the sister names and the origin's name (TERMINAL)
        out = []
        for k in (1, 2):
            for side in ('L', 'R'):
                site = 'tel-%s-s%d' % (side, k)
                x = TV_JL if side == 'L' else TV_JR
                out.append('<text id="txt-tvlab-%s" class="%s" x="%.1f" y="%.1f"> </text>'
                           % (site, 'tvtexte' if side == 'L' else 'tvtext', x, TV_Y[k] + TV_TEXT_DY[k]))
        out.append('<g id="fx-tvsis" class="fx gone"><text class="tvsis" x="%.1f" y="%.1f">sister 1</text>'
                   '<text class="tvsis" x="%.1f" y="%.1f">sister 2</text></g>'
                   % (TV_ORI, TV_Y[1] - 9.0, TV_ORI, TV_Y[2] + 16.0))
        out.append('<g id="fx-tvori" class="fx present"><text class="tvsis" x="%.1f" y="%.1f">parental duplex</text>'
                   '<text class="tvsis" x="%.1f" y="%.1f">origin</text></g>'
                   % ((TV_JL + TV_ORI) / 2.0 - 20.0, TV_Y[1] - 9.0, TV_ORI, TV_Y['p'] + 20.0))
        return ''.join(out)

    def draw_hits():
        # VIEW: one click target per daughter end (TERMINAL)
        maxpx = TV_MAXBP * TV_S
        out = []
        for k in (1, 2):
            for side in ('L', 'R'):
                x0 = TV_JL - maxpx - 36.0 if side == 'L' else TV_JR
                out.append('<rect class="chrhit" data-telsite="tel-%s-s%d" x="%.1f" y="%.1f" width="%.1f" '
                           'height="%.1f"/>' % (side, k, x0, TV_Y[k] - 24.0, maxpx + 36.0, 48.0))
        return ''.join(out)

    def draw_selection():
        # VIEW: the ring on the selected end, moved by the page (TERMINAL)
        maxpx = TV_MAXBP * TV_S
        return ('<g id="actor-tvsel" class="act tvsel"><rect class="chrselring" x="%.1f" y="%.1f" '
                'width="%.1f" height="%.1f" rx="4"/></g>'
                % (TV_JR - 6.0, TV_Y[1] - 24.0, maxpx + 44.0, 48.0))

    def draw_key():
        # VIEW: one line saying how to read the view (TERMINAL)
        return notelab('Dark: parental strand; light: new strand. Gold: G-rich repeat strand; blue: C-rich; grey: '
                       'interior DNA, drawn at a smaller scale than the ends, which are drawn to length. Purple: one '
                       'Rap1 site per 19 bp; each Rif1 glyph is one Rif1-PP1 copy bound at the end, unavailable to the origins.')

    def describe(sites):
        # MODEL: the numbers src/chrom-frames.js draws the view with (TERMINAL)
        maxpx = TV_MAXBP * TV_S
        return {'sites': sites, 's': TV_S, 'maxBp': TV_MAXBP, 'jl': TV_JL, 'jr': TV_JR, 'ori': round(TV_ORI, 3),
                'arms': list(TV_ARMS), 'rows': {'p': TV_Y['p'], '1': TV_Y[1], '2': TV_Y[2]},
                'inset': TV_INSET, 'slide': TV_SLIDE, 'labDx': TV_LAB_DX, 'cmgHalf': MCM_HALF * CHR_MINI,
                'rap1Slots': int(TV_MAXBP // 19), 'rifSlots': TV_RIF_SLOTS, 'bpPerRap1': 19.0,
                'ringDx': {'L': round((TV_JL - maxpx - 38.0) - (TV_JR - 6.0), 3), 'R': 0.0}}

    # === COORDINATE SUB-CONTROLLERS ===

    sites = ['tel-L-s1', 'tel-L-s2', 'tel-R-s1', 'tel-R-s2']
    rows = ('<g clip-path="url(#cp-tvpar)">%s</g>'
            '<g clip-path="url(#cp-tvbubl)"><g clip-path="url(#cp-tvbubr)">%s%s</g></g>'
            % (draw_row(TV_Y['p'], ('old', 'old'), ('par-L', 'par-R')),
               draw_row(TV_Y[1], ('old', 'new'), ('tel-L-s1', 'tel-R-s1')),
               draw_row(TV_Y[2], ('new', 'old'), ('tel-L-s2', 'tel-R-s2'))))
    fl, fr = draw_fork('L'), draw_fork('R')
    body = (draw_heads() + draw_clips() + '<g class="glyphlayer back">%s%s</g>' % (fl[0], fr[0]) + rows
            + '<g class="glyphlayer front">%s%s</g>' % (fl[1], fr[1]) + draw_words()
            + draw_selection() + '<g data-feat="ui">%s</g>' % draw_hits() + '<g data-feat="key">%s</g>' % draw_key())
    return body, describe(sites)


def build_live_view():
    """BASE CONTROLLER: the live chromosome panel at rest, and the geometry the page needs.

    The panel is drawn once and holds every object any run can show: two forks
    and two copied strips for every origin, every glyph state of every origin
    with and without bob1, every copy in its reservoir, and text elements whose
    words each run writes. src/chrom-frames.js builds a run's frames from the
    schedule src/chrom-rule.js computes and from CHROM_GEOM, which this
    function returns so the page places copies, strips and meters with the
    numbers the markup was drawn with.
    """

    # === SUB-CONTROLLERS ===

    def load_inputs():
        # SUB-CONTROLLER: the origins and the drawing scale

        def load_origins():
            # MODEL: the six origins as the rule names them, with their recruiter (TERMINAL)
            # Equal to RULE.origins in src/chrom-rule.js; the test suite holds them equal.
            return [('L3', 15.0, 'none'), ('L2', 55.0, 'Fkh1/2'), ('L1', 110.0, 'Ctf19'),
                    ('R1', 130.0, 'Ctf19'), ('R2', 185.0, 'Fkh1/2'), ('R3', 212.0, 'none')]

        def chromosome_scale():
            # MODEL: panel units per kb (TERMINAL)
            return {'kb': (CHR_X1 - CHR_X0) / CHR_KB}

        return load_origins(), chromosome_scale()

    def draw_live_panel(origins, sc, tel_body):
        # SUB-CONTROLLER: the panel at rest, layer by layer, and the two views
        # alone for the layout guard. The chromosome's own parts sit in
        # .chrlayer and the telomere view in .tvlayer; the page shows one.

        def draw_clock():
            # VIEW: the phase strip, five S ticks whose numbers each run writes, the playhead (TERMINAL)
            out = ['<g class="chrclockstrip">']
            for name, slug, a, b in CHR_BANDS:
                out.append('<rect class="cycleband phase-%s" x="%.1f" y="%.1f" width="%.1f" '
                           'height="%.1f" rx="3"/>' % (slug, a, CHR_CLOCK_Y, b - a, CHR_CLOCK_H))
                out.append('<text class="chrclock" x="%.1f" y="%.1f">%s</text>'
                           % ((a + b) / 2.0, CHR_CLOCK_Y + 10.0, esc(name)))
            base = CHR_CLOCK_Y + CHR_CLOCK_H
            for k, f in enumerate(CHR_TICKS):
                x = CHR_S_X0 + f * (CHR_S_X1 - CHR_S_X0)
                word = ('%d min into S' % int(CHR_S_MAX * f)) if k == len(CHR_TICKS) - 1 \
                    else str(int(CHR_S_MAX * f))
                out.append('<path class="chrtickline" d="M%.1f %.1f V%.1f"/>' % (x, base, base + 3))
                out.append('<text id="txt-tick-%d" class="chrtick" x="%.1f" y="%.1f">%s</text>'
                           % (k, x, base + 11, word))
            out.append('</g>')
            out.append('<g id="actor-playhead" class="act"><path class="chrplayhead" '
                       'd="M%.1f %.1f V%.1f"/></g>'
                       % (CHR_PLAYHEAD_X, CHR_CLOCK_Y - 3.0, base + 3.0))
            return ''.join(out)

        def draw_header():
            # VIEW: the genotype and its supplies, written by each run (TERMINAL)
            return ('<text id="txt-label" class="chrlab" data-feat="label" x="%.1f" y="58">wild type</text>'
                    '<text id="txt-pools" class="chrpar" data-feat="pools" x="%.1f" y="72">DDK: 10 of 10 active. '
                    'Rif1-PP1: 2 on each telomere, 6 free</text>'
                    '<text id="txt-cond" class="chrpar" data-feat="label" x="%.1f" y="84"></text>'
                    % (CHR_X0, CHR_X0, CHR_X0))

        def draw_spindle():
            # VIEW: the spindle to scale, two pole bodies and the bundle between them (TERMINAL)
            # The left pole body stays put. The right one is an actor that a run
            # slides out by the spindle length, and the bundle is revealed by a
            # sliding clip, so the spindle grows by translation only. The bundle
            # turns from the short colour to the extended colour at 3 um, which
            # the dashed line marks.
            # The bundle is drawn as three microtubules and each pole body as a
            # layered plaque, so the gauge reads as a spindle seen from the side.
            x0, y, h, um = CHR_SPL_X0, CHR_SPL_Y, CHR_SPL_H, CHR_SPL_UM
            w = 10.0 * um

            def mts(cls, xa, wa):
                return ''.join('<rect class="%s" x="%.1f" y="%.1f" width="%.1f" height="1.3" rx="0.6"/>'
                               % (cls, xa, y + dy, wa) for dy in (0.2, 2.35, 4.5))

            def pole(xa):
                return ('<rect class="chrspb" x="%.1f" y="%.1f" width="6" height="%.1f" rx="2.5"/>'
                        '<rect class="chrspbin" x="%.1f" y="%.1f" width="2" height="%.1f" rx="1"/>'
                        % (xa, y - 3.0, h + 6.0, xa + 2.0, y - 1.0, h + 2.0))
            return ('<text id="txt-spl" class="chrpar" x="%.1f" y="%.1f">spindle 10.0 \u00b5m, extended</text>'
                    '<path class="chrsplline" d="M%.1f %.1f V%.1f"/>'
                    '<clipPath id="cg-live-spl"><rect x="%.1f" y="%.1f" width="%.1f" height="%.1f"/></clipPath>'
                    '<g clip-path="url(#cg-live-spl)"><g id="actor-spl" class="act">'
                    '<g id="fx-spl-short" class="fx present">%s</g>'
                    '<g id="fx-spl-ext" class="fx gone">%s</g></g></g>'
                    '%s<g id="actor-spb2" class="act">%s</g>'
                    % (CHR_X0, y - 4.0,
                       x0 + 3.0 * um, y - 3.0, y + h + 3.0,
                       x0, y, w, h,
                       mts('chrsplshort', x0 - w, w), mts('chrsplext', x0 - w, w),
                       pole(x0 - 6.0), pole(x0)))

        def draw_tray():
            # VIEW: the tray and the two firing-factor sets at rest (TERMINAL)
            kit = chr_bundle_kit()
            rel, rests = chr_tray_layout(kit)
            x0 = rests[0][0] + rel[0] - 4.0
            x1 = rests[1][0] + rel[2] + 4.0
            y0, y1 = rests[0][1] + rel[1] - 3.0, rests[0][1] + rel[3] + 3.0
            out = ['<rect class="chrtray" x="%.1f" y="%.1f" width="%.1f" height="%.1f" rx="4"/>'
                   % (x0, y0, x1 - x0, y1 - y0),
                   '<g id="fx-held-sets" class="fx gone" data-feat="rad53"><rect class="chrtrayheld" x="%.1f" y="%.1f" '
                   'width="%.1f" height="%.1f" rx="4"/></g>' % (x0, y0, x1 - x0, y1 - y0),
                   '<text class="chrtag" x="%.1f" y="%.1f">two firing-factor sets: Sld3-Sld7, '
                   'Sld2, Dpb11</text>' % ((x0 + x1) / 2.0, y1 + 9.0)]
            for n, (ax, ay) in enumerate(rests):
                out.append('<g id="actor-bundle-%d" class="act">%s</g>'
                           % (n + 1, mini(kit, DH_X, DNA_Y, ax, ay, CHR_MINI)))
            return ''.join(out)

        def draw_reservoirs():
            # VIEW: the DDK and Rif1-PP1 reservoirs with every copy at rest (TERMINAL)
            # Each copy is an actor inside a presence wrapper. A run sends active
            # copies to docks and back, fades the DDK copies its genotype leaves
            # inactive, and hides the Rif1 copies a rif1 deletion removes.
            lay = chr_reservoir_layout({'ddk_total': 10, 'rif1_free': 10})
            (ddk, dcx, dcy), (rif, rcx, rcy) = chr_copy_glyphs()
            # Each reservoir is a copy's home. Its outline turns solid while
            # Rad53 holds the copies there (fx-held-ddk), drawn over the dashed one.
            out = []
            for kind, label in (('ddk', 'DDK'), ('rif', 'free Rif1-PP1')):
                box = lay[kind][0]
                out.append('<g data-feat="%s"><rect class="chrtray" x="%.1f" y="%.1f" width="%.1f" height="%.1f" '
                           'rx="3"/><text class="chrtag" x="%.1f" y="%.1f">%s</text>'
                           % (kind, box[0], box[1], box[2] - box[0], box[3] - box[1],
                              (box[0] + box[2]) / 2.0, box[3] + 9.0, label))
                if kind == 'ddk':
                    out.append('<g id="fx-held-ddk" class="fx gone" data-feat="rad53"><rect class="chrtrayheld" x="%.1f" y="%.1f" '
                               'width="%.1f" height="%.1f" rx="3"/></g>'
                               % (box[0], box[1], box[2] - box[0], box[3] - box[1]))
                out.append('</g>')
            out.append('<g data-feat="ddk">')
            for k, (cx, cy) in enumerate(lay['ddk'][1]):
                # dbf4-m25 fills the Rad53 site on each copy; the fill rides the copy.
                out.append('<g id="fx-ddk-%d" class="fx present"><g id="actor-ddk-%d" class="act">'
                           '%s<g id="fx-ddkblock-%d" class="fx gone">%s</g></g></g>'
                           % (k + 1, k + 1, mini(ddk, dcx, dcy, cx, cy, CHR_COPY_DDK), k + 1,
                              mini(ddk_block(0.0, 0.0), 0.0, 0.0, cx + DDK_CLEFT[0] * CHR_COPY_DDK,
                                   cy + DDK_CLEFT[1] * CHR_COPY_DDK, CHR_COPY_DDK)))
            out.append('</g><g data-feat="rif">')
            for k, (cx, cy) in enumerate(lay['rif'][1]):
                out.append('<g id="fx-rif-%d" class="fx present"><g id="actor-rif-%d" class="act">'
                           '%s</g></g>' % (k + 1, k + 1, mini(rif, rcx, rcy, cx, cy, CHR_COPY_RIF)))
            out.append('</g>')
            return ''.join(out)

        def draw_checkpoint():
            # VIEW: the checkpoint circuit, its outputs, and the Rad53 marks (TERMINAL)
            # Input to output, left to right: the Mec1 signal gauge fills with the
            # RPA summed over the stalled forks, and signal tokens fly up to it
            # from each fork's RPA; its full mark is the threshold; an arrow runs
            # to Rad53, drawn as the figure's kinase silhouette with a burnt-orange
            # core so it reads apart from DDK; four outputs are listed beside it
            # and light as they act. The dNTP gauge sits under the signal gauge.
            # A Rad53 mark is the figure's phosphate star on a set or a DDK copy
            # that Rad53 holds at home.
            rad = kinase_burst(0.0, 0.0, 'Rad53')
            sx0, sx1, sy, sh = CHR_SIG_X0, CHR_SIG_X1, CHR_SIG_Y, CHR_SIG_H
            gx0, gx1, gy, gh = CHR_DNTP_X0, CHR_DNTP_X1, CHR_DNTP_Y, CHR_DNTP_H
            out = ['<text class="chrtag" data-feat="mec1" x="%.1f" y="%.1f">Mec1-Ddc2, Mrc1</text>'
                   % ((sx0 + sx1) / 2.0, sy - 4.0)]
            for kind, x0, x1, y, h, fill, label in (
                    ('sig', sx0, sx1, sy, sh, 'chrsigfill', None),
                    ('dntp', gx0, gx1, gy, gh, 'chrdntp', 'dNTP pool')):
                feat = 'mec1' if kind == 'sig' else 'dntp'
                out.append('<g data-feat="%s"><rect class="chrmeter" x="%.1f" y="%.1f" width="%.1f" height="%.1f"/>'
                           '<clipPath id="cg-live-%s"><rect x="%.1f" y="%.1f" width="%.1f" '
                           'height="%.1f"/></clipPath><g clip-path="url(#cg-live-%s)"><g id="actor-%s" '
                           'class="act"><rect class="%s" x="%.1f" y="%.1f" width="%.1f" height="%.1f"/>'
                           '</g></g>'
                           % (feat, x0, y, x1 - x0, h, kind, x0, y, x1 - x0, h, kind, kind, fill,
                              x0, y, x1 - x0, h))
                if label:
                    out.append('<text class="chrtag" x="%.1f" y="%.1f">%s</text>'
                               % ((x0 + x1) / 2.0, y + h + 9.0, label))
                out.append('</g>')
            out.append('<path class="chrtheta" data-feat="mec1" d="M%.1f %.1f V%.1f"/>' % (sx1, sy - 2.0, sy + sh + 2.0))
            out.append('<g id="fx-sigarrow" class="fx fading" data-feat="mec1 rad53"><path class="chrsig" d="M%.1f %.1f H%.1f '
                       'M%.1f %.1f l-4 -3 M%.1f %.1f l-4 3"/></g>'
                       % (sx1 + 3.0, sy + sh / 2.0, CHR_RAD53_X - 9.0, CHR_RAD53_X - 9.0, sy + sh / 2.0,
                          CHR_RAD53_X - 9.0, sy + sh / 2.0))
            out.append('<g data-feat="rad53"><g id="fx-rad53" class="fx fading">%s</g>'
                       % mini(rad, 0.0, 0.0, CHR_RAD53_X, CHR_RAD53_Y, CHR_COPY_RAD53, 'rad53k'))
            out.append('<text class="chrtag" x="%.1f" y="%.1f">Rad53</text>'
                       % (CHR_RAD53_X, CHR_RAD53_Y + 16.0))
            out.append('<path class="chrsig" d="M%.1f %.1f V%.1f"/>'
                       % (CHR_OUT_X - 4.0, CHR_OUT_Y - 6.0, CHR_OUT_Y + 3.0 * CHR_OUT_DY + 2.0))
            for k, (key, words) in enumerate((('sld3', 'Sld3 marked: sets stay home'),
                                              ('dbf4', 'Dbf4 marked: DDK sent home'),
                                              ('dun1', 'Dun1: dNTP pool raised'),
                                              ('fork', 'stalled forks protected'))):
                out.append('<g id="fx-out-%s" class="fx fading"><text class="chrout" x="%.1f" '
                           'y="%.1f">%s</text></g>' % (key, CHR_OUT_X, CHR_OUT_Y + k * CHR_OUT_DY, words))
            out.append('<g id="fx-ev-rad53" class="fx gone"><text id="txt-ev-rad53" class="chrev" '
                       'x="%.1f" y="96.0">Rad53 on</text></g></g>' % CHR_RAD53_X)
            star = phos_star(0.0, 0.0)
            rests = chr_tray_layout(chr_bundle_kit())[1]
            for n, (ax, ay) in enumerate(rests):
                out.append('<g id="fx-setmark-%d" class="fx gone" data-feat="sets rad53">%s</g>'
                           % (n + 1, mini(star, 0.0, 0.0, ax, ay + 3.0, 0.45)))
            lay = chr_reservoir_layout({'ddk_total': 10, 'rif1_free': 10})
            for k, (cx, cy) in enumerate(lay['ddk'][1]):
                out.append('<g id="fx-ddkmark-%d" class="fx gone" data-feat="ddk rad53">%s</g>'
                           % (k + 1, mini(star, 0.0, 0.0, cx + DDK_CLEFT[0] * CHR_COPY_DDK, cy + DDK_CLEFT[1] * CHR_COPY_DDK, 0.22)))
            box = lay['ddk'][0]
            out.append('<g id="fx-ev-ddk" class="fx gone" data-feat="ddk rad53"><text class="chrev" x="%.1f" y="%.1f">'
                       'Rad53 marks Dbf4: DDK sent home</text></g>' % ((box[0] + box[2]) / 2.0, box[3] + 18.0))
            return ''.join(out)

        def draw_bar():
            # VIEW: the unreplicated chromosome as a duplex: two parental strands joined by rungs (TERMINAL)
            # Proportions are the step panels' substrate scaled by CHR_STRAND_K,
            # so a stretch reads the same at both scales.
            k, y = CHR_STRAND_K, CHR_DNA_Y
            # Strand ends: the top strand runs 5' to 3' left to right.
            ends = ''.join('<text class="strandend%s" x="%.1f" y="%.2f">%s</text>' % (cls, x, yy, lab)
                           for cls, x, yy, lab in (('e', CHR_X0 - 2.0, y - 8.0 * k + 2.0, '5′'),
                                                   ('', CHR_X1 + 2.0, y - 8.0 * k + 2.0, '3′'),
                                                   ('e', CHR_X0 - 2.0, y + 8.0 * k + 2.0, '3′'),
                                                   ('', CHR_X1 + 2.0, y + 8.0 * k + 2.0, '5′')))
            return ends + ('<defs><pattern id="chr-rung" width="%.2f" height="40" patternUnits="userSpaceOnUse">'
                    '<path class="chrrung" d="M%.2f 0 V40"/></pattern></defs>'
                    '<rect class="chrstrand" x="%.1f" y="%.2f" width="%.1f" height="%.2f"/>'
                    '<rect fill="url(#chr-rung)" x="%.1f" y="%.2f" width="%.1f" height="%.2f"/>'
                    '<rect class="chrstrand" x="%.1f" y="%.2f" width="%.1f" height="%.2f"/>'
                    % (9.0 * k, 4.5 * k,
                       CHR_X0, y - 8.0 * k, CHR_X1 - CHR_X0, 5.0 * k,
                       CHR_X0, y - 3.0 * k, CHR_X1 - CHR_X0, 6.0 * k,
                       CHR_X0, y + 3.0 * k, CHR_X1 - CHR_X0, 5.0 * k))

        def draw_copies(origins, sc):
            # VIEW: two copied stretches per origin, each revealed by a sliding clip (TERMINAL)
            # A copied stretch is two daughter duplexes, each a grey parental
            # strand paired by rungs to a blue new strand, at the step panels'
            # proportions scaled by CHR_STRAND_K. The stretch itself is fixed
            # to the chromosome, from its origin to the end it faces; the frames
            # slide its clip (the actor) out behind the fork, so the DNA stays
            # put while the copied part grows, and two stretches that meet
            # overlap in the same drawing.
            out = []
            k, y = CHR_STRAND_K, CHR_DNA_Y
            rows = (('chrstrand', -18.0, 5.0), ('rung', -13.0, 3.0), ('chrnew', -10.0, 4.0),
                    ('chrnew', 9.0, 4.0), ('rung', 13.0, 3.0), ('chrstrand', 16.0, 5.0))
            top, bot = y - 19.0 * k, y + 22.0 * k
            for name, pos, _ in origins:
                xo = CHR_X0 + pos * sc['kb']
                for side, xe in (('left', CHR_X0), ('right', CHR_X1)):
                    lo, hi = min(xo, xe), max(xo, xe)
                    span = hi - lo
                    cx0 = xo - span if side == 'right' else xo
                    clip = 'cp-live-%s-%s' % (name, side)
                    out.append('<clipPath id="%s"><rect id="actor-copy-%s-%s" class="act" x="%.1f" '
                               'y="%.2f" width="%.1f" height="%.2f"/></clipPath>'
                               % (clip, name, side, cx0, top, span, bot - top))
                    body = ['<rect class="chrgap" x="%.1f" y="%.2f" width="%.1f" height="%.2f"/>'
                            % (lo, top, span, bot - top)]
                    for cls, dy, h in rows:
                        fill = 'fill="url(#chr-rung)"' if cls == 'rung' else 'class="%s"' % cls
                        body.append('<rect %s x="%.1f" y="%.2f" width="%.1f" height="%.2f"/>'
                                    % (fill, lo, y + dy * k, span, h * k))
                    out.append('<g clip-path="url(#%s)">%s</g>' % (clip, ''.join(body)))
            return ''.join(out)

        def draw_sisters(sc):
            # VIEW: the two sister chromatids for G2 and anaphase, each in segments (TERMINAL)
            # Each sister is one daughter duplex of the copied stretch, drawn at
            # the same rows, so the swap from the copied strips is invisible.
            # Each segment is an actor a run moves toward its pole, the
            # centromere segment furthest, so the sisters part in a V led by
            # the centromere, by translation only.
            k, y = CHR_STRAND_K, CHR_DNA_Y
            rows = {'t': (('chrstrand', -18.0, 5.0), ('rung', -13.0, 3.0), ('chrnew', -10.0, 4.0)),
                    'b': (('chrnew', 9.0, 4.0), ('rung', 13.0, 3.0), ('chrstrand', 16.0, 5.0))}
            n = int(round(CHR_KB / CHR_SIS_SEG_KB))
            w = CHR_SIS_SEG_KB * sc['kb']
            out = ['<g id="fx-sisters" class="fx gone">']
            for sis in ('t', 'b'):
                for j in range(n):
                    x0 = CHR_X0 + j * w
                    body = ''.join('<rect %s x="%.2f" y="%.2f" width="%.2f" height="%.2f"/>'
                                   % ('fill="url(#chr-rung)"' if cls == 'rung' else 'class="%s"' % cls,
                                      x0, y + dy * k, w + 0.4, h * k)
                                   for cls, dy, h in rows[sis])
                    out.append('<g id="actor-sis-%s-%d" class="act">%s</g>' % (sis, j, body))
            out.append('</g>')
            return ''.join(out)

        def draw_telomeres():
            # VIEW: the Rap1 units, Rif1 on them, names, and arrival states (TERMINAL)
            out = []
            for side, name, x, inward in (('L', 'TEL-L', CHR_X0, 1.0), ('R', 'TEL-R', CHR_X1, -1.0)):
                base, rif1 = tel_rap1_units(2, flip=(side == 'L'))
                b = raw_box(base + rif1)
                ax = (b[0] if side == 'L' else b[2])
                ty = CHR_DNA_Y - CHR_BAR_H / 2.0
                out.append(mini(base, ax, 139.0, x, ty, CHR_MINI_TEL))
                out.append('<g id="fx-rif1-%s" class="fx present" data-feat="rif">%s</g>'
                           % (side, mini(rif1, ax, 139.0, x, ty, CHR_MINI_TEL)))
                out.append('<text class="chrstate" x="%.1f" y="%.1f">%s</text>'
                           % (x + inward * 14.0, CHR_LABEL_Y, name))
                out.append('<g id="fx-telwait-%s" class="fx present"><text class="chrstate alt" '
                           'x="%.1f" y="%.1f">not yet copied</text></g>'
                           % (side, x + inward * 26.0, CHR_LABEL3_Y))
                out.append('<g id="fx-teldone-%s" class="fx gone"><text id="txt-teldone-%s" '
                           'class="chrstate alt" x="%.1f" y="%.1f">copied at 00.0 min</text></g>'
                           % (side, side, x + inward * 34.0, CHR_LABEL3_Y))
            return ''.join(out)

        def draw_centromere(sc):
            # VIEW: the centromere tick and the Ctf19 complex that recruits DDK to its origins (TERMINAL)
            x = CHR_X0 + 120.0 * sc['kb']
            box = protein(x, 60.0, 70.0, 'Ctf19 complex', 'ctf19')
            return ('<path class="chrcen" d="M%.1f %.1f V%.1f"/>'
                    '<text class="chrstate" x="%.1f" y="%.1f">CEN</text>'
                    '%s'
                    '<g id="fx-rec-CEN" class="fx fading" data-feat="recruit"><text class="chrtag" x="%.1f" '
                    'y="153.0">Ctf19 complex</text></g>'
                    % (x, CHR_DNA_Y - 7.0, CHR_DNA_Y + 7.0, x, CHR_LABEL_Y,
                       '<g id="actor-ctf" class="act" data-feat="recruit">%s</g>'
                       % mini(box, x, 60.0, x, 158.0, CHR_MINI_BOX),
                       x - 34.0))

        def draw_kinetochores(sc):
            # VIEW: the CEN kinetochore and the late artificial one, each held by a microtubule (TERMINAL)
            # The CEN microtubule comes down from under the clock strip and the
            # artificial kinetochore's comes up from above the key, so the two
            # poles of the spindle both lie out of frame. Each microtubule sits
            # in a clip; when its kinetochore loses its anchor the run slides it
            # out of the clip, which reads as the microtubule letting go. The
            # spindle length itself is the gauge in the header.
            xc = CHR_X0 + 120.0 * sc['kb']
            xa = CHR_X0 + CHR_AK_KB * sc['kb']
            top, kt, bot, akt = CHR_KMT_TOP, CHR_KT_Y, CHR_KMT_BOT, CHR_AK_KT_Y
            return ('<defs><linearGradient id="chr-kmt-top" gradientUnits="userSpaceOnUse" x1="0" y1="%.1f" '
                    'x2="0" y2="%.1f"><stop offset="0" stop-color="#3f8f3f" stop-opacity="0"/>'
                    '<stop offset="1" stop-color="#3f8f3f" stop-opacity="1"/></linearGradient>'
                    '<linearGradient id="chr-kmt-bot" gradientUnits="userSpaceOnUse" x1="0" y1="%.1f" '
                    'x2="0" y2="%.1f"><stop offset="0" stop-color="#3f8f3f" stop-opacity="0"/>'
                    '<stop offset="1" stop-color="#3f8f3f" stop-opacity="1"/></linearGradient></defs>'
                    '<clipPath id="cp-live-kmt-CEN"><rect x="%.1f" y="%.1f" width="8" height="%.1f"/></clipPath>'
                    '<g clip-path="url(#cp-live-kmt-CEN)"><g id="actor-kmt-CEN" class="act">'
                    '<rect class="chrkmt" x="%.1f" y="%.1f" width="1.8" height="%.1f" fill="url(#chr-kmt-top)"/>'
                    '</g></g>'
                    '<g id="fx-kt-CEN" class="fx present"><g id="actor-kt1" class="act"><rect class="chrkt" '
                    'x="%.1f" y="%.1f" width="12" height="7" rx="3"/></g></g>'
                    '<clipPath id="cp-live-kmt2-CEN"><rect x="%.1f" y="%.1f" width="8" height="%.1f"/>'
                    '<rect x="%.1f" y="%.1f" width="8" height="%.1f"/></clipPath>'
                    '<g id="fx-kt2-CEN" class="fx gone"><g clip-path="url(#cp-live-kmt2-CEN)">'
                    '<g id="actor-kmt2-CEN" class="act"><rect class="chrkmt" x="%.1f" y="%.1f" width="1.8" '
                    'height="%.1f" fill="url(#chr-kmt-bot)"/></g></g>'
                    '<g id="actor-kt2" class="act"><rect class="chrkt" x="%.1f" y="%.1f" width="12" '
                    'height="7" rx="3"/></g></g>'
                    '<g id="fx-ev-CEN" class="fx gone"><text id="txt-ev-CEN" class="chrev" x="%.1f" y="96.0">'
                    'kinetochore lost</text></g>'
                    '<g id="fx-ak-site" class="fx gone"><rect class="chraklac" x="%.1f" y="%.1f" width="10" '
                    'height="10" rx="1.5"/><text class="chrstate" x="%.1f" y="%.1f">late AK</text></g>'
                    '<clipPath id="cp-live-kmt-AK"><rect x="%.1f" y="%.1f" width="8" height="%.1f"/></clipPath>'
                    '<g id="fx-ak-on" class="fx gone"><g clip-path="url(#cp-live-kmt-AK)">'
                    '<g id="actor-kmt-AK" class="act"><rect class="chrkmt" x="%.1f" y="%.1f" width="1.8" '
                    'height="%.1f" fill="url(#chr-kmt-bot)"/></g></g>'
                    '<g id="fx-kt-AK" class="fx present"><rect class="chrkt" x="%.1f" y="%.1f" width="12" '
                    'height="7" rx="3"/></g></g>'
                    '<g id="fx-ev-AK" class="fx gone"><text id="txt-ev-AK" class="chrev" x="%.1f" y="%.1f">'
                    'kinetochore lost</text></g>'
                    % (top, top + 22.0, bot, bot - 22.0,
                       xc - 4.0, top, kt - top + 1.0,
                       xc - 0.9, top, kt - top + 1.0,
                       xc - 6.0, kt,
                       xc - 4.0, CHR_KT2_Y + 6.0, CHR_LABEL_Y - 9.0 - CHR_KT2_Y - 6.0,
                       xc - 4.0, CHR_LABEL_Y + 3.0, bot - CHR_LABEL_Y - 3.0,
                       xc - 0.9, CHR_KT2_Y + 6.0, bot - CHR_KT2_Y - 6.0,
                       xc - 6.0, CHR_KT2_Y,
                       xc,
                       xa - 5.0, CHR_DNA_Y - 5.0, xa + 22.0, CHR_LABEL_Y,
                       xa - 4.0, akt + 6.0, bot - akt - 6.0,
                       xa - 0.9, akt + 6.0, bot - akt - 6.0,
                       xa - 6.0, akt,
                       xa + 34.0, CHR_LABEL2_Y))

        def draw_origins(origins, sc):
            # VIEW: meter, ceiling, lock, recruiter, drain, every glyph state and the labels (TERMINAL)
            # Returns (back, front, hits): the far arcs, everything else, and a
            # click area per origin that selects it for the close-up.
            out, back, hits = [], [], []
            orc_cx, orc_cy = ARS_X, ORC_Y
            orc_only = orc_ring(orc_cx, orc_cy, fits=False)
            orc_cdc6 = orc_ring(orc_cx, orc_cy, cdc6=True, fits=False)
            spent = '<g class="spent">%s</g>' % orc_only
            seat_b, seat_f = sld_cradle(DH_X, DNA_Y, fits=False, cdc45=True, cdc45_pending=False)
            # Pair states. The b suffix is the bob1 pair (Mcm5 tooth blunted in
            # both hexamers); mbob is its permissive shape, the NSD released with
            # no mark as offBOB1 draws it. Fired states carry the seated clasp.
            # mmark1 to mmark3 carry one to three tail marks with the NSD still
            # seated (MCM_MARK_ORDER); mmark carries all four, the NSD moved.
            pairs = {
                'mlic': mcm_double(DH_X, DNA_Y, nsd='seated'),
                'mlicb': mcm_double(DH_X, DNA_Y, nsd='seated', bob1=('5',)),
                'mmark': mcm_double(DH_X, DNA_Y, nsd='displaced', phos=True, phos_pending=False),
                'mmarkb': mcm_double(DH_X, DNA_Y, nsd='displaced', phos=True, phos_pending=False,
                                     bob1=('5',)),
                'mbob': mcm_double(DH_X, DNA_Y, nsd='released', bob1=('5',)),
            }
            for k in (1, 2, 3):
                pairs['mmark%d' % k] = mcm_double(DH_X, DNA_Y, nsd='seated', phos=k, phos_pending=False)
                pairs['mmarkb%d' % k] = mcm_double(DH_X, DNA_Y, nsd='seated', phos=k, phos_pending=False,
                                                   bob1=('5',))
            fires = {
                'mfire': mcm_double(DH_X, DNA_Y, nsd='displaced', phos=True, phos_pending=False,
                                    mcm2p='present'),
                'mfirebm': mcm_double(DH_X, DNA_Y, nsd='displaced', phos=True, phos_pending=False,
                                      mcm2p='present', bob1=('5',)),
                'mfireb': mcm_double(DH_X, DNA_Y, nsd='released', bob1=('5',)),
            }
            orc_y = CHR_DNA_Y - 4.0 * CHR_MINI
            for name, pos, recruiter in origins:
                x = CHR_X0 + pos * sc['kb']
                side = chr_orc_side(pos)
                ox = x + side * CHR_ORC_GAP
                mx, mt, mh, mw = x - CHR_METER_W / 2.0, CHR_METER_TOP, CHR_METER_H, CHR_METER_W
                clip = 'cm-live-%s' % name
                # The meter counts DDK marks on this pair's Mcm4 and Mcm6 tails. The
                # dashed ceiling is the threshold; in a bob1 pair's permissive shape
                # it drops to the floor, because no marks are needed then.
                out.append('<g class="chrmeterg" data-feat="meters">')
                out.append('<rect class="chrmeter" x="%.1f" y="%.1f" width="%.1f" height="%.1f"/>'
                           % (mx, mt, mw, mh))
                out.append('<clipPath id="%s"><rect x="%.1f" y="%.1f" width="%.1f" '
                           'height="%.1f"/></clipPath>' % (clip, mx, mt, mw, mh))
                out.append('<g id="fx-mfill-%s" class="fx present"><g clip-path="url(#%s)">'
                           '<g id="actor-mfill-%s" class="act"><rect class="chrmfill" x="%.1f" '
                           'y="%.1f" width="%.1f" height="%.1f"/></g></g></g>'
                           % (name, clip, name, mx, mt + mh, mw, mh))
                out.append('<g id="fx-mgrey-%s" class="fx gone"><rect class="chrmgrey" x="%.1f" '
                           'y="%.1f" width="%.1f" height="%.1f"/></g>' % (name, mx, mt, mw, mh))
                out.append('<g id="actor-theta-%s" class="act"><path class="chrtheta" '
                           'd="M%.1f %.1f H%.1f"/></g>' % (name, x - 7.0, mt, x + 7.0))
                out.append('<g id="fx-lock-%s" class="fx present"><path class="chrlock" '
                           'd="M%.1f %.1f v-2.5 a2.6 2.6 0 0 1 5.2 0 v2.5"/><rect class="chrlockbody" '
                           'x="%.1f" y="%.1f" width="7.0" height="4.5" rx="1"/></g>'
                           % (name, x - 2.6, mt + 2.0, x - 3.5, mt + 2.0))
                out.append('</g>')
                if recruiter == 'Fkh1/2':
                    box = protein(x, 60.0, 54.0, 'Fkh1/2', 'fkh')
                    out.append('<g data-feat="recruit">%s</g>'
                               % mini(box, x, 60.0, x - side * 20.0, CHR_DNA_Y + 14.0, CHR_MINI_BOX))
                    out.append('<g id="fx-rec-%s" class="fx fading" data-feat="recruit"><text class="chrtag" '
                               'x="%.1f" y="94.0">Fkh1/2</text></g>' % (name, x))
                if min(pos, CHR_KB - pos) <= 30.0:
                    # The telomere's captured Rif1-PP1 acting on this origin.
                    bx = x + side * 17.0
                    tx = CHR_X0 + 10.0 if pos < 120.0 else CHR_X1 - 10.0
                    box = rif1_glyph(bx, 60.0)
                    out.append('<g id="fx-drain-%s" class="fx gone" data-feat="rif"><path class="chrdrain" '
                               'd="M%.1f %.1f L%.1f %.1f"/>%s<path class="chrdrain" '
                               'd="M%.1f %.1f H%.1f"/><path class="chrdrain" d="M%.1f %.1f '
                               'V%.1f"/></g>'
                               % (name, tx, CHR_DNA_Y - 22.0, bx, 142.0,
                                  mini(box, bx, 60.0, bx, 138.0, CHR_MINI_BOX),
                                  bx - side * 5.0, 134.0, x + side * 4.0,
                                  x + side * 4.0, 130.0, 138.0))
                out.append('<g id="fx-morc-%s" class="fx gone">%s</g>'
                           % (name, mini(orc_only, orc_cx, orc_cy, ox, orc_y, CHR_MINI)))
                out.append('<g id="fx-mcdc6-%s" class="fx gone">%s</g>'
                           % (name, mini(orc_cdc6, orc_cx, orc_cy, ox, orc_y, CHR_MINI)))
                for st, (pb, pf) in sorted(pairs.items()):
                    back.append('<g id="fx-%s-%s-b" class="fx gone">%s</g>'
                                % (st, name, mini(pb, DH_X, DNA_Y, x, CHR_DNA_Y, CHR_MINI)))
                    out.append('<g id="fx-%s-%s" class="fx gone">%s%s</g>'
                               % (st, name, mini(spent, orc_cx, orc_cy, ox, orc_y, CHR_MINI),
                                  mini(pf, DH_X, DNA_Y, x, CHR_DNA_Y, CHR_MINI)))
                for st, (pb, pf) in sorted(fires.items()):
                    back.append('<g id="fx-%s-%s-b" class="fx gone">%s</g>'
                                % (st, name, mini(pb + seat_b, DH_X, DNA_Y, x, CHR_DNA_Y, CHR_MINI)))
                    out.append('<g id="fx-%s-%s" class="fx gone">%s%s</g>'
                               % (st, name, mini(spent, orc_cx, orc_cy, ox, orc_y, CHR_MINI),
                                  mini(pf + seat_f, DH_X, DNA_Y, x, CHR_DNA_Y, CHR_MINI)))
                out.append('<g id="fx-mspent-%s" class="fx gone">%s</g>'
                           % (name, mini(spent, orc_cx, orc_cy, ox, orc_y, CHR_MINI)))
                out.append('<g id="fx-pas-%s" class="fx gone"><circle class="chrpassive" '
                           'cx="%.1f" cy="%.1f" r="12.0"/></g>' % (name, x, CHR_DNA_Y))
                out.append('<text class="chrstate" x="%.1f" y="%.1f">%s</text>'
                           % (x, CHR_LABEL_Y, name))
                hits.append('<rect class="chrhit" data-origin="%s" x="%.1f" y="%.1f" width="%.1f" '
                            'height="%.1f"/>' % (name, x - 22.0, CHR_METER_TOP - 4.0, 44.0,
                                                 CHR_LABEL2_Y + 4.0 - CHR_METER_TOP + 4.0))
                out.append('<g id="fx-lablic-%s" class="fx gone"><text class="chrstate alt" '
                           'x="%.1f" y="%.1f">licensed</text></g>' % (name, x, CHR_LABEL2_Y))
                out.append('<g id="fx-labfate-%s" class="fx gone"><text id="txt-fate-%s" '
                           'class="chrstate alt" x="%.1f" y="%.1f">fires 00.0</text></g>'
                           % (name, name, x, CHR_LABEL2_Y))
                # What just happened at this origin's forks, shown for a few frames.
                # Two rows, so neighbouring origins' words do not run into each other.
                out.append('<g id="fx-ev-%s" class="fx gone"><text id="txt-ev-%s" class="chrev" '
                           'x="%.1f" y="%.1f"><tspan id="txt-ev-%s-a" x="%.1f">RPA on</tspan>'
                           '<tspan id="txt-ev-%s-b" x="%.1f" dy="7">ssDNA</tspan></text></g>'
                           % (name, name, x, CHR_EV_Y - 7.0, name, x, name, x))
            return ''.join(back), ''.join(out), ''.join(hits)

        def draw_forks(origins, sc):
            # VIEW: two CMGs per origin, the origin panels' CMGE, hidden until a run fires it (TERMINAL)
            # Returns (back, front, tokens): the far arcs, the forks with their
            # RPA, and the signal tokens, which go on top of everything.
            out, back, tokens = [], [], []
            for name, pos, _ in origins:
                x = CHR_X0 + pos * sc['kb']
                for side, direction in (('left', -1.0), ('right', 1.0)):
                    face = 'l' if direction < 0 else 'r'
                    b, f = cmg_actor(face, pole=True)
                    gcx = DH_X + (-MCM_HALF if face == 'l' else MCM_HALF)
                    tx = x + direction * MCM_HALF * CHR_MINI
                    fid = '%s-%s' % (name, side)
                    back.append('<g id="fx-chrfork-%s-b" class="fx gone"><g id="actor-chrfork-%s-b" '
                                'class="act"><g class="vib">%s</g></g></g>'
                                % (fid, fid, mini(b, gcx, DNA_Y, tx, CHR_DNA_Y, CHR_MINI)))
                    # RPA on the single-stranded DNA the helicase leaves behind it:
                    # one wedge per level, in a row on the DNA between the two
                    # parental strands, trailing the fork as steps 10 and 11 place
                    # it, and riding with the fork.
                    wedges = ''.join('<g id="fx-rpa%d-%s" class="fx gone" data-feat="rpa">%s</g>'
                                     % (k + 1, fid, mini(rpa(0.0, 0.0), 0.0, 0.0,
                                                         tx - direction * (CHR_RPA_TRAIL + CHR_RPA_STEP * k),
                                                         CHR_DNA_Y + 3.0, CHR_COPY_RPA))
                                     for k in range(3))
                    out.append('<g id="fx-chrfork-%s" class="fx gone"><g id="actor-chrfork-%s" '
                               'class="act"><g class="vib">%s</g>%s</g></g>'
                               % (fid, fid, mini(f, gcx, DNA_Y, tx, CHR_DNA_Y, CHR_MINI), wedges))
                    # Resection from this fork once it collapses: the group moves to
                    # the collapse point, and each side's stretch is revealed by a
                    # clip that slides out with Exo1 at its front.
                    out.append(resection_group(fid, x))

                    # The signal token: an RPA wedge that flies from this fork up
                    # to the Mec1 gauge. It rests at the gauge.
                    tokens.append('<g id="fx-sig-%s" class="fx gone" data-feat="mec1"><g id="actor-sig-%s" class="act">'
                                  '%s</g></g>' % (fid, fid, mini(rpa(0.0, 0.0), 0.0, 0.0, CHR_SIG_X0 + 6.0,
                                                                 CHR_SIG_Y + CHR_SIG_H / 2.0 + 3.0,
                                                                 CHR_COPY_TOKEN, 'sigtoken')))
            return ''.join(back), ''.join(out), ''.join(tokens)

        def draw_readouts():
            # VIEW: the firing order at the end of S, and the message for a genotype that cannot fire (TERMINAL)
            return ('<g id="fx-order" class="fx gone"><text id="txt-outcome" class="chrstate" x="560.0" '
                    'y="241.0">Copied in full</text><text id="txt-order" class="chrstate alt" '
                    'x="560.0" y="252.0">Firing order</text></g>'
                    '<g id="fx-lethal" class="fx gone"><text id="txt-lethal" class="chrstate alt" x="560.0" '
                    'y="252.0">No DDK and no bob1: no origin can fire, so dbf4Δ alone is lethal</text></g>')

        def draw_key():
            # VIEW: one line saying how to read the panel (TERMINAL)
            return notelab('Each DDK and Rif1-PP1 glyph is one copy, dealt to open origins. Meters: '
                           'DDK marks; dashed line: the proposed threshold. Gold stars: Rad53 marks. '
                           'Orange: DNA resected from a collapsed fork, Exo1 at each front. Green: '
                           'kinetochore microtubules, their poles out of frame.')

        ob, of, hits = draw_origins(origins, sc)
        fb, ff, ft = draw_forks(origins, sc)
        x_l1 = CHR_X0 + 108.0 * sc['kb']
        ring = ('<g id="chrsel" data-basex="%.1f"><rect class="chrselring" x="%.1f" y="%.1f" width="40" '
                'height="%.1f" rx="4"/></g>' % (x_l1, x_l1 - 20.0, CHR_LABEL_Y - 10.0,
                                                 CHR_LABEL2_Y - CHR_LABEL_Y + 14.0))
        # data-feat names the reader-facing feature each part belongs to, so a
        # guided lesson can show a feature only once it has introduced it.
        always = ['<g data-feat="clock">%s</g>' % draw_clock(), draw_header(),
                  '<g data-feat="spindle">%s</g>' % draw_spindle()]
        origin_head = ('<g class="orghead"><g data-feat="sets">%s</g>%s%s</g>'
                       % (draw_tray(), draw_reservoirs(), draw_checkpoint()))
        shared = always + [origin_head]
        chrom = ['<g class="glyphlayer back">%s<g data-feat="forks">%s</g></g>' % (ob, fb),
                 '<g id="fx-dna" class="fx present">%s%s</g>' % (draw_bar(), draw_copies(origins, sc)),
                 draw_sisters(sc), draw_telomeres(),
                 draw_centromere(sc), '<g data-feat="kinet">%s</g>' % draw_kinetochores(sc),
                 '<g class="glyphlayer front">%s<g data-feat="forks">%s</g></g>' % (of, ff)]
        readouts = '<g data-feat="outcome">%s</g>' % draw_readouts()
        chrom2 = [ft, '<g data-feat="key">%s</g>' % draw_key(), '<g data-feat="ui">%s%s</g>' % (ring, hits)]
        top = ''.join(shared)
        chr_layer = '<g class="chrlayer">%s</g>%s<g class="chrlayer">%s</g>' % (''.join(chrom), readouts,
                                                                              ''.join(chrom2))
        tel_layer = '<g class="tvlayer">%s</g>' % tel_body
        return (panel('chrLIVE', top + chr_layer + tel_layer),
                [panel('chrLIVE', top + chr_layer), panel('chrLIVE', ''.join(always) + readouts + tel_layer)])

    def resection_group(fid, x):
        # VIEW: one fork's resected stretches and Exo1 fronts, at rest on its origin (TERMINAL)
        reach, k, y, hh = CHR_RES_KB, sc_kb_global(), CHR_DNA_Y, CHR_RES_H
        span = reach * k
        parts = ['<g id="fx-res-%s" class="fx gone" data-feat="resect"><g id="actor-res-%s" class="act">'
                 % (fid, fid)]
        for side, sx0, cx0, sgn in (('l', x - span, x, -1.0), ('r', x, x - span, 1.0)):
            parts.append('<clipPath id="cp-res-%s-%s"><rect id="actor-resclip-%s-%s" class="act" x="%.1f" '
                         'y="%.1f" width="%.1f" height="%.1f"/></clipPath>'
                         % (fid, side, fid, side, cx0, y - hh, span, 2.0 * hh))
            parts.append('<rect class="chrres" clip-path="url(#cp-res-%s-%s)" x="%.1f" y="%.1f" width="%.1f" '
                         'height="%.1f"/>' % (fid, side, sx0, y - hh, span, 2.0 * hh))
            parts.append('<g id="actor-exo-%s-%s" class="act"><path class="chrexo" d="M%.1f %.1f '
                         'l%.1f -2.2 a3.2 3.2 0 1 0 0 4.4 z"/></g>'
                         % (fid, side, x, y - hh - 3.5, sgn * 2.8))
        parts.append('</g></g>')
        return ''.join(parts)

    def describe_geometry(origins, sc, tel_geom):
        # MODEL: the numbers src/chrom-frames.js places things with (TERMINAL)
        lay = chr_reservoir_layout({'ddk_total': 10, 'rif1_free': 10})
        rests = chr_tray_layout(chr_bundle_kit())[1]
        return {
            'x0': CHR_X0, 'x1': CHR_X1, 'kbScale': sc['kb'], 'dnaY': CHR_DNA_Y,
            'sX0': CHR_S_X0, 'sX1': CHR_S_X1, 'sMax': CHR_S_MAX, 'ticks': CHR_TICKS,
            'playheadX': CHR_PLAYHEAD_X, 'meterTop': CHR_METER_TOP, 'meterH': CHR_METER_H,
            'dockTop': CHR_DOCK_TOP, 'ddkCell': CHR_DDK_CELL, 'ddkCols': CHR_DDK_COLS,
            'rifCellW': CHR_RIF_CELL_W, 'rifCellH': CHR_RIF_CELL_H, 'rifCols': CHR_RIF_COLS,
            'ddkHomes': [[round(a, 2), round(b, 2)] for a, b in lay['ddk'][1]],
            'rifHomes': [[round(a, 2), round(b, 2)] for a, b in lay['rif'][1]],
            'setRests': [[round(a, 2), round(b, 2)] for a, b in rests],
            'origins': [{'name': n, 'position': p, 'recruiter': r} for n, p, r in origins],
            'fps': CHR_FPS,
            'dntpW': CHR_DNTP_X1 - CHR_DNTP_X0,
            'sigW': CHR_SIG_X1 - CHR_SIG_X0,
            'tokenHome': [CHR_SIG_X0 + 6.0, CHR_SIG_Y + CHR_SIG_H / 2.0 + 3.0],
            'rpaY': CHR_DNA_Y,
            'ciMeterH': CI_METER_H,
            'ciDntpH': CI_METER_H,
            'ciFrag': CI_FRAG,
            'ciW': CI_W,
            'ciH': CI_H,
            'ciS': CI_S,
            'ciFx': CI_FX,
            'ciStepX0': DH_X - CI_PX / CI_S,
            # A step panel cropped so its pair lands where the close-up draws
            # the origin's pair, at the close-up's scale.
            'ciStepView': '%.2f %.2f %.2f %.2f' % (DH_X - CI_PX / CI_S, DNA_Y - CI_DNA_Y / CI_S,
                                                   CI_W / CI_S, CI_H / CI_S),
            'rpaTrail': CHR_RPA_TRAIL + MCM_HALF * CHR_MINI,
            'cenX': CHR_X0 + 120.0 * sc['kb'], 'akX': CHR_X0 + CHR_AK_KB * sc['kb'], 'akKb': CHR_AK_KB,
            'kmtGone': CHR_KMT_GONE, 'resKb': CHR_RES_KB,
            'sisSegKb': CHR_SIS_SEG_KB, 'sisN': int(round(CHR_KB / CHR_SIS_SEG_KB)), 'anaDy': CHR_ANA_DY,
            'splW': 10.0 * CHR_SPL_UM, 'splUm': CHR_SPL_UM,
            # The close-up's own panels: the origin's frame for each state, and
            # what the elongation painter needs to repaint a fork's strip.
            'ciOrigin': ci_origin_frames(),
            'ciElong': {'range': CI_ELONG_RANGE, 'start': CI_ELONG_START, 'wrap': CI_ELONG_WRAP,
                        'nucs': dict((sd, elong_nucs(sd)) for sd in ('r', 'l')),
                        'x0': X0, 'cw': CW, 'split': FORK_SPLIT, 'okazaki': OKAZAKI_N,
                        'ext': 4, 'rpa': CI_ELONG_RPA, 'mcmW': MCM_W},
            'ciTerm': {'range': CI_TERM_RANGE, 'm': CI_TERM_M, 'split': CI_TERM_SPLIT},
            'ciCen': ci_cen_frames(), 'ciCenStates': CI_CEN_STATES,
            'ciPass': {'range': CI_PASS_RANGE, 'split': CI_PASS_SPLIT, 'ars': [lin(ARS_A), lin(ARS_B)],
                       'dh': [lin(DH[0]), lin(DH[1])], 'dhLeft': cx(lin(DH[0])), 'dhRight': cx(lin(DH[1])) + CW},
            'tel': tel_geom,
            # The telomere close-up: a telomere workflow panel cropped to the end.
            'twView': TW_CI_VIEW,
        }

    # === COORDINATE SUB-CONTROLLERS ===

    origins, sc = load_inputs()
    tel_body, tel_geom = build_telomere_layer()
    full, audits = draw_live_panel(origins, sc, tel_body)
    return full, describe_geometry(origins, sc, tel_geom), audits


def ci_row(x0, x1, dy, h, cls):
    """VIEW: one row of the close-up's DNA, dy and h in step-panel units about the axis (TERMINAL)

    A rung row is filled with the close-up's rung pattern; every other row is a
    strand of its class.
    """
    yy = CI_DNA_Y + dy * CI_S
    fill = 'fill="url(#ci-rung)"' if cls == 'rung' else 'class="%s"' % (
        'cistrandfill' if cls == 'cistrand' else 'cinewfill')
    return ('<rect %s x="%.2f" y="%.2f" width="%.2f" height="%.2f"/>'
            % (fill, x0, yy, x1 - x0, h * CI_S))


def ci_rungs(x0, span, y0, y1):
    """VIEW: explicit rungs for a conveyor strip, one every CI_RUNG (TERMINAL)"""
    return ''.join('<path class="cirung" d="M%.2f %.2f V%.2f"/>' % (x0 + n * CI_RUNG + CI_RUNG / 2.0, y0, y1)
                   for n in range(int(span / CI_RUNG)))


def inset_clean(markup):
    """MODEL: a glyph's markup for the close-up: no ids, no fit points, text kept (TERMINAL)

    The close-up draws origins at step-panel scale, so the labels stay. Ids go
    so nothing in the close-up answers to an id the engine or the panels use,
    and a glyph's own frame wrappers become static.
    """
    out = re.sub(r'\s+id="[^"]*"', '', markup)
    out = re.sub(r'<circle class="fitpt"[^>]*/>', '', out)
    out = re.sub(r'class="fx ', 'class="mfx ', out)
    return out


def build_inset_view():
    """BASE CONTROLLER: the origin close-up drawn under C1 in the navigation pane.

    The close-up shows one origin at a time through panels drawn by the step
    panels' own functions and painted by the engine's own rules, so the
    origin, the firing (steps 7 to 11, copied from the stage when first used)
    and the fork that leaves are one drawing from start to finish:

      ciorigin, ciorigin-b   the origin before and after it fires or is copied
                             (the -b panel carries the mcm5-bob1 double hexamer)
      cielong-r, cielong-l   one fork carried on past step 11: the step panels'
                             substrate extended outward from the origin

    Each is a nested svg with the step copies' viewBox and camera group, so a
    switch from one to the next shows the same picture. The left column and
    the text lines sit on top; src/chrom-frames.js writes what each frame
    shows and src/chrom-live.js paints it.
    """

    # === SUB-CONTROLLERS ===

    def draw_text_area():
        # VIEW: the title and three status lines that each frame writes (TERMINAL)
        return ('<text id="ci-title" class="cititle" x="6" y="14">Origin close-up: L1</text>'
                '<text id="ci-line1" class="ciline" x="6" y="28"> </text>'
                '<text id="ci-line2" class="ciline" x="6" y="40"> </text>'
                '<text id="ci-line3" class="ciline strong" x="6" y="52"> </text>')

    def draw_left_column():
        # VIEW: the meter with its count, the DDK and Rif1-PP1 the origin holds, its recruiter (TERMINAL)
        mx, mt, mw, mh = CI_METER_X, CI_METER_TOP, CI_METER_W, CI_METER_H
        ddk = inset_clean(ddk_glyph(0.0, 0.0))
        rif = inset_clean(rif1_glyph(0.0, 60.0))
        star = inset_clean(phos_star(0.0, 0.0))
        return ('<rect class="chrmeter" x="%.1f" y="%.1f" width="%.1f" height="%.1f"/>'
                '<clipPath id="ci-clip-meter"><rect x="%.1f" y="%.1f" width="%.1f" height="%.1f"/>'
                '</clipPath><g clip-path="url(#ci-clip-meter)"><g id="ci-mfill"><rect class="chrmfill" '
                'x="%.1f" y="%.1f" width="%.1f" height="%.1f"/></g></g>'
                '<g id="ci-theta"><path class="chrtheta" d="M%.1f %.1f H%.1f"/></g>'
                '<text id="ci-marks" class="cismall" x="%.1f" y="%.1f">0 of 20</text>'
                '<text class="cismall" x="%.1f" y="%.1f">marks</text>'
                '<g transform="translate(%.1f %.1f) scale(0.45)">%s</g>'
                '<g id="ci-ddkstar" class="cifx gone" transform="translate(%.1f %.1f) scale(0.45)">%s</g>'
                '<g id="ci-ddkblock" class="cifx gone" transform="translate(%.1f %.1f) scale(0.45)">%s</g>'
                '<text id="ci-ddkn" class="cismall" x="%.1f" y="%.1f">0 DDK</text>'
                '<g transform="translate(%.1f %.1f) scale(0.6) translate(0 -60)">%s</g>'
                '<text id="ci-rifn" class="cismall" x="%.1f" y="%.1f">0 Rif1-PP1</text>'
                '<text id="ci-rifcap" class="cismall" x="%.1f" y="%.1f"> </text>'
                '<text id="ci-rec" class="cismall" x="%.1f" y="%.1f"> </text>'
                % (mx, mt, mw, mh, mx, mt, mw, mh, mx, mt + mh, mw, mh, mx - 4.0, mt, mx + mw + 4.0,
                   mx + mw / 2.0, mt + mh + 10.0, mx + mw / 2.0, mt + mh + 19.0,
                   CI_COL_X, 78.0, ddk, CI_COL_X + DDK_CLEFT[0] * 0.45, 78.0 + DDK_CLEFT[1] * 0.45, star,
                   CI_COL_X + DDK_CLEFT[0] * 0.45, 78.0 + DDK_CLEFT[1] * 0.45, ddk_block(0.0, 0.0), CI_COL_X, 101.0,
                   CI_COL_X, 120.0, rif, CI_COL_X, 136.0, CI_COL_X, 145.0, CI_COL_X, 176.0))

    def draw_set_overlays():
        # VIEW: a set that cannot come, dim in the tray under the pair (TERMINAL)
        g = 'transform="translate(%.1f %.1f) scale(%.2f) translate(%.1f %.1f)"' % (
            CI_PX, CI_DNA_Y, CI_S, -DH_X, -DNA_Y)
        kit = inset_clean(chr_bundle_kit())
        star = inset_clean(phos_star(0.0, 0.0))
        sx, sy = sld_pad_point(DH_X, DNA_Y)
        out = []
        for st, words in (('held', 'set stays in the tray: Rad53 marked Sld3'),
                          ('wait', 'no free set yet')):
            out.append('<g id="ci-set-%s" class="cifx gone"><g class="cidim" %s><g transform="translate(-60 %.1f)">'
                       '%s%s</g></g><text class="cismall" x="%.1f" y="%.1f">%s</text></g>'
                       % (st, g, CI_SET_DROP, kit,
                          ('<g transform="translate(%.1f %.1f) scale(1.6)">%s</g>' % (sx, sy, star))
                          if st == 'held' else '',
                          CI_PX, CI_H - 6.0, words))
        return ''.join(out)

    def draw_dntp_gauge():
        # VIEW: the dNTP pool the followed fork draws on, as a column filled to its share of normal (TERMINAL)
        # It takes the left column's place while the close-up follows a fork,
        # with the chromosome panel's meter frame and dNTP fill. The top of the
        # column is the normal pool.
        mx, mt, mw, mh = CI_DNTP_X, CI_METER_TOP, CI_METER_W, CI_METER_H
        return ('<g id="ci-dntpg" class="cifx gone"><rect class="cicolbg" x="1" y="56" width="70" height="140"/>'
                '<rect class="chrmeter" x="%.1f" y="%.1f" width="%.1f" height="%.1f"/>'
                '<clipPath id="ci-clip-dntp"><rect x="%.1f" y="%.1f" width="%.1f" height="%.1f"/></clipPath>'
                '<g clip-path="url(#ci-clip-dntp)"><g id="ci-dfill"><rect class="chrdntp" x="%.1f" y="%.1f" '
                'width="%.1f" height="%.1f"/></g></g>'
                '<text class="cismall" x="%.1f" y="%.1f">dNTP pool</text>'
                '<text id="ci-dntpn" class="cismall" x="%.1f" y="%.1f">100%% of normal</text></g>'
                % (mx, mt, mw, mh, mx, mt, mw, mh, mx, mt + mh, mw, mh,
                   mx + mw / 2.0, mt + mh + 10.0, mx + mw / 2.0, mt + mh + 19.0))

    def draw_rnr():
        # VIEW: where the forks' dNTPs come from: RNR, blocked by HU, raised by Rad53 through Dun1 (TERMINAL)
        # Placed below the third status line's second row, which a long line wraps onto.
        x, y = 352.0, 86.0
        return ('<g id="ci-rnr" class="cifx gone"><rect class="cicolbg" x="%.1f" y="%.1f" width="96" height="64"/>'
                '%s<text class="cismall" x="%.1f" y="%.1f">makes the dNTPs</text>'
                '<text class="cismall" x="%.1f" y="%.1f">the forks draw on</text></g>'
                '<g id="ci-hu" class="cifx gone"><path class="inhline" d="M%.1f %.1f H%.1f"/>'
                '<path class="inhbar" d="M%.1f %.1f V%.1f"/><text class="cismall hu" x="%.1f" y="%.1f">HU</text></g>'
                '<g id="ci-dun1" class="cifx gone"><text class="cismall dun1" x="%.1f" y="%.1f">'
                'Rad53, via Dun1:</text><text class="cismall dun1" x="%.1f" y="%.1f">more RNR</text></g>'
                % (x - 48.0, y - 12.0, inset_clean(protein(x, y, 40, 'RNR', 'rnr', h=16)),
                   x, y + 17.0, x, y + 26.0,
                   x + 40.0, y, x + 22.0, x + 22.0, y - 7.0, y + 7.0, x + 37.0, y + 3.0 - 9.0,
                   x, y + 37.0, x, y + 46.0))

    panels = (ci_own_panel('ciorigin', ci_origin_body(False))
              + ci_own_panel('ciorigin-b', ci_origin_body(True))
              + ci_own_panel('cielong-r', ci_elong_body('r'))
              + ci_own_panel('cielong-l', ci_elong_body('l'))
              + ci_own_panel('cielong-r-b', ci_elong_body('r', True))
              + ci_own_panel('cielong-l-b', ci_elong_body('l', True))
              + ci_own_panel('cipass-r', ci_pass_body('r'))
              + ci_own_panel('cipass-l', ci_pass_body('l'))
              + ci_own_panel('cipass-r-b', ci_pass_body('r', True))
              + ci_own_panel('cipass-l-b', ci_pass_body('l', True))
              + ci_own_panel('cicen', ci_cen_body())
              + ci_own_panel('citerm', ci_term_body(False))
              + ci_own_panel('citerm-b', ci_term_body(True))
              + ''.join(ci_from_stage(fn(bob1=('5',), key=k + 'b'), k + 'b')
                        for k, fn in (('step07', p_step07), ('step08', p_step08), ('step09', p_step09),
                                      ('step10', p_step10), ('step11', p_step11))))
    body = (panels + draw_set_overlays() + draw_rnr()
            + '<g id="ci-leftcol" class="cifx present"><rect class="cicolbg" x="1" y="56" '
            'width="70" height="140"/>' + draw_left_column() + '</g>'
            + draw_dntp_gauge()
            + '<rect id="ci-headbg" class="cicolbg" x="1" y="1" width="%d" height="59"/>' % (CI_W - 2)
            + draw_text_area())
    return ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 %d %d" id="chrinset" '
            'class="navchart chrinset">%s%s<rect class="ciframe" x="0.5" y="0.5" width="%d" height="%d" '
            'rx="4"/></svg>' % (CI_W, CI_H, defs('chrinset'), body, CI_W - 1, CI_H - 1))


# The close-up's own panels. Their positions run past the step panels' 46 on
# the side of the fork they carry: indices 24 to 80 on the right, -34 to 23 on
# the left, each drawn exactly as a step-panel position at that index would be.
CI_ELONG_RANGE = {'r': (24, 80), 'l': (-34, 23)}
# Where the fork stands when step 11 hands over (its last frame), and the
# window it is kept in afterwards. Every pattern on the strip (Okazaki
# fragments, nucleosomes) repeats every OKAZAKI_N positions from there on, so
# moving the fork back by OKAZAKI_N inside the window changes nothing drawn.
CI_ELONG_START = {'r': NPOS, 'l': 1}
CI_ELONG_WRAP = {'r': (NPOS + OKAZAKI_N, NPOS + 2 * OKAZAKI_N), 'l': (1 - 2 * OKAZAKI_N + 1, 1 - OKAZAKI_N)}
CI_ELONG_RPA = 30                   # bare positions an uncoupled fork can leave in view, one RPA on each
CI_MEC_DX = 120.0                   # Mec1-Ddc2 sits on the coat this far behind the fork
CI_R53_DX, CI_R53_DY = 44.0, 78.0   # Rad53 docks on marked Mrc1, behind it and above


def elong_id(i):
    """MODEL: the close-up elongation panels' id for position index i (TERMINAL)"""
    return 'e%03d' % (i + 100)


def elong_nucs(side):
    """MODEL: the nucleosome spans on one elongation panel (TERMINAL).

    The step panels' own spans on that side, then one octamer every
    OKAZAKI_N positions outward, so the strip ahead of the fork repeats with
    the same period as the fragments behind it.
    """
    lo, hi = CI_ELONG_RANGE[side]
    if side == 'r':
        spans = [sp for sp in NUC_SPANS if sp[0] > FORK_SPLIT]
        j = NPOS + 1
        while j + 6 <= hi:
            spans.append((j, j + 6))
            j += OKAZAKI_N
    else:
        spans = [sp for sp in NUC_SPANS if sp[1] <= FORK_SPLIT]
        j = 0
        while j - 6 >= lo:
            spans.append((j - 6, j))
            j -= OKAZAKI_N
    return spans


def ci_from_stage(svg, key):
    """VIEW: a whole step panel turned into one of the close-up's own panels (TERMINAL)

    For the mcm5-bob1 drawings of steps 7 to 11, which no stage panel shows:
    the panel's own markup and ids, cropped and given a camera like a step copy.
    """
    inner_ = svg[svg.index('>') + 1:svg.rindex('</svg>')]
    view = '%.2f %.2f %.2f %.2f' % (DH_X - CI_PX / CI_S, DNA_Y - CI_DNA_Y / CI_S, CI_W / CI_S, CI_H / CI_S)
    inner_ = re.sub(r'<circle class="fitpt"[^>]*/>', '', inner_)
    return ('<svg class="cistep ciown" data-step="%s" x="0" y="0" width="%d" height="%d" '
            'viewBox="%s" style="opacity:0"><g class="cistepcam">%s</g></svg>' % (key, CI_W, CI_H, view, inner_))


def ci_own_panel(key, body):
    """VIEW: one of the close-up's own panels, as a nested svg like a step copy (TERMINAL)"""
    view = '%.2f %.2f %.2f %.2f' % (DH_X - CI_PX / CI_S, DNA_Y - CI_DNA_Y / CI_S, CI_W / CI_S, CI_H / CI_S)
    body = re.sub(r'<circle class="fitpt"[^>]*/>', '', body)
    return ('<svg class="cistep ciown" data-step="%s" x="0" y="0" width="%d" height="%d" '
            'viewBox="%s" style="opacity:0">%s<g class="cistepcam">%s</g></svg>'
            % (key, CI_W, CI_H, view, defs(key), body))


def ci_origin_body(bob1):
    """VIEW: the origin as the step panels draw it, every state it can show (TERMINAL).

    The substrate and the double hexamer are step 7's (same tracks, same
    actor, same fits), so the licensed origin marked by DDK is the picture
    step 7 opens on. ORC is drawn twice, in the near layer as steps 1 and 2
    draw it and in the far layer as steps 6 to 11 do, and a frame shows one.
    The double hexamer sits in a wrapper a frame can slide, which is how a
    passing fork pushes it off a passively copied origin.
    """
    t = licensed_tracks('displaced')
    dhb, dhf = dh_actor(phos=True, phos_pending=True, fits=('sld3', 'cdc45p'), nsd='displaced',
                        mcm2p='pending', bob1=('5',) if bob1 else (), graded=True)
    back = (fx('fx-orcback', orc_ring(ARS_X, ORC_Y))
            + '<g id="actor-dhout-b" class="act">%s</g>' % dhb)
    nx, ny = orc_notch(ARS_X, ORC_Y)
    # Cdc6 is its own actor here, so it comes down to the notch and leaves
    # again by travelling, as in steps 2 to 5.
    front = ('<g id="actor-dhout" class="act">%s</g>' % dhf
             + fx('fx-orcfront', orc_ring(ARS_X, ORC_Y))
             + actor('cdc6ci', cdc6_wedge(nx, ny, fits=False), basex=nx))
    # Step 11's two forks, each in a wrapper a frame slides outward: the
    # opened origin first shows them where step 11 leaves them, at its edges,
    # and the next frame carries them out of view.
    for sd in ('l', 'r'):
        fb, ff = split([a for a in fork_actors(side=sd)])
        back += '<g id="actor-forkout-%s-b" class="act">%s</g>' % (sd, fb)
        front += '<g id="actor-forkout-%s" class="act">%s</g>' % (sd, ff)
    return substrate(t, back, nascent=True) + '<g class="glyphlayer front">%s</g>' % front


def ci_strip(lo, hi, split=None, ars=False):
    """VIEW: positions lo..hi as the step panels draw them, with the close-up's ids (TERMINAL).

    Returns (zones, strands, cpx). Each position is drawn by the step panels'
    functions at its own index; split names the origin of the fork that
    copies it, which sets which daughter is continuous. ars draws the ARS
    blocks where the step panels have them.
    """
    zones, strands, cpx = [], [], []
    a, b = lin(ARS_A), lin(ARS_B)
    for i in range(lo, hi + 1):
        pid = elong_id(i)
        ctx = ' ctx' if (i <= LEFT_CTX or i > LEFT_CTX + ORIGIN_N) else ''
        kink = 'kink-fixed' if ars and a <= i <= b else 'kink-none'
        zones.append('<rect id="%s-z" class="zone" x="%.1f" y="%d" width="%d" height="%d"/>'
                     % (pid, cx(i), ZONE_Y, CW, ZONE_H))
        strands.append('<g id="%s-s" class="strand duplex present %s%s"><g class="kinkwrap">'
                       '<rect class="bar top" x="%.1f" y="%d" width="%d" height="%d"/>'
                       '<rect class="bar bot" x="%.1f" y="%d" width="%d" height="%d"/>%s%s%s</g></g>'
                       % (pid, kink, ctx, cx(i) + 0.5, ROW_T, CW - 1, BAR_H, cx(i) + 0.5, ROW_B, CW - 1,
                          BAR_H, rung_pieces(i, True, split),
                          ars_pieces(i) if ars and a <= i <= b else '', nascent_pieces(i, split)))
        cpx.append('<g id="%s-c" class="cpx naked present gate-na nsd-na"><rect class="cpxbar" '
                   'x="%.1f" y="%d" width="%d" height="%d"/></g>' % (pid, cx(i) + 0.5, CPX_Y, CW - 1, CPX_H))
    return ''.join(zones), ''.join(strands), ''.join(cpx)


def ci_nucs(spans):
    """VIEW: nucleosomes over position spans, each carrying its span for the painter (TERMINAL)"""
    out = []
    for k, (n0, n1) in enumerate(spans):
        x = (cx(n0) + cx(n1) + CW) / 2.0
        rx = (cx(n1) + CW - cx(n0)) / 2.0 - 2
        out.append('<g id="enuc%d" class="nuc" data-i0="%d" data-i1="%d"><ellipse class="nucbody" '
                   'cx="%.1f" cy="%.1f" rx="%.1f" ry="19"/><text class="glyphlab sm lt" x="%.1f" '
                   'y="%.1f">nuc</text></g>' % (k + 1, n0, n1, x, DNA_Y, rx, x, DNA_Y + 3))
    return ''.join(out)


def ci_compose(zones, nucs, back, strands, cpx, front, clip=''):
    """VIEW: the layers of a close-up panel in the step panels' order (TERMINAL)"""
    return (clip + '<g class="ciclip">'
            + '<g class="substrate"><g class="zonelayer">' + zones + '</g>'
            + '<g class="nuclayer">' + nucs + '</g>'
            + '<g class="glyphlayer back">' + back + '</g>'
            + '<g class="strandlayer">' + strands + '</g>'
            + '<g class="cpxlayer">' + cpx + '</g></g>'
            + '<g class="glyphlayer front">' + front + '</g></g>')


def ci_elong_body(side, bob1=False):
    """VIEW: one fork carried past step 11: the substrate on its side, its machinery (TERMINAL).

    Every position is drawn by the step panels' functions at its own index, so
    a fragment, a primer or a rung sits exactly where step 11 puts it, and
    the fork's actors are step 11's (fork_actors) with each glyph in a .vib
    group the close-up shakes while the fork moves. The whole drawing sits in
    a group the close-up clips while step 11 is still on top of it, so only
    the DNA past the step panel's end shows through.
    """
    lo, hi = CI_ELONG_RANGE[side]
    zones, strands, cpx = ci_strip(lo, hi)
    back, front = split(fork_actors(side=side, vib=True, bob1=('5',) if bob1 else ()))
    # One more RPA for each bare position a stalled fork leaves: parked below
    # the page, each comes up onto its position as the uncopied stretch grows.
    # Every other one is labelled, so neighbouring labels do not overlap. They
    # go in before the fork's machinery, so the replisome is drawn over the
    # ones nearest the helicase.
    coat = ''
    for n in range(CI_ELONG_RPA):
        x = DH_X + (-70 if side == 'l' else 70)
        glyph = rpa(x, DNA_Y + 14) if n % 2 == 1 else wedge(x, DNA_Y + 14, 13, 'rpaglyph')
        coat += actor('rpa%d-%s' % (n + 2, side), '<g class="vib">%s</g>' % glyph, basex=x)
    front = coat + front
    front += checkpoint_actor(side)
    # Exo1 at the resection front behind a collapsed fork, parked above the page until then.
    xe = fork_base(side)
    front += actor('exo-' + side, '<g class="vib">%s</g>' % protein(xe, DNA_Y + 46.0, 40, 'Exo1', 'exo1', h=16),
                   basex=xe)
    clip_x = cx(NPOS + 1) if side == 'r' else cx(1) - 6000.0
    clip = ('<clipPath id="cielong-%s-ahead"><rect x="%.1f" y="-2000" width="6000" height="4000"/>'
            '</clipPath>' % (side, clip_x))
    return ci_compose(zones, ci_nucs(elong_nucs(side)), back, strands, cpx, front, clip)


# A passing fork's panel: the origin as the origin panel draws it, crossed by
# a fork from a neighbouring origin. Its positions run far enough past both
# edges that the fork enters and leaves off the page, and its daughters are
# drawn as that fork makes them, from an origin far to the side.
CI_PASS_RANGE = (-14, NPOS + 14)
CI_PASS_SPLIT = {'r': -40, 'l': NPOS + 40}


def rrm3_actor(side):
    """Rrm3, the accessory helicase that travels with the fork and takes off
    the double hexamer the fork pushes ahead of it."""
    x = fork_base(side)
    t = 1.0 if side == 'r' else -1.0
    return actor('rrm3-' + side, inner('rrm3in-' + side,
                 '<g class="vib">%s</g>' % protein(x + t * 30.0, DNA_Y - 100.0, 36, 'Rrm3', 'rrm3', h=15)),
                 basex=x)


def ci_pass_body(side, bob1=False):
    """VIEW: a fork from a neighbouring origin crossing an unfired origin (TERMINAL).

    The origin is the origin panel's: its ORC, its licensed double hexamer
    with step 7's actor, the ARS and the nucleosomes at their places. The
    fork is step 11's machinery with Rrm3. The double hexamer sits in a
    wrapper the painter slides ahead of the fork and then lifts away, which
    is the CMG pushing it and Rrm3 removing it (Hill et al., bioRxiv 2020).
    """
    lo, hi = CI_PASS_RANGE
    zones, strands, cpx = ci_strip(lo, hi, CI_PASS_SPLIT[side], ars=True)
    dhb, dhf = dh_actor(phos=True, phos_pending=True, fits=('sld3', 'cdc45p'), nsd='displaced',
                        mcm2p='pending', bob1=('5',) if bob1 else (), graded=True)
    fb, ff = split(fork_actors(side=side, vib=True, bob1=('5',) if bob1 else ()))
    back = (fx('fx-orcback', orc_ring(ARS_X, ORC_Y), state='fading')
            + '<g id="actor-dhpush-b" class="act">%s</g>' % dhb + fb)
    front = '<g id="actor-dhpush" class="act">%s</g>' % dhf + ff + rrm3_actor(side)
    return ci_compose(zones, ci_nucs(NUC_SPANS), back, strands, cpx, front)


# Termination: two forks from neighbouring origins meeting in the middle of the
# panel. Positions left of the meeting point are copied by a fork moving right
# from an origin far to the left, positions right of it by a fork moving left
# from an origin far to the right, so each half carries its own fork's
# continuous and Okazaki daughters.
CI_TERM_RANGE = (-14, NPOS + 14)
CI_TERM_M = 23                       # the last position the rightward fork copies
CI_TERM_SPLIT = {'l': -40, 'r': NPOS + 40}


def term_actors(side):
    """VIEW: what ends one fork: SCF-Dia2, the ubiquitin chain on Mcm7, Cdc48 (TERMINAL).

    Each rides the fork's CMG at its base x. A frame brings each in from above
    the page; when Cdc48 extracts the CMG all three leave upward with it.
    """
    x = fork_base(side)
    chain = ''.join('<circle class="ubq" cx="%.1f" cy="%.1f" r="4.2"/>' % (x + 9.0 * k, DNA_Y - 36.0 - 7.0 * k)
                    for k in range(4))
    return (actor('dia2-' + side, protein(x, DNA_Y - 112.0, 62, 'SCF-Dia2', 'dia2', h=16), basex=x)
            + actor('ubq-' + side, fx('fx-ubq-' + side, chain, state='gone'), basex=x)
            + actor('cdc48-' + side, protein(x, DNA_Y - 84.0, 52, 'Cdc48', 'cdc48', h=18), basex=x))


def ci_term_body(bob1=False):
    """VIEW: two converging forks and the end of replication between them (TERMINAL).

    Both forks are step 11's machinery. They close the gap, their CMGs pass
    each other onto double-stranded DNA, SCF-Dia2 ubiquitylates Mcm7 and
    Cdc48 extracts each CMG (Maric et al. 2014). The painter sets every
    position and actor per frame.
    """
    lo, hi = CI_TERM_RANGE
    zl, sl, cl = ci_strip(lo, CI_TERM_M, CI_TERM_SPLIT['l'])
    zr, sr, cr = ci_strip(CI_TERM_M + 1, hi, CI_TERM_SPLIT['r'])
    back, front = split(fork_actors(vib=True, bob1=('5',) if bob1 else ()))
    front += term_actors('r') + term_actors('l')
    return ci_compose(zl + zr, '', back, sl + sr, cl + cr, front)


# The centromere close-up. One CEN at molecular scale: the CDE elements, the
# Cse4 nucleosome and the kinetochore built on it, with a microtubule from the
# pole above the page. Forks arrive from both sides; once the CEN is copied the
# two sisters lie apart, held by cohesin, and the sister kinetochore takes a
# microtubule from the pole below. In anaphase cohesin is gone and the sisters
# part. Without Rad53 a fork collapses short of the CEN and Exo1 resects toward
# it; when resection reaches the CEN the Cse4 nucleosome is lost and the
# kinetochore lets go. Distances between forks, fronts and the CEN are drawn
# closer than they are. Every state is a frame in CI_CEN_STATES.
CEN_X, CEN_W = 350.0, 46.0
CEN_SIS = 32.0                       # each sister's axis from the unreplicated axis
CEN_X0, CEN_X1 = 20.0, 680.0         # the drawn stretch, wider than the close-up's window
CEN_STALL = 170.0                    # where the collapsed fork's polymerases stopped
CEN_RISE = 26.0                      # length of the curve where a strand changes height
# Each strand's height in each stretch, about DNA_Y: a sister (copied), the
# unwound stretch ahead of a stalled fork, and the duplex.
CEN_ROWS = {'top': {'sis': -CEN_SIS - 4.5, 'uw': -14.0, 'dup': -4.5},
            'bot': {'sis': CEN_SIS + 5.5, 'uw': 13.0, 'dup': 4.5}}
CEN_NEW = {'top': -CEN_SIS + 4.0, 'bot': CEN_SIS - 4.0}
# The DNA of each state: its stretches left to right, and where the new
# strands end on the left (Exo1 resects them back from the stalled ends).
CEN_DNA = {
    'single': {'spans': [(20.0, 680.0, 'dup')]},
    'forks': {'spans': [(20.0, 170.0, 'sis'), (170.0, 560.0, 'dup'), (560.0, 680.0, 'sis')]},
    'near': {'spans': [(20.0, 290.0, 'sis'), (290.0, 410.0, 'dup'), (410.0, 680.0, 'sis')]},
    'collapse': {'spans': [(20.0, 170.0, 'sis'), (170.0, 196.0, 'uw'), (196.0, 680.0, 'dup')], 'exo': 170.0},
    'resect1': {'spans': [(20.0, 170.0, 'sis'), (170.0, 246.0, 'uw'), (246.0, 680.0, 'dup')], 'exo': 148.0},
    'resect2': {'spans': [(20.0, 170.0, 'sis'), (170.0, 300.0, 'uw'), (300.0, 680.0, 'dup')], 'exo': 126.0},
    'lost': {'spans': [(20.0, 170.0, 'sis'), (170.0, 436.0, 'uw'), (436.0, 680.0, 'dup')], 'exo': 104.0},
}


def strand_course(spans, y, rows, rise):
    """MODEL: one strand's path along stretches of set heights, curved at each change of height (TERMINAL)

    spans is [(x0, x1, mode)] left to right; rows maps a mode to its height
    about y. Each change is a cubic curve of length rise centred on the
    boundary, its control points level with the two heights, so the strand
    leaves one height and arrives at the next without a corner.
    """
    x0, _, m0 = spans[0]
    d = ['M%.1f %.1f' % (x0, y + rows[m0])]
    for (a0, a1, ma), (b0, b1, mb) in zip(spans, spans[1:]):
        if rows[ma] == rows[mb]:
            continue
        h = rise / 2.0
        d.append('H%.1f C%.1f %.1f %.1f %.1f %.1f %.1f' % (a1 - h, a1, y + rows[ma], a1, y + rows[mb], a1 + h, y + rows[mb]))
    d.append('H%.1f' % spans[-1][1])
    return ' '.join(d)


def cen_dna(spec):
    """VIEW: one centromere-close-up state's DNA as whole strands, new strands and RPA (TERMINAL)"""
    spans, exo = spec['spans'], spec.get('exo')
    out = []
    for side in ('top', 'bot'):
        out.append('<path class="dnapar" d="%s"/>' % strand_course(spans, DNA_Y, CEN_ROWS[side], CEN_RISE))
    for x0, x1, mode in spans:
        if mode != 'sis':
            continue
        h = CEN_RISE / 2.0
        a = x0 + (h if x0 > CEN_X0 else 0.0)
        b = min(x1 - (h if x1 < CEN_X1 else 0.0), exo if exo is not None and x0 < exo else x1)
        for side in ('top', 'bot'):
            out.append('<path class="dnanew" d="M%.1f %.1f H%.1f"/>' % (a, DNA_Y + CEN_NEW[side], b))
        if exo is not None and x0 < exo:
            # The resected stretch: each sister's parental strand single, coated by RPA.
            for k, x in enumerate(range(int(exo) + 4, int(x1) - 6, 26)):
                out.append(wedge(x, DNA_Y - CEN_SIS + 2, 8, 'rpaglyph', ''))
                out.append(wedge(x + 11, DNA_Y + CEN_SIS - 0.5, 8, 'rpaglyph', ''))
        if mode == 'sis':
            pass
    for x0, x1, mode in spans:
        if mode != 'uw':
            continue
        # The unwound stretch: both parental strands single, coated by RPA between them.
        for k, x in enumerate(range(int(x0) + 24, int(x1) - 14, 28)):
            out.append(wedge(x, DNA_Y - 2.5, 9, 'rpaglyph', 'RPA' if k % 2 == 0 else ''))
            out.append(wedge(x + 13, DNA_Y + 10.5, 9, 'rpaglyph', ''))
    return ''.join(out)
CEN_NUCS = (214.0, 258.0, 300.0, 404.0, 448.0)   # nucleosomes on the unreplicated duplex beside the CEN
CI_CEN_STATES = ['single', 'forks', 'near', 'copied', 'anaphase', 'collapse', 'resect1', 'resect2', 'lost']


def cen_kinetochore(sign):
    """VIEW: one kinetochore on its Cse4 nucleosome, built toward the pole on sign's side (TERMINAL)

    sign -1 builds upward, +1 downward. Inner to outer: the Cse4 nucleosome on
    the CEN, the Ctf19 complex (COMA), MIND (Mtw1), the Ndc80 complex as two
    rods, and the Dam1 ring around the microtubule tip.
    """
    y0 = DNA_Y
    def yy(d):
        return y0 + sign * d
    rods = ''.join('<path class="cenndc80" d="M%.1f %.1f L%.1f %.1f"/>' % (CEN_X + dx, yy(66), CEN_X + dx * 0.4, yy(100))
                   for dx in (-12.0, 12.0))
    return ('<ellipse class="cse4nuc" cx="%.1f" cy="%.1f" rx="30" ry="17"/>'
            '<text class="glyphlab sm" x="%.1f" y="%.1f">Cse4</text>' % (CEN_X, y0, CEN_X, y0 + 4)
            + protein(CEN_X, yy(34), 78, 'Ctf19 (COMA)', 'ctf19', h=16)
            + protein(CEN_X, yy(54), 60, 'Mtw1 (MIND)', 'mind', h=14)
            + rods + '<text class="glyphlab sm" x="%.1f" y="%.1f">Ndc80</text>' % (CEN_X + 34, yy(86))
            + '<ellipse class="cendam1" cx="%.1f" cy="%.1f" rx="15" ry="5"/>' % (CEN_X, yy(102))
            + '<text class="glyphlab sm" x="%.1f" y="%.1f">Dam1</text>' % (CEN_X - 34, yy(104)))


def cen_strand_rows(dy, top_parent):
    """VIEW: one sister, a parental strand paired by rungs to a new strand, about axis dy (TERMINAL)"""
    yp = DNA_Y + dy + (-7.0 if top_parent else 3.0)
    yn = DNA_Y + dy + (2.0 if top_parent else -6.0)
    return ('<rect class="bar" x="%.1f" y="%.1f" width="%.1f" height="5"/>'
            '<rect class="cennew" x="%.1f" y="%.1f" width="%.1f" height="4"/>'
            '<rect class="cende" x="%.1f" y="%.1f" width="%.1f" height="11" rx="2"/>'
            % (CEN_X0, yp, CEN_X1 - CEN_X0, CEN_X0, yn, CEN_X1 - CEN_X0,
               CEN_X - CEN_W / 2, min(yp, yn), CEN_W))


def ci_cen_body():
    """VIEW: the centromere close-up, every object any state shows (TERMINAL)"""
    w = CEN_X1 - CEN_X0
    duplex = ('<rect class="bar" x="%.1f" y="%.1f" width="%.1f" height="5"/>'
              '<rect class="bar" x="%.1f" y="%.1f" width="%.1f" height="5"/>'
              % (CEN_X0, DNA_Y - 7, w, CEN_X0, DNA_Y + 2, w))
    cde = ('<g id="fx-cencde" class="fx present"><rect class="cende" x="%.1f" y="%.1f" width="%.1f" height="14" rx="2"/>'
           '<text class="glyphlab sm" x="%.1f" y="%.1f">CEN (CDE I, II, III)</text></g>'
           % (CEN_X - CEN_W / 2, DNA_Y - 7, CEN_W, CEN_X, DNA_Y + 32))
    # The sisters are -top and -bot: a -b suffix is the engine's far-layer twin.
    sisters = ('<g id="actor-cens-top" class="act">%s</g><g id="actor-cens-bot" class="act">%s</g>'
               % (cen_strand_rows(-CEN_SIS, True), cen_strand_rows(CEN_SIS, False)))
    gap = '<rect class="cengap" x="%.1f" y="%.1f" width="%.1f" height="18"/>' % (CEN_X0, DNA_Y - 11, w)
    copies = ''
    for side, x0 in (('l', CEN_X0 - w), ('r', CEN_X1)):
        copies += ('<clipPath id="cp-cen-%s"><rect id="actor-cencp-%s" class="act" x="%.1f" y="-400" width="%.1f" '
                   'height="900"/></clipPath><g clip-path="url(#cp-cen-%s)">%s%s</g>'
                   % (side, side, x0, w, side, gap, sisters.replace('actor-cens-', 'actor-cens%s-' % side)))
    # Every state but the copied and anaphase ones draws its DNA as whole
    # strands (cen_dna): each parental strand runs the width of the panel and
    # bends on a curve where it passes from a sister to the unwound stretch or
    # to the duplex, so the DNA reads as one molecule. A collapsed fork sits
    # at CEN_STALL: ahead of it the runaway helicase leaves two RPA-coated
    # single strands, and behind it Exo1 resects the new strands.
    dna = ''.join('<g id="fx-cendna-%s" class="fx gone">%s</g>' % (st, cen_dna(spec))
                  for st, spec in sorted(CEN_DNA.items()))
    stall = ('<g id="fx-censtall" class="fx gone"><path class="censtall" d="M%.1f %.1f V%.1f"/>'
             '<text class="glyphlab sm" x="%.1f" y="%.1f">stalled ends</text></g>'
             % (CEN_STALL, DNA_Y - CEN_SIS - 14, DNA_Y + CEN_SIS + 14, CEN_STALL, DNA_Y + CEN_SIS + 26))
    nucs = ''.join('<g id="fx-cennuc-%d" class="fx gone"><ellipse class="nucbody" cx="%.1f" cy="%.1f" rx="17" '
                   'ry="15"/><text class="glyphlab sm lt" x="%.1f" y="%.1f">nuc</text></g>'
                   % (k + 1, x, DNA_Y, x, DNA_Y + 3) for k, x in enumerate(CEN_NUCS))
    res = dna + stall + nucs
    mt = lambda ident, sign: ('<clipPath id="cp-cen-%s"><rect x="%.1f" y="%.1f" width="40" height="%.1f"/></clipPath>'
                              '<g clip-path="url(#cp-cen-%s)"><g id="actor-%s" class="act"><rect class="cenmt" '
                              'x="%.1f" y="%.1f" width="12" height="%.1f" rx="5"/></g></g>'
                              % (ident, CEN_X - 20, -400 if sign < 0 else DNA_Y + 100, 400 + DNA_Y - 100 if sign < 0 else 400,
                                 ident, ident, CEN_X - 6, -400 if sign < 0 else DNA_Y + 100, 400 + DNA_Y - 100 if sign < 0 else 400))
    coh = ''.join('<ellipse class="cencoh" cx="%.1f" cy="%.1f" rx="9" ry="%.1f"/>' % (x, DNA_Y, CEN_SIS + 12)
                  for x in (190.0, 250.0, 460.0, 520.0))
    coh += '<text class="glyphlab sm" x="190" y="%.1f">cohesin</text>' % (DNA_Y + CEN_SIS + 26)
    cmg = lambda side: actor('cencmg-' + side, '<g id="fx-cencmg-%s" class="fx gone">%s</g>' % (
        side, protein(CEN_X, DNA_Y, 44, 'CMG', 'cmgbox', h=26)), basex=CEN_X)
    # Exo1 on the new strand's end: the nuclease, its mouth on the strand, and
    # the nucleotides it releases behind it.
    exo_glyph = (protein(CEN_X - 4, DNA_Y - CEN_SIS - 26, 40, 'Exo1', 'exo1', h=15)
                 + '<path class="exomouth" d="M%.1f %.1f l7 -4 a8 8 0 1 0 0 8 z"/>'
                 % (CEN_X + 2, DNA_Y - CEN_SIS - 12)
                 + ''.join('<circle class="dnmp" cx="%.1f" cy="%.1f" r="2.2"/>' % (CEN_X + dx, DNA_Y - CEN_SIS - 12 + dy)
                           for dx, dy in ((12, -10), (19, -4), (15, 4)))
                 + protein(CEN_X - 4, DNA_Y + CEN_SIS + 26, 40, 'Exo1', 'exo1', h=15)
                 + '<path class="exomouth" d="M%.1f %.1f l7 -4 a8 8 0 1 0 0 8 z"/>'
                 % (CEN_X + 2, DNA_Y + CEN_SIS + 12)
                 + ''.join('<circle class="dnmp" cx="%.1f" cy="%.1f" r="2.2"/>' % (CEN_X + dx, DNA_Y + CEN_SIS + 12 + dy)
                           for dx, dy in ((12, 10), (19, 4), (15, -4))))
    exo = actor('cenexo', '<g id="fx-cenexo" class="fx gone">%s</g>' % exo_glyph, basex=CEN_X)
    # The runaway helicase: the CMG with Pol epsilon, at the close-up's scale.
    kb, kf = cmg_actor('r', pole=True)
    run = actor('cenrun', '<g id="fx-cenrun" class="fx gone">%s</g>'
                % mini(kb + kf, DH_X + MCM_HALF, DNA_Y, CEN_X, DNA_Y, 0.62), basex=CEN_X)
    note = '<text id="txt-cennote" class="glyphlab sm lt" x="%.1f" y="%.1f">not to scale along the DNA</text>' % (
        CEN_X + 120, DNA_Y + 140)
    back = ('<g id="fx-cendup" class="fx present">%s</g>' % duplex) + copies + res + cde
    front = (mt('mt-top', -1) + '<g id="fx-cenmt2" class="fx gone">%s</g>' % mt('mt-bot', 1)
             + '<g id="fx-cenkt1" class="fx present"><g id="actor-cenkt1" class="act">%s</g></g>' % cen_kinetochore(-1)
             + '<g id="fx-cenkt2" class="fx gone"><g id="actor-cenkt2" class="act">%s</g></g>' % cen_kinetochore(1)
             + '<g id="fx-cencoh" class="fx gone">%s</g>' % coh + cmg('l') + cmg('r') + run + exo + note)
    return '<g class="ciclip">' + back + front + '</g>'


def ci_cen_frames():
    """MODEL: the centromere close-up's frame for each state (TERMINAL)

    Each frame names every wrapper and actor, so any one paints on its own.
    The copied and anaphase states draw the sisters as two actors that part
    in anaphase; every other state shows its own whole-strand drawing
    (CEN_DNA). A collapsed fork's frames place the runaway helicase (run) and
    Exo1 (exo).
    """
    w = CEN_X1 - CEN_X0
    def frame(st, cmgl=None, cmgr=None, sis=0.0, kt1=0.0, kt2=None, mt1=0.0, coh=False,
              run=None, exo=None, lost=False):
        spans = CEN_DNA[st]['spans'] if st in CEN_DNA else []
        whole = st in CEN_DNA
        fx = {'fx-cendup': 'gone', 'fx-cenkt1': 'fading' if lost else 'present',
              'fx-cencde': 'gone' if (kt2 is not None or lost) else 'present',
              'fx-cenkt2': 'present' if kt2 is not None else 'gone', 'fx-cenmt2': 'present' if kt2 is not None else 'gone',
              'fx-cencoh': 'present' if coh else 'gone',
              'fx-cencmg-l': 'gone' if cmgl is None else 'present',
              'fx-cencmg-r': 'gone' if cmgr is None else 'present',
              'fx-cenrun': 'present' if run is not None else 'gone',
              'fx-censtall': 'present' if run is not None else 'gone',
              'fx-cenexo': 'present' if exo is not None else 'gone'}
        for k in CEN_DNA:
            fx['fx-cendna-' + k] = 'present' if k == st else 'gone'
        for k, x in enumerate(CEN_NUCS):
            on = whole and any(a <= x <= b and m == 'dup' for a, b, m in spans) and (run is None or x > run + 24.0)
            fx['fx-cennuc-%d' % (k + 1)] = 'present' if on else 'gone'
        full = 0.0 if whole else w / 2.0 + 10.0
        act = {'actor-cencp-l': [full, 0], 'actor-cencp-r': [-full, 0],
               'actor-censl-top': [0, -sis], 'actor-censl-bot': [0, sis], 'actor-censr-top': [0, -sis], 'actor-censr-bot': [0, sis],
               'actor-cenkt1': [0, kt1], 'actor-cenkt2': [0, kt2 or 0.0], 'actor-mt-top': [0, mt1],
               'actor-mt-bot': [0, sis], 'actor-cencmg-l': [(cmgl or CEN_X) - CEN_X, 0],
               'actor-cencmg-r': [(cmgr or CEN_X) - CEN_X, 0],
               'actor-cenrun': [(run or CEN_X) - CEN_X, 0],
               'actor-cenexo': [(exo or CEN_X) - CEN_X, 0]}
        return {'fx': fx, 'actors': act}
    return {
        'single': frame('single'),
        'forks': frame('forks', cmgl=170, cmgr=560),
        'near': frame('near', cmgl=290, cmgr=410),
        'copied': frame('copied', kt1=-CEN_SIS, kt2=CEN_SIS, coh=True),
        'anaphase': frame('anaphase', sis=36.0, kt1=-CEN_SIS - 36.0, kt2=CEN_SIS + 36.0, mt1=-36.0),
        'collapse': frame('collapse', run=196.0, exo=CEN_DNA['collapse']['exo']),
        'resect1': frame('resect1', run=246.0, exo=CEN_DNA['resect1']['exo']),
        'resect2': frame('resect2', run=300.0, exo=CEN_DNA['resect2']['exo']),
        'lost': frame('lost', run=436.0, exo=CEN_DNA['lost']['exo'], kt1=-240.0, mt1=-240.0, lost=True),
    }


def cen_still(state, prefix):
    """VIEW: the centromere close-up frozen at one of its states, its ids prefixed so two stills can share a page (TERMINAL)

    The same body and frame the live close-up plays, with each wrapper set to
    the state's visibility and each actor to the state's offset, so a figure
    built from it shows exactly what the close-up shows at that state.
    """
    body = ci_cen_body()
    frame = ci_cen_frames()[state]
    for ident, st in frame['fx'].items():
        body = re.sub(r'id="%s" class="fx [a-z]+"' % re.escape(ident), 'id="%s" class="fx %s"' % (ident, st), body)
    for ident, (dx, dy) in frame['actors'].items():
        body = body.replace('id="%s" class="act"' % ident, 'id="%s" class="act" transform="translate(%.1f %.1f)"' % (ident, dx, dy))
    return body.replace('id="', 'id="%s-' % prefix).replace('url(#', 'url(#%s-' % prefix)


def rif2_glyph(x, y, r=16.0):
    """VIEW: Rif2 as the telomere panels draw it, a violet disc carrying its name (TERMINAL)"""
    return ('<g class="prot rif2glyph"><circle class="telrif2" cx="%.1f" cy="%.1f" r="%.1f"/>'
            '<text class="glyphlab sm rif2lab" x="%.1f" y="%.1f">Rif2</text></g>' % (x, y, r, x, y + 3.5))


def checkpoint_actor(side):
    """VIEW: what reads a stalled fork, drawn on the fork (TERMINAL).

    Ddc2 binds the RPA coat and brings Mec1; Mec1 marks Mrc1 (the star on
    Mrc1 rides mrc_actor) and then Rad53 once it docks there; Rad53 marks
    itself, and one copy leaves for its targets while the docked one stays to
    hold the fork. Without Rad53 the dock stays empty. Every part sits in an
    inner group a frame can bring in or send off, and the arrows are the
    kinase arrows of the step panels, shown on the frame the mark lands.
    """
    x = fork_base(side)
    t = 1.0 if side == 'r' else -1.0
    mx, my = x - t * CI_MEC_DX, DNA_Y + 44.0
    rx, ry = x - t * CI_R53_DX, DNA_Y - CI_R53_DY
    mrc = (x, DNA_Y - MRC_DY)
    mec = (protein(mx, my - 9.0, 34, 'Ddc2', 'ddc2', h=15)
           + protein(mx, my + 8.0, 38, 'Mec1', 'mec1', h=17))
    burst = '<g transform="translate(%.1f %.1f) scale(0.62) translate(%.1f %.1f)">%s</g>' % (
        rx, ry, -rx, -ry, kinase_burst(rx, ry, 'Rad53'))
    r53 = ('<g class="rad53k">%s</g>' % burst
           + fx('fx-r53p1-' + side, phos_star(rx - 15.0, ry + 12.0))
           + fx('fx-r53p2-' + side, phos_star(rx + 15.0, ry + 12.0)))
    copy = '<g class="rad53k">%s</g>' % burst
    k1 = kin_ends((mx, my - 18.0), (mrc[0] - t * 20.0, mrc[1] + 6.0))
    k2 = kin_ends((mx + t * 10.0, my - 18.0), (rx - 15.0, ry + 18.0))
    gone = protein(rx, ry, 40, 'no Rad53', 'r53none gonebox', h=16)
    return actor('chk-' + side,
                 inner('mecin-' + side, mec)
                 + fx('fx-kmrc-' + side, kin_arrow(k1[0][0], k1[0][1], k1[1][0], k1[1][1]))
                 + fx('fx-kr53-' + side, kin_arrow(k2[0][0], k2[0][1], k2[1][0], k2[1][1]))
                 + fx('fx-nor53-' + side, gone)
                 + inner('r53in-' + side, inner('r53x-' + side, copy) + r53),
                 basex=x)


def ci_origin_frames():
    """MODEL: the origin panel's frame for each state the close-up can show (TERMINAL).

    Each frame names every position's strand and complex value and every
    wrapper, so any one of them paints correctly on its own. 'opened' is the
    tracks of step 11's last frame: the origin copied out to both edges.
    """
    # Off the page: Cdc6 above and left of ORC (where steps 2 to 5 bring it
    # from and send it), the double hexamer above the pair (it is loaded in
    # steps 3 to 5, which the origin panel does not play).
    cdc6_off, dh_off = (-289.0, -275.0), (0.0, -300.0)

    def frame(t, fxs, dh=(0, 0), cdc6=cdc6_off, out=0.0):
        tr = {}
        for i in range(1, NPOS + 1):
            row = t[i - 1]
            tr[chunk_id(i) + '-s'] = '%s:present:%s' % (row[0], row[2])
            tr[chunk_id(i) + '-c'] = '%s:%s:%s:%s' % (row[1], row[5], row[3], row[4])
        return {'tracks': tr, 'fx': fxs, 'actors': {'actor-dhout': list(dh), 'actor-cdc6ci': list(cdc6),
                                                     'actor-forkout-l': [-out, 0], 'actor-forkout-r': [out, 0]}}

    def engaged(cdc6):
        t = tracks_default()
        set_cpx(t, ARS_A, ARS_B, 'orc')
        set_kink(t, ARS_A, ARS_B, 'kink-fixed' if cdc6 else 'kink-transient')
        return t

    def marks(k):
        # The first k of the pair's four marks shown, in the order DDK places them.
        out = {'fx-phos': 'present' if k else 'gone'}
        for j, site in enumerate(MCM_MARK_ORDER):
            out['fx-pm-' + site] = 'present' if j < k else 'gone'
        return out

    near = dict({'fx-orcfront': 'present', 'fx-orcback': 'gone'}, **marks(0))
    far = lambda k: dict({'fx-orcfront': 'gone', 'fx-orcback': 'fading'}, **marks(k))
    last = load_anim_table()['step11']['frames'][-1]['tracks']
    t11 = tracks_default()
    set_cpx(t11, ARS_A, ARS_B, 'orc')
    set_cpx_state(t11, ARS_A, ARS_B, 'fading')
    set_cpx(t11, DH[0], DH[1], 'cmg')
    set_kink(t11, ARS_A, ARS_B, 'kink-fixed')
    set_gate(t11, DH[0], DH[1], 'gate-sealed')
    set_strand(t11, 'o07', 'o12', 'extruded')
    for ident, val in last.items():
        if ident.endswith('-s'):
            t11[lin(ident[:-2]) - 1][0] = val.split(':')[0]
    passive = licensed_tracks('displaced')
    for i in range(NPOS):
        passive[i][0] = 'replicated'
    return {'orc': frame(engaged(False), near, dh_off),
            'cdc6': frame(engaged(True), near, dh_off, (0.0, 0.0)),
            'lic': frame(licensed_tracks('seated'), far(0)),
            'mark1': frame(licensed_tracks('seated'), far(1)),
            'mark2': frame(licensed_tracks('seated'), far(2)),
            'mark3': frame(licensed_tracks('seated'), far(3)),
            'mark': frame(licensed_tracks('displaced'), far(4)),
            'bob': frame(licensed_tracks('released'), far(0)),
            'opened': frame(t11, far(0)),
            'cleared': frame(t11, far(0), out=float(VBW) / 2.0),
            'passiveR': frame(passive, far(4), (VBW, 0)),
            'passiveL': frame(passive, far(4), (-VBW, 0))}


def write_inset(root, svg):
    """VIEW: write the close-up for tools/make_shell.py to place under the chromosome chart (TERMINAL)"""
    with open(os.path.join(root, 'src', 'chrom-inset.svg'), 'w', encoding='utf-8') as f:
        f.write(svg)


def write_chrom_geom(root, geom):
    """VIEW: write CHROM_GEOM for the page (TERMINAL)"""
    with open(os.path.join(root, 'src', 'chrom-geom.js'), 'w', encoding='utf-8') as f:
        f.write('/* Generated by tools/make_panels.py. Do not edit.\n'
                '   The geometry the live chromosome panel was drawn with, so\n'
                '   src/chrom-frames.js places copies, strips and meters to match. */\n'
                'var CHROM_GEOM = %s;\n'
                "if (typeof window !== 'undefined') { window.CHROM_GEOM = CHROM_GEOM; }\n"
                "if (typeof module !== 'undefined') { module.exports = CHROM_GEOM; }\n"
                % json.dumps(geom, indent=1))



# ===========================================================================
# NAVIGATION
# ---------------------------------------------------------------------------
# Three charts: the main line, the context panels, and the firing models for
# CST. Phase is stated only by the cell-cycle axis in the left margin, which
# appears on every page, so no panel carries a phase band or a phase chip.
# The axis is a narrow coloured strip beside the step column and not a wide band
# in the right margin: the right margin is where the context badges hang off
# each step, and a step with five of them ran under the axis and off the chart.
# ===========================================================================

NAV_W = 340
NODE_W, NODE_H, PITCH, Y0, COL_X = 200, 34, 52, 40, 32
AXIS_X, AXIS_W = 4, 18
BADGE_X, BADGE_PITCH = COL_X + NODE_W + 8, 20

STEP_NODES = [
    ('step01', '1', 'ORC binds', 'the ARS'),
    ('step02', '2', 'Cdc6 closes', 'the ring'),
    ('step03', '3', 'Cdt1 delivers Mcm2-7,', 'first hexamer loads'),
    ('step04', '4', 'Cdc6 returns', 'to the notch'),
    ('step05', '5', 'Cdt1 delivers the second,', 'licensed origin'),
    ('step06', '6', 'Dbf4 displaces the NSD,', 'DDK marks the tails'),
    ('step07', '7', 'Sld3-Sld7 clasps the', 'pair, reads the mark'),
    ('step08', '8', 'S-CDK marks', 'Sld2 and Sld3'),
    ('step09', '9', 'Dpb11 delivers GINS,', 'Cdc45 seats, CMG forms'),
    ('step10', '10', 'Mcm10 arrives, origin', 'melts and extrudes'),
    ('step11', '11', 'Replisome and', 'bidirectional fork'),
]

CONTEXT_GROUPS = [
    ('Legends', [
        ('ctxARS', 'L1', 'ARS anatomy and', 'the drawn scale'),
        ('ctxORC', 'L2', 'ORC subunit', 'architecture'),
        ('ctxMCM', 'L3', 'Mcm2-7 subunit', 'and ring'),
        ('ctxDH', 'L4', 'The double hexamer', 'in every state'),
        ('ctxCHROM', 'L5', 'Nucleosome-free', 'region and phasing'),
    ]),
    ('Regulation', [
        ('regCDK', 'R1', 'S-CDK separates', 'loading from firing'),
        ('regCDC6', 'R2', 'Cdc6 proteolysis', 'by SCF'),
        ('regMCM', 'R3', 'Mcm2-7 export', 'and G1 SUMOylation'),
        ('regCDT1', 'R4', 'Cdt1 export and', 'the Orc6 block'),
        ('regRIF1', 'R5', 'Rif1-PP1 opposes', 'the DDK marks'),
    ]),
    ('Alternatives', [
        ('altDH01', 'C1', 'Second load through', 'ORC-Cdc6'),
        ('altDH02', 'C2', 'First hexamer', 'templates the second'),
    ]),
    ('Perturbations', [
        ('offQC', 'P1', 'Cdc6 ATPase', 'quality control'),
        ('offATP', 'P2', 'Mcm2 Walker A,', 'Mcm6 arginine finger'),
        ('offCDT1N', 'P3', 'Cdt1 N-terminal', 'deletion'),
        ('offDDK', 'P4', 'No DDK: the NSD', 'stays seated'),
        ('offMCM4N', 'P5', 'Mcm4 N-terminal', 'deletion'),
        ('offPHOS', 'P6', 'Mcm4 and Mcm6', 'phosphomimetic'),
        ('offBOB1', 'P7', 'The bob1 allele', 'of Mcm5'),
    ]),
]

# Which main-line step each context panel hangs off. Duplicated as
# CONTEXT_PARENT in src/data.js and asserted by the test suite.
CONTEXT_PARENT = {
    'ctxARS': 'step01', 'ctxORC': 'step01', 'ctxMCM': 'step03', 'ctxDH': 'step05',
    'ctxCHROM': 'step01',
    'regCDK': 'step08', 'regCDC6': 'step04', 'regMCM': 'step05', 'regCDT1': 'step03',
    'regRIF1': 'step06',
    'altDH01': 'step05', 'altDH02': 'step05',
    'offQC': 'step03', 'offATP': 'step03', 'offCDT1N': 'step05',
    'offDDK': 'step07',
    'offMCM4N': 'step06', 'offPHOS': 'step06', 'offBOB1': 'step06',
}

CONTEXT_BADGE = dict((k, num) for _, rows in CONTEXT_GROUPS for k, num, _, _ in rows)

# The third chart. Every node on it is a proposal of the dissertation's and not
# a finding from the literature, which is why it is a chart of its own: the
# boundary between the two is the first thing a reader sees on opening it.
#
# Two nodes are parents. Each draws the models nested under it on one panel,
# because those models can act together: the DDK-dependent route carries M1 to
# M3, and the models downstream of the Rad53 block carry M5 to M7. A child is
# indented under its parent and joined to it by a rule. Nesting says the
# children are parts of one picture; it is a different claim from the bracket,
# which joins the two ejection mechanisms as competing accounts of one step and
# names what separates them, the idiom the second-load pair uses on the context
# chart. The bracket keeps that meaning inside the nesting.
MODEL_GROUPS = [
    ('DDK-dependent route', [
        ('cstDDK', '', 'DDK-dependent route:', 'M1 to M3 on one pair'),
        ('cstCONF', 'M1', 'Mcm2-7 conformation:', 'Cdc7 marks the NSD readily'),
        ('cstCDC7', 'M2', 'Cdc7 retention: CST on', 'Dbf4 holds Cdc7 on the NSD'),
        ('cstRIF1', 'M3', 'Rif1-PP1 inhibition,', 'not the sole route'),
    ]),
    ('DDK-independent route', [
        ('cstBOB1', 'M4', 'Conformation without', 'DDK: Mcm5 surface, Sld3'),
        ('cstDOWN', '', 'Downstream of the', 'Rad53 block: M5 to M7'),
        ('cstEJSS', 'M5', 'Ejection: Stn1 N fold', 'holds the lagging strand'),
        ('cstEJPR', 'M6', 'Ejection: Stn1 C region', 'holds Mcm2 and Mcm5'),
        ('cstPOLA', 'M7', 'Pol alpha stimulation,', 'after the origin unwinds'),
    ]),
]
MODEL_PAIR = ('cstEJSS', 'cstEJPR')

# Which parent each nested model sits under. Duplicated as MODEL_NEST in
# src/data.js and asserted by the test suite.
MODEL_NEST = {
    'cstCONF': 'cstDDK', 'cstCDC7': 'cstDDK', 'cstRIF1': 'cstDDK',
    'cstEJSS': 'cstDOWN', 'cstEJPR': 'cstDOWN', 'cstPOLA': 'cstDOWN',
}

# Which main-line step each model acts at. Duplicated as MODEL_PARENT in
# src/data.js and asserted by the test suite. Drives the second row of badges
# on the steps chart, which is the overview of where every model acts. A
# nested model keeps its step here and takes no badge: its parent's badge is
# the one on the chart, and the models chart reaches the children.
MODEL_PARENT = {
    'cstDDK': 'step06', 'cstCONF': 'step06', 'cstCDC7': 'step06', 'cstRIF1': 'step06',
    'cstBOB1': 'step07', 'cstDOWN': 'step10', 'cstEJSS': 'step10', 'cstEJPR': 'step10',
    'cstPOLA': 'step11',
}

# A parent's badge carries the name the dissertation gives that group, from
# its section and subsection titles. A standalone model keeps its number.
MODEL_NAMES = {'cstDDK': 'DDK-dependent route',
               'cstDOWN': 'Downstream of the Rad53 block'}
MODEL_BADGE = dict((k, num or MODEL_NAMES[k])
                   for _, rows in MODEL_GROUPS for k, num, _, _ in rows)
MODEL_KEYS = [k for _, rows in MODEL_GROUPS for k, _, _, _ in rows]

NEST_IN = 16                  # how far a child node is indented under its parent

# Cell-cycle bands, given as (label, slug, first row, last row) on the steps
# page. The slug drives the colour, which is the one thing on the chart that
# carries a fact rather than a position: the same phase is the same colour on
# both pages and in the same order every time.
STEP_CYCLE = [('late M', 'm', 0, 0), ('G1', 'g1', 1, 4),
              ('G1/S', 'g1s', 5, 7), ('S', 's', 8, 10)]


def cycle_axis(y1, y2, bands):
    """The phase strip down the left margin.

    Labels are rotated because the strip is narrow enough to sit beside the
    step column instead of competing with the context badges for the right
    margin. Rotating about the anchor point moves the visual centre of the text
    3.2 units left of it, so the anchor is placed that far right of the band
    centre and the glyphs land on it.
    """
    out = ['<g class="cycleaxis">']
    for name, slug, a, b in bands:
        top = y1 + a
        bot = y1 + b
        cx_ = AXIS_X + AXIS_W / 2.0
        cy_ = (top + bot) / 2.0
        out.append('<rect class="cycleband phase-%s" x="%d" y="%.1f" width="%d" '
                   'height="%.1f" rx="4"/>'
                   % (slug, AXIS_X, top, AXIS_W, max(bot - top, 8)))
        out.append('<text class="cyclelab phase-%s" x="%.1f" y="%.1f" '
                   'transform="rotate(-90 %.1f %.1f)">%s</text>'
                   % (slug, cx_ + 3.2, cy_, cx_ + 3.2, cy_, esc(name)))
    out.append('</g>')
    return ''.join(out)


def nav_node(key, num, l1, l2, x, y, w, kind):
    out = ['<g class="navnode %s" data-key="%s">' % (kind, key)]
    out.append('<rect class="navbox" x="%d" y="%.1f" width="%d" height="%d" rx="4"/>'
               % (x, y, w, NODE_H))
    out.append('<text class="navnum" x="%d" y="%.1f">%s</text>' % (x + 7, y + 14, num))
    out.append('<text class="navtext" x="%d" y="%.1f">%s</text>' % (x + 28, y + 14, esc(l1)))
    out.append('<text class="navtext" x="%d" y="%.1f">%s</text>' % (x + 28, y + 26, esc(l2)))
    out.append('</g>')
    return ''.join(out)


def nav_svg(page):
    """Emit one navigation chart. page is 'steps', 'context' or 'models'."""
    if page == 'steps':
        return _nav_steps()
    if page == 'models':
        return _nav_models()
    if page == 'chromosome':
        return _nav_chromosome()
    return _nav_context()


def nav_badge(key, label, x, y, kind):
    """One badge on the steps chart, linking to a panel on another chart.

    kind is 'ctxb' for a context panel and 'modelb' for a firing model, so the
    two can be told apart on the chart and dropped separately by the figure
    exporter. A badge is as wide as its label needs and never narrower than a
    number badge; a label too wide for the room left before the chart edge
    wraps onto a second line. Returns the markup and the width taken.
    """
    room = NAV_W - x - 4.0
    rows = [label] if text_width(label, 8.0) + 8.0 <= room else wrap_text(label, 8.0,
                                                                       room - 8.0)
    w = max(17.0, max(text_width(r, 8.0) for r in rows) + 8.0) if len(label) > 3 else 17.0
    h = 14.0 + 10.0 * (len(rows) - 1)
    text = ''.join('<text class="navbadgelab" x="%.1f" y="%.1f">%s</text>'
                   % (x + w / 2.0, y + 11 + 10.0 * k, esc(r)) for k, r in enumerate(rows))
    return ('<g class="navbadge %s" data-goto="%s"><rect class="navbadgebox" x="%.1f" '
            'y="%.1f" width="%.1f" height="%.1f" rx="3"/>%s</g>'
            % (kind, key, x, y, w, h, text), w)


def _nav_steps():
    rows = len(STEP_NODES)
    h = Y0 + rows * PITCH + 20
    out = ['<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 %d %d" id="navsvg-steps" '
           'class="navchart">' % (NAV_W, h)]
    out.append(defs('navsteps'))
    ys = [Y0 + r * PITCH for r in range(rows)]
    out.append(cycle_axis(0, h, [(n, s, ys[a], ys[b] + NODE_H)
                                 for n, s, a, b in STEP_CYCLE]))
    for r in range(rows - 1):
        out.append('<path class="navedge main" d="M%d %.1f L%d %.1f" marker-end='
                   '"url(#ah-navsteps)"/>'
                   % (COL_X + NODE_W / 2, ys[r] + NODE_H, COL_X + NODE_W / 2, ys[r + 1] - 2))
    children, models = {}, {}
    for ctx, parent in CONTEXT_PARENT.items():
        children.setdefault(parent, []).append(ctx)
    for mod, parent in MODEL_PARENT.items():
        # A nested model is reached through its parent's badge.
        if mod not in MODEL_NEST:
            models.setdefault(parent, []).append(mod)
    for r, (key, num, l1, l2) in enumerate(STEP_NODES):
        out.append(nav_node(key, num, l1, l2, COL_X, ys[r], NODE_W, 'main'))
        kids = sorted(children.get(key, []), key=lambda k: CONTEXT_BADGE[k])
        mods = sorted(models.get(key, []), key=MODEL_KEYS.index)
        # A step with models carries two rows: context above, models below.
        # Five badges is all a row holds before the chart edge, so one row
        # could not take both kinds on a step that carries several of each.
        top = ys[r] + 2 if mods else ys[r] + NODE_H / 2 - 7
        for j, ctx in enumerate(kids):
            out.append(nav_badge(ctx, CONTEXT_BADGE[ctx], BADGE_X + j * BADGE_PITCH,
                                 top, 'ctxb')[0])
        bx = BADGE_X
        for mod in mods:
            mark, w = nav_badge(mod, MODEL_BADGE[mod], bx, ys[r] + 18, 'modelb')
            out.append(mark)
            bx += w + BADGE_PITCH - 17
    out.append('</svg>')
    return ''.join(out)


def _nav_context():
    y = Y0
    body = []
    pair_y = None
    for name, rows in CONTEXT_GROUPS:
        body.append('<text class="navgrouplab" x="%d" y="%.1f">%s</text>' % (COL_X, y, name))
        # The group that carries the disagreement bracket needs room for the
        # bracket's own label, which would otherwise be drawn on top of the
        # group heading.
        y += 30 if any(k == 'altDH01' for k, _, _, _ in rows) else 14
        for key, num, l1, l2 in rows:
            kind = 'pair' if key.startswith('alt') else 'ctx'
            body.append(nav_node(key, num, l1, l2, COL_X, y, NODE_W, kind))
            if key == 'altDH01':
                pair_y = y
            y += PITCH
        y += 12
    h = y + 10
    out = ['<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 %d %.1f" '
           'id="navsvg-context" class="navchart">' % (NAV_W, h)]
    out.append(defs('navctx'))
    out.append(cycle_axis(0, h, [('cell cycle', 'all', 30, h - 20)]))
    out.extend(body)
    # The pairing bracket. The two accounts are drawn side by side, and the
    # label says how the loading intermediates relate them.
    out.append('<g class="pairbracket"><path class="pairline" d="M%d %.1f L%d %.1f L%d %.1f '
               'L%d %.1f"/><text class="pairlab" x="%d" y="%.1f">second load: two accounts, '
               'one mechanism</text></g>'
               % (COL_X, pair_y - 6, COL_X, pair_y - 12, COL_X + NODE_W, pair_y - 12,
                  COL_X + NODE_W, pair_y + 2 * PITCH - 10,
                  COL_X + NODE_W / 2, pair_y - 16))
    out.append('</svg>')
    return ''.join(out)


def _nav_models():
    """The firing models for CST, grouped by route, with each parent's models
    nested under it and the ejection pair bracketed."""
    y = Y0
    body = []
    pair_y = None
    rules = {}
    for name, rows in MODEL_GROUPS:
        body.append('<text class="navgrouplab" x="%d" y="%.1f">%s</text>' % (COL_X, y, name))
        y += 14
        for key, num, l1, l2 in rows:
            child = key in MODEL_NEST
            x, w = (COL_X + NEST_IN, NODE_W - NEST_IN) if child else (COL_X, NODE_W)
            if key == MODEL_PAIR[0]:
                # The pair does not open its group, so the room its bracket
                # label needs goes above the pair and not under the heading.
                y += 18
                pair_y = y
            if child:
                kind = 'model modelchild modelpair' if key in MODEL_PAIR else \
                    'model modelchild'
                rules.setdefault(MODEL_NEST[key], [None, []])[1].append(y + NODE_H / 2.0)
            elif key in MODEL_NAMES:
                kind = 'model modelparent'
                rules.setdefault(key, [None, []])[0] = y + NODE_H
            else:
                kind = 'model'
            body.append(nav_node(key, num, l1, l2, x, y, w, kind))
            y += PITCH
            if key == MODEL_PAIR[1]:
                # The bracket closes under the pair, so the node after it needs
                # the space the closing tick takes.
                y += 8
        y += 12
    h = y + 10
    out = ['<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 %d %.1f" '
           'id="navsvg-models" class="navchart">' % (NAV_W, h)]
    out.append(defs('navmodels'))
    out.append(cycle_axis(0, h, [('cell cycle', 'all', 30, h - 20)]))
    # The nesting rule: down from the parent along the indent, with a tick to
    # each child. Drawn under the nodes so the ticks meet the boxes cleanly.
    for parent, (top, mids) in rules.items():
        rx = COL_X + NEST_IN / 2.0
        d = ['M%.1f %.1f L%.1f %.1f' % (rx, top, rx, mids[-1])]
        d += ['M%.1f %.1f L%d %.1f' % (rx, m, COL_X + NEST_IN, m) for m in mids]
        out.append('<path class="nestline" data-parent="%s" d="%s"/>' % (parent, ' '.join(d)))
    out.extend(body)
    px0, px1 = COL_X + NEST_IN, COL_X + NODE_W
    out.append('<g class="pairbracket"><path class="pairline" d="M%d %.1f L%d %.1f L%d %.1f '
               'L%d %.1f"/><text class="pairlab" x="%d" y="%.1f">ejection: which Stn1 region '
               'acts at the gate</text></g>'
               % (px0, pair_y - 6, px0, pair_y - 12, px1, pair_y - 12,
                  px1, pair_y + 2 * PITCH - 10,
                  (px0 + px1) / 2, pair_y - 16))
    out.append('</svg>')
    return ''.join(out)


def _nav_chromosome():
    """The chromosome chart: one node, the live panel."""
    y = Y0
    body = ['<text class="navgrouplab" x="%d" y="%.1f">One chromosome, live</text>' % (COL_X, y)]
    y += 14
    for key, num, l1, l2 in CHROM_NODES:
        body.append(nav_node(key, num, l1, l2, COL_X, y, NODE_W, 'chrom'))
        y += PITCH
    h = y + 10
    out = ['<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 %d %.1f" '
           'id="navsvg-chromosome" class="navchart">' % (NAV_W, h)]
    out.append(defs('navchrom'))
    out.append(cycle_axis(0, h, [('cell cycle', 'all', 30, h - 20)]))
    out.extend(body)
    out.append('</svg>')
    return ''.join(out)


CHROM_NODES = [('chrLIVE', 'C1', 'Firing program', 'pick a genotype, run it')]


# ===========================================================================
# MAIN
# ===========================================================================

def audit_nsd():
    """Fail the build if the NSD stops controlling access to the clasp floor.

    Between them these assertions are the whole claim the NSD makes on the page.
    The seated block stands proud of the profile the clasp is cut to, deep
    enough to read. The clasp in offDDK comes to rest just clear of that block,
    so it is stopped by the NSD and by nothing else. The displaced NSD hangs
    above the profile everywhere except its mark, and the mark lies inside the
    clasp wall where the cleft is cut, so the clasp takes the displaced pair.

    This lives here and not in the behavioural suite because the suite asserts
    that paired fits meet, and a fit that must not meet is the one thing it is
    built to reject.
    """
    bad = []
    pts = dh_bottom_profile(DH_X, DNA_Y)
    poly = nsd_seat_poly(DH_X, DNA_Y)

    def lowest(poly_, x):
        # MODEL: the lowest point of the block at one x (TERMINAL)
        ys = []
        for (x1, y1), (x2, y2) in zip(poly_, poly_[1:] + poly_[:1]):
            if min(x1, x2) - 1e-6 <= x <= max(x1, x2) + 1e-6 and abs(x2 - x1) > 1e-6:
                ys.append(y1 + (y2 - y1) * (x - x1) / (x2 - x1))
        return max(ys) if ys else None

    xs = [min(p[0] for p in poly) + 0.25 * k
          for k in range(int((max(p[0] for p in poly) - min(p[0] for p in poly)) / 0.25) + 1)]
    proud = max((lowest(poly, x) or 0.0) - profile_y(pts, x) for x in xs)
    if proud < 10.0:
        bad.append('the seated NSD stands only %.1f proud of the pair, too little to read'
                   % proud)
    frames = load_anim_table().get('offDDK', {}).get('frames', [])
    dys = [f['actors']['actor-sld3'][1] for f in frames
           if isinstance((f.get('actors') or {}).get('actor-sld3'), list)]
    if not dys:
        bad.append('offDDK has no clasp frames to check the stop against')
    else:
        # The clasp rises until it stops. Its nearest approach is the smallest
        # downward offset any frame gives it.
        stop = float(min(dys))
        gap = stop - proud
        if gap < 0.3:
            bad.append('the offDDK clasp overlaps the seated NSD by %.1f' % -gap)
        elif gap > 2.0:
            bad.append('the offDDK clasp stops %.1f short of the seated NSD, so the NSD is '
                       'not what stops it' % gap)
    sx, sy = nsd_star_point(DH_X, DNA_Y)
    top, foot = sy - PHOS_R / 2.0, sy + PHOS_R / 2.0
    floor = profile_y(pts, sx)
    if top < floor - 0.1 or foot > floor + SLD_T + 0.1:
        bad.append('the NSD mark at %.1f..%.1f is not inside the clasp wall %.1f..%.1f'
                   % (top, foot, floor, floor + SLD_T))
    for px_, py_ in nsd_tail_points(DH_X, DNA_Y, 'displaced')[:-1]:
        py_floor = profile_y(pts, px_)
        if py_floor is not None and py_ > py_floor + 0.1:
            bad.append('the displaced NSD tail runs below the pair at x %.1f' % px_)
            break
    # The released form has to clear the floor it would otherwise block. Every
    # vertex of the block and every point of its tail stays above the underside,
    # so the clasp, which is cut to the bare profile, meets nothing.
    rel = nsd_release_poly(DH_X, DNA_Y) + nsd_tail_points(DH_X, DNA_Y, 'released')
    for px_, py_ in rel:
        py_floor = profile_y(pts, px_)
        if py_floor is not None and py_ > py_floor - 0.5:
            bad.append('the released NSD reaches the underside at x %.1f' % px_)
            break
    if min(p[1] for p in rel) < SAFE_PAD or max(p[0] for p in rel) > VBW - SAFE_PAD:
        bad.append('the released NSD runs off the canvas')
    # The floor has to keep its step, or the clasp would go on either way round.
    if abs(pts[0][1] - pts[-1][1]) < MCM_ROW_PITCH / 4.0:
        bad.append('the clasp floor has lost the half-row step')
    if bad:
        raise SystemExit('NSD geometry: \n  %s' % '\n  '.join(bad))


def audit_marks():
    """CONTROLLER: fail the build if a DDK mark appears out of the order the
    model claims.

    The Mcm4 and Mcm6 marks land in step 6. The Mcm2 marks do not: they sit in
    fx-mcm2p, which step 6 must not emit, which step 7 must emit hidden and
    bring in no earlier than the clasp has seated, and which every later panel
    that draws the pair must show at rest. The behavioural suite checks that a
    frame table and its markup agree; what it cannot see is whether either one
    says the right thing about the order, which is what this checks.

    Python needs the nested functions defined before the calls that use them,
    so the sub-controllers come first and the coordination is at the bottom.
    """

    # === SUB-CONTROLLERS ===

    def find_faults():
        """SUB-CONTROLLER: collect every ordering fault from markup and frames."""

        def load_markup():
            """MODEL: the markup of the four panels that carry the pair (TERMINAL)"""
            return dict((key, PANEL_FNS[key]())
                        for key in ('step06', 'step07', 'step08', 'step09'))

        def load_step07_frames():
            """MODEL: the step07 frame table (TERMINAL)"""
            return load_anim_table().get('step07', {}).get('frames', [])

        def markup_faults(markup):
            """MODEL: faults in what each panel emits at rest (TERMINAL)"""
            bad = []
            if 'fx-mcm2p' in markup['step06']:
                bad.append('step06 draws the Mcm2 marks, which arrive only once Sld3 is on')
            if '<g id="fx-mcm2p" class="fx gone">' not in markup['step07']:
                bad.append('step07 does not emit the Mcm2 marks hidden at rest')
            for key in ('step08', 'step09'):
                if '<g id="fx-mcm2p" class="fx present">' not in markup[key]:
                    bad.append('%s does not show the Mcm2 marks at rest' % key)
            return bad

        def frame_faults(frames):
            """MODEL: faults in when step07 brings the Mcm2 marks in (TERMINAL)"""
            seated = next((k for k, fr in enumerate(frames)
                           if (fr.get('actors') or {}).get('actor-sld3') == [0.0, 0.0]),
                          None)
            first = next((k for k, fr in enumerate(frames)
                          if (fr.get('fx') or {}).get('fx-mcm2p', 'gone') != 'gone'),
                         None)
            if first is None:
                return ['step07 never brings the Mcm2 marks in']
            if seated is None or first <= seated:
                return ['step07 brings the Mcm2 marks in at frame %s, before the clasp '
                        'has seated' % first]
            return []

        markup = load_markup()
        frames = load_step07_frames()
        return markup_faults(markup) + frame_faults(frames)

    def report_faults(bad):
        """SUB-CONTROLLER: stop the build if any fault was found."""

        def fail_build(bad):
            """VIEW: print the faults and exit (TERMINAL)"""
            raise SystemExit('DDK marks: \n  %s' % '\n  '.join(bad))

        if bad:
            fail_build(bad)

    # === COORDINATE SUB-CONTROLLERS ===

    faults = find_faults()
    report_faults(faults)


# Each phosphorylation arrow, the mark wrapper whose arrival it draws, and the
# kinase it leaves, with the offset that kinase must have on that frame.
KIN_EVENTS = [
    ('step06', 'fx-kin-ddk-4', 'fx-phos', 'actor-ddk', (DH_X - DDK_X, 0.0)),
    ('step06', 'fx-kin-ddk-6', 'fx-phos', 'actor-ddk', (DH_X - DDK_X, 0.0)),
    ('step08', 'fx-kin-sld2', 'fx-sld2p', 'actor-scdk', SCDK_AT_SLD2),
    ('step08', 'fx-kin-sld3', 'fx-sld3p', 'actor-scdk', SCDK_AT_SLD3),
]


def audit_kinase():
    """CONTROLLER: fail the build if a phosphorylation arrow is shown on any
    frame but the one its mark arrives, or leaves a kinase that is not there.

    The arrow is the drawn form of a transfer, so it belongs to one frame: the
    first on which the mark is no longer gone. Shown earlier it would draw a
    transfer before the kinase reached its substrate; shown later it would turn
    an event into a standing relation. Its tail is computed from the offset the
    generator expects the kinase to have on that frame, so the frame table has
    to give that offset or the arrow starts from empty space.

    Python needs the nested functions defined before the calls that use them,
    so the sub-controllers come first and the coordination is at the bottom.
    """

    # === SUB-CONTROLLERS ===

    def find_faults():
        """SUB-CONTROLLER: collect every fault from the frame tables."""

        def load_tables():
            """MODEL: the frame tables of the panels that draw an arrow (TERMINAL)"""
            tab = load_anim_table()
            return dict((key, tab.get(key, {}).get('frames', []))
                        for key, _, _, _, _ in KIN_EVENTS)

        def event_faults(frames, key, arrow_id, mark_id, kinase, want):
            """MODEL: faults for one arrow (TERMINAL)"""
            first = next((k for k, fr in enumerate(frames)
                          if (fr.get('fx') or {}).get(mark_id, 'gone') != 'gone'), None)
            if first is None:
                return ['%s never brings %s in' % (key, mark_id)]
            shown = [k for k, fr in enumerate(frames)
                     if (fr.get('fx') or {}).get(arrow_id, 'gone') == 'present']
            bad = []
            if shown != [first]:
                bad.append('%s shows %s on frames %s; it belongs on frame %d alone, where '
                           '%s arrives' % (key, arrow_id, shown, first, mark_id))
            off = (frames[first].get('actors') or {}).get(kinase, 0.0)
            off = tuple(float(v) for v in off) if isinstance(off, list) else (float(off), 0.0)
            if off != tuple(float(v) for v in want):
                bad.append('%s frame %d puts %s at %s; %s is drawn from %s'
                           % (key, first, kinase, off, arrow_id, want))
            return bad

        tables = load_tables()
        bad = []
        for key, arrow_id, mark_id, kinase, want in KIN_EVENTS:
            bad += event_faults(tables[key], key, arrow_id, mark_id, kinase, want)
        return bad

    def report_faults(bad):
        """SUB-CONTROLLER: stop the build if any fault was found."""

        def fail_build(bad):
            """VIEW: print the faults and exit (TERMINAL)"""
            raise SystemExit('phosphorylation arrows: \n  %s' % '\n  '.join(bad))

        if bad:
            fail_build(bad)

    # === COORDINATE SUB-CONTROLLERS ===

    faults = find_faults()
    report_faults(faults)


def audit_cdc45():
    """CONTROLLER: fail the build if the partly seated Cdc45 stops saying what
    the structures say.

    Before GINS, Cdc45 sits on Mcm5 and stands off Mcm2. That is two numeric
    claims about one glyph: its Mcm5 corner lands on the Mcm5 seat, and its
    Mcm2 corner lands CDC45_TILT_HOLD off the Mcm2 seat, away from the
    hexamer. The partial fit is also only ever offered on a closed gate, since
    a sealed gate is the one GINS has braced. The behavioural suite checks that
    paired fits meet; it cannot see that the unpaired corner stands off by the
    right amount, which is what this checks.

    Python needs the nested functions defined before the calls that use them,
    so the sub-controllers come first and the coordination is at the bottom.
    """

    # === SUB-CONTROLLERS ===

    def find_faults():
        """SUB-CONTROLLER: collect every fault in the partial seat."""

        def corner_faults():
            """MODEL: faults in where the two corners land, both sides (TERMINAL)"""
            bad = []
            for side, hx, skew in (('left', DH_X - MCM_HALF, -MCM_DH_SKEW),
                                   ('right', DH_X + MCM_HALF, MCM_DH_SKEW)):
                s2 = mcm_seat(hx, DNA_Y, '2', side, skew)
                s5 = mcm_seat(hx, DNA_Y, '5', side, skew)
                pivot = (s2[0], s2[1] + MCM_ROW_PITCH)
                if abs(pivot[0] - s5[0]) > 0.05 or abs(pivot[1] - s5[1]) > 0.05:
                    bad.append('%s Cdc45 Mcm5 corner misses the Mcm5 seat' % side)
                c = cdc45_corner(s2[0], s2[1], side, partial=True)
                off = (c[0] - s2[0]) * (-1.0 if side == 'left' else 1.0)
                if abs(off - CDC45_TILT_HOLD) > 0.05:
                    bad.append('%s Cdc45 Mcm2 corner stands off by %.2f, not %.2f'
                               % (side, off, CDC45_TILT_HOLD))
            return bad

        def gate_faults():
            """MODEL: faults in which gate carries the partial fit (TERMINAL)"""
            bad = []
            for key in ('step07', 'step08', 'offMCM4N', 'offPHOS', 'offBOB1'):
                svg = PANEL_FNS[key]()
                if 'cdc45p-mcm5' not in svg:
                    bad.append('%s draws the clasp Cdc45 without its Mcm5 fit' % key)
                if 'gate-sealed' in svg:
                    bad.append('%s offers the partial fit on a sealed gate' % key)
            for key in ('step09', 'step10', 'step11'):
                if 'cdc45p-mcm5' in PANEL_FNS[key]():
                    bad.append('%s claims a partial Cdc45 fit after GINS' % key)
            return bad

        return corner_faults() + gate_faults()

    def report_faults(bad):
        """SUB-CONTROLLER: stop the build if any fault was found."""

        def fail_build(bad):
            """VIEW: print the faults and exit (TERMINAL)"""
            raise SystemExit('Cdc45 seat: \n  %s' % '\n  '.join(bad))

        if bad:
            fail_build(bad)

    # === COORDINATE SUB-CONTROLLERS ===

    faults = find_faults()
    report_faults(faults)


def main():
    here = os.path.dirname(os.path.abspath(__file__))
    root = os.path.dirname(here)
    pdir = os.path.join(root, 'src', 'panels')
    os.makedirs(pdir, exist_ok=True)
    audit_nsd()
    audit_marks()
    audit_kinase()
    audit_cdc45()
    offsets = load_frame_offsets()
    # Every file is written as UTF-8, as build.py reads it, so the output does
    # not depend on the platform's default codec (cp1252 on Windows).
    for key, fn in PANEL_FNS.items():
        svg = fn()
        audit_panel(key, svg, offsets)
        with open(os.path.join(pdir, key + '.svg'), 'w', encoding='utf-8') as f:
            f.write(svg)
    # The live chromosome panel holds every object any run can show, and the
    # page builds its frames, so it is audited at rest. Stale chromosome panels
    # from earlier builds are removed so dist/ does not inline them.
    for name in os.listdir(pdir):
        if name.startswith('chr') and name.endswith('.svg') and name != 'chrLIVE.svg':
            os.remove(os.path.join(pdir, name))
    live_svg, live_geom, live_views = build_live_view()
    # Each view is audited alone: the page never shows both layers at once.
    for view in live_views:
        audit_panel('chrLIVE', view, {'chrLIVE': {}})
    with open(os.path.join(pdir, 'chrLIVE.svg'), 'w', encoding='utf-8') as f:
        f.write(live_svg)
    write_chrom_geom(root, live_geom)
    write_inset(root, build_inset_view())
    for page, name in (('steps', 'nav-steps.svg'), ('context', 'nav-context.svg'),
                       ('models', 'nav-models.svg'), ('chromosome', 'nav-chromosome.svg')):
        with open(os.path.join(root, 'src', name), 'w', encoding='utf-8') as f:
            f.write(nav_svg(page))
    print('wrote %d panels, chrom-geom.js and four charts' % (len(PANEL_FNS) + 1))


if __name__ == '__main__':
    main()