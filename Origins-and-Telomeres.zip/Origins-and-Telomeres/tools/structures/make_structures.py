"""Reduce the ChimeraX structure assets to what the lesson draws.

    python3 tools/structures/make_structures.py

Reads mcm_structure_assets.zip (written by export_mcm_structure_assets.py in
ChimeraX) and writes structures-lesson.json beside it. make_tour.py embeds that
file as window.TOUR_STRUCTURES, and tour.js draws each scene with WebGL.

What this keeps. Only the scenes in SCENES. Each chain surface is welded (the
ChimeraX surface repeats a vertex wherever two atom patches meet), then
decimated to the triangle budget of its group, so the double hexamer turns in
the browser at full frame rate. Colors are the per-vertex colors ChimeraX drew,
carried onto the decimated vertices. ChimeraX "lighting soft" shades by ambient
occlusion from many directions; this script bakes that occlusion into one value
per vertex per scene, so the browser shades each scene the way ChimeraX does
while the model turns.

Anchors. Every scene names its chains by subunit, and in a double hexamer by
the side of the double hexamer the chain sits on in the scene's camera ('L' or
'R'). Each anchor is the front-most surface point near the chain's centre on
screen, with its surface normal, so a marker can sit on the chain and fade when
the chain turns away.

Requires numpy and fast-simplification (pip install fast-simplification).
"""

import base64
import json
import os
import sys
import zipfile

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
ARCHIVE = os.path.join(HERE, 'mcm_structure_assets.zip')
OUTPUT = os.path.join(HERE, 'structures-lesson.json')

SCENES = ('arch_pair', 'arch_closed', 'ddk_profile', 'ddk_face', 'ddk_ring')
TRIANGLES = {'DNA': 8000, 'Dbf4': 30000, 'Cdc7': 30000}   # per chain surface; every other group gets DEFAULT_TRIANGLES
DEFAULT_TRIANGLES = 30000
SMOOTHING = 0             # Taubin passes after decimation; none at this budget, so the surface keeps the ChimeraX shape
AO_DIRECTIONS = 96        # directions over the sphere for the baked occlusion
AO_CELL = 1.6             # Angstroms; depth-map cell size
AO_BIAS = 3.0             # Angstroms a surface point may sit behind the front depth and still count as lit
ANCHOR_SPREAD = 0.45      # fraction of a chain's screen radius searched for its front-most point


def main():
    """BASE CONTROLLER: read the archive, reduce the meshes, bake each scene, write the lesson file."""

    def load_archive(path):
        # MODEL: the manifest and a reader for its binary files (TERMINAL)
        archive = zipfile.ZipFile(path)
        return {'manifest': json.loads(archive.read('manifest.json')), 'zip': archive}

    def reduce_meshes(store):
        """SUB-CONTROLLER: every mesh the kept scenes draw, welded, decimated, with the map from old vertices to new"""

        def used_meshes(manifest):
            # MODEL: mesh ids drawn by the kept scenes (TERMINAL)
            return sorted({part['mesh'] for key in SCENES for part in manifest['scenes'][key]['parts']})

        def decode_mesh(store, mesh_id):
            # MODEL: quantized positions, positions in Angstroms and triangles of one stored mesh (TERMINAL)
            info, archive = store['manifest']['meshes'][mesh_id], store['zip']
            q = np.frombuffer(archive.read(info['positions']['file']), '<u2').reshape(-1, 3)
            tri = np.frombuffer(archive.read(info['triangles']['file']), info['triangles']['dtype']).reshape(-1, 3)
            pos = np.array(info['positions']['offset']) + q * np.array(info['positions']['scale'])
            return {'q': q, 'pos': pos, 'tri': tri.astype(np.int64), 'group': info['group']}

        def weld_and_decimate(mesh):
            # MODEL: shared vertices merged, the surface decimated to its budget, and old-to-new vertex map (TERMINAL)
            import fast_simplification as fs
            unique, inverse = np.unique(mesh['q'], axis=0, return_inverse=True)
            inverse = inverse.reshape(-1)
            welded = mesh['pos'][np.unique(inverse, return_index=True)[1]].astype(np.float32)
            tri = inverse[mesh['tri']]
            keep = (tri[:, 0] != tri[:, 1]) & (tri[:, 1] != tri[:, 2]) & (tri[:, 0] != tri[:, 2])
            tri = np.ascontiguousarray(tri[keep].astype(np.int32))
            budget = TRIANGLES.get(mesh['group'], DEFAULT_TRIANGLES)
            if len(tri) <= budget:
                return {'pos': welded, 'tri': tri, 'map': inverse, 'group': mesh['group']}
            _, _, collapses = fs.simplify(welded, tri, target_count=budget, return_collapses=True)
            pos, tri2, mapping = fs.replay_simplification(welded, tri, collapses)
            pos = pos.astype(np.float64)
            edges = np.concatenate([tri2[:, [0, 1]], tri2[:, [1, 2]], tri2[:, [2, 0]]])
            edges = np.concatenate([edges, edges[:, ::-1]])
            degree = np.bincount(edges[:, 0], minlength=len(pos))[:, None].astype(np.float64)
            for _ in range(SMOOTHING):
                for factor in (0.5, -0.53):
                    mean = np.zeros_like(pos)
                    np.add.at(mean, edges[:, 0], pos[edges[:, 1]])
                    pos = pos + factor * (mean / np.maximum(degree, 1) - pos)
            return {'pos': pos.astype(np.float32), 'tri': tri2.astype(np.int32), 'map': mapping[inverse], 'group': mesh['group']}

        out = {}
        for mesh_id in used_meshes(store['manifest']):
            out[mesh_id] = weld_and_decimate(decode_mesh(store, mesh_id))
        return out

    def bake_scenes(store, meshes):
        """SUB-CONTROLLER: per scene, the colors, occlusion and anchors of every part"""

        def part_colors(store, part, mesh):
            # MODEL: one RGB per decimated vertex, from the part's color or palette (TERMINAL)
            n = len(mesh['pos'])
            if 'color' in part:
                return np.tile(np.array(part['color'][:3], np.uint8), (n, 1))
            index = np.frombuffer(store['zip'].read(part['color_index']['file']), part['color_index']['dtype'])
            palette = np.array(part['palette'], np.uint8)[:, :3]
            new = np.zeros(n, np.int64)
            new[mesh['map']] = index
            return palette[new]

        def scene_geometry(scene, meshes):
            # MODEL: every part's vertices in scene coordinates, its normals, and its triangles offset into one list (TERMINAL)
            verts, norms, tris, owner, base = [], [], [], [], 0
            for k, part in enumerate(scene['parts']):
                mesh = meshes[part['mesh']]
                m = np.array(part['transform'])
                p = mesh['pos'] @ m[:, :3].T + m[:, 3]
                t = mesh['tri']
                fn = np.cross(p[t[:, 1]] - p[t[:, 0]], p[t[:, 2]] - p[t[:, 0]])
                n = np.zeros_like(p)
                for c in range(3):
                    np.add.at(n, t[:, c], fn)
                n /= np.maximum(np.linalg.norm(n, axis=1, keepdims=True), 1e-9)
                verts.append(p)
                norms.append(n)
                tris.append(t + base)
                owner.append(np.full(len(p), k))
                base += len(p)
            return {'v': np.vstack(verts), 'n': np.vstack(norms), 't': np.vstack(tris), 'owner': np.concatenate(owner)}

        def bake_occlusion(geo):
            # MODEL: share of the visible hemisphere each vertex sees, from depth maps over many directions (TERMINAL)
            v, n, t = geo['v'], geo['n'], geo['t']
            bary = np.array([[1/3, 1/3, 1/3], [2/3, 1/6, 1/6], [1/6, 2/3, 1/6], [1/6, 1/6, 2/3],
                             [0.5, 0.5, 0], [0, 0.5, 0.5], [0.5, 0, 0.5]])
            samples = np.vstack([v] + [b[0] * v[t[:, 0]] + b[1] * v[t[:, 1]] + b[2] * v[t[:, 2]] for b in bary])
            k = np.arange(AO_DIRECTIONS) + 0.5
            phi = np.arccos(1 - 2 * k / AO_DIRECTIONS)
            theta = np.pi * (1 + 5 ** 0.5) * k
            dirs = np.stack([np.cos(theta) * np.sin(phi), np.sin(theta) * np.sin(phi), np.cos(phi)], 1)
            lit = np.zeros(len(v))
            total = np.zeros(len(v))
            for d in dirs:
                a = np.cross(d, [1.0, 0, 0] if abs(d[0]) < 0.9 else [0, 1.0, 0])
                a /= np.linalg.norm(a)
                b = np.cross(d, a)
                su, sv, sd = samples @ a, samples @ b, samples @ d
                u0, v0 = su.min(), sv.min()
                iu = ((su - u0) / AO_CELL).astype(np.int64)
                iv = ((sv - v0) / AO_CELL).astype(np.int64)
                width = iu.max() + 1
                depth = np.full(width * (iv.max() + 1), -np.inf)
                np.maximum.at(depth, iv * width + iu, sd)
                cell = iv[:len(v)] * width + iu[:len(v)]
                facing = np.maximum(n @ d, 0)
                visible = sd[:len(v)] >= depth[cell] - AO_BIAS
                lit += facing * visible
                total += facing
            return np.clip(lit / np.maximum(total, 1e-9), 0, 1)

        def scene_anchors(scene, geo, groups):
            # MODEL: per named chain, its front-most surface point near its screen centre, with the normal there (TERMINAL)
            cam = np.array(scene['camera']['position'])
            local = (geo['v'] - cam[:, 3]) @ cam[:, :3]
            lnorm = geo['n'] @ cam[:, :3]
            mcm = np.isin(geo['owner'], [k for k, g in enumerate(groups) if g.startswith('Mcm')])
            centre = local[mcm, :2].mean(axis=0)
            centroids = {k: local[geo['owner'] == k, :2].mean(axis=0) for k in range(len(groups))}
            names, counts = {}, {}
            sizes = {k: int(np.sum(geo['owner'] == k)) for k in range(len(groups))}
            ring_sizes = [sizes[k] for k, g in enumerate(groups) if g.startswith('Mcm')]
            tail = {k for k, g in enumerate(groups) if g.startswith('Mcm') and sizes[k] < 0.5 * np.median(ring_sizes)}
            for k, g in enumerate(groups):
                if k not in tail:
                    counts[g] = counts.get(g, 0) + 1
            for k, g in enumerate(groups):
                if k in tail:
                    names[k] = g + '.tail'
                elif counts[g] > 1 and g.startswith('Mcm'):
                    names[k] = g + ('.L' if centroids[k][0] < centre[0] else '.R')
                else:
                    names[k] = g
            anchors = {}
            for k, name in names.items():
                own = geo['owner'] == k
                pts, nn = local[own], lnorm[own]
                c = pts[:, :2].mean(axis=0)
                r = np.linalg.norm(pts[:, :2] - c, axis=1)
                near = r <= max(ANCHOR_SPREAD * r.max(), 1e-6)
                i = np.flatnonzero(near)[np.argmax(pts[near, 2])]
                world = geo['v'][own][i]
                anchors[name] = {'p': [round(float(x), 2) for x in world],
                                 'n': [round(float(x), 3) for x in geo['n'][own][i]]}
            return {'names': [names[k] for k in range(len(groups))], 'anchors': anchors}

        def view_box(scene, geo):
            # MODEL: the designed camera and the box the drawn geometry fills in it, in camera coordinates (TERMINAL)
            cam = np.array(scene['camera']['position'])
            local = (geo['v'] - cam[:, 3]) @ cam[:, :3]
            lo, hi = local.min(axis=0), local.max(axis=0)
            centre = (lo + hi) / 2
            return {'camera': [[round(float(x), 6) for x in row] for row in cam],
                    'centre': [round(float(x), 3) for x in cam[:, :3] @ centre + cam[:, 3]],
                    'half': [round(float(x), 3) for x in (hi - lo) / 2]}

        out = {}
        for key in SCENES:
            scene = store['manifest']['scenes'][key]
            geo = scene_geometry(scene, meshes)
            ao = bake_occlusion(geo)
            groups = [meshes[p['mesh']]['group'] for p in scene['parts']]
            named = scene_anchors(scene, geo, groups)
            parts = []
            for k, part in enumerate(scene['parts']):
                mesh = meshes[part['mesh']]
                parts.append({'mesh': part['mesh'], 'name': named['names'][k], 'transform': part['transform'],
                              'color': part_colors(store, part, mesh), 'ao': ao[geo['owner'] == k]})
            out[key] = {'parts': parts, 'anchors': named['anchors'], 'view': view_box(scene, geo),
                        'outline': (scene.get('outline') or {}).get('meshes', [])}
        return out

    def encode(meshes, scenes, meta):
        # MODEL: the lesson file: quantized meshes and per-scene colors and occlusion as base64 (TERMINAL)
        def b64(a):
            return base64.b64encode(np.ascontiguousarray(a).tobytes()).decode('ascii')
        used = {p['mesh'] for s in scenes.values() for p in s['parts']}
        mout = {}
        for mesh_id in sorted(used):
            m = meshes[mesh_id]
            lo = m['pos'].min(axis=0)
            scale = np.maximum(m['pos'].max(axis=0) - lo, 1e-6) / 65535.0
            q = np.round((m['pos'] - lo) / scale).astype('<u2')
            idx = m['tri'].astype('<u2' if len(m['pos']) <= 65535 else '<u4')
            mout[mesh_id] = {'group': m['group'], 'offset': [float(x) for x in lo], 'scale': [float(x) for x in scale],
                             'p': b64(q), 't': b64(idx), 'wide': len(m['pos']) > 65535}
        sout = {}
        for key, s in scenes.items():
            sout[key] = {'view': s['view'], 'anchors': s['anchors'], 'outline': s['outline'],
                         'parts': [{'mesh': p['mesh'], 'name': p['name'],
                                    'm': [[round(float(x), 6) for x in row] for row in p['transform']],
                                    'c': b64(p['color'].astype(np.uint8)),
                                    'ao': b64(np.round(p['ao'] * 255).astype(np.uint8))} for p in s['parts']]}
        return {'meta': meta, 'meshes': mout, 'scenes': sout}

    def write_out(path, data):
        # VIEW: the lesson's structure file and a size line (TERMINAL)
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(data, f, separators=(',', ':'))
        print('wrote %s (%.1f MB, %d meshes, %d scenes)' % (path, os.path.getsize(path) / 1e6,
                                                            len(data['meshes']), len(data['scenes'])))

    store = load_archive(ARCHIVE)
    meshes = reduce_meshes(store)
    scenes = bake_scenes(store, meshes)
    meta = {k: store['manifest']['meta'][k] for k in ('entries', 'created', 'chimerax', 'colors')}
    write_out(OUTPUT, encode(meshes, scenes, meta))


if __name__ == '__main__':
    sys.exit(main())
