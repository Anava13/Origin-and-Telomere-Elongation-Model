# =============================================================================
# ChimeraX 3D Structure Assets for the Replication-Initiation lesson
# =============================================================================
# Builds the same scenes as build_mcm_structure_figures.py, with the same chain
# assignment, colors, superposition, hidden chains and cameras, and writes the
# 3D geometry of every scene to one archive in place of PNG images and TikZ
# anchor files.
#
#   Architecture scenes, 5XF8 + 5BK4
#       arch_open    open Cdt1-Mcm2-7 ring (Cdt1 hidden), down its axis, gate at the top
#       arch_closed  one closed ring of the double hexamer on dsDNA, same camera
#       arch_pair    5BK4 double hexamer side view, PAIR_SKEW_DEGREES
#
#   DDK scenes, 7PT6 (first DDK copy shown, other copies hidden)
#       ddk_profile  DDK edge on above the double hexamer
#       ddk_face     DDK facing the viewer
#       ddk_ring     Dbf4-bound ring down its axis, other hexamer hidden
#       The three DDK scenes name the Dbf4 and Cdc7 meshes the figures outline.
#
#   Open and closed scene, 5XF8 + 5BK4
#       openclosed   open ring superposed on a closed ring over Mcm3/4/6/7, then stacked above it
#
#   Glyph legend scenes, 5XF8 + 5V8F + 5BK4
#       ring         open ring down its axis
#       subunit      one Mcm2 from the OCCM along the DNA axis, colored by Pfam domain
#       edge         open and closed rings edge on, far arc lightened
#
# Output: ASSET_FILE (mcm_structure_assets.zip next to this script)
#   manifest.json
#       meta     generator, ChimeraX version, date, entries, colors and constants
#       meshes   one entry per chain surface: entry, chain, subunit group, counts,
#                and the files below. A chain surface shared by several scenes is
#                stored once.
#       scenes   per scene: camera (camera-to-scene 3x4 matrix, orthographic field
#                width in Angstroms, window aspect), parts (mesh id, mesh-to-scene
#                3x4 matrix, one RGBA color or a palette with a per-vertex index
#                file, optional triangle mask), outline mesh ids, and the
#                annotation data of the figure (tips in scene coordinates and in
#                image widths, labels, ring, arcs, spans, crop)
#   meshes/<id>/positions.bin   uint16 x,y,z per vertex; position = offset + value * scale
#   meshes/<id>/triangles.bin   uint16 or uint32 vertex indices, three per triangle
#   meshes/<id>/residues.bin    int16 residue number of the atom under each vertex
#   scenes/<scene>/<id>_colors.bin   uint8 palette index per vertex (multi-color parts only)
#   scenes/<scene>/<id>_mask.bin     packed bits, one per triangle (partly hidden parts only)
#   All binary files are little-endian.
#
# Chains are assigned to subunits from the entity descriptions in each mmCIF,
# so no chain IDs are hardcoded.
#
# Run: runscript "<path to Replication-Initiation>/tools/structures/export_mcm_structure_assets.py"

import hashlib
import json
import os
import re
import zipfile
from datetime import datetime, timezone
import subprocess
import tempfile
import numpy as np
from pathlib import Path

# =============================================================================
# DETECT ENVIRONMENT
# =============================================================================

INSIDE_CHIMERAX = False
try:
    from chimerax.core.commands import run
    INSIDE_CHIMERAX = True
except ModuleNotFoundError:
    pass

# =============================================================================
# EXTERNAL LAUNCHER
# =============================================================================

if not INSIDE_CHIMERAX:
    CHIMERAX_PATH = "C:/Program Files/ChimeraX 1.11.1/bin/ChimeraX.exe"
    script_path = os.path.abspath(__file__).replace("\\", "/")
    cxc_path = os.path.join(tempfile.gettempdir(), "mcm_structure_assets_launch.cxc")
    with open(cxc_path, 'w') as f:
        f.write(f'runscript "{script_path}"')
    subprocess.Popen([CHIMERAX_PATH, cxc_path])
    raise SystemExit(0)

# =============================================================================
# CONFIGURATION
# =============================================================================

SCRIPT_FILE = globals().get("__file__")
ASSET_DIR = Path(SCRIPT_FILE).resolve().parent if SCRIPT_FILE else Path("C:/Users/User/Desktop/Origin_Models")
ASSET_FILE = ASSET_DIR / "mcm_structure_assets.zip"
ASSET_FORMAT = "mcm-structure-assets"
ASSET_VERSION = 1

# --- Deposited entries ---
ARCHITECTURE_ENTRY = "5bk4"   # Mcm2-7 double hexamer on dsDNA, both rings closed
DDK_ENTRY = "7pt6"            # Mcm2-7 double hexamer with Cdc7-Dbf4, state III
OPEN_RING_ENTRY = "5xf8"      # Cdt1-Mcm2-7, ring open between Mcm5 and Mcm2
SUBUNIT_ENTRY = "5v8f"        # OCCM on DNA, Mcm2-7 winged-helix domains engaged with ORC-Cdc6

# --- Subunit groups ---
MCM_SUBUNITS = ("Mcm2", "Mcm3", "Mcm4", "Mcm5", "Mcm6", "Mcm7")
NEAR_ARC_SUBUNITS = ("Mcm2", "Mcm5", "Mcm3")
FAR_ARC_SUBUNITS = ("Mcm6", "Mcm4", "Mcm7")
SUPERPOSE_SUBUNITS = ("Mcm3", "Mcm4", "Mcm6", "Mcm7")
HIDDEN_PARTNERS = ("Cdt1",)

# --- Subunit assignment from mmCIF entity descriptions ---
SUBUNIT_PATTERNS = (
    ("Mcm2", r"\bMCM\s*2\b|maintenance protein\s*2\b"),
    ("Mcm3", r"\bMCM\s*3\b|maintenance protein\s*3\b"),
    ("Mcm4", r"\bMCM\s*4\b|maintenance protein\s*4\b"),
    ("Mcm5", r"\bMCM\s*5\b|maintenance protein\s*5\b"),
    ("Mcm6", r"\bMCM\s*6\b|maintenance protein\s*6\b"),
    ("Mcm7", r"\bMCM\s*7\b|maintenance protein\s*7\b"),
    ("Cdc7", r"\bCDC7\b|division control protein\s*7\b"),
    ("Dbf4", r"\bDBF4\b"),
    ("Cdt1", r"\bCDT1\b|\bTAH11\b"),
)

# --- Colors (match the origin-firing glyphs) ---
SUBUNIT_COLORS = {
    "Mcm2": "red",
    "Mcm3": "orange",
    "Mcm4": "yellow",
    "Mcm5": "green",
    "Mcm6": "blue",
    "Mcm7": "violet",
    "Cdc7": "#5fd3e0",   # light cyan
    "Dbf4": "#c19a6b",   # light brown
    "Cdt1": "tan",
}
DNA_COLOR = "dim gray"
UNASSIGNED_COLOR = "light gray"

# --- Camera ---
CAMERA_DISTANCE = 1000.0   # Angstroms from the target centre, before the view is refit
SKEW_DEGREES = 45.0        # turn about the vertical screen axis; positive turns the right-hand end toward the viewer

# --- Glyph legend and open/closed layout ---
SINGLE_SUBUNIT = "Mcm2"    # subunit laid along the DNA axis in the legend
RING_VIEW_FACE = "N"       # face of the ring toward the viewer in the architecture and legend ring views ("N" or "C")
FAR_ARC_LIGHTEN = 0.5      # fraction of the way to white for Mcm6, Mcm4, Mcm7 in the edge-on panel
STACK_SPACING = 1.3        # centre-to-centre distance of the stacked rings, in closed-ring diameters

# --- Ring order and faces (face-map figure, drawn over the closed-ring image) ---
RING_ORDER = ("Mcm2", "Mcm6", "Mcm4", "Mcm7", "Mcm3", "Mcm5")
FACE_SUBUNITS = {
    "ddk_face": ("Mcm4", "Mcm6", "Mcm2"),   # DDK, Sld3, Sld7
    "cmg_face": ("Mcm2", "Mcm5", "Mcm3"),   # Cdc45, GINS
}

# --- Architecture figure ---
PAIR_SKEW_DEGREES = 20.0      # side-view turn for the double hexamer; small enough that the two rings keep a clean boundary
RING_LABEL_GAP = 0.04         # subunit label distance outside the ring, in image widths
GATE_TIP_GAP = 0.025          # gate arrow tip distance outside the ring, in image widths
GATE_LABEL_GAP = 0.10         # gate label distance outside the ring, in image widths
BRACKET_GAP = 0.03            # bracket height above the double hexamer, in image widths
BRACKET_JUNCTION_GAP = 0.008  # half-gap between the two brackets at the hexamer junction, in image widths
CROP_MARGIN = 4.0             # Angstroms kept around the displayed atoms when the figure crops an image
CHECK_MARKER_LIFT = 5.0       # Angstroms a placed marker sits in front of the structure in the check image

# --- DDK figure ---
DDK_OUTLINE_WIDTH = 12        # outline thickness in pixels on the IMAGE_WIDTH image (about 1.2 pt at 3.2 cm per 100 A)
DDK_OUTLINE_COLOR = (0, 0, 0)
DDK_LABEL_GAP = 0.04          # Dbf4 and Cdc7 label distance beyond the DDK (and above the Mcm top edge in the profile), in image widths
DDK_RING_VIEW_FACE = "N"      # face of the Dbf4-bound ring toward the viewer in the down-axis DDK panel ("N" or "C")

# --- Superposition ---
MIN_SUPERPOSE_ATOMS = 100

# --- Surface export ---
SURFACE_GRID_SPACING = 1.0   # Angstroms; ChimeraX default is 0.5, which gives about four times the vertices and file size
POSITION_LEVELS = 65535      # uint16 quantization steps across each mesh's bounding box

# --- Domain annotation (Pfam through the InterPro API) ---
UNIPROT_ACCESSIONS = {
    "Mcm2": "P29469",
    "Mcm3": "P24279",
    "Mcm4": "P30665",
    "Mcm5": "P29496",
    "Mcm6": "P53091",
    "Mcm7": "P38132",
}
INTERPRO_PFAM_URL = "https://www.ebi.ac.uk/interpro/api/entry/pfam/protein/uniprot/{accession}?page_size=100"
UNIPROT_FASTA_URL = "https://rest.uniprot.org/uniprotkb/{accession}.fasta"
AAA_PFAM_ACCESSIONS = ("PF00493", "PF17855")   # MCM P-loop domain, MCM AAA-lid domain
DOMAIN_SHADES = {"N-terminal": 0.45, "AAA+": 0.0, "C-terminal": -0.45}   # + toward white, - toward black
MIN_NUMBERING_MATCH = 0.95

THREE_TO_ONE = {
    "ALA": "A", "ARG": "R", "ASN": "N", "ASP": "D", "CYS": "C",
    "GLN": "Q", "GLU": "E", "GLY": "G", "HIS": "H", "ILE": "I",
    "LEU": "L", "LYS": "K", "MET": "M", "PHE": "F", "PRO": "P",
    "SER": "S", "THR": "T", "TRP": "W", "TYR": "Y", "VAL": "V",
}

# --- Scenes (one per figure image; names match the figure script's image stems) ---
IMAGE_WIDTH = 3000   # width of the figure images; the DDK outline width is given in these pixels
SCENE_NAMES = {
    "arch_open": f"arch_ring_open_{OPEN_RING_ENTRY}",
    "arch_closed": f"arch_ring_closed_{ARCHITECTURE_ENTRY}",
    "arch_pair": f"arch_double_hexamer_{ARCHITECTURE_ENTRY}",
    "ddk_profile": f"ddk_edge_on_{DDK_ENTRY}",
    "ddk_face": f"ddk_face_on_{DDK_ENTRY}",
    "ddk_ring": f"ddk_ring_down_axis_{DDK_ENTRY}",
    "openclosed": "open_closed_skew",
    "ring": f"legend_ring_{OPEN_RING_ENTRY}",
    "subunit": f"legend_subunit_{SINGLE_SUBUNIT}_{SUBUNIT_ENTRY}",
    "edge": "legend_edge_open_closed",
}
SCENE_FIGURES = {
    "architecture": ("arch_open", "arch_closed", "arch_pair"),
    "ddk": ("ddk_profile", "ddk_face", "ddk_ring"),
    "open_closed": ("openclosed",),
    "glyph_legend": ("ring", "subunit", "edge"),
}
MIN_SUBUNIT_RESIDUES = 50   # chains shorter than this (e.g. the 7PT6 Mcm4 tail fragment) are not ring subunits
MAX_CANDIDATES = 3000       # candidate tip points kept per target
OCCLUSION_RADIUS = 3.5      # Angstroms; screen-plane cell size for the occlusion test
DEPTH_TOLERANCE = 1.5       # Angstroms an occluder must sit in front of a candidate to hide it
SURFACE_TOLERANCE = 3.0     # Angstroms behind the target's own front surface a candidate may sit
EDGE_MARGIN = 0.03          # tips must lie this far inside the image edge (fraction of width or height)
INTERFACE_WINDOW = 4.0      # Angstroms above the closest CA-CA distance kept as interface pairs
CONTACT_DISTANCE = 8.0      # Angstroms; CA proximity used to pair DDK chains with Mcm chains
C_FACE_SLAB = 12.0          # Angstroms; outermost slab of the near hexamer used for the C-face label
LABEL_GAP = 0.05            # label column distance outside the image, in image widths
LABEL_SPACING = 0.05        # minimum spacing between labels, in image widths

# =============================================================================
# SHARED FUNCTIONS (called by multiple controllers)
# =============================================================================

def open_entry(session, entry_id):
    """MODEL: Fetch a deposited entry and return its atomic structure (TERMINAL)"""
    from chimerax.atomic import AtomicStructure
    models = run(session, f"open {entry_id}")
    return next(model for model in models if isinstance(model, AtomicStructure))

def classify_chains(structure):
    """MODEL: Assign every chain to a subunit, DNA, or Unassigned from its entity description (TERMINAL)"""
    from chimerax.atomic import Residue
    chain_map = {name: [] for name, _ in SUBUNIT_PATTERNS}
    chain_map["DNA"] = []
    chain_map["Unassigned"] = []
    for chain in structure.chains:
        if chain.polymer_type == Residue.PT_NUCLEIC:
            chain_map["DNA"].append(chain.chain_id)
            continue
        description = chain.description or ""
        subunit = next((name for name, pattern in SUBUNIT_PATTERNS
                        if re.search(pattern, description, re.IGNORECASE)), "Unassigned")
        chain_map[subunit].append(chain.chain_id)
    return chain_map

def build_chain_specs(structure, chain_map):
    """MODEL: Convert each non-empty chain group into a ChimeraX atom spec (TERMINAL)"""
    model_spec = f"#{structure.id_string}"
    return {name: f"{model_spec}/{','.join(chain_ids)}"
            for name, chain_ids in chain_map.items() if chain_ids}

def compute_double_hexamer_frame(structure, chain_map):
    """MODEL: Centre and long axis of the double hexamer from its Mcm atoms (TERMINAL)"""
    mcm_ids = [cid for name in MCM_SUBUNITS for cid in chain_map[name]]
    atoms = structure.atoms
    coords = atoms.scene_coords[np.isin(atoms.chain_ids, mcm_ids)]
    center = coords.mean(axis=0)
    _, _, principal_axes = np.linalg.svd(coords - center, full_matrices=False)
    return {"center": center, "axis": principal_axes[0]}

def compute_camera_pose(frame, toward_camera, view_name, skew_degrees=0.0):
    """MODEL: Camera on one side of a frame axis, axis horizontal, turned about the vertical (TERMINAL)"""
    axis = frame["axis"]
    z_axis = toward_camera - np.dot(toward_camera, axis) * axis
    z_axis = z_axis / np.linalg.norm(z_axis)
    y_axis = np.cross(z_axis, axis)
    y_axis = y_axis / np.linalg.norm(y_axis)
    x_axis = np.cross(y_axis, z_axis)
    angle = np.radians(skew_degrees)
    z_axis, x_axis = (np.cos(angle) * z_axis + np.sin(angle) * x_axis,
                      np.cos(angle) * x_axis - np.sin(angle) * z_axis)
    return {
        "axes": [x_axis, y_axis, z_axis],
        "origin": frame["center"] + CAMERA_DISTANCE * z_axis,
        "name": view_name,
    }

def compute_ring_center(structure, hexamer):
    """MODEL: Centre of one ring's Mcm atoms in scene coordinates (TERMINAL)"""
    atoms = structure.atoms
    return atoms.scene_coords[np.isin(atoms.chain_ids, list(hexamer.values()))].mean(axis=0)

def compute_ring_axis_pose(structure, hexamer, frame, center, face, view_name):
    """MODEL: Camera on one ring's axis, the chosen face ("N" or "C") toward the viewer, Mcm2-Mcm5 gate at the top (TERMINAL)

    The N face of each ring of a double hexamer points toward the pair centre in frame.
    """
    atoms = structure.atoms
    coords = atoms.scene_coords
    chain_ids = atoms.chain_ids
    axis = frame["axis"]
    n_direction = axis * np.sign(np.dot(frame["center"] - center, axis))
    z_axis = n_direction if face == "N" else -n_direction
    gate = 0.5 * (coords[chain_ids == hexamer["Mcm2"]].mean(axis=0)
                  + coords[chain_ids == hexamer["Mcm5"]].mean(axis=0)) - center
    y_axis = gate - np.dot(gate, z_axis) * z_axis
    y_axis = y_axis / np.linalg.norm(y_axis)
    x_axis = np.cross(y_axis, z_axis)
    return {"axes": [x_axis, y_axis, z_axis], "origin": center + CAMERA_DISTANCE * z_axis, "name": view_name}

def ensure_output_dir():
    """MODEL: Create the folder that receives the asset archive if it does not exist (TERMINAL)"""
    os.makedirs(ASSET_FILE.parent, exist_ok=True)

def clear_session(session):
    """VIEW: Close all models and reset the scene (TERMINAL)"""
    run(session, "close session")

def log_chain_assignment(session, entry_id, chain_map):
    """VIEW: Report which chains were assigned to each subunit (TERMINAL)"""
    label = entry_id.upper()
    session.logger.info(f"Chain assignment for {label}:")
    for name, chain_ids in chain_map.items():
        if chain_ids:
            session.logger.info(f"  {name}: {', '.join(chain_ids)}")
    missing = [name for name in MCM_SUBUNITS if not chain_map[name]]
    if missing:
        session.logger.warning(f"  {label}: no chains matched {', '.join(missing)}")
    if chain_map["Unassigned"]:
        session.logger.warning(
            f"  {label}: chains {', '.join(chain_map['Unassigned'])} matched no subunit "
            f"and are colored {UNASSIGNED_COLOR}")

def set_publication_style(session):
    """VIEW: White background, soft lighting, silhouettes, orthographic camera (TERMINAL)"""
    run(session, "set bgColor white")
    run(session, "lighting soft")
    run(session, "graphics silhouettes true width 1")
    run(session, "camera ortho")

def render_colored_surfaces(session, structure, specs):
    """VIEW: Replace atoms and cartoons with per-chain surfaces colored by subunit (TERMINAL)"""
    model_spec = f"#{structure.id_string}"
    if "DNA" in specs:
        run(session, f"nucleotides {specs['DNA']} atoms")
    run(session, f"hide {model_spec} target ac")
    run(session, f"surface {model_spec} gridSpacing {SURFACE_GRID_SPACING}")
    for name, spec in specs.items():
        if name == "DNA":
            color = DNA_COLOR
        elif name == "Unassigned":
            color = UNASSIGNED_COLOR
        else:
            color = SUBUNIT_COLORS[name]
        run(session, f"color {spec} {color}")

def render_structure_scene(session, fig):
    """SUB-CONTROLLER: Log chain assignment, set the scene style, draw colored surfaces"""
    log_chain_assignment(session, fig["entry"], fig["chain_map"])
    set_publication_style(session)
    render_colored_surfaces(session, fig["structure"], fig["specs"])

def apply_camera_pose(session, pose):
    """VIEW: Place the camera, fit all displayed models, save the result as a named view (TERMINAL)"""
    from chimerax.geometry import Place
    session.main_view.camera.position = Place(axes=pose["axes"], origin=pose["origin"])
    run(session, "view")
    run(session, f"view name {pose['name']}")

def capture_scene(session, assets, key, outline_ids=()):
    """SUB-CONTROLLER: Record the camera and every shown chain surface of the current view as one scene"""

    def record_scene(session, assets, key, outline_ids):
        """SUB-CONTROLLER: Read the camera and the shown surfaces, add them to the asset store"""

        def capture_view(session):
            """MODEL: Camera-to-scene matrix, orthographic field width and window aspect of the current view (TERMINAL)"""
            view = session.main_view
            camera = view.camera
            if not hasattr(camera, "field_width"):
                raise ValueError("Scene export needs the orthographic camera (camera ortho)")
            width, height = view.window_size
            return {
                "position": camera.position.matrix.tolist(),
                "field_width": float(camera.field_width),
                "aspect": height / width,
                "window": [int(width), int(height)],
            }

        def list_visible_structures(session):
            """MODEL: Atomic structures drawn in the current view (TERMINAL)"""
            from chimerax.atomic import AtomicStructure
            return [model for model in session.models.list(type=AtomicStructure) if model.visible]

        def extract_surface_parts(structures, chain_maps):
            """MODEL: Geometry, placement, colors and shown triangles of every drawn chain surface (TERMINAL)"""
            parts = []
            for structure in structures:
                entry = structure.name.lower()
                groups = {cid: name for name, cids in chain_maps[structure.id_string].items() for cid in cids}
                for surface in structure.surfaces():
                    if not surface.visible or surface.vertices is None or len(surface.triangles) == 0:
                        continue
                    mask = surface.triangle_mask
                    if mask is not None and not mask.any():
                        continue
                    vertices = np.asarray(surface.vertices, dtype=np.float32)
                    triangles = np.asarray(surface.triangles, dtype=np.int64)
                    colors = surface.vertex_colors
                    if colors is None:
                        colors = np.tile(np.asarray(surface.color, dtype=np.uint8), (len(vertices), 1))
                    chain_ids = sorted(set(surface.atoms.chain_ids))
                    vertex_atoms = surface.vertex_to_atom_map()
                    residues = (surface.atoms.residues.numbers[vertex_atoms] if vertex_atoms is not None
                                else np.zeros(len(vertices), dtype=np.int64))
                    digest = hashlib.sha1(vertices.tobytes() + triangles.tobytes()).hexdigest()[:10]
                    parts.append({
                        "mesh_id": f"{entry}_{'-'.join(chain_ids)}_{digest}",
                        "entry": entry,
                        "chain_ids": chain_ids,
                        "group": groups.get(chain_ids[0], "Unassigned"),
                        "vertices": vertices,
                        "triangles": triangles,
                        "residues": residues,
                        "colors": np.asarray(colors, dtype=np.uint8),
                        "mask": None if mask is None or mask.all() else np.asarray(mask, dtype=bool),
                        "transform": np.asarray(surface.scene_position.matrix, dtype=float),
                    })
            return parts

        def store_scene(assets, key, view, parts, outline_ids):
            """MODEL: Add each new mesh once, then record the scene's camera, parts and outline (TERMINAL)"""
            scene_parts = []
            for part in parts:
                mesh_id = part["mesh_id"]
                base = f"meshes/{mesh_id}"
                if mesh_id not in assets["meshes"]:
                    vertices = part["vertices"]
                    low = vertices.min(axis=0)
                    scale = np.maximum(vertices.max(axis=0) - low, 1e-6) / POSITION_LEVELS
                    index_type = np.uint16 if len(vertices) <= 65536 else np.uint32
                    assets["arrays"][f"{base}/positions.bin"] = np.round((vertices - low) / scale).astype("<u2")
                    assets["arrays"][f"{base}/triangles.bin"] = part["triangles"].astype(np.dtype(index_type).newbyteorder("<"))
                    assets["arrays"][f"{base}/residues.bin"] = part["residues"].astype("<i2")
                    assets["meshes"][mesh_id] = {
                        "entry": part["entry"],
                        "chain_ids": part["chain_ids"],
                        "group": part["group"],
                        "vertex_count": int(len(vertices)),
                        "triangle_count": int(len(part["triangles"])),
                        "positions": {"file": f"{base}/positions.bin", "dtype": "uint16",
                                      "offset": low.astype(float).tolist(), "scale": scale.astype(float).tolist()},
                        "triangles": {"file": f"{base}/triangles.bin", "dtype": np.dtype(index_type).name},
                        "residues": {"file": f"{base}/residues.bin", "dtype": "int16"},
                    }
                palette, index = np.unique(part["colors"], axis=0, return_inverse=True)
                index = index.reshape(-1)
                scene_part = {"mesh": mesh_id, "transform": part["transform"].tolist()}
                if len(palette) == 1:
                    scene_part["color"] = palette[0].astype(int).tolist()
                else:
                    color_file = f"scenes/{key}/{mesh_id}_colors.bin"
                    color_type = np.uint8 if len(palette) <= 256 else np.uint16
                    assets["arrays"][color_file] = index.astype(np.dtype(color_type).newbyteorder("<"))
                    scene_part["palette"] = palette.astype(int).tolist()
                    scene_part["color_index"] = {"file": color_file, "dtype": np.dtype(color_type).name}
                if part["mask"] is not None:
                    mask_file = f"scenes/{key}/{mesh_id}_mask.bin"
                    assets["arrays"][mask_file] = np.packbits(part["mask"])
                    scene_part["triangle_mask"] = {"file": mask_file, "dtype": "packbits", "count": int(len(part["mask"]))}
                scene_parts.append(scene_part)
            outline = [part["mesh_id"] for part in parts if set(part["chain_ids"]) & set(outline_ids)]
            assets["scenes"][key] = {
                "name": SCENE_NAMES[key],
                "camera": view,
                "parts": scene_parts,
                "outline": {"meshes": outline, "color": list(DDK_OUTLINE_COLOR),
                            "width_px": DDK_OUTLINE_WIDTH, "image_width_px": IMAGE_WIDTH} if outline else None,
            }

        view = capture_view(session)
        structures = list_visible_structures(session)
        chain_maps = {structure.id_string: classify_chains(structure) for structure in structures}
        parts = extract_surface_parts(structures, chain_maps)
        store_scene(assets, key, view, parts, outline_ids)
        return parts

    def log_scene_capture(session, key, parts):
        """VIEW: Report the surfaces and triangle count recorded for a scene (TERMINAL)"""
        triangles = sum(len(part["triangles"]) for part in parts)
        session.logger.info(f"  Scene {key}: {len(parts)} chain surfaces, {triangles} triangles")

    parts = record_scene(session, assets, key, outline_ids)
    log_scene_capture(session, key, parts)

def shade_color(session, color_name, fraction):
    """MODEL: Blend a named color toward white (positive fraction) or black (negative) as hex (TERMINAL)"""
    from chimerax.core.commands import ColorArg
    color, _, _ = ColorArg.parse(color_name, session)
    rgb = np.array(color.rgba[:3], dtype=float)
    target = np.ones(3) if fraction >= 0 else np.zeros(3)
    blended = rgb + abs(fraction) * (target - rgb)
    return "#" + "".join(f"{int(round(channel * 255)):02x}" for channel in blended)

def load_open_closed_pair(session):
    """SUB-CONTROLLER: Load the closed double hexamer and the open ring, superpose the open ring onto one closed ring"""

    def select_open_hexamer(chain_map):
        """MODEL: One chain per Mcm subunit from the open-ring entry (TERMINAL)"""
        missing = [name for name in MCM_SUBUNITS if not chain_map[name]]
        if missing:
            raise ValueError(f"{OPEN_RING_ENTRY.upper()}: no chains matched {', '.join(missing)}")
        return {name: chain_map[name][0] for name in MCM_SUBUNITS}

    def compute_superposition(open_structure, open_hexamer, closed_structure, closed_hexamer):
        """MODEL: Least-squares fit of open-ring CA atoms onto the closed ring over the superposition subunits (TERMINAL)"""
        moving, fixed = [], []
        for name in SUPERPOSE_SUBUNITS:
            open_atoms = open_structure.atoms
            open_ca = open_atoms.filter((open_atoms.names == "CA") & (open_atoms.chain_ids == open_hexamer[name]))
            closed_atoms = closed_structure.atoms
            closed_ca = closed_atoms.filter((closed_atoms.names == "CA") & (closed_atoms.chain_ids == closed_hexamer[name]))
            open_by_number = dict(zip(open_ca.residues.numbers, open_ca.scene_coords))
            closed_by_number = dict(zip(closed_ca.residues.numbers, closed_ca.scene_coords))
            for number in sorted(set(open_by_number) & set(closed_by_number)):
                moving.append(open_by_number[number])
                fixed.append(closed_by_number[number])
        if len(moving) < MIN_SUPERPOSE_ATOMS:
            raise ValueError(f"Only {len(moving)} matching CA atoms for superposition; residue numbering may differ")
        moving = np.array(moving)
        fixed = np.array(fixed)
        moving_center = moving.mean(axis=0)
        fixed_center = fixed.mean(axis=0)
        u, _, vt = np.linalg.svd((moving - moving_center).T @ (fixed - fixed_center))
        handedness = np.sign(np.linalg.det(vt.T @ u.T))
        rotation = vt.T @ np.diag([1.0, 1.0, handedness]) @ u.T
        translation = fixed_center - rotation @ moving_center
        fitted = moving @ rotation.T + translation
        return {
            "matrix": np.hstack([rotation, translation[:, None]]),
            "rmsd": float(np.sqrt(np.mean(np.sum((fitted - fixed) ** 2, axis=1)))),
            "atom_count": len(moving),
        }

    def apply_superposition(open_structure, fit):
        """MODEL: Move the open ring into the frame of the closed ring (TERMINAL)"""
        from chimerax.geometry import Place
        open_structure.position = Place(matrix=fit["matrix"]) * open_structure.position

    def compute_hexamer_geometry(closed_structure, closed_hexamer, frame):
        """MODEL: Centre, N-face direction, near-arc direction and diameter of the chosen closed ring (TERMINAL)"""
        atoms = closed_structure.atoms
        coords = atoms.scene_coords
        chain_ids = atoms.chain_ids
        axis = frame["axis"]
        ring_coords = coords[np.isin(chain_ids, list(closed_hexamer.values()))]
        center = ring_coords.mean(axis=0)
        n_direction = axis * np.sign(np.dot(frame["center"] - center, axis))
        near = coords[np.isin(chain_ids, [closed_hexamer[name] for name in NEAR_ARC_SUBUNITS])].mean(axis=0) - center
        near = near - np.dot(near, axis) * axis
        radial = ring_coords - center
        radial = radial - np.outer(radial @ axis, axis)
        return {
            "frame": {"center": center, "axis": axis},
            "n_direction": n_direction,
            "near_direction": near / np.linalg.norm(near),
            "diameter": 2.0 * float(np.max(np.linalg.norm(radial, axis=1))),
        }

    def build_hide_specs(closed_structure, other_hexamer, open_structure, open_map):
        """MODEL: Specs for the unused closed ring and the open ring's loading partners (TERMINAL)"""
        partners = [cid for name in HIDDEN_PARTNERS for cid in open_map[name]] + open_map["Unassigned"]
        return {
            "other_hexamer": f"#{closed_structure.id_string}/{','.join(other_hexamer.values())}",
            "partners": f"#{open_structure.id_string}/{','.join(partners)}" if partners else None,
        }

    ensure_output_dir()
    closed = open_entry(session, ARCHITECTURE_ENTRY)
    closed_map = classify_chains(closed)
    closed_specs = build_chain_specs(closed, closed_map)
    frame = compute_double_hexamer_frame(closed, closed_map)
    hexamers = split_hexamers(closed, closed_map, frame)
    open_ring = open_entry(session, OPEN_RING_ENTRY)
    open_map = classify_chains(open_ring)
    open_specs = build_chain_specs(open_ring, open_map)
    open_hexamer = select_open_hexamer(open_map)
    fit = compute_superposition(open_ring, open_hexamer, closed, hexamers[1])
    apply_superposition(open_ring, fit)
    geometry = compute_hexamer_geometry(closed, hexamers[1], frame)
    open_center = compute_ring_center(open_ring, open_hexamer)
    hide_specs = build_hide_specs(closed, hexamers[-1], open_ring, open_map)
    return {
        "closed": {"entry": ARCHITECTURE_ENTRY, "structure": closed, "chain_map": closed_map, "specs": closed_specs},
        "open": {"entry": OPEN_RING_ENTRY, "structure": open_ring, "chain_map": open_map, "specs": open_specs},
        "frame": frame,
        "closed_hexamer": hexamers[1],
        "open_hexamer": open_hexamer,
        "fit": fit,
        "geometry": geometry,
        "open_center": open_center,
        "hide_specs": hide_specs,
    }

def compute_stacked_pose(pair, view_name, skew_degrees):
    """SUB-CONTROLLER: Camera on the near-arc side of the closed ring, with the open ring stacked above it"""

    def compute_stack_translation(pose, geometry):
        """MODEL: Shift along the camera's vertical that places the open ring above the closed ring (TERMINAL)"""
        return pose["axes"][1] * geometry["diameter"] * STACK_SPACING

    def compute_stack_frame(geometry, translation):
        """MODEL: Frame centred between the closed ring and the shifted open ring (TERMINAL)"""
        return {"center": geometry["frame"]["center"] + 0.5 * translation, "axis": geometry["frame"]["axis"]}

    geometry = pair["geometry"]
    ring_pose = compute_camera_pose(geometry["frame"], geometry["near_direction"], view_name, skew_degrees)
    translation = compute_stack_translation(ring_pose, geometry)
    stack_frame = compute_stack_frame(geometry, translation)
    pose = compute_camera_pose(stack_frame, geometry["near_direction"], view_name, skew_degrees)
    return {"pose": pose, "translation": translation}

def hide_unused_chains(session, hide_specs):
    """VIEW: Hide the second closed ring and the open ring's loading partners (TERMINAL)"""
    run(session, f"hide {hide_specs['other_hexamer']} target s")
    if hide_specs["partners"]:
        run(session, f"hide {hide_specs['partners']} target s")

def arrange_open_closed_pair(session, pair, translation):
    """SUB-CONTROLLER: One closed ring with DNA, the open ring stacked above it, loading partners hidden"""

    def log_superposition(session, pair):
        """VIEW: Report the fit used to superpose the open ring (TERMINAL)"""
        fit = pair["fit"]
        session.logger.info(
            f"  {OPEN_RING_ENTRY.upper()} superposed on {ARCHITECTURE_ENTRY.upper()} over "
            f"{', '.join(SUPERPOSE_SUBUNITS)}: {fit['atom_count']} CA atoms, RMSD {fit['rmsd']:.2f} A")

    def shift_open_ring(open_structure, translation):
        """VIEW: Move the open ring by the stacking translation (TERMINAL)"""
        from chimerax.geometry import Place
        open_structure.position = Place(origin=translation) * open_structure.position

    log_superposition(session, pair)
    hide_unused_chains(session, pair["hide_specs"])
    shift_open_ring(pair["open"]["structure"], translation)

def split_hexamers(structure, chain_map, frame):
    """MODEL: Assign each full-length Mcm chain to a hexamer by its side of the pair centre (TERMINAL)"""
    residue_counts = {chain.chain_id: len(chain.existing_residues) for chain in structure.chains}
    atoms = structure.atoms
    coords = atoms.scene_coords
    chain_ids = atoms.chain_ids
    hexamers = {-1: {}, 1: {}}
    for name in MCM_SUBUNITS:
        for cid in chain_map[name]:
            if residue_counts[cid] < MIN_SUBUNIT_RESIDUES:
                continue
            com = coords[chain_ids == cid].mean(axis=0)
            side = 1 if np.dot(com - frame["center"], frame["axis"]) > 0 else -1
            hexamers[side][name] = cid
    if any(len(hexamer) != len(MCM_SUBUNITS) for hexamer in hexamers.values()):
        raise ValueError(f"{structure.name}: Mcm chains do not split into two complete hexamers")
    return hexamers

def chain_target(key, structure, chain_ids):
    """MODEL: Annotation target covering whole chains, tip placed on their visible surface (TERMINAL)"""
    atoms = structure.atoms
    points = atoms.scene_coords[np.isin(atoms.chain_ids, list(chain_ids))]
    count = min(len(points), MAX_CANDIDATES)
    keep = np.unique(np.linspace(0, len(points) - 1, count).astype(int)) if count else np.array([], dtype=int)
    return {
        "key": key,
        "points": points[keep],
        "owners": {f"{structure.id_string}/{cid}" for cid in chain_ids},
        "mode": "surface",
    }

def range_target(key, structure, chain_id, ranges):
    """MODEL: Annotation target covering residue ranges of one chain, tip on their visible surface (TERMINAL)"""
    atoms = structure.atoms
    numbers = atoms.residues.numbers
    in_range = np.zeros(len(atoms), dtype=bool)
    for start, end in ranges:
        in_range |= (numbers >= start) & (numbers <= end)
    points = atoms.scene_coords[in_range & (atoms.chain_ids == chain_id)]
    count = min(len(points), MAX_CANDIDATES)
    keep = np.unique(np.linspace(0, len(points) - 1, count).astype(int)) if count else np.array([], dtype=int)
    return {
        "key": key,
        "points": points[keep],
        "owners": {f"{structure.id_string}/{chain_id}"},
        "mode": "surface",
    }

def interface_target(key, structure_a, chain_ids_a, structure_b, chain_ids_b):
    """MODEL: Annotation target at midpoints of the closest CA pairs between two chain sets (TERMINAL)"""
    atoms_a = structure_a.atoms
    ca_a = atoms_a.filter((atoms_a.names == "CA") & np.isin(atoms_a.chain_ids, list(chain_ids_a))).scene_coords
    atoms_b = structure_b.atoms
    ca_b = atoms_b.filter((atoms_b.names == "CA") & np.isin(atoms_b.chain_ids, list(chain_ids_b))).scene_coords
    owners = ({f"{structure_a.id_string}/{cid}" for cid in chain_ids_a}
              | {f"{structure_b.id_string}/{cid}" for cid in chain_ids_b})
    if len(ca_a) == 0 or len(ca_b) == 0:
        return {"key": key, "points": np.zeros((0, 3)), "owners": owners, "mode": "point"}
    row_min = np.empty(len(ca_a))
    for start in range(0, len(ca_a), 500):
        block = np.linalg.norm(ca_a[start:start + 500, None, :] - ca_b[None, :, :], axis=2)
        row_min[start:start + 500] = block.min(axis=1)
    cutoff = row_min.min() + INTERFACE_WINDOW
    near_a = ca_a[row_min <= cutoff]
    pair_distances = np.linalg.norm(near_a[:, None, :] - ca_b[None, :, :], axis=2)
    index_a, index_b = np.nonzero(pair_distances <= cutoff)
    midpoints = 0.5 * (near_a[index_a] + ca_b[index_b])
    count = min(len(midpoints), MAX_CANDIDATES)
    keep = np.unique(np.linspace(0, len(midpoints) - 1, count).astype(int))
    return {"key": key, "points": midpoints[keep], "owners": owners, "mode": "point"}

def collect_displayed_atoms(entries):
    """MODEL: Scene coordinates and owning chain of every atom drawn in an image (TERMINAL)"""
    coords, owners = [], []
    for structure, chain_ids in entries:
        atoms = structure.atoms
        mask = np.isin(atoms.chain_ids, list(chain_ids))
        coords.append(atoms.scene_coords[mask])
        owners.append(np.array([f"{structure.id_string}/{cid}" for cid in atoms.chain_ids[mask]], dtype=object))
    return {"coords": np.vstack(coords), "owners": np.concatenate(owners)}

def pair_display_entries(pair):
    """MODEL: Chains drawn when the open ring is stacked on the closed ring (TERMINAL)"""
    closed_ids = list(pair["closed_hexamer"].values()) + pair["closed"]["chain_map"]["DNA"]
    return [(pair["closed"]["structure"], closed_ids),
            (pair["open"]["structure"], list(pair["open_hexamer"].values()))]

def capture_camera(session):
    """MODEL: World-to-camera transform, field width and image aspect of the rendered view (TERMINAL)"""
    view = session.main_view
    camera = view.camera
    if not hasattr(camera, "field_width"):
        raise ValueError("Annotation anchors need the orthographic camera (camera ortho)")
    width, height = view.window_size
    return {
        "to_camera": camera.position.inverse().matrix,
        "field_width": float(camera.field_width),
        "aspect": height / width,
    }

def compute_annotation_tips(camera, targets, displayed):
    """MODEL: Visible arrow tip for each target in image-width units, or the reason it was omitted (TERMINAL)"""
    rotation = camera["to_camera"][:, :3]
    shift = camera["to_camera"][:, 3]
    width, aspect = camera["field_width"], camera["aspect"]
    scene = displayed["coords"] @ rotation.T + shift
    scene_depth = -scene[:, 2]
    tips, omitted = {}, {}
    for target in targets:
        key, points = target["key"], target["points"]
        if len(points) == 0:
            omitted[key] = "no modeled atoms"
            continue
        local = points @ rotation.T + shift
        depth = -local[:, 2]
        cells = np.floor(local[:, :2] / OCCLUSION_RADIUS).astype(np.int64)

        blocking = ~np.isin(displayed["owners"], list(target["owners"]))
        blocker_cells = np.floor(scene[blocking, :2] / OCCLUSION_RADIUS).astype(np.int64)
        blocker_depth = scene_depth[blocking]
        front = {}
        if len(blocker_depth):
            order = np.lexsort((blocker_depth, blocker_cells[:, 1], blocker_cells[:, 0]))
            unique_cells, first = np.unique(blocker_cells[order], axis=0, return_index=True)
            front = {(int(cx), int(cy)): d for (cx, cy), d in zip(unique_cells, blocker_depth[order][first])}

        visible = np.ones(len(points), dtype=bool)
        for index, (cx, cy) in enumerate(cells):
            for dx in (-1, 0, 1):
                for dy in (-1, 0, 1):
                    blocker = front.get((int(cx) + dx, int(cy) + dy))
                    if blocker is not None and blocker < depth[index] - DEPTH_TOLERANCE:
                        visible[index] = False

        if target["mode"] == "surface":
            order = np.lexsort((depth, cells[:, 1], cells[:, 0]))
            unique_cells, first = np.unique(cells[order], axis=0, return_index=True)
            own_front = {(int(cx), int(cy)): d for (cx, cy), d in zip(unique_cells, depth[order][first])}
            facing = np.array([depth[i] <= own_front[(int(cx), int(cy))] + SURFACE_TOLERANCE
                               for i, (cx, cy) in enumerate(cells)])
            visible &= facing

        u = 0.5 + local[:, 0] / width
        v = 0.5 + local[:, 1] / (width * aspect)
        inside = (u > EDGE_MARGIN) & (u < 1 - EDGE_MARGIN) & (v > EDGE_MARGIN) & (v < 1 - EDGE_MARGIN)
        usable = visible & inside
        if not usable.any():
            omitted[key] = "no visible point inside the image"
            continue
        distance = np.linalg.norm(local[:, :2] - local[:, :2].mean(axis=0), axis=1)
        distance[~usable] = np.inf
        best = int(np.argmin(distance))
        tips[key] = {"xyz": points[best], "x": float(u[best]), "y": float(v[best] * aspect)}
    return {"tips": tips, "omitted": omitted}

def layout_labels(tips, aspect):
    """MODEL: Label positions in columns left and right of the image, ordered and spaced by tip height (TERMINAL)"""
    labels = {}
    for side, anchor, x in (("left", "east", -LABEL_GAP), ("right", "west", 1.0 + LABEL_GAP)):
        items = sorted(((key, tip) for key, tip in tips.items() if (tip["x"] < 0.5) == (side == "left")),
                       key=lambda item: item[1]["y"])
        ys = [tip["y"] for _, tip in items]
        for i in range(1, len(ys)):
            ys[i] = max(ys[i], ys[i - 1] + LABEL_SPACING)
        if ys and ys[-1] > aspect:
            ys[-1] = aspect
            for i in range(len(ys) - 2, -1, -1):
                ys[i] = min(ys[i], ys[i + 1] - LABEL_SPACING)
        for (key, _), y in zip(items, ys):
            labels[key] = {"x": x, "y": y, "anchor": anchor}
    return labels

def compute_ring_layout(camera, structure, hexamer, center_xyz):
    """MODEL: Ring centre, outer radius, front depth and screen direction of each subunit and of the Mcm2-Mcm5 gate, in camera coordinates (TERMINAL)"""
    rotation = camera["to_camera"][:, :3]
    shift = camera["to_camera"][:, 3]
    atoms = structure.atoms
    chain_ids = atoms.chain_ids
    local = atoms.scene_coords @ rotation.T + shift
    center = (rotation @ center_xyz + shift)[:2]
    in_ring = np.isin(chain_ids, list(hexamer.values()))
    radius = float(np.max(np.linalg.norm(local[in_ring, :2] - center, axis=1)))
    centroids = {name: local[chain_ids == cid, :2].mean(axis=0) for name, cid in hexamer.items()}
    centroids["gate"] = 0.5 * (centroids["Mcm2"] + centroids["Mcm5"])
    directions = {}
    for name, centroid in centroids.items():
        offset = centroid - center
        directions[name] = offset / np.linalg.norm(offset)
    return {
        "center": center,
        "radius": radius,
        "front": float(local[in_ring, 2].max()),
        "directions": directions,
    }

def place_radial_annotations(camera, layout, specs):
    """MODEL: Tip and label outside the ring along each (key, direction, tip gap, label gap), in image-width units (TERMINAL)"""
    rotation = camera["to_camera"][:, :3]
    shift = camera["to_camera"][:, 3]
    width, aspect = camera["field_width"], camera["aspect"]
    tips, labels = {}, {}
    for key, direction_name, tip_gap, label_gap in specs:
        direction = layout["directions"][direction_name]
        tip = layout["center"] + (layout["radius"] + tip_gap * width) * direction
        label = layout["center"] + (layout["radius"] + label_gap * width) * direction
        marker = np.array([tip[0], tip[1], layout["front"] + CHECK_MARKER_LIFT])
        facing_ring = (np.degrees(np.arctan2(direction[1], direction[0])) + 180.0) % 360.0
        tips[key] = {"xyz": rotation.T @ (marker - shift),
                     "x": float(0.5 + tip[0] / width), "y": float(0.5 * aspect + tip[1] / width)}
        labels[key] = {"x": float(0.5 + label[0] / width), "y": float(0.5 * aspect + label[1] / width),
                       "anchor": str(int(round(facing_ring)) % 360)}
    return {"tips": tips, "labels": labels}

def compute_crop(camera, displayed):
    """MODEL: Image region holding every displayed atom plus CROP_MARGIN, in image-width units (TERMINAL)"""
    rotation = camera["to_camera"][:, :3]
    shift = camera["to_camera"][:, 3]
    width, aspect = camera["field_width"], camera["aspect"]
    local = displayed["coords"] @ rotation.T + shift
    low = local[:, :2].min(axis=0) - CROP_MARGIN
    high = local[:, :2].max(axis=0) + CROP_MARGIN
    return {
        "x0": float(max(0.0, 0.5 + low[0] / width)),
        "y0": float(max(0.0, 0.5 * aspect + low[1] / width)),
        "x1": float(min(1.0, 0.5 + high[0] / width)),
        "y1": float(min(aspect, 0.5 * aspect + high[1] / width)),
    }

def compute_hexamer_brackets(camera, structure, hexamers, frame, displayed, side):
    """MODEL: Span above (side 1) or below (side -1) each hexamer, split where the two rings meet, in image-width units (TERMINAL)"""
    rotation = camera["to_camera"][:, :3]
    shift = camera["to_camera"][:, 3]
    width, aspect = camera["field_width"], camera["aspect"]
    atoms = structure.atoms
    chain_ids = atoms.chain_ids
    local = atoms.scene_coords @ rotation.T + shift
    shown = displayed["coords"] @ rotation.T + shift
    junction = float((rotation @ frame["center"] + shift)[0])
    extents = {}
    for hexamer_side, hexamer in hexamers.items():
        x = local[np.isin(chain_ids, list(hexamer.values())), 0]
        extents[hexamer_side] = (float(x.min()), float(x.max()), float(x.mean()))
    left, right = sorted(extents, key=lambda hexamer_side: extents[hexamer_side][2])
    edge = float(shown[:, 1].max()) if side > 0 else float(shown[:, 1].min())
    height = edge + side * BRACKET_GAP * width
    front = float(shown[:, 2].max()) + CHECK_MARKER_LIFT
    gap = BRACKET_JUNCTION_GAP * width
    spans = {}
    for key, start, end in (("hexamer_left", extents[left][0], junction - gap),
                            ("hexamer_right", junction + gap, extents[right][1])):
        spans[key] = {
            "x1": 0.5 + start / width,
            "x2": 0.5 + end / width,
            "y": 0.5 * aspect + height / width,
            "xyz": [rotation.T @ (np.array([x, height, front]) - shift) for x in (start, end)],
        }
    return spans

def write_annotations(session, assets, prefix, annotations):
    """SUB-CONTROLLER: Store the annotation data with its scene, log every tip and omission"""

    def store_annotations(assets, prefix, annotations):
        """MODEL: Annotation data as plain JSON values, attached to its scene (TERMINAL)"""
        kept = {key: value for key, value in annotations.items() if key not in ("scene_name", "notes")}
        assets["scenes"][prefix]["annotations"] = json.loads(json.dumps(
            kept, default=lambda value: value.tolist() if hasattr(value, "tolist") else str(value)))
        assets["scenes"][prefix]["notes"] = list(annotations.get("notes", []))

    def log_annotations(session, prefix, annotations):
        """VIEW: Report each tip position, each omission and any pairing note (TERMINAL)"""
        session.logger.info(f"Annotations for {prefix} ({annotations['scene_name']}):")
        for key, tip in annotations["tips"].items():
            x, y, z = tip["xyz"]
            session.logger.info(f"  {key}: tip at ({tip['x']:.3f}, {tip['y']:.3f}), scene ({x:.1f}, {y:.1f}, {z:.1f})")
        for key, arc in annotations.get("arcs", {}).items():
            session.logger.info(f"  {key}: arc from {arc['start']:.1f} to {arc['end']:.1f} degrees")
        for key, span in annotations.get("spans", {}).items():
            session.logger.info(f"  {key}: bracket from {span['x1']:.3f} to {span['x2']:.3f} at height {span['y']:.3f}")
        for key, reason in annotations["omitted"].items():
            session.logger.warning(f"  {key}: omitted, {reason}")
        for note in annotations.get("notes", []):
            session.logger.warning(f"  {note}")

    store_annotations(assets, prefix, annotations)
    log_annotations(session, prefix, annotations)

# =============================================================================
# BASE CONTROLLERS
# =============================================================================

def build_architecture_figure(session, assets):
    """CONTROLLER: Open ring, closed ring on DNA and the double hexamer side view, with annotation anchors"""

    # === SUB-CONTROLLERS ===

    def reset_scene(session):
        """SUB-CONTROLLER: Start from an empty session"""
        clear_session(session)

    def load_ring_model(session):
        """SUB-CONTROLLER: Load the superposed open and closed rings, compute a down-axis camera with the gate at the top"""
        pair = load_open_closed_pair(session)
        pose = compute_ring_axis_pose(pair["closed"]["structure"], pair["closed_hexamer"], pair["frame"],
                                      pair["geometry"]["frame"]["center"], RING_VIEW_FACE, "arch_rings")
        return {"pair": pair, "pose": pose}

    def render_ring_scene(session, rings):
        """SUB-CONTROLLER: Style both structures, hide the unused ring and loading partners, fit one camera to both rings"""
        pair = rings["pair"]
        render_structure_scene(session, pair["closed"])
        render_structure_scene(session, pair["open"])
        hide_unused_chains(session, pair["hide_specs"])
        apply_camera_pose(session, rings["pose"])

    def render_open_panel(session, assets, pair):
        """SUB-CONTROLLER: Record the open ring alone, camera unchanged"""

        def show_open_ring(session, pair):
            """VIEW: Hide the closed structure and show the open structure (TERMINAL)"""
            run(session, f"hide #{pair['closed']['structure'].id_string} models")
            run(session, f"show #{pair['open']['structure'].id_string} models")

        show_open_ring(session, pair)
        capture_scene(session, assets, "arch_open")

    def load_open_annotations(session, pair):
        """SUB-CONTROLLER: Six subunit labels and the gate marker around the open ring"""
        open_ring, open_hex = pair["open"]["structure"], pair["open_hexamer"]
        camera = capture_camera(session)
        layout = compute_ring_layout(camera, open_ring, open_hex, pair["geometry"]["frame"]["center"])
        specs = [(name.lower(), name, RING_LABEL_GAP, RING_LABEL_GAP) for name in MCM_SUBUNITS]
        specs.append(("gate", "gate", GATE_TIP_GAP, GATE_LABEL_GAP))
        placed = place_radial_annotations(camera, layout, specs)
        crop = compute_crop(camera, collect_displayed_atoms([(open_ring, list(open_hex.values()))]))
        return {"scene_name": SCENE_NAMES["arch_open"], "tips": placed["tips"], "labels": placed["labels"],
                "omitted": {}, "crop": crop, "field_width": camera["field_width"]}

    def render_closed_panel(session, assets, pair):
        """SUB-CONTROLLER: Record the closed ring with its DNA, camera unchanged"""

        def show_closed_ring(session, pair):
            """VIEW: Hide the open structure and show the closed structure (TERMINAL)"""
            run(session, f"hide #{pair['open']['structure'].id_string} models")
            run(session, f"show #{pair['closed']['structure'].id_string} models")

        show_closed_ring(session, pair)
        capture_scene(session, assets, "arch_closed")

    def load_closed_annotations(session, pair):
        """SUB-CONTROLLER: Gate marker, six subunit labels, ring geometry and face arcs around the closed ring"""

        def compute_ring_sectors(camera, layout, interfaces):
            """MODEL: Ring centre and radius in image widths, and the angular span of each subunit between its interfaces (TERMINAL)"""
            rotation = camera["to_camera"][:, :3]
            shift = camera["to_camera"][:, 3]
            width, aspect = camera["field_width"], camera["aspect"]
            center = layout["center"]
            boundaries = {}
            for target in interfaces:
                if len(target["points"]) == 0:
                    raise ValueError(f"{ARCHITECTURE_ENTRY.upper()}: no contacts found for interface {target['key']}")
                offset = (target["points"] @ rotation.T + shift)[:, :2].mean(axis=0) - center
                boundaries[target["key"]] = float(np.degrees(np.arctan2(offset[1], offset[0])))
            sectors = {}
            for index, name in enumerate(RING_ORDER):
                before = boundaries[f"{RING_ORDER[index - 1]}|{name}"]
                after = boundaries[f"{name}|{RING_ORDER[(index + 1) % len(RING_ORDER)]}"]
                direction = layout["directions"][name]
                middle = float(np.degrees(np.arctan2(direction[1], direction[0])))
                if (middle - before) % 360.0 < (after - before) % 360.0:
                    sectors[name] = (before % 360.0, (after - before) % 360.0)
                else:
                    sectors[name] = (after % 360.0, (before - after) % 360.0)
            return {
                "x": float(0.5 + center[0] / width),
                "y": float(0.5 * aspect + center[1] / width),
                "radius": float(layout["radius"] / width),
                "sectors": sectors,
            }

        def compute_face_arcs(ring):
            """MODEL: Counterclockwise arc spanned by each face in FACE_SUBUNITS, in degrees (TERMINAL)"""
            arcs = {}
            for key, names in FACE_SUBUNITS.items():
                parts = [ring["sectors"][name] for name in names]
                ends = [(start + span) % 360.0 for start, span in parts]
                openings = [start for start, _ in parts
                            if all(min(abs(start - end), 360.0 - abs(start - end)) > 0.01 for end in ends)]
                if len(openings) != 1:
                    raise ValueError(f"{key}: subunits {', '.join(names)} are not adjacent in the ring")
                start = openings[0]
                arcs[key] = {"start": start, "end": start + sum(span for _, span in parts)}
            return arcs

        closed, closed_hex = pair["closed"]["structure"], pair["closed_hexamer"]
        camera = capture_camera(session)
        layout = compute_ring_layout(camera, closed, closed_hex, pair["geometry"]["frame"]["center"])
        specs = [(name.lower(), name, RING_LABEL_GAP, RING_LABEL_GAP) for name in MCM_SUBUNITS]
        specs.append(("gate", "gate", GATE_TIP_GAP, GATE_LABEL_GAP))
        placed = place_radial_annotations(camera, layout, specs)
        interfaces = [interface_target(f"{name}|{RING_ORDER[(index + 1) % len(RING_ORDER)]}",
                                       closed, [closed_hex[name]],
                                       closed, [closed_hex[RING_ORDER[(index + 1) % len(RING_ORDER)]]])
                      for index, name in enumerate(RING_ORDER)]
        ring = compute_ring_sectors(camera, layout, interfaces)
        arcs = compute_face_arcs(ring)
        shown = list(closed_hex.values()) + pair["closed"]["chain_map"]["DNA"]
        crop = compute_crop(camera, collect_displayed_atoms([(closed, shown)]))
        return {"scene_name": SCENE_NAMES["arch_closed"], "tips": placed["tips"], "labels": placed["labels"],
                "omitted": {}, "crop": crop, "field_width": camera["field_width"], "ring": ring, "arcs": arcs}

    def load_pair_model(session):
        """SUB-CONTROLLER: Load 5BK4, assign chains, compute the side-view camera opposite the gates"""

        def compute_direction_opposite_gates(structure, chain_map, frame):
            """MODEL: Unit direction from the pair axis away from the two Mcm2-Mcm5 gates (TERMINAL)"""
            gate_subunits = ("Mcm2", "Mcm5")
            if not all(chain_map[name] for name in gate_subunits):
                raise ValueError(f"{ARCHITECTURE_ENTRY.upper()}: Mcm2 or Mcm5 chains not found")
            atoms = structure.atoms
            coords = atoms.scene_coords
            chain_ids = atoms.chain_ids
            center, axis = frame["center"], frame["axis"]
            gate_coms = {-1: [], 1: []}
            for name in gate_subunits:
                for cid in chain_map[name]:
                    com = coords[chain_ids == cid].mean(axis=0)
                    gate_coms[1 if np.dot(com - center, axis) > 0 else -1].append(com)
            if not (gate_coms[-1] and gate_coms[1]):
                raise ValueError(f"{ARCHITECTURE_ENTRY.upper()}: gate subunits not found in both hexamers")
            radials = []
            for side in (-1, 1):
                radial = np.mean(gate_coms[side], axis=0) - center
                radial = radial - np.dot(radial, axis) * axis
                radials.append(radial / np.linalg.norm(radial))
            bisector = radials[0] + radials[1]
            if np.linalg.norm(bisector) < 0.2:
                return -radials[1]
            return -bisector / np.linalg.norm(bisector)

        ensure_output_dir()
        structure = open_entry(session, ARCHITECTURE_ENTRY)
        chain_map = classify_chains(structure)
        specs = build_chain_specs(structure, chain_map)
        frame = compute_double_hexamer_frame(structure, chain_map)
        hexamers = split_hexamers(structure, chain_map, frame)
        toward_camera = compute_direction_opposite_gates(structure, chain_map, frame)
        pose = compute_camera_pose(frame, toward_camera, "arch_pair", PAIR_SKEW_DEGREES)
        return {
            "entry": ARCHITECTURE_ENTRY,
            "structure": structure,
            "chain_map": chain_map,
            "specs": specs,
            "frame": frame,
            "hexamers": hexamers,
            "pose": pose,
        }

    def render_pair_panel(session, assets, fig):
        """SUB-CONTROLLER: Record the double hexamer side view"""
        apply_camera_pose(session, fig["pose"])
        capture_scene(session, assets, "arch_pair")

    def load_pair_annotations(session, fig):
        """SUB-CONTROLLER: One bracket above each hexamer"""

        structure = fig["structure"]
        displayed = collect_displayed_atoms([(structure, [chain.chain_id for chain in structure.chains])])
        camera = capture_camera(session)
        spans = compute_hexamer_brackets(camera, structure, fig["hexamers"], fig["frame"], displayed, 1)
        crop = compute_crop(camera, displayed)
        return {"scene_name": SCENE_NAMES["arch_pair"], "tips": {}, "labels": {}, "omitted": {},
                "spans": spans, "crop": crop, "field_width": camera["field_width"]}

    # === COORDINATE ===

    reset_scene(session)
    rings = load_ring_model(session)
    render_ring_scene(session, rings)
    render_open_panel(session, assets, rings["pair"])
    write_annotations(session, assets, "arch_open", load_open_annotations(session, rings["pair"]))
    render_closed_panel(session, assets, rings["pair"])
    write_annotations(session, assets, "arch_closed", load_closed_annotations(session, rings["pair"]))
    reset_scene(session)
    fig = load_pair_model(session)
    render_structure_scene(session, fig)
    render_pair_panel(session, assets, fig)
    write_annotations(session, assets, "arch_pair", load_pair_annotations(session, fig))

def build_ddk_figure(session, assets):
    """CONTROLLER: 7PT6 double hexamer with one DDK copy, edge on, face on and down the bound ring's axis, with annotation anchors"""

    # === SUB-CONTROLLERS ===

    def reset_scene(session):
        """SUB-CONTROLLER: Start from an empty session"""
        clear_session(session)

    def load_ddk_model(session):
        """SUB-CONTROLLER: Load 7PT6, pair the first DDK copy with its Mcm contacts, compute all three cameras"""

        def select_ddk_partners(structure, chain_map, hexamers, dbf4_id):
            """MODEL: Cdc7, Mcm2, Mcm4 and Mcm4-tail chains paired with one Dbf4 copy by CA proximity (TERMINAL)"""
            if not chain_map["Cdc7"]:
                raise ValueError(f"{DDK_ENTRY.upper()}: no Cdc7 chains found")
            atoms = structure.atoms
            ca = atoms.filter(atoms.names == "CA")
            coords, ids = ca.scene_coords, ca.chain_ids
            residue_counts = {chain.chain_id: len(chain.existing_residues) for chain in structure.chains}
            full_mcm4 = [cid for cid in chain_map["Mcm4"] if residue_counts[cid] >= MIN_SUBUNIT_RESIDUES]
            tails = [cid for cid in chain_map["Mcm4"] if residue_counts[cid] < MIN_SUBUNIT_RESIDUES]
            chosen = {"dbf4": dbf4_id}
            for role, reference, candidates in (("cdc7", "dbf4", chain_map["Cdc7"]),
                                                ("mcm2", "dbf4", chain_map["Mcm2"]),
                                                ("mcm4", "cdc7", full_mcm4),
                                                ("tail", "cdc7", tails)):
                if not candidates:
                    continue
                reference_coords = coords[ids == chosen[reference]]
                scores = []
                for cid in candidates:
                    distances = np.linalg.norm(coords[ids == cid][:, None, :] - reference_coords[None, :, :], axis=2)
                    closest = distances.min(axis=1)
                    scores.append((int(np.sum(closest <= CONTACT_DISTANCE)), -float(closest.min()), cid))
                chosen[role] = max(scores)[2]
            side_of = {cid: side for side, hexamer in hexamers.items() for cid in hexamer.values()}
            chosen["opposite"] = side_of.get(chosen.get("mcm2")) != side_of.get(chosen.get("mcm4"))
            return chosen

        def build_pairing_notes(chosen):
            """MODEL: Warnings when the chosen chains contradict the expected DDK geometry (TERMINAL)"""
            notes = []
            if not chosen["opposite"]:
                notes.append("Mcm4 nearest Cdc7 lies in the same hexamer as the Mcm2 nearest Dbf4; "
                             "the figure's premise that DDK spans both hexamers needs checking")
            if "tail" not in chosen:
                notes.append("No Mcm4 tail fragment found near the shown Cdc7")
            return notes

        def compute_ddk_direction(structure, chosen, frame):
            """MODEL: Unit direction from the pair axis toward the chosen Dbf4 and Cdc7 (TERMINAL)"""
            atoms = structure.atoms
            ddk = atoms.scene_coords[np.isin(atoms.chain_ids, [chosen["dbf4"], chosen["cdc7"]])]
            radial = ddk.mean(axis=0) - frame["center"]
            radial = radial - np.dot(radial, frame["axis"]) * frame["axis"]
            return radial / np.linalg.norm(radial)

        def build_ddk_display(structure, chain_map, chosen):
            """MODEL: Chains shown in the figure and a spec for every other DDK chain and Mcm4 tail (TERMINAL)"""
            residue_counts = {chain.chain_id: len(chain.existing_residues) for chain in structure.chains}
            tails = [cid for cid in chain_map["Mcm4"] if residue_counts[cid] < MIN_SUBUNIT_RESIDUES]
            kept = {chosen["dbf4"], chosen["cdc7"], chosen.get("tail")}
            others = [cid for cid in chain_map["Dbf4"] + chain_map["Cdc7"] + tails if cid not in kept]
            shown = [chain.chain_id for chain in structure.chains if chain.chain_id not in others]
            return {"shown": shown,
                    "hide_spec": f"#{structure.id_string}/{','.join(others)}" if others else None}

        def select_bound_hexamer(hexamers, chosen):
            """MODEL: Side of the hexamer whose Mcm2 the shown Dbf4 contacts (TERMINAL)"""
            for side, hexamer in hexamers.items():
                if hexamer["Mcm2"] == chosen.get("mcm2"):
                    return side
            raise ValueError(f"{DDK_ENTRY.upper()}: the Mcm2 nearest Dbf4 is in neither full hexamer")

        def build_bound_ring_display(structure, hexamers, bound_side, shown):
            """MODEL: Chains shown in the down-axis panel and a spec for the hexamer Dbf4 does not contact (TERMINAL)"""
            other_ids = list(hexamers[-bound_side].values())
            return {"shown": [cid for cid in shown if cid not in other_ids],
                    "hide_spec": f"#{structure.id_string}/{','.join(other_ids)}"}

        ensure_output_dir()
        structure = open_entry(session, DDK_ENTRY)
        chain_map = classify_chains(structure)
        specs = build_chain_specs(structure, chain_map)
        frame = compute_double_hexamer_frame(structure, chain_map)
        hexamers = split_hexamers(structure, chain_map, frame)
        if not chain_map["Dbf4"]:
            raise ValueError(f"{DDK_ENTRY.upper()}: no Dbf4 chains found")
        chosen = select_ddk_partners(structure, chain_map, hexamers, chain_map["Dbf4"][0])
        direction = compute_ddk_direction(structure, chosen, frame)
        display = build_ddk_display(structure, chain_map, chosen)
        bound_side = select_bound_hexamer(hexamers, chosen)
        ring_display = build_bound_ring_display(structure, hexamers, bound_side, display["shown"])
        ring_center = compute_ring_center(structure, hexamers[bound_side])
        return {
            "entry": DDK_ENTRY,
            "structure": structure,
            "chain_map": chain_map,
            "specs": specs,
            "frame": frame,
            "hexamers": hexamers,
            "chosen": chosen,
            "notes": build_pairing_notes(chosen),
            "shown": display["shown"],
            "hide_spec": display["hide_spec"],
            "ddk_ids": [chosen["dbf4"], chosen["cdc7"]],
            "profile_pose": compute_camera_pose(frame, np.cross(frame["axis"], direction), "ddk_profile", PAIR_SKEW_DEGREES),
            "face_pose": compute_camera_pose(frame, direction, "ddk_face", PAIR_SKEW_DEGREES),
            "bound_hexamer": hexamers[bound_side],
            "ring_center": ring_center,
            "ring_shown": ring_display["shown"],
            "ring_hide_spec": ring_display["hide_spec"],
            "ring_pose": compute_ring_axis_pose(structure, hexamers[bound_side], frame, ring_center,
                                                DDK_RING_VIEW_FACE, "ddk_ring"),
        }

    def render_ddk_scene(session, fig):
        """SUB-CONTROLLER: Style 7PT6 and hide the other DDK copies"""

        def hide_other_copies(session, hide_spec):
            """VIEW: Hide every DDK chain and Mcm4 tail outside the shown copy (TERMINAL)"""
            if hide_spec:
                run(session, f"hide {hide_spec} target s")

        render_structure_scene(session, fig)
        hide_other_copies(session, fig["hide_spec"])

    def render_profile_panel(session, assets, fig):
        """SUB-CONTROLLER: Record the double hexamer with the DDK standing edge on above it, DDK marked for outline"""
        apply_camera_pose(session, fig["profile_pose"])
        capture_scene(session, assets, "ddk_profile", fig["ddk_ids"])

    def load_profile_annotations(session, fig):
        """SUB-CONTROLLER: Dbf4 and Cdc7 labels beside the DDK, one bracket below each hexamer"""

        def layout_ddk_labels(camera, structure, ddk_ids, ring_ids, tips):
            """MODEL: Labels level with their tips, outside the DDK's horizontal extent and above the Mcm top edge (TERMINAL)"""
            width, aspect = camera["field_width"], camera["aspect"]
            rotation = camera["to_camera"][:, :3]
            shift = camera["to_camera"][:, 3]
            atoms = structure.atoms
            local = atoms.scene_coords @ rotation.T + shift
            ddk = local[np.isin(atoms.chain_ids, ddk_ids)]
            ring = local[np.isin(atoms.chain_ids, ring_ids)]
            left = 0.5 + float(ddk[:, 0].min()) / width - DDK_LABEL_GAP
            right = 0.5 + float(ddk[:, 0].max()) / width + DDK_LABEL_GAP
            floor = 0.5 * aspect + float(ring[:, 1].max()) / width + DDK_LABEL_GAP
            ordered = sorted(tips, key=lambda key: tips[key]["x"])
            labels = {}
            for index, key in enumerate(ordered):
                on_left = index < len(ordered) / 2
                labels[key] = {"x": left if on_left else right,
                               "y": max(tips[key]["y"], floor),
                               "anchor": "east" if on_left else "west"}
            return labels

        structure = fig["structure"]
        chosen = fig["chosen"]
        ddk_ids = fig["ddk_ids"]
        ring_ids = [cid for hexamer in fig["hexamers"].values() for cid in hexamer.values()]
        displayed = collect_displayed_atoms([(structure, fig["shown"])])
        targets = [chain_target("dbf4", structure, [chosen["dbf4"]]),
                   chain_target("cdc7", structure, [chosen["cdc7"]])]
        camera = capture_camera(session)
        placed = compute_annotation_tips(camera, targets, displayed)
        labels = layout_ddk_labels(camera, structure, ddk_ids, ring_ids, placed["tips"])
        spans = compute_hexamer_brackets(camera, structure, fig["hexamers"], fig["frame"], displayed, -1)
        crop = compute_crop(camera, displayed)
        return {"scene_name": SCENE_NAMES["ddk_profile"], "tips": placed["tips"], "labels": labels,
                "omitted": placed["omitted"], "spans": spans, "crop": crop,
                "field_width": camera["field_width"], "notes": fig["notes"]}

    def render_face_panel(session, assets, fig):
        """SUB-CONTROLLER: Record the double hexamer with the DDK facing the viewer, DDK marked for outline"""
        apply_camera_pose(session, fig["face_pose"])
        capture_scene(session, assets, "ddk_face", fig["ddk_ids"])

    def load_face_annotations(session, fig):
        """SUB-CONTROLLER: One bracket below each hexamer"""
        structure = fig["structure"]
        displayed = collect_displayed_atoms([(structure, fig["shown"])])
        camera = capture_camera(session)
        spans = compute_hexamer_brackets(camera, structure, fig["hexamers"], fig["frame"], displayed, -1)
        crop = compute_crop(camera, displayed)
        return {"scene_name": SCENE_NAMES["ddk_face"], "tips": {}, "labels": {}, "omitted": {},
                "spans": spans, "crop": crop, "field_width": camera["field_width"]}

    def render_bound_ring_panel(session, assets, fig):
        """SUB-CONTROLLER: Record the Dbf4-bound ring viewed down its axis, other hexamer hidden, DDK marked for outline"""

        def hide_unbound_hexamer(session, hide_spec):
            """VIEW: Hide the hexamer whose Mcm2 Dbf4 does not contact (TERMINAL)"""
            run(session, f"hide {hide_spec} target s")

        hide_unbound_hexamer(session, fig["ring_hide_spec"])
        apply_camera_pose(session, fig["ring_pose"])
        capture_scene(session, assets, "ddk_ring", fig["ddk_ids"])

    def load_bound_ring_annotations(session, fig):
        """SUB-CONTROLLER: Six subunit labels, the gate and the ring geometry, plus Dbf4 and Cdc7 tips labeled beyond the DDK"""

        def compute_ring_anchor(camera, layout):
            """MODEL: Ring centre and outer radius in image widths (TERMINAL)"""
            width, aspect = camera["field_width"], camera["aspect"]
            return {"x": float(0.5 + layout["center"][0] / width),
                    "y": float(0.5 * aspect + layout["center"][1] / width),
                    "radius": float(layout["radius"] / width)}

        def layout_ddk_ring_labels(camera, layout, structure, ddk_ids, tips):
            """MODEL: Labels on the line from the ring centre through each tip, beyond the DDK, spread apart when crowded (TERMINAL)"""
            if not tips:
                return {}
            rotation = camera["to_camera"][:, :3]
            shift = camera["to_camera"][:, 3]
            width, aspect = camera["field_width"], camera["aspect"]
            center = layout["center"]
            atoms = structure.atoms
            ddk = (atoms.scene_coords[np.isin(atoms.chain_ids, ddk_ids)] @ rotation.T + shift)[:, :2]
            radius = float(np.max(np.linalg.norm(ddk - center, axis=1))) + DDK_LABEL_GAP * width
            offsets = {key: (rotation @ tip["xyz"] + shift)[:2] - center for key, tip in tips.items()}
            mean = np.sum([offset / np.linalg.norm(offset) for offset in offsets.values()], axis=0)
            base = float(np.degrees(np.arctan2(mean[1], mean[0])))
            relative = {key: (float(np.degrees(np.arctan2(offset[1], offset[0]))) - base + 180.0) % 360.0 - 180.0
                        for key, offset in offsets.items()}
            order = sorted(relative, key=relative.get)
            min_step = float(np.degrees(LABEL_SPACING * width / radius))
            spread = [relative[order[0]]]
            for key in order[1:]:
                spread.append(max(relative[key], spread[-1] + min_step))
            correction = float(np.mean([relative[key] for key in order]) - np.mean(spread))
            labels = {}
            for key, angle in zip(order, spread):
                theta = np.radians(base + angle + correction)
                point = center + radius * np.array([np.cos(theta), np.sin(theta)])
                facing_ring = (float(np.degrees(theta)) + 180.0) % 360.0
                labels[key] = {"x": float(0.5 + point[0] / width),
                               "y": float(0.5 * aspect + point[1] / width),
                               "anchor": str(int(round(facing_ring)) % 360)}
            return labels

        structure = fig["structure"]
        chosen = fig["chosen"]
        hexamer = fig["bound_hexamer"]
        displayed = collect_displayed_atoms([(structure, fig["ring_shown"])])
        camera = capture_camera(session)
        layout = compute_ring_layout(camera, structure, hexamer, fig["ring_center"])
        specs = [(name.lower(), name, RING_LABEL_GAP, RING_LABEL_GAP) for name in MCM_SUBUNITS]
        specs.append(("gate", "gate", GATE_TIP_GAP, GATE_LABEL_GAP))
        ring_placed = place_radial_annotations(camera, layout, specs)
        targets = [chain_target("dbf4", structure, [chosen["dbf4"]]),
                   chain_target("cdc7", structure, [chosen["cdc7"]])]
        ddk_placed = compute_annotation_tips(camera, targets, displayed)
        ddk_labels = layout_ddk_ring_labels(camera, layout, structure, fig["ddk_ids"], ddk_placed["tips"])
        crop = compute_crop(camera, displayed)
        return {"scene_name": SCENE_NAMES["ddk_ring"],
                "tips": {**ring_placed["tips"], **ddk_placed["tips"]},
                "labels": {**ring_placed["labels"], **ddk_labels},
                "omitted": ddk_placed["omitted"], "crop": crop,
                "field_width": camera["field_width"], "ring": compute_ring_anchor(camera, layout),
                "notes": fig["notes"]}

    # === COORDINATE ===

    reset_scene(session)
    fig = load_ddk_model(session)
    render_ddk_scene(session, fig)
    render_profile_panel(session, assets, fig)
    write_annotations(session, assets, "ddk_profile", load_profile_annotations(session, fig))
    render_face_panel(session, assets, fig)
    write_annotations(session, assets, "ddk_face", load_face_annotations(session, fig))
    render_bound_ring_panel(session, assets, fig)
    write_annotations(session, assets, "ddk_ring", load_bound_ring_annotations(session, fig))

def build_open_closed_figure(session, assets):
    """CONTROLLER: Open 5XF8 ring stacked above a closed 5BK4 ring, superposed on Mcm3/4/6/7, skewed, with anchors"""

    # === SUB-CONTROLLERS ===

    def reset_scene(session):
        """SUB-CONTROLLER: Start from an empty session"""
        clear_session(session)

    def render_pair_scene(session, pair):
        """SUB-CONTROLLER: Style and color both structures"""
        render_structure_scene(session, pair["closed"])
        render_structure_scene(session, pair["open"])

    def render_open_closed(session, assets, stacked):
        """SUB-CONTROLLER: Record the skewed view"""
        apply_camera_pose(session, stacked["pose"])
        capture_scene(session, assets, "openclosed")

    def load_open_closed_annotations(session, pair):
        """SUB-CONTROLLER: Both gates, Mcm2 and Mcm5 of each ring, and the DNA"""
        closed, open_ring = pair["closed"]["structure"], pair["open"]["structure"]
        closed_hex, open_hex = pair["closed_hexamer"], pair["open_hexamer"]
        displayed = collect_displayed_atoms(pair_display_entries(pair))
        targets = [interface_target("open_gate", open_ring, [open_hex["Mcm2"]], open_ring, [open_hex["Mcm5"]]),
                   interface_target("closed_gate", closed, [closed_hex["Mcm2"]], closed, [closed_hex["Mcm5"]]),
                   chain_target("open_mcm2", open_ring, [open_hex["Mcm2"]]),
                   chain_target("open_mcm5", open_ring, [open_hex["Mcm5"]]),
                   chain_target("closed_mcm2", closed, [closed_hex["Mcm2"]]),
                   chain_target("closed_mcm5", closed, [closed_hex["Mcm5"]]),
                   chain_target("dna", closed, pair["closed"]["chain_map"]["DNA"])]
        camera = capture_camera(session)
        placed = compute_annotation_tips(camera, targets, displayed)
        labels = layout_labels(placed["tips"], camera["aspect"])
        return {"scene_name": SCENE_NAMES["openclosed"], "tips": placed["tips"],
                "omitted": placed["omitted"], "labels": labels}

    # === COORDINATE ===

    reset_scene(session)
    pair = load_open_closed_pair(session)
    stacked = compute_stacked_pose(pair, "open_closed", SKEW_DEGREES)
    render_pair_scene(session, pair)
    arrange_open_closed_pair(session, pair, stacked["translation"])
    render_open_closed(session, assets, stacked)
    annotations = load_open_closed_annotations(session, pair)
    write_annotations(session, assets, "openclosed", annotations)

def build_glyph_legend_figure(session, assets):
    """CONTROLLER: Structure counterpart of the Mcm2-7 glyph legend (ring, single subunit, edge on), with anchors"""

    # === SUB-CONTROLLERS ===

    def reset_scene(session):
        """SUB-CONTROLLER: Start from an empty session"""
        clear_session(session)

    def load_subunit_model(session):
        """SUB-CONTROLLER: Load the single-subunit entry, fetch Pfam domains, verify numbering, compute the camera"""

        def select_subunit_chain(chain_map):
            """MODEL: First chain of the chosen subunit (TERMINAL)"""
            if not chain_map[SINGLE_SUBUNIT]:
                raise ValueError(f"{SUBUNIT_ENTRY.upper()}: no {SINGLE_SUBUNIT} chain found")
            return chain_map[SINGLE_SUBUNIT][0]

        def fetch_pfam_domains(accession):
            """MODEL: Pfam domain boundaries for a UniProt accession from the InterPro API (TERMINAL)"""
            import json
            import urllib.request
            with urllib.request.urlopen(INTERPRO_PFAM_URL.format(accession=accession), timeout=30) as response:
                body = response.read()
            if not body:
                return []
            domains = []
            for result in json.loads(body.decode()).get("results", []):
                metadata = result["metadata"]
                name = metadata.get("name")
                name = name.get("name") if isinstance(name, dict) else name
                for protein in result.get("proteins", []):
                    for location in protein.get("entry_protein_locations") or []:
                        for fragment in location.get("fragments", []):
                            domains.append({
                                "accession": metadata["accession"].upper(),
                                "name": name or "",
                                "start": int(fragment["start"]),
                                "end": int(fragment["end"]),
                            })
            return sorted(domains, key=lambda domain: domain["start"])

        def fetch_uniprot_sequence(accession):
            """MODEL: UniProt canonical sequence (TERMINAL)"""
            import urllib.request
            with urllib.request.urlopen(UNIPROT_FASTA_URL.format(accession=accession), timeout=30) as response:
                lines = response.read().decode().splitlines()
            return "".join(line.strip() for line in lines if not line.startswith(">"))

        def check_chain_numbering(structure, chain_id, sequence):
            """MODEL: Fraction of modeled residues whose type matches UniProt at the same number (TERMINAL)"""
            chain = next(chain for chain in structure.chains if chain.chain_id == chain_id)
            residues = chain.existing_residues
            matched = sum(1 for residue in residues
                          if 1 <= residue.number <= len(sequence)
                          and THREE_TO_ONE.get(residue.name) == sequence[residue.number - 1])
            total = len(residues)
            fraction = matched / total if total else 0.0
            if fraction < MIN_NUMBERING_MATCH:
                raise ValueError(
                    f"{SUBUNIT_ENTRY.upper()}/{chain_id}: only {matched}/{total} residues match UniProt "
                    f"numbering; Pfam ranges cannot be mapped onto this chain")
            return {"matched": matched, "total": total, "fraction": fraction}

        def group_domains(domains):
            """MODEL: Sort Pfam domains into the glyph's N-terminal, AAA+ and C-terminal regions (TERMINAL)"""
            aaa = [domain for domain in domains
                   if domain["accession"] in AAA_PFAM_ACCESSIONS or "lid" in domain["name"].lower()]
            if not aaa:
                raise ValueError(f"{SINGLE_SUBUNIT}: no AAA+ Pfam domain returned")
            aaa_start = min(domain["start"] for domain in aaa)
            aaa_end = max(domain["end"] for domain in aaa)
            grouped = []
            for domain in domains:
                if domain in aaa:
                    group = "AAA+"
                elif domain["end"] <= aaa_start:
                    group = "N-terminal"
                elif domain["start"] >= aaa_end:
                    group = "C-terminal"
                else:
                    group = None
                grouped.append({**domain, "group": group})
            return grouped

        def count_resolved_residues(structure, chain_id, grouped):
            """MODEL: Number of modeled residues inside each Pfam range (TERMINAL)"""
            chain = next(chain for chain in structure.chains if chain.chain_id == chain_id)
            numbers = chain.existing_residues.numbers
            return [{**domain, "resolved": int(np.sum((numbers >= domain["start"]) & (numbers <= domain["end"])))}
                    for domain in grouped]

        def build_domain_targets(structure, chain_id, grouped):
            """MODEL: Residue-range spec and region for each classified Pfam domain (TERMINAL)"""
            base = f"#{structure.id_string}/{chain_id}"
            return [(f"{base}:{domain['start']}-{domain['end']}", domain["group"])
                    for domain in grouped if domain["group"]]

        def build_subunit_hide_spec(structure, chain_map, chain_id):
            """MODEL: Spec for every chain except the chosen subunit and the DNA (TERMINAL)"""
            others = [chain.chain_id for chain in structure.chains
                      if chain.chain_id != chain_id and chain.chain_id not in chain_map["DNA"]]
            return f"#{structure.id_string}/{','.join(others)}" if others else None

        def compute_subunit_frame(structure, chain_map, chain_id, grouped):
            """MODEL: DNA axis pointing from the AAA+ region toward the N-terminal region, and the subunit's side (TERMINAL)"""
            atoms = structure.atoms
            coords = atoms.scene_coords
            dna = coords[np.isin(atoms.chain_ids, chain_map["DNA"])]
            if len(dna) == 0:
                raise ValueError(f"{SUBUNIT_ENTRY.upper()}: no DNA chains for the axis")
            dna_center = dna.mean(axis=0)
            _, _, principal_axes = np.linalg.svd(dna - dna_center, full_matrices=False)
            axis = principal_axes[0]
            chain_atoms = atoms.filter(atoms.chain_ids == chain_id)
            numbers = chain_atoms.residues.numbers
            chain_coords = chain_atoms.scene_coords
            n_mask = np.zeros(len(numbers), dtype=bool)
            aaa_mask = np.zeros(len(numbers), dtype=bool)
            for domain in grouped:
                in_range = (numbers >= domain["start"]) & (numbers <= domain["end"])
                if domain["group"] == "N-terminal":
                    n_mask |= in_range
                elif domain["group"] == "AAA+":
                    aaa_mask |= in_range
            if not (n_mask.any() and aaa_mask.any()):
                raise ValueError(f"{SUBUNIT_ENTRY.upper()}/{chain_id}: N-terminal or AAA+ region not modeled")
            direction = chain_coords[n_mask].mean(axis=0) - chain_coords[aaa_mask].mean(axis=0)
            axis = axis * np.sign(np.dot(direction, axis))
            center = chain_coords.mean(axis=0)
            radial = center - dna_center
            radial = radial - np.dot(radial, axis) * axis
            return {"frame": {"center": center, "axis": axis}, "toward_camera": radial / np.linalg.norm(radial)}

        def summarize_regions(structure, chain_id, grouped):
            """MODEL: Pfam ranges per glyph region and the first and last modeled residues (TERMINAL)"""
            chain = next(chain for chain in structure.chains if chain.chain_id == chain_id)
            numbers = chain.existing_residues.numbers
            regions = {}
            for domain in grouped:
                if domain["group"]:
                    regions.setdefault(domain["group"], []).append((domain["start"], domain["end"]))
            return {"regions": regions, "first": int(numbers.min()), "last": int(numbers.max())}

        accession = UNIPROT_ACCESSIONS[SINGLE_SUBUNIT]
        structure = open_entry(session, SUBUNIT_ENTRY)
        chain_map = classify_chains(structure)
        specs = build_chain_specs(structure, chain_map)
        chain_id = select_subunit_chain(chain_map)
        sequence = fetch_uniprot_sequence(accession)
        numbering = check_chain_numbering(structure, chain_id, sequence)
        grouped = group_domains(fetch_pfam_domains(accession))
        domains = count_resolved_residues(structure, chain_id, grouped)
        targets = build_domain_targets(structure, chain_id, grouped)
        domain_colors = [(spec, shade_color(session, SUBUNIT_COLORS[SINGLE_SUBUNIT], DOMAIN_SHADES[group]))
                         for spec, group in targets]
        hide_spec = build_subunit_hide_spec(structure, chain_map, chain_id)
        placement = compute_subunit_frame(structure, chain_map, chain_id, grouped)
        pose = compute_camera_pose(placement["frame"], placement["toward_camera"], "subunit")
        summary = summarize_regions(structure, chain_id, grouped)
        return {
            "fig": {"entry": SUBUNIT_ENTRY, "structure": structure, "chain_map": chain_map, "specs": specs},
            "accession": accession,
            "chain_id": chain_id,
            "chain_spec": f"#{structure.id_string}/{chain_id}",
            "summary": summary,
            "numbering": numbering,
            "domains": domains,
            "domain_colors": domain_colors,
            "hide_spec": hide_spec,
            "pose": pose,
        }

    def load_ring_panels_model(session, pair):
        """SUB-CONTROLLER: Down-axis camera for the open ring and lightened colors for the far arc"""

        def compute_ring_pose(pair):
            """MODEL: Camera on the ring axis facing the chosen face of the open ring, near arc at the top (TERMINAL)"""
            geometry = pair["geometry"]
            z_axis = geometry["n_direction"] if RING_VIEW_FACE == "N" else -geometry["n_direction"]
            y_axis = geometry["near_direction"] - np.dot(geometry["near_direction"], z_axis) * z_axis
            y_axis = y_axis / np.linalg.norm(y_axis)
            x_axis = np.cross(y_axis, z_axis)
            center = pair["open_center"]
            return {"axes": [x_axis, y_axis, z_axis], "origin": center + CAMERA_DISTANCE * z_axis, "name": "ring"}

        def build_far_arc_targets(pair):
            """MODEL: Spec and subunit for every far-arc chain in both rings (TERMINAL)"""
            closed_id = pair["closed"]["structure"].id_string
            open_id = pair["open"]["structure"].id_string
            targets = []
            for name in FAR_ARC_SUBUNITS:
                targets.append((f"#{closed_id}/{pair['closed_hexamer'][name]}", name))
                targets.append((f"#{open_id}/{pair['open_hexamer'][name]}", name))
            return targets

        ring_pose = compute_ring_pose(pair)
        far_arc_colors = [(spec, shade_color(session, SUBUNIT_COLORS[name], FAR_ARC_LIGHTEN))
                          for spec, name in build_far_arc_targets(pair)]
        return {"ring_pose": ring_pose, "far_arc_colors": far_arc_colors}

    def render_all_scenes(session, pair, subunit):
        """SUB-CONTROLLER: Style and color all three structures"""
        render_structure_scene(session, pair["closed"])
        render_structure_scene(session, pair["open"])
        render_structure_scene(session, subunit["fig"])

    def render_ring_panel(session, assets, pair, subunit, panels):
        """SUB-CONTROLLER: Open ring alone, viewed down its axis"""

        def show_open_ring_only(session, pair, subunit):
            """VIEW: Hide the closed pair, the subunit entry and the open ring's loading partners (TERMINAL)"""
            run(session, f"hide #{pair['closed']['structure'].id_string} models")
            run(session, f"hide #{subunit['fig']['structure'].id_string} models")
            if pair["hide_specs"]["partners"]:
                run(session, f"hide {pair['hide_specs']['partners']} target s")

        show_open_ring_only(session, pair, subunit)
        apply_camera_pose(session, panels["ring_pose"])
        capture_scene(session, assets, "ring")

    def render_subunit_panel(session, assets, pair, subunit):
        """SUB-CONTROLLER: One subunit along the DNA axis, colored by Pfam domain"""

        def log_domain_annotation(session, subunit):
            """VIEW: Report numbering check and Pfam ranges used for the domain coloring (TERMINAL)"""
            numbering = subunit["numbering"]
            session.logger.info(
                f"{SINGLE_SUBUNIT} ({subunit['accession']}) in {SUBUNIT_ENTRY.upper()} {subunit['chain_spec']}: "
                f"{numbering['matched']}/{numbering['total']} residues match UniProt numbering")
            for domain in subunit["domains"]:
                session.logger.info(
                    f"  {domain['accession']} {domain['name']}: {domain['start']}-{domain['end']}, "
                    f"region {domain['group'] or 'not colored (overlaps AAA+)'}, {domain['resolved']} residues modeled")
            if not any(domain["group"] == "C-terminal" and domain["resolved"] for domain in subunit["domains"]):
                session.logger.warning(f"  {SINGLE_SUBUNIT}: no modeled residues in a C-terminal Pfam domain")

        def isolate_subunit(session, pair, subunit):
            """VIEW: Show only the chosen subunit and the DNA of the subunit entry (TERMINAL)"""
            run(session, f"hide #{pair['closed']['structure'].id_string} models")
            run(session, f"hide #{pair['open']['structure'].id_string} models")
            run(session, f"show #{subunit['fig']['structure'].id_string} models")
            if subunit["hide_spec"]:
                run(session, f"hide {subunit['hide_spec']} target s")

        def color_domains(session, subunit):
            """VIEW: Color the subunit gray, then each Pfam region in its shade (TERMINAL)"""
            run(session, f"color {subunit['chain_spec']} {UNASSIGNED_COLOR}")
            for spec, color in subunit["domain_colors"]:
                run(session, f"color {spec} {color}")

        log_domain_annotation(session, subunit)
        isolate_subunit(session, pair, subunit)
        color_domains(session, subunit)
        apply_camera_pose(session, subunit["pose"])
        capture_scene(session, assets, "subunit")

    def prepare_edge_scene(session, pair, subunit, panels):
        """SUB-CONTROLLER: Bring back the open and closed rings and lighten the far arc"""

        def show_pair_models(session, pair, subunit):
            """VIEW: Hide the subunit entry and show the open and closed structures (TERMINAL)"""
            run(session, f"hide #{subunit['fig']['structure'].id_string} models")
            run(session, f"show #{pair['closed']['structure'].id_string} models")
            run(session, f"show #{pair['open']['structure'].id_string} models")

        def lighten_far_arc(session, far_arc_colors):
            """VIEW: Recolor Mcm6, Mcm4 and Mcm7 of both rings in their lightened shades (TERMINAL)"""
            for spec, color in far_arc_colors:
                run(session, f"color {spec} {color}")

        show_pair_models(session, pair, subunit)
        lighten_far_arc(session, panels["far_arc_colors"])

    def render_edge_panel(session, assets, stacked):
        """SUB-CONTROLLER: Record the open and closed rings edge on"""
        apply_camera_pose(session, stacked["pose"])
        capture_scene(session, assets, "edge")

    def load_ring_annotations(session, pair):
        """SUB-CONTROLLER: The six subunits of the open ring and the Mcm5-Mcm2 gap"""
        open_ring, open_hex = pair["open"]["structure"], pair["open_hexamer"]
        displayed = collect_displayed_atoms([(open_ring, list(open_hex.values()))])
        targets = [chain_target(name.lower(), open_ring, [open_hex[name]]) for name in MCM_SUBUNITS]
        targets.append(interface_target("gap", open_ring, [open_hex["Mcm2"]], open_ring, [open_hex["Mcm5"]]))
        camera = capture_camera(session)
        placed = compute_annotation_tips(camera, targets, displayed)
        labels = layout_labels(placed["tips"], camera["aspect"])
        return {"scene_name": SCENE_NAMES["ring"], "tips": placed["tips"],
                "omitted": placed["omitted"], "labels": labels}

    def load_subunit_annotations(session, subunit):
        """SUB-CONTROLLER: Pfam regions, the N and C ends, and the DNA of the single-subunit panel"""
        structure = subunit["fig"]["structure"]
        chain_id = subunit["chain_id"]
        summary = subunit["summary"]
        dna_ids = subunit["fig"]["chain_map"]["DNA"]
        displayed = collect_displayed_atoms([(structure, [chain_id] + dna_ids)])
        targets = [range_target("n_region", structure, chain_id, summary["regions"].get("N-terminal", [])),
                   range_target("aaa_region", structure, chain_id, summary["regions"].get("AAA+", [])),
                   range_target("c_region", structure, chain_id, summary["regions"].get("C-terminal", [])),
                   range_target("n_end", structure, chain_id, [(summary["first"], summary["first"])]),
                   range_target("c_end", structure, chain_id, [(summary["last"], summary["last"])]),
                   chain_target("dna", structure, dna_ids)]
        camera = capture_camera(session)
        placed = compute_annotation_tips(camera, targets, displayed)
        labels = layout_labels(placed["tips"], camera["aspect"])
        return {"scene_name": SCENE_NAMES["subunit"], "tips": placed["tips"],
                "omitted": placed["omitted"], "labels": labels}

    def load_edge_annotations(session, pair):
        """SUB-CONTROLLER: Near and far arcs of the closed ring, both gates, and the DNA"""
        closed, open_ring = pair["closed"]["structure"], pair["open"]["structure"]
        closed_hex, open_hex = pair["closed_hexamer"], pair["open_hexamer"]
        displayed = collect_displayed_atoms(pair_display_entries(pair))
        targets = [chain_target("near_arc", closed, [closed_hex[name] for name in NEAR_ARC_SUBUNITS]),
                   chain_target("far_arc", closed, [closed_hex[name] for name in FAR_ARC_SUBUNITS]),
                   interface_target("open_gate", open_ring, [open_hex["Mcm2"]], open_ring, [open_hex["Mcm5"]]),
                   interface_target("closed_gate", closed, [closed_hex["Mcm2"]], closed, [closed_hex["Mcm5"]]),
                   chain_target("dna", closed, pair["closed"]["chain_map"]["DNA"])]
        camera = capture_camera(session)
        placed = compute_annotation_tips(camera, targets, displayed)
        labels = layout_labels(placed["tips"], camera["aspect"])
        return {"scene_name": SCENE_NAMES["edge"], "tips": placed["tips"],
                "omitted": placed["omitted"], "labels": labels}

    # === COORDINATE ===

    reset_scene(session)
    pair = load_open_closed_pair(session)
    subunit = load_subunit_model(session)
    panels = load_ring_panels_model(session, pair)
    stacked = compute_stacked_pose(pair, "edge", 0.0)
    render_all_scenes(session, pair, subunit)
    render_ring_panel(session, assets, pair, subunit, panels)
    write_annotations(session, assets, "ring", load_ring_annotations(session, pair))
    render_subunit_panel(session, assets, pair, subunit)
    write_annotations(session, assets, "subunit", load_subunit_annotations(session, subunit))
    prepare_edge_scene(session, pair, subunit, panels)
    arrange_open_closed_pair(session, pair, stacked["translation"])
    render_edge_panel(session, assets, stacked)
    write_annotations(session, assets, "edge", load_edge_annotations(session, pair))

# =============================================================================
# MAIN CONTROLLER
# =============================================================================

def build_mcm_structure_assets(session):
    """CONTROLLER: Build every structure scene of the MCM figures and write their 3D geometry to one archive"""

    # === SUB-CONTROLLERS ===

    def prepare_asset_store(session):
        """SUB-CONTROLLER: Start an empty store with the run metadata"""

        def create_asset_store(session):
            """MODEL: Empty store for meshes, binary arrays and scenes, with generator, entries, colors and constants (TERMINAL)"""
            try:
                from chimerax.core import version as chimerax_version
            except ImportError:
                chimerax_version = "unknown"
            return {
                "meta": {
                    "format": ASSET_FORMAT,
                    "version": ASSET_VERSION,
                    "generator": "export_mcm_structure_assets.py",
                    "chimerax": str(chimerax_version),
                    "created": datetime.now(timezone.utc).isoformat(timespec="seconds"),
                    "entries": {"architecture": ARCHITECTURE_ENTRY, "ddk": DDK_ENTRY,
                                "open_ring": OPEN_RING_ENTRY, "subunit": SUBUNIT_ENTRY},
                    "figures": {name: list(keys) for name, keys in SCENE_FIGURES.items()},
                    "style": {"background": "white", "lighting": "soft", "silhouette_width": 1,
                              "camera": "ortho", "surface_grid_spacing": SURFACE_GRID_SPACING},
                    "colors": {"subunits": SUBUNIT_COLORS, "dna": DNA_COLOR, "unassigned": UNASSIGNED_COLOR,
                               "far_arc_lighten": FAR_ARC_LIGHTEN, "domain_shades": DOMAIN_SHADES},
                    "constants": {"ring_order": list(RING_ORDER), "face_subunits": {k: list(v) for k, v in FACE_SUBUNITS.items()},
                                  "near_arc": list(NEAR_ARC_SUBUNITS), "far_arc": list(FAR_ARC_SUBUNITS),
                                  "superpose_subunits": list(SUPERPOSE_SUBUNITS), "single_subunit": SINGLE_SUBUNIT,
                                  "skew_degrees": SKEW_DEGREES, "pair_skew_degrees": PAIR_SKEW_DEGREES,
                                  "stack_spacing": STACK_SPACING, "ring_view_face": RING_VIEW_FACE,
                                  "ddk_ring_view_face": DDK_RING_VIEW_FACE},
                },
                "meshes": {},
                "arrays": {},
                "scenes": {},
            }

        return create_asset_store(session)

    def export_asset_archive(session, assets):
        """SUB-CONTROLLER: Pack the store into manifest and binary files, write the archive, report its contents"""

        def pack_asset_archive(assets):
            """MODEL: File name to bytes for the manifest and every binary array (TERMINAL)"""
            missing = [key for key in SCENE_NAMES if key not in assets["scenes"]]
            manifest = {"meta": {**assets["meta"], "missing_scenes": missing},
                        "meshes": assets["meshes"], "scenes": assets["scenes"]}
            files = {"manifest.json": json.dumps(manifest, indent=1).encode()}
            for name, array in assets["arrays"].items():
                files[name] = np.ascontiguousarray(array).tobytes()
            return files

        def write_asset_archive(files):
            """VIEW: Write all files into ASSET_FILE as one deflated zip, replacing any earlier archive (TERMINAL)"""
            partial = ASSET_FILE.with_suffix(".partial")
            with zipfile.ZipFile(partial, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
                for name, data in files.items():
                    archive.writestr(name, data)
            os.replace(partial, ASSET_FILE)

        def log_asset_archive(session, assets, files):
            """VIEW: Report the archive path, size, mesh and scene counts, and any scene not recorded (TERMINAL)"""
            size = ASSET_FILE.stat().st_size / 1e6
            session.logger.info(f"Structure assets written: {ASSET_FILE} ({size:.1f} MB, "
                                f"{len(assets['meshes'])} meshes, {len(assets['scenes'])} scenes, {len(files)} files)")
            missing = [key for key in SCENE_NAMES if key not in assets["scenes"]]
            if missing:
                session.logger.warning(f"  Scenes not recorded: {', '.join(missing)}")

        files = pack_asset_archive(assets)
        write_asset_archive(files)
        log_asset_archive(session, assets, files)

    # === COORDINATE ===

    assets = prepare_asset_store(session)
    build_architecture_figure(session, assets)
    build_ddk_figure(session, assets)
    build_open_closed_figure(session, assets)
    build_glyph_legend_figure(session, assets)
    export_asset_archive(session, assets)


# =============================================================================
# ENTRY POINT
# =============================================================================

if INSIDE_CHIMERAX:
    try:
        build_mcm_structure_assets(session)
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()
