/* The lineage pages: many divisions shown as pages turned in a book.

   TourPages.mount(spec, box) draws lineages of CHROM_RULE.lineage, or, with
   spec.mode 'hist', the distribution over many lineages. A lineage slide
   compares two genotypes from the same spore and the same draws: a
   reference row (spec.ref, wild type unless the slide says otherwise) over
   the slide's genotype (spec.alleles), as the alleles chapter sets a mutant
   against wild type. Each row is a book whose page is one division, zoomed on
   one end: the essential gene nearest that end, the interior between them,
   and the telomere with its Rap1 sites and cap, or, once the cap is lost, its
   RPA-coated single strand. Beside each book, mitosis as the checkpoint
   leaves it: Esp1 and Cdc5 kept home, or released. The end followed is the
   one the slide's genotype loses first, or its shorter end if it keeps both.
   A page turn passes twenty divisions while nothing changes in either row,
   and one division at a time near a change. Arrows on the books turn pages
   by hand. The second view stacks every division of each lineage, early at
   the top, both ends drawn to length, the two lineages side by side.
   Everything drawn is read off the lineages; nothing here decides biology. */

var TourPages = (function () {
  var NS = 'http://www.w3.org/2000/svg';
  var STEP = 20;              // divisions a page turn passes while nothing changes
  var Z = { j: 440, y: 52, h: 4, kb: 15, bp: 0.8, maxBp: 520 };   // the zoomed page: junction x, strand y, px per kb and per bp
  var K = { mid: 440, tel: 0.5, kb: 5, top: 34 };                   // the all-divisions view: px per bp and per kb
  var state = { timer: null, box: null, spec: null, rows: [], frames: [], at: 0, side: 'R', playing: false, busy: false };
  var RPA = function () { return (window.TOUR_FIGURES || {})['glyph-rpa'] || ''; };
  var FIG = function (k) { return (window.TOUR_FIGURES || {})[k] || ''; };

  // === BASE CONTROLLER: mount =================================================

  function mount(spec, box) {
    // BASE CONTROLLER: compute both lineages, merge their pages into frames, build the books, and start turning.
    unmount();
    state.box = box;
    state.spec = spec;
    if (spec.mode === 'hist') { mountHist(spec, box); return; }
    state.rows = [
      { label: (spec.ref || {}).label || 'wild type', run: CHROM_RULE.lineage(spec.seed, { alleles: (spec.ref || {}).alleles || {}, max: spec.max }) },
      { label: spec.label, run: CHROM_RULE.lineage(spec.seed, { alleles: spec.alleles || {}, max: spec.max }) }
    ];
    state.frames = mergeFrames(state.rows);
    state.side = followedEnd(state.rows[1].run);
    setScale(state.rows);
    buildShell(box, spec, state.rows, state.side);
    wireControls(box);
    state.at = 0;
    showFrame(0, 0);
    state.playing = true;
    schedule(1600);

    // === SUB-CONTROLLERS ===

    function mergeFrames(rows) {
      // MODEL: the frames shown: each row's pages next to a change, every twentieth division, the first and last,
      // merged in order of division; each frame names the page each row shows (TERMINAL)
      var keys = [], seen = {};
      var keyOf = rows.map(function (r) {
        var rank = {}, out = [];
        r.run.pages.forEach(function (p) { rank[p.g] = (rank[p.g] || 0) + 1; out.push(p.g * 10 + rank[p.g] - 1); });
        return out;
      });
      rows.forEach(function (r, n) {
        var pages = r.run.pages, near = {}, i, k;
        for (i = 1; i < pages.length; i += 1) {
          if (pages[i].state !== pages[i - 1].state || pages[i].L.capped !== pages[i - 1].L.capped
              || pages[i].R.capped !== pages[i - 1].R.capped || pages[i].words !== pages[i - 1].words) {
            for (k = Math.max(0, i - 1); k <= Math.min(pages.length - 1, i + 1); k += 1) { near[k] = true; }
          }
        }
        for (i = 0; i < pages.length; i += 1) {
          if (i === 0 || i === pages.length - 1 || near[i] || pages[i].g % STEP === 0) {
            if (!seen[keyOf[n][i]]) { seen[keyOf[n][i]] = true; keys.push(keyOf[n][i]); }
          }
        }
      });
      keys.sort(function (a, b) { return a - b; });
      return keys.map(function (key) {
        return { g: Math.floor(key / 10), pages: keyOf.map(function (ks) {
          var i, last = 0;
          for (i = 0; i < ks.length; i += 1) { if (ks[i] <= key) { last = i; } }
          return last;
        }) };
      });
    }

    function followedEnd(run) {
      // MODEL: the end the pages follow: the first the slide's genotype loses, or its shorter at the last page (TERMINAL)
      var i, p, last = run.pages[run.pages.length - 1];
      for (i = 0; i < run.pages.length; i += 1) {
        p = run.pages[i];
        if (!p.L.capped) { return 'L'; }
        if (!p.R.capped) { return 'R'; }
      }
      return last.L.bp < last.R.bp ? 'L' : 'R';
    }

    function setScale(rows) {
      // MODEL: px per bp for the page and the all-divisions view, from the longest end either lineage reaches (TERMINAL)
      var most = 400;
      rows.forEach(function (r) { r.run.pages.forEach(function (p) { most = Math.max(most, p.L.bp, p.R.bp); }); });
      Z.maxBp = most;
      Z.bp = 350 / most;
      K.tel = 260 / most;
    }

    function buildShell(box, spec, rows, side) {
      // VIEW: the header, the controls, a book and a mitosis strip per row, the network, and the all-divisions view (TERMINAL)
      var books = rows.map(function (r, n) {
        return '<div class="tpgrowx"><div class="tpgrowhead"><span class="tpggeno">' + r.label + '</span>'
          + '<span class="tpgrowstate" id="tpgstate' + n + '"></span></div>'
          + '<div class="tpgrowbody"><div class="tpgbook"><div class="tpgstack"></div><div class="tpgleaf" id="tpgback' + n + '"></div>'
          + '<div class="tpgleaf front" id="tpgfront' + n + '"></div>'
          + '<button type="button" class="tpgarrow prev" data-nav="prev" aria-label="Previous page">‹</button>'
          + '<button type="button" class="tpgarrow next" data-nav="next" aria-label="Next page">›</button></div>'
          + '<div class="tpgmito" id="tpgmito' + n + '"></div></div></div>';
      }).join('');
      var alls = rows.map(function (r, n) {
        return '<div class="tpgallcol"><div class="tpggeno">' + r.label + '</div><div id="tpgall' + n + '"></div></div>';
      }).join('');
      box.innerHTML = '<div class="tpages"><div class="tpghead"><div class="tpgcount">Division <b id="tpgn">0</b>'
        + '<span class="tpgturn" id="tpgturn"></span></div></div>'
        + '<div class="tpgtools"><span class="tpgviews" role="tablist">'
        + '<button type="button" class="tpgview on" data-view="pages">One division, TEL-' + side + '</button>'
        + '<button type="button" class="tpgview" data-view="all">All divisions</button></span>'
        + '<button type="button" class="tpgplay" id="tpgplay">Pause</button></div>'
        + '<div class="tpgpane" id="tpgpane-pages">' + books
        + '<details class="tpggrn" open><summary class="tlab">The Rad53 network in ' + rows[1].label + ' at this division</summary>'
        + '<div id="tpggrn"></div></details></div>'
        + '<div class="tpgpane" id="tpgpane-all" hidden><div class="tpgalls">' + alls + '</div></div></div>';
    }

    function wireControls(box) {
      // VIEW: the arrows, the play button, the view buttons and a click on a row of the all-divisions view (TERMINAL)
      box.querySelectorAll('[data-nav]').forEach(function (b) {
        b.addEventListener('click', function () { navigate(b.getAttribute('data-nav')); });
      });
      box.querySelector('#tpgplay').addEventListener('click', function () { navigate('play'); });
      box.querySelectorAll('.tpgview').forEach(function (b) {
        b.addEventListener('click', function () { navigate('view', b.getAttribute('data-view')); });
      });
      box.querySelector('.tpgalls').addEventListener('click', function (ev) {
        var t = ev.target.closest && ev.target.closest('[data-g]');
        if (t) { navigate('goto', +t.getAttribute('data-g')); }
      });
    }
  }

  // === BASE CONTROLLER: navigate ==============================================

  function navigate(action, arg) {
    // BASE CONTROLLER: turn forward or back by hand, play or pause, switch views, or go to a division.
    if (!state.rows.length) { return; }
    if (action === 'next' || action === 'prev') {
      pause();
      if (!state.busy) { stepBy(action === 'next' ? 1 : -1); }
    } else if (action === 'play') {
      if (state.playing) { pause(); } else { play(); }
    } else if (action === 'view') {
      switchView(arg);
    } else if (action === 'goto') {
      pause();
      switchView('pages');
      jumpTo(arg);
    }

    // === SUB-CONTROLLERS ===

    function stepBy(d) {
      // SUB-CONTROLLER: the next or previous frame, turned over the spine or back
      var k = state.at + d;
      if (k < 0 || k >= state.frames.length) { return; }
      state.at = k;
      showFrame(k, d);
    }

    function jumpTo(g) {
      // SUB-CONTROLLER: the last frame at or before a division, without a turn
      var k = 0;
      state.frames.forEach(function (f, n) { if (f.g <= g) { k = n; } });
      state.at = k;
      showFrame(k, 0);
    }

    function pause() {
      // VIEW: stop the turning, and offer play (TERMINAL)
      if (state.timer) { clearTimeout(state.timer); state.timer = null; }
      state.playing = false;
      document.getElementById('tpgplay').textContent = 'Play';
    }

    function play() {
      // SUB-CONTROLLER: start turning again, from the spore if the last frame is showing
      if (state.at >= state.frames.length - 1) { state.at = 0; showFrame(0, 0); }
      state.playing = true;
      document.getElementById('tpgplay').textContent = 'Pause';
      schedule(900);
    }

    function switchView(view) {
      // VIEW: show the books or the all-divisions view, and mark its button (TERMINAL)
      document.getElementById('tpgpane-pages').hidden = view !== 'pages';
      document.getElementById('tpgpane-all').hidden = view !== 'all';
      state.box.querySelectorAll('.tpgview').forEach(function (b) {
        b.classList.toggle('on', b.getAttribute('data-view') === view);
      });
    }
  }

  function schedule(wait) {
    // SUB-CONTROLLER: turn to the next frame after a pause, until the last
    state.timer = setTimeout(function () {
      state.timer = null;
      if (!state.playing) { return; }
      if (state.at >= state.frames.length - 1) {
        state.playing = false;
        document.getElementById('tpgplay').textContent = 'Play';
        return;
      }
      state.at += 1;
      showFrame(state.at, 1);
      schedule(1500);
    }, wait);
  }

  function showFrame(k, dir) {
    // SUB-CONTROLLER: turn each row whose page changed, then the header, mitosis, network and all-divisions view
    var f = state.frames[k], prev = k ? state.frames[k - 1] : null;
    state.rows.forEach(function (r, n) {
      var page = r.run.pages[f.pages[n]], moved = !prev || prev.pages[n] !== f.pages[n];
      turnLeaves(n, pageSvg(page, r.run, state.side), moved ? dir : 0);
      document.getElementById('tpgstate' + n).textContent = page.words;
      document.getElementById('tpgmito' + n).innerHTML = FIG('mito-' + mitoKey(page));
      document.getElementById('tpgall' + n).innerHTML = allSvg(r.run, f.pages[n]);
    });
    var mut = state.rows[1];
    document.getElementById('tpggrn').innerHTML = FIG(grnKey(mut.run.pages[f.pages[1]], mut.run));
    writeHeader(f, prev);
    state.box.querySelectorAll('.tpgarrow.prev').forEach(function (b) { b.disabled = k === 0; });
    state.box.querySelectorAll('.tpgarrow.next').forEach(function (b) { b.disabled = k === state.frames.length - 1; });

    function turnLeaves(n, html, d) {
      // VIEW: forward, the front leaf turns over the spine and leaves the new page beneath; back, the
      // previous page turns back over the spine onto the book; in place, both leaves take the page (TERMINAL)
      var front = document.getElementById('tpgfront' + n), back = document.getElementById('tpgback' + n);
      if (d > 0) {
        back.innerHTML = html;
        state.busy = true;
        front.classList.add('turning');
        setTimeout(function () {
          front.classList.add('settle');
          front.innerHTML = html;
          front.classList.remove('turning');
          void front.offsetWidth;
          front.classList.remove('settle');
          state.busy = false;
        }, 820);
      } else if (d < 0) {
        state.busy = true;
        front.classList.add('settle');
        front.classList.add('turning');
        front.innerHTML = html;
        void front.offsetWidth;
        front.classList.remove('settle');
        front.classList.remove('turning');
        setTimeout(function () { back.innerHTML = html; state.busy = false; }, 820);
      } else {
        back.innerHTML = html;
        front.innerHTML = html;
      }
    }

    function writeHeader(f, prev) {
      // VIEW: the division count, and how many divisions the turn passed (TERMINAL)
      document.getElementById('tpgn').textContent = f.g;
      document.getElementById('tpgturn').textContent = prev && f.g - prev.g > 1 ? '  (page turn: ' + (f.g - prev.g) + ' divisions)'
        : (prev && f.g === prev.g ? '  (same division)' : '');
    }
  }

  // === SHARED FUNCTIONS =====================================================

  function grnKey(p, run) {
    // MODEL: which drawing of the Rad53 network this page shows: rad53-21 drawn removed, and the kind of page (TERMINAL)
    var kind = p.state === 'dividing' ? 'capped' : p.state;
    if (p.state === 'dead') { kind = p.death === 'arrest' ? 'deadarrest' : 'deadloss'; }
    return 'grncap-' + ((run.alleles || {}).rad53_21 ? 'rad53' : 'wt') + '-' + kind;
  }

  function mitoKey(p) {
    // MODEL: mitosis at this page: held while the cell is arrested, released otherwise, faded once it has died (TERMINAL)
    if (p.state === 'dead') { return p.death === 'arrest' ? 'deadhold' : 'deadgo'; }
    return p.state === 'arrested' ? 'hold' : 'go';
  }

  function pageSvg(p, run, side) {
    // VIEW: one division zoomed on one end: the essential gene, the interior to the telomere, and the telomere with its cap or its RPA (TERMINAL)
    // Two scales meet at the junction: the interior in kb to its left, the
    // telomere in bp to its right, each with its own scale bar.
    var e = p[side], other = p[side === 'L' ? 'R' : 'L'], y = Z.y, h = Z.h, J = Z.j, out = [], j;
    var gx = J - run.geneKb * Z.kb, lost = Math.min(run.geneKb, e.eroded) * Z.kb, len = Math.min(Z.maxBp, e.bp) * Z.bp;
    var geneLost = e.eroded >= run.geneKb, rapW = Math.min(12, 19 * Z.bp - 1.5);
    out.push('<rect class="tpgint" x="56" y="' + (y - h - 0.5) + '" width="' + (J - 56 - lost) + '" height="' + h + '"/>'
      + '<rect class="tpgint" x="56" y="' + (y + 0.5) + '" width="' + (J - 56 - lost) + '" height="' + h + '"/>');
    if (lost > 0) {
      out.push('<rect class="tpggone" x="' + (J - lost) + '" y="' + (y - h - 1) + '" width="' + lost + '" height="' + (2 * h + 2) + '"/>'
        + '<text class="tpgsmall" x="' + (J - lost / 2) + '" y="' + (y - 12) + '">' + e.eroded + ' kb eroded</text>');
    }
    out.push('<rect class="tpggene' + (geneLost ? ' lost' : '') + '" x="' + (gx - 13) + '" y="' + (y - 11) + '" width="26" height="22" rx="3"/>'
      + '<text class="tpggenelab' + (geneLost ? ' lost' : '') + '" x="' + gx + '" y="' + (y + 26) + '">' + (geneLost ? 'essential gene lost' : 'essential gene') + '</text>');
    out.push('<text class="tpgsmall start" x="58" y="' + (y - 18) + '">← toward the centromere</text>');
    out.push('<path class="tpgjunc" d="M' + J + ' ' + (y - 20) + ' V' + (y + 14) + '"/>');
    if (e.capped) {
      out.push('<rect class="tpgG" x="' + J + '" y="' + (y - h - 0.5) + '" width="' + len + '" height="' + h + '"/>'
        + '<rect class="tpgC" x="' + J + '" y="' + (y + 0.5) + '" width="' + len + '" height="' + h + '"/>');
      for (j = 0; j < e.sites; j += 1) {
        out.push('<rect class="tpgrap" x="' + (J + (j + 0.5) * 19 * Z.bp - rapW / 2) + '" y="' + (y - h - 10) + '" width="' + rapW + '" height="7" rx="1.5"/>');
      }
      // Strand ends: the G-rich strand runs 5' to 3' toward the tip.
      out.push('<text class="tpgpol" x="' + (J + len + 2) + '" y="' + (y - h - 3) + '">3\u2032</text>'
        + '<text class="tpgpol" x="' + (J + len + 2) + '" y="' + (y + h + 12) + '">5\u2032</text>');
      out.push('<rect class="tpgcdc13" x="' + (J + len + 4) + '" y="' + (y - 6) + '" width="34" height="12" rx="2"/>'
        + '<text class="tpgglyph" x="' + (J + len + 21) + '" y="' + (y + 3) + '">Cdc13</text>');
    } else {
      var stub = J - lost, ss = Math.max(60, len);
      out.push('<rect class="tpgss" x="' + stub + '" y="' + (y - h - 0.5) + '" width="' + ss + '" height="1.8"/>');
      out.push('<text class="tpgpol" x="' + (stub + ss + 3) + '" y="' + (y - h + 3) + '">3\u2032</text>'
        + '<text class="tpgpol" x="' + (stub + 2) + '" y="' + (y + h + 12) + '">5\u2032</text>');
      for (j = 0; j < Math.min(14, Math.floor(ss / 20)); j += 1) {
        out.push('<g transform="translate(' + (stub + 6 + j * 20) + ' ' + (y - h - 1) + ') scale(1.3)">' + RPA() + '</g>');
      }
    }
    out.push('<path class="tpgscale" d="M' + (J - 20 - 5 * Z.kb) + ' 94 h' + (5 * Z.kb) + '"/><text class="tpgsmall" x="' + (J - 20 - 2.5 * Z.kb) + '" y="106">5 kb</text>'
      + '<path class="tpgscale" d="M' + (J + 20) + ' 94 h' + (100 * Z.bp) + '"/><text class="tpgsmall" x="' + (J + 20 + 50 * Z.bp) + '" y="106">100 bp</text>');
    out.push('<text class="tpgend" x="' + (J + 140) + '" y="106" text-anchor="start">TEL-' + side + ': ' + endWords(e, run) + '</text>');
    out.push('<text class="tpgsmall end" x="860" y="16">the other end, TEL-' + (side === 'L' ? 'R' : 'L') + ': '
      + endWords(other, run) + '</text>');
    return '<svg class="tpgsvg" viewBox="0 0 880 114" xmlns="' + NS + '">' + out.join('') + '</svg>';
  }

  function endWords(e, run) {
    // MODEL: one end's state in words (TERMINAL)
    if (e.capped) { return e.bp + ' bp, ' + e.sites + ' Rap1 sites, capped'; }
    if (e.eroded >= run.geneKb) { return 'uncapped; eroded into the essential gene'; }
    return e.eroded > 0 ? 'uncapped; ' + e.eroded + ' kb of interior eroded' : 'uncapped; C-strand resected';
  }

  function allSvg(run, current) {
    // VIEW: every division of the lineage as a row, early at the top, both ends drawn to length about the interior (TERMINAL)
    // Each row is the chromosome at the end of that division: TEL-L to the
    // left, TEL-R to the right, each essential gene in from its end. A capped
    // telomere is a gold bar to length; an uncapped end is a thin red strand,
    // and the interior it has eroded is cut away. The row of the page on the
    // book is outlined. A click on a row turns the books to that division.
    var rows = [], seen = {}, out = [], H, W = 880, top = K.top, half = 400, gk = run.geneKb * K.kb;
    run.pages.forEach(function (p, i) { if (!seen[p.g] || p.state === 'dead') { seen[p.g] = true; rows.push({ p: p, i: i }); } });
    var rh = Math.max(3, Math.min(10, Math.floor(560 / Math.max(rows.length, 40))));
    H = top + rows.length * rh + 44;
    var tipL = K.mid - half, tipR = K.mid + half;
    ['L', 'R'].forEach(function (side) {
      var sx = side === 'L' ? -1 : 1, J = K.mid + sx * (half - 260), G = J - sx * gk;
      out.push('<path class="tpgcol" d="M' + J + ' ' + (top - 4) + ' V' + (top + rows.length * rh) + '"/>'
        + '<text class="tpgsmall" x="' + J + '" y="' + (top - 8) + '">TEL-' + side + '</text>'
        + '<text class="tpgsmall" x="' + G + '" y="' + (top - 8) + '">gene</text>');
    });
    rows.forEach(function (r, n) {
      var p = r.p, y = top + n * rh;
      out.push('<g class="tpgrow' + (r.i === current ? ' here' : '') + '" data-g="' + p.g + '">');
      out.push('<rect class="tpghit" x="0" y="' + y + '" width="' + W + '" height="' + rh + '"/>');
      ['L', 'R'].forEach(function (side) {
        var e = p[side], sx = side === 'L' ? -1 : 1, J = K.mid + sx * (half - 260), G = J - sx * gk;
        var cut = Math.min(run.geneKb, e.eroded) * K.kb, inner = K.mid + sx * 30, from = J - sx * cut;
        out.push('<path class="tpgkint" d="M' + inner + ' ' + (y + rh / 2) + ' H' + from + '"/>');
        out.push('<rect class="tpgkgene' + (e.eroded >= run.geneKb ? ' lost' : '') + '" x="' + (G - 3) + '" y="' + (y + 0.5) + '" width="6" height="' + (rh - 1) + '"/>');
        if (e.capped) {
          var len = Math.min(Z.maxBp, e.bp) * K.tel;
          out.push('<rect class="tpgktel" x="' + Math.min(J, J + sx * len) + '" y="' + (y + 0.5) + '" width="' + len + '" height="' + (rh - 1) + '"/>');
        } else {
          out.push('<path class="tpgkss" d="M' + from + ' ' + (y + rh / 2) + ' h' + (sx * 24) + '"/>');
        }
      });
      if (p.state === 'arrested' || (p.state === 'dead' && p.death === 'arrest')) {
        out.push('<text class="tpgkmark end" x="' + (W - 4) + '" y="' + (y + rh) + '">arrest</text>');
      }
      if (p.state === 'dead') {
        out.push('<text class="tpgkmark dead" x="4" y="' + (y + rh) + '">' + (p.death === 'arrest' ? 'death in arrest' : 'gene loss') + '</text>');
      }
      out.push('</g>');
      if (p.g % 10 === 0 && (n === 0 || rows[n - 1].p.g !== p.g)) {
        out.push('<text class="tpgtick" x="' + K.mid + '" y="' + (y + rh / 2 + 4) + '">' + p.g + '</text>');
      }
    });
    out.push('<text class="tpgsmall" x="' + K.mid + '" y="' + (top - 22) + '">division, early at the top</text>');
    var yb = top + rows.length * rh + 20;
    out.push('<path class="tpgscale" d="M' + (tipR - 100 * K.tel) + ' ' + yb + ' h' + (100 * K.tel) + '"/>'
      + '<text class="tpgsmall" x="' + (tipR - 50 * K.tel) + '" y="' + (yb + 16) + '">100 bp</text>'
      + '<path class="tpgscale" d="M' + tipL + ' ' + yb + ' h' + (5 * K.kb) + '"/>'
      + '<text class="tpgsmall" x="' + (tipL + 2.5 * K.kb) + '" y="' + (yb + 16) + '">5 kb</text>'
      + '<rect class="tpgktel" x="300" y="' + (yb - 6) + '" width="18" height="8"/><text class="tpgsmall start" x="324" y="' + (yb + 2) + '">capped</text>'
      + '<path class="tpgkss" d="M450 ' + (yb - 2) + ' h18"/><text class="tpgsmall start" x="474" y="' + (yb + 2) + '">uncapped</text>');
    return '<svg class="tpgsvg tpgallsvg" viewBox="0 0 ' + W + ' ' + H + '" xmlns="' + NS + '">' + out.join('') + '</svg>';
  }

  function mountHist(spec, box) {
    // SUB-CONTROLLER: many lineages' first cap loss, as two histograms: the division and the length
    box.innerHTML = '<div class="tpages"><div class="tpghead"><div class="tpgcount">' + spec.n + ' lineages</div>'
      + '<div class="tpgsub">' + spec.label + '</div><div class="tpgstate" id="tpgstate">computing…</div></div>'
      + '<div class="tpghist" id="tpghist"></div></div>';
    state.timer = setTimeout(function () {
      var st = CHROM_RULE.lineageStats(spec.alleles || {}, spec.n), div = [], bp = [];
      st.forEach(function (x) { if (x.at !== null) { div.push(x.at); bp.push(x.bp); } });
      state.stats = { div: div, bp: bp };
      document.getElementById('tpghist').innerHTML = hist(div, 'division of the first cap loss', 0, 120, 5)
        + hist(bp, 'length of the end that lost its cap, bp', 0, 400, 10);
      var med = function (xs) { var s = xs.slice().sort(function (a, b) { return a - b; }); return s[Math.floor(s.length / 2)]; };
      document.getElementById('tpgstate').textContent = 'median first cap loss at division ' + med(div) + '; median length then '
        + med(bp) + ' bp; ' + div.length + ' of ' + st.length + ' lineages lost a cap within ' + CHROM_RULE.RULE.lineageMax + ' divisions';
      state.timer = null;
    }, 40);
  }

  function hist(xs, title, lo, hi, bin) {
    // VIEW: one histogram with its median marked (TERMINAL)
    var n = Math.ceil((hi - lo) / bin), counts = [], i, maxC = 1, out = [];
    for (i = 0; i < n; i += 1) { counts.push(0); }
    xs.forEach(function (v) { var k = Math.min(n - 1, Math.max(0, Math.floor((v - lo) / bin))); counts[k] += 1; });
    counts.forEach(function (c) { maxC = Math.max(maxC, c); });
    var X = function (v) { return 50 + 380 * (v - lo) / (hi - lo); };
    counts.forEach(function (c, k) {
      var hgt = 96 * c / maxC;
      out.push('<rect class="tpgbar" x="' + (X(lo + k * bin) + 0.5) + '" y="' + (130 - hgt) + '" width="' + (380 / n - 1) + '" height="' + hgt + '"/>');
    });
    var s = xs.slice().sort(function (a, b) { return a - b; }), m = s[Math.floor(s.length / 2)];
    out.push('<line class="tpgmed" x1="' + X(m) + '" y1="28" x2="' + X(m) + '" y2="132"/><text class="tpgtick strong start" x="' + (X(m) + 4) + '" y="22">median ' + m + '</text>');
    out.push('<line class="tpgaxis" x1="50" y1="130" x2="430" y2="130"/>');
    for (i = 0; i <= 4; i += 1) { out.push('<text class="tpgtick" x="' + X(lo + (hi - lo) * i / 4) + '" y="144">' + Math.round(lo + (hi - lo) * i / 4) + '</text>'); }
    out.push('<text class="tpgtick" x="240" y="160">' + title + '</text>');
    return '<svg class="tpgsvg half" viewBox="0 0 450 165" xmlns="' + NS + '">' + out.join('') + '</svg>';
  }

  function unmount() {
    // VIEW: stop turning pages (TERMINAL)
    if (state.timer) { clearTimeout(state.timer); state.timer = null; }
    state.rows = [];
    state.playing = false;
    state.busy = false;
  }

  function restart() {
    // VIEW: play the lineage again from the spore (TERMINAL)
    if (state.spec && state.box) { mount(state.spec, state.box); }
  }

  return { mount: mount, unmount: unmount, restart: restart, lastStats: function () { return state.stats; } };
}());

if (typeof window !== 'undefined') { window.TourPages = TourPages; }
