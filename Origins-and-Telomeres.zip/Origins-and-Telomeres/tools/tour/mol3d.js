/* Structures in the lesson: the ChimeraX surfaces of tools/structures, drawn
   with WebGL2 and turned slowly, in the colors and soft lighting of the
   dissertation figures.

   window.TOUR_STRUCTURES (built by tools/structures/make_structures.py)
   carries decimated chain surfaces, and per scene the ChimeraX camera, each
   part's placement and colors, the ambient occlusion baked from many light
   directions (ChimeraX "lighting soft"), and named anchors on the chains.

   Mol3D.mount(el, opts) fills el with a turning scene:
     scene   a scene key in TOUR_STRUCTURES.scenes
     spin    'y' turns about the screen's vertical axis, 'x' about its
             horizontal axis, 'rock' swings back and forth about the vertical,
             'rockx' about the horizontal, 'none' holds the ChimeraX view
     period  seconds per turn (or per swing)
     marks   [{at, text, shape: 'circle'|'square', fill, stroke, dx, dy}]
     labels  [{at, text, color, dx, dy, radial, keep}]
   radial pushes an item that many pixels outward from the centre of the
   view; keep shows it at every angle. Other items fade while their chain
   faces away or another surface lies in front of it.
   Dragging turns the scene by hand; it starts turning again after a pause.
   Double-click returns it to the ChimeraX view. Mol3D.unmountAll() frees
   every context, which tour.js calls before it draws the next slide. */

(function () {
  'use strict';

  var SILHOUETTE = 0.03;     // depth jump drawn as a silhouette edge, as a fraction of the depth range (ChimeraX's default)
  var OUTLINE_HALF = 1.0;   // Angstroms of the DDK outline on each side of its edge
  var MAX_SUPERSAMPLE = 4;   // drawing pixels per canvas pixel; the figures are drawn large, then shown small
  var MAX_BACKING = 2400;    // widest drawing, in pixels
  var RESUME_MS = 2500;      // after a drag, the pause before the scene turns again
  var HIDE_DEPTH = 4.0;      // Angstroms another surface must lie in front of an anchor to hide its marker
  var HIDE_REACH = 5.0;      // Angstroms on screen around an anchor searched for surfaces in front of it
  var OCCLUSION_EVERY = 5;   // frames between occlusion checks
  var mounted = [];
  var meshCache = {};
  var sceneCache = {};

  // ---- MODEL: data ------------------------------------------------------------

  function bytes(b64) {
    // MODEL: base64 text as bytes (TERMINAL)
    var s = atob(b64), out = new Uint8Array(s.length), i;
    for (i = 0; i < s.length; i += 1) { out[i] = s.charCodeAt(i); }
    return out;
  }

  function decodeMesh(id) {
    // MODEL: one chain surface's positions, smooth normals and triangles in its own coordinates (TERMINAL)
    var m = window.TOUR_STRUCTURES.meshes[id], raw, q, t, pos, nor, i, a, b, c, ux, uy, uz, vx, vy, vz, nx, ny, nz, len;
    if (meshCache[id]) { return meshCache[id]; }
    raw = bytes(m.p);
    q = new Uint16Array(raw.buffer, raw.byteOffset, raw.byteLength / 2);
    raw = bytes(m.t);
    t = m.wide ? new Uint32Array(raw.buffer, raw.byteOffset, raw.byteLength / 4) : new Uint16Array(raw.buffer, raw.byteOffset, raw.byteLength / 2);
    pos = new Float32Array(q.length);
    for (i = 0; i < q.length; i += 3) {
      pos[i] = m.offset[0] + q[i] * m.scale[0];
      pos[i + 1] = m.offset[1] + q[i + 1] * m.scale[1];
      pos[i + 2] = m.offset[2] + q[i + 2] * m.scale[2];
    }
    nor = new Float32Array(q.length);
    for (i = 0; i < t.length; i += 3) {
      a = t[i] * 3; b = t[i + 1] * 3; c = t[i + 2] * 3;
      ux = pos[b] - pos[a]; uy = pos[b + 1] - pos[a + 1]; uz = pos[b + 2] - pos[a + 2];
      vx = pos[c] - pos[a]; vy = pos[c + 1] - pos[a + 1]; vz = pos[c + 2] - pos[a + 2];
      nx = uy * vz - uz * vy; ny = uz * vx - ux * vz; nz = ux * vy - uy * vx;
      nor[a] += nx; nor[a + 1] += ny; nor[a + 2] += nz;
      nor[b] += nx; nor[b + 1] += ny; nor[b + 2] += nz;
      nor[c] += nx; nor[c + 1] += ny; nor[c + 2] += nz;
    }
    for (i = 0; i < nor.length; i += 3) {
      len = Math.sqrt(nor[i] * nor[i] + nor[i + 1] * nor[i + 1] + nor[i + 2] * nor[i + 2]) || 1;
      nor[i] /= len; nor[i + 1] /= len; nor[i + 2] /= len;
    }
    meshCache[id] = { pos: pos, nor: nor, tri: t };
    return meshCache[id];
  }

  function buildScene(key) {
    // MODEL: every part of a scene placed in scene coordinates, merged into one set of vertex arrays (TERMINAL)
    var s = window.TOUR_STRUCTURES.scenes[key], nv = 0, nt = 0, parts = [], pos, nor, col, ao, idx, v = 0, t = 0;
    if (sceneCache[key]) { return sceneCache[key]; }
    s.parts.forEach(function (p) {
      var mesh = decodeMesh(p.mesh);
      parts.push({ p: p, mesh: mesh });
      nv += mesh.pos.length / 3;
      nt += mesh.tri.length;
    });
    pos = new Float32Array(nv * 3); nor = new Float32Array(nv * 3); col = new Uint8Array(nv * 3); ao = new Uint8Array(nv); var ring = new Uint8Array(nv);
    idx = new Uint32Array(nt);
    parts.forEach(function (e) {
      var m = e.p.m, mesh = e.mesh, c = bytes(e.p.c), o = bytes(e.p.ao), n = mesh.pos.length / 3, i, x, y, z;
      for (i = 0; i < n; i += 1) {
        x = mesh.pos[3 * i]; y = mesh.pos[3 * i + 1]; z = mesh.pos[3 * i + 2];
        pos[3 * (v + i)] = m[0][0] * x + m[0][1] * y + m[0][2] * z + m[0][3];
        pos[3 * (v + i) + 1] = m[1][0] * x + m[1][1] * y + m[1][2] * z + m[1][3];
        pos[3 * (v + i) + 2] = m[2][0] * x + m[2][1] * y + m[2][2] * z + m[2][3];
        x = mesh.nor[3 * i]; y = mesh.nor[3 * i + 1]; z = mesh.nor[3 * i + 2];
        nor[3 * (v + i)] = m[0][0] * x + m[0][1] * y + m[0][2] * z;
        nor[3 * (v + i) + 1] = m[1][0] * x + m[1][1] * y + m[1][2] * z;
        nor[3 * (v + i) + 2] = m[2][0] * x + m[2][1] * y + m[2][2] * z;
      }
      col.set(c, 3 * v);
      ao.set(o, v);
      if ((s.outline || []).indexOf(e.p.mesh) >= 0) { ring.fill(255, v, v + n); }
      for (i = 0; i < mesh.tri.length; i += 1) { idx[t + i] = mesh.tri[i] + v; }
      v += n;
      t += mesh.tri.length;
    });
    sceneCache[key] = { pos: pos, nor: nor, col: col, ao: ao, ring: ring, idx: idx, scene: s };
    return sceneCache[key];
  }

  function spinMatrix(mode, angle, user) {
    // MODEL: the turn applied in camera coordinates: the hand-set turn, then the automatic turn (TERMINAL)
    var a = mode === 'x' ? 0 : angle, b = mode === 'x' ? angle : 0;
    var ca = Math.cos(a + user.yaw), sa = Math.sin(a + user.yaw), cb = Math.cos(b + user.pitch), sb = Math.sin(b + user.pitch);
    // R = Rx(b) * Ry(a)
    return [[ca, 0, sa], [sb * sa, cb, -sb * ca], [-cb * sa, sb, cb * ca]];
  }

  function viewTransform(scene, spin) {
    // MODEL: the scene-to-view rotation (camera axes, then the turn) and the pivot (TERMINAL)
    var c = scene.view.camera, r = [[0, 0, 0], [0, 0, 0], [0, 0, 0]], i, j, k;
    // camera axes are the columns of c; scene to camera is their transpose
    for (i = 0; i < 3; i += 1) {
      for (j = 0; j < 3; j += 1) {
        for (k = 0; k < 3; k += 1) { r[i][j] += spin[i][k] * c[j][k]; }
      }
    }
    return { rot: r, pivot: scene.view.centre };
  }

  function fitHalf(scene, mode, aspect, amplitude) {
    // MODEL: half width and half height of the view, wide enough for every angle of the turn and the canvas shape (TERMINAL)
    var h = scene.view.half, hx = h[0], hy = h[1], hz = h[2];
    function reach(a, b, amp) {
      // the widest a box of half sizes a (across) and b (deep) gets while it swings through amp
      return amp >= Math.atan2(b, a) ? Math.sqrt(a * a + b * b) : a * Math.cos(amp) + b * Math.sin(amp);
    }
    if (mode === 'y') { hx = Math.sqrt(hx * hx + hz * hz); }
    if (mode === 'x') { hy = Math.sqrt(hy * hy + hz * hz); }
    if (mode === 'rock') { hx = reach(hx, hz, amplitude); }
    if (mode === 'rockx') { hy = reach(hy, hz, amplitude); }
    hx *= 1.06; hy *= 1.06;
    if (hx * aspect < hy) { hx = hy / aspect; } else { hy = hx * aspect; }
    return { x: hx, y: hy, z: Math.sqrt(h[0] * h[0] + h[1] * h[1] + h[2] * h[2]) * 1.05 };
  }

  // ---- VIEW: WebGL ---------------------------------------------------------------

  var VS = '#version 300 es\n' +
    'in vec3 aPos; in vec3 aNor; in vec3 aCol; in float aAo; in float aRing;\n' +
    'uniform mat3 uRot; uniform vec3 uPivot; uniform vec3 uInv;\n' +
    'out vec3 vNor; out vec3 vCol; out float vAo; out float vDepth; out float vRing;\n' +
    'void main() {\n' +
    '  vec3 p = uRot * (aPos - uPivot);\n' +
    '  float z = -p.z * uInv.z;\n' +
    '  gl_Position = vec4(p.x * uInv.x, p.y * uInv.y, z, 1.0);\n' +
    '  vNor = uRot * aNor; vCol = aCol; vAo = aAo; vRing = aRing; vDepth = 0.5 * (z + 1.0);\n' +
    '}\n';
  var FS = '#version 300 es\nprecision highp float;\n' +
    'in vec3 vNor; in vec3 vCol; in float vAo; in float vDepth; in float vRing;\n' +
    'out vec4 outColor;\n' +
    'void main() {\n' +
    // ChimeraX "lighting soft": ambient light 1.5 from 64 shadowed directions, no key light,
    // depth cue from halfway back to the far side, toward the white background.
    '  float light = clamp(1.5 * vAo, 0.0, 1.0);\n' +
    '  vec3 c = vCol * light;\n' +
    '  float cue = clamp((vDepth - 0.5) / 0.5, 0.0, 1.0);\n' +
    '  outColor = vec4(mix(c, vec3(1.0), cue), vRing > 0.5 ? 0.5 : 1.0);\n' +
    '}\n';
  var VS2 = '#version 300 es\nin vec2 aXY; out vec2 vUV;\n' +
    'void main() { vUV = 0.5 * (aXY + 1.0); gl_Position = vec4(aXY, 0.0, 1.0); }\n';
  var FS2 = '#version 300 es\nprecision highp float;\n' +
    'in vec2 vUV; uniform sampler2D uColor; uniform sampler2D uDepth; uniform vec2 uPx; uniform float uEdge; uniform int uRing;\n' +
    'out vec4 outColor;\n' +
    'float ringed(vec2 uv) { float a = texture(uColor, uv).a; return a > 0.25 && a < 0.75 ? 1.0 : 0.0; }\n' +
    'void main() {\n' +
    '  float d = texture(uDepth, vUV).r;\n' +
    // The bold outline the DDK figures draw around Dbf4 and Cdc7: a band where
    // the outlined chains meet anything else, half on each side of the edge.
    '  if (uRing > 0) {\n' +
    '    float own = ringed(vUV);\n' +
    '    for (int i = -4; i <= 4; i++) { for (int j = -4; j <= 4; j++) {\n' +
    '      if (abs(i) > uRing || abs(j) > uRing || i * i + j * j > uRing * uRing) { continue; }\n' +
    '      if (ringed(vUV + vec2(float(i), float(j)) * uPx) != own) { outColor = vec4(0.0, 0.0, 0.0, 1.0); return; }\n' +
    '    } }\n' +
    '  }\n' +
    '  float jump = 0.0;\n' +
    '  for (int i = -1; i <= 1; i++) { for (int j = -1; j <= 1; j++) {\n' +
    '    float e = texture(uDepth, vUV + vec2(float(i), float(j)) * uPx).r;\n' +
    '    jump = max(jump, abs(e - d));\n' +
    '  } }\n' +
    '  if (jump > uEdge) { outColor = vec4(0.0, 0.0, 0.0, 1.0); return; }\n' +
    '  if (d >= 1.0) { outColor = vec4(0.0); return; }\n' +
    '  outColor = vec4(texture(uColor, vUV).rgb, 1.0);\n' +
    '}\n';

  // The drawing is made at k times the canvas and averaged down k by k, as a
  // 3000-pixel ChimeraX image is shrunk onto a page: thin silhouettes and
  // fine shading soften as they do in the figures.
  var FS3 = '#version 300 es\nprecision highp float;\n' +
    'uniform sampler2D uComp; uniform vec2 uPx; uniform int uK;\n' +
    'out vec4 outColor;\n' +
    'void main() {\n' +
    '  vec4 sum = vec4(0.0);\n' +
    '  vec2 base = floor(gl_FragCoord.xy) * float(uK);\n' +
    '  for (int i = 0; i < 4; i++) { for (int j = 0; j < 4; j++) {\n' +
    '    if (i >= uK || j >= uK) { continue; }\n' +
    '    sum += texture(uComp, (base + vec2(float(i), float(j)) + 0.5) * uPx);\n' +
    '  } }\n' +
    '  outColor = sum / float(uK * uK);\n' +
    '}\n';

  function compile(gl, vs, fs) {
    // VIEW: one shader program (TERMINAL)
    var p = gl.createProgram();
    [[gl.VERTEX_SHADER, vs], [gl.FRAGMENT_SHADER, fs]].forEach(function (pair) {
      var s = gl.createShader(pair[0]);
      gl.shaderSource(s, pair[1]);
      gl.compileShader(s);
      if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) { throw new Error(gl.getShaderInfoLog(s)); }
      gl.attachShader(p, s);
    });
    gl.linkProgram(p);
    if (!gl.getProgramParameter(p, gl.LINK_STATUS)) { throw new Error(gl.getProgramInfoLog(p)); }
    return p;
  }

  function upload(gl, prog, data) {
    // VIEW: the scene's vertex arrays as one vertex array object, and the screen quad (TERMINAL)
    var vao = gl.createVertexArray(), quad = gl.createVertexArray();
    function attr(name, arr, size, type, norm) {
      var loc = gl.getAttribLocation(prog.scene, name), b = gl.createBuffer();
      gl.bindBuffer(gl.ARRAY_BUFFER, b);
      gl.bufferData(gl.ARRAY_BUFFER, arr, gl.STATIC_DRAW);
      gl.enableVertexAttribArray(loc);
      gl.vertexAttribPointer(loc, size, type, norm, 0, 0);
    }
    gl.bindVertexArray(vao);
    attr('aPos', data.pos, 3, gl.FLOAT, false);
    attr('aNor', data.nor, 3, gl.FLOAT, false);
    attr('aCol', data.col, 3, gl.UNSIGNED_BYTE, true);
    attr('aAo', data.ao, 1, gl.UNSIGNED_BYTE, true);
    attr('aRing', data.ring, 1, gl.UNSIGNED_BYTE, true);
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, gl.createBuffer());
    gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, data.idx, gl.STATIC_DRAW);
    gl.bindVertexArray(quad);
    gl.bindBuffer(gl.ARRAY_BUFFER, gl.createBuffer());
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), gl.STATIC_DRAW);
    gl.enableVertexAttribArray(gl.getAttribLocation(prog.post, 'aXY'));
    gl.vertexAttribPointer(gl.getAttribLocation(prog.post, 'aXY'), 2, gl.FLOAT, false, 0, 0);
    gl.bindVertexArray(null);
    return { vao: vao, quad: quad, count: data.idx.length };
  }

  function targets(gl, w, h, old) {
    // VIEW: the offscreen color and depth the silhouette pass reads, sized to the canvas (TERMINAL)
    var t = old || { fb: gl.createFramebuffer(), color: gl.createTexture(), depth: gl.createTexture() };
    if (t.w === w && t.h === h) { return t; }
    gl.bindTexture(gl.TEXTURE_2D, t.color);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA8, w, h, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    gl.bindTexture(gl.TEXTURE_2D, t.depth);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.DEPTH_COMPONENT24, w, h, 0, gl.DEPTH_COMPONENT, gl.UNSIGNED_INT, null);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    gl.bindFramebuffer(gl.FRAMEBUFFER, t.fb);
    gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, t.color, 0);
    gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.DEPTH_ATTACHMENT, gl.TEXTURE_2D, t.depth, 0);
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    t.w = w; t.h = h;
    return t;
  }

  function drawScene(v) {
    // VIEW: the surfaces into the large offscreen target, the silhouette pass into a second, then averaged onto the canvas (TERMINAL)
    var gl = v.gl, w = v.canvas.width * v.ss, h = v.canvas.height * v.ss, half = v.half, tf = v.tf, r = tf.rot;
    v.target = targets(gl, w, h, v.target);
    v.comp = targets(gl, w, h, v.comp);
    gl.bindFramebuffer(gl.FRAMEBUFFER, v.target.fb);
    gl.viewport(0, 0, w, h);
    gl.clearColor(1, 1, 1, 0);
    gl.clearDepth(1);
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    gl.enable(gl.DEPTH_TEST);
    gl.useProgram(v.prog.scene);
    gl.uniformMatrix3fv(v.loc.rot, false, [r[0][0], r[1][0], r[2][0], r[0][1], r[1][1], r[2][1], r[0][2], r[1][2], r[2][2]]);
    gl.uniform3fv(v.loc.pivot, tf.pivot);
    gl.uniform3f(v.loc.inv, 1 / half.x, 1 / half.y, 1 / half.z);
    gl.bindVertexArray(v.buf.vao);
    gl.drawElements(gl.TRIANGLES, v.buf.count, gl.UNSIGNED_INT, 0);
    gl.bindFramebuffer(gl.FRAMEBUFFER, v.comp.fb);
    gl.disable(gl.DEPTH_TEST);
    gl.clearColor(0, 0, 0, 0);
    gl.clear(gl.COLOR_BUFFER_BIT);
    gl.useProgram(v.prog.post);
    gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, v.target.color);
    gl.activeTexture(gl.TEXTURE1); gl.bindTexture(gl.TEXTURE_2D, v.target.depth);
    gl.uniform1i(v.loc.color, 0);
    gl.uniform1i(v.loc.depth, 1);
    gl.uniform2f(v.loc.px, 1 / w, 1 / h);
    gl.uniform1f(v.loc.edge, SILHOUETTE);
    // The figures draw the outline 12 pixels wide on a 3000-pixel image of a
    // 400 to 550 A field, about 2 A of the structure: 1 A to each side of the edge.
    gl.uniform1i(v.loc.ring, v.data.scene.outline && v.data.scene.outline.length ? Math.max(1, Math.min(4, Math.round(OUTLINE_HALF * w / (2 * half.x)))) : 0);
    gl.bindVertexArray(v.buf.quad);
    gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    gl.viewport(0, 0, v.canvas.width, v.canvas.height);
    gl.clear(gl.COLOR_BUFFER_BIT);
    gl.useProgram(v.prog.down);
    gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, v.comp.color);
    gl.uniform1i(v.loc.comp, 0);
    gl.uniform2f(v.loc.cpx, 1 / w, 1 / h);
    gl.uniform1i(v.loc.k, v.ss);
    gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
    gl.bindVertexArray(null);
  }

  function project(v, p) {
    // MODEL: an anchor's place on the overlay in CSS pixels, and how squarely its surface faces the viewer (TERMINAL)
    var r = v.tf.rot, d = [p.p[0] - v.tf.pivot[0], p.p[1] - v.tf.pivot[1], p.p[2] - v.tf.pivot[2]];
    var x = r[0][0] * d[0] + r[0][1] * d[1] + r[0][2] * d[2];
    var y = r[1][0] * d[0] + r[1][1] * d[1] + r[1][2] * d[2];
    var nz = r[2][0] * p.n[0] + r[2][1] * p.n[1] + r[2][2] * p.n[2];
    return { x: (0.5 + 0.5 * x / v.half.x) * v.cssW, y: (0.5 - 0.5 * y / v.half.y) * v.cssH, facing: nz };
  }

  function occlusion(v) {
    // MODEL: for each anchor, whether surface lies in front of it in the current view (TERMINAL)
    var r = v.tf.rot, pv = v.tf.pivot, pos = v.data.pos, n = pos.length / 3, out = {}, keys = Object.keys(v.data.scene.anchors);
    var ax = [], ay = [], az = [], hid = [], i, k, x, y, z, dx, dy, d0, d1, d2;
    keys.forEach(function (key) {
      var a = v.data.scene.anchors[key].p;
      d0 = a[0] - pv[0]; d1 = a[1] - pv[1]; d2 = a[2] - pv[2];
      ax.push(r[0][0] * d0 + r[0][1] * d1 + r[0][2] * d2);
      ay.push(r[1][0] * d0 + r[1][1] * d1 + r[1][2] * d2);
      az.push(r[2][0] * d0 + r[2][1] * d1 + r[2][2] * d2);
      hid.push(false);
    });
    for (i = 0; i < n; i += 1) {
      d0 = pos[3 * i] - pv[0]; d1 = pos[3 * i + 1] - pv[1]; d2 = pos[3 * i + 2] - pv[2];
      z = r[2][0] * d0 + r[2][1] * d1 + r[2][2] * d2;
      x = NaN;
      for (k = 0; k < keys.length; k += 1) {
        if (hid[k] || z < az[k] + HIDE_DEPTH) { continue; }
        if (x !== x) {
          x = r[0][0] * d0 + r[0][1] * d1 + r[0][2] * d2;
          y = r[1][0] * d0 + r[1][1] * d1 + r[1][2] * d2;
        }
        dx = x - ax[k]; dy = y - ay[k];
        if (dx * dx + dy * dy < HIDE_REACH * HIDE_REACH) { hid[k] = true; }
      }
    }
    keys.forEach(function (key, k) { out[key] = hid[k]; });
    return out;
  }

  function drawMarks(v) {
    // VIEW: markers and labels on the overlay, faded as their chain turns away or goes behind another (TERMINAL)
    var ctx = v.ctx, anchors = v.data.scene.anchors, dpr = v.dpr;
    function place(item, a) {
      var s = project(v, a), cx = v.cssW / 2, cy = v.cssH / 2, dx = s.x - cx, dy = s.y - cy, len = Math.sqrt(dx * dx + dy * dy) || 1;
      var shown = item.keep || (s.facing > -0.1 && !(v.hidden && v.hidden[item.at])) ? 1 : 0;
      v.alpha[item.at] = (v.alpha[item.at] === undefined ? shown : v.alpha[item.at]) * 0.8 + shown * 0.2;
      return { x: s.x + (item.radial ? dx / len * item.radial : 0) + (item.dx || 0),
               y: s.y + (item.radial ? dy / len * item.radial : 0) + (item.dy || 0), alpha: v.alpha[item.at] };
    }
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, v.cssW, v.cssH);
    (v.opts.labels || []).forEach(function (l) {
      var a = anchors[l.at], s;
      if (!a) { return; }
      s = place(l, a);
      ctx.globalAlpha = s.alpha;
      ctx.font = '600 12px Georgia, serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.lineWidth = 3.5;
      ctx.lineJoin = 'round';
      ctx.strokeStyle = 'rgba(255,255,255,0.92)';
      ctx.strokeText(l.text, s.x, s.y);
      ctx.fillStyle = l.color || '#1d1d1b';
      ctx.fillText(l.text, s.x, s.y);
      ctx.textBaseline = 'alphabetic';
    });
    (v.opts.marks || []).forEach(function (m) {
      var a = anchors[m.at], s, x, y, r = 8.5;
      if (!a) { return; }
      s = place(m, a);
      x = s.x; y = s.y;
      ctx.globalAlpha = s.alpha;
      ctx.beginPath();
      if (m.shape === 'square') { ctx.rect(x - r, y - r, 2 * r, 2 * r); } else { ctx.arc(x, y, r, 0, 2 * Math.PI); }
      ctx.fillStyle = m.fill || '#3f8f6a';
      ctx.fill();
      ctx.lineWidth = 1.4;
      ctx.strokeStyle = m.stroke || '#1d1d1b';
      ctx.stroke();
      ctx.fillStyle = m.ink || '#ffffff';
      ctx.font = 'bold 10px Georgia, serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(m.text, x, y + 0.5);
      ctx.textBaseline = 'alphabetic';
    });
    ctx.globalAlpha = 1;
  }

  // ---- CONTROLLERS ---------------------------------------------------------------

  function mount(el, opts) {
    // CONTROLLER: one turning scene in el, with its markers, hand turning and its own frame loop
    var v = { el: el, opts: opts, user: { yaw: 0, pitch: 0 }, t0: performance.now(), held: 0, live: true, alpha: {} };
    if (!window.TOUR_STRUCTURES || !window.TOUR_STRUCTURES.scenes[opts.scene]) { return null; }

    function setup() {
      // SUB-CONTROLLER: canvases, context, programs and buffers
      v.canvas = document.createElement('canvas');
      v.canvas.className = 'm3dgl';
      v.over = document.createElement('canvas');
      v.over.className = 'm3dover';
      el.appendChild(v.canvas);
      el.appendChild(v.over);
      v.gl = v.canvas.getContext('webgl2', { antialias: false, premultipliedAlpha: true, alpha: true });
      if (!v.gl) { el.classList.add('m3dnone'); el.setAttribute('data-msg', 'This browser cannot draw the 3D structure (WebGL2).'); return false; }
      v.ctx = v.over.getContext('2d');
      v.prog = { scene: compile(v.gl, VS, FS), post: compile(v.gl, VS2, FS2), down: compile(v.gl, VS2, FS3) };
      v.loc = {
        rot: v.gl.getUniformLocation(v.prog.scene, 'uRot'), pivot: v.gl.getUniformLocation(v.prog.scene, 'uPivot'),
        inv: v.gl.getUniformLocation(v.prog.scene, 'uInv'), color: v.gl.getUniformLocation(v.prog.post, 'uColor'),
        depth: v.gl.getUniformLocation(v.prog.post, 'uDepth'), px: v.gl.getUniformLocation(v.prog.post, 'uPx'),
        edge: v.gl.getUniformLocation(v.prog.post, 'uEdge'), ring: v.gl.getUniformLocation(v.prog.post, 'uRing'),
        comp: v.gl.getUniformLocation(v.prog.down, 'uComp'), cpx: v.gl.getUniformLocation(v.prog.down, 'uPx'),
        k: v.gl.getUniformLocation(v.prog.down, 'uK')
      };
      v.data = buildScene(opts.scene);
      v.buf = upload(v.gl, v.prog, v.data);
      return true;
    }

    function size() {
      // SUB-CONTROLLER: canvas backing sized to the box, and the view fitted to its shape
      var w = Math.max(1, el.clientWidth), h = Math.max(1, el.clientHeight), dpr = window.devicePixelRatio || 1;
      if (v.cssW === w && v.cssH === h) { return; }
      v.cssW = w; v.cssH = h; v.dpr = dpr;
      v.canvas.width = Math.round(w * dpr); v.canvas.height = Math.round(h * dpr);
      v.ss = Math.max(1, Math.min(MAX_SUPERSAMPLE, Math.floor(MAX_BACKING / v.canvas.width)));
      v.over.width = Math.round(w * dpr); v.over.height = Math.round(h * dpr);
      v.half = fitHalf(v.data.scene, opts.spin || 'none', h / w, opts.amplitude || 0.6);
    }

    function frame(now) {
      // SUB-CONTROLLER: the turn for this moment, then the surfaces and the markers
      var period = (opts.period || 24) * 1000, angle = 0, still = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
      if (!v.live) { return; }
      size();
      if (!v.dragging && !still && now > v.held) {
        v.clock = (v.clock || 0) + Math.min(now - (v.last || now), 100);
      }
      v.last = now;
      if (opts.spin === 'rock' || opts.spin === 'rockx') { angle = Math.sin(2 * Math.PI * (v.clock || 0) / period) * (opts.amplitude || 0.6); } else if (opts.spin && opts.spin !== 'none') { angle = 2 * Math.PI * (v.clock || 0) / period; }
      v.tf = viewTransform(v.data.scene, spinMatrix(opts.spin === 'x' || opts.spin === 'rockx' ? 'x' : 'y', angle, v.user));
      drawScene(v);
      v.tick = (v.tick || 0) + 1;
      if ((opts.marks || opts.labels) && v.tick % OCCLUSION_EVERY === 1) { v.hidden = occlusion(v); }
      drawMarks(v);
      v.raf = requestAnimationFrame(frame);
    }

    function handTurn() {
      // SUB-CONTROLLER: drag to turn, double-click to return to the ChimeraX view
      var x0, y0;
      el.addEventListener('pointerdown', function (e) {
        v.dragging = true; x0 = e.clientX; y0 = e.clientY;
        el.setPointerCapture(e.pointerId);
      });
      el.addEventListener('pointermove', function (e) {
        if (!v.dragging) { return; }
        v.user.yaw += (e.clientX - x0) * 0.012; v.user.pitch += (e.clientY - y0) * 0.012;
        x0 = e.clientX; y0 = e.clientY;
      });
      el.addEventListener('pointerup', function () { v.dragging = false; v.held = performance.now() + RESUME_MS; });
      el.addEventListener('dblclick', function () { v.user.yaw = 0; v.user.pitch = 0; v.clock = 0; });
    }

    if (!setup()) { return null; }
    handTurn();
    v.raf = requestAnimationFrame(frame);
    mounted.push(v);
    return v;
  }

  function unmountAll() {
    // CONTROLLER: stop every scene and release its WebGL context
    mounted.forEach(function (v) {
      var lose = v.gl && v.gl.getExtension('WEBGL_lose_context');
      v.live = false;
      cancelAnimationFrame(v.raf);
      if (lose) { lose.loseContext(); }
      if (v.canvas && v.canvas.parentNode) { v.canvas.parentNode.removeChild(v.canvas); }
      if (v.over && v.over.parentNode) { v.over.parentNode.removeChild(v.over); }
    });
    mounted = [];
  }

  function mountAll(root) {
    // CONTROLLER: a scene in every [data-m3d] box under root, each box's options in its data-m3d JSON
    Array.prototype.forEach.call(root.querySelectorAll('[data-m3d]'), function (el) {
      var opts;
      try { opts = JSON.parse(el.getAttribute('data-m3d')); } catch (e) { return; }
      mount(el, opts);
    });
  }

  window.Mol3D = { mount: mount, mountAll: mountAll, unmountAll: unmountAll };
}());
