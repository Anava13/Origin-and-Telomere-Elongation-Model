"""The guided lesson's model-key figures, drawn with the panels' own glyphs.

Each figure introduces one abstraction of the chromosome panel before the
lesson first shows it: the limited pools and their homes, the origin meters,
the Mec1 gauge, Rad53's marks, the orange single-stranded stretch, and the
spindle gauge. tools/make_tour.py calls build_figures() and injects the result
as window.TOUR_FIGURES, so the glyphs are the ones the viewer draws, styled by
the viewer's own stylesheet.
"""

import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import make_panels as mp  # noqa: E402
import grn  # noqa: E402

W, H = 880, 270


def build_figures(presets=None, spindle=None):
    """BASE CONTROLLER: every figure, by name.

    spindle is tools/tour/spindles.py classify()'s result: each measured
    strain's class, short or extended, within its own experiment. The
    readout chapter draws strains from it as cards and never as numbers.
    """

    # === SUB-CONTROLLERS ===

    def figure_pools():
        # VIEW: the three limited pools, each in its home, dealt to licensed origins (TERMINAL)
        ddk, dcx, dcy = mp.chr_copy_glyphs()[0]
        rif, rcx, rcy = mp.chr_copy_glyphs()[1]
        kit = mp.chr_bundle_kit()
        out = [label(440, 18, 'Three limited pools. Each copy waits in its home until it is dealt to an origin.', 'tfh')]
        homes = ((110, 'DDK (Dbf4-Cdc7)', 'adds marks to an origin', '10 copies in the model'),
                 (440, 'Rif1-PP1', 'removes marks', '6 free, and 2 bound at each telomere'),
                 (770, 'firing-factor sets', 'Sld3-Sld7, Sld2, Dpb11', '2 sets in the model'))
        for k, (x, name, does, count) in enumerate(homes):
            out.append(tray(x - 90, 40, 180, 60, False))
            out.append(label(x - 86, 36, 'home', 'tfs start'))
            if k == 0:
                for j in range(10):
                    out.append(place(ddk, dcx, dcy, x - 64 + (j % 5) * 32, 57 + (j // 5) * 26, 0.36))
            elif k == 1:
                for j in range(6):
                    out.append(place(mp.rif1_glyph(0.0, 0.0, 13.0), 0.0, 0.0,
                                     x - 56 + (j % 3) * 56, 57 + (j // 3) * 26, 0.9))
            else:
                for j in range(2):
                    out.append(set_glyph(kit, x - 52 + j * 80, 72, 52))
            out.append(label(x, 116, name, 'tfn'))
            out.append(label(x, 130, does, 'tfl'))
            out.append(label(x, 143, count, 'tfs'))
        out.append(dna(40, 840, 214))
        for x in (190, 440, 690):
            b, f = mp.mcm_double(mp.DH_X, mp.DNA_Y, nsd='seated')
            out.append(mp.mini(b + f, mp.DH_X, mp.DNA_Y, x, 214, 0.3))
        out.append(label(440, 248, 'licensed origins: copies are dealt to them and come back home', 'tfl'))
        base, rif1 = mp.tel_rap1_units(2, flip=False)
        out.append(mp.mini(base + rif1, 3.0, 139.0, 788, 206, 0.3))
        out.append(label(820, 248, 'telomere: Rap1 binds Rif1', 'tfs'))
        for x0, x1 in ((110, 190), (440, 440), (770, 690)):
            out.append(mp.arrow(x0, 150, x1, 196, key=KEY))
        return svg('pools', ''.join(out))

    def figure_meters():
        # VIEW: what an origin's DDK-mark meter counts, and who sets how fast it fills (TERMINAL)
        b, f = mp.mcm_double(mp.DH_X, mp.DNA_Y, nsd='displaced', phos=True, phos_pending=False)
        ddk = mp.ddk_glyph(0.0, 0.0)
        rif = mp.rif1_glyph(0.0, 0.0)
        out = [label(440, 18, 'Each origin carries a DDK-mark meter: the DDK marks on its licensed Mcm2-7 double hexamer.', 'tfh')]
        out.append(dna(30, 330, 150))
        out.append(place(b + f, mp.DH_X, mp.DNA_Y, 180, 150, 0.62))
        out.append(place(ddk, 0.0, 0.0, 70, 70, 0.9))
        out.append(mp.arrow(98, 78, 150, 118, 'adds marks', key=KEY))
        out.append(place(rif, 0.0, 0.0, 290, 70, 1.0))
        out.append(mp.inhibit(276, 84, 222, 118))
        out.append(label(300, 98, 'removes them', 'tfs'))
        out.append(label(180, 205, 'licensed origin: Mcm2-7 double hexamer, loaded in G1', 'tfl'))
        out.append(label(180, 219, 'gold stars: DDK marks on Mcm4 and Mcm6, one per 5 marks', 'tfs'))
        out.append(label(180, 232, 'the fourth, at the line, moves the NSD off for Sld3', 'tfs'))
        # The meter.
        out.append(meter(400, 60, 120, 0.62))
        out.append(label(428, 64, 'dashed line: marks', 'tfs start'))
        out.append(label(428, 77, 'needed to recruit Sld3', 'tfs start'))
        out.append(label(428, 90, '(a model threshold)', 'tfs start'))
        out.append(label(428, 150, 'fill: marks on', 'tfs start'))
        out.append(label(428, 163, 'this origin now', 'tfs start'))
        out.append(label(408, 205, 'the DDK-mark meter', 'tfn'))
        # Recruiters.
        rows = ((84, 'Ctf19 complex', 'ctf19', 'L1, R1: the largest share'),
                (134, 'Fkh1/2', 'fkh', 'L2, R2: a smaller share'),
                (184, 'no recruiter', 'gonebox', 'L3, R3: a baseline share,', 'against telomeric Rif1-PP1'))
        out.append(label(700, 52, 'DDK goes where it is recruited', 'tfn'))
        for row in rows:
            y, name, cls = row[0], row[1], row[2]
            out.append(mp.protein(610, y, 90, name, cls))
            out.append(label(664, y + 4, row[3], 'tfs start'))
            if len(row) > 4:
                out.append(label(664, y + 17, row[4], 'tfs start'))
        out.append(label(700, 232, 'These shares are set in the model.', 'tfs'))
        # The structures the glyph draws.
        out.append('<path d="M30 262 H850" stroke="#e6e3da" stroke-width="1"/>')
        out.append(label(440, 284, 'The double hexamer glyph draws this complex, its six subunits in the same colours.', 'tfn'))
        out.append(m3d_slot(30, 294, 400, 200, {'scene': 'arch_pair', 'spin': 'x', 'period': 36}))
        out.append(m3d_slot(450, 294, 400, 200, {'scene': 'ddk_profile', 'spin': 'rock', 'period': 16, 'amplitude': 0.75,
                                                  'labels': [{'at': 'Dbf4', 'text': 'Dbf4', 'dx': -34, 'dy': 4},
                                                             {'at': 'Cdc7', 'text': 'Cdc7', 'dx': 30, 'dy': -6}]}))
        out.append(label(230, 510, 'Mcm2-7 double hexamer on DNA (PDB 5BK4)', 'tfl'))
        out.append(label(650, 510, 'DDK docked on the double hexamer (PDB 7PT6)', 'tfl'))
        out.append(colour_key(70, 536, ('Mcm2', 'Mcm3', 'Mcm4', 'Mcm5', 'Mcm6', 'Mcm7', 'Dbf4', 'Cdc7', 'DNA')))
        out.append(label(440, 558, 'Cryo-EM surfaces: Noguchi et al. 2017; Saleh et al. 2022. Drag a structure to turn it.', 'tfs lt'))
        return svg_h('meters', ''.join(out), 568)

    def figure_mec1():
        # VIEW: RPA at stalled forks feeds one gauge, which switches Rad53 on (TERMINAL)
        out = [label(440, 18, 'The Mec1 gauge sums the RPA-coated single strands at every stalled fork.', 'tfh')]
        for k, y in enumerate((96, 196)):
            out.append(fork(60, y, 4))
            out.append(label(130, y + 40, 'stalled fork %d: RPA on unwound template' % (k + 1), 'tfs'))
            out.append(mp.arrow(210, y - 8, 380, 128 if k == 0 else 150, '' if k else 'RPA signal', key=KEY))
        out.append(mp.meter_h(390, 130, 180, 0.72, 'chrsigfill'))
        out.append(label(480, 116, 'Mec1-Ddc2 gauge', 'tfn'))
        out.append(label(480, 166, 'dashed line: the signal that switches Rad53 on', 'tfs'))
        out.append(mp.arrow(580, 136, 680, 136, key=KEY))
        out.append('<g class="rad53k">%s</g>' % place(mp.kinase_burst(0.0, 0.0, 'Rad53'), 0.0, 0.0, 720, 136, 1.0))
        out.append(label(720, 186, 'Rad53 on', 'tfn'))
        out.append(label(440, 244, 'Ddc2 binds the RPA coat and brings Mec1, which marks Mrc1 at the fork, where Rad53 docks.', 'tfs'))
        return svg('mec1', ''.join(out))

    def figure_rad53():
        # VIEW: Rad53's targets in the model, and the home drawn solid while Rad53 holds it (TERMINAL)
        ddk, dcx, dcy = mp.chr_copy_glyphs()[0]
        kit = mp.chr_bundle_kit()
        star = mp.phos_star(0.0, 0.0)
        out = [label(440, 18, 'Rad53 phosphorylates its targets. A phosphorylated copy stays home, drawn solid.', 'tfh')]
        out.append('<g class="rad53k">%s</g>' % place(mp.kinase_burst(0.0, 0.0, 'Rad53'), 0.0, 0.0, 90, 140, 1.1))
        out.append(mp.arrow(126, 118, 276, 66, key=KEY))
        out.append(label(196, 80, 'phosphorylates Sld3', 'tfs'))
        out.append(tray(284, 38, 170, 56, True))
        for j in range(2):
            out.append(set_glyph(kit, 314 + j * 80, 68, 52))
            out.append(place(star, 0.0, 0.0, 326 + j * 84, 58, 0.9))
        out.append(label(470, 70, 'sets stay home: no origin can fire', 'tfs start'))
        out.append(mp.arrow(132, 140, 276, 136, key=KEY))
        out.append(label(204, 130, 'phosphorylates Dbf4', 'tfs'))
        out.append(tray(284, 112, 170, 54, True))
        for j in range(10):
            x, y = 306 + (j % 5) * 32, 127 + (j // 5) * 24
            out.append(place(ddk, dcx, dcy, x, y, 0.32))
            out.append(place(star, 0.0, 0.0, x + mp.DDK_CLEFT[0] * 0.32, y + mp.DDK_CLEFT[1] * 0.32, 0.5))
        out.append(label(470, 143, 'DDK stays home: marks on origins fade', 'tfs start'))
        out.append(mp.arrow(126, 162, 276, 202, key=KEY))
        out.append(label(206, 172, 'phosphorylates Dun1', 'tfs'))
        out.append(label(284, 206, 'through Dun1: more RNR, so the dNTP pool rises', 'tfs start'))
        out.append(mp.arrow(112, 172, 276, 240, key=KEY))
        out.append(label(206, 230, 'acts at stalled forks', 'tfs end'))
        out.append(label(284, 244, 'keeps stalled forks able to restart', 'tfs start'))
        out.append(tray(700, 160, 50, 26, False))
        out.append(label(760, 177, 'dashed: free to leave', 'tfs start'))
        out.append(tray(700, 200, 50, 26, True))
        out.append(label(760, 217, 'solid: kept home', 'tfs start'))
        return svg('rad53', ''.join(out))

    def figure_resect():
        # VIEW: a collapsed fork at molecular scale, and the orange stretch that stands for it (TERMINAL)
        kb, kf = mp.cmg_actor('r', pole=True)
        out = [label(440, 18, 'At a collapsed fork, single-stranded DNA spreads both ways. The chromosome panel draws it orange.', 'tfh')]
        y = 110
        # Whole parental strands: sisters behind the stalled ends, the unwound
        # stretch to the runaway helicase, then the duplex ahead of it, each
        # change of height a curve. New strands end where Exo1 has resected them.
        spans = [(40, 340, 'sis'), (340, 590, 'uw'), (590, 840, 'dup')]
        rows = {'top': {'sis': -26.0, 'uw': -15.0, 'dup': -4.5}, 'bot': {'sis': 26.0, 'uw': 15.0, 'dup': 4.5}}
        for side in ('top', 'bot'):
            out.append('<path class="dnapar" d="%s"/>' % mp.strand_course(spans, y, rows[side], 40.0))
        out.append('<path class="dnanew" d="M40 %.1f H168"/>' % (y - 19.5))
        out.append('<path class="dnanew" d="M40 %.1f H168"/>' % (y + 19.5))
        # Strand ends: the top parental strand runs 5' to 3' left to right, and
        # each new strand runs antiparallel to the strand it pairs with.
        out.append(pol_pair(40, y - 22.75, '5', '3', True) + pol_pair(40, y + 22.75, '5', '3', True)
                   + pol_pair(840, y, '3', '5', False)
                   + pol(168, y - 19.5, '5', False) + pol(168, y + 19.5, '3', False))
        for k, x in enumerate(range(196, 326, 28)):
            out.append(mp.wedge(x, y - 15.5, 8, 'rpaglyph', 'RPA' if k == 1 else ''))
            out.append(mp.wedge(x + 10, y + 23.5, 8, 'rpaglyph'))
        out.append(place(mp.protein(0.0, 0.0, 40, 'Exo1', 'exo1', h=15), 0.0, 0.0, 168, y - 48, 1.0))
        out.append(place(mp.protein(0.0, 0.0, 40, 'Exo1', 'exo1', h=15), 0.0, 0.0, 168, y + 50, 1.0))
        out.append(mp.arrow(150, y - 62, 100, y - 62, 'resects the new strands', key=KEY))
        out.append('<path class="censtall" d="M340 %.1f V%.1f"/>' % (y - 40, y + 40))
        out.append(label(340, y + 58, 'stalled ends', 'tfs'))
        for x in range(372, 552, 30):
            out.append(mp.wedge(x, y - 3.5, 8, 'rpaglyph'))
            out.append(mp.wedge(x + 12, y + 11.5, 8, 'rpaglyph'))
        out.append(place(kb + kf, mp.DH_X + mp.MCM_HALF, mp.DNA_Y, 590, y, 0.6))
        out.append(mp.arrow(620, y - 50, 680, y - 50, 'helicase runs on', key=KEY))
        for x in (700, 760, 820):
            out.append('<ellipse class="nucbody" cx="%d" cy="%d" rx="16" ry="14"/>' % (x, y))
        out.append(label(760, y + 44, 'nucleosomes come off as the helicase passes', 'tfs'))
        out.append(label(450, y + 58, 'RPA coats every single strand', 'tfs'))
        # The chromosome panel's drawing of the same thing.
        yc = 226
        out.append(rect(40, yc - 3, 800, 6, 'barfill'))
        out.append('<rect class="chrres" x="250" y="%d" width="300" height="14"/>' % (yc - 7))
        for x, sgn in ((250, -1), (550, 1)):
            out.append('<path class="chrexo" transform="translate(%d %d) scale(2)" d="M0 0 l%.1f -2.2 a3.2 3.2 0 1 0 0 4.4 z"/>'
                       % (x, yc - 14, sgn * 2.8))
        out.append(label(400, yc + 24, 'on the chromosome panel: orange is this single-stranded stretch, a glyph at each front', 'tfs'))
        return svg('resect', ''.join(out))

    def figure_spindle():
        # VIEW: a metaphase spindle at molecular scale, and the gauge that draws its length (TERMINAL)
        out = [label(440, 18, 'The spindle: two pole bodies and the microtubules between them.', 'tfh')]
        y = 112
        out.append(pole_body(150, y))
        out.append(pole_body(730, y))
        out.append(label(150, y + 56, 'spindle pole body', 'tfs'))
        out.append(label(730, y + 56, 'spindle pole body', 'tfs'))
        for dy, x0, x1 in ((-26, 162, 520), (-18, 718, 360), (18, 162, 500), (26, 718, 380)):
            out.append(mt(x0, x1, y + dy))
        out.append(label(440, y - 62, 'interpolar microtubules overlap in the middle; in anaphase they slide apart', 'tfs'))
        out.append(mt(162, 410, y))
        out.append(mt(718, 470, y))
        out.append(label(300, y + 34, 'kinetochore microtubule', 'tfs'))
        # Sister chromatids, bi-oriented, held by cohesin.
        for x in (424, 456):
            out.append(rect(x - 3, y - 50, 6, 100, 'barfill'))
        out.append('<rect class="chrkt" x="408" y="%d" width="12" height="14" rx="3"/>' % (y - 7))
        out.append('<rect class="chrkt" x="460" y="%d" width="12" height="14" rx="3"/>' % (y - 7))
        for yy in (y - 34, y + 34):
            out.append('<ellipse class="cencoh" cx="440" cy="%d" rx="26" ry="7"/>' % yy)
        out.append(label(440, y + 70, 'sister chromatids joined by cohesin; each kinetochore faces its own pole', 'tfs'))
        # The gauge.
        yg = 232
        out.append(label(40, yg - 14, 'the chromosome panel’s gauge draws the pole-to-pole length to scale:', 'tfs start'))
        x0 = 120
        out.append(rect(x0 - 6, yg - 3, 6, 12, 'spbfill'))
        for k in range(3):
            out.append('<rect class="chrsplshort" x="%d" y="%.1f" width="%d" height="1.3"/>' % (x0, yg + 0.2 + k * 2.15, 27))
        out.append(rect(x0 + 27, yg - 3, 6, 12, 'spbfill'))
        out.append(label(x0 + 14, yg + 24, '1.5 µm: metaphase', 'tfs'))
        x1 = 380
        out.append(rect(x1 - 6, yg - 3, 6, 12, 'spbfill'))
        for k in range(3):
            out.append('<rect class="chrsplext" x="%d" y="%.1f" width="%d" height="1.3"/>' % (x1, yg + 0.2 + k * 2.15, 162))
        out.append(rect(x1 + 162, yg - 3, 6, 12, 'spbfill'))
        out.append('<path class="chrsplline" d="M%d %d V%d"/>' % (x1 + 54, yg - 6, yg + 12))
        out.append(label(x1 + 81, yg + 24, '9 µm: extended; the dashed tick is the model’s 3 µm cutoff', 'tfs'))
        return svg('spindle', ''.join(out))

    def figure_bars(title, keys):
        # VIEW: each strain's share of extended spindles in the model, beside the paper's (TERMINAL)
        # A bar is the model's share over 301 runs; the black mark is the
        # paper's share, a band where the paper gives a range.
        out = [label(440, 18, title, 'tfh')]
        x0, x1, y0, y1, top = 90.0, 850.0, 44.0, 196.0, 80.0
        ys = lambda v: y1 - (y1 - y0) * min(v, top) / top
        out.append('<path class="tfaxis" d="M%.1f %.1f V%.1f H%.1f"/>' % (x0, y0 - 4, y1, x1))
        for v in (0, 20, 40, 60, 80):
            out.append(label(x0 - 8, ys(v) + 4, '%d%%' % v, 'tfs end'))
            if v:
                out.append('<path class="tfgrid" d="M%.1f %.1f H%.1f"/>' % (x0, ys(v), x1))
        step = (x1 - x0) / len(keys)
        for k, key in enumerate(keys):
            p = (presets or {}).get(key)
            if not p:
                continue
            cx = x0 + step * (k + 0.5)
            share = 100.0 * p['share']
            cls = {'wt': 'tfbar wt', 'rad53': 'tfbar r53', 'sites': 'tfbar sites'}[p['checkpoint']]
            out.append('<rect class="%s" x="%.1f" y="%.1f" width="44" height="%.1f"/>' % (cls, cx - 22, ys(share), y1 - ys(share)))
            nums = [float(n) for n in re.findall(r'[0-9.]+', p['paper'])]
            out.append(label(cx, min(ys(share), ys(max(nums or [0]))) - 6, 'model %d%%' % round(share), 'tfs'))
            if len(nums) >= 2:
                out.append('<rect class="tfpaperband" x="%.1f" y="%.1f" width="60" height="%.1f"/>'
                           % (cx - 30, ys(nums[1]), ys(nums[0]) - ys(nums[1])))
            elif nums:
                out.append('<path class="tfpaper" d="M%.1f %.1f H%.1f"/>' % (cx - 30, ys(nums[0]), cx + 30))
            words = p['label'].replace(', ', ' ').split(' ')
            half = (len(words) + 1) // 2
            out.append(label(cx, y1 + 16, ' '.join(words[:half]), 'tfs'))
            out.append(label(cx, y1 + 29, ' '.join(words[half:]), 'tfs'))
            out.append(label(cx, y1 + 43, 'paper: %s' % p['paper'], 'tfs lt'))
        out.append('<rect class="tfbar wt" x="96" y="252" width="12" height="9"/>')
        out.append(label(114, 260, 'bar: share of 301 model cells with a spindle of 3 \u00b5m or more at the scoring time', 'tfs start'))
        out.append('<path class="tfpaper" d="M560 256 H584"/>')
        out.append(label(590, 260, "black mark: the paper's share", 'tfs start'))
        return svg('bars', ''.join(out))

    def figure_ak():
        # VIEW: the late artificial kinetochore: a lacO array that builds a kinetochore only with ASK1-LacI (TERMINAL)
        out = [label(440, 18, 'A late artificial kinetochore: a lacO array that becomes a kinetochore when LacI carries Ask1.', 'tfh')]
        for y, on, words in ((128, True, 'ASK1-LacI: Ask1 on LacI builds a kinetochore on the array, which takes a microtubule'),
                             (214, False, 'vector: the same arrays, with LacI alone and no kinetochore')):
            out.append(dna(60, 820, y))
            out.append('<rect class="chraklac" x="300" y="%.1f" width="60" height="16" rx="2"/>' % (y - 8))
            out.append(label(330, y + 24, 'lacO array, 20 kb from L2', 'tfs'))
            out.append(place(mp.protein(0.0, 0.0, 44, 'LacI', 'gonebox' if not on else 'mind', h=14), 0.0, 0.0, 330, y - 18, 1.0))
            if on:
                out.append(place(mp.protein(0.0, 0.0, 44, 'Ask1', 'cendam1box', h=14), 0.0, 0.0, 330, y - 34, 1.0))
                out.append('<rect class="chrkt" x="322" y="%.1f" width="16" height="9" rx="3"/>' % (y - 52))
                out.append('<rect class="tfmt" x="328.5" y="%.1f" width="3" height="30" rx="1.5"/>' % (y - 82))
            out.append(label(560, y - 18, words, 'tfs'))
        out.append(label(440, 260, 'The model places one such site at 75 kb; in the strains on this page it stands for four.', 'tfs'))
        return svg('ak', ''.join(out))

    def figure_readout():
        # VIEW: a cell in HU scored at the 3 um line: a short spindle and an extended one (TERMINAL)
        out = [label(440, 18, 'In HU each cell is scored by the distance between its two spindle poles.', 'tfh')]
        for x, ext, words, sub in ((230, False, 'short: 1 to 2 µm', 'the poles stay close while the chromosomes are copied'),
                                   (650, True, 'extended: 3 to 7 µm', 'the poles move apart before copying is done')):
            out.append(cell(x, 104, ext))
            out.append(label(x, 182, words, 'tfn'))
            out.append(label(x, 197, sub, 'tfs'))
        out.append(gauge(250, 232, False))
        out.append(gauge(560, 232, True))
        out.append(label(440, 262, 'gauges drawn to scale; the dashed tick is the 3 µm line that separates the two classes', 'tfs lt'))
        return svg('readout', ''.join(out))

    def figure_controls():
        # VIEW: one experiment's two controls, and a strain classed by the control it lies nearer (TERMINAL)
        out = [label(440, 18, 'Each experiment scores its own short and extended controls.', 'tfh')]
        out.append(card(40, 70, ['wild type'], 'short', sub='short control'))
        out.append(card(672, 70, ['rad53-21'], 'extended', sub='extended control'))
        out.append(card(356, 70, ['a strain tested', 'in the same experiment'], None, sub='takes the class of the nearer'))
        out.append(mp.arrow(352, 113, 214, 113, 'nearer?', key=KEY))
        out.append(mp.arrow(528, 113, 666, 113, 'nearer?', key=KEY))
        out.append(label(440, 200, 'The share of extended spindles shifts with incubation time, temperature and HU dose,', 'tfl'))
        out.append(label(440, 216, 'so a strain is compared only with strains scored alongside it.', 'tfl'))
        out.append(label(440, 248, 'Each strain appears as a card with its genotype and its class.', 'tfs lt'))
        return svg('controls', ''.join(out))

    def figure_buds():
        # VIEW: a bud growing through S phase, the 15 um circumference that splits early from late, and the controls in each class (TERMINAL)
        out = [label(440, 18, 'Bud size tells how long a cell has been in S phase.', 'tfh')]
        out.append(mp.arrow(90, 98, 800, 98, '', key=KEY))
        out.append(label(806, 102, 'time in HU', 'tfs start'))
        for k, (x, r) in enumerate(((150, 7), (280, 12), (410, 17), (560, 22), (700, 27))):
            out.append('<circle class="tscmother" cx="%.1f" cy="58" r="24"/>' % (x - 6))
            out.append('<circle class="tscbud" cx="%.1f" cy="58" r="%.1f"/>' % (x + 16 + r * 0.8, r))
        out.append('<path class="chrsplline" d="M485 30 V124"/>')
        out.append(label(300, 118, 'small to medium buds: up to 15 µm around', 'tfs'))
        out.append(label(640, 118, 'medium to large buds: over 15 µm around', 'tfs'))
        x0 = 40
        for k, (sid, r, sub) in enumerate((('j8e-wt', 'small', 'small buds'), ('j8e-wt', 'large', 'large buds'),
                                           ('j8e-rad53', 'small', 'small buds'), ('j8e-rad53', 'large', 'large buds'))):
            out.append(spindle_card(x0 + k * 206, 140, [sid], r, sub=sub))
        out.append(label(440, 248, 'rad53-21 spindles extend as soon as the spindle forms, so they are extended in both classes.', 'tfs'))
        out.append(label(440, 263, sources(['j8e-wt']), 'tfs lt'))
        return svg('buds', ''.join(out))

    def figure_cenwhy():
        # VIEW: a fork collapsing beside a centromere and one collapsing far out on an arm, and what each does to the kinetochore (TERMINAL)
        # Each row is one chromosome stretch: the resected stretch above the
        # DNA, the kinetochore and its microtubule below it, toward the pole.
        out = [label(440, 18, 'A fork that fails beside a centromere costs it its kinetochore.', 'tfh')]
        for y, near in ((80, True), (186, False)):
            cen, col = 430.0, (372.0 if near else 130.0)
            out.append(dna(50, 620, y))
            out.append('<rect class="tsccen" x="%.1f" y="%.1f" width="22" height="14" rx="2"/>' % (cen - 11, y - 7))
            out.append(label(cen + 16, y - 12, 'centromere', 'tfs start'))
            ox = 392 if near else 160
            out.append('<path class="tfaxis" d="M%.1f %.1f V%.1f"/>' % (ox, y + 8, y + 16))
            out.append(label(ox - 4, y + 28, 'early origin', 'tfs end'))
            lo, hi = col - 64, col + 64
            out.append('<rect class="tscres" x="%.1f" y="%.1f" width="%.1f" height="6" rx="1"/>' % (lo, y - 20, hi - lo))
            out.append(label(col - 64, y - 26, 'collapsed fork, resected both ways by Exo1', 'tfs start'))
            out.append('<path class="chrsplline" d="M%.1f %.1f V%.1f"/>' % (col, y - 16, y + 10))
            kt = '<rect class="chrkt" x="%.1f" y="%.1f" width="16" height="10" rx="3"/>' % (cen - 8, y + 10)
            if near:
                out.append('<g class="tscfaded">%s</g>' % kt)
                out.append('<rect class="tfmt" x="%.1f" y="%.1f" width="3" height="22" rx="1.5"/>' % (cen - 1.5, y + 32))
                out.append(label(cen + 16, y + 34, 'the kinetochore lets go of its microtubule', 'tfs start'))
            else:
                out.append(kt)
                out.append('<rect class="tfmt" x="%.1f" y="%.1f" width="3" height="34" rx="1.5"/>' % (cen - 1.5, y + 20))
                out.append(label(cen + 16, y + 34, 'the kinetochore stays attached to its microtubule', 'tfs start'))
            out.append(card(690, y - 40, ['beside the centromere' if near else 'far out on an arm'], 'extended' if near else 'short',
                            sub='the spindle'))
        out.append(label(440, 258, 'Drawing, not data: in the model, resection stops 6.6 kb from the collapse.', 'tfs lt'))
        return svg('cenwhy', ''.join(out))

    def figure_readsum():
        # VIEW: the events between unchecked firing and an extended spindle, each with the strains that test it (TERMINAL)
        out = [label(440, 18, 'Spindles extend after forks fail near a centromere.', 'tfh')]
        steps = (('origins fire', 'past Rad53'), ('forks collapse', 'in a low dNTP pool'), ('next to a', 'centromere'),
                 ('Exo1 resects', 'centromeric DNA'), ('the kinetochore', 'lets go'), ('the spindle', 'extends'))
        tests = ((('dbf4-zn, mcm alleles:', 'short'), ('dbf4-m25 sld3-38A:', 'extended')),
                 (('dun1Δ added:', 'still extended'),),
                 (('ctf19Δ, mcm21Δ:', 'short'), ('late kinetochores:', 'short in small buds')),
                 (('exo1Δ:', 'short in small buds'),),
                 (),
                 (('the readout',),))
        w, gap = 122.0, 20.0
        for k, ((a, b), test) in enumerate(zip(steps, tests)):
            x = 30 + k * (w + gap)
            out.append('<rect class="tscbox" x="%.1f" y="44" width="%.1f" height="44" rx="6"/>' % (x, w))
            out.append(label(x + w / 2, 62, a, 'tfl'))
            out.append(label(x + w / 2, 77, b, 'tfl'))
            if k < len(steps) - 1:
                out.append(mp.arrow(x + w + 2, 66, x + w + gap - 2, 66, '', key=KEY))
            y = 112
            for words in test:
                for line in words:
                    out.append(label(x + w / 2, y, line, 'tfs'))
                    y += 13
                y += 6
        out.append(label(440, 230, 'Each strain below changes one step on this line. Spindles extend after a failure at some step,', 'tfl'))
        out.append(label(440, 246, 'and the strains that keep spindles short name the steps extension needs.', 'tfl'))
        out.append(label(440, 263, 'Julius et al. 2019; the HU firing profiles of rad53-21 dbf4-zn measure firing directly', 'tfs lt'))
        return svg('readsum', ''.join(out))

    def figure_chain(name, title, rows, foot=''):
        # VIEW: chains of strain cards, each step labelled with the manipulation it makes (TERMINAL)
        # A row alternates cards ({'ids', 'r', 'label', 'sub', 'hide'}) and
        # the words for the step between them; None between two cards draws
        # no arrow, for a card that is not made from its left neighbour. With
        # two rows each takes half the height.
        out = [label(440, 18, title, 'tfh')]
        tops = (96.0,) if len(rows) == 1 else (44.0, 152.0)
        for row, top in zip(rows, tops):
            cards = row[0::2]
            n = len(cards)
            cw = CARD_W if n < 4 else 150.0
            gap = (820.0 - n * cw) / max(1, n - 1)
            for k, spec in enumerate(cards):
                x = 30.0 + k * (cw + gap)
                out.append(spindle_card(x, top, spec['ids'], spec.get('r', 'all'), spec.get('label'), spec.get('sub'),
                                        spec.get('hide', False), cw))
                if k < n - 1 and row[2 * k + 1] is not None:
                    words = row[2 * k + 1].split(' / ')
                    yc = top + CARD_H / 2.0
                    out.append(mp.arrow(x + cw + 3, yc, x + cw + gap - 4, yc, '', key=KEY))
                    for j, line in enumerate(reversed(words)):
                        out.append(label(x + cw + gap / 2.0, yc - 6 - 12 * j, line, 'tfs'))
        ids = [i for row in rows for spec in row[0::2] for i in spec['ids']]
        if foot:
            out.append(label(440, 246, foot, 'tfs'))
        out.append(label(440, 263, sources(ids), 'tfs lt'))
        return svg(name, ''.join(out))

    def spindle_card(x, y, ids, readout, words=None, sub=None, hide=False, width=None):
        # VIEW: one card for one strain, or for strains that share a class, drawn from the classification (TERMINAL)
        got = [(spindle or {}).get(i) for i in ids]
        if any(g is None or readout not in g['cls'] for g in got):
            raise SystemExit('figures: no class for %s (%s)' % (', '.join(ids), readout))
        classes = set(g['cls'][readout] for g in got)
        if len(classes) != 1:
            raise SystemExit('figures: one card mixes classes: %s' % ', '.join(ids))
        name = words or ' or '.join(g['label'] for g in got)
        control = all(g['control'] for g in got)
        tag = sub or ''
        if control:
            tag = (tag + ', ' if tag else '') + '%s control' % classes.copy().pop()
        return card(x, y, split_words(name, 19 if width and width < CARD_W else 22), classes.pop(), sub=tag, hide=hide,
                    width=width or CARD_W)

    def sources(ids):
        # MODEL: the figure's sources, in the order its cards name them (TERMINAL)
        seen = []
        for i in ids:
            src = (spindle or {}).get(i, {}).get('source')
            if src and src not in seen:
                seen.append(src)
        return '; '.join(seen)

    def figure_result_chain(name, title, rows, source, foot=''):
        # VIEW: chains of result cards for readouts other than the spindle: growth, Rad53, firing (TERMINAL)
        # A row alternates cards ({'lines', 'word', 'kind', 'sub', 'hide'})
        # and the words for the step between them, as in figure_chain.
        out = [label(440, 18, title, 'tfh')]
        tops = (96.0,) if len(rows) == 1 else (44.0, 152.0)
        for row, top in zip(rows, tops):
            cards = row[0::2]
            n = len(cards)
            cw = CARD_W if n < 4 else 150.0
            gap = (820.0 - n * cw) / max(1, n - 1)
            for k, spec in enumerate(cards):
                x = 30.0 + k * (cw + gap)
                out.append(result_card(x, top, spec['lines'], spec['word'], spec['kind'], spec.get('sub', ''),
                                       spec.get('hide', False), cw))
                if k < n - 1 and row[2 * k + 1] is not None:
                    words = row[2 * k + 1].split(' / ')
                    yc = top + CARD_H / 2.0
                    out.append(mp.arrow(x + cw + 3, yc, x + cw + gap - 4, yc, '', key=KEY))
                    for j, line in enumerate(reversed(words)):
                        out.append(label(x + cw + gap / 2.0, yc - 6 - 12 * j, line, 'tfs'))
        if foot:
            out.append(label(440, 246, foot, 'tfs'))
        out.append(label(440, 263, source, 'tfs lt'))
        return svg(name, ''.join(out))

    def figure_growth():
        # VIEW: a spot test drawn as a schematic: two strains, a dilution series, a plate without HU and one with it (TERMINAL)
        out = [label(440, 18, 'Growth on HU plates reports whether cells survive replication stress.', 'tfh')]
        for px, plate in ((60, 'no HU'), (470, 'with HU')):
            out.append('<rect class="tscplate" x="%.1f" y="48" width="350" height="128" rx="10"/>' % px)
            out.append(label(px + 175, 194, plate, 'tfn'))
            for r, (strain, fails) in enumerate((('resistant strain', False), ('HU-sensitive strain', True))):
                y = 88 + 52 * r
                if px == 60:
                    out.append(label(px + 12, y + 4, strain, 'tfs start'))
                for k in range(5):
                    out.append(spot(px + 150 + 40 * k, y, 14.0 - 1.6 * k, fails and px > 100, k))
            out.append(label(px + 230, 66, 'each spot: tenfold fewer cells', 'tfs'))
        out.append(label(440, 222, 'A strain that grows without HU but not with it is HU-sensitive. The test reports survival,', 'tfl'))
        out.append(label(440, 238, 'so any defect that kills cells in HU reads the same way.', 'tfl'))
        out.append(label(440, 263, 'Drawing, not data. The cited growth tests spot tenfold or twentyfold dilutions.', 'tfs lt'))
        return svg('growth', ''.join(out))

    def figure_op_sum():
        # VIEW: the two arms left, each acting on the Mcm2-7 double hexamer, and the question that follows (TERMINAL)
        b, f = mp.mcm_double(mp.DH_X, mp.DNA_Y, nsd='displaced', phos=True, phos_pending=False)
        out = [label(440, 18, 'The Sld3 arm and the DDK arm both act on the Mcm2-7 double hexamer.', 'tfh')]
        for y, words in ((66, ['DDK marks', 'late origins']), (150, ['Sld3 binds', 'late origins'])):
            out.append('<rect class="tscbox" x="40" y="%.1f" width="150" height="46" rx="6"/>' % (y - 23))
            out.append(label(115, y - 3, words[0], 'tfl'))
            out.append(label(115, y + 13, words[1], 'tfl'))
        out.append(mp.arrow(194, 66, 290, 98, '', key=KEY))
        out.append(mp.arrow(194, 150, 290, 122, '', key=KEY))
        out.append(dna(290, 560, 112))
        out.append(place(b + f, mp.DH_X, mp.DNA_Y, 425, 112, 0.62))
        out.append(label(425, 182, 'Mcm2-7 double hexamer', 'tfn'))
        out.append(label(425, 198, 'DDK phosphorylates the Mcm4 and Mcm6 tails;', 'tfs'))
        out.append(label(425, 211, 'Sld3 binds the phosphorylated tails', 'tfs'))
        out.append('<g transform="translate(690 70) scale(2.4)">%s</g>'
                   % mp.cst_glyph({'stn1c': (0.0, 0.0, 14.0, 10.0), 'stn1n': (14.0, 0.0, 28.0, 10.0)}, pieces=('stn1c', 'stn1n')))
        out.append(label(724, 112, 'excess Stn1', 'tfn'))
        out.append('<path class="chrsplline" d="M684 96 Q560 92 474 102"/>')
        out.append(label(590, 86, '?', 'tfh'))
        out.append(label(724, 150, 'Does CST contact', 'tfl'))
        out.append(label(724, 166, 'Mcm2-7?', 'tfl'))
        out.append(label(440, 246, 'Drawing, not data: the question mark is the open question, not a contact.', 'tfs'))
        out.append(label(440, 263, 'DDK and Sld3: Deegan et al. 2016. Results: Gasparyan et al. 2009, 2022', 'tfs lt'))
        return svg('op-sum', ''.join(out))

    def op_chains():
        # VIEW: the measured spindles of the excess-Stn1 chapter, as chains of cards (TERMINAL)
        wt_op = [{'ids': ['g3a-wt']}, '+ stn1-OP', {'ids': ['g3a-op']}, None, {'ids': ['g3a-rad53']}]
        return {
            'op-sp': figure_chain('op-sp', 'Excess Stn1 extends spindles in HU with Rad53 intact.', [
                [{'ids': ['g3a-wt']}, '+ stn1-OP', {'ids': ['g3a-op'], 'hide': True}],
                [{'ids': ['g3a-wt']}, '+ rad53-21', {'ids': ['g3a-rad53']}]]),
            'op-exo1': figure_chain('op-exo1', 'Without Exo1, stn1-OP spindles stay short.', [
                wt_op, [{'ids': ['g3a-exo1']}, '+ stn1-OP', {'ids': ['g3a-exo1op'], 'hide': True}]]),
            'op-mcm': figure_chain('op-mcm', 'A weaker helicase keeps stn1-OP spindles short.', [
                wt_op, [{'ids': ['g3a-mcm2', 'g3a-mcm5'], 'label': 'mcm2-1 or mcm5-1, vector'}, '+ stn1-OP',
                        {'ids': ['g3a-mcm2op', 'g3a-mcm5op'], 'label': 'mcm2-1 or mcm5-1 stn1-OP', 'hide': True}]]),
            'op-zn': figure_chain('op-zn', 'dbf4-zn keeps stn1-OP spindles short.', [
                wt_op, [{'ids': ['g3a-zn']}, '+ stn1-OP', {'ids': ['g3a-znop'], 'hide': True}]]),
            'op-bob': figure_chain('op-bob', 'Without Dbf4, stn1-OP spindles still extend.', [
                [{'ids': ['g5c-wt']}, '+ stn1-OP', {'ids': ['g5c-op']}, None, {'ids': ['g5c-rad53']}],
                [{'ids': ['g5c-bobp']}, '+ stn1-OP', {'ids': ['g5c-bobpop'], 'hide': True}, None,
                 {'ids': ['g5c-bob']}, '+ stn1-OP', {'ids': ['g5c-bobop'], 'hide': True}]]),
            'op-rad53': figure_result_chain('op-rad53', 'Rad53 is phosphorylated on time in stn1-OP cells.', [
                [{'lines': ['vector'], 'sub': 'HU and MMS', 'word': 'on time', 'kind': 'good'}, '+ stn1-OP',
                 {'lines': ['stn1-OP'], 'sub': 'HU and MMS', 'word': 'on time', 'kind': 'good'}],
                [{'lines': ['rad9Δ, vector'], 'sub': 'HU: Mrc1 route only', 'word': 'on time', 'kind': 'good'}, '+ stn1-OP',
                 {'lines': ['rad9Δ stn1-OP'], 'sub': 'HU: Mrc1 route only', 'word': 'on time', 'kind': 'good', 'hide': True}]],
                'Gasparyan et al. 2009, Fig. 4 and Fig. S3', foot='Scored by the shift of phosphorylated Rad53 on a western blot.'),
            'op-rnr': figure_result_chain('op-rnr', 'Extra RNR activity does not rescue stn1-OP cells; less RNR activity kills them.', [
                [{'lines': ['wild type, vector'], 'sub': 'on HU', 'word': 'grows', 'kind': 'grows'}, '+ stn1-OP',
                 {'lines': ['stn1-OP'], 'sub': 'on HU', 'word': 'fails', 'kind': 'fails'}, '+ sml1Δ / or extra RNR1',
                 {'lines': ['stn1-OP sml1Δ, or', 'stn1-OP with extra RNR1'], 'sub': 'on HU', 'word': 'fails', 'kind': 'fails', 'hide': True}],
                [{'lines': ['dun1Δ, vector'], 'sub': 'no HU', 'word': 'grows', 'kind': 'grows'}, '+ stn1-OP',
                 {'lines': ['dun1Δ stn1-OP'], 'sub': 'no HU', 'word': 'fails', 'kind': 'fails'}, None,
                 {'lines': ['rnr2-1 stn1-OP'], 'sub': 'no HU, 23 °C', 'word': 'fails', 'kind': 'fails'}]],
                'Gasparyan et al. 2009, Figs. 1A and S4; Gasparyan et al. 2022, Figs. 1B and 1C'),
            'op-fire': figure_result_chain('op-fire', 'Late origins fire in stn1-OP cells in MMS, with Rad53 on.', [
                [{'lines': ['vector'], 'sub': 'late origins, 30 to 60 min', 'word': 'wait', 'kind': 'good'}, '+ stn1-OP',
                 {'lines': ['stn1-OP'], 'sub': 'ARS601/2, ARS603, ARS610', 'word': 'fire', 'kind': 'bad', 'hide': True}],
                [{'lines': ['vector'], 'sub': 'DNA made by one fork', 'word': 'farther', 'kind': 'good'}, '+ stn1-OP',
                 {'lines': ['stn1-OP'], 'sub': 'DNA made by one fork', 'word': 'less far', 'kind': 'bad'}]],
                'Gasparyan et al. 2009, Fig. 3: new DNA labelled with BrdU after release into MMS'),
            'growth': figure_growth(),
            'op-sum': figure_op_sum(),
        }

    def figure_y2h_read():
        # VIEW: a two-hybrid reporter turned on by a contact and by a bridge (TERMINAL)
        out = [label(440, 18, 'A two-hybrid reporter reads a contact and a bridge the same way.', 'tfh')]
        for ox, bridge in ((40, False), (470, True)):
            by = 196
            out.append(dna(ox, ox + 370, by))
            out.append('<rect x="%.1f" y="%.1f" width="54" height="20" rx="3" fill="#ffffff" stroke="#8a877b"/>' % (ox + 38, by - 10))
            out.append(label(ox + 65, by + 4, 'UAS', 'tfs'))
            out.append('<rect x="%.1f" y="%.1f" width="128" height="20" rx="3" fill="#ffffff" stroke="#8a877b"/>' % (ox + 215, by - 10))
            out.append(label(ox + 279, by + 4, 'reporter gene', 'tfs'))
            out.append('<rect x="%.1f" y="%.1f" width="44" height="24" rx="4" fill="#c9d6ea" stroke="#5b7aa8"/>' % (ox + 43, by - 38))
            out.append(label(ox + 65, by - 22, 'BD', 'tfs'))
            out.append('<ellipse cx="%.1f" cy="%.1f" rx="34" ry="19" fill="#ece7f5" stroke="#6d5a9a"/>' % (ox + 65, by - 72))
            out.append(label(ox + 65, by - 68, 'bait', 'tfl'))
            px = ox + (196 if bridge else 131)
            out.append('<ellipse cx="%.1f" cy="%.1f" rx="32" ry="19" fill="#ece7f5" stroke="#6d5a9a"/>' % (px, by - 72))
            out.append(label(px, by - 68, 'prey', 'tfl'))
            if bridge:
                out.append('<ellipse cx="%.1f" cy="%.1f" rx="36" ry="17" fill="#e3efe0" stroke="#3f8f3f"/>' % (ox + 130, by - 98))
                out.append(label(ox + 130, by - 94, 'native', 'tfs'))
            out.append('<rect x="%.1f" y="%.1f" width="40" height="24" rx="4" fill="#f3dfb2" stroke="#b07a1c"/>' % (px + 22, by - 116))
            out.append(label(px + 42, by - 100, 'AD', 'tfs'))
            out.append(mp.arrow(px + 52, by - 90, ox + 236, by - 14, '', key=KEY))
            out.append(label(ox + 185, by + 36, 'a native protein binds both: a bridge' if bridge else 'bait and prey touch: a contact', 'tfl'))
        out.append(label(440, 258, 'BD: GAL4 DNA-binding domain. AD: GAL4 activation domain. Reporters: HIS3, ADE2 and lacZ.', 'tfs'))
        out.append(label(440, 276, 'Drawing, not data.', 'tfs lt'))
        return svg_h('y2h-read', ''.join(out), 288)

    def figure_y2h_cut():
        # VIEW: the known pairs within CST and within the ring, and which of them interact (TERMINAL)
        out = [label(440, 18, 'Known partners show what an interaction means.', 'tfh')]
        yes, no, ring = '#3f8f6a', '#b9b5aa', '#6f7f99'
        cst = {'Cdc13': (150, 82), 'Stn1': (96, 176), 'Ten1': (204, 176)}
        for a, b, ok in (('Cdc13', 'Stn1', True), ('Stn1', 'Ten1', True), ('Cdc13', 'Ten1', False)):
            out.append(edge(cst[a], cst[b], yes if ok else no, not ok, 3))
        for name, (x, y) in cst.items():
            out.append('<circle cx="%.1f" cy="%.1f" r="23" fill="#ffffff" stroke="#3b3a35"/>' % (x, y))
            out.append(label(x, y + 4, name, 'tfs'))
        out.append(label(150, 228, 'CST: 2 of 3 contacts interact', 'tfl'))
        pos = ring_positions(430, 140, 64)
        adj = (('2', '6'), ('6', '4'), ('4', '7'), ('7', '3'), ('3', '5'), ('5', '2'))
        for a, b in adj:
            out.append(edge(pos[a], pos[b], no if (a, b) == ('2', '6') else yes, (a, b) == ('2', '6'), 3))
        for a, b in (('5', '6'), ('5', '7'), ('4', '5'), ('2', '4')):
            out.append(edge(pos[a], pos[b], ring, False, 1.4))
        for n, (x, y) in pos.items():
            out.append('<circle cx="%.1f" cy="%.1f" r="17" fill="%s" stroke="#3b3a35"/>' % (x, y, MCM_FILL[n]))
            out.append(label(x, y + 4, 'Mcm' + n, 'tfs'))
        out.append(label(430, 228, 'Mcm2-7: 5 of 6 contacts interact,', 'tfl'))
        out.append(label(430, 243, 'and 4 of 9 pairs that do not touch', 'tfl'))
        ring3d = {'scene': 'arch_closed', 'spin': 'rock', 'period': 14, 'amplitude': 0.45,
                  'labels': [{'at': 'Mcm' + n, 'text': 'Mcm' + n, 'radial': 46, 'keep': True} for n in '234567']}
        out.append(m3d_slot(618, 40, 236, 196, ring3d))
        out.append(label(736, 228, 'the ring in the structure (PDB 5BK4),', 'tfs'))
        out.append(label(736, 243, 'seen down the DNA', 'tfs'))
        out.append(label(440, 270, 'Known contacts interact 7 of 9 times. Mcm subunits that do not touch interact 4 of 9 times,', 'tfl'))
        out.append(label(440, 286, 'joined through the host ring. An interaction places two proteins in one assembly.', 'tfl'))
        ly = 314
        out.append(edge((40, ly - 4), (66, ly - 4), yes, False, 3))
        out.append(label(72, ly, 'interacts: 8 points or more over both orientations', 'tfs start'))
        out.append(edge((380, ly - 4), (406, ly - 4), no, True, 3))
        out.append(label(412, ly, 'no interaction', 'tfs start'))
        out.append(edge((520, ly - 4), (546, ly - 4), ring, False, 1.4))
        out.append(label(552, ly, 'interacts without touching', 'tfs start'))
        out.append(label(440, 338, 'Two-hybrid array, this dissertation. CST contacts: Lim et al. 2020; Grandin et al. 2001. Ring order Mcm2-6-4-7-3-5; structure Noguchi et al. 2017.', 'tfs lt'))
        return svg_h('y2h-cut', ''.join(out), 348)

    def figure_y2h_gate():
        # VIEW: which CST-Mcm2-7 pairs interact, as a grid, beside the plates of the four baits behind them (TERMINAL)
        out = [label(440, 18, 'Every CST–Mcm2-7 interaction includes Mcm2 or Mcm5.', 'tfh')]
        hits = {('Cdc13', '2'), ('Stn1', '2'), ('Stn1', '5'), ('Ten1', '2'), ('Ten1', '5')}
        grid = []
        for j, n in enumerate('234567'):
            out.append(label(118 + 44 * j, 78, 'Mcm' + n, 'tfs'))
        for i, row in enumerate(('Cdc13', 'Stn1', 'Ten1')):
            y = 112 + 42 * i
            out.append(label(86, y + 4, row, 'tfl end'))
            for j, n in enumerate('234567'):
                hit = (row, n) in hits
                grid.append('<circle cx="%.1f" cy="%.1f" r="12" fill="%s" stroke="%s" stroke-width="1.4"/>'
                            % (118 + 44 * j, y, '#3f8f6a' if hit else '#ffffff', '#3f8f6a' if hit else '#cfcabd'))
        out.append('<g class="tans">%s<image href="%s" x="404" y="44" width="462" height="363" preserveAspectRatio="xMidYMid meet"/></g>'
                   % (''.join(grid), image_uri('y2h-gate.jpg')))
        out.append('<g class="tqmark">%s</g>' % label(228, 158, '?', 'tfh'))
        out.append(label(228, 228, 'filled: the pair interacts', 'tfs'))
        out.append(label(228, 246, 'open: no interaction', 'tfs'))
        out.append(label(228, 278, 'Stn1 and Cdc13 activate no reporter', 'tfs'))
        out.append(label(228, 293, 'with Mcm4 in either orientation.', 'tfs'))
        out.append(label(635, 424, 'Plates for the four baits behind every interaction at Mcm2 and Mcm5.', 'tfs'))
        out.append(label(635, 439, 'Rows: −Trp −Leu; −Ade; −His with 3-AT; X-gal.', 'tfs'))
        out.append(label(440, 462, 'Two-hybrid array, this dissertation', 'tfs lt'))
        return svg_h('y2h-gate', ''.join(out), 472)

    def figure_y2h_bridge():
        # VIEW: the CST contacts on DDK and Mcm2-7, beside what each possible bridge predicts (TERMINAL)
        out = [label(440, 18, 'Each possible bridge predicts interactions that the screen does not show.', 'tfh')]
        marks = (cst_marks('Mcm2', 'CST', 26, 4) + cst_marks('Mcm5', 'ST', -22, 4)
                 + [{'at': 'Dbf4', 'text': 'S', 'shape': 'square', 'fill': CONTACT_FILL, 'ink': '#1d1d1b', 'dx': -20},
                    {'at': 'Cdc7', 'text': 'S', 'shape': 'square', 'fill': CONTACT_FILL, 'ink': '#1d1d1b', 'dx': 18}])
        out.append(m3d_slot(110, 34, 240, 216, {'scene': 'ddk_ring', 'spin': 'rock', 'period': 16, 'amplitude': 0.55, 'marks': marks,
                                                'labels': [{'at': 'Mcm2', 'text': 'Mcm2', 'dx': 30, 'dy': 22},
                                                           {'at': 'Mcm5', 'text': 'Mcm5', 'dx': -30, 'dy': 22},
                                                           {'at': 'Dbf4', 'text': 'Dbf4', 'dx': -24, 'dy': -16},
                                                           {'at': 'Cdc7', 'text': 'Cdc7', 'dx': 26, 'dy': -18}]}))
        out.append(key_mark(30, 70, 'circle', Y2H_FILL, '#ffffff', 'S'))
        out.append(label(44, 74, 'two-hybrid', 'tfs start'))
        out.append(key_mark(30, 96, 'square', CONTACT_FILL, '#1d1d1b', 'S'))
        out.append(label(44, 100, 'published', 'tfs start'))
        out.append(label(30, 124, 'C Cdc13', 'tfs start'))
        out.append(label(30, 139, 'S Stn1', 'tfs start'))
        out.append(label(30, 154, 'T Ten1', 'tfs start'))
        out.append('<image href="%s" x="16" y="252" width="404" height="258" preserveAspectRatio="xMidYMid meet"/>' % image_uri('cst-contacts-b.png'))
        rows = (('Dbf4 bridge', 'predicts Stn1 with Mcm2, Mcm4 and Mcm6', 'observed: Stn1 with Mcm2 and Mcm5'),
                ('Polymerase α bridge', 'predicts Cdc13 and Stn1 with all six', 'observed: interactions with two'),
                ('Host Mcm2-7 ring', 'predicts a partner of Mcm2 with Mcm4', 'observed: no CST interaction with Mcm4'))
        for k, (name, pred, seen) in enumerate(rows):
            y = 52 + 92 * k
            out.append('<rect class="tscbox" x="440" y="%.1f" width="420" height="78" rx="6"/>' % y)
            out.append(label(456, y + 22, name, 'tfn start'))
            out.append(label(456, y + 44, pred, 'tfl start'))
            out.append(label(456, y + 64, seen, 'tfl start tscfail'))
        out.append(label(650, 344, 'Interactions at Mcm2 fit direct contact best.', 'tfl'))
        out.append(label(650, 362, 'Interactions at Mcm5 could come from the host ring.', 'tfl'))
        out.append(label(440, 528, 'Left: CST contacts on DDK and Mcm2-7 (this dissertation): the Dbf4-bound ring of PDB 7PT6 (Saleh et al. 2022) seen down the DNA, and the domain map.', 'tfs lt'))
        return svg_h('y2h-bridge', ''.join(out), 538)

    def figure_y2h_models():
        # VIEW: what the Stn1-alone and CST-complex models predict, and what the screen found (TERMINAL)
        out = [label(440, 18, 'All three CST subunits interact with Mcm2-7.', 'tfh')]
        for cx, name, subs, pred, fits in ((220, 'Stn1-alone model', ('stn1',), 'predicts: only Stn1 interacts', False),
                                           (660, 'CST-complex model', ('cdc13', 'stn1', 'ten1'), 'predicts: all three interact', True)):
            out.append(label(cx, 56, name, 'tfn'))
            out.append('<circle cx="%.1f" cy="128" r="42" fill="#eef1f4" stroke="#6f7f99" stroke-width="1.4"/>' % cx)
            out.append(label(cx, 132, 'Mcm2-7', 'tfs'))
            for k, s in enumerate(subs):
                x = cx + 50 + 30 * k
                cls = {'stn1': 'cststn1', 'ten1': 'cstten1', 'cdc13': 'cstcdc13'}[s]
                out.append('<rect class="%s" x="%.1f" y="104" width="28" height="18" rx="2"/>' % (cls, x))
                out.append(label(x + 14, 117, {'stn1': 'S', 'ten1': 'T', 'cdc13': 'C'}[s], 'tfs'))
            out.append(label(cx, 196, pred, 'tfl'))
            out.append(label(cx, 216, 'observed: Cdc13, Stn1 and Ten1 interact', 'tfl ' + ('tscgrow' if fits else 'tscfail')))
        out.append(label(440, 252, 'Each cell tests one pair, so the screen cannot show the three subunits bound at once.', 'tfs'))
        out.append(label(440, 270, 'C, S, T: Cdc13, Stn1, Ten1. Drawing, not data.', 'tfs lt'))
        return svg_h('y2h-models', ''.join(out), 280)

    def figure_y2h_sites():
        # VIEW: the ring seen from its N-terminal face: where CST interacts, where Dbf4 anchors, where Sld3 binds (TERMINAL)
        out = [label(440, 18, 'CST interacts with Mcm2, where Dbf4 anchors DDK, and with Mcm5.', 'tfh')]
        star = {'shape': 'square', 'fill': '#d9a521', 'ink': '#1d1d1b', 'text': 'P'}
        marks = (cst_marks('Mcm2.R', 'CST', 0, 6) + cst_marks('Mcm5.R', 'ST', 0, -16)
                 + [dict(star, at=a) for a in ('Mcm4.L', 'Mcm6.L', 'Mcm4.R', 'Mcm6.R')])
        out.append(m3d_slot(20, 30, 540, 262, {'scene': 'ddk_face', 'spin': 'rockx', 'period': 22, 'amplitude': 1.1, 'marks': marks,
                                               'labels': [{'at': 'Dbf4', 'text': 'Dbf4', 'dx': -34},
                                                          {'at': 'Cdc7', 'text': 'Cdc7', 'dx': 30, 'dy': -16},
                                                          {'at': 'Mcm2.R', 'text': 'Mcm2', 'dx': 58, 'dy': 6},
                                                          {'at': 'Mcm5.R', 'text': 'Mcm5', 'dx': -48, 'dy': -16}]}))
        for k, line in enumerate(('DDK arm: CST interacts with Mcm2,', 'which carries the Dbf4 anchor.', '',
                                  'Sld3 arm: CST shows no interaction', 'with Mcm4 or Mcm6, where Sld3 binds.', '',
                                  'An interaction names a subunit and', 'leaves the surface unidentified.')):
            if line:
                out.append(label(586, 84 + 18 * k, line, 'tfl start'))
        out.append(key_mark(30, 306, 'circle', Y2H_FILL, '#ffffff', 'S'))
        out.append(label(44, 310, 'two-hybrid interaction (C Cdc13, S Stn1, T Ten1)', 'tfs start'))
        out.append(key_mark(330, 306, 'square', '#d9a521', '#1d1d1b', 'P'))
        out.append(label(344, 310, 'Mcm4 or Mcm6: DDK phosphorylates its tail, Sld3 binds it (tails not resolved)', 'tfs start'))
        out.append(label(440, 330, 'Mcm2-7 double hexamer with DDK, PDB 7PT6. Saleh et al. 2022; Deegan et al. 2016; Noguchi et al. 2026', 'tfs lt'))
        return svg_h('y2h-sites', ''.join(out), 340)

    def figure_y2h_tests():
        # VIEW: four measurements, each beside the models it separates (TERMINAL)
        out = [label(440, 18, 'Four measurements would separate the models.', 'tfh')]
        rows = (('purified CST and Mcm2-7 subunits', 'contact or bridge'),
                ('Stn1 fragments against Mcm2 and Mcm5', 'the Stn1 N-terminal fold or C-terminal region'),
                ('Sld3 at late origins in stn1-OP cells in MMS', 'models that act before Sld3 arrives or after'),
                ('ChIP of each CST subunit through S phase', 'CST-complex model or Stn1-alone model'))
        for k, (test, sep) in enumerate(rows):
            y = 46 + 54 * k
            out.append('<rect class="tscbox" x="30" y="%.1f" width="370" height="40" rx="6"/>' % y)
            out.append(label(215, y + 25, test, 'tfl'))
            out.append(mp.arrow(406, y + 20, 476, y + 20, '', key=KEY))
            out.append('<rect class="tscbox" x="482" y="%.1f" width="370" height="40" rx="6"/>' % y)
            out.append(label(667, y + 25, sep, 'tfl'))
        out.append(label(215, 274, 'measurement', 'tfs lt'))
        out.append(label(667, 274, 'what it separates', 'tfs lt'))
        return svg_h('y2h-tests', ''.join(out), 284)

    def figure_tel_q():
        # VIEW: CST acting at origins and at telomeres, with the reverse arrow still a question (TERMINAL)
        out = [label(440, 18, 'Origin firing and telomere function could act on each other through CST.', 'tfh')]
        for x, head, lines in ((30, 'At origins', ('excess Stn1 lets late origins fire', 'in MMS while Rad53 is active', '',
                                                   'dbf4-1 weakens DDK and', 'origin firing', '',
                                                   'excess Stn1 suppresses the', 'temperature sensitivity of dbf4-1')),
                               (560, 'At telomeres', ('Cdc13, Stn1 and Ten1 cap telomeres', '', 'Cdc13 recruits telomerase', '',
                                                      'cdc13-2 caps telomeres but recruits', 'too little telomerase: telomeres',
                                                      'shorten until cells senesce'))):
            out.append('<rect class="tscbox" x="%.1f" y="40" width="290" height="196" rx="8"/>' % x)
            out.append(label(x + 145, 62, head, 'tfn'))
            for k, line in enumerate(lines):
                if line:
                    out.append(label(x + 145, 86 + 17 * k, line, 'tfl'))
        out.append(mp.arrow(552, 100, 328, 100, '', key=KEY))
        out.append(label(440, 90, 'CST changes origin firing', 'tfs'))
        out.append('<path d="M328 176 H544" stroke="#6d6a5f" stroke-width="1.6" stroke-dasharray="5 4" fill="none"/>'
                   '<path d="M552 176 l-10 -5 v10 z" fill="#6d6a5f"/>')
        out.append(label(440, 166, 'does origin firing change', 'tfs'))
        out.append(label(440, 196, 'CST at telomeres?', 'tfs'))
        out.append(label(440, 262, 'Xu et al. 2009; Nugent et al. 1996; Caridi 2016; Hsieh 2012; Gasparyan et al. 2009, 2022', 'tfs lt'))
        return svg_h('tel-q', ''.join(out), 272)

    def figure_tel_test():
        # VIEW: the two mechanisms as telomere length over passages, and severity as a distribution of arrest passages (TERMINAL)
        out = [label(440, 18, 'The rate of telomere shortening separates the two mechanisms.', 'tfh')]
        for x0, name, slope, stop in ((50, 'elongation mechanism', 0.55, 205), (330, 'capping mechanism', 1.0, 205)):
            out.append('<path class="tfaxis" d="M%.1f 54 V196 H%.1f"/>' % (x0, x0 + 220))
            out.append(label(x0 + 110, 214, 'passages', 'tfs'))
            out.append(label(x0 - 6, 70, 'length', 'tfs end'))
            out.append('<path d="M%.1f 70 L%.1f 160" stroke="#8a877b" stroke-width="2" fill="none"/>' % (x0 + 4, x0 + 94))
            out.append(cross_mark(x0 + 94, 160, '#8a877b'))
            x1 = x0 + 4 + 90 / slope if slope < 1 else x0 + 94
            end = x1 if slope < 1 else x0 + 150
            if slope < 1:
                out.append('<path d="M%.1f 70 L%.1f 160" stroke="#3b6fb6" stroke-width="2.4" fill="none"/>' % (x0 + 4, end))
            else:
                end = x0 + 120
                out.append('<path d="M%.1f 70 L%.1f 186" stroke="#3b6fb6" stroke-width="2.4" fill="none"/>' % (x0 + 4, end))
            out.append(cross_mark(end, 160 if slope < 1 else 186, '#3b6fb6'))
            out.append(label(x0 + 110, 236, name, 'tfn'))
            out.append(label(x0 + 110, 252, 'slower shortening' if slope < 1 else 'same shortening, later arrest', 'tfs'))
        bx = 620
        out.append('<path class="tfaxis" d="M%.1f 54 V196 H%.1f"/>' % (bx, bx + 220))
        for k, (h1, h2) in enumerate(((20, 6), (55, 14), (80, 38), (45, 70), (18, 60), (6, 30), (0, 12))):
            x = bx + 12 + 29 * k
            out.append('<rect x="%.1f" y="%.1f" width="12" height="%.1f" fill="#b9b5aa"/>' % (x, 196 - h1, h1))
            out.append('<rect x="%.1f" y="%.1f" width="12" height="%.1f" fill="#3b6fb6" opacity="0.75"/>' % (x + 13, 196 - h2, h2))
        out.append(label(bx + 110, 214, 'passage at which a lineage stops', 'tfs'))
        out.append(label(bx + 110, 236, 'severity across lineages', 'tfn'))
        out.append(label(bx + 110, 252, 'scored from colonies by QuantaColony', 'tfs'))
        out.append(label(440, 280, 'grey: cdc13-2; blue: dbf4-1 cdc13-2 under each mechanism; a cross marks arrest. Drawing, not data.', 'tfs lt'))
        return svg_h('tel-test', ''.join(out), 290)

    readout_figs = {}
    if spindle:
        readout_figs = {
            'readout': figure_readout(),
            'controls': figure_controls(),
            'cenwhy': figure_cenwhy(),
            'sp-mcm': figure_chain('sp-mcm', 'Weakening the helicase gives short spindles in rad53-21.', [
                [{'ids': ['j4a-wt']}, '+ rad53-21', {'ids': ['j4a-rad53']}, '+ mcm2-1, mcm3-1 / or mcm5-1',
                 {'ids': ['j4a-mcm2', 'j4a-mcm3', 'j4a-mcm5'], 'label': 'rad53-21 mcm2-1, mcm3-1 or mcm5-1', 'hide': True}]]),
            'sp-zn': figure_chain('sp-zn', 'dbf4-zn lowers firing and keeps rad53-21 spindles short.', [
                [{'ids': ['j4a-wt']}, '+ rad53-21 / dbf4Δ covered by pDBF4', {'ids': ['j4a-pdbf4']},
                 'pDBF4 replaced / by pdbf4-zn', {'ids': ['j4a-zn'], 'hide': True}]],
                foot='In these strains firing was measured directly: centromere-flanking origins fire at 0.15 of the rad53-21 level.'),
            'sp-sites': figure_chain('sp-sites', 'Origins firing past Rad53 extend spindles while Rad53 works.', [
                [{'ids': ['j5a-wt']}, '+ one site', {'ids': ['j5a-m25', 'j5a-38a']}, '+ the other',
                 {'ids': ['j5a-sites'], 'hide': True}, '+ dun1Δ', {'ids': ['j5a-sitesdun1'], 'hide': True}],
                [{'ids': ['j5a-dun1'], 'sub': 'alone'}, None, {'ids': ['j5a-wt']}, '+ rad53-21', {'ids': ['j5a-rad53']}]]),
            'sp-ctf': figure_chain('sp-ctf', 'Removing the Ctf19 recruiter of DDK keeps rad53-21 spindles short.', [
                [{'ids': ['j6d-ctf19', 'j6d-mcm21']}, '+ rad53-21',
                 {'ids': ['j6d-rad53ctf19', 'j6d-rad53mcm21'], 'label': 'rad53-21 ctf19Δ or mcm21Δ', 'hide': True}],
                [{'ids': ['j6d-rad53']}, '+ ctf19Δ / or mcm21Δ',
                 {'ids': ['j6d-rad53ctf19', 'j6d-rad53mcm21'], 'label': 'rad53-21 ctf19Δ or mcm21Δ', 'hide': True}]]),
            'buds': figure_buds(),
            'sp-exo1': figure_chain('sp-exo1', 'Without Exo1, rad53-21 spindles stay short in small buds and extend later.', [
                [{'ids': ['j8e-wt'], 'r': 'small', 'sub': 'small buds'}, '+ rad53-21',
                 {'ids': ['j8e-rad53'], 'r': 'small', 'sub': 'small buds'}, '+ exo1Δ',
                 {'ids': ['j8e-rad53exo1'], 'r': 'small', 'sub': 'small buds', 'hide': True}],
                [{'ids': ['j8e-wt'], 'r': 'large', 'sub': 'large buds'}, '+ rad53-21',
                 {'ids': ['j8e-rad53'], 'r': 'large', 'sub': 'large buds'}, '+ exo1Δ',
                 {'ids': ['j8e-rad53exo1'], 'r': 'large', 'sub': 'large buds', 'hide': True}]]),
            'sp-ak': figure_chain('sp-ak', 'Kinetochores far from early origins keep rad53-21 spindles short in small buds.', [
                [{'ids': ['j9b-akv'], 'r': 'small', 'sub': 'small buds'}, '+ rad53-21',
                 {'ids': ['j9b-rad53akv'], 'r': 'small', 'sub': 'small buds'}, '+ ASK1-LacI / builds the kinetochores',
                 {'ids': ['j9b-rad53ako'], 'r': 'small', 'sub': 'small buds', 'hide': True}],
                [{'ids': ['j9b-akv'], 'r': 'large', 'sub': 'large buds'}, '+ rad53-21',
                 {'ids': ['j9b-rad53akv'], 'r': 'large', 'sub': 'large buds'}, '+ ASK1-LacI / builds the kinetochores',
                 {'ids': ['j9b-rad53ako'], 'r': 'large', 'sub': 'large buds', 'hide': True}]]),
            'readsum': figure_readsum(),
        }
        readout_figs.update(op_chains())
        readout_figs.update({'y2h-read': figure_y2h_read(), 'y2h-cut': figure_y2h_cut(), 'y2h-gate': figure_y2h_gate(),
                             'y2h-bridge': figure_y2h_bridge(), 'y2h-models': figure_y2h_models(), 'y2h-sites': figure_y2h_sites(),
                             'y2h-tests': figure_y2h_tests(), 'tel-q': figure_tel_q(), 'tel-test': figure_tel_test()})

    def figure_capping():
        # VIEW: a capped end: Rap1 with Rif1 and Rif2 on the duplex repeat, CST on the overhang, Ku at the end (TERMINAL)
        out = [label(440, 18, 'A capped end: Rap1 on the duplex repeat, CST on the 3\u2032 overhang, Ku at the end.', 'tfh')]
        y, j0, tip, oh = 132, 300, 690, 736
        out.append(rect(60, y - 4.5, j0 - 60, 3.5, 'tvstr I old') + rect(60, y + 0.5, j0 - 60, 3.5, 'tvstr I old'))
        out.append(rect(j0, y - 4.5, oh - j0, 3.5, 'tvstr G old') + rect(j0, y + 0.5, tip - j0, 3.5, 'tvstr C old'))
        for k in range(16):
            x = j0 + 12 + k * 23
            if x > tip - 10:
                break
            out.append('<rect class="tvrap1" x="%.1f" y="%.1f" width="18" height="9" rx="2"/>' % (x - 9, y - 16))
            if k % 2 == 0:
                out.append(mp.rif2_glyph(x, y - 32, 11.5) if k % 4 == 0 else mp.rif1_glyph(x, y - 32, 11.5))
        out.append(mp.tv_box(tip - 18, y + 14, 22, 12, 'Ku', 'tfku'))
        out.append(mp.tv_box(oh - 10, y - 2, 34, 12, 'Cdc13', 'tvcdc13'))
        out.append(mp.tv_box(oh - 10, y - 18, 46, 12, 'Stn1-Ten1', 'tvst'))
        out.append(pol_pair(60, y, '5', '3', True))
        out.append(pol(tip, y + 2.25, '5', False) + pol(oh + 18, y - 2.75, '3', False))
        out.append(label(180, y + 30, 'interior DNA', 'tfs'))
        out.append(label(470, y + 52, 'Rap1 binds the duplex repeat about once every 19 bp; Rif1 and Rif2 bind Rap1', 'tfs'))
        out.append(label(700, 82, 'CST: Cdc13, Stn1 and Ten1 on the overhang', 'tfs'))
        out.append(label(640, y + 30, 'Ku at the duplex end', 'tfs'))
        out.append(label(440, 238, 'The cap is the set of bound proteins: an end keeps it while enough Rap1 and CST stay bound.', 'tfl'))
        return svg('capping', ''.join(out))

    def figure_endrep():
        # VIEW: why copying leaves each new end short of the tip: the lagging-made end loses its last primer's
        # stretch, and the leading-made end is resected to make its overhang (TERMINAL)
        out = [label(440, 18, 'Each copy of a chromosome end leaves the C-rich strand short of the tip.', 'tfh')]
        h = 4.0

        def duplex(x0, j, xt, y, top, bot, xb=None):
            # Two strands from x0 to the tip xt, interior up to j; the bottom strand may stop at xb.
            xb = xt if xb is None else xb
            o = [rect(x0, y - h - 0.5, j - x0, h, 'tvstr I ' + top), rect(j, y - h - 0.5, xt - j, h, 'tvstr G ' + top),
                 rect(x0, y + 0.5, j - x0, h, 'tvstr I ' + bot)]
            if xb > j:
                o.append(rect(j, y + 0.5, xb - j, h, 'tvstr C ' + bot))
            return ''.join(o)

        # The lagging-made end: the parental G-rich strand is the template, and the
        # new C-rich strand arrives as Okazaki fragments, each started from an RNA primer.
        out.append(label(225, 52, 'lagging-made end', 'tfn'))
        y = 96
        out.append(rect(40, y - h - 0.5, 160, h, 'tvstr I old') + rect(200, y - h - 0.5, 200, h, 'tvstr G old'))
        for a, b in ((40, 150), (152, 262), (264, 378)):
            out.append(rect(a, y + 0.5, b - a, h, 'tvstr ' + ('I' if b <= 200 else 'C') + ' new')
                       if b <= 200 or a >= 200 else
                       rect(a, y + 0.5, 200 - a, h, 'tvstr I new') + rect(200, y + 0.5, b - 200, h, 'tvstr C new'))
            if b < 378:
                out.append('<rect class="tfrna" x="%.1f" y="%.1f" width="16" height="%.1f"/>' % (b - 16, y + 0.5, h))
        # The last fragment's primer sits at the tip, at the fragment's 5' end.
        out.append('<rect class="tfrna" x="378" y="%.1f" width="22" height="%.1f"/>' % (y + 0.5, h))
        out.append(label(389, y + 22, 'last RNA primer', 'tfs'))
        out.append(pol_pair(40, y, '5', '3', True) + pol(400, y - 2.5, '3', False))
        y2 = 172
        out.append(duplex(40, 200, 400, y2, 'old', 'new', 378))
        out.append(pol_pair(40, y2, '5', '3', True) + pol(400, y2 - 2.5, '3', False) + pol(378, y2 + 2.5, '5', False))
        out.append(mp.arrow(225, y + 32, 225, y2 - 22, key=KEY))
        out.append(label(232, y + 46, 'primers removed; nothing lies upstream to fill the last gap', 'tfs start'))
        out.append(mp.bracket(378, 400, y2 + 18, 'uncopied: the 3′ overhang'))
        # The leading-made end: the parental C-rich strand is the template, copied to the tip.
        out.append(label(655, 52, 'leading-made end', 'tfn'))
        out.append(duplex(470, 630, 830, y, 'new', 'old'))
        out.append(pol_pair(470, y, '5', '3', True) + pol_pair(830, y, '3', '5', False))
        out.append(label(650, y + 22, 'copied to the tip: a blunt end', 'tfs'))
        out.append(duplex(470, 630, 830, y2, 'new', 'old', 790))
        out.append(pol_pair(470, y2, '5', '3', True) + pol(830, y2 - 2.5, '3', False) + pol(790, y2 + 2.5, '5', False))
        out.append(mp.arrow(655, y + 32, 655, y2 - 22, key=KEY))
        out.append(label(662, y + 46, 'resection of the C-rich 5′ end', 'tfs start'))
        out.append(mp.bracket(790, 830, y2 + 18, 'resected'))
        out.append(label(440, 238, 'Fill-in by polymerase α starts from an RNA primer and cannot reach the tip either, so both daughter', 'tfl'))
        out.append(label(440, 256, 'C-rich strands end short of it, and the next copy of each end starts from the shorter strand.', 'tfl'))
        return svg('endrep', ''.join(out))

    # === SHARED FUNCTIONS ===

    figures = {
        'pools': figure_pools(), 'meters': figure_meters(), 'mec1': figure_mec1(),
        'rad53': figure_rad53(), 'resect': figure_resect(), 'spindle': figure_spindle(),
        'bars2': figure_bars('Spindles of 3 \u00b5m or more, 90 min after release into HU', ['s2-wt', 's2-rad53']),
        'bars3': figure_bars('Weakening the kinase or the helicase lowers rad53-21 extension', ['s2-wt', 's2-rad53', 's3-zn', 's3-mcm']),
        'bars4': figure_bars('Firing past Rad53 extends spindles while Rad53 works', ['s2-wt', 's2-rad53', 's4-sites', 's4-dun1']),
        'bars5': figure_bars('Where firing happens sets the extension', ['s2-wt', 's2-rad53', 's5-ctf19', 's5-akv', 's5-ako']),
        'bars6': figure_bars('Exo1 and bud size', ['s2-wt', 's6-rad53', 's6-exo1', 's6-exo1l']),
        'ak': figure_ak(),
        'capping': figure_capping(), 'endrep': figure_endrep(),
        'network': network(),
    }
    figures.update(readout_figs)
    figures.update(grn.build_all())
    figures.update({'rmeter-%s-%s' % (m, 'hu' if hu else 'nohu'): route_meter(m, hu) for m in ROUTE_METERS for hu in (True, False)})
    figures['stn1-badge'] = stn1_badge()
    # Mitosis at each kind of lineage page, and the slide that introduces it.
    figures.update({'mito-' + k: mitosis_strip(k) for k in MITO_STATES})
    figures['mito-key'] = figure_mitosis()
    # The RPA glyph, for the lineage pages to place at an uncapped end.
    figures['glyph-rpa'] = mp.wedge(0.0, 0.0, 8, 'rpaglyph')
    return figures


# A late origin's DDK-mark meter in each proposed model, as a fraction of the
# line: wild type, then stn1-OP in that model, without HU and in HU. The
# DDK-dependent models raise the marks: Mcm4 phosphorylation rises with excess
# Stn1 (Caridi et al. 2016). In HU Rad53 opposes DDK docking, which leaves the
# wild-type meter under the line. The models that act after Sld3 binds leave
# the marks unchanged, and mcm5-bob1 dbf4-delta cells carry no DDK. Drawing,
# not data: the heights order the cases and measure nothing.
ROUTE_METERS = {
    'conf': {'nohu': (1.05, 1.25), 'hu': (0.45, 1.12), 'notes': (['each DDK copy', 'marks more sites'], ['marks rise with', 'excess Stn1'])},
    'cdc7': {'nohu': (1.05, 1.25), 'hu': (0.45, 1.12), 'notes': (['DDK stays docked', 'against Rad53'], ['marks rise with', 'excess Stn1'])},
    'rif1': {'nohu': (1.05, 1.25), 'hu': (0.45, 1.12), 'notes': (['Rif1-PP1 removes', 'fewer marks'], ['marks rise with', 'excess Stn1'])},
    'bob1': {'nohu': (0.0, 0.0), 'hu': (0.0, 0.0), 'notes': (['no DDK: mcm5-bob1', 'fires without marks'], ['no DDK: mcm5-bob1', 'fires without marks'])},
    'ejss': {'nohu': (1.05, 1.05), 'hu': (0.45, 0.45), 'notes': (['unchanged: the model', 'acts after Sld3 binds'], ['unchanged: the model', 'acts after Sld3 binds'])},
    'ejpr': {'nohu': (1.05, 1.05), 'hu': (0.45, 0.45), 'notes': (['unchanged: the model', 'acts after Sld3 binds'], ['unchanged: the model', 'acts after Sld3 binds'])},
    'pola': {'nohu': (1.05, 1.05), 'hu': (0.45, 0.45), 'notes': (['unchanged: the model', 'acts after unwinding'], ['unchanged: the model', 'acts after unwinding'])},
}


def route_meter(model, hu):
    """VIEW: a late origin's DDK-mark meter in wild type and in stn1-OP, in one proposed model (TERMINAL)"""
    m = ROUTE_METERS[model]
    wt, op = m['hu' if hu else 'nohu']
    notes = m['notes'][0 if hu else 1]
    out = [label(85, 18, 'DDK-mark meter', 'tfn'), label(85, 33, 'at a late origin', 'tfs')]
    top, line_h, bar_h = 52, 118, 150
    base = top + bar_h
    for x, frac, name, cls in ((34, wt, 'wild type', 'chrmfill'), (100, op, 'stn1-OP', 'trmop')):
        out.append('<rect class="chrmeter" x="%.1f" y="%.1f" width="34" height="%.1f"/>' % (x, top, bar_h))
        h = min(frac * line_h, bar_h)
        out.append('<rect class="%s" x="%.1f" y="%.1f" width="34" height="%.1f"/>' % (cls, x, base - h, h))
        out.append(label(x + 17, base + 15, name, 'tfs'))
    out.append('<path class="chrtheta" d="M24 %.1f H144"/>' % (base - line_h))
    out.append(label(150, base - line_h + 4, 'line', 'tfs start'))
    for k, line in enumerate(notes):
        out.append(label(85, base + 36 + 14 * k, line, 'tfs'))
    out.append(label(85, base + 70, 'Drawing, not data.', 'tfs lt'))
    return ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 176 %d" class="tfig trmeter" data-fig="rmeter-%s">%s</svg>'
            % (base + 78, model, ''.join(out)))


NET_NODES = (('rad53', 'Rad53', 10, 22), ('ddk', 'DDK', 96, 22), ('mcm', 'Mcm2-7 near CEN', 182, 22),
             ('sld3', 'Sld3', 268, 22), ('exo1', 'Exo1 at CEN', 354, 22), ('spindle', 'Spindle ext.', 440, 22),
             ('dun1', 'Dun1, RNR', 10, 72), ('rif1', 'Rif1-PP1', 182, 72))


def network():
    """VIEW: the network the readout chapters assemble, every node present and dim until lit (TERMINAL)

    The lesson lights a node (on) once a page has shown it, and marks the
    node a page tests (focus). Arrows run left to right along the top row;
    Rad53 blocks DDK, Sld3 and Exo1 at the centromere through the line above
    the row, and acts through Dun1 below it; Rif1-PP1 opposes the marks on Mcm2-7.
    """
    w, h = 76, 26
    out = []
    for key, name, x, y in NET_NODES:
        words = name.split(' ', 1) if len(name) > 11 else [name]
        text = ''.join('<text class="tnettx" x="%.1f" y="%.1f">%s</text>' % (x + w / 2.0, y + (11 if len(words) > 1 else 17) + 10 * k, mp.esc(t))
                       for k, t in enumerate(words))
        out.append('<g id="tnet-%s" class="tnet"><rect class="tnetbox" x="%d" y="%d" width="%d" height="%d" rx="4"/>%s</g>'
                   % (key, x, y, w, h, text))
    links = []
    for a, b in ((96, 182), (182, 268), (268, 354), (354, 440)):
        links.append('<path class="tnetln" marker-end="url(#ah-tnet)" d="M%d 35 H%d"/>' % (a + w, b - 1))
    links.append('<path class="tnetln" d="M86 35 H95 M95 29 V41"/>')
    links.append('<path class="tnetln" d="M48 22 V8 H392 V21 M306 8 V21 M300 21 H312 M386 21 H398"/>')
    links.append('<path class="tnetln" marker-end="url(#ah-tnet)" d="M48 48 V71"/>')
    links.append('<path class="tnetln" d="M220 72 V49 M214 49 H226"/>')
    marker = ('<defs><marker id="ah-tnet" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" '
              'orient="auto-start-reverse"><path class="ahead" d="M0 0 L10 5 L0 10 z"/></marker></defs>')
    return ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 530 104" class="tnetsvg">%s%s%s</svg>'
            % (marker, ''.join(links), ''.join(out)))


CARD_W, CARD_H = 168.0, 86.0
UM = 12.0                  # figure units per micrometre in a card's gauge


def card(x, y, lines, cls, sub='', hide=False, width=CARD_W):
    """VIEW: a strain card: its genotype, a note, and a gauge with the class word, or a question mark until answered (TERMINAL)

    cls is 'short', 'extended' or None for a card with no class yet. A hidden
    card shows a question mark until the reader answers the slide's question.
    """
    out = ['<g class="tsc">', '<rect class="tscbox" x="%.1f" y="%.1f" width="%.1f" height="%.1f" rx="6"/>'
           % (x, y, width, CARD_H)]
    for k, line in enumerate(lines[:2]):
        out.append(label(x + width / 2, y + 18 + 14 * k, line, 'tfl tscgeno'))
    if sub:
        out.append(label(x + width / 2, y + 47, sub, 'tfs lt'))
    if cls:
        body = gauge(x + 14, y + 64, cls == 'extended') + label(x + width - 12, y + 72, cls, 'tfn end tscw ' + cls)
        if hide:
            out.append('<g class="tans">%s</g>' % body)
            out.append('<g class="tqmark">%s</g>' % label(x + width / 2, y + 74, '?', 'tfh'))
        else:
            out.append(body)
    out.append('</g>')
    return ''.join(out)


def result_card(x, y, lines, word, kind, sub='', hide=False, width=CARD_W):
    """VIEW: a card for a readout other than the spindle: genotype, note, and the result word, with spots for growth (TERMINAL)"""
    out = ['<g class="tsc">', '<rect class="tscbox" x="%.1f" y="%.1f" width="%.1f" height="%.1f" rx="6"/>'
           % (x, y, width, CARD_H)]
    for k, line in enumerate(lines[:2]):
        out.append(label(x + width / 2, y + 18 + 14 * k, line, 'tfl tscgeno'))
    if sub:
        out.append(label(x + width / 2, y + 47, sub, 'tfs lt'))
    cls = {'grows': 'tscgrow', 'good': 'tscgrow', 'fails': 'tscfail', 'bad': 'tscfail'}[kind]
    if kind in ('grows', 'fails'):
        body = ''.join(spot(x + 18 + 13 * k, y + 68, 5.2 - 0.6 * k, kind == 'fails', k) for k in range(5))
        body += label(x + width - 12, y + 72, word, 'tfn end ' + cls)
    else:
        body = label(x + width / 2, y + 74, word, 'tfn ' + cls)
    if hide:
        out.append('<g class="tans">%s</g>' % body)
        out.append('<g class="tqmark">%s</g>' % label(x + width / 2, y + 74, '?', 'tfh'))
    else:
        out.append(body)
    out.append('</g>')
    return ''.join(out)


def spot(x, y, r, fails, k):
    """VIEW: one spot of a dilution series, faint where a sensitive strain fails (TERMINAL)"""
    shade = (0.85, 0.3, 0.08, 0.0, 0.0)[k] if fails else (0.9, 0.85, 0.75, 0.65, 0.5)[k]
    return ('<circle class="tscspot" cx="%.1f" cy="%.1f" r="%.1f" opacity="%.2f"/>'
            '<circle cx="%.1f" cy="%.1f" r="%.1f" fill="none" stroke="#b9b5aa" stroke-width="0.6"/>'
            % (x, y, r, shade, x, y, r))


def stn1_badge():
    """VIEW: the stn1-OP badge for a close-up: the viewer's Stn1 glyph and the words (TERMINAL)"""
    glyph = mp.cst_glyph({'stn1c': (0.0, 0.0, 14.0, 10.0), 'stn1n': (14.0, 0.0, 28.0, 10.0)}, pieces=('stn1c', 'stn1n'))
    return ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="-1 -1 30 12">%s</svg>'
            '<span><b>stn1-OP</b>: Stn1 overproduced; the model does not draw it</span>' % glyph)


def gauge(x, y, extended):
    """VIEW: a spindle drawn to scale, pole to pole, with the 3 um line (TERMINAL)"""
    length = (5.0 if extended else 1.5) * UM
    cls = 'chrsplext' if extended else 'chrsplshort'
    out = [rect(x - 4, y - 5, 4, 12, 'spbfill')]
    for k in range(3):
        out.append('<rect class="%s" x="%.1f" y="%.1f" width="%.1f" height="1.3"/>' % (cls, x, y - 2.6 + k * 2.6, length))
    out.append(rect(x + length, y - 5, 4, 12, 'spbfill'))
    out.append('<path class="chrsplline" d="M%.1f %.1f V%.1f"/>' % (x + 3.0 * UM, y - 9, y + 9))
    return ''.join(out)


def cell(x, y, extended):
    """VIEW: a budded cell in HU: mother, bud, the nucleus across the neck and its spindle (TERMINAL)"""
    out = ['<circle class="tscmother" cx="%.1f" cy="%.1f" r="44"/>' % (x - 30, y),
           '<circle class="tscbud" cx="%.1f" cy="%.1f" r="30"/>' % (x + 42, y)]
    if extended:
        out.append('<ellipse class="tscnuc" cx="%.1f" cy="%.1f" rx="62" ry="13"/>' % (x + 4, y))
        x0, x1 = x - 50, x + 58
    else:
        out.append('<ellipse class="tscnuc" cx="%.1f" cy="%.1f" rx="22" ry="17"/>' % (x - 2, y))
        x0, x1 = x - 11, x + 7
    out.append(rect(x0 - 4, y - 6, 4, 12, 'spbfill'))
    out.append(rect(x1, y - 6, 4, 12, 'spbfill'))
    for k in range(3):
        out.append('<rect class="%s" x="%.1f" y="%.1f" width="%.1f" height="1.3"/>'
                   % ('chrsplext' if extended else 'chrsplshort', x0, y - 2.6 + k * 2.6, x1 - x0))
    return ''.join(out)


def split_words(words, width=22):
    """MODEL: a genotype on at most two lines, broken between words (TERMINAL)"""
    if len(words) <= width:
        return [words]
    parts, line = words.split(' '), ''
    for k, w in enumerate(parts):
        if line and len(line) + 1 + len(w) > width:
            return [line, ' '.join(parts[k:])]
        line = (line + ' ' + w).strip()
    return [line]


KEY = 'tfig'


# Mcm subunit fills, as the double hexamer glyph colours them.
MCM_FILL = {'2': '#e8a092', '3': '#efb98a', '4': '#efd27e', '5': '#a9d29a', '6': '#9cc3e6', '7': '#b9a8de'}
IMAGES = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'figures')


def image_uri(name):
    """MODEL: an image from tools/tour/figures as a data URI, so the lesson stays one file (TERMINAL)"""
    import base64
    kind = 'image/jpeg' if name.endswith('.jpg') else 'image/png'
    with open(os.path.join(IMAGES, name), 'rb') as f:
        return 'data:%s;base64,%s' % (kind, base64.b64encode(f.read()).decode('ascii'))


# ChimeraX subunit colours of the structure figures (build_mcm_structure_figures.py).
CX_COLORS = (('Mcm2', '#ff0000'), ('Mcm3', '#ffa500'), ('Mcm4', '#ffff00'), ('Mcm5', '#008000'), ('Mcm6', '#0000ff'),
             ('Mcm7', '#ee82ee'), ('Dbf4', '#c19a6b'), ('Cdc7', '#5fd3e0'), ('DNA', '#696969'))
Y2H_FILL = '#3f8f6a'      # a two-hybrid interaction, as the grid draws it
CONTACT_FILL = '#ffffff'  # a published contact


def m3d_slot(x, y, w, h, opts):
    """VIEW: a box the lesson fills with a turning ChimeraX structure (tools/tour/mol3d.js reads opts) (TERMINAL)"""
    import html
    import json
    return ('<foreignObject class="m3dslot" x="%.1f" y="%.1f" width="%.1f" height="%.1f">'
            '<div xmlns="http://www.w3.org/1999/xhtml" class="m3d" data-m3d="%s"></div></foreignObject>'
            % (x, y, w, h, html.escape(json.dumps(opts), quote=True)))


def colour_key(x, y, names):
    """VIEW: one row of subunit swatches in the structures' colours, starting at x (TERMINAL)"""
    out, cx = [], x
    for name, fill in CX_COLORS:
        if name not in names:
            continue
        out.append('<rect x="%.1f" y="%.1f" width="11" height="11" rx="2" fill="%s" stroke="#3b3a35" stroke-width="0.6"/>' % (cx, y - 9, fill))
        out.append(label(cx + 15, y, name, 'tfs start'))
        cx += 26 + 6.2 * len(name)
    return ''.join(out)


def key_mark(x, y, shape, fill, ink, letter):
    """VIEW: one marker as the structures draw it: a circle or a square with a letter (TERMINAL)"""
    body = ('<circle cx="%.1f" cy="%.1f" r="8" fill="%s" stroke="#1d1d1b" stroke-width="1.2"/>' % (x, y, fill)
            if shape == 'circle' else
            '<rect x="%.1f" y="%.1f" width="16" height="16" fill="%s" stroke="#1d1d1b" stroke-width="1.2"/>' % (x - 8, y - 8, fill))
    return body + ('<text x="%.1f" y="%.1f" font-size="9.5" text-anchor="middle" fill="%s" font-weight="bold" '
                   'font-family="Georgia, serif">%s</text>' % (x, y + 3.5, ink, letter))


def cst_marks(at, letters, dx0=0.0, dy=0.0):
    """MODEL: two-hybrid markers on one chain, side by side (TERMINAL)"""
    n = len(letters)
    return [{'at': at, 'text': c, 'shape': 'circle', 'fill': Y2H_FILL, 'dx': dx0 + 19 * (k - (n - 1) / 2.0), 'dy': dy}
            for k, c in enumerate(letters)]


def ring_positions(cx, cy, r):
    """MODEL: the six Mcm subunits around the ring, Mcm2-6-4-7-3-5, seen from the N-terminal face with the gate at the top (TERMINAL)"""
    import math
    order = ('2', '6', '4', '7', '3', '5')
    return {n: (cx + r * math.cos(math.radians(-60 + 60 * k)), cy + r * math.sin(math.radians(-60 + 60 * k)))
            for k, n in enumerate(order)}


def edge(a, b, colour, dashed, width):
    """VIEW: a line between two subunits (TERMINAL)"""
    return ('<path d="M%.1f %.1f L%.1f %.1f" stroke="%s" stroke-width="%.1f" fill="none"%s/>'
            % (a[0], a[1], b[0], b[1], colour, width, ' stroke-dasharray="5 4"' if dashed else ''))


# Mitosis as the checkpoint leaves it. Two homes, drawn as the trays of the
# Rad53 figure: Esp1 (separase) with Pds1 (securin) bound, and Cdc5. While
# Rad53 acts, Pds1 is kept from APC-Cdc20 and holds Esp1 home, so cohesin
# stays on the sisters and the spindle stays short; Cdc5 is held home, so
# mitotic exit waits. Without the hold, APC-Cdc20 destroys Pds1, Esp1 leaves
# home and cuts the cohesin subunit Scc1 (Uhlmann et al. 1999), the sisters
# part and the spindle lengthens; Cdc5 leaves home for mitotic exit. The
# star on Pds1 is Chk1's phosphate (Sanchez et al. 1999). Lengths are drawn
# closer than they are.
MITO_STATES = ('hold', 'go', 'deadhold', 'deadgo')
MITO_W, MITO_H = 330, 150


def mitosis_strip(state):
    """VIEW: one strip: the Esp1 and Cdc5 homes, and the spindle with its sisters, held or released (TERMINAL)"""
    return ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 %d %d" class="tfig tmito" data-mito="%s">%s</svg>'
            % (MITO_W, MITO_H, state, mitosis_body(state, 0.0, 0.0)))


def mitosis_body(state, ox, oy):
    """VIEW: the strip's contents at (ox, oy): homes, spindle, sisters, cohesin, and one line of words (TERMINAL)"""
    held = state in ('hold', 'deadhold')
    out = ['<g transform="translate(%.1f %.1f)"%s>' % (ox, oy, ' opacity="0.45"' if state.startswith('dead') else '')]
    # The homes.
    out.append(tray(6, 10, 112, 50, held))
    out.append(label(62, 72, 'Esp1 home', 'tfs'))
    out.append(tray(6, 84, 112, 34, held))
    out.append(label(62, 130, 'Cdc5 home', 'tfs'))
    if held:
        out.append(mp.protein(62, 42, 60, 'Esp1', 'esp1', h=18))
        out.append(mp.protein(62, 24, 52, 'Pds1', 'pds1', h=14))
        marks = []
        grn.ptm(marks, 92, 20, 'P')
        out.append(''.join(marks))
        out.append(mp.protein(62, 101, 52, 'Cdc5', 'cdc5', h=18))
    # The spindle: poles, microtubules, the sisters with their kinetochores.
    y = 62
    pl, pr = (204.0, 286.0) if held else (152.0, 318.0)
    for x in (pl, pr):
        out.append('<rect class="spbfill" x="%.1f" y="%.1f" width="8" height="30" rx="3"/>' % (x - 4, y - 15))
    out.append(mt(pl + 4, pr - 14, y - 9) + mt(pr - 4, pl + 14, y + 9))
    if held:
        cx = (pl + pr) / 2.0
        for dx in (-5, 5):
            out.append(rect(cx + dx - 2, y - 28, 4, 56, 'barfill'))
        out.append('<rect class="chrkt" x="%.1f" y="%.1f" width="6" height="10" rx="2"/>' % (cx - 13, y - 5))
        out.append('<rect class="chrkt" x="%.1f" y="%.1f" width="6" height="10" rx="2"/>' % (cx + 7, y - 5))
        for yy in (y - 18, y + 18):
            out.append('<ellipse class="cencoh" cx="%.1f" cy="%.1f" rx="11" ry="4"/>' % (cx, yy))
        out.append(label(cx, y + 48, 'cohesin joins the sisters', 'tfs'))
        out.append(label(cx, y + 62, 'spindle short', 'tfs'))
    else:
        for x, kx in ((pl + 22, pl + 10), (pr - 22, pr - 16)):
            out.append(rect(x - 2, y - 28, 4, 56, 'barfill'))
            out.append('<rect class="chrkt" x="%.1f" y="%.1f" width="6" height="10" rx="2"/>' % (kx, y - 5))
        cx = (pl + pr) / 2.0
        # Cut cohesin, and Esp1 that cut it; Pds1 destroyed by APC-Cdc20; Cdc5 out for mitotic exit.
        out.append('<path class="cencoh" d="M%.1f %.1f q6 -6 12 -2 M%.1f %.1f q6 4 12 -2"/>' % (cx - 22, y - 20, cx + 10, y + 22))
        out.append(mp.protein(cx, y - 4, 44, 'Esp1', 'esp1', h=16))
        out.append(mp.protein(cx, y + 32, 44, 'Cdc5', 'cdc5', h=14))
        out.append(mp.protein(cx, y - 40, 40, 'Pds1', 'pds1 gonebox', h=12))
        out.append(cross_mark(cx + 24, y - 40, '#b5452a'))
        out.append(label(cx, y + 62, 'Pds1 destroyed: the sisters part', 'tfs'))
    out.append('</g>')
    return ''.join(out)


def figure_mitosis():
    """VIEW: the slide: the centromere close-up of chapter 2 at anaphase beside the same close-up in a metaphase arrest,
    with the proteins that decide between them placed on it (TERMINAL)

    Each panel is the live close-up frozen at a state (mp.cen_still): the
    anaphase frame, sisters parted and cohesin gone, and the copied frame,
    cohesin on the sisters. On each sit APC-Cdc20, Pds1, Esp1 and Cdc5, with
    Rad53 in the arrest. Edges use the network's notation: arrows promote,
    bars inhibit, dashed grey is blocked; P and U are the phosphate Chk1 adds
    to Pds1 and the ubiquitin APC-Cdc20 adds.
    """
    out = [label(440, 18, 'While Rad53 acts, Pds1 keeps Esp1 from cohesin at the centromere, and mitosis waits.', 'tfh')]
    x0, y0, cw, ch, sc = 20.0, mp.DNA_Y - 236.0, 620.0, 400.0, 0.68
    for k, (state, title, held) in enumerate((('anaphase', 'caps intact: anaphase', False),
                                               ('copied', 'a cap lost: metaphase arrest', True))):
        px = 15 + 440 * k
        out.append(label(px + cw * sc / 2, 46, title, 'tfn'))
        clip = 'mk%d-crop' % k
        body = [mp.cen_still(state, 'mk%d' % k)]
        body.append(mitosis_regulators(held))
        out.append('<clipPath id="%s"><rect x="%.1f" y="%.1f" width="%.1f" height="%.1f"/></clipPath>' % (clip, x0, y0, cw, ch))
        out.append('<rect x="%.1f" y="56" width="%.1f" height="%.1f" rx="6" fill="#fff" stroke="#d9d6cc"/>' % (px, cw * sc, ch * sc))
        out.append('<g transform="translate(%.1f %.1f) scale(%.2f) translate(%.1f %.1f)"><g clip-path="url(#%s)">%s</g></g>'
                   % (px, 56, sc, -x0, -y0, clip, ''.join(body)))
    keys = []
    grn.link(keys, 250, 356, 272, 356, 'run')
    grn.text(keys, 278, 360, 'promotes', size=11, anchor='start', fill='#3b3a35')
    grn.link(keys, 350, 356, 372, 356, 'run', blunt=True)
    grn.text(keys, 378, 360, 'inhibits', size=11, anchor='start', fill='#3b3a35')
    grn.link(keys, 440, 356, 462, 356, 'held')
    grn.text(keys, 468, 360, 'blocked', size=11, anchor='start', fill='#3b3a35')
    grn.ptm(keys, 532, 356, 'P')
    grn.text(keys, 542, 360, 'phosphate (Chk1)', size=11, anchor='start', fill='#3b3a35')
    grn.ptm(keys, 650, 356, 'U')
    grn.text(keys, 660, 360, 'ubiquitin (APC-Cdc20)', size=11, anchor='start', fill='#3b3a35')
    out.append(''.join(keys))
    return svg_h('mitosis', ''.join(out), 372)


def mitosis_regulators(held):
    """VIEW: APC-Cdc20, Pds1, Esp1, Cdc5 and, in an arrest, Rad53, in the centromere close-up's coordinates (TERMINAL)

    In anaphase APC-Cdc20 ubiquitinates Pds1, Esp1 is free and sits at the
    cut cohesin between the parted sisters, and Cdc5 drives mitotic exit. In
    the arrest Rad53 blocks Pds1 binding to Cdc20 and restrains Cdc5, Chk1's
    phosphate is on Pds1, and Pds1 bound to Esp1 keeps it from cohesin.
    All of it sits above the sisters, left of the kinetochore.
    """
    out = []
    out.append(mp.protein(175, -56, 84, 'APC-Cdc20', 'apc', h=18))
    grn.link(out, 175, -46, 175, -23, 'held' if held else 'run')
    out.append(mp.protein(62, 30, 48, 'Cdc5', 'cdc5', h=18))
    grn.link(out, 87, 30, 110, 30, 'held' if held else 'run')
    out.append('<text class="glyphlab sm" x="62" y="52">%s</text>' % ('mitotic exit waits' if held else 'mitotic exit'))
    if held:
        burst = mp.kinase_burst(0.0, 0.0, 'Rad53')
        out.append('<g class="rad53k" transform="translate(62 -40) scale(0.62)">%s</g>' % burst)
        grn.ptm(out, 80, -56, 'P')
        grn.link(out, 82, -38, 166, -34, 'run', blunt=True)
        grn.link(out, 62, -20, 62, 19, 'run', blunt=True)
        out.append(mp.protein(175, -12, 46, 'Pds1', 'pds1', h=16))
        grn.ptm(out, 201, -20, 'P')
        out.append(mp.protein(175, 8, 56, 'Esp1', 'esp1', h=18))
        out.append('<text class="glyphlab sm" x="250" y="12">Pds1 binds Esp1</text>')
        grn.link(out, 178, 18, 188, 104, 'held')
    else:
        out.append('<g opacity="0.55">%s</g>' % mp.protein(175, -12, 46, 'Pds1', 'pds1 gonebox', h=16))
        grn.ptm(out, 201, -20, 'U')
        out.append('<text class="glyphlab sm" x="240" y="-8">degraded</text>')
        # Esp1 freed, at the cohesin it has cut between the parted sisters.
        out.append(mp.protein(250, mp.DNA_Y, 50, 'Esp1', 'esp1', h=18))
        out.append('<path class="cencoh" d="M232 %.1f q-10 -20 0 -40 M268 %.1f q10 20 0 40" fill="none"/>'
                   % (mp.DNA_Y - 14, mp.DNA_Y + 14))
        out.append('<text class="glyphlab sm" x="250" y="%.1f">cuts Scc1</text>' % (mp.DNA_Y + 28))
    return ''.join(out)


def cross_mark(x, y, colour):
    """VIEW: a small cross that marks where a lineage arrests (TERMINAL)"""
    return ('<path d="M%.1f %.1f l8 8 M%.1f %.1f l-8 8" stroke="%s" stroke-width="2.2" stroke-linecap="round"/>'
            % (x - 4, y - 4, x + 4, y - 4, colour))


def svg_h(name, body, h):
    """VIEW: one figure as an svg element of its own height, with its own arrow markers (TERMINAL)"""
    return ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 %d %d" class="tfig" data-fig="%s">%s%s</svg>'
            % (W, h, name, mp.defs(KEY), body))


def svg(name, body):
    """VIEW: one figure as an svg element with its own arrow markers (TERMINAL)"""
    return ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 %d %d" class="tfig" data-fig="%s">%s%s</svg>'
            % (W, H, name, mp.defs(KEY), body))


def pol(x, y, end, left):
    """VIEW: one strand-end label, 5' or 3', its baseline set on the strand's centre line y (TERMINAL)"""
    return label(x - 3 if left else x + 3, y + 2.8, end + '\u2032', 'tfpol ' + ('end' if left else 'start'))


def pol_pair(x, ymid, top, bot, left):
    """VIEW: the two strand-end labels of one duplex end, stacked clear of each other about its centre line (TERMINAL)"""
    cls = 'tfpol ' + ('end' if left else 'start')
    xx = x - 3 if left else x + 3
    return label(xx, ymid - 1.2, top + '\u2032', cls) + label(xx, ymid + 7.4, bot + '\u2032', cls)


def label(x, y, words, cls):
    """VIEW: one line of figure text (TERMINAL)"""
    return '<text class="tfx %s" x="%.1f" y="%.1f">%s</text>' % (cls, x, y, mp.esc(words))


def place(markup, cx, cy, tx, ty, s):
    """VIEW: a glyph with its labels, its point (cx, cy) on (tx, ty), at scale s (TERMINAL)"""
    body = re.sub(r'\s+id="[^"]*"', '', markup)
    body = re.sub(r'class="fx ', 'class="mfx ', body)
    return ('<g transform="translate(%.1f %.1f) scale(%.3f) translate(%.1f %.1f)">%s</g>'
            % (tx, ty, s, -cx, -cy, body))


def tray(x, y, w, h, solid):
    """VIEW: a home, dashed while its copies are free, solid while Rad53 holds them (TERMINAL)"""
    return '<rect class="%s" x="%.1f" y="%.1f" width="%.1f" height="%.1f" rx="4"/>' % (
        'chrtrayheld' if solid else 'chrtray tfdash', x, y, w, h)


def set_glyph(kit, x, y, width):
    """VIEW: one firing-factor set, centred on (x, y) and scaled to width (TERMINAL)"""
    b = mp.raw_box(mp.mini_clean(kit))
    return mp.mini(kit, (b[0] + b[2]) / 2.0, (b[1] + b[3]) / 2.0, x, y, width / (b[2] - b[0]))


def rect(x, y, w, h, cls):
    """VIEW: a plain bar (TERMINAL)"""
    return '<rect class="%s" x="%.1f" y="%.1f" width="%.1f" height="%.1f" rx="1"/>' % (cls, x, y, w, h)


def dna(x0, x1, y):
    """VIEW: a duplex: two strands joined by rungs (TERMINAL)"""
    return (rect(x0, y - 6, x1 - x0, 4, 'barfill') + rect(x0, y + 2, x1 - x0, 4, 'barfill')
            + ''.join('<path class="tfrung" d="M%.1f %.1f V%.1f"/>' % (x, y - 2, y + 2) for x in range(int(x0) + 4, int(x1), 8)))


def meter(x, y, h, frac):
    """VIEW: an origin meter, filled to frac, with its dashed threshold at the top (TERMINAL)"""
    return ('<rect class="chrmeter" x="%.1f" y="%.1f" width="16" height="%.1f"/>'
            '<rect class="chrmfill" x="%.1f" y="%.1f" width="16" height="%.1f"/>'
            '<path class="chrtheta" d="M%.1f %.1f H%.1f"/>'
            % (x, y, h, x, y + h * (1 - frac), h * frac, x - 6, y, x + 22))


def fork(x, y, n):
    """VIEW: a stalled fork: two copied sisters, two unwound strands carrying n RPA, the duplex ahead (TERMINAL)

    Each parental strand is one path that bends on a curve where its height
    changes, so the fork reads as one molecule.
    """
    x1, x2 = x + 50, x + 50 + 30 * n
    spans = [(x, x1, 'sis'), (x1, x2, 'uw'), (x2, x2 + 40, 'dup')]
    rows = {'top': {'sis': -11.0, 'uw': -12.0, 'dup': -3.0}, 'bot': {'sis': 11.0, 'uw': 12.0, 'dup': 3.0}}
    out = ['<path class="dnapar thin" d="%s"/>' % mp.strand_course(spans, y, rows[side], 20.0) for side in ('top', 'bot')]
    out.append('<path class="dnanew thin" d="M%.1f %.1f H%.1f"/>' % (x, y - 6.5, x1 - 6))
    out.append('<path class="dnanew thin" d="M%.1f %.1f H%.1f"/>' % (x, y + 6.5, x1 - 6))
    # Strand ends: the top parental strand runs 5' to 3' left to right; the new
    # strand on it is the lagging strand, 5' at the fork; the other is leading.
    out.append(pol_pair(x2 + 40, y, '3', '5', False)
               + pol(x1 - 6, y - 6.5, '5', False) + pol(x1 - 6, y + 6.5, '3', False)
               + pol_pair(x, y - 8.75, '5', '3', True) + pol_pair(x, y + 8.75, '5', '3', True))
    for k in range(n):
        out.append(mp.wedge(x + 58 + 30 * k, y - 9.5, 8, 'rpaglyph', 'RPA' if k == 0 else ''))
    return ''.join(out)


def pole_body(x, y):
    """VIEW: a spindle pole body as a layered plaque (TERMINAL)"""
    return ('<rect class="spbfill" x="%.1f" y="%.1f" width="20" height="64" rx="8"/>'
            '<rect class="spbin" x="%.1f" y="%.1f" width="6" height="52" rx="3"/>' % (x - 10, y - 32, x - 3, y - 26))


def mt(x0, x1, y):
    """VIEW: one microtubule from a pole toward x1 (TERMINAL)"""
    return '<rect class="tfmt" x="%.1f" y="%.1f" width="%.1f" height="3" rx="1.5"/>' % (min(x0, x1), y - 1.5, abs(x1 - x0))


if __name__ == '__main__':
    for k, v in build_figures().items():
        print(k, len(v))
