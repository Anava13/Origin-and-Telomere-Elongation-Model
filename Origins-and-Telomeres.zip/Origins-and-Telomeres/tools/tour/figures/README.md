Dissertation figures the lesson shows as images. tools/tour/figures.py embeds
each one as a data URI, so the tour stays one self-contained HTML file.

- y2h-gate.jpg: two-hybrid plates for the four baits behind every CST-Mcm2-7
  interaction at Mcm2 and Mcm5 (dissertation figure Y2H_Raw_Gate), title cropped,
  resized to 1400 px wide.
- cst-contacts.png: CST contacts on DDK and Mcm2-7, panels A and B (dissertation
  figure origin-cst-contacts), caption cropped.
- cst-contacts-b.png: panel B of the same figure (the domain map), cut from
  cst-contacts.png. The lesson draws panel A as a turning structure (PDB 7PT6).
