"""The Rad53 network in HU: Rad53's four outputs, the arms they hold, and the spindle at the end.

The readout chapter draws one panel per genotype under each close-up. Every
arm ends at the spindle: the four arms Rad53 holds in HU feed one event, a
fork failing beside a centromere, and that event ends in a spindle that
extends before the DNA is copied. While nothing reaches the end, anaphase
waits until the DNA is copied and the spindle stays short.

Rules. Rad53 holds each arm through one output: it marks Sld3, marks Dbf4,
marks Dun1 (which raises the dNTP pool) and acts at stalled forks. An arm
runs when Rad53 is broken or when the output that holds it is broken. Late
origins fire only while both the Sld3 arm and the DDK arm run and the
helicase works. A fork fails beside a centromere only while late origins
fire and DDK still reaches the origins beside centromeres; the dNTP and fork
arms add to that failure and are not enough alone (dun1-delta alone keeps
spindles short; dbf4-m25 sld3-38A extends them while Rad53 still raises
dNTPs and protects forks). A slowed step (exo1-delta, kinetochores far from
early origins) delays the end: extension waits for large buds.

States: 'run' (green), 'held' (grey, Rad53 holds it or nothing feeds it),
'broken' (a red cross, an allele removes it), 'slow' (amber, an allele slows it).
"""

W, H = 780, 252

import math  # noqa: E402
import os  # noqa: E402
import sys  # noqa: E402

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import make_panels as mp  # noqa: E402

# Each genotype the chapter draws: what it breaks, with the allele named on the cross.
GENOTYPES = {
    'wt': {'name': 'wild type'},
    'rad53': {'name': 'rad53-21', 'rad53': 'rad53-21'},
    'r53zn': {'name': 'rad53-21 dbf4-zn', 'rad53': 'rad53-21', 'ddk': 'dbf4-zn'},
    'r53mcm': {'name': 'rad53-21 mcm2-1', 'rad53': 'rad53-21', 'helicase': 'mcm2-1'},
    'sites': {'name': 'dbf4-m25 sld3-38A', 'immune': 'dbf4-m25 sld3-38A'},
    'r53ctf19': {'name': 'rad53-21 ctf19Δ', 'rad53': 'rad53-21', 'ctf19': 'ctf19Δ'},
    'r53exo1': {'name': 'rad53-21 exo1Δ', 'rad53': 'rad53-21', 'exo1': 'exo1Δ'},
    'r53ako': {'name': 'rad53-21 4× LATE-AK, ASK1-LacI', 'rad53': 'rad53-21', 'ak': 'late kinetochores'},
}

ARMS = (('sld3', 'phosphorylates Sld3', ['Sld3 binds', 'late origins']),
        ('dbf4', 'phosphorylates Dbf4', ['DDK marks', 'late origins']),
        ('dun1', 'phosphorylates Dun1', ['dNTP pool', 'stays low']),
        ('fork', 'acts at stalled forks', ['stalled forks', 'collapse']))


def build_all():
    """BASE CONTROLLER: one network panel per genotype, and the key panel with its legend."""

    # === SUB-CONTROLLERS ===

    def panel(key, legend=False):
        # SUB-CONTROLLER: a genotype's states, then its drawing

        st = states(GENOTYPES[key])
        return draw(st, GENOTYPES[key], legend)

    def honing(key):
        # SUB-CONTROLLER: one step of the search for where excess Stn1 acts, then its drawing

        step = hone_step(key)
        return draw_hone(step)

    def route(model, hu):
        # SUB-CONTROLLER: one proposed model's network with or without HU, then its drawing

        st = route_states(model, hu)
        return draw_route(st, ROUTES[model], hu)

    def capped_net(al, page, legend=False):
        # SUB-CONTROLLER: the network's states for one allele at one kind of page, then its drawing

        st = cap_states(al, page)
        return draw_cap(st, CAP_ALLELES[al], legend)

    out = {'grn-' + k: panel(k) for k in GENOTYPES}
    out['grn-key'] = panel('wt', legend=True)
    out.update({'grn-' + k: honing(k) for k in HONE})
    for model in ROUTES:
        for hu in (True, False):
            out['route-%s-%s' % (model, 'hu' if hu else 'nohu')] = route(model, hu)
    out['route-key'] = route_key()
    out['route-map'] = draw_route_map()
    for al in CAP_ALLELES:
        for page in CAP_PAGES:
            out['grncap-%s-%s' % (al, page)] = capped_net(al, page)
    out['grncap-key'] = capped_net('wt', 'arrested', legend=True)
    return out


# The excess-Stn1 chapter narrows, one result at a time, the region of the
# network where excess Stn1 may first act. Each region is a polygon in network
# units; a result drops the steps it rules out, and from the fifth result on the
# region stays the same size while the results that follow test what is left.
# The fork arm is not ruled out by any genetic test: forks travel less far in
# stn1-OP cells, which extra firing also causes, so it is drawn apart as open.
# Once Rad53 is known to come on, the region starts at the arm boxes: each arm
# box stands for its whole arm, Rad53's mark included.
_L = 194
HONE_REGIONS = {
    'all': [(2, -4), (778, -4), (778, 258), (2, 258)],
    'rad53': [(_L, 20), (778, 20), (778, 258), (_L, 258)],
    'exo1': [(_L, 20), (512, 20), (512, 140), (652, 140), (652, 258), (_L, 258)],
    'dun1': [(_L, 20), (512, 20), (512, 140), (652, 140), (652, 251), (346, 251), (346, 200), (_L, 200)],
    'fire': [(_L, 20), (504, 20), (504, 104), (330, 104), (330, 138), (_L, 138)],
}
HONE = {
    'hone1': {'region': 'all', 'end': 'extended', 'cap': 'stn1-OP cells extend spindles in HU with Rad53 present'},
    'hone2': {'region': 'rad53', 'end': 'extended', 'cap': 'Rad53 is activated on time, also in rad9Δ cells',
              'rad53note': ['on time,', 'also in rad9Δ']},
    'hone3': {'region': 'exo1', 'end': 'short', 'cap': 'stn1-OP cells need Exo1 to extend spindles',
              'slow': 'exo1Δ: slower'},
    'hone4': {'region': 'dun1', 'end': 'extended', 'cap': 'Extra RNR activity does not rescue stn1-OP cells, and dun1Δ kills them',
              'dntp': 'sml1Δ or extra RNR1: more RNR activity; stn1-OP cells still fail on HU'},
    'hone5': {'region': 'fire', 'open': True, 'end': 'extended',
              'cap': 'Late origins fire in stn1-OP cells while Rad53 is on'},
    'hone6': {'region': 'fire', 'open': True, 'end': 'short', 'cap': 'A weaker helicase keeps stn1-OP spindles short',
              'helicase': 'mcm2-1, mcm5-1: weaker helicase'},
    'hone7': {'region': 'fire', 'open': True, 'end': 'short', 'cap': 'dbf4-zn keeps stn1-OP spindles short',
              'ddk': 'dbf4-zn'},
    'hone8': {'region': 'fire', 'open': True, 'end': 'extended', 'cap': 'Without Dbf4, stn1-OP spindles still extend',
              'ddk': 'mcm5-bob1 dbf4Δ'},
    'hone9': {'region': 'fire', 'open': True, 'end': 'extended',
              'cap': 'The Sld3 and DDK arms both act on the Mcm2-7 double hexamer'},
}


# The proposed models of CST at Mcm2-7, each drawn as the steps from the
# double hexamer to the spindle in a stn1-OP cell. Rad53, on in HU, opposes
# DDK docking and keeps Sld3 off Mcm4 (the DDK and Sld3 arms of chapter 9).
# Each model names the step CST acts on (target) and how ('edge': an arrow,
# or a bar for an inhibition). In HU a model reaches the spindle through its
# own step only where the dissertation says the step suffices; where firing
# would also need Sld3 to reach a late origin while Rad53 is on, that step is
# drawn open, as the Sld3 measurement of the next slide would test. Steps
# after an open step are drawn as proposals: they follow if the model holds.
ROUTES = {
    'conf': {'name': 'Mcm2-7 conformation model', 'target': 'mk', 'edge': 'better substrate for Cdc7',
             'hu': {'dk': 'held', 'mk': 'prop', 's3': 'open'}},
    'cdc7': {'name': 'Cdc7-retention model', 'target': 'dk', 'edge': 'keeps DDK on Mcm4',
             'hu': {'dk': 'prop', 'mk': 'prop', 's3': 'open'}},
    'rif1': {'name': 'Rif1-PP1 inhibition model', 'target': 'rif', 'edge': 'lowers its activity', 'bar': True,
             'hu': {'dk': 'held', 'rif': 'held', 'mk': 'prop', 's3': 'open'}},
    'bob1': {'name': 'conformation model without DDK', 'target': 's3', 'edge': 'carries Sld3 past Rad53',
             'second': ('s3', '\u2020 alters the Mcm5 surface'), 'allele': 'mcm5-bob1 dbf4\u0394',
             'hu': {'s3': 'prop'}},
    'ejss': {'name': 'lagging-strand ejection, ssDNA binding', 'target': 'cg', 'edge': 'binds the exiting strand',
             'hu': {'dk': 'held', 'mk': 'held', 's3': 'open'}},
    'ejpr': {'name': 'lagging-strand ejection, protein binding', 'target': 'cg', 'edge': 'binds Mcm2 and Mcm5',
             'hu': {'dk': 'held', 'mk': 'held', 's3': 'open'}},
    'pola': {'name': 'polymerase \u03b1 stimulation', 'target': 'pa', 'edge': 'stimulates priming',
             'hu': {'dk': 'held', 'mk': 'held', 's3': 'open'}},
}
ROUTE_W, ROUTE_H = 560, 276
# The chain at a late origin, left to right, then down to the spindle.
ROUTE_NODES = (('dk', 8, 92, 80, ['DDK docks', 'on Mcm2']), ('mk', 104, 92, 88, ['Mcm4 marks', 'pass the line']),
               ('s3', 208, 92, 78, ['Sld3 binds', 'Mcm4']), ('cg', 302, 92, 84, ['the helicase', 'activates']),
               ('pa', 402, 92, 70, ['Pol \u03b1', 'primes']), ('lf', 488, 92, 66, ['late origins', 'fire']))
ROUTE_COL = {'prop': '#2f5fa7', 'open': '#8a877b', 'allele': '#c48a1c'}


def route_states(model, hu):
    """MODEL: every step of one proposed model's network, with or without HU (TERMINAL)"""
    m = ROUTES[model]
    s = {k: 'run' for k, _, _, _, _ in ROUTE_NODES}
    s.update({'hu': 'run' if hu else 'held', 'rad53': hu, 'rif': 'run', 'ff': 'held', 'end': 'short'})
    if hu:
        s.update({'cg': 'prop', 'pa': 'prop', 'lf': 'prop', 'ff': 'prop', 'end': 'extended'})
        s.update(m['hu'])
    if m.get('allele'):
        s['dk'] = 'broken'
        s['mk'] = 'allele'
    return s


def draw_route(s, m, hu):
    """VIEW: one proposed model as the steps from the double hexamer to the spindle, CST's step drawn as a proposal (TERMINAL)"""
    out = []
    blue, grey = ROUTE_COL['prop'], ROUTE_COL['open']
    nodes = {k: (x, y, w, h) for k, x, y, w, h in ((n[0], n[1], n[2], n[3], 40) for n in ROUTE_NODES)}
    nodes['rif'] = (104, 166, 88, 30)
    nodes['ff'] = (442, 160, 112, 40)
    # Upstream: HU, then Rad53 and its two holds on the double hexamer.
    route_node(out, 8, 6, 104, 34, ['HU stalls forks'] if hu else ['no HU'], s['hu'])
    link(out, 112, 23, 146, 23, 'run' if hu else 'held')
    small_star(out, 170, 24, hu)
    for key in ('dk', 's3'):
        x, y, w, h = nodes[key]
        link(out, 170 + (-14 if key == 'dk' else 14), 44, x + w / 2, y - 3, 'run' if hu else 'held', blunt=True)
    text(out, 196, 18, 'Rad53 on' if hu else 'Rad53 idle', size=10.5, anchor='start', fill='#7a3a14' if hu else '#8a877b')
    text(out, 196, 31, 'opposes DDK docking,' if hu else '', size=10, anchor='start', fill='#3b3a35')
    text(out, 196, 43, 'keeps Sld3 off Mcm4' if hu else '', size=10, anchor='start', fill='#3b3a35')
    text(out, ROUTE_W - 6, 18, 'stn1-OP cell, in HU' if hu else 'stn1-OP cell, no HU', size=11, anchor='end', fill='#6d6a5f',
         weight='bold')
    # The chain at a late origin.
    order = [n[0] for n in ROUTE_NODES]
    for a, b in zip(order, order[1:]):
        xa, ya, wa, ha = nodes[a]
        xb, yb, wb, hb = nodes[b]
        st = s[b] if s[b] in ('prop', 'open', 'held') else ('run' if s[a] != 'held' else 'held')
        if s[a] in ('held', 'broken') and s[b] != 'allele':
            st = 'held'
        route_link(out, xa + wa, ya + ha / 2, xb - 2, yb + hb / 2, st)
    for key, x, y, w, lines in ROUTE_NODES:
        words = lines
        if key == 'mk' and s['mk'] == 'allele':
            words = ['mcm5-bob1:', 'no marks needed']
        route_node(out, x, y, w, 40, words, s[key])
    if s['dk'] == 'broken':
        cross(out, 8 + 80 - 10, 92 + 6, '')
        text(out, 48, 146, m.get('allele', ''), size=10.5, fill=COL['broken'], style='italic')
    if s['s3'] == 'open':
        text(out, 247, 146, 'needs Sld3 at late', size=10, fill=grey, style='italic')
        text(out, 247, 158, 'origins: untested', size=10, fill=grey, style='italic')
    # Rif1-PP1 opposes the marks.
    if not m.get('allele'):
        x, y, w, h = nodes['rif']
        route_node(out, x, y, w, h, ['Rif1-PP1'], s['rif'])
        link(out, x + w / 2, y - 2, x + w / 2, 134, 'run' if s['rif'] == 'run' else 'held', blunt=True)
        text(out, x + w / 2 - 6, 152, 'removes marks', size=10, anchor='end', fill='#3b3a35')
    # Down to the spindle.
    x, y, w, h = nodes['ff']
    route_link(out, 521, 134, 521, y - 2, s['ff'] if s['ff'] != 'run' else 'run')
    route_node(out, x, y, w, h, ['forks fail beside', 'a centromere'], s['ff'])
    route_link(out, x + w / 2, y + h, x + w / 2, 212, s['ff'])
    route_end(out, 316, 214, 238, 44, s['end'], hu)
    # CST and its proposed step.
    cx, cy = 8, 214
    cst_node(out, cx, cy)
    targets = [(m['target'], m['edge'])] + ([m['second']] if m.get('second') else [])
    for k, (key, words) in enumerate(targets):
        x, y, w, h = nodes[key]
        tx, ty = x + w / 2 + (10 * k), y + h + 2
        sx, sy = cx + 70 + 12 * k, cy + 2
        cxp, cyp = (sx + tx) / 2.0 - 10 + 24 * k, max(sy, ty) + 16 + 10 * k
        out.append('<path d="M%.1f %.1f Q%.1f %.1f %.1f %.1f" stroke="%s" stroke-width="2" fill="none" stroke-dasharray="6 4"/>'
                   % (sx, sy, cxp, cyp, tx, ty, blue))
        a = math.atan2(ty - cyp, tx - cxp)
        if m.get('bar'):
            dx, dy = 7 * math.cos(a + math.pi / 2), 7 * math.sin(a + math.pi / 2)
            out.append('<path d="M%.1f %.1f L%.1f %.1f" stroke="%s" stroke-width="2.6"/>' % (tx - dx, ty - dy, tx + dx, ty + dy, blue))
        else:
            p = [(tx, ty), (tx - 9 * math.cos(a) + 4.5 * math.sin(a), ty - 9 * math.sin(a) - 4.5 * math.cos(a)),
                 (tx - 9 * math.cos(a) - 4.5 * math.sin(a), ty - 9 * math.sin(a) + 4.5 * math.cos(a))]
            out.append('<path d="M%.1f %.1f L%.1f %.1f L%.1f %.1f Z" fill="%s"/>' % (p[0] + p[1] + p[2] + (blue,)))
        text(out, cx + 74, cy + 22 + 14 * k, 'proposed: ' + words if k == 0 else words, size=10.5, anchor='start',
             fill=blue, style='italic')
    return ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 %d %d" class="tgrnsvg troute">%s</svg>'
            % (ROUTE_W, ROUTE_H, ''.join(out)))


# Where each proposed model places CST on the chapter 9 network: a numbered
# badge at the step, keyed beside the network. The network is the last search
# panel of chapter 9, so the outline still encloses the steps where excess
# Stn1 may first act.
ROUTE_MAP = (
    ('1', 'Mcm2-7 conformation', ('dbf4',)),
    ('2', 'Cdc7 retention', ('dbf4',)),
    ('3', 'Rif1-PP1 inhibition', ('dbf4',)),
    ('4', 'conformation without DDK', ('sld3', 'fire')),
    ('5', 'ejection, ssDNA binding', ('fire',)),
    ('6', 'ejection, protein binding', ('fire',)),
    ('7', 'polymerase \u03b1 stimulation', ('fire', 'fork')),
)
# Badge rows, one per step: the first badge's centre and the step between badges.
ROUTE_MAP_AT = {'dbf4': (236, 140, 22), 'sld3': (312, 26, 22), 'fire': (390, 38, 22), 'fork': (342, 198, 22)}
ROUTE_MAP_KEY = (('DDK arm: more phosphorylated Mcm4 sites', ('1', '2', '3')),
                 ('Sld3 arm: Sld3 carried past Rad53', ('4',)),
                 ('firing, at the Mcm5 surface', ('4',)),
                 ('firing, after Sld3 binds', ('5', '6')),
                 ('firing, once the origin unwinds', ('7',)),
                 ('fork arm, in elongation or restart', ('7',)))


def draw_route_map():
    """VIEW: the chapter 9 network with a numbered badge on each step a proposed model places CST at, keyed at the side (TERMINAL)"""
    step = hone_step('hone9')
    step['cap'] = 'Where each proposed model places CST'
    svg = draw_hone(step)
    out = []
    placed = {}
    for num, _, steps in ROUTE_MAP:
        for st in steps:
            x, y, dx = ROUTE_MAP_AT[st]
            k = placed.get(st, 0)
            placed[st] = k + 1
            map_badge(out, x + dx * k, y, num)
    kx = 800
    text(out, kx, 0, 'Proposed models', size=12, anchor='start', weight='bold')
    for k, (num, name, _) in enumerate(ROUTE_MAP):
        map_badge(out, kx + 9, 20 + 19 * k, num)
        text(out, kx + 24, 24 + 19 * k, name, size=11, anchor='start')
    y0 = 20 + 19 * len(ROUTE_MAP) + 14
    text(out, kx, y0, 'Steps they act on', size=12, anchor='start', weight='bold')
    for k, (words, nums) in enumerate(ROUTE_MAP_KEY):
        text(out, kx, y0 + 18 + 16 * k, ', '.join(nums) + ': ' + words, size=10.5, anchor='start', fill='#2f5fa7')
    svg = svg.replace('viewBox="0 -46 %d ' % W, 'viewBox="0 -46 %d ' % (W + 260), 1)
    return svg.replace('</svg>', ''.join(out) + '</svg>')


def map_badge(out, x, y, num):
    """VIEW: one model's number in a dashed blue circle, the proposal style (TERMINAL)"""
    out.append('<circle cx="%.1f" cy="%.1f" r="9" fill="#e8eef8" stroke="#2f5fa7" stroke-width="1.5" stroke-dasharray="3 2"/>' % (x, y))
    text(out, x, y + 4, num, size=11, fill='#2f5fa7', weight='bold')


def route_key():
    """VIEW: the key shared by every proposed model's network (TERMINAL)"""
    out = []
    items = (('run', 'runs'), ('held', 'blocked by Rad53, or without input'), ('prop', 'proposed, or follows from a proposal'),
             ('open', 'needs a step not yet tested'))
    x = 6
    for state, words in items:
        route_link(out, x, 12, x + 24, 12, state, head=False)
        text(out, x + 30, 16, words, size=11, anchor='start', fill='#3b3a35')
        x += 44 + 6.0 * len(words)
    return ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 %d 24" class="troutekey">%s</svg>' % (int(x), ''.join(out)))


def route_node(out, x, y, w, h, lines, state):
    """VIEW: one step of a proposed model's network, its box styled by state (TERMINAL)"""
    if state in ('run', 'held', 'broken', 'slow', 'plain'):
        stroke = {'run': COL['run'], 'held': '#cfcabd', 'broken': COL['broken'], 'slow': COL['slow'], 'plain': '#8a877b'}[state]
        fill = {'run': '#eef5ec', 'held': '#f7f6f2', 'broken': '#fbeeea', 'slow': '#fbf3e2', 'plain': '#ffffff'}[state]
        dash = ' stroke-dasharray="4 3"' if state == 'held' else ''
    else:
        stroke = ROUTE_COL[state]
        fill = {'prop': '#e8eef8', 'open': '#ffffff', 'allele': '#fbf3e2'}[state]
        dash = {'prop': ' stroke-dasharray="6 3"', 'open': ' stroke-dasharray="2 4" stroke-linecap="round"', 'allele': ''}[state]
    out.append('<rect x="%.1f" y="%.1f" width="%.1f" height="%.1f" rx="5" fill="%s" stroke="%s" stroke-width="1.5"%s/>'
               % (x, y, w, h, fill, stroke, dash))
    ink = '#8a877b' if state in ('held', 'open') else ('#2f5fa7' if state == 'prop' else '#1d1d1b')
    for k, line in enumerate(lines):
        text(out, x + w / 2, y + h / 2 + 4 - 7 * (len(lines) - 1) + 14 * k, line, size=11, fill=ink)


def route_link(out, x0, y0, x1, y1, state, head=True):
    """VIEW: an arrow between two steps, styled by state (TERMINAL)"""
    c = ROUTE_COL.get(state, COL.get(state, '#6d6a5f'))
    dash = {'held': ' stroke-dasharray="5 4"', 'prop': ' stroke-dasharray="6 4"',
            'open': ' stroke-dasharray="2 4" stroke-linecap="round"'}.get(state, '')
    out.append('<path d="M%.1f %.1f L%.1f %.1f" stroke="%s" stroke-width="2" fill="none"%s/>' % (x0, y0, x1, y1, c, dash))
    if head:
        a = math.atan2(y1 - y0, x1 - x0)
        p = [(x1, y1), (x1 - 8 * math.cos(a) + 4 * math.sin(a), y1 - 8 * math.sin(a) - 4 * math.cos(a)),
             (x1 - 8 * math.cos(a) - 4 * math.sin(a), y1 - 8 * math.sin(a) + 4 * math.cos(a))]
        out.append('<path d="M%.1f %.1f L%.1f %.1f L%.1f %.1f Z" fill="%s"/>' % (p[0] + p[1] + p[2] + (c,)))


def route_end(out, x, y, w, h, end, hu):
    """VIEW: the spindle at the end of a proposed model's network (TERMINAL)"""
    fill = {'extended': '#fbe9df', 'short': '#e6f1e3'}[end]
    stroke = {'extended': '#c0571f', 'short': '#3f8f6a'}[end]
    out.append('<rect x="%.1f" y="%.1f" width="%.1f" height="%.1f" rx="6" fill="%s" stroke="%s" stroke-width="1.6"/>'
               % (x, y, w, h, fill, stroke))
    words = (['the spindle extends', 'before the DNA is copied'] if end == 'extended'
             else ['the spindle stays short', 'until the DNA is copied'])
    for k, line in enumerate(words):
        text(out, x + w / 2, y + 19 + 16 * k, line, size=12, fill=stroke, weight='bold' if k == 0 else 'normal')
    if hu:
        text(out, x + w / 2, y + h + 13, 'measured in stn1-OP cells in HU', size=10, fill='#6d6a5f')


def small_star(out, x, y, on):
    """VIEW: Rad53 as a small star, bright while it acts (TERMINAL)"""
    pts = []
    for k in range(24):
        r = 21 if k % 2 == 0 else 15.5
        a = math.pi * 2 * k / 24
        pts.append('%.1f,%.1f' % (x + r * math.cos(a), y + r * math.sin(a)))
    out.append('<polygon points="%s" fill="%s" stroke="#7a3a14" stroke-width="1"/>' % (' '.join(pts), '#c8622a' if on else '#e6c2ad'))
    text(out, x, y + 4, 'Rad53', size=10, weight='bold')


def cst_node(out, x, y):
    """VIEW: CST as three blocks, Cdc13, Stn1 and Ten1, with its name (TERMINAL)"""
    for k, (cls, letter) in enumerate((('cstcdc13', 'C'), ('cststn1', 'S'), ('cstten1', 'T'))):
        out.append('<rect class="%s" x="%.1f" y="%.1f" width="20" height="18" rx="2"/>' % (cls, x + 22 * k, y))
        text(out, x + 22 * k + 10, y + 13, letter, size=10, weight='bold')
    text(out, x + 33, y + 32, 'CST', size=11, weight='bold')


def hone_step(key):
    """MODEL: one step of the search: its region's outline, its caption and the result it draws (TERMINAL)"""
    step = dict(HONE[key])
    step['key'] = key
    step['outline'] = HONE_REGIONS[step['region']]
    return step


def states(g):
    """MODEL: every node and link of the network in one genotype (TERMINAL)"""
    s = {'rad53': 'broken' if g.get('rad53') else 'run'}
    for arm, _, _ in ARMS:
        edge_broken = (arm in ('sld3', 'dbf4') and g.get('immune'))
        s['e-' + arm] = 'broken' if edge_broken else ('held' if s['rad53'] == 'broken' else 'run')
        s['a-' + arm] = 'run' if (s['rad53'] == 'broken' or edge_broken) else 'held'
    if g.get('ddk'):
        s['a-dbf4'] = 'broken'
    fires = s['a-sld3'] == 'run' and s['a-dbf4'] == 'run'
    s['fire'] = 'broken' if g.get('helicase') else ('run' if fires else 'held')
    s['l-fire'] = 'broken' if (g.get('ctf19') and s['fire'] == 'run') else ('run' if s['fire'] == 'run' else 'held')
    s['fail'] = 'run' if s['l-fire'] == 'run' else 'held'
    s['exo'] = ('slow' if g.get('exo1') else 'run') if s['fail'] == 'run' else 'held'
    s['kt'] = s['exo']
    if s['kt'] == 'held':
        s['l-end'] = 'held'
    else:
        s['l-end'] = 'slow' if (g.get('ak') or s['kt'] == 'slow') else 'run'
    s['end'] = {'run': 'extended', 'slow': 'delayed', 'held': 'short'}[s['l-end']]
    return s


def draw(s, g, legend):
    """VIEW: the network as an svg, its links coloured by state and each broken step crossed and named (TERMINAL)"""
    out = []
    # Rad53 and its four outputs.
    rx, ry = 52, 120
    star(out, rx, ry, s['rad53'] == 'run')
    if s['rad53'] == 'broken':
        cross(out, rx, ry - 2, '')
        text(out, rx, ry + 52, g.get('rad53', ''), size=11, fill=COL['broken'], style='italic')
    ys = (34, 88, 152, 206)
    ax, aw, ah = 200, 122, 40
    for (arm, words, lines), y in zip(ARMS, ys):
        e = s['e-' + arm]
        x0, y0, x1, y1 = rx + 30, ry + (y - ry) * 0.25, ax - 4, y + ah / 2
        link(out, x0, y0, x1, y1, 'run' if e == 'run' else ('held' if e == 'held' else 'broken'), blunt=True)
        # The fork arm's words sit under its link, clear of the Dun1 arm's words above it.
        link_label(out, x0, y0, x1, y1, words, below=(arm == 'fork'))
        if e == 'broken':
            cross(out, x0 + (x1 - x0) * 0.85, y0 + (y1 - y0) * 0.85, '')
        node(out, ax, y, aw, ah, lines, s['a-' + arm])
        if arm == 'dbf4' and s['a-dbf4'] == 'broken':
            cross(out, ax + aw - 10, y + 6, '')
            text(out, ax + aw / 2, y + ah + 13, g.get('ddk', ''), size=11, fill=COL['broken'], style='italic')
    if g.get('immune'):
        for k, part in enumerate(g['immune'].split(' ')):
            text(out, rx, ry + 50 + 13 * k, part, size=11, fill=COL['broken'], style='italic')
    # Late origins fire, from the Sld3 and DDK arms.
    fx, fy, fw, fh = 368, 50, 128, 46
    link(out, ax + aw, ys[0] + ah / 2, fx - 2, fy + 14, s['a-sld3'] if s['a-sld3'] != 'broken' else 'held')
    link(out, ax + aw, ys[1] + ah / 2, fx - 2, fy + fh - 12, s['a-dbf4'] if s['a-dbf4'] != 'broken' else 'held')
    node(out, fx, fy, fw, fh, ['late origins fire', 'and add forks'], s['fire'])
    if s['fire'] == 'broken':
        cross(out, fx + fw - 10, fy + 6, '')
        text(out, fx + fw / 2, fy - 6, g.get('helicase', '') + ': weaker helicase', size=11, fill=COL['broken'], style='italic')
    # Forks fail beside a centromere.
    vx, vy, vw, vh = 368, 160, 128, 46
    lf = s['l-fire']
    link(out, fx + fw / 2, fy + fh, vx + vw / 2, vy - 2, 'held' if lf == 'broken' else lf)
    if lf == 'broken':
        cross(out, fx + fw / 2 + 2, (fy + fh + vy) / 2.0 - 4, '')
        text(out, fx + fw / 2 + 16, (fy + fh + vy) / 2.0 + 2, g.get('ctf19', '') + ': less DDK beside centromeres', size=11,
             fill=COL['broken'], anchor='start', style='italic')
    link(out, ax + aw, ys[2] + ah / 2, vx - 2, vy + 14, s['a-dun1'])
    link(out, ax + aw, ys[3] + ah / 2, vx - 2, vy + vh - 10, s['a-fork'])
    node(out, vx, vy, vw, vh, ['forks fail beside', 'a centromere'], s['fail'])
    # Exo1, the kinetochore, the spindle.
    ex = 530
    link(out, vx + vw, vy + vh / 2, ex - 2, vy + vh / 2, s['exo'] if s['exo'] != 'slow' else 'slow')
    node(out, ex, vy, 112, vh, ['Exo1 resects', 'the centromere'], s['exo'])
    if s['exo'] == 'slow':
        text(out, ex + 56, vy + vh + 14, g.get('exo1', '') + ': slower', size=11, fill=COL['slow'], style='italic')
    kx = 666
    link(out, ex + 112, vy + vh / 2, kx - 2, vy + vh / 2, s['kt'])
    node(out, kx, vy, 106, vh, ['the kinetochore', 'lets go'], s['kt'])
    # The spindle: the end every arm reaches.
    ox, oy, ow, oh = 530, 50, 242, 70
    le = s['l-end']
    link(out, kx + 53, vy - 2, kx + 53, oy + oh + 2, le)
    if g.get('ak') and le != 'held':
        cross(out, kx + 53, (oy + oh + vy) / 2.0, '', COL['slow'])
        text(out, kx + 44, (oy + oh + vy) / 2.0 + 4, g['ak'] + ' stay attached', size=11, fill=COL['slow'], anchor='end', style='italic')
    end_box(out, ox, oy, ow, oh, s['end'])
    if legend:
        lx, ly = 16, 268
        for k, (state, words) in enumerate((('run', 'running'), ('held', 'blocked by Rad53, or without input'),
                                            ('broken', 'removed by an allele'), ('slow', 'slowed by an allele'))):
            x = lx + k * 190
            out.append('<path d="M%d %d H%d" stroke="%s" stroke-width="2.4"%s/>' % (x, ly - 4, x + 22, COL[state],
                       ' stroke-dasharray="5 4"' if state == 'held' else ''))
            text(out, x + 28, ly, words, size=11, anchor='start', fill='#3b3a35')
    h = H + (26 if legend else 0)
    return ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 %d %d" class="tgrnsvg" data-grn="%s">%s</svg>'
            % (W, h, esc(g['name']), ''.join(out)))


HH = 270          # network height in a search panel, room under the Dun1 arm for a note


def draw_hone(step):
    """VIEW: the network with Rad53 on and nothing assumed of excess Stn1: the region where it may first act, outlined (TERMINAL)

    Every step is drawn plain, since the papers do not say which ones excess
    Stn1 changes. The spindle carries the class of the strain the slide tests.
    A header carries the Stn1 glyph, unattached to any step, and the result.
    """
    out = []
    gold, grey = '#a07c10', '#8a877b'
    # The region where excess Stn1 may first act, and the fork arm left open.
    pts = step['outline']
    out.append('<path d="M%s Z" fill="#f2c94c" fill-opacity="0.12" stroke="%s" stroke-width="2.2" stroke-dasharray="8 5" '
               'stroke-linejoin="round"/>' % (' L'.join('%.1f %.1f' % p for p in pts), gold))
    if step.get('open'):
        out.append('<rect x="194" y="147" width="134" height="50" rx="7" fill="none" stroke="%s" stroke-width="1.6" '
                   'stroke-dasharray="2 4" stroke-linecap="round"/>' % grey)
    # Upstream of Rad53: the signal from stalled forks.
    node(out, 6, 2, 140, 36, [], 'plain')
    text(out, 76, 16, 'stalled forks signal', size=12)
    text(out, 76, 31, 'through Mec1 and Mrc1', size=12)
    link(out, 52, 38, 52, 84, 'plain')
    rx, ry = 52, 120
    star(out, rx, ry, True)
    for k, line in enumerate(step.get('rad53note', [])):
        text(out, 46, 172 + 13 * k, line, size=11, fill='#3f8f3f', style='italic')
    # Rad53's four outputs, the Dun1 arm last so the search can drop it alone.
    ax, aw, ah = 200, 122, 40
    rows = {'sld3': 34, 'dbf4': 88, 'fork': 152, 'dun1': 206}
    for arm, words, lines in ARMS:
        y = rows[arm]
        x0, y0, x1, y1 = rx + 30, ry + (y - ry) * 0.25, ax - 4, y + ah / 2
        link(out, x0, y0, x1, y1, 'plain', blunt=True)
        link_label(out, x0, y0, x1, y1, words, below=(arm == 'dun1'))
        node(out, ax, y, aw, ah, lines, 'plain')
    if step.get('ddk'):
        cross(out, ax + aw - 10, rows['dbf4'] + 6, '')
        text(out, ax + aw / 2, 84, step['ddk'], size=11, fill=COL['broken'], style='italic')
    if step.get('dntp'):
        text(out, ax, 264, step['dntp'], size=11, fill='#3f8f3f', style='italic', anchor='start')
    fx, fy, fw, fh = 368, 50, 128, 46
    link(out, ax + aw, rows['sld3'] + ah / 2, fx - 2, fy + 14, 'plain')
    link(out, ax + aw, rows['dbf4'] + ah / 2, fx - 2, fy + fh - 12, 'plain')
    node(out, fx, fy, fw, fh, ['late origins fire', 'and add forks'], 'plain')
    if step.get('helicase'):
        cross(out, fx + fw - 10, fy + 6, '')
        text(out, fx + fw, fy - 6, step['helicase'], size=11, fill=COL['broken'], anchor='end', style='italic')
    vx, vy, vw, vh = 368, 150, 128, 46
    link(out, fx + fw / 2, fy + fh, vx + vw / 2, vy - 2, 'plain')
    link(out, ax + aw, rows['fork'] + ah / 2, vx - 2, vy + 14, 'plain')
    link(out, ax + aw, rows['dun1'] + ah / 2, vx - 2, vy + vh - 10, 'plain')
    node(out, vx, vy, vw, vh, ['forks fail beside', 'a centromere'], 'plain')
    ex, kx = 530, 666
    link(out, vx + vw, vy + vh / 2, ex - 2, vy + vh / 2, 'plain')
    node(out, ex, vy, 112, vh, ['Exo1 resects', 'the centromere'], 'slow' if step.get('slow') else 'plain')
    if step.get('slow'):
        text(out, ex + 56, vy + vh + 14, step['slow'], size=11, fill=COL['slow'], style='italic')
    link(out, ex + 112, vy + vh / 2, kx - 2, vy + vh / 2, 'plain')
    node(out, kx, vy, 106, vh, ['the kinetochore', 'lets go'], 'plain')
    ox, oy, ow, oh = 530, 50, 242, 70
    link(out, kx + 53, vy - 2, kx + 53, oy + oh + 2, 'plain')
    end_box(out, ox, oy, ow, oh, step['end'])
    # The header: excess Stn1, drawn with the viewer's glyph and placed on no step.
    out.append('<g transform="translate(8 -38) scale(2)">%s</g>'
               % mp.cst_glyph({'stn1c': (0.0, 0.0, 14.0, 10.0), 'stn1n': (14.0, 0.0, 28.0, 10.0)}, pieces=('stn1c', 'stn1n')))
    text(out, 76, -21, step['cap'], size=13, anchor='start', fill='#5e4a0c', weight='bold')
    # The key.
    ly = HH + 22
    out.append('<path d="M16 %d H40" stroke="%s" stroke-width="2.2" stroke-dasharray="8 5"/>' % (ly - 4, gold))
    text(out, 46, ly, 'where excess Stn1 may first act', size=11, anchor='start', fill='#3b3a35')
    if step.get('open'):
        out.append('<path d="M232 %d H256" stroke="%s" stroke-width="1.6" stroke-dasharray="2 4" stroke-linecap="round"/>'
                   % (ly - 4, grey))
        text(out, 262, ly, 'open: not tested apart', size=11, anchor='start', fill='#3b3a35')
    out.append('<path d="M448 %d l8 8 M456 %d l-8 8" stroke="%s" stroke-width="2.4" stroke-linecap="round"/>'
               % (ly - 9, ly - 9, COL['broken']))
    text(out, 462, ly, 'removed by an allele', size=11, anchor='start', fill='#3b3a35')
    out.append('<path d="M600 %d H624" stroke="%s" stroke-width="2.4"/>' % (ly - 4, COL['slow']))
    text(out, 630, ly, 'slowed by an allele', size=11, anchor='start', fill='#3b3a35')
    return ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 -46 %d %d" class="tgrnsvg thone" data-grn="%s">%s</svg>'
            % (W, HH + 46 + 30, esc(step['key']), ''.join(out)))


# The same Rad53 network when an end loses its cap, in G2, drawn in the
# usual notation: an arrow promotes, a bar inhibits, a yellow circled P is a
# phosphorylation and a green circled U a ubiquitination. The signal is the
# RPA coat on the resected end, read by the Mec1 gauge of the chromosome
# panel. Mec1 phosphorylates Rad9, which brings in and activates Rad53 and
# Chk1. Rad53's four S-phase outputs are drawn idle, since no forks are left
# in G2. Mitosis runs through two branches. APC-Cdc20 ubiquitinates Pds1,
# which is then degraded; Pds1 inhibits the protease Esp1, and Esp1 cleaves
# the cohesin subunit Scc1, so the sisters separate (Cohen-Fix 1996, Uhlmann
# 1999). Cdc5 drives mitotic exit. Rad53 blocks Pds1 binding to Cdc20 and
# Chk1 phosphorylates Pds1, which blocks its ubiquitination (Agarwal 2003,
# Sanchez 1999); Rad53 also restrains Cdc5 (Sanchez 1999). cdc13 mutants
# that also carry a rad53 mutation fail to arrest (Weinert 1994), so in the
# model the arrest needs Rad53. Adaptation is Cdc5 switching Rad53 off.
CAP_ALLELES = {
    'wt': {},
    'rad53': {'rad53': 'rad53-21'},
}
# The kinds of page a lineage shows, from CHROM_RULE.lineage page states.
CAP_PAGES = ('capped', 'arrested', 'adapted', 'unchecked', 'deadarrest', 'deadloss')
CAP_W, CAP_H = 820, 352


def cap_states(al, page):
    """MODEL: every node and edge of the capping network for one allele at one kind of page (TERMINAL)"""
    a = CAP_ALLELES[al]
    signal = page != 'capped'
    arrest = page in ('arrested', 'deadarrest')
    adapted = page in ('adapted', 'deadloss') and not a.get('rad53')
    s = {'signal': 'run' if signal else 'held', 'gauge': 1.0 if signal else 0.0}
    s['mec1'] = s['rad9'] = s['signal']
    s['rad53'] = 'broken' if a.get('rad53') else ('run' if arrest else 'held')
    s['chk1'] = 'run' if signal and not adapted else 'held'
    # Mitosis: everything runs while the cell divides, and stops in an arrest.
    go = 'held' if arrest else 'run'
    s['apc'] = s['esp1'] = s['exit'] = s['cdc5'] = go
    s['pds1'] = 'run' if arrest else 'held'          # Pds1 inhibiting Esp1
    s['adapt'] = 'run' if adapted else 'held'
    s['end'] = {'capped': 'divides', 'arrested': 'arrest', 'adapted': 'uncapped', 'unchecked': 'uncapped',
                'deadarrest': 'deadarrest', 'deadloss': 'deadloss'}[page]
    return s


def draw_cap(s, a, legend):
    """VIEW: the Rad53 network at an uncapped end in promote and inhibit notation, with its phosphorylations and ubiquitination (TERMINAL)"""
    out = []
    on = lambda k: s[k] == 'run'
    edge = lambda k: 'run' if on(k) else 'held'
    # The signal: RPA on the resected single strand, read by the Mec1 gauge.
    ink = '#1d1d1b' if on('signal') else '#8a877b'
    out.append('<path d="M14 32 H160" stroke="#a8721a" stroke-width="2" fill="none"%s/>'
               % ('' if on('signal') else ' stroke-opacity="0.35"'))
    for k in range(5):
        glyph = mp.wedge(20 + 28 * k, 31, 12, 'rpaglyph', 'RPA' if k == 0 else '')
        out.append(glyph if on('signal') else '<g opacity="0.35">%s</g>' % glyph)
    text(out, 100, 48, 'uncapped end: RPA on the single strand' if on('signal') else 'both ends capped: no RPA signal',
         size=11, fill=ink)
    link(out, 84, 53, 84, 72, edge('signal'))
    text(out, 84, 82, 'Mec1-Ddc2', size=11, fill=ink)
    out.append(mp.meter_h(14, 88, 140, s['gauge'], 'chrsigfill'))
    link(out, 75, 106, 75, 121, edge('rad9'))
    node(out, 40, 122, 70, 26, ['Rad9'], s['rad9'])
    if on('rad9'):
        ptm(out, 110, 122, 'P')
    link(out, 75, 148, 75, 167, edge('rad9') if s['rad53'] != 'broken' else 'held')
    rx, ry = 80, 200
    star(out, rx, ry, on('rad53'))
    if on('rad53'):
        ptm(out, 48, 174, 'P')
    if s['rad53'] == 'broken':
        cross(out, rx + 26, ry - 26, '')
        text(out, 4, 180, a['rad53'], size=11, fill=COL['broken'], style='italic', anchor='start')
    # Rad9 also brings in Chk1.
    out.append('<path d="M40 135 H22 V303 H26" stroke="%s" stroke-width="2" fill="none"%s/>'
               % (COL[edge('chk1')] if on('chk1') else COL['held'], '' if on('chk1') else ' stroke-dasharray="5 4"'))
    link(out, 24, 303, 30, 303, edge('chk1'))
    node(out, 30, 290, 76, 26, ['Chk1'], s['chk1'])
    if on('chk1'):
        ptm(out, 106, 290, 'P')
    # Rad53's S-phase outputs, idle in G2: no forks are left to act on.
    arms = (('Sld3', True), ('Dbf4 (DDK)', True), ('Dun1', False), ('stalled forks', False))
    for k, (name, bar) in enumerate(arms):
        y = 10 + 30 * k
        link(out, rx + 28, ry - 24 + 4 * k, 224, y + 12, 'held', blunt=bar)
        node(out, 226, y, 104, 24, [name], 'held')
    text(out, 340, 52, "Rad53's S-phase outputs:", size=11, anchor='start', fill='#8a877b', style='italic')
    text(out, 340, 66, 'no forks are left in G2', size=11, anchor='start', fill='#8a877b', style='italic')
    # Mitotic exit: Cdc5 drives it, and Rad53 restrains Cdc5.
    link(out, rx + 32, ry - 6, 238, 182, edge('rad53') if on('rad53') else 'held', blunt=True)
    node(out, 240, 168, 80, 28, ['Cdc5'], s['cdc5'])
    link(out, 320, 182, 398, 182, edge('exit'))
    node(out, 400, 168, 120, 28, ['mitotic exit'], s['exit'])
    # Adaptation: Cdc5 switches Rad53 off.
    c = COL['run'] if on('adapt') else COL['held']
    out.append('<path d="M280 168 V152 H128 Q112 152 108 174" stroke="%s" stroke-width="2" fill="none"%s/>'
               % ('#1d1d1b' if on('adapt') else c, '' if on('adapt') else ' stroke-dasharray="5 4"'))
    out.append('<path d="M101 172 L115 176" stroke="%s" stroke-width="2.6"/>' % ('#1d1d1b' if on('adapt') else c))
    text(out, 200, 148, 'adaptation', size=10.5, fill='#3b3a35' if on('adapt') else '#8a877b', style='italic')
    # Anaphase: APC-Cdc20 ubiquitinates Pds1; Pds1 inhibits Esp1; Esp1 cleaves cohesin.
    node(out, 230, 230, 100, 28, ['APC-Cdc20'], s['apc'])
    link(out, rx + 30, ry + 14, 228, 248, edge('rad53') if on('rad53') else 'held', blunt=True)
    text(out, 160, 222, 'Pds1 binding', size=10, fill='#3b3a35', angle=12)
    link(out, 280, 258, 280, 288, edge('apc'))
    text(out, 288, 277, 'ubiquitinates', size=10, anchor='start', fill='#3b3a35')
    node(out, 240, 290, 80, 28, ['Pds1'], 'run' if (on('pds1') or on('apc')) else 'held')
    if on('chk1'):
        ptm(out, 244, 290, 'P')
    if on('apc'):
        ptm(out, 316, 290, 'U')
    link(out, 106, 303, 238, 303, edge('chk1'))
    text(out, 172, 298, 'phosphorylates', size=10, fill='#3b3a35')
    link(out, 320, 304, 398, 304, edge('pds1'), blunt=True)
    node(out, 400, 290, 70, 28, ['Esp1'], s['esp1'])
    link(out, 470, 304, 518, 304, edge('esp1'))
    node(out, 520, 290, 150, 28, ['Scc1 cut: anaphase'], s['esp1'])
    if on('apc'):
        text(out, 280, 336, 'Pds1 is degraded', size=10, fill='#3b3a35', style='italic')
    # The cell.
    ex, ey, ew, eh = 590, 150, 220, 92
    link(out, 520, 182, ex - 2, 190, edge('exit'))
    link(out, 640, 290, 640, ey + eh + 2, edge('esp1'))
    cap_end(out, ex, ey, ew, eh, s['end'])
    if legend:
        lx, ly = 400, 344
        out.append('<path d="M%d %d H%d" stroke="%s" stroke-width="2"/>' % (lx, ly - 4, lx + 18, COL['run']))
        out.append('<path d="M%d %d l-7 -4 v8 z" fill="%s"/>' % (lx + 20, ly - 4, COL['run']))
        text(out, lx + 26, ly, 'promotes', size=11, anchor='start', fill='#3b3a35')
        out.append('<path d="M%d %d H%d M%d %d V%d" stroke="#1d1d1b" stroke-width="2.2"/>'
                   % (lx + 90, ly - 4, lx + 110, lx + 110, ly - 10, ly + 2))
        text(out, lx + 116, ly, 'inhibits', size=11, anchor='start', fill='#3b3a35')
        ptm(out, lx + 176, ly - 10, 'P')
        text(out, lx + 186, ly, 'phosphorylation', size=11, anchor='start', fill='#3b3a35')
        ptm(out, lx + 286, ly - 10, 'U')
        text(out, lx + 296, ly, 'ubiquitination', size=11, anchor='start', fill='#3b3a35')
        out.append('<path d="M%d %d H%d" stroke="%s" stroke-width="2" stroke-dasharray="5 4"/>' % (lx - 140, ly - 4, lx - 118, COL['held']))
        text(out, lx - 112, ly, 'idle or blocked', size=11, anchor='start', fill='#3b3a35')
    return ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 %d %d" class="tgrnsvg tgrncap">%s</svg>'
            % (CAP_W, CAP_H + (8 if legend else 0), ''.join(out)))


def ptm(out, x, y, letter):
    """VIEW: a modification mark centred on (x, y): a yellow circled P for a phosphate, a green circled U for ubiquitin (TERMINAL)"""
    fill, edge = {'P': ('#f2c94c', '#8a6d10'), 'U': ('#8fd18a', '#2f6b2a')}[letter]
    out.append('<circle cx="%.1f" cy="%.1f" r="7" fill="%s" stroke="%s" stroke-width="1.2"/>' % (x, y, fill, edge))
    text(out, x, y + 3.6, letter, size=9.5, weight='bold')


def cap_end(out, x, y, w, h, end):
    """VIEW: what the cell does at this page, the end every branch reaches (TERMINAL)"""
    colour = {'divides': '#3f8f6a', 'arrest': '#c0571f', 'uncapped': '#c48a1c', 'deadarrest': '#7a2a14', 'deadloss': '#7a2a14'}[end]
    fill = {'divides': '#e6f1e3', 'arrest': '#fbe9df', 'uncapped': '#fbf3e2', 'deadarrest': '#f3e0da', 'deadloss': '#f3e0da'}[end]
    words = {'divides': ['the cell divides', 'both ends capped'],
             'arrest': ['G2/M arrest', 'anaphase and mitotic exit wait'],
             'uncapped': ['the cell divides', 'with an end uncapped'],
             'deadarrest': ['death in arrest', 'the cell never divides again'],
             'deadloss': ['death by gene loss', 'the end eroded into a gene']}[end]
    out.append('<rect x="%.1f" y="%.1f" width="%.1f" height="%.1f" rx="6" fill="%s" stroke="%s" stroke-width="1.6"/>'
               % (x, y, w, h, fill, colour))
    text(out, x + w / 2, y + 38, words[0], size=14, fill=colour, weight='bold')
    text(out, x + w / 2, y + 60, words[1], size=12, fill=colour)


# === SHARED FUNCTIONS: the network's pieces, drawn into a list of svg markup ===

COL = {'run': '#3f8f3f', 'held': '#b9b5aa', 'broken': '#b5452a', 'slow': '#c48a1c', 'plain': '#6d6a5f'}


def text(out, x, y, words, size=13, anchor='middle', fill='#1d1d1b', weight='normal', style='normal', angle=0.0):
    """VIEW: one line of network text, turned by angle about its anchor (TERMINAL)"""
    turn = ' transform="rotate(%.1f %.1f %.1f)"' % (angle, x, y) if angle else ''
    out.append('<text x="%.1f" y="%.1f" font-size="%s" text-anchor="%s" fill="%s" font-weight="%s" font-style="%s" '
               'font-family="Georgia, \'Times New Roman\', serif"%s>%s</text>'
               % (x, y, size, anchor, fill, weight, style, turn, esc(words)))


def node(out, x, y, w, h, lines, state):
    """VIEW: one step of the network, its box styled by state (TERMINAL)"""
    stroke = {'run': COL['run'], 'held': '#cfcabd', 'broken': COL['broken'], 'slow': COL['slow'], 'plain': '#8a877b'}[state]
    fill = {'run': '#eef5ec', 'held': '#f7f6f2', 'broken': '#fbeeea', 'slow': '#fbf3e2', 'plain': '#ffffff'}[state]
    out.append('<rect x="%.1f" y="%.1f" width="%.1f" height="%.1f" rx="5" fill="%s" stroke="%s" stroke-width="1.4"%s/>'
               % (x, y, w, h, fill, stroke, '' if state != 'held' else ' stroke-dasharray="4 3"'))
    for k, line in enumerate(lines):
        text(out, x + w / 2, y + h / 2 + 5 - 8 * (len(lines) - 1) + 16 * k, line,
             fill='#1d1d1b' if state != 'held' else '#8a877b')


def link(out, x0, y0, x1, y1, state, blunt=False):
    """VIEW: an arrow, or a blunt bar for Rad53's holds, coloured by state (TERMINAL)"""
    c = COL[state] if state != 'run' or not blunt else '#1d1d1b'
    dash = ' stroke-dasharray="5 4"' if state == 'held' else ''
    out.append('<path d="M%.1f %.1f L%.1f %.1f" stroke="%s" stroke-width="2" fill="none"%s/>' % (x0, y0, x1, y1, c, dash))
    if blunt:
        a = math.atan2(y1 - y0, x1 - x0) + math.pi / 2
        dx, dy = 7 * math.cos(a), 7 * math.sin(a)
        out.append('<path d="M%.1f %.1f L%.1f %.1f" stroke="%s" stroke-width="2.6"/>' % (x1 - dx, y1 - dy, x1 + dx, y1 + dy, c))
    else:
        a = math.atan2(y1 - y0, x1 - x0)
        p = [(x1, y1), (x1 - 9 * math.cos(a) + 4.5 * math.sin(a), y1 - 9 * math.sin(a) - 4.5 * math.cos(a)),
             (x1 - 9 * math.cos(a) - 4.5 * math.sin(a), y1 - 9 * math.sin(a) + 4.5 * math.cos(a))]
        out.append('<path d="M%.1f %.1f L%.1f %.1f L%.1f %.1f Z" fill="%s"/>' % (p[0] + p[1] + p[2] + (c,)))


def link_label(out, x0, y0, x1, y1, words, below=False):
    """VIEW: a link's words, along the link and just above it, or just below it (TERMINAL)"""
    # Set a little past the middle, where the links have spread apart.
    mx, my = x0 + (x1 - x0) * 0.56, y0 + (y1 - y0) * 0.56
    ln = math.hypot(x1 - x0, y1 - y0)
    nx, ny = (y1 - y0) / ln, -(x1 - x0) / ln
    if ny > 0:
        nx, ny = -nx, -ny
    off = -12.0 if below else 4.0
    text(out, mx + nx * off, my + ny * off, words, size=10.5, fill='#3b3a35',
         angle=math.degrees(math.atan2(y1 - y0, x1 - x0)))


def cross(out, x, y, words, colour=None):
    """VIEW: a cross over a removed step, with its allele's name under it (TERMINAL)"""
    c = colour or COL['broken']
    out.append('<path d="M%.1f %.1f l12 12 M%.1f %.1f l-12 12" stroke="%s" stroke-width="3" stroke-linecap="round"/>'
               % (x - 6, y - 6, x + 6, y - 6, c))
    if words:
        text(out, x, y + 20, words, size=11, fill=c, style='italic')


def star(out, rx, ry, on):
    """VIEW: Rad53, a star, bright while it can act (TERMINAL)"""
    pts = []
    for k in range(24):
        r = 34 if k % 2 == 0 else 25
        a = math.pi * 2 * k / 24
        pts.append('%.1f,%.1f' % (rx + r * math.cos(a), ry + r * math.sin(a)))
    out.append('<polygon points="%s" fill="%s" stroke="#7a3a14" stroke-width="1"/>'
               % (' '.join(pts), '#c8622a' if on else '#e6c2ad'))
    text(out, rx, ry + 5, 'Rad53', size=13, weight='bold')


def end_box(out, ox, oy, ow, oh, end):
    """VIEW: the spindle in HU, the end every arm reaches, worded by its class (TERMINAL)"""
    fill = {'extended': '#fbe9df', 'short': '#e6f1e3', 'delayed': '#fbf3e2'}[end]
    stroke = {'extended': '#c0571f', 'short': '#3f8f6a', 'delayed': '#c48a1c'}[end]
    out.append('<rect x="%.1f" y="%.1f" width="%.1f" height="%.1f" rx="6" fill="%s" stroke="%s" stroke-width="1.6"/>'
               % (ox, oy, ow, oh, fill, stroke))
    words = {'extended': ['the spindle extends', 'before the DNA is copied'],
             'short': ['anaphase waits until the DNA', 'is copied: the spindle stays short'],
             'delayed': ['short in small buds;', 'extends later, in large buds']}[end]
    for k, line in enumerate(words):
        text(out, ox + ow / 2, oy + 28 + 18 * k, line, size=13, fill=stroke, weight='bold' if k == 0 else 'normal')
    text(out, ox + ow / 2, oy - 8, 'in HU', size=11, fill='#6d6a5f')


def esc(words):
    """MODEL: text safe inside svg markup (TERMINAL)"""
    return str(words).replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;').replace('"', '&quot;')


if __name__ == '__main__':
    for k, g in GENOTYPES.items():
        st = states(g)
        print('%-9s end=%-8s fire=%-6s fail=%-5s exo=%-5s %s' % (k, st['end'], st['fire'], st['fail'], st['exo'],
                                                           {a: st['a-' + a] for a, _, _ in ARMS}))
