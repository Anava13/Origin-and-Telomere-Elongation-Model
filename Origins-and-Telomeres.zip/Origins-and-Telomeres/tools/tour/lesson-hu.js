/* Lesson: the S-phase checkpoint and the hydroxyurea spindle phenotype.

   Four conditions, each played as its typical run: wild type and rad53-21,
   each without and with hydroxyurea (HU), then the two HU runs side by side.
   The chromosome teaches the replication program; the close-up teaches the
   molecules at one origin, one fork or the centromere. Boxes are panel units
   (880 by 300).

   Every part of the chromosome panel is an abstraction of the model, so the
   lesson introduces each one before it is first shown. features lists the
   panel's parts by the data-feat names tools/make_panels.py gives them; a
   beat introduces some (introduce) and shows only the ones it needs (show).
   tour.js checks that nothing is shown before it is introduced. A beat with a
   figure shows a model-key figure (tools/tour/figures.py) above the panel.

   Wording. A statement about cells carries its citation. A statement about
   the model says so ("in the model", "in this run"), and every minute, count
   and share is the model's. */

(function () {

  // Where things sit on the chromosome panel.
  var X = { L3: 90, L2: 223.3, L1: 406.7, R1: 473.3, R2: 656.7, R3: 746.7, CEN: 440 };
  var meter = function (n) { return [X[n] - 8, 96, 16, 52]; };
  // The telomere view's four ends, and the first and last frame at which a
  // copied end is at a given step of the telomere workflow.
  var TELBOX = { 'tel-L-s1': [3, 90, 271, 70], 'tel-L-s2': [3, 166, 271, 70],
    'tel-R-s1': [606, 90, 271, 70], 'tel-R-s2': [606, 166, 271, 70] };
  // The one-origin chromosome's moments: the frame before the origin fires,
  // and the frame a fork has slid off its tip.
  var FIRE = function (c) { return c.at(c.sched.one.fireAt - 1); };
  var OFF = function (c, side) {
    var f = null;
    c.sched.one.forks.forEach(function (x) { if (x.side === side) { f = x; } });
    return c.first(function (fr) { return fr.clock !== null && fr.clock !== undefined && fr.clock >= f.t1 + 0.4 - 1e-6; });
  };
  var INTO = function (c, side) {
    var f = null;
    c.sched.one.forks.forEach(function (x) { if (x.side === side) { f = x; } });
    return c.at(f.tJ);
  };
  // The chromosome panel zoomed on the right end's two daughters.
  var ENDZOOM = [480, 88, 400, 145];
  var nExt = function (c) {
    var n = 0;
    ['TEL-L', 'TEL-R'].forEach(function (t) { c.sched.telo[t].daughters.forEach(function (d) { if (d.extended) { n += 1; } }); });
    return n;
  };
  var onStep = function (site, key) {
    return function (f) { return !!(f.tel && f.tel[site] && f.tel[site].copied && f.tel[site].key === key); };
  };
  var TS = function (c, site, key) { return c.first(onStep(site, key)); };
  var TE = function (c, site, key) { return c.lastWhere(onStep(site, key)); };
  var dEnd = function (c, site) {
    var out = null;
    ['TEL-L', 'TEL-R'].forEach(function (t) { c.sched.telo[t].daughters.forEach(function (d) { if (d.id === site) { out = d; } }); });
    return out;
  };
  var pct = function (p) { return Math.round(100 * p) + '%'; };
  var origin = function (n) { return [X[n] - 16, 160, 32, 58]; };
  var BOX = {
    ddk: [298, 46, 66, 32], rif: [364, 48, 80, 30], tel: [0, 88, 880, 150], tert: [466, 42, 68, 44], sig: [464, 38, 66, 24], dntp: [464, 64, 66, 18],
    rad53: [536, 40, 34, 32], outputs: [572, 42, 112, 40], sets: [680, 40, 162, 52],
    cen: [424, 138, 32, 62], spindle: [38, 230, 206, 30], dna: [40, 160, 800, 32],
    telL: [40, 160, 40, 30], telR: [800, 160, 40, 30], label: [40, 46, 220, 42], clock: [40, 12, 800, 30],
    outcome: [460, 232, 210, 24]
  };
  var ZOOM = { cen: [360, 120, 160, 100], header: [262, 34, 580, 66], spindleCen: [30, 120, 480, 145] };

  // The panel's parts, as tools/make_panels.py tags them.
  var BASE = ['clock', 'label'];
  var POOLS = ['pools', 'ddk', 'rif', 'sets'];

  // Event times, in model minutes into S, read off a run.
  var cenCopied = function (s) {
    var best = Infinity;
    s.forks.forEach(function (f) {
      var i, a, b;
      for (i = 0; i + 1 < f.path.length; i += 1) {
        a = f.path[i];
        b = f.path[i + 1];
        if ((a[1] - 120) * (b[1] - 120) <= 0 && b[1] !== a[1]) {
          best = Math.min(best, a[0] + (b[0] - a[0]) * (120 - a[1]) / (b[1] - a[1]));
        }
      }
    });
    return best;
  };
  var nearCen = function (s) {
    var best = null;
    (s ? s.collapses : []).forEach(function (c) {
      if (best === null || Math.abs(c.x - 120) < Math.abs(best.x - 120)) { best = c; }
    });
    return best;
  };
  // The first collapse more than 30 kb from the centromere, before the kinetochore
  // is lost, as a fork id, for the beat that sets it beside a collapse at the centromere.
  var farCollapse = function (s) {
    var lost = s.anchors.lostAt === null ? Infinity : s.anchors.lostAt, best = null;
    (s.collapses || []).forEach(function (c) {
      if (c.t <= lost && Math.abs(c.x - 120) > 30 && (best === null || c.t < best.t)) { best = c; }
    });
    return best ? best.fork : 'L3-left';
  };
  // A fork from an early origin that is still moving when Rad53 comes on, for the
  // beats that watch the checkpoint build at one fork.
  var steady = function (s) {
    var ids = ['L1-right', 'R1-left', 'L1-left', 'R1-right', 'L2-right', 'R2-left', 'L2-left', 'R2-right'], i, f, until;
    if (!s) { return null; }
    until = (s.rad53At === null ? 20 : s.rad53At) + 8;
    for (i = 0; i < ids.length; i += 1) {
      f = s.forks.filter(function (q) { return q.id === ids[i]; })[0];
      if (f && f.t1 > until && !(f.downs || []).some(function (d) { return d[0] < until; })) { return f.id; }
    }
    return 'L1-right';
  };
  var g1s = function (ctx, t) { return Math.round(t + ctx.sched.onsetFromG1S); };
  var paused = function (f) { return /paused/.test(f.inset.text['ci-line1'] || ''); };
  // A slide strain's share of extended spindles over its 301 runs, in percent.
  var share = function (key) { return Math.round(100 * ((window.TOUR_PRESETS || {})[key] || { share: 0 }).share); };
  // The frame at a run's scoring time: 90 min after release, earlier for small buds, later for large ones.
  var scored = function (c, when) { return c.at(c.sched.spindle.score[when || 'at'].t); };
  var own = function (when) { return function (sched) { return sched.spindle.score[when || 'at'].t; }; };
  var ALL = ['clock', 'label', 'pools', 'ddk', 'rif', 'sets', 'meters', 'recruit', 'forks', 'rpa', 'mec1', 'dntp',
    'rad53', 'resect', 'kinet', 'spindle', 'outcome'];
  var firstElong = function (c) {
    return c.first(function (f, v) { return v.kind === 'elong'; });
  };

  window.TOUR_LESSON = {
    title: 'The S-phase checkpoint and the HU spindle',
    features: ['clock', 'label', 'pools', 'ddk', 'rif', 'sets', 'meters', 'recruit', 'forks', 'rpa', 'mec1', 'dntp',
      'rad53', 'resect', 'kinet', 'spindle', 'outcome', 'key', 'ui'],
    conditions: {
      wt: { genotype: 'wt', checkpoint: 'wt', hu: false, seed: 1 },
      rad53: { genotype: 'wt', checkpoint: 'rad53', hu: false, seed: 1 },
      wtHU: { genotype: 'wt', checkpoint: 'wt', hu: true, preset: 's2-wt' },
      rad53HU: { genotype: 'wt', checkpoint: 'rad53', hu: true, preset: 's2-rad53' },
      // Each allele alone in an otherwise wild-type cell in HU. Seeds are runs that
      // show the allele's mark; the wild-type drawer replays the same seed.
      sitesA: { genotype: 'wt', checkpoint: 'sites', hu: true, seed: 1 },
      dun1A: { genotype: 'wt', checkpoint: 'wt', hu: true, alleles: { dun1: true }, seed: 1 },
      znA: { genotype: 'wt', checkpoint: 'wt', hu: true, alleles: { dbf4zn: true }, seed: 1 },
      ctf19A: { genotype: 'wt', checkpoint: 'wt', hu: true, alleles: { ctf19: true }, seed: 3 },
      mcmA: { genotype: 'wt', checkpoint: 'wt', hu: true, alleles: { mcm: true }, seed: 1 },
      exo1A: { genotype: 'wt', checkpoint: 'wt', hu: true, alleles: { exo1: true }, seed: 11 },
      akA: { genotype: 'wt', checkpoint: 'wt', hu: true, ak: 'on', seed: 1 },
      // The readout chapter's strains, each playing its slide strain's typical run.
      r53mcm: { genotype: 'wt', preset: 's3-mcm' },
      r53zn: { genotype: 'wt', preset: 's3-zn' },
      sitesHU: { genotype: 'wt', preset: 's4-sites' },
      r53ctf19: { genotype: 'wt', preset: 's5-ctf19' },
      r53exo1: { genotype: 'wt', preset: 's6-exo1' },
      r53ako: { genotype: 'wt', preset: 's5-ako' },
      // mcm5-bob1 dbf4Δ: origins fire without DDK through the bob1 shape.
      bobA: { genotype: 'dbf4', bob1: true, checkpoint: 'wt', hu: true, seed: 6 },
      bobHU: { genotype: 'dbf4', bob1: true, checkpoint: 'wt', hu: true, seed: 2 },
      // Excess Stn1. The model has no Stn1: a stn1-OP cell keeps Rad53 and
      // fires late origins anyway, the two results the papers measured, and
      // the model draws no Stn1 and no route between them. The seeds are runs
      // that show the step each slide follows.
      op: { genotype: 'wt', checkpoint: 'sites', hu: true, seed: 5 },
      opExo1: { genotype: 'wt', checkpoint: 'sites', hu: true, alleles: { exo1: true }, seed: 5 },
      opMcm: { genotype: 'wt', checkpoint: 'sites', hu: true, alleles: { mcm: true }, seed: 5 },
      opZn: { genotype: 'wt', checkpoint: 'sites', hu: true, alleles: { dbf4zn: true }, seed: 5 },
      opBob: { genotype: 'dbf4', bob1: true, checkpoint: 'sites', hu: true, seed: 2 },
      // The telomere chapter. telShort starts both ends at 125 bp; in seed 1
      // telomerase reaches both daughter ends on the right.
      telShort: { genotype: 'wt', checkpoint: 'wt', hu: false, seed: 1, telBp: 125 },
      telCdc13: { genotype: 'wt', checkpoint: 'wt', hu: false, seed: 1, alleles: { cdc13_2: true } }
    },
    labels: {
      wt: 'Wild type, no HU', rad53: 'rad53-21, no HU', wtHU: 'Wild type in HU', rad53HU: 'rad53-21 in HU',
      telShort: 'Wild type, both ends at 125 bp', telCdc13: 'cdc13-2, no HU',
      sitesA: 'dbf4-m25 sld3-38A in HU', dun1A: 'dun1Δ in HU', znA: 'dbf4-zn in HU', ctf19A: 'ctf19Δ in HU',
      mcmA: 'mcm2-1 in HU', exo1A: 'exo1Δ in HU', akA: '4× LATE-AK + ASK1-LacI in HU',
      r53mcm: 'rad53-21 mcm2-1 in HU', r53zn: 'rad53-21 dbf4-zn in HU', sitesHU: 'dbf4-m25 sld3-38A in HU',
      r53ctf19: 'rad53-21 ctf19Δ in HU', r53exo1: 'rad53-21 exo1Δ in HU', r53ako: 'rad53-21 4× LATE-AK + ASK1-LacI in HU',
      bobA: 'mcm5-bob1 dbf4Δ in HU', bobHU: 'mcm5-bob1 dbf4Δ in HU', op: 'stn1-OP in HU',
      opExo1: 'exo1Δ stn1-OP in HU', opMcm: 'mcm2-1 stn1-OP in HU', opZn: 'dbf4-zn stn1-OP in HU',
      opBob: 'mcm5-bob1 dbf4Δ stn1-OP in HU'
    },
    beats: [

      // --- 1. The model and its pools ---------------------------------------
      {
        chapter: '1. The model', title: 'One chromosome with six origins stands for the genome', cond: 'wt',
        from: function (c) { return c.phase('lateG1'); },
        introduce: BASE, show: BASE,
        spot: { boxes: [BOX.dna] },
        text: "The model’s chromosome is 240 kb long and carries six origins (L3 to R3), licensed in G1, a centromere (CEN) in the middle and a telomere at each end. A S. cerevisiae cell carries sixteen chromosomes, from about 230 kb (chromosome I) to about 1.5 Mb (chromosome IV), with several hundred origins in all. The one model chromosome stands for them: its six origins represent three classes, the centromere-flanking origins, the Fkh1/2-bound origins and the late origins near the telomeres.\n\nThe bar along the top is the cell-cycle clock. It counts model minutes, tuned to the timing of the experiments the model follows, and every time quoted for a model run is in these minutes.\""
      },
      {
        chapter: '1. The model', title: 'Origins compete for a few copies of the factors that fire them', cond: 'wt', figure: 'pools',
        from: function (c) { return c.phase('lateG1'); },
        introduce: POOLS, show: BASE.concat(POOLS),
        spot: { boxes: [BOX.label, BOX.ddk, BOX.rif, BOX.sets, BOX.telL, BOX.telR] },
        text: "Origins outnumber several of the factors that fire them. Sld2, Sld3, Dpb11, Dbf4, Sld7 and Cdc45 are present in fewer copies than there are origins: raising all six together makes late origins fire early \\cite{mantiero2011limiting,Tanaka2011Origin}. Rif1 opposes firing by bringing PP1 to licensed origins, where PP1 removes the phosphates that DDK adds. Rif1 bound to Rap1 at telomeres delays the origins near them \\cite{hiraga2014rif1,mattarocci2014rif1}.\n\nThe model keeps these factors in three limited pools, each with a home, the dashed box where idle copies wait: 10 DDK copies, 2 firing-factor sets (Sld3-Sld7, Sld2, Dpb11), and 6 free Rif1-PP1 copies with 2 more bound at each telomere. Copies leave home for origins and return when an origin fires or is copied. Every origin draws on the same few copies, so where the copies go decides which origins fire first."
      },
      {
        chapter: '1. The model', title: 'Each meter counts the DDK phosphates on one double hexamer', cond: 'wt', figure: 'meters',
        from: function (c) { return c.phase('lateG1'); },
        introduce: ['meters', 'recruit'], show: BASE.concat(POOLS, ['meters', 'recruit']),
        spot: { boxes: [meter('L3'), meter('L2'), meter('L1'), meter('R1'), meter('R2'), meter('R3'), BOX.cen] },
        text: "An origin needs DDK before Sld3 can bind it. Licensing loads one Mcm2-7 double hexamer at each origin in G1. DDK (Dbf4-Cdc7) then phosphorylates the Mcm4 and Mcm6 tails of that double hexamer, which creates the sites that Sld3 binds \\cite{deegan2016phosphopeptide}. Rif1-PP1 removes those phosphates. The model counts the phosphorylated sites at each origin as marks on that origin’s DDK-mark meter. The meter’s dashed line sits at 20 marks: at that count the model lets Sld3 bind, and a firing-factor set binds with it.\n\nThe double hexamer under each meter draws the count, gaining one phosphate for every 5 marks: on the left Mcm6 at 5, the right Mcm6 at 10 and the left Mcm4 at 15. At 20 the last phosphate lands on the Mcm4 NSD, which moves off the surface that Sld3 binds. Below 20 the NSD stays seated and blocks Sld3. Rif1-PP1 removes the phosphates in the reverse order.\n\nWhere DDK goes depends on its recruiters. The Ctf19 complex at kinetochores recruits DDK to centromere-flanking origins \\cite{natsume2013kinetochores}, and Fkh1/2 recruit it to the origins they bind \\cite{fang2017dbf4}. The model gives the Ctf19 pair (L1, R1) the largest share of DDK, the Fkh1/2 pair (L2, R2) a smaller one, and L3 and R3 a baseline share opposed by Rif1-PP1 from their telomeres. The pool sizes, the threshold, the order of the four phosphates and these shares are all model parameters.\n\nBelow the key turn the cryo-EM structures of the Mcm2-7 double hexamer on DNA \\cite{noguchi2017cryo} and of DDK docked on it \\cite{saleh2022structural}, each subunit in the colour the glyph gives it."
      },

      {
        chapter: '1. The model', title: 'Each telomere holds Rif1 away from the origins, and copying an end doubles its hold', cond: 'wt',
        view: 'tel', telSite: 'tel-R-s1',
        from: FIRE,
        to: function (c) { return Math.max(FIRE(c), OFF(c, 'L')); },
        show: BASE.concat(POOLS, ['meters', 'recruit']),
        spot: { boxes: [BOX.rif, BOX.tel, BOX.label] },
        text: "Each end of the chromosome is a telomere, about 325 bp of TG1-3 repeat \\cite{ray1999yeast}. Rap1 binds the duplex repeat about once every 19 bp \\cite{ray1999yeast}. Rif1 binds the Rap1 C-terminus \\cite{hardy1992rap1,shi2013rif1}. Rif1 held at telomeres delays the late origins near them \\cite{mattarocci2014rif1}. Releasing Rif1 from telomeres raises its binding at internal origins and delays those origins \\cite{hafner2018rif1}. Telomeres hold Rif1 away from the rest of the genome.\n\nThe telomere view sets the origin program aside. It draws a hypothetical chromosome with one origin, its two ends drawn to length and its interior at a smaller scale. A wild-type end holds 17 Rap1 sites and, in the model, 2 Rif1-PP1 copies. The model cell has 10 copies: the ends hold 4 and the origins share the other 6. A fork that copies an end makes two daughter ends, one on each sister, and each daughter holds its own 2 copies. The two forks reach the two ends together, so the free pool falls from 6 to 2 at once. Ends and origins draw on one Rif1 pool, so the length and number of ends set how much Rif1 the origins get."
      },

      // --- 2. Wild type, unperturbed --------------------------------------
      {
        chapter: '2. Wild type, unperturbed S phase', title: 'DDK goes where it is recruited', cond: 'wt',
        from: function (c) { return c.phase('lateG1'); }, to: function (c) { return c.at(0); },
        show: BASE.concat(POOLS, ['meters', 'recruit']),
        spot: { boxes: [BOX.ddk, BOX.rif, meter('L3'), meter('L2'), meter('L1'), meter('R1'), meter('R2'), meter('R3')] },
        ask: {
          q: "In this model, which pair of origins reaches its DDK-mark meter’s dashed line first?",
          options: ["L1 and R1: the Ctf19 complex recruits the largest share of DDK to them",
            "L2 and R2: Fkh1/2 recruit DDK to them and keep telomeric Rif1-PP1 away",
            "L3 and R3: the telomeres hold Rif1-PP1 there, which frees more DDK for them"],
          answer: 0,
          explain: "The Ctf19 pair receives the most DDK copies at G1/S, so its marks rise fastest. With no recruiter, L3 and R3 also lose marks to Rif1-PP1 from their telomeres."
        },
        text: "At G1/S the model deals DDK and Rif1-PP1 copies from their homes to the open origins. Each DDK copy adds marks to its origin while each Rif1-PP1 copy removes a share of them, so the DDK-mark meters fill at different rates."
      },
      {
        chapter: '2. Wild type, unperturbed S phase', title: 'L1 fires once Sld3, GINS and Cdc45 assemble on its double hexamer', cond: 'wt', layout: 'close',
        origin: function () { return 'L1'; }, follow: function () { return 'right'; },
        from: function (c) { return c.first(function (f, v) { return v.kind === 'step'; }); },
        to: function (c) { return firstElong(c); },
        steps: 40, interval: 500, cruise: true,
        introduce: ['forks'], show: BASE.concat(POOLS, ['meters', 'recruit']),
        text: "Model time stops while the close-up plays steps 7 to 11 at L1. Sld3-Sld7 seats on the marked double hexamer, S-CDK phosphorylates Sld2 and Sld3, Dpb11 delivers GINS, Cdc45 seats, Mcm10 arrives and the origin melts. Two replisomes then leave in opposite directions; the close-up follows the right-hand fork.\n\nAt that fork the CMG helicase unwinds the parental DNA ahead of three polymerases: Pol ε copies the leading strand, while Pol α and Pol δ make the lagging strand in Okazaki fragments. Nucleosomes come off the parental DNA as the fork reaches them. On the chromosome panel each moving fork is drawn as a small CMG riding the DNA."
      },
      {
        chapter: '2. Wild type, unperturbed S phase', title: 'Forks copy R3 before it can fire', cond: 'wt', layout: 'both',
        origin: function () { return 'R3'; }, follow: function () { return 'origin'; },
        from: function (c) { return c.at(0); },
        to: function (c) { return c.lastWhere(function (f) { return /copied passively/.test(f.inset.text['ci-line1'] || ''); }) + 2; },
        show: BASE.concat(POOLS, ['meters', 'recruit', 'forks']),
        spot: { boxes: [meter('R3'), meter('L3')], ids: ['fx-chrfork-R2-right', 'fx-chrfork-L2-left'] },
        ask: {
          q: "A fork from R2 runs through R3’s licensed double hexamer before R3 fires. What becomes of R3 for the rest of S phase?",
          options: ["It fires later, once its DDK-mark meter reaches the line and a firing-factor set is free",
            "It is copied passively: the fork removes its double hexamer, which cannot be reloaded before G1",
            "It fires at once, because the passing fork brings the helicase activators it lacked"],
          answer: 1,
          explain: "Licensing happens only in G1, so an origin whose double hexamer a passing fork has removed cannot fire until the next cell cycle. The model then returns R3’s DDK copies home and deals them to the origins still open."
        },
        text: function (c) {
          return 'In this run the Ctf19 pair fires first, followed by the Fkh1/2 pair ' + c.fmt(c.sched.origins.L2.time) + ' model minutes into S. Each origin that fires or is copied sends its DDK copies home, from where the model deals them to the origins left. The fork from R2 copies R3 at ' + c.fmt(c.sched.origins.R3.time) + ' min, and L3 fires at ' + c.fmt(c.sched.origins.L3.time) + ' min.';
        }
      },
      {
        chapter: '2. Wild type, unperturbed S phase', title: 'Converging forks finish the stretch between L1 and R1', cond: 'wt', layout: 'both',
        origin: function () { return 'L1'; }, follow: function () { return 'right'; },
        from: function (c) { return c.first(function (f, v) { return v.kind === 'term'; }); },
        to: function (c) { return c.lastWhere(function (f, v) { return v.kind === 'term' && paused(f); }); },
        interval: 900,
        show: BASE.concat(['meters', 'forks']),
        spot: { boxes: [[X.L1 - 10, 150, X.R1 - X.L1 + 20, 40]] },
        text: "L1’s right fork meets R1’s left fork over the centromere. As the two forks close the gap, their CMGs pass each other onto double-stranded DNA, as they do in Xenopus egg extracts \\cite{dewar2015}. SCF-Dia2 then ubiquitylates Mcm7, which marks each CMG for extraction by Cdc48 \\cite{maric2014cdc48}, leaving the stretch between the two origins copied."
      },
      {
        chapter: '2. Wild type, unperturbed S phase', title: 'The copied centromere attaches to both poles', cond: 'wt',
        layout: 'both', follow: function () { return 'cen'; },
        zoom: ZOOM.cen,
        from: function (c) { return c.at(Math.max(0, cenCopied(c.sched) - 3)); },
        to: function (c) { return c.at(cenCopied(c.sched) + 3); },
        introduce: ['kinet'], show: BASE.concat(['forks', 'kinet', 'recruit']),
        spot: { boxes: [BOX.cen, [X.CEN - 8, 182, 16, 30]] },
        text: function (c) {
          return 'At molecular scale, the kinetochore sits on a Cse4 nucleosome at the CDE elements and is built outward from it: the Ctf19 complex, MIND, the Ndc80 rods and the Dam1 ring around the microtubule tip. Before a fork arrives, the one kinetochore is attached to one microtubule. On the chromosome panel that kinetochore is the small grey block on the CEN, with its microtubule the green line running out of frame to its pole.\n\nIn this run, forks from L1 and R1 meet over the centromere ' + c.fmt(cenCopied(c.sched)) + ' model minutes into S. Cohesin keeps the two sisters together while each sister assembles a kinetochore. The lower kinetochore then takes a microtubule from the other pole.';
        }
      },
      {
        chapter: '2. Wild type, unperturbed S phase', title: 'The spindle stays short until cohesin is cleaved', cond: 'wt', figure: 'spindle',
        from: function (c) { return c.phase('G2'); },
        introduce: ['spindle'], show: BASE.concat(['kinet', 'spindle']),
        spot: { boxes: [BOX.spindle, BOX.cen] },
        text: "Two spindle pole bodies and the microtubules between them make up the spindle. Kinetochore microtubules attach each sister kinetochore to one pole, and interpolar microtubules from the two poles overlap in the middle. Cohesed sisters attached to opposite poles resist the outward push of the interpolar microtubules, which keeps the metaphase spindle short, about 1.5 to 2 µm. At anaphase separase cleaves cohesin, freeing the interpolar microtubules to slide apart and extend the spindle. In HU wild-type spindles stay short, whereas rad53 mutants extend their spindles with their chromosomes partly copied \\cite{krishnan2004dna,bachant2005yeast}.\n\nThe chromosome panel draws the spindle to scale as a gauge in its lower left corner, a pole body at each end with three microtubules between them. Its dashed tick marks 3 µm, the model’s cutoff between a short spindle and an extended one."
      },
      {
        chapter: '2. Wild type, unperturbed S phase', title: 'Anaphase follows once the chromosome is copied', cond: 'wt',
        layout: 'both', follow: function () { return 'cen'; },
        // G2 is sampled for the telomere view; this slide starts on its last frame.
        from: function (c) { return Math.max(c.phase('G2'), c.phase('A1') - 1); }, to: function (c) { return c.last; }, interval: 1100,
        introduce: ['outcome'], show: BASE.concat(['kinet', 'spindle', 'outcome']),
        spot: { boxes: [BOX.spindle, BOX.dna, BOX.cen, BOX.outcome] },
        text: "Once every stretch is copied, the cell leaves S. In G2 cohesin keeps the two sisters together until anaphase, when separase cleaves it and the sisters part toward the two poles, centromere first with the arms trailing, while the spindle gauge extends to the model’s 9 µm. The line at the lower right summarizes the run: when the chromosome was copied in full, and the order in which its origins fired."
      },

      // --- 3. rad53-21, unperturbed ---------------------------------------
      {
        chapter: '3. rad53-21, unperturbed S phase', title: 'Without stalled forks, the checkpoint is idle', cond: 'rad53',
        from: function (c) { return c.at(0); }, to: function (c) { return c.last; }, steps: 30,
        show: BASE.concat(POOLS, ['meters', 'recruit', 'forks', 'kinet', 'spindle', 'outcome']),
        spot: { boxes: [BOX.spindle, BOX.outcome] },
        ask: {
          q: "rad53-21 carries a defective Rad53, the effector kinase of the S-phase checkpoint. Without HU, does it extend its spindle before S ends?",
          options: ["Yes: Rad53 restrains the spindle in every S phase, and this mutant lacks that restraint",
            "No: its forks rarely stall without stress, so it copies and divides on time, as wild type does",
            "Yes, after a delay: its forks run short of firing-factor sets, and S phase stalls"],
          answer: 1,
          explain: "The checkpoint responds to single-stranded DNA at stalled forks (chapter 4), which unperturbed forks rarely leave. The model gives rad53-21 no Rad53 activity, so without HU it runs as wild type does."
        },
        text: "In this run rad53-21 fires the same origins in the same order as wild type, copies the chromosome, and enters anaphase on time. Its spindle extends early only when its forks stall, as they do in HU."
      },

      // --- 4. Wild type in HU ----------------------------------------------
      {
        chapter: '4. Wild type in hydroxyurea', title: 'HU slows the forks by lowering dNTPs', cond: 'wtHU', layout: 'both',
        origin: function (c) { return (steady(c.sched) || 'L1-right').split('-')[0]; },
        follow: function (c) { return (steady(c.sched) || 'L1-right').split('-')[1]; },
        from: function (c) { return firstElong(c); },
        to: function (c) { return c.first(function (f, v) { return v.kind === 'elong' && v.bare >= 2; }); },
        interval: 900,
        introduce: ['dntp', 'rpa'], show: BASE.concat(POOLS, ['meters', 'recruit', 'forks', 'rpa', 'dntp']),
        spot: { boxes: [BOX.dntp], ids: ['fx-chrfork-L1-right', 'fx-chrfork-R1-left'] },
        text: "Hydroxyurea inhibits ribonucleotide reductase (RNR), the enzyme that makes dNTPs, so the dNTP pool falls \\cite{poli2012dntp}. The new gauge in the header is the model’s dNTP pool, which every fork draws on. In HU the model sets that pool to a tenth of normal and slows its forks to match.\n\nIn the close-up the dNTP streams thin and the polymerases fall behind the helicase, leaving the template it unwinds ahead of them single-stranded and coated by RPA. On the chromosome panel, RPA appears as small wedges behind each fork."
      },
      {
        chapter: '4. Wild type in hydroxyurea', title: 'One gauge sums the RPA signal from every stalled fork', cond: 'wtHU', figure: 'mec1',
        from: function (c) { return c.at(Math.max(0, c.sched.rad53At - 12)); },
        to: function (c) { return c.at(c.sched.rad53At) - 1; },
        introduce: ['mec1'], show: BASE.concat(POOLS, ['meters', 'recruit', 'forks', 'rpa', 'dntp', 'mec1']),
        spot: { boxes: [BOX.sig] },
        text: "RPA-coated single-stranded DNA signals a stalled fork. Ddc2 binds the RPA coat and brings Mec1 \\cite{zou2003sensing}, which acts through Mrc1 at the fork to activate Rad53 \\cite{alcasabas2001mrc1}.\n\nThe model sums this signal over every fork in one gauge, labelled Mec1-Ddc2, Mrc1. As the gauge fills, an RPA token flies to it from each stalled fork. The gauge’s dashed line marks the signal at which the model switches Rad53 on."
      },
      {
        chapter: '4. Wild type in hydroxyurea', title: 'RPA builds a signal for Rad53', cond: 'wtHU', layout: 'both',
        origin: function (c) { return (steady(c.sched) || 'L1-right').split('-')[0]; },
        follow: function (c) { return (steady(c.sched) || 'L1-right').split('-')[1]; },
        from: function (c) { return c.first(function (f, v) { return v.kind === 'elong' && v.bare >= 2; }); },
        to: function (c) { return c.first(function (f, v) { return v.kind === 'elong' && v.active; }) + 8; },
        interval: 1100, cruise: true,
        show: BASE.concat(POOLS, ['meters', 'recruit', 'forks', 'rpa', 'dntp', 'mec1']),
        spot: { boxes: [BOX.sig], ids: ['fx-chrfork-L1-right', 'fx-chrfork-R1-left'] },
        ask: {
          q: "In this wild-type cell in HU, what switches Rad53 on?",
          options: ["DDK marks on the late origins, once their meters reach the dashed line in HU",
            "RPA-coated single strands at stalled forks, read by Mec1-Ddc2 and passed on through Mrc1",
            "The short metaphase spindle, sensed through the tension across the sister kinetochores"],
          answer: 1,
          explain: "Ddc2 binds the RPA coat and brings Mec1, which phosphorylates Mrc1 in the replisome. Rad53 docks on phosphorylated Mrc1, where Mec1 and then Rad53 itself phosphorylate it \\cite{alcasabas2001mrc1,santocanale1998mec1}. The model’s Mec1 gauge sums the RPA over all stalled forks."
        },
        text: "At first the helicase runs ahead of the stalled polymerases, so in the close-up the fork moves without making new DNA and each step leaves more RPA-coated template behind it. On the chromosome, RPA tokens fly from the forks to the gauge. Once the gauge reaches its line, Rad53 docks on Mrc1, is activated, and slows unwinding by the helicase to the pace of the polymerases, as purified Rad53 does in reconstituted replication \\cite{devbhandari2020rad53}. The fork then moves slowly, copying as it goes, and the single-stranded stretch stops growing."
      },
      {
        chapter: '4. Wild type in hydroxyurea', title: 'Rad53 phosphorylation keeps firing factors and DDK at home', cond: 'wtHU',
        figure: 'rad53', zoom: ZOOM.header,
        from: function (c) { return c.at(c.sched.rad53At) - 1; }, to: function (c) { return c.at(c.sched.rad53At) + 2; },
        interval: 1200,
        introduce: ['rad53'], show: BASE.concat(POOLS, ['meters', 'recruit', 'forks', 'rpa', 'dntp', 'mec1', 'rad53']),
        spot: { boxes: [BOX.rad53, BOX.outputs, BOX.sets, BOX.ddk, BOX.dntp] },
        text: function (c) {
          return 'In this run Rad53 comes on ' + c.fmt(c.sched.rad53At) + ' model minutes into S. Rad53 phosphorylates Sld3 and Dbf4, which blocks late origins from firing \\cite{zegerman2010checkpoint,lopez2010damage}. Rad53 also raises dNTP supply through Dun1 \\cite{zhao2002dun1} and keeps stalled forks able to restart \\cite{lopes2001dna}.\n\nThe model draws each Rad53 phosphorylation as a gold star. A phosphorylated copy stays home, and the outline of that home turns from dashed to solid: with the firing-factor sets at home no origin can fire, and with DDK at home the marks on waiting origins fade.\n\nRad53 also phosphorylates Exo1 under replication stress \\cite{chappidi2019replication}, a modification proposed to restrain it \\cite{morin2008checkpoint}. Deleting EXO1 largely suppresses fork breakdown in rad53 cells \\cite{segurado2008separate}, as that restraint predicts. The model omits this target: a wild-type fork that collapses is resected like any other, which is the model’s only route to the few wild-type cells that extend their spindles.';
        }
      },
      {
        chapter: '4. Wild type in hydroxyurea', title: 'Late origins wait while Rad53 is on, and the spindle stays short', cond: 'wtHU',
        from: function (c) { return c.at(c.sched.rad53At); }, to: function (c) { return c.at(c.sched.spindle.score.at.t); },
        show: BASE.concat(POOLS, ['meters', 'recruit', 'forks', 'rpa', 'dntp', 'mec1', 'rad53', 'kinet', 'spindle']),
        spot: { boxes: [meter('L3'), meter('R3'), BOX.spindle, BOX.cen] },
        ask: {
          q: "This wild-type cell in HU has Rad53 on, and L3 and R3 are licensed but unfired. Will they fire while Rad53 stays on?",
          options: ["Yes: once DDK has phosphorylated their MCM, Sld3 binds and a firing-factor set follows",
            "No: phosphorylated Sld3 keeps the sets home, and phosphorylated Dbf4 lets their DDK marks fade",
            "Yes, slowly: the dNTPs that Dun1 raises let the late origins fire one at a time"],
          answer: 1,
          explain: "Rad53-phosphorylated Sld3 cannot bind Dpb11, and Rad53-phosphorylated Dbf4 inhibits DDK \\cite{zegerman2010checkpoint,lopez2010damage}. The model keeps both blocks in place for as long as Rad53 stays on, so the late origins wait until a fork copies them."
        },
        text: "In this run the spindle forms 30 model minutes after G1/S and stays at 1.5 µm while the CEN kinetochore remains attached to its microtubule. The spindle is still short at 90 minutes after release from G1, a time at which spindles are scored in HU \\cite{Gasparayan2009yeast,julius2019inhibition}.\""
      },
      {
        chapter: '4. Wild type in hydroxyurea', title: 'S finishes slowly, then anaphase', cond: 'wtHU',
        from: function (c) { return c.at(c.sched.spindle.score.at.t); }, to: function (c) { return c.last; }, steps: 30,
        show: BASE.concat(POOLS, ['meters', 'recruit', 'forks', 'rpa', 'dntp', 'mec1', 'rad53', 'kinet', 'spindle', 'outcome']),
        spot: { boxes: [BOX.spindle, BOX.dna] },
        text: function (c) {
          return 'Forks protected by Rad53 copy the rest of the chromosome slowly, while the late origins are copied passively. In the model a fork that collapses with Rad53 on restarts after a delay. In this run the chromosome is copied in full ' + g1s(c, c.sched.sEnd) + ' model minutes after G1/S, and only then do the sisters part.';
        }
      },

      // --- 5. rad53-21 in HU -----------------------------------------------
      {
        chapter: '5. rad53-21 in hydroxyurea', title: 'No Rad53: late origins fire', cond: 'rad53HU', layout: 'both',
        origin: function () { return 'R3'; }, follow: function () { return 'origin'; },
        from: function (c) { return c.at(Math.max(0, (c.sched.origins.R3.time || 0) - 6)); },
        to: function (c) { return c.lastWhere(function (f, v) { return v.kind === 'step'; }) + 2; },
        show: BASE.concat(POOLS, ['meters', 'recruit', 'forks', 'rpa', 'dntp', 'mec1', 'rad53']),
        spot: { boxes: [meter('R3'), origin('R3'), meter('L3'), BOX.rad53, BOX.sig] },
        ask: {
          q: "With no Rad53 to receive the signal, what happens to L3 and R3?",
          options: ["They wait, as in wild type: the full Mec1 gauge keeps the sets home by itself",
            "They fire: Sld3 and Dbf4 stay unmarked, so DDK keeps marking them until a set binds",
            "They are copied passively: the slow forks reach them before their meters can fill"],
          answer: 1,
          explain: "The Mec1 gauge fills, but with no Rad53 to activate, Sld3 and Dbf4 stay unphosphorylated and DDK keeps marking the late origins."
        },
        text: "The same RPA signal fills the gauge. With no Rad53 to receive it, the homes stay dashed. The close-up follows R3 as it fires, molecule by molecule: R3 fires late in this run because Rad53 is missing, whereas in the wild-type run R3 stayed unfired until a fork copied it. More forks now draw on a dNTP pool that Dun1 never raises."
      },
      {
        chapter: '5. rad53-21 in hydroxyurea', title: 'More forks, one pool: forks collapse', cond: 'rad53HU', layout: 'both',
        origin: function (c) { var k = c.sched && nearCen(c.sched); return k ? k.fork.split('-')[0] : 'L1'; },
        follow: function (c) { var k = c.sched && nearCen(c.sched); return k ? k.fork.split('-')[1] : 'right'; },
        from: function (c) { var k = nearCen(c.sched); return c.at(k.t - 6); },
        to: function (c) { var k = nearCen(c.sched); return c.at(k.t) + 8; },
        interval: 1000, cruise: true,
        show: BASE.concat(POOLS, ['meters', 'recruit', 'forks', 'rpa', 'dntp', 'mec1', 'rad53']),
        spot: { ids: ['fx-chrfork-' + 'L1-right', 'fx-chrfork-R1-left'], boxes: [[X.L1 - 10, 150, X.R1 - X.L1 + 20, 40]] },
        text: function (c) {
          var k = nearCen(c.sched);
          return 'A fork collapses when it loses the ability to resume synthesis, although its replisome stays on the DNA in rad53 cells in HU \\cite{depiccoli2012replisome}. Without Rad53 the helicase no longer slows to the pace of the stalled polymerases \\cite{devbhandari2020rad53}: in the close-up it runs on, unwinding without synthesis, stripping nucleosomes ahead of it and leaving RPA-coated template behind, while the stalled new strands fall out of frame. Collapsed forks reverse \\cite{sogo2002fork}, and Exo1 resects their new strands \\cite{cotta2005exo1}.\n\nThe model stands in for these steps with one rule: every moving fork collapses at a rate that rises steeply with the number of forks sharing the dNTP pool. The fork followed here, from ' + k.fork.split('-')[0] + ', collapses ' + c.fmt(k.t) + ' model minutes into S, ' + Math.abs(k.x - 120).toFixed(1) + ' kb from the centromere.';
        }
      },
      {
        chapter: '5. rad53-21 in hydroxyurea', title: 'Single-stranded DNA spreads both ways from a collapsed fork', cond: 'rad53HU', figure: 'resect',
        zoom: ZOOM.cen,
        from: function (c) { var k = nearCen(c.sched); return c.at(k.t); },
        to: function (c) { var k = nearCen(c.sched); return c.at(k.t) + 4; },
        introduce: ['resect'], show: BASE.concat(['meters', 'forks', 'rpa', 'resect', 'kinet']),
        spot: { boxes: [[X.L1 - 30, 150, X.R1 - X.L1 + 60, 40]] },
        text: "At a collapsed fork single-stranded DNA spreads both ways: ahead of the stalled ends the runaway helicase leaves unwound template coated by RPA, while behind them Exo1 resects the new strands, leaving each sister’s parental strand single.\n\nThe chromosome panel draws this stretch in orange, with a glyph at each front. The model spreads it both ways from the collapse at 0.95 kb per minute and stops it 6.6 kb away, both values model parameters."
      },
      {
        chapter: '5. rad53-21 in hydroxyurea', title: 'Single strands reach the centromere', cond: 'rad53HU', zoom: ZOOM.cen,
        layout: 'both', follow: function () { return 'cen'; },
        from: function (c) { var k = nearCen(c.sched); return c.at(k.t); },
        to: function (c) { return c.at(c.sched.anchors.lostAt) + 2; },
        interval: 900,
        show: BASE.concat(['meters', 'forks', 'rpa', 'resect', 'kinet']),
        spot: { boxes: [BOX.cen, [X.L1, 165, X.R1 - X.L1, 22]] },
        ask: {
          q: "In the model, the single-stranded stretch reaches the centromeric DNA. What does the kinetochore built there do?",
          options: ["It stays: cohesin and the Ctf19 complex keep it seated on the single strand",
            "It lets go: its Cse4 nucleosome comes off the single strand",
            "It moves: it slides along the strand to the nearest copied stretch"],
          answer: 1,
          explain: "Julius and colleagues proposed that fork collapse beside a centromere in rad53 cells in HU exposes centromeric DNA to Exo1, which disrupts the kinetochore \\cite{julius2019inhibition}. The model releases the kinetochore when the single-stranded stretch reaches the CEN."
        },
        text: function (c) {
          return 'In the close-up the polymerases have stopped at the stalled ends while the helicase runs on toward the centromere, stripping nucleosomes ahead of it. RPA coats both unwound strands, and behind the stalled ends Exo1 resects the new strands. In this run the stretch reaches the CEN ' + c.fmt(c.sched.anchors.lostAt) + ' model minutes into S. In the model the Cse4 nucleosome comes off single-stranded DNA, so the kinetochore built on it lets go of its microtubule. This loss of the kinetochore follows a proposal by Julius and colleagues \\cite{julius2019inhibition}.';
        }
      },
      {
        chapter: '5. rad53-21 in hydroxyurea', title: 'The spindle extends with the chromosome partly copied', cond: 'rad53HU',
        zoom: ZOOM.spindleCen,
        from: function (c) { return c.at(c.sched.anchors.lostAt); }, to: function (c) { return c.last; },
        show: BASE.concat(['meters', 'forks', 'rpa', 'resect', 'kinet', 'spindle', 'outcome']),
        spot: { boxes: [BOX.spindle, BOX.cen] },
        text: function (c) {
          return 'With no kinetochore attached at the centromere, the spindle gauge extends past 3 µm ' + g1s(c, c.sched.extStart) + ' model minutes after G1/S, in cycles of extension and breakage. Pds1 is still stable, so cohesin keeps the sisters together \\cite{bachant2005yeast,julius2019inhibition}. The run ends here, with the spindle extended and the chromosome partly copied.';
        }
      },

      // --- 6. Side by side ------------------------------------------------
      {
        chapter: '6. Side by side', title: 'At the same minute in HU, wild type keeps a short spindle and rad53-21 has extended its own', cond: 'rad53HU', layout: 'compare',
        from: function (c) { return c.at(c.sched.extStart + 8); },
        compare: { cond: 'wtHU', at: function (c) { return c.sched.extStart + 8; } },
        show: BASE.concat(POOLS, ['meters', 'forks', 'rpa', 'dntp', 'mec1', 'rad53', 'resect', 'kinet', 'spindle']),
        spot: { boxes: [BOX.spindle, BOX.cen, meter('L3'), meter('R3'), BOX.rad53] },
        text: function (c) {
          return 'Both cells are in HU, ' + g1s(c, c.sched.extStart + 8) + ' model minutes after G1/S, with each clock scaled to its own run so that the two playheads sit at different places. Wild type keeps a short spindle: Rad53 is on, its homes are solid, the late origins wait and the CEN kinetochore stays attached to its microtubule. rad53-21 has fired its late origins and lost forks beside the centromere, so its kinetochore has let go and its spindle is extended.';
        }
      },
      {
        chapter: '6. Side by side', title: 'Wild type finishes S phase in HU, whereas rad53-21 never reaches anaphase', cond: 'rad53HU', layout: 'compare',
        from: function (c) { return c.last; },
        compare: { cond: 'wtHU', at: function () { return Infinity; } },
        show: BASE.concat(['meters', 'forks', 'resect', 'kinet', 'spindle', 'outcome']),
        spot: { boxes: [BOX.spindle, BOX.dna] },
        text: "Wild type copies the whole chromosome in HU, then parts the sisters on the model’s 9 µm anaphase spindle, whereas rad53-21 extends its spindle with the chromosome partly copied and never reaches anaphase. In this model, spindle extension in HU marks a cell whose centromere was exposed by a fork that Rad53 would have protected."
      }
,

      // --- 7. The alleles, one at a time ---------------------------------
      {
        chapter: "7. The alleles, one at a time", title: "dbf4-m25 sld3-38A: late origins fire while Rad53 is on", cond: "sitesA", layout: "mol",
        origin: function (c) { return c.sched && c.sched.origins.R3.fate === 'fired' ? 'R3' : 'L3'; }, follow: function () { return 'origin'; },
        from: function (c) { return c.at(c.sched.rad53At); }, to: function (c) { return c.lastWhere(function (f, v) { return v.kind === 'step'; }) + 2; },
        compare: { cond: 'wtHU', sameSeed: true, drawer: true, follow: true, view: "close", at: function () { return 0; } },
        show: ALL, spot: null,
        ask: {
          q: "When Rad53 comes on in dbf4-m25 sld3-38A cells in HU, what happens at the late origin R3?",
          options: ["Its DDK-mark meter keeps filling until a firing-factor set lands, and it fires",
            "Its firing-factor set is held at home, as in wild type, so it waits",
            "Its DDK copies are sent home, so its marks fade before it can fire"],
          answer: 0,
          explain: "Rad53 cannot phosphorylate these forms of Sld3 and Dbf4, so neither block forms \\cite{zegerman2010checkpoint}. In the model, a firing-factor set leaves home for R3 while Rad53 is on."
        },
        text: "The Rad53 sites on Dbf4 and Sld3 are replaced in dbf4-m25 sld3-38A cells, which lets late origins fire while Rad53 is active \\cite{zegerman2010checkpoint,julius2019inhibition}.\n\nThe model keeps Rad53 and its other two outputs, fork protection and the Dun1 output, and removes its blocks on Sld3 and Dbf4. The close-up follows the late origin R3: once its DDK-mark meter reaches the line, a firing-factor set lands and R3 fires while Rad53 is on. In the wild-type cell on the left, R3 waits at the same minute, with the phosphorylated firing-factor sets and DDK at home."
      },
      {
        chapter: "7. The alleles, one at a time", title: "dun1Δ: dNTPs stay low after Rad53 comes on", cond: "dun1A", layout: "mol",
        origin: function (c) { return (steady(c.sched) || 'L1-right').split('-')[0]; },
        follow: function (c) { return (steady(c.sched) || 'L1-right').split('-')[1]; },
        from: function (c) { return c.at(c.sched.rad53At) - 3; }, to: function (c) { return c.at(c.sched.rad53At) + 10; },
        compare: { cond: 'wtHU', sameSeed: true, drawer: true, follow: true, view: "close", at: function () { return 0; } },
        show: ALL, spot: null,
        ask: {
          q: "Rad53 comes on in dun1Δ cells in HU. What happens to the dNTP streams at the followed fork?",
          options: ["They stay thin, because Rad53 can no longer raise RNR activity through Dun1",
            "They thicken as in wild type, because Rad53 raises RNR activity without Dun1",
            "They stop altogether, because RNR needs Dun1 to make any dNTPs at all"],
          answer: 0,
          explain: "Dun1 phosphorylates the RNR inhibitor Sml1 \\cite{zhao2002dun1}, so Rad53 raises dNTP supply through it. In the model the pool stays at a tenth of normal without Dun1."
        },
        text: "Rad53 raises dNTP supply through Dun1, which phosphorylates the RNR inhibitor Sml1 \\cite{zhao2002dun1}.\n\nThe model removes the Dun1 output, so the dNTP pool stays at a tenth of normal after Rad53 comes on. In the close-up the dNTP streams at the followed fork stay thin, whereas in the wild-type cell on the left they thicken once Rad53 raises RNR."
      },
      {
        chapter: "7. The alleles, one at a time", title: "dbf4-zn: less DDK at L1", cond: "znA", layout: "mol",
        origin: function () { return 'L1'; }, follow: function () { return 'origin'; },
        from: function (c) { return c.phase('lateG1'); }, to: function (c) { return Math.max(c.phase('lateG1'), c.first(function (f, v) { return v.kind === 'step'; }) - 1); },
        compare: { cond: 'wtHU', sameSeed: true, drawer: true, follow: true, view: "close", at: function () { return 0; } },
        show: ALL, spot: null,
        ask: {
          q: "How does L1’s DDK-mark meter fill in dbf4-zn cells in HU, compared with wild type?",
          options: ["More slowly: L1 receives fewer DDK copies, so it reaches the line later",
            "Faster: with fewer active DDK copies, Rif1-PP1 leaves L1 alone",
            "At the same rate: the Ctf19 complex still concentrates DDK at L1"],
          answer: 0,
          explain: "In the model, dbf4-zn leaves 7 of the 10 DDK copies active, and the Ctf19 complex no longer concentrates them at L1 and R1."
        },
        text: "dbf4-zn alters the zinc finger of Dbf4, the regulatory subunit of DDK \\cite{julius2019inhibition}.\n\nThe model represents dbf4-zn in two ways: 7 of the 10 DDK copies stay active, and the Ctf19 complex no longer concentrates DDK at L1 and R1. The close-up stays on L1, whose left column counts the DDK copies at L1, while its DDK-mark meter climbs slowly toward the line. At the same minute after G1/S, the wild-type L1 on the left has already fired."
      },
      {
        chapter: "7. The alleles, one at a time", title: "mcm5-bob1 dbf4Δ: origins fire without DDK", cond: "bobA", layout: "mol",
        origin: function () { return 'L1'; }, follow: function () { return 'origin'; },
        from: function (c) { return Math.max(c.phase('lateG1'), c.first(function (f, v) { return v.kind === 'step'; }) - 4); },
        to: function (c) { return c.lastWhere(function (f, v) { return v.kind === 'step'; }) + 2; },
        compare: { cond: 'wtHU', sameSeed: true, drawer: true, follow: true, view: "close", at: function () { return 0; } },
        show: ALL, spot: null,
        ask: {
          q: "mcm5-bob1 dbf4Δ cells have no Dbf4, so no DDK. How does L1 fire in them?",
          options: ["Without marks: in the model the bob1 double hexamer takes a permissive shape, and a firing-factor set lands on it",
            "It does not fire: without DDK marks, Sld3 cannot bind any origin",
            "Through Cdc7 alone, which marks the double hexamer without Dbf4"],
          answer: 0,
          explain: "mcm5-bob1 lets cells grow without Cdc7 or Dbf4 \\cite{Hardy1997,hoang2007structural}. In the model a bob1 double hexamer takes the permissive shape now and then, and a firing-factor set can land on it with no marks."
        },
        text: "mcm5-bob1 changes one residue of Mcm5. Cells that carry it grow without Cdc7 or Dbf4, so their origins fire without DDK \\cite{Hardy1997}. The change alters the shape of Mcm5, which lowers the efficiency of origin firing \\cite{hoang2007structural}. Rad53 still phosphorylates Sld3 in these cells, which keeps the check on late origins largely intact in HU; most mcm5-bob1 cells keep short spindles there \\cite{zegerman2010checkpoint,Gasparayan2022yeast}.\n\nIn the model the bob1 double hexamer spends about a thirtieth of its time in a permissive shape, with the NSD released and no DDK marks. A firing-factor set can land while that shape lasts. The close-up stays on L1 in mcm5-bob1 dbf4Δ: its DDK-mark meter stays empty, and L1 fires through the bob1 shape. At the same minute after G1/S, the wild-type L1 on the left is still gaining DDK marks toward the line."
      },
      {
        chapter: "7. The alleles, one at a time", title: "ctf19Δ: L1 loses its recruiter", cond: "ctf19A", layout: "mol",
        origin: function () { return 'L1'; }, follow: function () { return 'origin'; },
        from: function (c) { return c.phase('lateG1'); }, to: function (c) { return Math.max(c.phase('lateG1'), c.first(function (f, v) { return v.kind === 'step'; }) - 1); },
        compare: { cond: 'wtHU', sameSeed: true, drawer: true, follow: true, view: "close", at: function () { return 0; } },
        show: ALL, spot: null,
        ask: {
          q: "How does L1’s DDK-mark meter fill in ctf19Δ cells in HU, compared with wild type?",
          options: ["More slowly: without the Ctf19 complex, L1 takes only a baseline share of DDK",
            "Faster: without Ctf19 at the kinetochore, more DDK is free to reach L1",
            "At the same rate: Fkh1/2 binds L1 and takes over the recruitment of DDK"],
          answer: 0,
          explain: "The Ctf19 complex recruits DDK to centromere-flanking origins \\cite{natsume2013kinetochores}. In the model, without it L1 and R1 take the baseline share."
        },
        text: "The Ctf19 complex at kinetochores recruits DDK to the origins beside centromeres, which therefore fire early \\cite{natsume2013kinetochores}. Deleting CTF19 or MCM21 removes that recruitment.\n\nThe model gives L1 and R1 the baseline share of DDK in place of the largest one. In the close-up L1 carries fewer DDK copies and its DDK-mark meter climbs slowly, while the wild-type L1 on the left has already fired at the same minute after G1/S."
      },
      {
        chapter: "7. The alleles, one at a time", title: "mcm2-1, mcm3-1, mcm5-1: origins left unlicensed", cond: "mcmA", layout: "mol",
        origin: function (c) { var o = c.sched ? ['L1', 'R1', 'L2', 'R2', 'L3', 'R3'].filter(function (n) { return c.sched.origins[n].fate === 'unlicensed'; }) : []; return o.length ? o[0] : 'L1'; },
        follow: function () { return 'origin'; },
        from: function (c) { return c.phase('lateG1'); }, to: function (c) { return c.at(12); },
        compare: { cond: 'wtHU', sameSeed: true, drawer: true, follow: true, view: "close", at: function () { return 0; } },
        show: ALL, spot: null,
        ask: {
          q: "At G1/S in mcm2-1 cells in HU, how does the model draw an origin?",
          options: ["Often with no double hexamer: it cannot fire, so a passing fork copies it",
            "Always licensed, but each origin fires at half its normal rate in S phase",
            "Always licensed and firing on time, but with forks at half their normal speed"],
          answer: 0,
          explain: "In the model each origin is licensed about a third of the time in these alleles."
        },
        text: "mcm2-1, mcm3-1 and mcm5-1 each weaken one subunit of the Mcm2-7 helicase \\cite{julius2019inhibition}.\n\nThe model represents these alleles as a lower chance of licensing, so each origin carries a double hexamer about a third of the time. The close-up stays on an origin left unlicensed: it carries ORC with no Mcm2-7 pair, cannot fire, and is copied by a passing fork. The same origin in the wild-type cell on the left carries its double hexamer. Firing was not measured in these strains, so this representation is an inference."
      },
      {
        chapter: "7. The alleles, one at a time", title: "exo1Δ: slower resection at the centromere", cond: "exo1A", layout: "mol",
        follow: function () { return 'cen'; },
        from: function (c) { var k = nearCen(c.sched); return c.at(k ? k.t : 20); },
        to: function (c) { var k = nearCen(c.sched), l = c.sched.anchors.lostAt; return l !== null ? c.at(l) + 2 : c.at((k ? k.t : 20) + 20); },
        compare: { cond: 'wtHU', sameSeed: true, drawer: true, follow: true, view: "close", at: function () { return 0; } },
        show: ALL, spot: null,
        ask: {
          q: "A fork collapses beside the centromere in exo1Δ cells in HU. What changes in the centromere close-up?",
          options: ["The single-stranded stretch reaches the centromere much later, so the kinetochore holds longer",
            "No single-stranded DNA forms at all, because Exo1 makes all of it at a collapsed fork",
            "The stretch spreads just as fast, but it stops short of the centromeric DNA"],
          answer: 0,
          explain: "Exo1 resects the new strands at collapsed forks \\cite{cotta2005exo1}. In the model, the stretch spreads at a fifth of the rate without Exo1."
        },
        text: "Exo1 resects the new strands at collapsed forks \\cite{cotta2005exo1}.\n\nWithout Exo1 the model still resects, at a fifth of the wild-type rate. In this run a fork beside the centromere collapses with Rad53 on. The wild-type run on the left shares its random draws and has the same collapse. In the exo1\u0394 close-up the single-stranded stretch advances slowly, so the kinetochore stays attached to its microtubule long after the wild-type one has let go."
      },
      {
        chapter: "7. The alleles, one at a time", title: "Ask1-LacI builds kinetochores on lacO arrays far from early origins", cond: "akA", layout: "chrom",
        from: function (c) { return c.at(0); }, to: function (c) { return c.at(10); },
        compare: { cond: 'wtHU', sameSeed: true, drawer: true, follow: true, view: "chrom", at: function () { return 0; } },
        show: ALL, spot: { boxes: [[270, 160, 60, 82]] },
        ask: {
          q: "In 4× LATE-AK + ASK1-LacI cells in HU, what appears at the lacO site 75 kb along the chromosome?",
          options: ["A kinetochore, holding a microtubule from the pole below the frame",
            "A new origin that fires late, because the array recruits DDK to it",
            "Nothing, because a kinetochore forms only on centromeric DNA"],
          answer: 0,
          explain: "LacI brings Ask1, a subunit of the Dam1 complex, to the arrays, where it builds kinetochores \\cite{julius2019inhibition}."
        },
        text: "Four lacO arrays sit about 20 kb from origins that fire late in HU, each on a separate chromosome \\cite{julius2019inhibition}. With ASK1-LacI each array builds a kinetochore; with the vector, the arrays stay bare.\n\nThe model places one such site at 75 kb, 20 kb from L2, drawn as a small block labelled “late AK”. With ASK1-LacI, a kinetochore sits on the block and takes a microtubule from the pole below the frame, and the spindle stays short while either kinetochore stays attached."
      },

      // --- 8. Reading spindles in HU ------------------------------------
      // Measured results as cards (tools/tour/spindles.py), each beside the
      // model's close-up of the step the strain changes. The comparison
      // close-up replays the same random draws with the strain it is
      // compared with.
      {
        chapter: '8. Reading spindles in HU', title: 'In HU, a spindle is short or extended', grn: { live: 'rad53', cmp: 'wt' }, cond: 'rad53HU', layout: 'mol',
        figure: 'readout', figureLabel: 'The readout', follow: function () { return 'cen'; },
        from: function (c) { return c.at(c.sched.extStart + 2); }, to: function (c) { return c.at(c.sched.extStart + 8); },
        compare: { cond: 'wtHU', sameSeed: true, drawer: true, follow: true, view: 'close', at: function () { return 0; } },
        show: ALL, spot: null,
        text: "A cell released from G1 into HU builds a spindle before its chromosomes are copied. Wild-type cells keep that spindle at 1 to 2 µm. rad53-21 cells extend it to 3 to 7 µm while their chromosomes are still partly copied \\cite{bachant2005yeast,julius2019inhibition}.\n\nEach cell is scored by the distance between its spindle poles: a cell whose poles sit 3 µm apart or more has an extended spindle \\cite{julius2019inhibition,Gasparayan2022yeast}.\n\nThe scoring times, 90 minutes to 3 hours after release into 200 mM HU, come before wild-type cells finish replicating, so wild-type spindles are still short when scored \\cite{julius2019inhibition,Gasparayan2022yeast,Gasparayan2009yeast}. Wild-type cells extend their spindles only after replication, in anaphase: Pds1 is destroyed, separase cuts cohesin, the sisters separate and the spindle reaches 8 to 10 µm. The extension scored in HU starts as soon as the spindle forms, while Pds1 stays stable and the sisters stay together, and it reaches 3 to 7 µm in cycles of extension and breakage \\cite{bachant2005yeast,julius2019inhibition}.\n\nThe close-ups show the centromere of each model cell at the same minute: the wild-type kinetochore stays attached to its microtubule, whereas the rad53-21 kinetochore has let go."
      },
      {
        chapter: '8. Reading spindles in HU', title: 'A fork that fails beside a centromere costs it its kinetochore', grn: { live: 'rad53', cmp: 'rad53' }, cond: 'rad53HU', layout: 'mol',
        figure: 'cenwhy', figureLabel: 'Why centromeres', follow: function () { return 'cen'; },
        from: function (c) { var k = nearCen(c.sched); return c.at(k.t - 1); },
        to: function (c) { return c.at(c.sched.anchors.lostAt) + 2; },
        compare: { cond: 'rad53HU', sameSeed: true, drawer: true, follow: true, view: 'close', at: function () { return 0; },
          focus: function (s) { var f = farCollapse(s); return [f.split('-')[0], f.split('-')[1]]; },
          label: 'rad53-21 in HU, a fork far from the centromere' },
        show: ALL, spot: null,
        ask: {
          q: "Two forks collapse in this rad53-21 cell, one beside the centromere and one far out on an arm. Which one costs the cell a kinetochore?",
          options: ["The fork beside the centromere: its single strands reach the centromeric DNA",
            "The fork far out on the arm: it collapses first",
            "Both: any collapsed fork releases the kinetochore"],
          answer: 0,
          explain: "Exo1 resection from a collapse far out on an arm stays on the arm. In rad53-21 cells in HU, GFP tags beside centromeres lose signal, whereas tags far from early origins keep it \\cite{julius2019inhibition}."
        },
        text: "Every yeast centromere lies beside origins that fire early in HU \\cite{julius2019inhibition}. Their forks reach the centromere first. In a rad53-21 cell a fork that collapses there leaves single-stranded DNA, and Exo1 extends it toward the centromere \\cite{cotta2005exo1}. Julius and colleagues proposed that this resection exposes the centromeric DNA and disrupts the kinetochore built on it \\cite{julius2019inhibition}. A kinetochore attached to a microtubule pulls against the force that pushes the poles apart, so a spindle that loses its kinetochores extends.\n\nThe right close-up follows the centromere through that sequence. The left one follows a fork in the same cell that collapses far out on an arm. Its single strands stay on the arm. In the model resection stops 6.6 kb from a collapse, so only a collapse within that reach of a centromere costs a kinetochore."
      },
      {
        chapter: '8. Reading spindles in HU', title: 'Rad53 keeps HU spindles short by slowing replication', grn: { live: 'rad53', cmp: 'wt' },
        cond: 'rad53HU', layout: 'mol', figure: 'grn-key', figureLabel: 'The Rad53 network',
        origin: function () { return 'L1'; }, follow: function () { return 'right'; },
        from: function (c) { return firstElong(c); }, to: function (c) { return firstElong(c) + 14; },
        compare: { cond: 'wtHU', sameSeed: true, drawer: true, follow: true, view: 'close', at: function () { return 0; } },
        show: ALL, spot: null,
        text: "Rad53 slows replication in HU through four outputs (chapter 4). Phosphorylated Sld3 and Dbf4 keep late origins unfired \\cite{zegerman2010checkpoint,lopez2010damage}, phosphorylated Dun1 raises the dNTP pool \\cite{zhao2002dun1}, and Rad53 at stalled forks keeps them able to restart \\cite{lopes2001dna}. Julius and colleagues proposed that these outputs together keep forks from failing beside centromeres \\cite{julius2019inhibition}. In wild-type cells the spindle stays short, and anaphase waits until the DNA is copied.\n\nThe network follows each output to the spindle. Without Rad53 all four arms run: late origins fire, the dNTP pool stays low and stalled forks collapse. A fork that fails beside a centromere costs it its kinetochore, so the spindle extends before the DNA is copied. Green arms run, grey dashed arms are blocked by Rad53 or receive no input, and a red cross marks a step an allele removes. Breaking one step downstream of Rad53 tests whether extension needs that step.\n\nThe close-ups follow the right fork of L1. In rad53-21 the helicase runs ahead of the stalled polymerases, whereas in wild type Rad53 slows the helicase to their pace."
      },
      {
        chapter: '8. Reading spindles in HU', title: 'Each experiment carries its own short and extended controls', grn: { live: 'rad53', cmp: 'wt' }, cond: 'rad53HU', layout: 'mol',
        figure: 'controls', figureLabel: 'Controls',
        origin: function () { return 'R3'; }, follow: function () { return 'origin'; },
        from: function (c) { return c.at(Math.max(0, (c.sched.origins.R3.time || 0) - 6)); },
        to: function (c) { return c.lastWhere(function (f, v) { return v.kind === 'step'; }) + 2; },
        compare: { cond: 'wtHU', sameSeed: true, drawer: true, follow: true, view: 'close', at: function () { return 0; } },
        show: ALL, spot: null,
        text: "The share of rad53-21 cells with extended spindles differs between experiments, which differ in incubation time, temperature and HU dose \\cite{julius2019inhibition,Gasparayan2022yeast}. Each experiment therefore scores its own controls: wild type for short spindles and rad53-21 for extended spindles. A strain tested in that experiment takes the class of the control it lies nearer.\n\nThe close-ups show the two controls at the late origin R3. In the model rad53-21 fires R3, whereas in wild type R3 stays unfired until a fork copies it. Each strain appears as a card that carries its genotype and its class."
      },
      {
        chapter: '8. Reading spindles in HU', title: 'A weaker helicase keeps rad53-21 spindles short', grn: { live: 'r53mcm', cmp: 'rad53' }, cond: 'r53mcm', layout: 'mol',
        figure: 'sp-mcm', figureLabel: 'Measured spindles',
        origin: function (c) { var o = c.sched ? ['L1', 'R1', 'L2', 'R2', 'L3', 'R3'].filter(function (n) { return c.sched.origins[n].fate === 'unlicensed'; }) : []; return o.length ? o[0] : 'L1'; },
        follow: function () { return 'origin'; },
        from: function (c) { return c.phase('lateG1'); }, to: function (c) { return c.at(12); },
        compare: { cond: 'rad53HU', sameSeed: true, drawer: true, follow: true, view: 'close', at: function () { return 0; } },
        show: ALL, spot: null,
        ask: {
          q: "rad53-21 cells extend their spindles in HU. What class do rad53-21 mcm2-1, rad53-21 mcm3-1 and rad53-21 mcm5-1 cells fall in?",
          options: ["Short, like wild type: extension needs a full-strength helicase",
            "Extended, like rad53-21: the helicase acts after the step Rad53 controls",
            "Short with one allele and extended with the others"],
          answer: 0,
          explain: "All three double mutants arrest with short spindles in HU \\cite{julius2019inhibition}. Firing was not measured in these strains."
        },
        text: "rad53-21 changes one gene in wild type, which turns short spindles into extended ones. A second mutation in the rad53-21 cell then tests whether extension needs the step that mutation changes. mcm2-1, mcm3-1 and mcm5-1 each weaken one subunit of the Mcm2-7 helicase \\cite{julius2019inhibition}.\n\nIn the model these alleles lower the chance of licensing (chapter 7). The right close-up stays on an origin left without a double hexamer in rad53-21 mcm2-1. The same origin in rad53-21, on the left, carries its double hexamer and fires. Both close-ups show the same minute after G1/S; each counts minutes into S from its own first firing."
      },
      {
        chapter: '8. Reading spindles in HU', title: 'Less firing beside centromeres keeps rad53-21 spindles short', grn: { live: 'r53zn', cmp: 'rad53' }, cond: 'r53zn', layout: 'mol',
        figure: 'sp-zn', figureLabel: 'Measured spindles',
        origin: function () { return 'L1'; }, follow: function () { return 'origin'; },
        from: function (c) { return c.phase('lateG1'); },
        to: function (c) { return Math.max(c.phase('lateG1'), c.first(function (f, v) { return v.kind === 'step'; }) - 1); },
        compare: { cond: 'rad53HU', sameSeed: true, drawer: true, follow: true, view: 'close', at: function () { return 0; } },
        show: ALL, spot: null,
        ask: {
          q: "rad53-21 dbf4-zn cells fire fewer origins in HU than rad53-21 cells. What class are their spindles?",
          options: ["Short, like wild type",
            "Extended, like rad53-21: the spindle does not depend on firing",
            "Extended, because Dbf4 is a Rad53 target"],
          answer: 0,
          explain: "rad53-21 dbf4-zn cells arrest with short spindles in HU \\cite{julius2019inhibition}."
        },
        text: "dbf4-zn alters the zinc finger of Dbf4 \\cite{julius2019inhibition}. These strains carry DBF4 on a plasmid in place of the deleted gene, so pdbf4-zn is compared with pDBF4 in the same rad53-21 cell. Firing was measured directly: on genome-wide profiles of single-stranded DNA in HU, rad53-21 dbf4-zn cells fire every origin less than rad53-21 cells, and the origins that flank centromeres least of all \\cite{julius2019inhibition}.\n\nThe close-ups follow L1, the origin beside the centromere. Its DDK-mark meter climbs more slowly in rad53-21 dbf4-zn than in rad53-21, so L1 fires later."
      },
      {
        chapter: '8. Reading spindles in HU', title: 'Late origins firing despite active Rad53 extend spindles', grn: { live: 'sites', cmp: 'wt' }, cond: 'sitesHU', layout: 'mol',
        figure: 'sp-sites', figureLabel: 'Measured spindles',
        origin: function (c) { return c.sched && c.sched.origins.R3.fate === 'fired' ? 'R3' : 'L3'; }, follow: function () { return 'origin'; },
        from: function (c) { return c.at(c.sched.rad53At); }, to: function (c) { return c.lastWhere(function (f, v) { return v.kind === 'step'; }) + 2; },
        compare: { cond: 'wtHU', sameSeed: true, drawer: true, follow: true, view: 'close', at: function () { return 0; } },
        show: ALL, spot: null,
        ask: {
          q: "Rad53 is active in dbf4-m25 sld3-38A cells, but it cannot block their late origins. What class are their spindles in HU?",
          options: ["Extended: late origins firing despite Rad53 are enough",
            "Short: Rad53 is active, so the spindle stays short",
            "Short until dun1Δ is added as well"],
          answer: 0,
          explain: "dbf4-m25 sld3-38A cells extend their spindles in HU, and adding dun1Δ leaves them extended \\cite{julius2019inhibition}."
        },
        text: "Rad53 keeps late origins unfired by phosphorylating Dbf4 and Sld3 \\cite{zegerman2010checkpoint,lopez2010damage}. dbf4-m25 and sld3-38A remove those sites, so late origins fire while Rad53 is active. Each site mutation alone leaves spindles short, and so does dun1Δ alone. The lower row carries this experiment's extended control, rad53-21.\n\nThe close-ups follow the late origin R3 after Rad53 comes on. In dbf4-m25 sld3-38A it fires; in wild type, on the left, it waits."
      },
      {
        chapter: '8. Reading spindles in HU', title: 'rad53-21 spindles need early firing beside centromeres to extend', grn: { live: 'r53ctf19', cmp: 'rad53' }, cond: 'r53ctf19', layout: 'mol',
        figure: 'sp-ctf', figureLabel: 'Measured spindles',
        origin: function () { return 'L1'; }, follow: function () { return 'origin'; },
        from: function (c) { return c.phase('lateG1'); },
        to: function (c) { return Math.max(c.phase('lateG1'), c.first(function (f, v) { return v.kind === 'step'; }) - 1); },
        compare: { cond: 'rad53HU', sameSeed: true, drawer: true, follow: true, view: 'close', at: function () { return 0; } },
        show: ALL, spot: null,
        ask: {
          q: "What class do rad53-21 ctf19Δ and rad53-21 mcm21Δ cells fall in?",
          options: ["Short: the origins beside centromeres no longer fire early",
            "Extended: a weaker kinetochore adds to the rad53-21 defect",
            "Extended, like rad53-21: recruitment of DDK does not matter in HU"],
          answer: 0,
          explain: "Both double mutants arrest with short spindles in HU \\cite{julius2019inhibition}. Less firing beside centromeres keeps rad53-21 spindles short."
        },
        text: "The Ctf19 complex at kinetochores brings DDK to the origins beside centromeres, which therefore fire early \\cite{natsume2013kinetochores}. ctf19Δ and mcm21Δ each remove that recruitment. No wild-type strain was scored in this experiment, so ctf19Δ and mcm21Δ alone serve as the short controls.\n\nThe close-ups follow L1. Without the Ctf19 complex L1 carries fewer DDK copies and its DDK-mark meter climbs slowly, while L1 in rad53-21 fires first."
      },
      {
        chapter: '8. Reading spindles in HU', title: 'Bud size tells how long a cell has been in S phase', grn: { live: 'rad53', cmp: 'wt' }, cond: 'rad53HU', layout: 'mol',
        figure: 'buds', figureLabel: 'Bud size', follow: function () { return 'cen'; },
        from: function (c) { return c.at(c.sched.anchors.lostAt - 3); }, to: function (c) { return c.at(c.sched.anchors.lostAt) + 3; },
        compare: { cond: 'wtHU', sameSeed: true, drawer: true, follow: true, view: 'close', at: function () { return 0; } },
        show: ALL, spot: null,
        text: "A cell's bud grows through S phase, so bud circumference serves as a clock for the time a cell has spent in S phase in HU \\cite{julius2019inhibition}. Cells are split at a circumference of 15 µm: small to medium buds below it, medium to large buds above it. In HU a cell's bud keeps growing while replication stalls \\cite{julius2019inhibition}. A large bud marks a cell that has spent longer in HU, not one that is ready to divide.\n\nrad53-21 spindles extend soon after the spindle forms, when the bud is about 10 to 12 µm around \\cite{Gasparayan2022yeast}. rad53-21 cells are therefore extended in both classes, and wild-type cells are short in both. The close-ups show the rad53-21 centromere losing its kinetochore early in S phase, beside wild type. A strain that is short in small buds and extended in large buds extends late."
      },
      {
        chapter: '8. Reading spindles in HU', title: 'Without Exo1, rad53-21 spindles extend late', grn: { live: 'r53exo1', cmp: 'rad53' }, cond: 'r53exo1', layout: 'mol',
        figure: 'sp-exo1', figureLabel: 'Measured spindles', follow: function () { return 'cen'; },
        from: function (c) { var k = nearCen(c.sched); return c.at(k ? k.t : 20); },
        to: function (c) { var k = nearCen(c.sched), l = c.sched.anchors.lostAt; return l !== null ? c.at(l) + 2 : c.at((k ? k.t : 20) + 20); },
        compare: { cond: 'rad53HU', sameSeed: true, drawer: true, follow: true, view: 'close', at: function () { return 0; } },
        show: ALL, spot: null,
        ask: {
          q: "What class do rad53-21 exo1Δ cells fall in?",
          options: ["Short in small buds and extended in large buds",
            "Short in both bud classes",
            "Extended in both bud classes, like rad53-21"],
          answer: 0,
          explain: "Without Exo1, rad53-21 spindles stay short in small buds and extend in large buds \\cite{julius2019inhibition}. Exo1 sets how soon extension happens."
        },
        text: "Exo1 resects the new strands at forks that collapse in rad53 cells in HU \\cite{cotta2005exo1}. In rad53-21 cells in HU, GFP tags next to centromeres lose signal, and that loss needs Exo1 \\cite{julius2019inhibition}. Each row of cards compares strains of one bud class.\n\nThe close-ups follow the centromere after the same fork collapses beside it. In the model resection without Exo1 runs at a fifth of the rate, so the rad53-21 exo1Δ kinetochore lets go later than the rad53-21 one on the left."
      },
      {
        chapter: '8. Reading spindles in HU', title: 'Kinetochores far from early origins delay extension', grn: { live: 'r53ako' }, cond: 'r53ako', layout: 'both',
        figure: 'sp-ak', figureLabel: 'Measured spindles', follow: function () { return 'cen'; },
        from: function (c) { var k = nearCen(c.sched); return c.at(k ? k.t : 20); },
        to: function (c) { var k = nearCen(c.sched); return c.at((k ? k.t : 20) + 30); },
        show: ALL, spot: { boxes: [[270, 160, 60, 82], BOX.spindle] },
        text: "The late artificial kinetochores of chapter 7 are four lacO arrays, each about 20 kb from an origin that fires in HU. They become kinetochores when LacI carries Ask1 \\cite{julius2019inhibition}. The short control carries the same arrays with Rad53 intact. With the arrays active, rad53-21 spindles stay short in small buds and extend in large buds.\n\nThe close-up follows the centromere of a rad53-21 cell with the arrays active, and the chromosome above it shows the whole cell. The centromere loses its kinetochore, while the artificial kinetochore far from early origins stays attached to its microtubule and the spindle stays short."
      },
      {
        chapter: '8. Reading spindles in HU', title: 'An extended spindle reports failed forks, not the step that failed', grn: { live: 'rad53' }, cond: 'rad53HU', layout: 'both',
        figure: 'readsum', figureLabel: 'The readout', follow: function () { return 'cen'; },
        from: function (c) { var k = nearCen(c.sched); return c.at(k.t); }, to: function (c) { return c.at(c.sched.extStart + 6); },
        show: ALL, spot: null,
        text: "Lower firing, lower firing beside centromeres, kinetochores far from early origins and the loss of Exo1 each keep rad53-21 spindles short. Late origins firing despite active Rad53 extend spindles \\cite{julius2019inhibition}. The close-up replays the whole sequence at one centromere: a fork collapses beside it, resection reaches it, the kinetochore lets go and the spindle gauge extends.\n\nRad53 slows replication in HU. Without Rad53, forks fail beside centromeres and spindles extend before the DNA is copied. Breaking one step downstream of Rad53 restores short spindles, so the strains that keep spindles short name the steps extension needs: Rad53 activation, Exo1, firing beside centromeres, DDK and the helicase. Overproduced Stn1 extends spindles while Rad53 is active \\cite{Gasparayan2009yeast}. The remaining question is which of these steps excess Stn1 needs."
      },
      // --- 9. Excess Stn1 ------------------------------------------------
      // Each slide narrows the region of the Rad53 network where excess Stn1
      // may first act (tools/tour/grn.py, HONE). A close-up of a cell that
      // overproduces Stn1 sits on a yellow ground with the stn1-OP badge; the
      // model draws no Stn1 there and proposes no route.
      {
        chapter: '9. Excess Stn1', title: 'Excess Stn1 extends spindles in HU with Rad53 present', cond: 'op', layout: 'mol',
        grn: { live: 'hone1' }, grnLabel: 'Where excess Stn1 may first act', op: { live: true },
        figure: 'op-sp', figureLabel: 'Measured spindles', follow: function () { return 'cen'; },
        from: function (c) { return c.at(c.sched.anchors.lostAt - 3); }, to: function (c) { return c.at(c.sched.anchors.lostAt) + 3; },
        compare: { cond: 'wtHU', sameSeed: true, drawer: true, follow: true, view: 'close', at: function () { return 0; } },
        show: ALL, spot: null,
        ask: {
          q: "stn1-OP cells overproduce Stn1, and their RAD53 is intact. What class are their spindles in HU?",
          options: ["Extended, like rad53-21",
            "Short, like wild type: Rad53 is intact",
            "Short in small buds and extended in large buds"],
          answer: 0,
          explain: "53% of stn1-OP cells extend their spindles in HU, against 6% of wild-type cells and 40% of rad53-21 cells scored in the same experiment \\cite{Gasparayan2022yeast}."
        },
        text: "rad53-21 cells extend their spindles in HU because their Rad53 is defective. Cells that overproduce Stn1 (stn1-OP) extend their spindles in HU with RAD53 intact, and they are sensitive to HU and MMS \\cite{Gasparayan2009yeast,Gasparayan2022yeast}. Stn1 is a subunit of CST (Cdc13-Stn1-Ten1), which caps telomeres and works with DNA polymerase α at them \\cite{Gasparayan2009yeast}. Excess Stn1 therefore gives the spindle extension of rad53-21 cells in a cell with working Rad53.\n\nThe model has no Stn1. A close-up on a yellow ground shows a stn1-OP cell, which in the model keeps Rad53 active and fires late origins anyway, two results measured in stn1-OP cells \\cite{Gasparayan2009yeast}. The model draws no Stn1 at origins and no route from excess Stn1 to either result.\n\nThe dashed outline on the network under the close-up encloses the steps where excess Stn1 may first act. With the spindle result alone, those steps run from the signal at stalled forks to the spindle. The close-ups show the centromere of each cell at the same minute: in the stn1-OP cell the kinetochore lets go, whereas in wild type it stays attached to its microtubule."
      },
      {
        chapter: '9. Excess Stn1', title: 'Rad53 is activated on time in stn1-OP cells', cond: 'op', layout: 'mol',
        grn: { live: 'hone2' }, grnLabel: 'Where excess Stn1 may first act', op: { live: true },
        figure: 'op-rad53', figureLabel: 'Rad53 phosphorylation',
        origin: function (c) { return (steady(c.sched) || 'L1-right').split('-')[0]; },
        follow: function (c) { return (steady(c.sched) || 'L1-right').split('-')[1]; },
        from: function (c) { return c.first(function (f, v) { return v.kind === 'elong' && v.bare >= 2; }); },
        to: function (c) { return c.first(function (f, v) { return v.kind === 'elong' && v.active; }) + 8; },
        compare: { cond: 'wtHU', sameSeed: true, drawer: true, follow: true, view: 'close', at: function () { return 0; } },
        show: ALL, spot: null,
        ask: {
          q: "rad9Δ cells activate Rad53 in HU through Mrc1 alone. When is Rad53 phosphorylated in rad9Δ stn1-OP cells?",
          options: ["On time, as in rad9Δ cells with the vector",
            "Late, as in cells that lack Mrc1",
            "Never: excess Stn1 blocks the Mrc1 route"],
          answer: 0,
          explain: "Rad53 phosphorylation keeps its normal timing in rad9Δ stn1-OP cells in HU \\cite{Gasparayan2009yeast}. Excess Stn1 leaves the Mrc1 route intact."
        },
        text: "Stalled forks activate Rad53 through Mec1 and its mediator Mrc1 \\cite{alcasabas2001mrc1}. Without Mrc1, Rad53 is still activated through Rad9, with a delay \\cite{alcasabas2001mrc1}. Phosphorylated Rad53 runs more slowly on a gel, so a western blot shows when Rad53 is activated.\n\nIn stn1-OP cells Rad53 is phosphorylated with normal timing in HU and in MMS \\cite{Gasparayan2009yeast}. In rad9Δ cells Mrc1 is the only route to Rad53, a route that excess Stn1 also leaves working \\cite{Gasparayan2009yeast}. Excess Stn1 therefore acts after Rad53 is activated, on one or more of the four arms of Rad53. On the network the outline now encloses those arms; each arm box stands for the whole arm, including the Rad53 phosphorylation that blocks it.\n\nThe close-ups follow one fork as Mec1 phosphorylates Mrc1 and Rad53 docks. In the model Rad53 comes on in both cells."
      },
      {
        chapter: '9. Excess Stn1', title: 'Spindle extension in stn1-OP cells needs Exo1', cond: 'opExo1', layout: 'mol',
        grn: { live: 'hone3' }, grnLabel: 'Where excess Stn1 may first act', op: { live: true, cmp: true },
        figure: 'op-exo1', figureLabel: 'Measured spindles', follow: function () { return 'cen'; },
        from: function (c) { var k = nearCen(c.sched); return c.at(k ? k.t : 20); },
        to: function (c) { var k = nearCen(c.sched), l = c.sched.anchors.lostAt; return l !== null ? c.at(l) + 2 : c.at((k ? k.t : 20) + 20); },
        compare: { cond: 'op', sameSeed: true, drawer: true, follow: true, view: 'close', at: function () { return 0; } },
        show: ALL, spot: null,
        ask: {
          q: "exo1Δ keeps rad53-21 spindles short in small buds. What class are exo1Δ stn1-OP spindles?",
          options: ["Short, like exo1Δ alone",
            "Extended, like stn1-OP: excess Stn1 bypasses Exo1",
            "Extended, because exo1Δ weakens the kinetochore"],
          answer: 0,
          explain: "20% of exo1Δ stn1-OP cells extend their spindles, nearer exo1Δ alone (3%) than stn1-OP (53%) in the same experiment \\cite{Gasparayan2022yeast}."
        },
        text: "In rad53-21 cells Exo1 resects collapsed forks toward the centromere, which costs the centromere its kinetochore (chapter 8). Deleting EXO1 lowers spindle extension in stn1-OP cells about as much as in rad53-21 cells \\cite{Gasparayan2022yeast}.\n\nSpindle extension by excess Stn1 needs Exo1. Excess Stn1 therefore acts at Exo1 or at a step before it, and the outline encloses Exo1 with the steps before it. Whether excess Stn1 acts on Exo1 itself stays open at this step.\n\nThe close-ups follow the centromere after the same fork collapses beside it. In the model resection without Exo1 runs at a fifth of the wild-type rate, so the kinetochore of the exo1Δ stn1-OP cell lets go later than that of the stn1-OP cell on the left."
      },
      {
        chapter: '9. Excess Stn1', title: 'Growth on HU plates reports whether cells survive replication stress', cond: 'wtHU', layout: 'mol',
        figure: 'growth', figureLabel: 'The growth readout',
        origin: function (c) { return (steady(c.sched) || 'L1-right').split('-')[0]; },
        follow: function (c) { return (steady(c.sched) || 'L1-right').split('-')[1]; },
        from: function (c) { return c.at(c.sched.rad53At) - 3; }, to: function (c) { return c.at(c.sched.rad53At) + 10; },
        show: ALL, spot: null,
        text: "A growth test spots serial dilutions of cells onto a plate without HU and a plate with HU. A strain that grows without HU but leaves faint or empty spots on HU is HU-sensitive \\cite{Gasparayan2009yeast}.\n\nGrowth sums every defect that kills cells in HU over days. A growth result therefore tests whether a change expected to help a strain does help it, without placing the defect on one step.\n\nOne such change raises RNR activity. HU blocks RNR; Rad53 counters the block through Dun1, which phosphorylates the RNR inhibitor Sml1 \\cite{zhao2002dun1,zhao1998suppressor}. The close-up follows a wild-type fork as Rad53 comes on: the dNTP streams thicken once Rad53 raises RNR activity."
      },
      {
        chapter: '9. Excess Stn1', title: 'Extra RNR activity does not rescue stn1-OP cells, and losing Dun1 kills them', cond: 'op', layout: 'mol',
        grn: { live: 'hone4' }, grnLabel: 'Where excess Stn1 may first act', op: { live: true },
        figure: 'op-rnr', figureLabel: 'Measured growth',
        origin: function (c) { return (steady(c.sched) || 'L1-right').split('-')[0]; },
        follow: function (c) { return (steady(c.sched) || 'L1-right').split('-')[1]; },
        from: function (c) { return c.at(c.sched.rad53At) - 3; }, to: function (c) { return c.at(c.sched.rad53At) + 10; },
        compare: { cond: 'wtHU', sameSeed: true, drawer: true, follow: true, view: 'close', at: function () { return 0; } },
        show: ALL, spot: null,
        ask: {
          q: "sml1Δ and extra RNR1 each raise RNR activity. Do they restore growth of stn1-OP cells on HU?",
          options: ["No: stn1-OP cells stay HU-sensitive",
            "Yes: excess Stn1 lowers RNR activity",
            "Only sml1Δ does, because Dun1 acts through Sml1"],
          answer: 0,
          explain: "Disrupting SML1 or overexpressing RNR1 leaves stn1-OP cells as sensitive to HU as before \\cite{Gasparayan2009yeast}."
        },
        text: "If excess Stn1 blocked the Dun1 arm of Rad53, stn1-OP cells would be short of RNR activity in HU, and raising RNR activity would rescue them. Disrupting SML1 or overproducing RNR1 leaves their HU sensitivity unchanged \\cite{Gasparayan2009yeast}.\n\nOverproducing Stn1 also kills dun1Δ cells without HU and stops the growth of cells carrying rnr2-1, a temperature-sensitive allele of an RNR subunit \\cite{Gasparayan2022yeast}. These results suggest that stn1-OP cells depend on Dun1 to raise RNR activity \\cite{Gasparayan2022yeast}. Both growth results are consistent with excess Stn1 leaving the Dun1 arm working, so the outline no longer encloses that arm.\n\nThe close-ups follow one fork as Rad53 comes on. In the model the dNTP streams thicken in the stn1-OP cell, as they do in wild type."
      },
      {
        chapter: '9. Excess Stn1', title: 'Late origins fire in stn1-OP cells while Rad53 is on', cond: 'op', layout: 'mol',
        grn: { live: 'hone5' }, grnLabel: 'Where excess Stn1 may first act', op: { live: true },
        figure: 'op-fire', figureLabel: 'Measured firing',
        origin: function () { return 'R3'; }, follow: function () { return 'origin'; },
        from: function (c) { return c.at(c.sched.rad53At); }, to: function (c) { return c.lastWhere(function (f, v) { return v.kind === 'step'; }) + 2; },
        compare: { cond: 'wtHU', sameSeed: true, drawer: true, follow: true, view: 'close', at: function () { return 0; } },
        show: ALL, spot: null,
        ask: {
          q: "In MMS, Rad53 keeps late origins from firing. Do the late origins ARS601/2 and ARS603 fire in stn1-OP cells in MMS?",
          options: ["Yes, between 30 and 60 min after release",
            "No: Rad53 is on, so they wait",
            "Only after S phase ends"],
          answer: 0,
          explain: "BrdU marks new DNA at ARS601/2, ARS603 and ARS610 in stn1-OP cells 30 to 60 min after release into MMS, and not in vector cells \\cite{Gasparayan2009yeast}."
        },
        text: "In MMS, which activates Rad53 but lets replication continue, BrdU labelling of new DNA shows the late origins ARS601/2 and ARS603, and ARS610 near a telomere, firing in stn1-OP cells 30 to 60 min after release. Vector cells leave these origins unfired \\cite{Gasparayan2009yeast}. Rad53 blocks late origins by phosphorylating Sld3 and Dbf4 \\cite{zegerman2010checkpoint}, yet in stn1-OP cells late origins fire while Rad53 is active.\n\nOn the network the outline now encloses the steps that fire late origins: the Sld3 arm, the DDK arm and firing itself. The steps after firing follow from it in this cell.\n\nForks also copy less DNA in stn1-OP cells in MMS. Checkpoint mutants show the same slowing, which the extra forks from late origins may explain \\cite{Gasparayan2009yeast}. Neither paper separates a fork defect from extra firing, so the network marks the fork arm as open, with a grey dotted outline.\n\nThe close-ups follow the late origin R3 after Rad53 comes on. In the model R3 fires in the stn1-OP cell and waits in wild type."
      },
      {
        chapter: '9. Excess Stn1', title: 'A weaker helicase keeps stn1-OP spindles short', cond: 'opMcm', layout: 'mol',
        grn: { live: 'hone6' }, grnLabel: 'Where excess Stn1 may first act', op: { live: true, cmp: true },
        figure: 'op-mcm', figureLabel: 'Measured spindles',
        origin: function (c) { var o = c.sched ? ['L1', 'R1', 'L2', 'R2', 'L3', 'R3'].filter(function (n) { return c.sched.origins[n].fate === 'unlicensed'; }) : []; return o.length ? o[0] : 'L1'; },
        follow: function () { return 'origin'; },
        from: function (c) { return c.phase('lateG1'); }, to: function (c) { return c.at(12); },
        compare: { cond: 'op', sameSeed: true, drawer: true, follow: true, view: 'close', at: function () { return 0; } },
        show: ALL, spot: null,
        ask: {
          q: "mcm2-1 and mcm5-1 keep rad53-21 spindles short. What class are mcm2-1 stn1-OP and mcm5-1 stn1-OP spindles?",
          options: ["Short, like the mcm alleles alone",
            "Extended, like stn1-OP",
            "Short with mcm2-1 and extended with mcm5-1"],
          answer: 0,
          explain: "1% of mcm2-1 stn1-OP cells and 5% of mcm5-1 stn1-OP cells extend their spindles in HU, as few as the mcm alleles alone \\cite{Gasparayan2022yeast}."
        },
        text: "mcm2-1 and mcm5-1 weaken the Mcm2-7 helicase and keep rad53-21 spindles short (chapter 8). They also keep stn1-OP spindles short, without lowering the amount of Stn1 or its binding to chromatin \\cite{Gasparayan2022yeast}. Spindle extension by excess Stn1 therefore needs a full-strength helicase, the enzyme loaded at origins in G1 and activated when they fire.\n\nThe outline on the network stays the same size: the result supports the firing step inside it.\n\nThe right close-up stays on an origin left without a double hexamer in mcm2-1 stn1-OP. The same origin in stn1-OP, on the left, carries its double hexamer and fires. In the model these alleles lower the chance of licensing (chapter 7)."
      },
      {
        chapter: '9. Excess Stn1', title: 'dbf4-zn keeps stn1-OP spindles short', cond: 'opZn', layout: 'mol',
        grn: { live: 'hone7' }, grnLabel: 'Where excess Stn1 may first act', op: { live: true, cmp: true },
        figure: 'op-zn', figureLabel: 'Measured spindles',
        origin: function () { return 'L1'; }, follow: function () { return 'origin'; },
        from: function (c) { return c.phase('lateG1'); },
        to: function (c) { return Math.max(c.phase('lateG1'), c.first(function (f, v) { return v.kind === 'step'; }) - 1); },
        compare: { cond: 'op', sameSeed: true, drawer: true, follow: true, view: 'close', at: function () { return 0; } },
        show: ALL, spot: null,
        ask: {
          q: "dbf4-zn lowers firing beside centromeres. What class are dbf4-zn stn1-OP spindles?",
          options: ["Short: nearer dbf4-zn alone than stn1-OP",
            "Extended: excess Stn1 does not need DDK",
            "Extended, because Dbf4 is a Rad53 target"],
          answer: 0,
          explain: "26% of dbf4-zn stn1-OP cells extend their spindles, against 10% of dbf4-zn cells and 53% of stn1-OP cells in the same experiment \\cite{Gasparayan2022yeast}. That reduction is smaller than the one dbf4-zn gives in rad53-21 cells."
        },
        text: "dbf4-zn alters the zinc finger of Dbf4, lowers firing most at the origins beside centromeres and keeps rad53-21 spindles short (chapter 8) \\cite{julius2019inhibition}. dbf4-zn also lowers spindle extension in stn1-OP cells into the short class \\cite{Gasparayan2022yeast}. Stn1 binds Dbf4 in a two-hybrid assay \\cite{Gasparayan2022yeast}, which made DDK a candidate target of excess Stn1.\n\nThe DDK arm stays inside the outline. Spindle extension by excess Stn1 needs full DDK activity, either because excess Stn1 acts through DDK or because it needs the firing that DDK supports beside centromeres.\n\nThe close-ups follow L1. Its DDK-mark meter climbs more slowly in dbf4-zn stn1-OP than in stn1-OP, so L1 fires later."
      },
      {
        chapter: '9. Excess Stn1', title: 'Without Dbf4, excess Stn1 still extends spindles', cond: 'opBob', layout: 'mol',
        grn: { live: 'hone8' }, grnLabel: 'Where excess Stn1 may first act', op: { live: true },
        figure: 'op-bob', figureLabel: 'Measured spindles',
        origin: function () { return 'L3'; }, follow: function () { return 'origin'; },
        from: function (c) { return c.at(c.sched.rad53At); }, to: function (c) { return c.lastWhere(function (f, v) { return v.kind === 'step'; }) + 2; },
        compare: { cond: 'bobHU', sameSeed: true, drawer: true, follow: true, view: 'close', at: function () { return 0; } },
        show: ALL, spot: null,
        ask: {
          q: "mcm5-bob1 dbf4Δ cells fire origins with no DDK, and most keep short spindles in HU. What class are mcm5-bob1 dbf4Δ stn1-OP spindles?",
          options: ["Extended, like stn1-OP",
            "Short: without Dbf4, excess Stn1 has nothing to act through",
            "Short in small buds and extended in large buds"],
          answer: 0,
          explain: "52% of mcm5-bob1 dbf4Δ stn1-OP cells extend their spindles in HU, against 9% of mcm5-bob1 dbf4Δ cells \\cite{Gasparayan2022yeast}."
        },
        text: "mcm5-bob1 lets cells fire origins without Dbf4, while Rad53 still phosphorylates Sld3 in HU (chapter 7) \\cite{zegerman2010checkpoint,Gasparayan2022yeast}. With no Dbf4 at all, stn1-OP spindles still extend \\cite{Gasparayan2022yeast}. DDK cannot be the only route for excess Stn1. The Sld3 arm stays inside the outline, since Rad53 still blocks that arm in these cells.\n\nThe outline stays the same size. Neither paper decides whether excess Stn1 acts on the Sld3 arm, the DDK arm or both.\n\nThe close-ups follow the late origin L3 after Rad53 comes on. In the stn1-OP cell L3 fires through the bob1 shape, whereas in mcm5-bob1 dbf4Δ on the left it waits. In the model mcm5-bob1 dbf4Δ fires few origins in HU, and its stn1-OP runs mostly keep short spindles. The model does not reproduce this spindle result, so the close-ups show only the firing step."
      },
      {
        chapter: '9. Excess Stn1', title: 'The Sld3 and DDK arms both act on the Mcm2-7 double hexamer', cond: 'op', layout: 'mol',
        grn: { live: 'hone9' }, grnLabel: 'Where excess Stn1 may first act', op: { live: true },
        figure: 'op-sum', figureLabel: 'Where the search ends',
        origin: function () { return 'R3'; }, follow: function () { return 'origin'; },
        from: function (c) { return c.first(function (f, v) { return v.kind === 'step'; }); },
        to: function (c) { return c.lastWhere(function (f, v) { return v.kind === 'step'; }) + 2; },
        steps: 40, interval: 700,
        show: ALL, spot: null,
        text: "Excess Stn1 leaves Rad53 activation and the Dun1 arm working, and late origins fire in stn1-OP cells while Rad53 is active \\cite{Gasparayan2009yeast}. Spindle extension by excess Stn1 needs Exo1, a full-strength helicase and full DDK activity, and it survives the loss of Dbf4 \\cite{Gasparayan2022yeast}. That leaves the Sld3 arm and the DDK arm, with the fork arm not separated from extra firing.\n\nThe close-up plays R3 firing in the stn1-OP cell: Sld3-Sld7 seats on the phosphorylated double hexamer and the helicase is activated, with no Stn1 drawn at the origin.\n\nNormal Stn1 contributes to rad53-21 spindle extension as well: stn1(1–186), which keeps only the N-terminal part of Stn1, keeps rad53-21 spindles short in HU \\cite{Gasparayan2022yeast}.\n\nThe Sld3 and DDK arms act on one complex. DDK phosphorylates the Mcm4 and Mcm6 tails of the Mcm2-7 double hexamer, which creates the sites that Sld3 binds \\cite{deegan2016phosphopeptide}. A protein that changes either step could do so by contacting Mcm2-7. The next question is whether CST binds subunits of Mcm2-7."
      },

      // --- 10. CST at Mcm2-7 ---------------------------------------------
      // The two-hybrid array of this dissertation, read as interactions above
      // the cutoff or not, then the proposed models drawn with the viewer's
      // own model panels, then the telomere question that follows.
      {
        chapter: '10. CST at Mcm2-7', title: 'A two-hybrid interaction places two proteins in one assembly', cond: 'wt', layout: 'fig',
        figure: 'y2h-read', figureLabel: 'The two-hybrid readout',
        from: function (c) { return c.phase('lateG1'); },
        show: ALL, spot: null,
        text: "Chapter 9 placed excess Stn1 on the Sld3 and DDK arms, which both act on the Mcm2-7 double hexamer. A contact between CST and Mcm2-7 is a physical claim, which takes a binding assay.\n\nIn the yeast two-hybrid assay, a bait protein fused to the GAL4 DNA-binding domain sits on a reporter promoter, and a prey protein fused to the GAL4 activation domain supplies the activity that promoter lacks. When bait and prey associate, the reporter is transcribed. The host strain carries three reporters: HIS3 and ADE2 let cells grow without histidine or adenine, and lacZ turns X-gal blue \\cite{james1996genomic}.\n\nThe assay runs in budding yeast, where the native partners of CST and Mcm2-7 are present. A native protein that binds both bait and prey turns on the reporters with no contact between them. An interaction therefore places two proteins in one assembly, either in contact or joined through a third protein.\n\nThe array of this dissertation crossed Cdc13, Stn1, Ten1 and the six Mcm subunits against one another, 36 pairs in all, and tested each pair with each protein as bait."
      },
      {
        chapter: '10. CST at Mcm2-7', title: 'Known partners set the cutoff for an interaction', cond: 'wt', layout: 'fig',
        figure: 'y2h-cut', figureLabel: 'The cutoff',
        from: function (c) { return c.phase('lateG1'); },
        show: ALL, spot: null,
        text: "Within CST each subunit contacts the other two \\cite{lim2020structure,grandin2001ten1}, and within Mcm2-7 each subunit contacts its two neighbours in the ring Mcm2-6-4-7-3-5. These pairs carry known answers, so their scores set the cutoff. Each pair scores up to 18 points over its two orientations, and a pair scoring 8 or more interacts. Each pair is drawn only as interacting or not.\n\nAt that cutoff 7 of the 9 known contacts interact. Pairs of Mcm subunits that do not touch interact 4 of 9 times, joined through the host ring. A contact clears the cutoff more often than a bridge does, and both can clear it."
      },
      {
        chapter: '10. CST at Mcm2-7', title: 'Every CST–Mcm2-7 interaction includes Mcm2 or Mcm5', cond: 'wt', layout: 'fig',
        figure: 'y2h-gate', figureLabel: 'Measured interactions',
        from: function (c) { return c.phase('lateG1'); },
        show: ALL, spot: null,
        ask: {
          q: "Which Mcm2-7 subunits interact with a CST subunit?",
          options: ["Mcm2 and Mcm5, the two subunits of the gate",
            "Mcm4 and Mcm6, whose tails DDK phosphorylates",
            "All six, joined through the host ring"],
          answer: 0,
          explain: "Five CST–Mcm2-7 pairs interact, each with Mcm2 or Mcm5. No CST subunit interacts with Mcm3, Mcm4, Mcm6 or Mcm7."
        },
        text: "Five of the 18 CST–Mcm2-7 pairs interact: Stn1-Mcm2, Ten1-Mcm5, Cdc13-Mcm2, Stn1-Mcm5 and Ten1-Mcm2. Each includes Mcm2 or Mcm5. Stn1-Mcm2 scores highest of the five, in both orientations. Stn1 and Cdc13 activate no reporter with Mcm4 in either orientation.\n\nMcm2 and Mcm5 form the gate through which ORC loads Mcm2-7 onto origin DNA \\cite{samel2014unique}. Mcm5 also carries the residue that mcm5-bob1 changes \\cite{Hardy1997}. The plates show the four baits behind every interaction at the gate."
      },
      {
        chapter: '10. CST at Mcm2-7', title: 'The interactions at Mcm2 fit direct contact better than a bridge', cond: 'wt', layout: 'fig',
        figure: 'y2h-bridge', figureLabel: 'Contacts and bridges',
        from: function (c) { return c.phase('lateG1'); },
        show: ALL, spot: null,
        text: "A native protein in the host could join a CST subunit to an Mcm subunit. Dbf4 binds Stn1 and anchors DDK on Mcm2 \\cite{Gasparayan2022yeast,caridi2016many,saleh2022structural}. Polymerase α binds Cdc13 and Stn1 and reaches the CMG through Ctf4 \\cite{grossi2004pol12,puglisi2008distinct,simon2014ctf4}. Host Mcm2-7 rings join subunits that do not touch.\n\nEach bridge predicts interactions with every subunit its bridging protein reaches. Dbf4 also contacts Mcm4 and Mcm6 \\cite{saleh2022structural,cheng2022structural}, yet Stn1 shows no interaction with either. Polymerase α would reach all six subunits, yet CST interacts with two. The host ring would join a partner of Mcm2 to Mcm4, yet Stn1 shows no interaction with Mcm4. These missing interactions weaken each bridge without excluding it.\n\nThree of the four Mcm pairs joined through the ring include Mcm5, so the CST interactions at Mcm5 are the likeliest to come from the ring. The interactions at Mcm2 fit direct contact best."
      },
      {
        chapter: '10. CST at Mcm2-7', title: 'All three CST subunits interact with Mcm2-7, as the CST-complex model predicts', cond: 'wt', layout: 'fig',
        figure: 'y2h-models', figureLabel: 'Two assemblies',
        from: function (c) { return c.phase('lateG1'); },
        show: ALL, spot: null,
        text: "Every result in chapter 9 came from excess Stn1, so Stn1 could act at origins on its own or as part of CST. In the Stn1-alone model, Stn1 acts on Mcm2-7 apart from Cdc13 and Ten1. In the CST-complex model, the whole complex sits at Mcm2-7. Cdc13 is essential, so the genetic experiments could not ask whether those results need Cdc13 \\cite{nugent1996cdc13}.\n\nCdc13, Stn1 and Ten1 each interact with Mcm2, and Stn1 and Ten1 also interact with Mcm5. Those interactions fit the CST-complex model. Each cell tested one pair, so the screen cannot show the three subunits bound at once. Where Stn1 outnumbers Cdc13 and Ten1, as in stn1-OP cells, Stn1 could still reach Mcm2-7 apart from them."
      },
      {
        chapter: '10. CST at Mcm2-7', title: 'CST interacts with the subunit that anchors DDK, whereas Sld3 binds Mcm4 and Mcm6', cond: 'wt', layout: 'fig',
        figure: 'y2h-sites', figureLabel: 'Where CST interacts',
        from: function (c) { return c.phase('lateG1'); },
        show: ALL, spot: null,
        text: "Chapter 9 ended on the Sld3 arm and the DDK arm. Dbf4 anchors DDK on the N-terminal domain of Mcm2 \\cite{saleh2022structural}, the subunit with which all three CST subunits interact. DDK then phosphorylates the Mcm4 and Mcm6 tails, which creates the sites that Sld3 binds \\cite{deegan2016phosphopeptide}. CST interacts with neither Mcm4 nor Mcm6.\n\nThe DDK arm therefore meets CST at Mcm2. The Sld3 arm meets CST only through Mcm2 and Mcm5, where Cdc45 seats across the gate after Sld3 arrives \\cite{noguchi2026structural}. A two-hybrid interaction names a subunit, so the surface CST sits beside stays unidentified."
      },
      {
        chapter: '10. CST at Mcm2-7', title: 'DDK-dependent route: three models raise the number of phosphorylated Mcm4 sites', cond: 'wt', layout: 'fig',
        figureLabel: 'Proposed models',
        routes: [
          { key: 'cstCONF', crop: [236, 56, 424, 226], model: 'conf', name: 'Mcm2-7 conformation model', title: 'CST bound to Mcm2-7 makes the Mcm4 NSD a better substrate for Cdc7' },
          { key: 'cstCDC7', crop: [236, 40, 424, 242], model: 'cdc7', name: 'Cdc7-retention model', title: 'CST keeps DDK acting on Mcm4 longer' },
          { key: 'cstRIF1', crop: [236, 56, 424, 226], model: 'rif1', name: 'Rif1-PP1 inhibition model', title: 'CST lowers Rif1-PP1 activity, which removes the same phosphates' }
        ],
        from: function (c) { return c.phase('lateG1'); },
        show: ALL, spot: null,
        text: "Stn1 dosage sets the level of DDK-dependent Mcm4 phosphorylation, which rises with excess Stn1 and falls in stn1 loss-of-function mutants \\cite{caridi2016many}. DDK adds those phosphates and Rif1-PP1 removes them, the balance each DDK-mark meter counts \\cite{mattarocci2014rif1,hiraga2014rif1}. Three proposals let CST at Mcm2 and Mcm5 shift that balance.\n\nIn the Mcm2-7 conformation model, CST bound to Mcm2-7 makes the Mcm4 NSD a better substrate for Cdc7. In the Cdc7-retention model, CST keeps DDK on Mcm4 longer, which gives Cdc7 more chances to reach the Mcm4 tail \\cite{cheng2022structural,saleh2022structural}. In the Rif1-PP1 inhibition model, CST lowers Rif1-PP1 activity. Without Rif1, full Mcm4 phosphorylation still needs Stn1, so Stn1 acts through at least one target besides Rif1-PP1 \\cite{caridi2016many}.\n\nEach row plays one model beside its network and the DDK-mark meter of a late origin. In each panel CST binds across the Mcm2 and Mcm5 rows, and DDK docks and phosphorylates the Mcm4 and Mcm6 tails. Dashed blue arrows and bars are proposals. One CST could carry all three, since all three act on the same phosphates.\n\nThe switch sets the cell with or without HU. In HU, Rad53 opposes DDK docking and keeps Sld3 off Mcm4, and the wild-type meter stays under the line. Each model lifts the stn1-OP meter past the line. Firing at a late origin also needs Sld3 to bind while Rad53 is on. The network draws that step as open. Measuring Sld3 at late origins in stn1-OP cells would test it."
      },
      {
        chapter: '10. CST at Mcm2-7', title: 'DDK-independent route: CST could act on Mcm5 and Sld3, on the exiting lagging strand, or on polymerase α', cond: 'wt', layout: 'fig',
        figureLabel: 'Proposed models',
        routes: [
          { key: 'cstBOB1', crop: [196, 40, 470, 242], model: 'bob1', name: 'Conformation model without DDK', title: 'CST alters the Mcm5 surface and carries Sld3 past Rad53' },
          { key: 'cstEJSS', crop: [180, 40, 520, 242], model: 'ejss', name: 'Lagging-strand ejection, ssDNA-binding mechanism', title: 'the Stn1 N-terminal fold binds the strand leaving the gate' },
          { key: 'cstEJPR', crop: [180, 40, 520, 242], model: 'ejpr', name: 'Lagging-strand ejection, protein-binding mechanism', title: 'the Stn1 C-terminal region binds Mcm2 and Mcm5' },
          { key: 'cstPOLA', crop: [170, 60, 540, 200], model: 'pola', name: 'Polymerase α', title: 'Stn1 stimulates priming once the origin has unwound' }
        ],
        from: function (c) { return c.phase('lateG1'); },
        show: ALL, spot: null,
        text: "Excess Stn1 still extends spindles in mcm5-bob1 dbf4Δ cells, whose Mcm2-7 carries no DDK phosphates (chapter 9) \\cite{Gasparayan2022yeast}. Three proposals give CST a route without DDK.\n\nIn the conformation model without DDK, CST alters the Mcm5 surface that Cdc45 engages, as the bob1 substitution is proposed to \\cite{simon2016structure}. Rad53 still keeps Sld3 off the double hexamer in these cells, so CST would also have to deliver Sld3 past that block \\cite{zegerman2010checkpoint}.\n\nIn the lagging-strand ejection model, CST at the gate raises the share of double hexamers whose CMGs eject their lagging strands as they pass each other \\cite{langston2023mechanism,douglas2018mechanism}. The Stn1 N-terminal fold could bind the exiting strand, or the Stn1 C-terminal region could bind Mcm2 and Mcm5. Ejection follows the arrival of Sld3, so this model needs no activity against Rad53.\n\nStn1 could also stimulate polymerase α through Pol12, once the origin has unwound \\cite{grossi2004pol12,lue2014cdc13}.\n\nEach row plays one model beside its network and the DDK-mark meter of a late origin. Dashed blue arrows are proposals. In the first panel the clasp rises into its seat once CST carries Sld3 past Rad53, with the Rad53 phosphate still on Sld3.\n\nThe switch sets the cell with or without HU. The ejection and polymerase α models leave the marks unchanged. In HU they raise firing at late origins only if Sld3 still reaches those origins while Rad53 is on. The network draws that step as open."
      },
      {
        chapter: '10. CST at Mcm2-7', title: 'The proposed models place CST on the Sld3 arm, the DDK arm or the firing step', cond: 'wt', layout: 'fig',
        figure: 'route-map', figureLabel: 'Where each model places CST',
        from: function (c) { return c.phase('lateG1'); },
        show: ALL, spot: null,
        text: "Chapter 9 left excess Stn1 inside the outlined region: the Sld3 arm, the DDK arm and the firing step, with the fork arm open. Each proposed model places CST on one or more of those steps.\n\nThe three DDK-dependent models act on the DDK arm, where each raises the number of phosphorylated Mcm4 sites (1 to 3). The conformation model without DDK acts on two steps: on the Sld3 arm, where CST carries Sld3 past Rad53, and at firing, where CST alters the Mcm5 surface that Cdc45 engages (4). The two ejection mechanisms act at firing after Sld3 binds (5, 6). Polymerase α stimulation acts once the origin has unwound, at the first priming or at forks, in elongation or fork restart (7) \\cite{grossi2004pol12,lue2014cdc13}. That last placement falls on the fork arm, which chapter 9 could not separate from extra firing.\n\nNone of the seven models acts on Rad53 activation, the Dun1 arm, Exo1 or the kinetochore. Separating them takes a measurement at each step they occupy."
      },
      {
        chapter: '10. CST at Mcm2-7', title: 'Purified proteins, Stn1 fragments, Sld3 at late origins and CST occupancy would separate the models', cond: 'wt', layout: 'fig',
        figure: 'y2h-tests', figureLabel: 'Next measurements',
        from: function (c) { return c.phase('lateG1'); },
        show: ALL, spot: null,
        text: "Purified CST and Mcm2-7 subunits, mixed without the host, would show whether CST touches Mcm2-7 or reaches it through a bridge. Stn1 fragments paired with Mcm2 and Mcm5 would show which half of Stn1 makes the contact: the N-terminal fold binds Ten1 and single strands, whereas the C-terminal region binds Cdc13 and Pol12 \\cite{sun2009stn1,puglisi2008distinct}.\n\nSld3 at late origins in stn1-OP cells in MMS would separate the models that act before Sld3 arrives from those that act after, as the same measurement did for excess Dbf4 \\cite{Tanaka2011Origin}. Genome-wide ChIP of each CST subunit through S phase would show whether Cdc13 and Ten1 occupy the origins that Stn1 occupies, as the CST-complex model predicts.\n\nThe open question at origins is whether CST touches Mcm2-7 directly, and at which step of firing."
      },
      {
        chapter: '10. CST at Mcm2-7', title: 'If CST acts at both origins and telomeres, origin firing could change CST function at telomeres', cond: 'wt', layout: 'fig',
        figure: 'tel-q', figureLabel: 'The reciprocal question',
        from: function (c) { return c.phase('lateG1'); },
        show: ALL, spot: null,
        text: "All three CST subunits cap telomeres \\cite{xu2009ten1}, and Cdc13 recruits telomerase \\cite{nugent1996cdc13}. In the CST-complex model the same complex acts on Mcm2-7 at origins. CST changes origin firing (chapters 9 and 10), which raises the reciprocal question: whether a change in origin firing changes CST function at telomeres.\n\nTwo alleles can ask it. dbf4-1 weakens DDK and origin firing, and excess Stn1 suppresses its temperature sensitivity \\cite{caridi2016many,hsieh2012using}. cdc13-2 caps telomeres but recruits too little telomerase, so telomeres shorten with each division until the cells senesce \\cite{nugent1996cdc13}."
      },
      // --- 11. Telomeres through one cell cycle ---------------------------
      {
        chapter: '11. Telomeres through one cell cycle', title: 'Each sister chromatid keeps one parental strand and gains one new strand', cond: 'wt',
        view: 'tel', telSite: 'tel-R-s1', layout: 'chrom', show: ALL,
        from: FIRE,
        to: function (c) { return Math.max(FIRE(c), OFF(c, 'R')); },
        spot: { boxes: [BOX.tel] },
        text: function (c) {
          var one = c.sched.one, r = one.forks[1], l = one.forks[0];
          return "Replication is semiconservative. The two parental strands separate, and each serves as the template for a new strand, so each daughter duplex carries one parental strand and one new strand \\cite{meselson1958replication}. Each fork copies one template continuously, the leading strand, and the other in Okazaki fragments, the lagging strand. Both new strands grow 5\u2032 to 3\u2032, so the leading strand is the new strand that runs toward the fork.\n\nThe telomere chapter sets the origin program aside and follows a hypothetical chromosome with one origin. The origin opens as its two CMG helicases separate, the step 9 to 10 transition of the origin chapter, and one fork runs toward each end. Dark strands are parental and light strands are new. Sister 1 keeps the parental top strand and sister 2 the parental bottom strand. At the right fork the leading strand is sister 2\u2019s new top strand; at the left fork it is sister 1\u2019s new bottom strand. Both arms are " + one.leftKb + " kb, so the two forks reach the two ends together, " + Math.round((r.t1 - r.t0) * 10) / 10 + " min after firing, and the four daughter ends start their steps at one moment.";
        }
      },
      {
        chapter: '11. Telomeres through one cell cycle', title: 'A fork that reaches an end makes a blunt leading-made end and a lagging-made end with a short overhang', cond: 'wt',
        view: 'tel', telSite: 'tel-R-s1', layout: 'mol', chrom: true, show: ALL, zoom: ENDZOOM,
        closeLabel: 'Lagging-made end: TEL-R, sister 1',
        compare: { cond: 'wt', sameSeed: true, drawer: true, follow: true, view: 'close', at: function () { return 0; },
          focus: function () { return ['tel-R-s2', 'right']; }, label: 'Leading-made end: TEL-R, sister 2' },
        from: function (c) { return INTO(c, 'R'); },
        to: function (c) { return Math.max(TS(c, 'tel-R-s1', 'lag01'), TE(c, 'tel-R-s1', 'lag01')); },
        spot: null,
        text: function (c) {
          var hit = c.sched.telomeres['TEL-R'];
          return "Leading-strand synthesis copies the parental C-rich strand to the chromosome end and leaves a blunt or nearly blunt end \\cite{pospiech2003dna,nelson2012blunt,wu2012telomeric}. Lagging-strand synthesis cannot start a fragment at the very end, so the lagging-made end keeps a short 3\u2032 overhang \\cite{lingner1995telomerase,soudet2014elucidation}. The two ends of one chromosome therefore start differently \\cite{parenteau2002differential}. G-tails form late in S, and only on telomeres a fork has copied \\cite{wellinger1996evidence,dionne1998processing}.\n\nThe panel zooms in on the right end. The G-rich strand runs 5\u2032 to 3\u2032 toward each tip, so the right fork\u2019s leading strand is sister 2\u2019s new G-rich strand and its lagging strand sister 1\u2019s new C-rich strand. In this run both forks run off their tips " + Math.round(hit.t * 10) / 10 + " min after G1/S. Each daughter starts 3 bp shorter than its parent, the loss per end per generation without telomerase \\cite{marcand1999progressive}. The close-ups follow the two right ends side by side: the leading-made end of sister 2 on the left and the lagging-made end of sister 1 on the right, each drawn by the telomere workflow panels.";
        }
      },
      {
        chapter: '11. Telomeres through one cell cycle', title: 'Cdk1-dependent resection turns both daughter ends into 3\u2032 overhangs', cond: 'wt',
        view: 'tel', telSite: 'tel-R-s1', layout: 'mol', chrom: true, show: ALL, zoom: ENDZOOM,
        closeLabel: 'Lagging-made end: TEL-R, sister 1',
        compare: { cond: 'wt', sameSeed: true, drawer: true, follow: true, view: 'close', at: function () { return 0; },
          focus: function () { return ['tel-R-s2', 'right']; }, label: 'Leading-made end: TEL-R, sister 2' },
        from: function (c) { return TS(c, 'tel-R-s2', 'step02'); },
        to: function (c) { return Math.max(TS(c, 'tel-R-s2', 'step02'), TE(c, 'tel-R-s2', 'step03')); },
        spot: null,
        text: "Telomerase extends a single-stranded 3\u2032 overhang. Cdk1 is required both to make the overhang and for telomere addition \\cite{frank2006regulation}. The leading-made end is resected from its blunt start and then filled in \\cite{soudet2014elucidation}. MRX is found mainly at the leading-made end, and Cdc13 and telomerase bind that end through MRX \\cite{faure2010cdc13}. The lagging-made end already has a short overhang and needs less processing.\n\nIn the model the leading-made end takes three steps: the blunt end, Cdk1-phosphorylated Sae2 with MRX, then resection, and Cdc13 loads 4 min after its fork arrives. The lagging-made end takes two, the short overhang and its resection, and Cdc13 loads after 2 min. Both times are drawing values. The overhang is drawn at 30 nt."
      },
      {
        chapter: '11. Telomeres through one cell cycle', title: 'Cdc13 on the overhang holds each end open to telomerase until late G2', cond: 'wt',
        view: 'tel', telSite: 'tel-L-s1', layout: 'both', show: ALL,
        from: function (c) { return TS(c, 'tel-L-s1', 'step04'); },
        to: function (c) { return Math.max(TS(c, 'tel-L-s1', 'step04'), TE(c, 'tel-L-s1', 'step04')); },
        spot: { boxes: [TELBOX['tel-L-s1'], TELBOX['tel-L-s2'], TELBOX['tel-R-s1'], TELBOX['tel-R-s2']] },
        text: function (c) {
          var d = dEnd(c, 'tel-L-s1');
          return "Cdc13 binds the single-stranded G-rich overhang \\cite{nugent1996cdc13}. Cdk1 phosphorylates Cdc13, which favours its binding to Est1 over Stn1-Ten1 and recruits telomerase \\cite{li2009cdk1}. Est1 and Est2 come to telomeres in late S and G2 \\cite{taggart2002est1p,sabourin2007telomerase}. Telomere addition still occurs in cells arrested in M phase \\cite{Diede1999}.\n\nIn the model each end can recruit telomerase from the moment Cdc13 loads until 6 min before anaphase, which comes 20 min after the last stretch is copied. A late-copied end therefore has a shorter window. On this chromosome both ends are copied at once, so the windows differ by strand: a leading-made end loads Cdc13 2 min after a lagging-made end. In this run sister 1\u2019s left end has a " + Math.round(d.window[1] - d.window[0]) + "-min window and a " + pct(d.pExtend) + " chance of telomerase this cycle. Telomerase reaches " + ['none', 'one', 'two', 'three', 'all'][nExt(c)] + " of the four ends.";
        }
      },
      {
        chapter: '11. Telomeres through one cell cycle', title: 'Telomerase reaches few ends each cycle, and short ends most often', cond: 'telShort',
        view: 'tel', telSite: 'tel-R-s1', layout: 'both', show: ALL,
        from: function (c) { return TS(c, 'tel-R-s1', 'step04'); },
        to: function (c) { return Math.max(TS(c, 'tel-R-s1', 'step04'), TE(c, 'tel-R-s1', 'step05')); },
        spot: { boxes: [TELBOX['tel-R-s1'], BOX.tert] },
        ask: {
          q: "About 7% of 300 bp ends are extended in a cell cycle. What share of 125 bp ends is extended?",
          options: ["About 40%: telomerase reaches short ends more often",
            "About 7%: telomerase reaches ends at random",
            "None: Cdc13 does not bind short ends"],
          answer: 0,
          explain: "Single-telomere sequencing found that extension rises from about 7% of ends at 300 bp to about 39% at 125 bp \\cite{teixeira2004telomere,chang2007telomerase}. Tel1 is enriched at short ends from early S and is required for telomerase to prefer them \\cite{sabourin2007telomerase}."
        },
        text: function (c) {
          var d = dEnd(c, 'tel-R-s1');
          return "Telomerase does not act on every end in every cycle, and it prefers short ends \\cite{teixeira2004telomere}. Tel1 marks short ends and directs telomerase to them \\cite{sabourin2007telomerase}. Rif1 and Rif2 keep Tel1 off long ends \\cite{hirano2009rif1}. Deleting RIF1 or RIF2 raises how often ends are extended \\cite{teixeira2004telomere}.\n\nIn the model recruitment is a random event. Its rate falls with the end\u2019s Rap1 sites, for Tel1, and with the Rif1 the end holds. The two constants are solved so that an end of 300 bp is extended 7% of the time and an end of 125 bp 39% of the time, over the mean window of a wild-type end. Telomerase in the model is 2 copies: the 29 TLC1 RNAs of a haploid cell \\cite{mozdy2006low}, shared over the 16 real ends each model end stands for. In this run both ends start at 125 bp, and sister 1\u2019s right end had a " + pct(d.pExtend) + " chance. Telomerase reached it.";
        }
      },
      {
        chapter: '11. Telomeres through one cell cycle', title: 'Telomerase adds a variable number of repeats, more to short ends', cond: 'telShort',
        view: 'tel', telSite: 'tel-R-s1', layout: 'both', show: ALL,
        from: function (c) { return TS(c, 'tel-R-s1', 'step06'); },
        to: function (c) { return Math.max(TS(c, 'tel-R-s1', 'step06'), TE(c, 'tel-R-s1', 'step07')); },
        spot: { boxes: [TELBOX['tel-R-s1'], BOX.tert] },
        text: function (c) {
          var d = dEnd(c, 'tel-R-s1');
          return "Est1 bridges TLC1 to Cdc13, and Est2 copies the RNA template onto the G-rich strand \\cite{lingner1997reverse,evans2002est1}. One extension adds from a few nucleotides to more than 100 \\cite{teixeira2004telomere}. Ends of over 200 bp gain about 44 nt on average. Ends under 125 bp gain about 102 nt, a gain that depends on Tel1 \\cite{chang2007telomerase}. Pif1 and Ipl1 then remove telomerase.\n\nIn the model the nucleotides added are drawn from an exponential with that mean, set by the end\u2019s length. In this run telomerase adds " + d.added + " nt to sister 1\u2019s right end, from " + d.bp0 + " to " + d.bp1 + " bp. While it works, it holds one of the 2 telomerase copies.";
        }
      },
      {
        chapter: '11. Telomeres through one cell cycle', title: 'Stn1-Ten1 and Pol \u03b1 fill in the C-strand, and the end is capped', cond: 'telShort',
        view: 'tel', telSite: 'tel-R-s1', layout: 'both', show: ALL,
        from: function (c) { return TS(c, 'tel-R-s1', 'step08'); },
        to: function (c) { return Math.max(TS(c, 'tel-R-s1', 'step08'), TS(c, 'tel-R-s1', 'step09') + 1); },
        spot: { boxes: [TELBOX['tel-R-s1']] },
        text: "Stn1-Ten1 joins Cdc13 on the overhang. Stn1 binds Pol12, the B subunit of DNA polymerase \u03b1, which fills in the C-strand \\cite{grossi2004pol12}. Stn1 is the main effector of end protection, and Cdc13 the platform that loads it \\cite{pennock2001cdc13}. The filled-in end, with Rap1 on its duplex and CST on its short overhang, is capped.\n\nIn the model an end telomerase reaches is filled in once telomerase is removed. An end it does not reach is filled in at the close of its window. Rap1, and the Rif1 it holds, bind the new repeats from the next cycle."
      },
      {
        chapter: '11. Telomeres through one cell cycle', title: 'An end loses about 3 bp a cycle and gains about 3 bp on average, so wild-type length holds steady', cond: 'wt',
        view: 'tel', telSite: 'tel-R-s2', layout: 'chrom', show: ALL,
        from: FIRE, to: function (c) { return c.last; },
        spot: { boxes: [BOX.tel] },
        text: "Without telomerase an end loses about 3 bp per generation, whatever its length \\cite{marcand1999progressive}. Telomere length holds steady because telomerase switches between extending and not extending an end, and extends short ends more often \\cite{teixeira2004telomere}.\n\nThe average gain per cycle is the chance of extension times the mean added. At 300 bp that is 7% of 44 nt, about 3 bp: the loss and the gain balance near the wild-type length. At 125 bp it is 39% of 102 nt, about 40 bp, so a short end regains length within a few cycles. The model takes both inputs from the measurements, so this balance is a check on them and not a result of the model. One cycle of the model is shown here; following ends over passages comes next."
      },
      {
        chapter: '11. Telomeres through one cell cycle', title: 'cdc13-2 ends are never extended, so every end shortens each cycle', cond: 'telCdc13',
        view: 'tel', telSite: 'tel-R-s1', layout: 'both', show: ALL,
        from: FIRE, to: function (c) { return c.last; },
        spot: { boxes: [TELBOX['tel-L-s1'], TELBOX['tel-L-s2'], TELBOX['tel-R-s1'], TELBOX['tel-R-s2']] },
        text: "Cdc13 gives telomerase access to the chromosome end. cdc13-2 cells keep telomerase activity, but they lose telomere sequence progressively and senesce, the est phenotype \\cite{nugent1996cdc13}. Fusing Est2 to the DNA-binding domain of Cdc13 restores telomere replication \\cite{pennock2001cdc13}. Cells without Est2 also senesce \\cite{lendvay1996}.\n\nIn the model cdc13-2 ends recruit no telomerase. Every daughter end ends the cycle 3 bp shorter than its parent, and the ends are still filled in and capped. In the dissertation the cdc13-2 senescence curve is the baseline for the double mutant on the next slide."
      },
      {
        chapter: '12. Weaker origin firing and senescence', title: 'A dbf4-1 cdc13-2 double mutant tests whether weaker origin firing changes senescence', cond: 'wt', layout: 'fig',
        figure: 'tel-test', figureLabel: 'The next test',
        from: function (c) { return c.phase('lateG1'); },
        show: ALL, spot: null,
        text: "A dbf4-1 cdc13-2 double mutant asks whether reduced DDK activity changes the severity of cdc13-2 senescence. A change could follow either of two mechanisms. Under the elongation mechanism, telomerase reaches cdc13-2 telomeres more often, so telomeres shorten more slowly. Under the capping mechanism, telomeres shorten at the same rate while CST occupies more ends, so fewer ends signal the checkpoint at a given length. The rate of shortening separates the two.\n\nBulk telomere length assays pool every end in every cell, whereas each lineage arrests on its shortest telomere \\cite{xu2015two}. Severity therefore takes the form of a distribution: the passage at which each lineage stops growing \\cite{xu2015two,xie2015early,xu2019heterogeneity}. QuantaColony measures that distribution from the colonies formed at each passage. The next question is whether dbf4-1 shifts the passages at which cdc13-2 lineages stop growing."
      }
    ]
  };
}());
