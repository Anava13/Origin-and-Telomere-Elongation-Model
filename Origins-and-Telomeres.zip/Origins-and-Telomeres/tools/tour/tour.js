/* The guided lesson, run on top of the built viewer.

   tools/make_tour.py copies dist/origins-and-telomeres.html and adds this
   script, tour.css and the lesson (tools/tour/lesson-hu.js). The viewer's own
   engine draws every picture: the tour only chooses the run, the frames, the
   panels, the zoom and what stays lit, and writes the words beside them.

   A beat names a condition, a stretch of frames, a layout (chromosome, both
   scales, close-up first, or two cells side by side), a zoom box in panel
   units, the things to keep lit, a caption and, for some beats, a prediction
   asked before the beat plays. Stretches are anchored on events in the run
   (Rad53 on, the kinetochore lost, S complete), found in the run's schedule
   when the beat opens, so a retuned rule moves the anchors with it. */

var TOUR = { lesson: null, at: 0, timer: null, runs: {}, answered: {}, overlayKey: null, settle: null, problems: [] };

// === BASE CONTROLLER: runTour =============================================

function runTour(command, arg) {
  // BASE CONTROLLER: every reader action enters here.

  if (command === 'init') { startTour(); return; }
  if (command === 'go') { openBeat(arg); return; }
  if (command === 'next') { openBeat(Math.min(TOUR.at + 1, TOUR.lesson.beats.length - 1)); return; }
  if (command === 'back') { openBeat(Math.max(TOUR.at - 1, 0)); return; }
  if (command === 'replay') { playBeat(currentBeat()); return; }
  if (command === 'answer') { answerQuestion(arg); return; }
  if (command === 'frame') { syncCompare(arg); followSpot(); settleSpot(); return; }
  if (command === 'clear') { clearAnswers(); return; }

  function clearAnswers() {
    // SUB-CONTROLLER: forget every prediction and ask the current beat's again

    forget();
    openBeat(TOUR.at);

    function forget() {
      // MODEL: no beat answered (TERMINAL)
      TOUR.answered = {};
    }
  }

  // === SUB-CONTROLLERS ===

  function startTour() {
    // SUB-CONTROLLER: lay out the page, find each condition's run, open the first beat

    TOUR.lesson = window.TOUR_LESSON;
    mountLayout();
    TOUR.problems = checkIntroductions(TOUR.lesson);
    TOUR.runs = findRuns(TOUR.lesson.conditions);
    hookFrames();
    openBeat(0);
    revealTour();

    function mountLayout() {
      // VIEW: move the stage and the close-up into the tour's slots, hide the rest (TERMINAL)
      var root = document.createElement('div'), badge = (window.TOUR_FIGURES || {})['stn1-badge'] || 'stn1-OP';
      root.id = 'tour';
      root.innerHTML = '<div class="tvis"><div class="tcell" id="tcellN"><div class="tlab">Network so far</div>'
        + '<div id="tnet"></div></div><div class="tcell" id="tcellD"><div class="tlab" id="tlabD">Model key</div>'
        + '<div class="tfigbox" id="tfig"></div></div><div class="tcell" id="tcellA"><div class="tlab" id="tlabA"></div>'
        + '<div class="tframe" id="tframeA"></div></div>'
        + '<div class="tcell" id="tcellB"><details id="tdrawer" open><summary class="tlab" id="tlabB"></summary>'
        // On the molecular slides the genotype is a horizontal title of its
        // own and the summary above shrinks to the chevron toggle.
        + '<div class="tlab tgeno" id="tgenoB"></div>'
        + '<div class="topbadge" id="topbadgeB">' + badge + '</div>'
        + '<div class="tframe" id="tframeB"></div><div class="tgrn" id="tgrnB"></div></details></div>'
        + '<div class="tcell" id="tcellC"><div class="tlab" id="tlabC">Close-up</div>'
        + '<div class="topbadge" id="topbadgeC">' + badge + '</div><div class="tclose" id="tclose"></div>'
        + '<div class="tgrn" id="tgrnC"></div></div></div>'
        // The navigation pane heads the card and stays put while the card's
        // text scrolls under it, so Back, Replay and Next never move between
        // slides. The two menus reach any chapter and any slide by title.
        + '<aside class="tcard"><nav class="tnavpane" aria-label="Lesson navigation">'
        + '<div class="tnav"><button type="button" id="tback">Back</button>'
        + '<button type="button" id="treplay">Replay</button>'
        + '<span class="tcount" id="tcount"></span>'
        + '<button type="button" id="tnext" class="primary">Next</button></div>'
        + '<label class="tjump">Chapter <select id="tchapsel" aria-label="chapter"></select></label>'
        + '<label class="tjump">Slide <select id="tslidesel" aria-label="slide"></select></label></nav>'
        + '<div class="tbody"><div class="tchap" id="tchap"></div><h2 id="ttitle"></h2>'
        + '<div class="ttext" id="ttext"></div>'
        + '<div class="task" id="task" hidden></div>'
        + '<button type="button" id="tclear" class="tclear">Clear all answers</button>'
        // The slide's references close the card.
        + '<div class="trefbox" id="trefs"></div></div></aside>';
      document.getElementById('app').appendChild(root);
      document.getElementById('tframeA').appendChild(document.getElementById('stage'));
      document.getElementById('tclose').appendChild(document.getElementById('chrinset'));
      document.body.classList.add('touring');
      document.getElementById('tback').addEventListener('click', function () { runTour('back'); });
      document.getElementById('tnext').addEventListener('click', function () { runTour('next'); });
      document.getElementById('treplay').addEventListener('click', function () { runTour('replay'); });
      document.getElementById('tclear').addEventListener('click', function () { runTour('clear'); });
      document.getElementById('task').addEventListener('click', function (ev) {
        var k = ev.target && ev.target.getAttribute && ev.target.getAttribute('data-opt');
        if (k !== null && k !== undefined) { runTour('answer', +k); }
      });
      // The drawer's state is written on .tvis for tour.css to read, in place of a :has() selector.
      root.querySelector('.tvis').setAttribute('data-drawer-open', 'yes');
      document.getElementById('tdrawer').addEventListener('toggle', function (ev) {
        root.querySelector('.tvis').setAttribute('data-drawer-open', ev.target.open ? 'yes' : 'no');
        refreshSpot();
      });
      document.getElementById('tchapsel').addEventListener('change', function (ev) {
        runTour('go', +ev.target.value);
      });
      document.getElementById('tslidesel').addEventListener('change', function (ev) {
        runTour('go', +ev.target.value);
      });
      window.selectStep('chrLIVE');
    }

    function revealTour() {
      // VIEW: show the page, which tour.css keeps hidden until the first slide is in place (TERMINAL)
      document.body.classList.add('tourready');
    }

    function checkIntroductions(lesson) {
      // MODEL: every feature a beat shows was introduced at or before it (TERMINAL)
      // A beat names the features it introduces and the ones it shows; a
      // feature shown before the beat that introduces it is listed, and the
      // console says so, so a reordered lesson cannot show an unexplained part.
      var seen = {}, out = [];
      lesson.beats.forEach(function (b, n) {
        (b.introduce || []).forEach(function (f) { seen[f] = true; });
        (b.show || []).forEach(function (f) {
          if (!seen[f]) { out.push('beat ' + (n + 1) + ' shows ' + f + ' before introducing it'); }
        });
      });
      if (out.length && typeof console !== 'undefined') { console.warn('tour: ' + out.join('; ')); }
      return out;
    }

    function findRuns(conditions) {
      // MODEL: each condition's switches and seed; a condition in HU plays its strain's typical run (TERMINAL)
      var out = {}, key, c, p;
      for (key in conditions) {
        if (Object.prototype.hasOwnProperty.call(conditions, key)) {
          c = JSON.parse(JSON.stringify(conditions[key]));
          if (c.preset) {
            // A slide strain plays its typical run, found when the lesson was
            // built (TOUR_PRESETS) or, failing that, here.
            p = (window.TOUR_PRESETS || {})[c.preset]
              || CHROM_RULE.PRESETS.filter(function (q) { return q.key === c.preset; })[0];
            c.seed = p.seed || CHROM_RULE.medianRun(p, 301).seed;
            c.hu = true;
            c.checkpoint = p.checkpoint;
            c.alleles = JSON.parse(JSON.stringify(p.alleles || {}));
            c.ak = p.ak || 'none';
            c.when = p.when || 'at';
          }
          out[key] = c;
        }
      }
      return out;
    }

    function hookFrames() {
      // VIEW: redraw the spotlight whenever the chromosome panel changes frame (TERMINAL)
      var previous = window.onFrameChange;
      window.onFrameChange = function (key, frame, total, playing) {
        if (typeof previous === 'function') { previous(key, frame, total, playing); }
        if (key === 'chrLIVE') { runTour('frame', frame); }
      };
    }
  }

  function openBeat(n) {
    // SUB-CONTROLLER: install the beat's run, place the camera, write the card, then play or ask

    var beat;
    stopPlaying();
    TOUR.at = n;
    beat = currentBeat();
    installRun(beat);
    beat.range = resolveRange(beat);
    showLayout(beat);
    showFeatures(beat);
    showFigure(beat);
    showGrn(beat);
    showOverproduced(beat);
    showNetwork(beat);
    window.runAnimation('goto', beat.range[0]);
    showCompare(beat);
    writeCard(beat, n);
    refreshSpot();
    settleSpot();
    if (beat.ask && TOUR.answered[n] === undefined) { showQuestion(beat, n); } else { playBeat(beat); }

    function installRun(beat) {
      // MODEL: the beat's condition, origin and camera installed as the live run (TERMINAL)
      var c = TOUR.runs[beat.cond];
      CHROM_LIVE.genotype = c.genotype || 'wt';
      CHROM_LIVE.bob1 = !!c.bob1;
      CHROM_LIVE.hu = !!c.hu;
      CHROM_LIVE.checkpoint = c.checkpoint || 'wt';
      CHROM_LIVE.alleles = JSON.parse(JSON.stringify(c.alleles || {}));
      CHROM_LIVE.ak = c.ak || 'none';
      CHROM_LIVE.preset = null;
      CHROM_LIVE.presetRun = null;
      CHROM_LIVE.focus = beat.origin ? beat.origin(ctxFor(null)) : 'L1';
      CHROM_LIVE.follow = beat.follow ? beat.follow(ctxFor(null)) : 'origin';
      CHROM_LIVE.seed = c.seed;
      // A beat may show the telomere view (view: 'tel'), with one end in the
      // close-up (telSite); a condition may set the ends' length (telBp).
      CHROM_LIVE.view = beat.view === 'tel' ? 'tel' : 'chrom';
      CHROM_LIVE.telFocus = beat.telSite || 'tel-R-s1';
      CHROM_LIVE.telBp = c.telBp === undefined ? null : c.telBp;
      // A telomere beat that compares two ends of one run samples both ends'
      // steps frame by frame, so the two close-ups keep one clock.
      CHROM_LIVE.alsoSites = beat.view === 'tel' && beat.compare && beat.compare.focus
        ? [beat.compare.focus(null)[0]] : null;
      // A beat whose comparison follows the run samples both runs on one clock.
      CHROM_LIVE.pair = (beat.compare && beat.compare.follow) ? compareSched(beat) : null;
      window.runChromLive('replay');
      window.runChromLive('view', CHROM_LIVE.view);
      window.runAnimation('pause');
      if (beat.origin || beat.follow) {
        CHROM_LIVE.focus = beat.origin ? beat.origin(ctxFor(CHROM_LIVE.sched)) : 'L1';
        CHROM_LIVE.follow = beat.follow ? beat.follow(ctxFor(CHROM_LIVE.sched)) : 'origin';
        window.runChromLive('focus', CHROM_LIVE.focus);
        window.runChromLive('follow', CHROM_LIVE.follow);
        window.runAnimation('pause');
      }
    }

    function resolveRange(beat) {
      // MODEL: the beat's first and last frame, from its event anchors (TERMINAL)
      var ctx = ctxFor(CHROM_LIVE.sched), last = ctx.frames.length - 1;
      var a = Math.max(0, Math.min(last, beat.from(ctx)));
      var b = Math.max(a, Math.min(last, beat.to ? beat.to(ctx) : a));
      return [a, b];
    }

    function showLayout(beat) {
      // VIEW: which cells show, and the zoom on the chromosome panel (TERMINAL)
      var vis = document.querySelector('#tour .tvis');
      var svg = document.querySelector('#stage svg.panelsvg[data-key="chrLIVE"]');
      var z = beat.zoom || [0, 0, 880, 300], s = Math.min(880 / z[2], 300 / z[3]);
      var x0 = z[0] - (880 / s - z[2]) / 2, y0 = z[1] - (300 / s - z[3]) / 2;
      vis.setAttribute('data-layout', beat.layout || 'chrom');
      document.getElementById('tlabC').textContent = beat.layout === 'mol' ? (beat.closeLabel || TOUR.lesson.labels[beat.cond]) : 'Close-up';
      // A molecular beat may keep the chromosome panel above its two close-ups.
      vis.setAttribute('data-chrom', beat.layout === 'mol' && beat.chrom ? 'yes' : 'no');
      document.getElementById('tlabA').textContent = TOUR.lesson.labels[beat.cond];
      // A label that names the strain and condition is set large and bold above its panel.
      document.getElementById('tlabA').classList.add('tgeno');
      document.getElementById('tlabB').classList.add('tgeno');
      document.getElementById('tlabC').classList.toggle('tgeno', beat.layout === 'mol');
      if (svg) {
        svg.style.transformOrigin = '0 0';
        svg.style.transform = 'scale(' + s.toFixed(3) + ') translate(' + (-x0 / 880 * 100).toFixed(2) + '%, '
          + (-y0 / 300 * 100).toFixed(2) + '%)';
      }
    }

    function showFeatures(beat) {
      // VIEW: hide every chromosome-panel feature this beat does not show (TERMINAL)
      var tag = document.getElementById('tourfeat'), hide;
      if (!tag) {
        tag = document.createElement('style');
        tag.id = 'tourfeat';
        document.head.appendChild(tag);
      }
      hide = TOUR.lesson.features.filter(function (f) { return (beat.show || []).indexOf(f) < 0; });
      tag.textContent = hide.map(function (f) {
        return '#tour svg [data-feat~="' + f + '"]';
      }).join(',\n') + (hide.length ? ' { display: none !important; }' : '');
    }

    function showCloseCompare(beat, holder) {
      // VIEW: the other condition's close-up in the drawer, a copy of the close-up painted by the engine (TERMINAL)
      // The copy's definitions take the prefix cmp-, and so do the step panels
      // it copies on first use, so nothing in it points into the live close-up.
      var src = document.getElementById('chrinset'), html, defs = [], c, sched, wrap, root;
      html = src.outerHTML;
      Array.prototype.forEach.call(src.querySelectorAll('clipPath[id], pattern[id], linearGradient[id], marker[id]'),
        function (d) { var st = d.closest('svg.cistep'); if (!st || !/^step/.test(st.getAttribute('data-step') || '')) { defs.push(d.id); } });
      defs.forEach(function (id) {
        var safe = id.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        html = html.replace(new RegExp('id="' + safe + '"', 'g'), 'id="cmp-' + id + '"')
          .replace(new RegExp('url\\(#' + safe + '\\)', 'g'), 'url(#cmp-' + id + ')');
      });
      wrap = document.createElement('div');
      wrap.className = 'tclose';
      wrap.innerHTML = html;
      root = wrap.firstChild;
      // Step-panel copies made at run time are dropped; the copy makes its own on first use.
      Array.prototype.forEach.call(root.querySelectorAll('svg.cistep'), function (e) {
        if (/^step/.test(e.getAttribute('data-step') || '')) { e.parentNode.removeChild(e); }
      });
      root.id = 'chrinset-cmp';
      root.setAttribute('data-ciprefix', 'cmp-');
      ['ciframe', 'ciview', 'cicam'].forEach(function (k) { delete root.dataset[k]; });
      holder.appendChild(wrap);
      sched = compareSched(beat);
      TOUR.cmpSched = sched;
      // The same origin and camera as the live close-up, so the two show one
      // place; a beat may instead name its own (compare.focus returns
      // [origin, camera] for the other run), which then plays no firing in
      // slow motion, so the two clocks stay together.
      var own = beat.compare.focus ? beat.compare.focus(sched) : null;
      TOUR.cmpInset = { root: root, table: buildChromFrames(sched, CHROM_GEOM, own ? own[0] : CHROM_LIVE.focus,
        own ? own[1] : CHROM_LIVE.follow, own ? [] : window.interludeSteps(), beat.compare.follow ? CHROM_LIVE.sched : null,
        sched.one ? [CHROM_LIVE.telFocus] : null) };
      document.getElementById('tlabB').textContent = beat.compare.label
        || (TOUR.lesson.labels[beat.compare.cond] + ', the same minute');
      document.getElementById('tgenoB').textContent = document.getElementById('tlabB').textContent;
      syncCompare(beat.range[0]);
    }

    function showNetwork(beat) {
      // VIEW: the network strip, its nodes lit as the lesson has shown them, the tested one marked (TERMINAL)
      var box = document.getElementById('tnet'), net = beat.network, figs = window.TOUR_FIGURES || {};
      document.querySelector('#tour .tvis').setAttribute('data-network', net ? 'yes' : 'no');
      if (!net) { return; }
      if (!box.firstChild) { box.innerHTML = figs.network || ''; }
      Array.prototype.forEach.call(box.querySelectorAll('.tnet'), function (g) {
        var key = g.id.replace('tnet-', '');
        g.classList.toggle('on', (net.on || []).indexOf(key) >= 0 || (net.focus || []).indexOf(key) >= 0);
        g.classList.toggle('focus', (net.focus || []).indexOf(key) >= 0);
      });
    }

    function showGrn(beat) {
      // VIEW: the Rad53 network for each close-up's genotype, under that close-up, or nothing (TERMINAL)
      var figs = window.TOUR_FIGURES || {}, g = beat.grn || {};
      [['tgrnC', g.live], ['tgrnB', g.cmp]].forEach(function (pair) {
        var box = document.getElementById(pair[0]), svg = pair[1] && figs['grn-' + pair[1]];
        box.innerHTML = svg ? '<div class="tlab">' + (beat.grnLabel || 'Rad53 network in HU') + '</div>' + svg : '';
      });
    }

    function showOverproduced(beat) {
      // VIEW: a yellow ground and the stn1-OP badge on each close-up whose cell overproduces Stn1 (TERMINAL)
      // The model draws no Stn1: the badge says the cell carries excess Stn1,
      // and the close-up shows only what that cell does.
      var vis = document.querySelector('#tour .tvis'), op = beat.op || {};
      vis.setAttribute('data-op-c', op.live ? 'yes' : 'no');
      vis.setAttribute('data-op-b', op.cmp ? 'yes' : 'no');
    }

    function showFigure(beat) {
      // VIEW: the beat's model-key figure, or none (TERMINAL)
      var box = document.getElementById('tfig'), figs = window.TOUR_FIGURES || {};
      if (window.Mol3D) { window.Mol3D.unmountAll(); }
      box.innerHTML = beat.figure && figs[beat.figure] ? figs[beat.figure] : '';
      if (beat.panels) { showModelPanels(beat.panels, box); }
      if (beat.routes) { showRoutes(beat.routes, box); }
      if (window.Mol3D) { window.Mol3D.mountAll(box); }
      document.querySelector('#tour .tvis').setAttribute('data-figure', beat.figure || beat.panels || beat.routes ? 'yes' : 'no');
      // An answer card in the figure stays a question mark until the reader answers.
      document.querySelector('#tour .tvis').setAttribute('data-asked',
        beat.ask && TOUR.answered[TOUR.at] === undefined ? 'no' : 'yes');
      document.getElementById('tlabD').textContent = beat.figureLabel || 'Model key';
    }

    function showModelPanels(panels, box) {
      // VIEW: the viewer's own model panels, one tile each, cropped to the origin and set to the frame each names (TERMINAL)
      var grid = document.createElement('div'), loops = [];
      grid.className = 'tpanels';
      panels.forEach(function (p, n) {
        var svg = modelPanelSvg(p, 'tp' + n + '-'), tile;
        if (!svg) { return; }
        tile = document.createElement('div');
        tile.className = 'tpanel';
        tile.innerHTML = '<div class="tptitle">' + p.title + '</div>';
        tile.appendChild(svg);
        grid.appendChild(tile);
        loops.push({ key: p.key, svg: svg });
      });
      box.appendChild(grid);
      loops.forEach(playModelPanel);
    }

    function modelPanelSvg(p, pre) {
      // VIEW: a copy of one of the viewer's model panels, cropped to the origin, its definitions renamed (TERMINAL)
      // Each copy renames its definitions (prefix pre), so its arrows and
      // clips do not point into the hidden original. The origin-state card
      // and the panel's own note are dropped; the tile carries its title.
      var html = (window.INLINE_PANELS || {})[p.key] || '', defs = [], holder, svg;
      html.replace(/<(?:clipPath|pattern|linearGradient|radialGradient|marker|filter)[^>]*\sid="([^"]+)"/g, function (all, id) { defs.push(id); return all; });
      defs.forEach(function (id) {
        var safe = id.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        html = html.replace(new RegExp('id="' + safe + '"', 'g'), 'id="' + pre + id + '"')
          .replace(new RegExp('url\\(#' + safe + '\\)', 'g'), 'url(#' + pre + id + ')');
      });
      holder = document.createElement('div');
      holder.innerHTML = html;
      svg = holder.querySelector('svg');
      if (!svg) { return null; }
      svg.setAttribute('class', 'tmodel');
      svg.removeAttribute('data-key');
      svg.setAttribute('viewBox', (p.crop || [150, 0, 540, 282]).join(' '));
      Array.prototype.forEach.call(svg.querySelectorAll('.capbar, .notelab'), function (e) { e.parentNode.removeChild(e); });
      return svg;
    }

    function showRoutes(routes, box) {
      // VIEW: one row per proposed model: its animated panel, its network and its DDK-mark meter, with one HU switch for the slide (TERMINAL)
      // Both states of every network and meter are in the page; the switch
      // only chooses which one shows, so the panels keep playing through it.
      var figs = window.TOUR_FIGURES || {}, wrap = document.createElement('div'), head = document.createElement('div'), loops = [];
      wrap.className = 'troutes';
      wrap.setAttribute('data-hu', TOUR.routeHU === false ? 'off' : 'on');
      head.className = 'trhead';
      head.innerHTML = '<div class="trswitch" role="group" aria-label="Hydroxyurea">' +
        '<button type="button" data-set="off">Without HU</button><button type="button" data-set="on">In HU</button></div>' +
        '<div class="trkey">' + (figs['route-key'] || '') + '</div>';
      wrap.appendChild(head);
      Array.prototype.forEach.call(head.querySelectorAll('button'), function (b) {
        b.setAttribute('aria-pressed', b.getAttribute('data-set') === wrap.getAttribute('data-hu') ? 'true' : 'false');
        b.addEventListener('click', function () {
          TOUR.routeHU = b.getAttribute('data-set') === 'on';
          wrap.setAttribute('data-hu', b.getAttribute('data-set'));
          Array.prototype.forEach.call(head.querySelectorAll('button'), function (o) {
            o.setAttribute('aria-pressed', o === b ? 'true' : 'false');
          });
        });
      });
      routes.forEach(function (r, n) {
        var row = document.createElement('details'), cells = document.createElement('div'), panel = document.createElement('div'),
          net = document.createElement('div'), meter = document.createElement('div'), svg = modelPanelSvg(r, 'tr' + n + '-');
        // Each model folds into its own row; the first opens with the slide.
        row.className = 'trrow';
        row.open = n === 0;
        row.innerHTML = '<summary class="trtitle"><b>' + r.name + '</b>' + (r.title ? ': ' + r.title : '') + '</summary>';
        cells.className = 'trcells';
        panel.className = 'trpanel';
        if (svg) { panel.appendChild(svg); loops.push({ key: r.key, svg: svg }); }
        net.className = 'trnet';
        net.innerHTML = '<div class="tron">' + (figs['route-' + r.model + '-hu'] || '') + '</div>' +
          '<div class="troff">' + (figs['route-' + r.model + '-nohu'] || '') + '</div>';
        meter.className = 'trmeterbox';
        meter.innerHTML = '<div class="tron">' + (figs['rmeter-' + r.model + '-hu'] || '') + '</div>' +
          '<div class="troff">' + (figs['rmeter-' + r.model + '-nohu'] || '') + '</div>';
        cells.appendChild(panel);
        cells.appendChild(net);
        cells.appendChild(meter);
        row.appendChild(cells);
        wrap.appendChild(row);
      });
      box.appendChild(wrap);
      loops.forEach(playModelPanel);
    }

    function playModelPanel(tile) {
      // VIEW: play one model panel's frame table in its tile, hold the last frame, then start again (TERMINAL)
      // The restart jumps back to the first frame with transitions off, so the
      // factors do not fly backwards out of the drawing.
      var table = window.ANIM && window.ANIM[tile.key], n = 0, hold = 0;
      window.applyFrame(tile.key, 0, tile.svg);
      if (typeof window.paintDerived === 'function') { window.paintDerived(tile.key, tile.svg); }
      if (!table || !table.frames || table.frames.length < 2) { return; }
      TOUR.panelTimers = TOUR.panelTimers || [];
      TOUR.panelTimers.push(setInterval(function () {
        tile.svg.classList.remove('tnotrans');
        if (n >= table.frames.length - 1) {
          hold += 1;
          if (hold < 3) { return; }
          hold = 0;
          n = 0;
          tile.svg.classList.add('tnotrans');
        } else {
          n += 1;
        }
        window.applyFrame(tile.key, n, tile.svg);
        if (typeof window.paintDerived === 'function') { window.paintDerived(tile.key, tile.svg); }
      }, Math.round(1000 / (table.fps || 1))));
    }

    function showCompare(beat) {
      // VIEW: a second cell beside the live one, the same minute of another condition, drawn by the engine (TERMINAL)
      var holder = document.getElementById('tframeB'), src, html, defs = [], c, sched, table, t, i, idx, svg;
      var drawer = !!(beat.compare && beat.compare.drawer);
      holder.innerHTML = '';
      // A drawer comparison opens with the slide; the reader can fold it away.
      document.querySelector('#tour .tvis').setAttribute('data-drawer', drawer ? 'yes' : 'no');
      document.getElementById('tdrawer').open = true;
      document.querySelector('#tour .tvis').setAttribute('data-drawer-open', 'yes');
      TOUR.cmpLast = -1;
      if (!beat.compare) { return; }
      if (beat.compare.view === 'close') { showCloseCompare(beat, holder); return; }
      src = document.querySelector('#stage svg.panelsvg[data-key="chrLIVE"]');
      html = src.outerHTML;
      Array.prototype.forEach.call(src.querySelectorAll('clipPath[id], pattern[id], linearGradient[id], marker[id]'),
        function (d) { defs.push(d.id); });
      defs.forEach(function (id) {
        var safe = id.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        html = html.replace(new RegExp('id="' + safe + '"', 'g'), 'id="cmp-' + id + '"')
          .replace(new RegExp('url\\(#' + safe + '\\)', 'g'), 'url(#cmp-' + id + ')');
      });
      holder.innerHTML = html;
      svg = holder.firstChild;
      svg.removeAttribute('data-key');
      svg.classList.add('tcmp');
      svg.style.transform = '';
      sched = compareSched(beat);
      TOUR.cmpSched = sched;
      table = buildChromFrames(sched, CHROM_GEOM, 'L1', 'origin', [], beat.compare.follow ? CHROM_LIVE.sched : null);
      window.ANIM.chrCMP = table;
      // The other cell's minute: the live run's, or one the beat reads off the other run itself.
      t = beat.compare.own ? beat.compare.own(sched) : beat.compare.at(ctxFor(CHROM_LIVE.sched));
      idx = 0;
      for (i = 0; i < table.frames.length; i += 1) {
        if (table.frames[i].phase === 'S' && table.frames[i].t <= t + 1e-6) { idx = i; }
        if (t === Infinity) { idx = table.frames.length - 1; }
      }
      window.applyFrame('chrCMP', idx, svg);
      if (beat.compare.follow) { syncCompare(beat.range[0]); }
      document.getElementById('tlabB').textContent = TOUR.lesson.labels[beat.compare.cond]
        + (t === Infinity ? ', at the end of its run' : (beat.compare.own ? ', at its scoring time' : ', the same minute'))
        + '';
      document.getElementById('tgenoB').textContent = document.getElementById('tlabB').textContent;
    }

    function writeCard(beat, n) {
      // VIEW: chapter, title, count, caption and the two menus (TERMINAL)
      var ctx = ctxFor(CHROM_LIVE.sched), beats = TOUR.lesson.beats, chaps = '', slides = '', k, prev = null;
      document.getElementById('tchap').textContent = beat.chapter;
      document.getElementById('ttitle').textContent = beat.title;
      document.getElementById('tcount').textContent = (n + 1) + ' of ' + beats.length;
      document.querySelector('#tour .tcard').scrollTop = 0;
      // Citations are the viewer's: a numbered marker linked to the work's
      // DOI, and the slide's references listed under the card, linked the same way.
      TOUR.ledger = [];
      document.getElementById('ttext').innerHTML = (typeof beat.text === 'function' ? beat.text(ctx) : beat.text)
        .split('\n\n').map(function (p) { return '<p>' + citedHTML(p, TOUR.ledger) + '</p>'; }).join('');
      document.getElementById('trefs').innerHTML = referencesHTML(TOUR.ledger);
      // The chapter menu lists every chapter and opens on its first slide;
      // the slide menu lists the slides of this slide's chapter by title.
      var esc = function (t) { return String(t).replace(/&/g, '&amp;').replace(/</g, '&lt;'); };
      for (k = 0; k < beats.length; k += 1) {
        if (beats[k].chapter !== prev) {
          chaps += '<option value="' + k + '"' + (beats[k].chapter === beat.chapter ? ' selected' : '') + '>'
            + esc(beats[k].chapter) + '</option>';
          prev = beats[k].chapter;
        }
        if (beats[k].chapter === beat.chapter) {
          slides += '<option value="' + k + '"' + (k === n ? ' selected' : '') + '>' + (k + 1) + '. '
            + esc(beats[k].title) + '</option>';
        }
      }
      document.getElementById('tchapsel').innerHTML = chaps;
      document.getElementById('tslidesel').innerHTML = slides;
      document.getElementById('tback').disabled = n === 0;
      document.getElementById('tnext').disabled = n === beats.length - 1;
      document.getElementById('task').hidden = !beat.ask;
    }

    function showQuestion(beat, n) {
      // VIEW: the prediction, asked before the beat plays (TERMINAL)
      var box = document.getElementById('task');
      box.hidden = false;
      box.innerHTML = '<div class="tq">Predict: ' + beat.ask.q + '</div>'
        + beat.ask.options.map(function (o, k) {
          return '<button type="button" class="topt" data-opt="' + k + '">' + o + '</button>';
        }).join('');
    }
  }

  function answerQuestion(k) {
    // SUB-CONTROLLER: mark the reader's answer, explain, then play the beat

    var beat = currentBeat();
    TOUR.answered[TOUR.at] = k;
    showAnswer(beat, k);
    playBeat(beat);

    function showAnswer(beat, k) {
      // VIEW: the options marked right and wrong, with the reason (TERMINAL)
      var box = document.getElementById('task');
      box.innerHTML = '<div class="tq">Predict: ' + beat.ask.q + '</div>'
        + beat.ask.options.map(function (o, j) {
          var cls = j === beat.ask.answer ? 'topt right' : (j === k ? 'topt wrong' : 'topt');
          return '<button type="button" class="' + cls + '" disabled>' + o + '</button>';
        }).join('')
        + '<div class="texplain">' + (k === beat.ask.answer ? 'Yes. ' : 'Not here. ')
        + citedHTML(beat.ask.explain, TOUR.ledger) + '</div>';
      document.getElementById('trefs').innerHTML = referencesHTML(TOUR.ledger);
      document.querySelector('#tour .tvis').setAttribute('data-asked', 'yes');
    }
  }
}

// === SHARED FUNCTIONS =====================================================

function slowStretch(frames, from, to) {
  // MODEL: whether frames after from up to to hold a slow-motion stretch, three or more frames at one minute (TERMINAL)
  var i, run = 1;
  for (i = from + 2; i <= to; i += 1) {
    run = (frames[i].phase === 'S' && frames[i].t === frames[i - 1].t) ? run + 1 : 1;
    if (run >= 3) { return true; }
  }
  return false;
}

function stepCompare() {
  // VIEW: paint the comparison close-up's next slow-motion frame; false once it has caught up (TERMINAL)
  var root = TOUR.cmpInset && TOUR.cmpInset.root, idx;
  if (!root || !(TOUR.cmpTarget > TOUR.cmpLast)) { return false; }
  idx = TOUR.cmpLast + 1;
  root.dataset.ciframe = String(idx - 1);
  TOUR.cmpLast = idx;
  window.runChromLive('insetInto', { root: root, table: TOUR.cmpInset.table, frame: idx });
  if (idx >= TOUR.cmpTarget) { TOUR.cmpTarget = -1; }
  return true;
}

function compareSched(beat) {
  // MODEL: the comparison condition's run (TERMINAL)
  // A comparison with the same random draws differs from the live run only by its alleles.
  // A telomere beat compares runs of the one-origin chromosome.
  var c = JSON.parse(JSON.stringify(TOUR.runs[beat.compare.cond]));
  if (beat.compare.sameSeed) { c.seed = TOUR.runs[beat.cond].seed; }
  return CHROM_RULE.simulate(c.genotype || 'wt', !!c.bob1, c.seed, { hu: !!c.hu, checkpoint: c.checkpoint || 'wt',
    alleles: c.alleles || {}, ak: c.ak || 'none', telomereBp: c.telBp, oneOrigin: beat.view === 'tel' });
}

function syncCompare(frameIndex) {
  // VIEW: the comparison cell at the live cell's moment, for a beat whose comparison follows the run (TERMINAL)
  // In S the other run shows its last frame at or before the live minute;
  // outside S it shows the first frame of the same phase.
  var beat = currentBeat(), close = beat && beat.compare && beat.compare.view === 'close';
  var svg = close ? (TOUR.cmpInset && TOUR.cmpInset.root) : document.querySelector('#tframeB svg.tcmp');
  var live = window.ANIM && window.ANIM.chrLIVE && window.ANIM.chrLIVE.frames[frameIndex];
  var table = close ? (TOUR.cmpInset && TOUR.cmpInset.table) : (window.ANIM && window.ANIM.chrCMP), idx = -1, i;
  if (!beat || !beat.compare || !beat.compare.follow || !svg || !live || !table) { return; }
  // The two runs are matched by minutes after G1/S, since each starts S at its own first firing.
  var t = live.t + ((CHROM_LIVE.sched && CHROM_LIVE.sched.onsetFromG1S) || 0)
    - ((TOUR.cmpSched && TOUR.cmpSched.onsetFromG1S) || 0);
  var oneClock = !!(TOUR.cmpSched && TOUR.cmpSched.one && live.clock !== null && live.clock !== undefined);
  for (i = 0; i < table.frames.length && oneClock; i += 1) {
    // Two one-origin runs keep one clock through S, G2 and anaphase, so the
    // telomere steps in G2 line up too.
    if (table.frames[i].clock !== null && table.frames[i].clock <= live.clock + 1e-6
        && (table.frames[i].phase === live.phase || live.phase.charAt(0) !== 'A')) { idx = i; }
  }
  for (i = 0; i < table.frames.length && !oneClock; i += 1) {
    if (live.phase === 'S' && table.frames[i].phase === 'S' && table.frames[i].t <= t + 1e-6) { idx = i; }
    if (live.phase !== 'S' && idx < 0 && table.frames[i].phase === live.phase) { idx = i; }
  }
  if (idx < 0 && live.phase === 'S') {
    // Before the other run's first S frame: show its first S frame.
    for (i = 0; i < table.frames.length && idx < 0; i += 1) { if (table.frames[i].phase === 'S') { idx = i; } }
  }
  if (idx < 0) { idx = table.frames.length - 1; }
  if (close) {
    // The other run's frames fall on their own minutes, so the frame it shows
    // can hold for a tick or move on by more than one. A held frame is not
    // painted again, and a forward move is painted as the next frame, so the
    // close-up glides on and only a move back is redrawn at once.
    // A slow-motion stretch in the other run (frames that share one minute,
    // such as an origin firing step by step) plays frame by frame while the
    // live run waits; stepCompare paints it, one frame a tick.
    TOUR.cmpTarget = -1;
    if (idx === TOUR.cmpLast) { return; }
    if (idx > TOUR.cmpLast + 1 && TOUR.cmpLast >= 0 && slowStretch(table.frames, TOUR.cmpLast, idx)) {
      TOUR.cmpTarget = idx;
      idx = TOUR.cmpLast + 1;
    }
    if (idx > TOUR.cmpLast && TOUR.cmpLast >= 0) { svg.dataset.ciframe = String(idx - 1); }
    TOUR.cmpLast = idx;
    window.runChromLive('insetInto', { root: svg, table: table, frame: idx });
    return;
  }
  window.applyFrame('chrCMP', idx, svg);
}

function citedHTML(text, ledger) {
  // MODEL: text with each \\cite{keys} replaced by numbered markers linked to each work's DOI (TERMINAL)
  // Numbers run in order of first citation on the slide; a key missing from
  // the bibliography keeps its number and is listed as missing.
  var bib = window.BIB || {};
  return String(text).replace(/\\cite\{([^}]*)\}/g, function (all, group) {
    return group.split(',').map(function (k) {
      var key = k.replace(/^\s+|\s+$/g, ''), e = bib[key], n;
      if (ledger.indexOf(key) < 0) { ledger.push(key); }
      n = ledger.indexOf(key) + 1;
      return e ? '<a class="tcite" href="' + window.linkFor(e) + '" target="_blank" rel="noreferrer">[' + n + ']</a>'
        : '<span class="tcite missing">[' + n + ']</span>';
    }).join('');
  });
}

function referencesHTML(ledger) {
  // MODEL: the slide's reference list, in the viewer's own format (TERMINAL)
  return ledger.length ? '<ol class="trefs">' + window.renderReferenceList(ledger) + '</ol>' : '';
}

function currentBeat() {
  // MODEL: the beat on show (TERMINAL)
  return TOUR.lesson.beats[TOUR.at];
}

function ctxFor(sched) {
  // MODEL: what a beat's anchors and captions read: the run, its frames, and finders (TERMINAL)
  var frames = (window.ANIM && window.ANIM.chrLIVE) ? window.ANIM.chrLIVE.frames : [];
  var view = function (f) { return (f.inset && f.inset.view) || {}; };
  return {
    sched: sched,
    frames: frames,
    last: frames.length - 1,
    // The first chromosome frame at or after t minutes into S.
    at: function (t) {
      var i;
      for (i = 0; i < frames.length; i += 1) {
        if (frames[i].phase === 'S' && frames[i].t >= t - 1e-6) { return i; }
      }
      return frames.length - 1;
    },
    first: function (pred) {
      var i;
      for (i = 0; i < frames.length; i += 1) { if (pred(frames[i], view(frames[i]))) { return i; } }
      return -1;
    },
    lastWhere: function (pred) {
      var i;
      for (i = frames.length - 1; i >= 0; i -= 1) { if (pred(frames[i], view(frames[i]))) { return i; } }
      return -1;
    },
    phase: function (p) {
      var i;
      for (i = 0; i < frames.length; i += 1) { if (frames[i].phase === p) { return i; } }
      return -1;
    },
    view: view,
    fmt: function (x) { return String(Math.round(x)); }
  };
}

function playBeat(beat) {
  // VIEW: step through the beat's stretch, long stretches in strides (TERMINAL)
  // A beat without the close-up skips the close-up's slow-motion frames,
  // which repeat one chromosome moment. A beat with the close-up plays every
  // frame at the panel's own rate, which is the length of its transitions,
  // so the close-up moves smoothly as it does in the viewer.
  var frames = window.ANIM.chrLIVE.frames, list = [], i, k = 0, stride;
  var close = beat.layout === 'both' || beat.layout === 'close' || beat.layout === 'mol';
  var rate = 1000 / (window.ANIM.chrLIVE.fps || 2);
  for (i = beat.range[0]; i <= beat.range[1]; i += 1) {
    if (close || i === beat.range[0] || !/paused/.test(frames[i].inset.text['ci-line1'] || '')) { list.push(i); }
  }
  stride = close ? 1 : Math.max(1, Math.ceil(list.length / (beat.steps || 40)));
  list = list.filter(function (v, j) { return j % stride === 0 || j === list.length - 1; });
  // A beat marked cruise keeps its close-up fork moving once the stretch ends.
  var end = function () {
    TOUR.timer = null;
    if (beat.cruise) {
      TOUR.cruiseWait = setTimeout(function () { window.runChromLive('cruise', list[list.length - 1]); }, rate);
    }
  };
  var step = close ? rate : (beat.interval || 650);
  if (TOUR.timer) { clearInterval(TOUR.timer); }
  // Every transition lasts a little longer than the step, so each move is
  // still running when the next frame lands and the motion never holds.
  [document.querySelector('#stage svg.panelsvg[data-key="chrLIVE"]'), document.querySelector('#tframeB svg.tcmp')]
    .forEach(function (svg) {
      if (!svg) { return; }
      svg.style.setProperty('--t-fade', step + 'ms');
      svg.style.setProperty('--t-move', Math.round(step * 1.1) + 'ms');
      svg.style.setProperty('--t-travel', Math.round(step * 1.1) + 'ms');
    });
  window.runChromLive('cruise', false);
  window.runAnimation('goto', list[0]);
  if (list.length < 2) { end(); return; }
  TOUR.cmpTarget = -1;
  TOUR.timer = setInterval(function () {
    // The live run waits while the comparison plays a slow-motion stretch.
    if (stepCompare()) { return; }
    if (k >= list.length - 1) { clearInterval(TOUR.timer); end(); return; }
    k += 1;
    window.runAnimation('goto', list[k]);
  }, step);
}

function stopPlaying() {
  // VIEW: stop the beat that is playing (TERMINAL)
  if (TOUR.timer) { clearInterval(TOUR.timer); }
  if (TOUR.cruiseWait) { clearTimeout(TOUR.cruiseWait); }
  TOUR.timer = null;
  TOUR.cruiseWait = null;
  (TOUR.panelTimers || []).forEach(function (t) { clearInterval(t); });
  TOUR.panelTimers = [];
  if (typeof window.runChromLive === 'function') { window.runChromLive('cruise', false); }
  if (typeof window.runAnimation === 'function') { window.runAnimation('pause'); }
}

function followSpot() {
  // VIEW: move the spotlight with a lit element while the frames play (TERMINAL)
  // Placing rings measures every label in the panel, which stalls the moving
  // actors for a moment. Rings on fixed boxes wait for settleSpot; only rings
  // that follow an element are placed on every frame.
  var beat = currentBeat();
  if (beat && beat.spot && beat.spot.ids && beat.spot.ids.length) {
    requestAnimationFrame(function () { refreshSpot(); });
  }
}

function settleSpot() {
  // VIEW: redraw the spotlight once the frame's transitions have finished (TERMINAL)
  // Labels fade and actors slide for up to a frame interval after a frame
  // lands; the rings are placed again against where everything comes to rest.
  if (TOUR.settle) { clearTimeout(TOUR.settle); }
  TOUR.settle = setTimeout(function () { TOUR.settle = null; refreshSpot(); }, 900);
}

function refreshSpot() {
  // CONTROLLER: dim the chromosome panel except the beat's lit boxes and elements, outlined
  // Boxes are panel units. An element's box is its own bounding box carried
  // through its ancestors' translates, so a moving fork stays lit as it moves.
  // Outlines never cross each other, text or the panel's own dashed lines:
  // a ring that would cut a label or a dashed shape grows to take it in, and
  // rings that touch merge into one.
  // The comparison cell gets its own rings, placed against its own picture.
  var beat = currentBeat(), spec = beat && beat.spot;
  [document.querySelector('#stage svg.panelsvg[data-key="chrLIVE"]'), document.querySelector('#tframeB svg.tcmp')]
    .forEach(function (svg) {
      var boxes, obstacles;
      if (!svg) { return; }
      clearSpot(svg);
      if (!spec) { return; }
      boxes = gatherSpotBoxes(svg, spec);
      obstacles = gatherSpotObstacles(svg);
      boxes = settleSpotBoxes(boxes, obstacles);
      drawSpot(svg, boxes);
    });

  function clearSpot(svg) {
    // VIEW: remove the previous spotlight (TERMINAL)
    var old = svg.querySelector('#tourspot');
    if (old) { old.parentNode.removeChild(old); }
  }

  function gatherSpotBoxes(svg, spec) {
    // MODEL: the beat's boxes and its elements' boxes, padded, in panel units (TERMINAL)
    var pad = 5, out = [];
    (spec.boxes || []).forEach(function (b) { out.push(b.slice()); });
    (spec.ids || []).forEach(function (id) {
      var el = svg.querySelector('#' + id);
      if (!el || el.classList.contains('gone')) { return; }
      var b = spotBoxOf(svg, el);
      if (b) { out.push(b); }
    });
    return out.map(function (b) { return [b[0] - pad, b[1] - pad, b[2] + 2 * pad, b[3] + 2 * pad]; });
  }

  function gatherSpotObstacles(svg) {
    // MODEL: boxes of every visible label and dashed shape a ring must not cut (TERMINAL)
    var out = [], cap = 170, gap = 3;
    svg.querySelectorAll('text, path, rect, line, polyline, ellipse, circle').forEach(function (el) {
      var cs, b;
      if (el.closest('#tourspot') || el.closest('.gone')) { return; }
      if (el.tagName !== 'text') {
        cs = getComputedStyle(el);
        if (!cs.strokeDasharray || cs.strokeDasharray === 'none' || cs.stroke === 'none') { return; }
      }
      if (el.checkVisibility && !el.checkVisibility({ opacityProperty: true, visibilityProperty: true })) { return; }
      b = spotBoxOf(svg, el);
      if (!b) { return; }
      var big = b[2] > cap || b[3] > cap, m = big ? 2 : (el.tagName === 'text' ? gap : 2 * gap);
      var tight = [b[0] - 1, b[1] - 1, b[2] + 2, b[3] + 2];
      b = [b[0] - m, b[1] - m, b[2] + 2 * m, b[3] + 2 * m];
      b.big = big;
      b.tight = tight;
      out.push(b);
    });
    return out;
  }

  function settleSpotBoxes(boxes, obstacles) {
    // MODEL: grow rings over the labels and dashes they cut, then merge rings that touch (TERMINAL)
    // A label too long to take in, such as the panel caption, pushes the
    // ring's nearer edge back off it, and so does a short label whose
    // taking in would make the ring cut a long one. Where the full margin
    // round a short label or dash would cut a long label, a tight one is used.
    var list = boxes.slice(), changed = true, rounds = 0, i, j, k, o, next, gap = 4;
    function hits(a, b, m) {
      return a[0] - m < b[0] + b[2] && b[0] < a[0] + a[2] + m && a[1] - m < b[1] + b[3] && b[1] < a[1] + a[3] + m;
    }
    function holds(a, b) {
      return b[0] >= a[0] && b[1] >= a[1] && b[0] + b[2] <= a[0] + a[2] && b[1] + b[3] <= a[1] + a[3];
    }
    function join(a, b) {
      var x = Math.min(a[0], b[0]), y = Math.min(a[1], b[1]);
      return [x, y, Math.max(a[0] + a[2], b[0] + b[2]) - x, Math.max(a[1] + a[3], b[1] + b[3]) - y];
    }
    function cutsBig(a) {
      return obstacles.some(function (o) { return o.big && hits(a, o, -1.5) && !holds(a, o); });
    }
    function trim(a, o) {
      var top = a[1], bot = a[1] + a[3], left = a[0], right = a[0] + a[2];
      if (o[2] >= o[3]) {
        if (o[1] + o[3] / 2 > top + a[3] / 2) { bot = Math.min(bot, o[1]); } else { top = Math.max(top, o[1] + o[3]); }
      } else if (o[0] + o[2] / 2 > left + a[2] / 2) { right = Math.min(right, o[0]); } else { left = Math.max(left, o[0] + o[2]); }
      return [left, top, Math.max(0, right - left), Math.max(0, bot - top)];
    }
    while (changed && rounds < 30) {
      changed = false; rounds += 1;
      for (i = 0; i < list.length; i += 1) {
        for (k = 0; k < obstacles.length; k += 1) {
          o = obstacles[k];
          if (!hits(list[i], o, 0) || holds(list[i], o) || holds(list[i], o.tight)) { continue; }
          if (o.big) { next = trim(list[i], o); }
          else if (!cutsBig(join(list[i], o))) { next = join(list[i], o); }
          else if (!cutsBig(join(list[i], o.tight))) { next = join(list[i], o.tight); }
          else { next = trim(list[i], o); }
          if (next.join() !== list[i].join()) { list[i] = next; changed = true; }
        }
      }
      for (i = 0; i < list.length; i += 1) {
        for (j = list.length - 1; j > i; j -= 1) {
          if (hits(list[i], list[j], gap)) { list[i] = join(list[i], list[j]); list.splice(j, 1); changed = true; }
        }
      }
    }
    return list;
  }

  function drawSpot(svg, boxes) {
    // VIEW: the veil with one hole per ring, and the rings (TERMINAL)
    var ns = 'http://www.w3.org/2000/svg', g = document.createElementNS(ns, 'g');
    var d = 'M-2000 -2000H3000V3000H-2000Z';
    g.setAttribute('id', 'tourspot');
    g.setAttribute('pointer-events', 'none');
    boxes.forEach(function (b) { d += 'M' + b[0] + ' ' + b[1] + 'v' + b[3] + 'h' + b[2] + 'v' + (-b[3]) + 'Z'; });
    g.innerHTML = '<path class="tspotveil" fill-rule="evenodd" d="' + d + '"/>'
      + boxes.map(function (b) {
        return '<rect class="tspotring" x="' + b[0] + '" y="' + b[1] + '" width="' + b[2] + '" height="' + b[3] + '" rx="5"/>';
      }).join('');
    svg.appendChild(g);
  }
}

function spotBoxOf(svg, el) {
  // MODEL: an element's bounding box in panel units, or null without geometry (TERMINAL)
  try {
    var bb = el.getBBox(), m = el.getCTM(), root = svg.getCTM(), p1, p2;
    if (!m || !root || (bb.width <= 0 && bb.height <= 0)) { return null; }
    m = root.inverse().multiply(m);
    p1 = { x: m.a * bb.x + m.c * bb.y + m.e, y: m.b * bb.x + m.d * bb.y + m.f };
    p2 = { x: m.a * (bb.x + bb.width) + m.c * (bb.y + bb.height) + m.e, y: m.b * (bb.x + bb.width) + m.d * (bb.y + bb.height) + m.f };
    return [Math.min(p1.x, p2.x), Math.min(p1.y, p2.y), Math.abs(p2.x - p1.x), Math.abs(p2.y - p1.y)];
  } catch (e) { return null; }
}

if (typeof document !== 'undefined') {
  window.addEventListener('load', function () { runTour('init'); });
}
