"""Measured spindle extension in HU, classified short or extended within each experiment.

The lesson shows each strain as short or extended, never as a percentage.
Each experiment sets its own scale, because incubation time, temperature and
HU dose differ between experiments. A strain takes the class of the
reference it is closer to: its short reference or its extended reference,
whichever value its own value lies nearer.

References. Every experiment names a short control (wild type, or a
checkpoint-proficient single mutant run in the same experiment) and an
extended control (rad53-21). A strain may also be compared with any strain of
the same experiment already classified, if that strain lies on the path from
the ground state to the one compared (every locus it changes, the strain
changes too) and the two differ by no more than two manipulations. The
closest relative wins: fewest manipulations apart, then the most loci in
common, then the strain listed first. A comparison is best when it changes one thing.

Manipulations are written per locus. A deletion covered by a plasmid
carrying the wild-type gene (dbf4-delta/pDBF4) is its own entry, so a strain
carrying pdbf4-zn in its place differs from it by one manipulation.

Values are percentages of cells with spindles of 3 um or more, read from the
figures (Julius et al. 2019; Gasparyan et al. 2022). An experiment that
scores cells by bud size gives one value per bud class.
"""

EXPERIMENTS = [
    {
        'key': 'j4a', 'source': 'Julius et al. 2019, Fig. 4A', 'cite': 'julius2019inhibition',
        'strains': [
            {'id': 'j4a-wt', 'label': 'wild type', 'm': {}, 'v': {'all': 0}, 'role': 'short'},
            {'id': 'j4a-rad53', 'label': 'rad53-21', 'm': {'RAD53': 'rad53-21'}, 'v': {'all': 65}, 'role': 'extended'},
            {'id': 'j4a-pdbf4', 'label': 'rad53-21 dbf4Δ/pDBF4', 'm': {'RAD53': 'rad53-21', 'DBF4': 'dbf4Δ/pDBF4'},
             'v': {'all': 51}},
            {'id': 'j4a-zn', 'label': 'rad53-21 dbf4Δ/pdbf4-zn', 'm': {'RAD53': 'rad53-21', 'DBF4': 'dbf4Δ/pdbf4-zn'},
             'v': {'all': 7}, 'model': 's3-zn'},
            {'id': 'j4a-mcm2', 'label': 'rad53-21 mcm2-1', 'm': {'RAD53': 'rad53-21', 'MCM2': 'mcm2-1'},
             'v': {'all': 4}, 'model': 's3-mcm'},
            {'id': 'j4a-mcm3', 'label': 'rad53-21 mcm3-1', 'm': {'RAD53': 'rad53-21', 'MCM3': 'mcm3-1'}, 'v': {'all': 3}},
            {'id': 'j4a-mcm5', 'label': 'rad53-21 mcm5-1', 'm': {'RAD53': 'rad53-21', 'MCM5': 'mcm5-1'}, 'v': {'all': 7}},
        ]
    },
    {
        'key': 'j5a', 'source': 'Julius et al. 2019, Fig. 5A', 'cite': 'julius2019inhibition',
        'strains': [
            {'id': 'j5a-wt', 'label': 'wild type', 'm': {}, 'v': {'all': 2}, 'role': 'short'},
            {'id': 'j5a-rad53', 'label': 'rad53-21', 'm': {'RAD53': 'rad53-21'}, 'v': {'all': 67}, 'role': 'extended'},
            {'id': 'j5a-m25', 'label': 'dbf4-m25', 'm': {'DBF4': 'dbf4-m25'}, 'v': {'all': 2}},
            {'id': 'j5a-38a', 'label': 'sld3-38A', 'm': {'SLD3': 'sld3-38A'}, 'v': {'all': 4}},
            {'id': 'j5a-dun1', 'label': 'dun1Δ', 'm': {'DUN1': 'dun1Δ'}, 'v': {'all': 0}},
            {'id': 'j5a-sites', 'label': 'dbf4-m25 sld3-38A', 'm': {'DBF4': 'dbf4-m25', 'SLD3': 'sld3-38A'},
             'v': {'all': 52}, 'model': 's4-sites'},
            {'id': 'j5a-sitesdun1', 'label': 'dbf4-m25 sld3-38A dun1Δ',
             'm': {'DBF4': 'dbf4-m25', 'SLD3': 'sld3-38A', 'DUN1': 'dun1Δ'}, 'v': {'all': 71}, 'model': 's4-dun1'},
        ]
    },
    {
        # No wild-type strain was scored; ctf19-delta and mcm21-delta alone are
        # checkpoint-proficient and were scored in the same experiment.
        'key': 'j6d', 'source': 'Julius et al. 2019, Fig. 6D', 'cite': 'julius2019inhibition',
        'strains': [
            {'id': 'j6d-ctf19', 'label': 'ctf19Δ', 'm': {'CTF19': 'ctf19Δ'}, 'v': {'all': 5}, 'role': 'short'},
            {'id': 'j6d-mcm21', 'label': 'mcm21Δ', 'm': {'MCM21': 'mcm21Δ'}, 'v': {'all': 5}, 'role': 'short'},
            {'id': 'j6d-rad53', 'label': 'rad53-21', 'm': {'RAD53': 'rad53-21'}, 'v': {'all': 48}, 'role': 'extended'},
            {'id': 'j6d-rad53ctf19', 'label': 'rad53-21 ctf19Δ', 'm': {'RAD53': 'rad53-21', 'CTF19': 'ctf19Δ'},
             'v': {'all': 11}, 'model': 's5-ctf19'},
            {'id': 'j6d-rad53mcm21', 'label': 'rad53-21 mcm21Δ', 'm': {'RAD53': 'rad53-21', 'MCM21': 'mcm21Δ'},
             'v': {'all': 12}},
        ]
    },
    {
        'key': 'j8e', 'source': 'Julius et al. 2019, Fig. 8E', 'cite': 'julius2019inhibition',
        'strains': [
            {'id': 'j8e-wt', 'label': 'wild type', 'm': {}, 'v': {'small': 1, 'large': 0}, 'role': 'short'},
            {'id': 'j8e-rad53', 'label': 'rad53-21', 'm': {'RAD53': 'rad53-21'}, 'v': {'small': 42, 'large': 40},
             'role': 'extended', 'model': {'small': 's6-rad53'}},
            {'id': 'j8e-exo1', 'label': 'exo1Δ', 'm': {'EXO1': 'exo1Δ'}, 'v': {'small': 1, 'large': 1}},
            {'id': 'j8e-rad53exo1', 'label': 'rad53-21 exo1Δ', 'm': {'RAD53': 'rad53-21', 'EXO1': 'exo1Δ'},
             'v': {'small': 7, 'large': 32}, 'model': {'small': 's6-exo1', 'large': 's6-exo1l'}},
        ]
    },
    {
        # The short control is the checkpoint-proficient strain carrying the
        # same four arrays; the extended control is rad53-21 without them.
        'key': 'j9b', 'source': 'Julius et al. 2019, Fig. 9B', 'cite': 'julius2019inhibition',
        'strains': [
            {'id': 'j9b-akv', 'label': '4× LATE-AK, vector', 'm': {'AK': '4× LATE-AK'}, 'v': {'small': 0, 'large': 0},
             'role': 'short'},
            {'id': 'j9b-rad53', 'label': 'rad53-21, vector', 'm': {'RAD53': 'rad53-21'}, 'v': {'small': 36, 'large': 61},
             'role': 'extended'},
            {'id': 'j9b-ako', 'label': '4× LATE-AK, ASK1-LacI', 'm': {'AK': '4× LATE-AK', 'ASK1': 'pASK1-LacI'},
             'v': {'small': 0, 'large': 1}},
            {'id': 'j9b-rad53akv', 'label': 'rad53-21 4× LATE-AK, vector', 'm': {'RAD53': 'rad53-21', 'AK': '4× LATE-AK'},
             'v': {'small': 43, 'large': 63}, 'model': {'small': 's5-akv'}},
            {'id': 'j9b-rad53ask', 'label': 'rad53-21, ASK1-LacI', 'm': {'RAD53': 'rad53-21', 'ASK1': 'pASK1-LacI'},
             'v': {'small': 33, 'large': 64}},
            {'id': 'j9b-rad53ako', 'label': 'rad53-21 4× LATE-AK, ASK1-LacI',
             'm': {'RAD53': 'rad53-21', 'AK': '4× LATE-AK', 'ASK1': 'pASK1-LacI'}, 'v': {'small': 12, 'large': 38},
             'model': {'small': 's5-ako'}},
        ]
    },
    {
        # Figs. 3A and 4 are one experiment: the Fig. 4 legend gives its wild-type
        # and STN1 OP samples as those of Fig. 3A, which carries the rad53-21 control.
        'key': 'g3a', 'source': 'Gasparyan et al. 2022, Figs. 3A and 4', 'cite': 'Gasparayan2022yeast',
        'strains': [
            {'id': 'g3a-wt', 'label': 'wild type, vector', 'm': {}, 'v': {'all': 6}, 'role': 'short'},
            {'id': 'g3a-rad53', 'label': 'rad53-21', 'm': {'RAD53': 'rad53-21'}, 'v': {'all': 40}, 'role': 'extended'},
            {'id': 'g3a-op', 'label': 'stn1-OP', 'm': {'STN1': 'OP'}, 'v': {'all': 53}},
            {'id': 'g3a-mcm2', 'label': 'mcm2-1, vector', 'm': {'MCM2': 'mcm2-1'}, 'v': {'all': 3}},
            {'id': 'g3a-mcm2op', 'label': 'mcm2-1 stn1-OP', 'm': {'MCM2': 'mcm2-1', 'STN1': 'OP'}, 'v': {'all': 1}},
            {'id': 'g3a-mcm5', 'label': 'mcm5-1, vector', 'm': {'MCM5': 'mcm5-1'}, 'v': {'all': 8}},
            {'id': 'g3a-mcm5op', 'label': 'mcm5-1 stn1-OP', 'm': {'MCM5': 'mcm5-1', 'STN1': 'OP'}, 'v': {'all': 5}},
            {'id': 'g3a-exo1', 'label': 'exo1Δ, vector', 'm': {'EXO1': 'exo1Δ'}, 'v': {'all': 3}},
            {'id': 'g3a-exo1op', 'label': 'exo1Δ stn1-OP', 'm': {'EXO1': 'exo1Δ', 'STN1': 'OP'}, 'v': {'all': 20}},
            {'id': 'g3a-zn', 'label': 'dbf4-zn, vector', 'm': {'DBF4': 'dbf4-zn'}, 'v': {'all': 10}},
            {'id': 'g3a-znop', 'label': 'dbf4-zn stn1-OP', 'm': {'DBF4': 'dbf4-zn', 'STN1': 'OP'}, 'v': {'all': 26}},
        ]
    },
    {
        'key': 'g5c', 'source': 'Gasparyan et al. 2022, Fig. 5C', 'cite': 'Gasparayan2022yeast',
        'strains': [
            {'id': 'g5c-wt', 'label': 'wild type, vector', 'm': {}, 'v': {'all': 4}, 'role': 'short'},
            {'id': 'g5c-rad53', 'label': 'rad53-21', 'm': {'RAD53': 'rad53-21'}, 'v': {'all': 49}, 'role': 'extended'},
            {'id': 'g5c-op', 'label': 'stn1-OP', 'm': {'STN1': 'OP'}, 'v': {'all': 48}},
            {'id': 'g5c-bobp', 'label': 'mcm5-bob1 dbf4Δ/pDBF4, vector', 'm': {'MCM5': 'mcm5-bob1', 'DBF4': 'dbf4Δ/pDBF4'},
             'v': {'all': 4}},
            {'id': 'g5c-bobpop', 'label': 'mcm5-bob1 dbf4Δ/pDBF4 stn1-OP',
             'm': {'MCM5': 'mcm5-bob1', 'DBF4': 'dbf4Δ/pDBF4', 'STN1': 'OP'}, 'v': {'all': 40}},
            {'id': 'g5c-bob', 'label': 'mcm5-bob1 dbf4Δ, vector', 'm': {'MCM5': 'mcm5-bob1', 'DBF4': 'dbf4Δ'},
             'v': {'all': 9}},
            {'id': 'g5c-bobop', 'label': 'mcm5-bob1 dbf4Δ stn1-OP', 'm': {'MCM5': 'mcm5-bob1', 'DBF4': 'dbf4Δ', 'STN1': 'OP'},
             'v': {'all': 52}},
        ]
    },
    {
        # No wild-type strain was scored; stn1-186 alone is checkpoint-proficient
        # and was scored in the same experiment.
        'key': 'g6a', 'source': 'Gasparyan et al. 2022, Fig. 6A', 'cite': 'Gasparayan2022yeast',
        'strains': [
            {'id': 'g6a-stn1', 'label': 'stn1(1–186)', 'm': {'STN1': 'stn1(1-186)'}, 'v': {'all': 0}, 'role': 'short'},
            {'id': 'g6a-rad53', 'label': 'rad53-21', 'm': {'RAD53': 'rad53-21'}, 'v': {'all': 53}, 'role': 'extended'},
            {'id': 'g6a-rad53stn1', 'label': 'rad53-21 stn1(1–186)', 'm': {'RAD53': 'rad53-21', 'STN1': 'stn1(1-186)'},
             'v': {'all': 11}},
        ]
    },
]

MAX_STEPS = 2          # the furthest a non-control reference may lie from the strain it is compared with


def classify(experiments=None):
    """BASE CONTROLLER: every strain's class in every readout, with the problems found.

    Returns ({strain id: {'label', 'source', 'cite', 'cls': {readout: 'short'|'extended'},
    'refs': {readout: (short id, extended id)}, 'model'}}, [problem, ...]).
    """

    # === SUB-CONTROLLERS ===

    def classify_experiment(exp):
        # SUB-CONTROLLER: check the experiment's controls, then classify its strains in order

        problems = check_controls(exp)
        if problems:
            return {}, problems
        out = record_controls(exp)
        for s in exp['strains']:
            if s.get('role'):
                continue
            for readout in sorted(s['v']):
                refs = nearest_references(exp, s, readout, out)
                if None in refs:
                    problems.append('%s %s: no %s reference within %d manipulations'
                                    % (exp['key'], s['id'], 'short' if refs[0] is None else 'extended', MAX_STEPS))
                    continue
                out.setdefault(s['id'], new_entry(exp, s))
                out[s['id']]['cls'][readout] = call_class(s, readout, refs, strain_by_id(exp))
                out[s['id']]['refs'][readout] = refs
        return out, problems

    def check_controls(exp):
        # MODEL: the experiment names a short and an extended control, the extended one above the short one (TERMINAL)
        shorts = [s for s in exp['strains'] if s.get('role') == 'short']
        longs = [s for s in exp['strains'] if s.get('role') == 'extended']
        bad = []
        if not shorts:
            bad.append('%s has no short control' % exp['key'])
        if not longs:
            bad.append('%s has no extended control' % exp['key'])
        for a in shorts:
            for b in longs:
                for r in a['v']:
                    if r in b['v'] and not a['v'][r] < b['v'][r]:
                        bad.append('%s: short control %s is not below extended control %s (%s)'
                                   % (exp['key'], a['id'], b['id'], r))
        return bad

    def record_controls(exp):
        # MODEL: each control classified by its role (TERMINAL)
        out = {}
        for s in exp['strains']:
            if s.get('role'):
                e = new_entry(exp, s)
                e['cls'] = {r: s['role'] for r in s['v']}
                e['control'] = True
                out[s['id']] = e
        return out

    def nearest_references(exp, s, readout, known):
        # MODEL: the closest short and extended references for one strain and readout (TERMINAL)
        def steps(a, b):
            keys = set(a) | set(b)
            return sum(1 for k in keys if a.get(k) != b.get(k))

        def shared(a, b):
            return len(set(a) & set(b))

        best = {'short': None, 'extended': None}
        for t in exp['strains']:
            e = known.get(t['id'])
            if t is s or not e or readout not in e['cls'] or readout not in t['v']:
                continue
            d = steps(s['m'], t['m'])
            if not e.get('control') and (d > MAX_STEPS or not set(t['m']) <= set(s['m'])):
                continue
            rank = (d, -shared(s['m'], t['m']))
            c = e['cls'][readout]
            if best[c] is None or rank < best[c][0]:
                best[c] = (rank, t['id'])
        return (best['short'][1] if best['short'] else None, best['extended'][1] if best['extended'] else None)

    def call_class(s, readout, refs, by_id):
        # MODEL: the class of the reference the strain's value lies nearer, a tie going to short (TERMINAL)
        lo, hi = by_id[refs[0]]['v'][readout], by_id[refs[1]]['v'][readout]
        return 'extended' if abs(s['v'][readout] - hi) < abs(s['v'][readout] - lo) else 'short'

    def strain_by_id(exp):
        # MODEL: the experiment's strains by id (TERMINAL)
        return {t['id']: t for t in exp['strains']}

    def new_entry(exp, s):
        # MODEL: one strain's record for the lesson, before its class is set (TERMINAL)
        return {'label': s['label'], 'source': exp['source'], 'cite': exp['cite'], 'cls': {}, 'refs': {},
                'model': s.get('model'), 'control': False}

    result, problems = {}, []
    for exp in (experiments or EXPERIMENTS):
        got, bad = classify_experiment(exp)
        result.update(got)
        problems.extend(bad)
    return result, problems


def check_model(classes, presets):
    """MODEL: every strain the model also runs falls in the same class in the model as in the paper (TERMINAL)

    The model's own controls set its scale: its wild-type and rad53-21 strains
    in HU. A model strain is extended when its share of extended spindles over
    301 runs lies nearer the rad53-21 share.
    """
    lo, hi = 100.0 * presets['s2-wt']['share'], 100.0 * presets['s2-rad53']['share']
    bad = []
    for sid, e in classes.items():
        m = e.get('model')
        if not m:
            continue
        keys = m if isinstance(m, dict) else {r: m for r in e['cls']}
        for readout, key in keys.items():
            share = 100.0 * presets[key]['share']
            got = 'extended' if abs(share - hi) < abs(share - lo) else 'short'
            if readout in e['cls'] and got != e['cls'][readout]:
                bad.append('%s (%s): paper %s, model %s (%s at %d%%)'
                           % (sid, readout, e['cls'][readout], got, key, round(share)))
    return bad


if __name__ == '__main__':
    got, problems = classify()
    for sid, e in got.items():
        print('%-16s %-34s %s %s' % (sid, e['label'], e['cls'], '' if e['control'] else e['refs']))
    print('problems:', problems)
