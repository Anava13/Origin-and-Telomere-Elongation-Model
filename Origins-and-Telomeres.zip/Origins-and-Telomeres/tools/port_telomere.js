#!/usr/bin/env node
/* Bring the telomere workflow (telomere/src) into the unified viewer.

       node tools/port_telomere.js

   The telomere workflow keeps its own generator, engine and standalone build
   in telomere/. This script reads what that generator writes and emits the
   files the unified viewer loads, every key prefixed tw- so nothing collides
   with the replication panels:

       src/tw-panels/tw-<key>.svg   each panel, class "panelsvg telo", its
                                    definitions renamed tw-<id>
       src/nav-telomere.svg         the telomere flowchart as the fifth chart
       src/telo-engine.js           the telomere engine, closed over its own
                                    frame tables, as TELO; it registers each
                                    panel's META entry and a frame table stub
                                    so the shared transport can count frames
       src/telo-style.css           the telomere glyph vocabulary and states,
                                    scoped to .telo and .telonav
       src/telo-refs.bib            telomere references the replication
                                    bibliography does not already carry

   The two engines differ. The replication engine reads compound track strings;
   the telomere engine paints strand halves and derives zones, Rap1 boxes and
   the cap bar from them. src/animate.js hands any tw- key to TELO, so each
   figure keeps the engine it was drawn for.

   Nothing here is hand-edited output: rerun this after any change in
   telomere/src. build.py runs it. */

'use strict';

const fs = require('fs');
const path = require('path');
const vm = require('vm');

const ROOT = path.dirname(__dirname);
const TSRC = path.join(ROOT, 'telomere', 'src');
const OUT = path.join(ROOT, 'src');
const PREFIX = 'tw-';

function main() {
  // BASE CONTROLLER: read the telomere sources, transform each kind, write the outputs.

  const data = readTelomereData();
  const panels = portPanels(data.order);
  const nav = portNav();
  const engine = buildEngine(data);
  const css = scopeStyle();
  const bib = mergeBib();
  writeOutputs(panels, nav, engine, css, bib);

  function readTelomereData() {
    // MODEL: META, the reading order and the frame tables, by running the telomere data files (TERMINAL)
    const src = fs.readFileSync(path.join(TSRC, 'data.js'), 'utf8') + '\n'
      + fs.readFileSync(path.join(TSRC, 'anim-data.js'), 'utf8')
      + '\n__out = { META: META, ORDER: ORDER, PANEL_ORDER: PANEL_ORDER, ANIM: ANIM };';
    const ctx = { __out: null };
    vm.createContext(ctx);
    vm.runInContext(src, ctx, { filename: 'telomere data' });
    const out = JSON.parse(JSON.stringify(ctx.__out));
    return { meta: out.META, order: out.PANEL_ORDER, line: out.ORDER, anim: out.ANIM,
      engineSrc: fs.readFileSync(path.join(TSRC, 'animate.js'), 'utf8') };
  }

  function portPanels(order) {
    // MODEL: each panel's markup with its key, class and renamed definitions (TERMINAL)
    const out = {};
    order.forEach(function (key) {
      let svg = fs.readFileSync(path.join(TSRC, 'panels', key + '.svg'), 'utf8').trim();
      const ids = [];
      const defs = svg.match(/<defs>[\s\S]*?<\/defs>/g) || [];
      defs.forEach(function (d) { (d.match(/id="([^"]+)"/g) || []).forEach(function (m) { ids.push(m.slice(4, -1)); }); });
      (svg.match(/<clipPath[^>]*id="([^"]+)"/g) || []).forEach(function (m) { ids.push(/id="([^"]+)"/.exec(m)[1]); });
      ids.forEach(function (id) {
        const safe = id.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        svg = svg.replace(new RegExp('id="' + safe + '"', 'g'), 'id="' + PREFIX + id + '"')
          .replace(new RegExp('url\\(#' + safe + '\\)', 'g'), 'url(#' + PREFIX + id + ')')
          .replace(new RegExp('href="#' + safe + '"', 'g'), 'href="#' + PREFIX + id + '"');
      });
      if (!/^<svg class="panelsvg"/.test(svg)) { throw new Error(key + ': panel does not open with <svg class="panelsvg"'); }
      svg = svg.replace(/^<svg class="panelsvg"/, '<svg class="panelsvg telo" data-key="' + PREFIX + key + '"');
      out[PREFIX + key] = svg;
    });
    return out;
  }

  function portNav() {
    // MODEL: the flowchart with prefixed keys and markers, marked as the telomere chart (TERMINAL)
    let svg = fs.readFileSync(path.join(TSRC, 'nav.svg'), 'utf8').trim();
    const ids = [];
    (svg.match(/<marker[^>]*id="([^"]+)"/g) || []).forEach(function (m) { ids.push(/id="([^"]+)"/.exec(m)[1]); });
    ids.forEach(function (id) {
      svg = svg.replace(new RegExp('id="' + id + '"', 'g'), 'id="' + PREFIX + id + '"')
        .replace(new RegExp('url\\(#' + id + '\\)', 'g'), 'url(#' + PREFIX + id + ')');
    });
    svg = svg.replace(/^<svg id="flow"/, '<svg id="navsvg-telomere" class="navchart telonav"');
    svg = svg.replace(/<g class="node([^"]*)" data-key="([^"]+)"/g, function (m, cls, key) {
      return '<g class="node navnode' + cls + '" data-key="' + PREFIX + key + '"';
    });
    svg = svg.replace(/data-goto="([^"]+)"/g, 'data-goto="' + PREFIX + '$1"');
    // Each node's box takes the shared chart's class, which the viewer's checks
    // read; the telomere sheet's .telonav rules still style it.
    svg = svg.replace(/(<g class="node navnode[^"]*" data-key="[^"]+"[^>]*>\s*)<rect /g, '$1<rect class="navbox" ');
    return svg;
  }

  function buildEngine(d) {
    // MODEL: the telomere engine closed over its own tables, and the registration of its panels (TERMINAL)
    const meta = {}, stubs = {};
    d.order.forEach(function (key) {
      const m = d.meta[key];
      meta[PREFIX + key] = { title: m.title, caption: m.caption, note: m.note || '', num: m.num,
        phase: m.phase, phaseLabel: m.phaseLabel, telomere: true };
      if (d.anim[key]) {
        stubs[PREFIX + key] = { fps: d.anim[key].fps || 1.2, label: d.anim[key].label || key,
          telo: true, frames: d.anim[key].frames.map(function () { return {}; }) };
      }
    });
    return '/* Generated by tools/port_telomere.js from telomere/src. Do not edit:\n'
      + '   edit telomere/ and rerun the port. */\n\n'
      + 'var TELO = (function () {\n\n'
      + '  var ANIM = ' + JSON.stringify(d.anim) + ';\n\n'
      + '  // === the telomere engine, as telomere/src/animate.js writes it ===\n'
      + d.engineSrc.replace(/^/gm, '  ') + '\n\n'
      + '  // === the unified viewer\'s entry points ===\n\n'
      + '  var KEYS = ' + JSON.stringify(d.order.map(function (k) { return PREFIX + k; })) + ';\n\n'
      + '  function owns(key) {\n'
      + '    // MODEL: is this a telomere panel (TERMINAL)\n'
      + '    return KEYS.indexOf(key) >= 0;\n'
      + '  }\n\n'
      + '  function apply(root, key, n) {\n'
      + '    // VIEW: one frame of a telomere panel, painted into root by the telomere engine (TERMINAL)\n'
      + '    var k = key.slice(' + PREFIX.length + '), f;\n'
      + '    if (!root || !ANIM[k]) { return; }\n'
      + '    f = ANIM[k].frames[Math.max(0, Math.min(n, ANIM[k].frames.length - 1))] || {};\n'
      + '    paintHalves(root, f.halves || {});\n'
      + '    paintActors(root, f.actors || {});\n'
      + '  }\n\n'
      + '  return { KEYS: KEYS, owns: owns, apply: apply, clear: clearAnimationClasses, derive: paintDerived,\n'
      + '    frameTotal: function (key) { var k = key.slice(' + PREFIX.length + '); return ANIM[k] ? ANIM[k].frames.length : 1; } };\n'
      + '}());\n\n'
      + '(function () {\n'
      + '  // Each telomere panel joins the shared tables: its caption in META and a\n'
      + '  // frame table stub in ANIM, which the shared transport counts frames by.\n'
      + '  var meta = ' + JSON.stringify(meta) + ';\n'
      + '  var stubs = ' + JSON.stringify(stubs) + ';\n'
      + '  var k;\n'
      + '  if (typeof window === \'undefined\') { return; }\n'
      + '  window.META = window.META || {};\n'
      + '  window.ANIM = window.ANIM || {};\n'
      + '  for (k in meta) { if (Object.prototype.hasOwnProperty.call(meta, k)) { window.META[k] = meta[k]; } }\n'
      + '  for (k in stubs) { if (Object.prototype.hasOwnProperty.call(stubs, k)) { window.ANIM[k] = stubs[k]; } }\n'
      + '  window.TELO = TELO;\n'
      + '  window.TELOMERE_LINE = ' + JSON.stringify(d.line.map(function (k) { return PREFIX + k; })) + ';\n'
      + '}());\n';
  }

  function scopeStyle() {
    // MODEL: the telomere colours, flowchart, glyph vocabulary and states, scoped to the telomere panels (TERMINAL)
    const css = fs.readFileSync(path.join(TSRC, 'style.css'), 'utf8').replace(/\/\*[\s\S]*?\*\//g, '');
    const raw = fs.readFileSync(path.join(TSRC, 'style.css'), 'utf8');
    const sec = function (a, b) {
      const s = raw.indexOf(a), e = b ? raw.indexOf(b) : raw.length;
      if (s < 0 || e < 0) { throw new Error('style section not found: ' + a); }
      return raw.slice(s, e).replace(/\/\*[\s\S]*?\*\//g, '');
    };
    const vars = /:root\s*\{([\s\S]*?)\}/.exec(css)[1];
    const nav = sec('/* -- 2. nav flowchart', '/* -- 3. panel glyph vocabulary');
    const glyphs = sec('/* -- 3. panel glyph vocabulary', '/* -- 5. transport controls');
    return '/* Generated by tools/port_telomere.js from telomere/src/style.css. Do not edit.\n'
      + '   The telomere colours apply inside the telomere panels and chart only, so\n'
      + '   the replication sheet keeps its own values where a name is shared. */\n\n'
      + '.telo, .telonav {' + vars + '}\n\n'
      + scope(nav, function (sel) {
        sel = sel.replace(/\.sel\b/g, '.selected');
        return sel.indexOf('#flow') === 0 ? sel.replace('#flow', '#navsvg-telomere') : '.telonav ' + sel;
      }) + '\n'
      + scope(glyphs, function (sel) {
        // The flowchart draws a few glyph-section classes too (its cell-cycle rail).
        if (sel.indexOf('.panelsvg') === 0) { return sel.replace('.panelsvg', '.panelsvg.telo'); }
        return '.telo ' + sel + ',.telonav ' + sel;
      }) + '\n';

    function scope(text, fix) {
      // MODEL: every selector in text rewritten by fix, at-rules recursed into (TERMINAL)
      let out = '', i = 0, depth, j, head, body;
      while (i < text.length) {
        j = text.indexOf('{', i);
        if (j < 0) { break; }
        head = text.slice(i, j).trim();
        depth = 1;
        let k = j + 1;
        while (k < text.length && depth > 0) {
          if (text[k] === '{') { depth += 1; }
          if (text[k] === '}') { depth -= 1; }
          k += 1;
        }
        body = text.slice(j + 1, k - 1);
        if (head.indexOf('@') === 0) {
          out += head + '{' + scope(body, fix) + '}\n';
        } else if (head) {
          out += splitSelectors(head).map(function (s) { return fix(s.trim()); }).join(',') + '{' + body.trim() + '}\n';
        }
        i = k;
      }
      return out;
    }

    function splitSelectors(head) {
      // MODEL: a selector list split at top-level commas (TERMINAL)
      const parts = [];
      let d = 0, cur = '';
      for (const ch of head) {
        if (ch === '(') { d += 1; }
        if (ch === ')') { d -= 1; }
        if (ch === ',' && d === 0) { parts.push(cur); cur = ''; } else { cur += ch; }
      }
      parts.push(cur);
      return parts.filter(function (p) { return p.trim(); });
    }
  }

  function mergeBib() {
    // MODEL: the telomere entries whose keys the replication bibliography lacks (TERMINAL)
    const have = {}, out = [];
    const rep = fs.readFileSync(path.join(OUT, 'refs.bib'), 'utf8');
    (rep.match(/@\w+\s*\{\s*([^,\s]+)\s*,/g) || []).forEach(function (m) {
      have[/\{\s*([^,\s]+)/.exec(m)[1].toLowerCase()] = true;
    });
    const tel = fs.readFileSync(path.join(TSRC, 'refs.bib'), 'utf8');
    const re = /@\w+\s*\{\s*([^,\s]+)\s*,/g;
    let m, starts = [];
    while ((m = re.exec(tel)) !== null) { starts.push([m.index, m[1]]); }
    starts.forEach(function (s, n) {
      const end = n + 1 < starts.length ? starts[n + 1][0] : tel.length;
      if (!have[s[1].toLowerCase()]) { out.push(tel.slice(s[0], end).trim()); }
    });
    return '% Generated by tools/port_telomere.js: telomere/src/refs.bib entries\n'
      + '% that src/refs.bib does not carry. Do not edit.\n\n' + out.join('\n\n') + '\n';
  }

  function writeOutputs(panels, nav, engine, css, bib) {
    // VIEW: write every output and report the counts (TERMINAL)
    const dir = path.join(OUT, 'tw-panels');
    fs.mkdirSync(dir, { recursive: true });
    fs.readdirSync(dir).forEach(function (f) { if (/\.svg$/.test(f)) { fs.unlinkSync(path.join(dir, f)); } });
    Object.keys(panels).forEach(function (k) { fs.writeFileSync(path.join(dir, k + '.svg'), panels[k] + '\n'); });
    fs.writeFileSync(path.join(OUT, 'nav-telomere.svg'), nav + '\n');
    fs.writeFileSync(path.join(OUT, 'telo-engine.js'), engine);
    fs.writeFileSync(path.join(OUT, 'telo-style.css'), css);
    fs.writeFileSync(path.join(OUT, 'telo-refs.bib'), bib);
    console.log('ported ' + Object.keys(panels).length + ' telomere panels, the chart, the engine, '
      + 'the scoped style and ' + (bib.match(/^@/gm) || []).length + ' new references');
  }
}

main();
