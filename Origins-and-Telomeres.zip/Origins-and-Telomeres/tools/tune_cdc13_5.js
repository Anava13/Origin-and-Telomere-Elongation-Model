// Solve RULE.c5Gain, the factor by which cdc13-5 raises telomerase
// recruitment, so that cdc13-5 lineages settle 750 bp longer than wild type,
// the middle of the 500 to 1000 bp elongation of Chandra et al. 2001. The
// plateau is read off the lineages: the mean end length over divisions 150
// to 300 of several lineages from a wild-type founder.
//
//   node tools/tune_cdc13_5.js
global.window = {};
const R = require('../src/chrom-rule.js');
const SEEDS = [1, 2, 3, 4], TARGET = 750, FROM = 150, TO = 300;

function plateau(alleles) {
  let sum = 0, n = 0;
  SEEDS.forEach(function (seed) {
    const run = R.lineage(seed, { alleles: alleles, max: TO, founder: { L: 325, R: 325 } });
    run.pages.forEach(function (p) {
      if (p.g >= FROM && p.L.capped && p.R.capped) { sum += p.L.bp + p.R.bp; n += 2; }
    });
  });
  return sum / n;
}

const wt = plateau({});
let lo = 0, hi = Math.log(1e6);
for (let i = 0; i < 16; i += 1) {
  const mid = (lo + hi) / 2;
  R.RULE.c5Gain = Math.exp(mid);
  if (plateau({ cdc13_5: true }) - wt < TARGET) { lo = mid; } else { hi = mid; }
}
const g = Math.exp((lo + hi) / 2);
R.RULE.c5Gain = g;
console.log('wild-type plateau', wt.toFixed(0), 'bp');
console.log('c5Gain', g.toPrecision(3), 'cdc13-5 plateau', plateau({ cdc13_5: true }).toFixed(0), 'bp');
