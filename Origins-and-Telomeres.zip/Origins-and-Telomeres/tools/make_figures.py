"""Export the origin-firing dissertation figures from the built animation.

    python3 build.py && python3 tools/make_figures.py
    python3 tools/make_figures.py fig-ddk                     # one figure
    python3 tools/make_figures.py --viewer dist/other.html    # a named viewer

Writes one SVG per figure into origin-firing-figures/, a PDF beside each when
cairosvg is installed, and origin-firing-figures/manifest.txt recording which
frame each part resolved to.

Why a browser. A frame is not a file. src/panels/*.svg holds every element in
its resting state with everything else pending, and a frame only exists once
src/animate.js has applied the frame table and run paintDerived, which places
the derived actors, tints the zones and writes the strand and complex states
onto the positions. None of that is on disk, so this drives the real page and
reads the result, which keeps the figures in step with the animation and
reimplements none of the engine.

Why the styles get flattened. Letting the browser resolve the cascade and
writing the computed values onto each element leaves an SVG with no stylesheet,
which converts to PDF cleanly. Transforms are baked the same way: each element's
transform is read back from the browser as a matrix relative to its parent, so
the export is right whether the engine writes transforms as attributes or as
CSS, and whatever transform-origin the stylesheet sets.

Frames are chosen by predicate, never by index. Frame tables get edited and
indices move. A predicate either matches or fails loudly, and the manifest says
what it picked, so a wrong choice is visible rather than silent.

What this assumes about the page. The built viewer exposes selectStep(key) and
runAnimation('goto', n), defines ANIM at top level, as the telomere viewer does, and inlines each panel
svg with the data-key attribute make_panels.py writes on it. The script checks
all four on load and stops with the missing one named.

A part can also be a navigation chart. Its panel is named "nav-" and the page,
so "nav-steps" is the steps chart, found by the id make_panels.py gives it
(navsvg-steps). The chart is brought forward with selectNavPage, which the
viewer also exposes, and printed with no node selected. The steps chart with
its context badges dropped is the overview of where each CST firing model
acts, since every model hangs a badge off the step it acts at.
"""

import glob
import os
import pathlib
import re
import sys

OUT_DIRNAME = "origin-firing-figures"

# Removed from every part. The status indicator and the free note under each
# panel are screen furniture: the indicator needs its own legend and the note
# restates what the dissertation caption says, at a size print cannot carry.
# The pointer labels narrate how the drawing was built ("the clasp is cut to
# the bare pair"), which is right for the viewer and wrong for a figure. Fit
# points draw nothing. The complex-state track under the substrate is an
# indicator row with no legend in print; delete ".cpxlayer" here to keep it.
DROP_ALWAYS = [".capbar", ".notelab", ".polelab", ".fitpt", ".cpxlayer"]

# CSS that would otherwise leave a captured frame mid-transition. The telomere
# stylesheet answered prefers-reduced-motion itself; this one may not, so the
# page gets transitions and animations switched off outright.
FREEZE_CSS = ("*, *::before, *::after { transition: none !important; "
              "animation: none !important; }")

# ---------------------------------------------------------------------------
# The figure list. One figure belongs to one section of the chapter. Each part
# names a panel and how to find its frame:
#
#   "frame": "last" | "static" | {"when": <js>, "pick": "first"|"middle"|"last"}
#
# The js runs in the page with k bound to the panel key and these helpers:
#   F.vis(k, sel)        the element is drawn on this frame
#   F.cls(k, sel, name)  the element carries a state class on this frame
#   F.home(k, id)        the actor sits at its base position on this frame
#
# A part may also carry:
#   "drop":  selectors removed from that part only
#   "solid": selectors drawn at full opacity on that part only. The stylesheet
#            draws a wrapper that is arriving or fading at half opacity, which
#            prints faint. Use it only where the frame's claim includes the
#            element, so printing it at full strength states nothing the frame
#            does not.
# ---------------------------------------------------------------------------
FIGURES = [
    # crop is the margin, in panel units, kept either side of the molecules
    # in each column; each part is captured inside its column's window. The
    # flanking nucleosomes take more than half of every 880-wide panel, and
    # the drawing prints larger once they go.
    #
    # cols lays the parts out row by row in that many columns. Once cropped,
    # a part is about half as wide as a panel and far wider than it is tall,
    # so a single column makes the figure tall and narrow, and on the page its
    # height sets the scale. Two columns bring the figure close to the
    # proportions of the space it goes in, and every glyph prints larger.
    # One column is used where the rows compare one pair across frames: the
    # parts then share one window, so the pair sits at the same x in every
    # row and only what changed moves.

    # Section 1, the Mcm2-7 helicase. The glyph key: ring order, one subunit,
    # the gate open and closed, and the near and far arcs every later figure
    # draws with. The panel carries no substrate, so the crop measures
    # everything drawn. Its one pointer label goes with DROP_ALWAYS.
    {"id": "fig-mcm-glyph", "cols": 1, "dividers": False, "crop": 12,
     "parts": [{"panel": "ctxMCM", "frame": "static"}]},

    # Section 2, licensing. Helicase loading in G1. The predicates test the
    # presence class on fx wrappers and the classes on the complex and strand
    # tracks, never actor offsets, so moving a glyph does not break them.
    # F.cls(...,'present') is used on fx wrappers instead of F.vis, because
    # F.vis also passes a wrapper that is arriving or fading, which the
    # stylesheet draws at half opacity and which prints faint.
    #
    # Factors that have left the origin are dropped by id. They sit near the
    # canvas edges on the frames chosen here, and left in they would widen the
    # column window to most of the panel.
    #
    # Column 0 (A, C, E) is the narrower column, about 165 units once cropped.
    # A title wider than its column wraps onto a second line.
    {"id": "fig-licensing", "cols": 2, "dividers": True, "crop": 12,
     "parts": [
         # Cdc6 fully seated in the ORC notch, with the bend in its fixed
         # form. Frame 1 has Cdc6 still arriving.
         {"panel": "step02", "label": "(A)",
          "title": "Cdc6 joins ORC",
          "frame": {"when": "F.cls(k,'#fx-cdc6','present') && "
                            "F.cls(k,'#o03-s','kink-fixed')", "pick": "last"}},
         # The OCCM with Cdc6 still in the notch and the ring open at the
         # Mcm2-Mcm5 gate.
         {"panel": "step03", "label": "(B)",
          "title": "Mcm2-7 docks on ORC-Cdc6",
          "frame": {"when": "F.cls(k,'#o08-c','occm') && "
                            "F.cls(k,'#fx-cdc6','present')", "pick": "first"}},
         # Cdc6 gone from the notch while Cdt1 is still bound. The empty notch
         # carries the release order; the departing Cdc6 is dropped.
         {"panel": "step03", "label": "(C)", "drop": ["#actor-cdc6out"],
          "title": "Cdc6 leaves first",
          "frame": {"when": "F.cls(k,'#o08-c','occm') && "
                            "F.cls(k,'#fx-cdc6','gone')", "pick": "first"}},
         # The first hexamer closed around DNA, with both loading factors
         # released.
         {"panel": "step03", "label": "(D)",
          "drop": ["#actor-cdc6out", "#actor-cdt1out"],
          "title": "The first ring closes",
          "frame": {"when": "F.cls(k,'#o08-c','mcm1') && "
                            "F.cls(k,'#o08-c','gate-closed') && "
                            "F.cls(k,'#o08-c','present')", "pick": "first"}},
         # Cdc6 back in the notch beside the loaded hexamer. The frame before
         # has it still arriving.
         {"panel": "step04", "label": "(E)",
          "title": "Cdc6 returns to ORC",
          "frame": {"when": "F.cls(k,'#fx-cdc6','present') && "
                            "F.cls(k,'#fx-cdc6in','gone')", "pick": "first"}},
         # The licensed double hexamer once Cdc6 and Cdt1 have both left. ORC
         # is drawn dim, which the caption has to read as finished, not gone,
         # since ORC stays bound. The seated NSD is dropped because this
         # section does not discuss it.
         {"panel": "step05", "label": "(F)",
          "drop": ["#actor-cdc6out2", "#actor-cdt1out2", "#nsdseat"],
          "title": "Two hexamers, head to head",
          "frame": {"when": "F.cls(k,'#o08-c','mcm2') && "
                            "F.cls(k,'#fx-cdc6','gone') && "
                            "F.cls(k,'#fx-cdt1pry','gone')", "pick": "first"}}]},

    # Section 4, DDK. Four frames of step06 in one column, so the pair holds
    # its x and the NSD and the marks are what change: seated, displaced by the
    # docked kinase before any mark lands, marked on the frame the kinase
    # places them, then marked once the kinase has left.
    {"id": "fig-ddk", "cols": 1, "dividers": True, "crop": 12,
     "parts": [
         # DDK waits beside a pair whose NSD is still seated and whose tails
         # carry no mark. Frame 1 has the kinase in flight, so home() is what
         # keeps this on the resting frame.
         {"panel": "step06", "label": "(A)",
          "title": "Licensed double hexamer, NSD seated",
          "frame": {"when": "F.vis(k,'#nsdseat') && F.cls(k,'#fx-phos','gone') && "
                            "F.home(k,'actor-ddk')", "pick": "first"}},
         # DDK docked over the seam and the NSD off its seat, with no mark yet.
         {"panel": "step06", "label": "(B)",
          "title": "DDK docks and Dbf4 displaces the NSD",
          "frame": {"when": "F.vis(k,'#nsdfree') && F.cls(k,'#fx-phos','gone')",
                    "pick": "first"}},
         # The one frame that carries the phosphorylation arrows. The marks
         # arrive on it, which the stylesheet draws at half strength; the
         # arrows say the kinase is placing them, so they print solid.
         {"panel": "step06", "label": "(C)", "solid": ["#fx-phos"],
          "title": "Cdc7 marks the Mcm4 and Mcm6 tails",
          "frame": {"when": "F.cls(k,'#fx-kin-ddk-4','present')", "pick": "first"}},
         # The last frame, with the marks at full strength. The kinase has
         # left the pair on this frame and is dropped, since in its column it
         # would set the window for a glyph that is no longer acting on
         # anything.
         {"panel": "step06", "label": "(D)", "drop": ["#actor-ddk"],
          "title": "The marks remain after DDK leaves",
          "frame": {"when": "F.cls(k,'#fx-phos','present') && F.vis(k,'#nsdfree')",
                    "pick": "last"}}]},

    # Section 5, Sld3, Cdc45 and Dpb11 through to CMG formation. The split
    # into two CMGs and the ADP to ATP exchange belong to this section's text,
    # so the split frame closes this figure. S-CDK places its two marks on two
    # frames from two positions, and each phosphorylation arrow is drawn only
    # from where the kinase stands on its own frame, so the two marks take a
    # part each. Five parts in reading order leave the last slot empty.
    {"id": "fig-cmg-assembly", "cols": 2, "dividers": True, "crop": 12,
     "parts": [
         # Clasp seated, Cdc45 partly seated on Mcm5, Mcm2 marks down.
         {"panel": "step07", "label": "(A)",
          "title": "Sld3-Sld7 reads the marks, Cdc45 partly seats",
          "frame": {"when": "F.vis(k,'#fx-mcm2p') && F.vis(k,'#fx-cdc45')",
                    "pick": "last"}},
         # The frame S-CDK marks Sld2, with its arrow. The mark is arriving on
         # this frame and prints solid, as the fig-ddk marks do.
         {"panel": "step08", "label": "(B)", "solid": ["#fx-sld2p"],
          "title": "S-CDK marks Sld2",
          "frame": {"when": "F.cls(k,'#fx-kin-sld2','present')", "pick": "first"}},
         # The frame S-CDK marks Sld3 on the clasp, with its arrow.
         {"panel": "step08", "label": "(C)", "solid": ["#fx-sld3p"],
          "title": "S-CDK marks Sld3",
          "frame": {"when": "F.cls(k,'#fx-kin-sld3','present')", "pick": "first"}},
         # The Dpb11 module docked on the Sld3 mark with GINS still on it, one
         # frame before Cdc45 transfers and the pair splits.
         {"panel": "step09", "label": "(D)",
          "title": "Dpb11 brings Sld2 and GINS",
          "frame": {"when": "F.home(k,'actor-dpb11') && F.vis(k,'#fx-ginsfree')",
                    "pick": "first"}},
         # The first frame of two CMGs, while Sld3, Dpb11 and Sld2 are still
         # bound, which is what the text says: none of them has left at the
         # split. The free GINS bar is fading into the two CMGs and is
         # dropped. The nucleotide disc is arriving on this frame; the model
         # places the exchange in the frame the pair splits, so it is printed
         # at full strength.
         {"panel": "step09", "label": "(E)",
          "drop": ["#fx-ginsfree"], "solid": ["#fx-atpx"],
          "title": "Two CMGs form, ADP is exchanged for ATP",
          "frame": {"when": "F.cls(k,'#o08-c','cmg') && "
                            "F.cls(k,'#fx-dpb11out','present')", "pick": "first"}}]},

    # Section 6, Mcm10 and Sld2. One column, so the two CMGs sit at the same
    # x in every row and the reader sees them separate against a fixed frame,
    # which is the camera the animation uses.
    {"id": "fig-firing-activation", "cols": 1, "dividers": True, "crop": 12,
     "parts": [
         # Mcm10 bound, ATP hydrolysis drawn, and the bubble part way open:
         # melted at o08 but not yet at o07.
         {"panel": "step10", "label": "(A)",
          "title": "Mcm10 binds and melting begins at the centre",
          "frame": {"when": "F.cls(k,'#o08-s','melted') && "
                            "!F.cls(k,'#o07-s','melted')", "pick": "first"}},
         # Extruded strands and fully separated CMGs. Mcm10 is drawn fading on
         # this frame, which the caption reads as release.
         {"panel": "step10", "label": "(B)",
          "title": "The strands extrude and the CMGs separate",
          "frame": "last"},
         # The core copied and both forks moving out, while they are still
         # close enough to the origin that this part does not set a window
         # far wider than the two above it: duplex at o03, template open at
         # o04, new DNA from o08. Ctf4 is dropped: the chapter never introduces
         # it, and a glyph the text does not name is one the reader cannot place.
         {"panel": "step11", "label": "(C)", "drop": ["#actor-ctf4"],
          "title": "Bidirectional forks leave the origin",
          "frame": {"when": "F.cls(k,'#o03-s','duplex') && "
                            "F.cls(k,'#o04-s','extruded') && "
                            "F.cls(k,'#o08-s','replicated')", "pick": "first"}}]},

    # Section 8, the bypasses. No DDK first, then the three routes that reach
    # Sld3-Cdc45 recruitment without it. The condition strips are dropped,
    # since each part title names its condition. offDDK is taken on the frame
    # the clasp comes to rest against the seated NSD.
    {"id": "fig-ddk-bypass", "cols": 2, "dividers": True, "crop": 12,
     "parts": [
         {"panel": "offDDK", "label": "(A)", "drop": ["#fx-cond-ddk"],
          "title": "No DDK, the clasp stops",
          "frame": {"when": "F.cls(k,'#fx-blocklab','present')", "pick": "first"}},
         {"panel": "offMCM4N", "label": "(B)", "drop": ["#fx-cond-noddk"],
          "title": "Mcm4 NSD deleted",
          "frame": "static"},
         {"panel": "offPHOS", "label": "(C)", "drop": ["#fx-cond-noddk"],
          "title": "Mcm4 and Mcm6 phosphomimetic",
          "frame": "static"},
         {"panel": "offBOB1", "label": "(D)", "drop": ["#fx-cond-noddk"],
          "title": "mcm5-bob1",
          "frame": "static"}]},

    # Section 10, Rif1-PP1. One static panel: DDK and Rif1-PP1 acting on the
    # same marks of one licensed pair.
    {"id": "fig-rif1", "cols": 1, "dividers": False, "crop": 12,
     "parts": [{"panel": "regRIF1", "frame": "static"}]},

    # The firing models for CST, from the third chart, one figure per section
    # of the chapter. Each section's models are drawn together on one parent
    # panel, so each figure prints that panel and nothing to compare it with.
    #
    # The DDK-dependent route: the Mcm2-7 conformation, Cdc7-retention and
    # Rif1-PP1 inhibition models on one docked, marked pair.
    {"id": "fig-cst-ddk-dependent", "cols": 1, "dividers": False, "crop": 12,
     "parts": [{"panel": "cstDDK", "frame": "static"}]},

    # The DDK-independent route: the conformation model without DDK beside the
    # models downstream of the Rad53 block. The bob1 condition strip goes, and
    # the caption carries the genotype and the HU condition. The flanking nucleosomes go from both parts: the
    # models act on the origin, and nucleosomes cut off at the window edge
    # read as part of the picture.
    {"id": "fig-cst-ddk-independent", "cols": 2, "dividers": True, "crop": 12,
     "parts": [
         {"panel": "cstBOB1", "label": "(A)", "drop": ["#fx-cond-bob1", ".nuclayer"],
          "title": "Mcm2-7 conformation model without DDK",
          "frame": "static"},
         {"panel": "cstDOWN", "label": "(B)", "drop": [".nuclayer"],
          "title": "Downstream of the Rad53 block",
          "frame": "static"}]},

    # Where each model acts: the steps chart with the context badges dropped,
    # so the second row of badges, one per model, is all that hangs off the
    # main line. Not cropped, since a chart has no molecules to zoom to.
    {"id": "fig-cst-overview", "cols": 1, "dividers": False, "crop": None,
     "parts": [{"panel": "nav-steps", "frame": "static",
                "drop": [".navbadge.ctxb"]}]},
]

# The part title face. Titles are measured in the page in this face and drawn
# in it, so the width a title is wrapped to is the width it prints at.
TITLE_FONT = "'Times New Roman',Times,serif"
TITLE_SIZE = 16
TITLE_WEIGHT = 600
TITLE_LEAD = 19               # baseline to baseline when a title wraps
TITLE_CLEAR = 4               # how far a title may run past either column edge

# Properties worth carrying onto each element. "none" is a real value for fill
# and the SVG default is black, so dropping it would turn every unfilled shape
# into a solid one. It is only safe to drop where the initial value is none.
DROPPABLE_NONE = ["filter", "stroke-dasharray"]

STYLE_PROPS = ["fill", "fill-opacity", "fill-rule", "stroke", "stroke-width",
               "stroke-opacity", "stroke-dasharray", "stroke-linecap",
               "stroke-linejoin", "opacity", "font-family", "font-size",
               "font-weight", "font-style", "letter-spacing", "text-anchor",
               "dominant-baseline", "filter"]

PAGE_API = r"""
// ANIM is a top-level const in its script, so it lives in the global lexical
// scope and never appears on window. It is reachable by bare reference from
// any script in the same realm, which is what this does once.
window.__ANIM = (typeof ANIM !== 'undefined') ? ANIM : {};

var DRAWN = ['rect', 'circle', 'ellipse', 'path', 'line', 'polygon',
             'polyline', 'text', 'use'];

// Hidden by anything between the element and the panel: display, visibility
// or an opacity the engine has taken to zero. Opacity does not inherit in the
// computed style, so an element inside a faded group reports opacity 1 on its
// own, which is why this walks up.
function hiddenIn(e, stop) {
  for (var n = e; n && n !== stop; n = n.parentElement) {
    var cs = window.getComputedStyle(n);
    if (cs.display === 'none' || cs.visibility === 'hidden' ||
        parseFloat(cs.opacity) < 0.05) { return true; }
  }
  return false;
}

function keep(prop, v) {
  if (!v || v === 'normal' || v === 'auto') { return false; }
  if (v === 'none') { return window.__dropNone.indexOf(prop) === -1; }
  return true;
}

// The transform of one element relative to its parent, as the browser renders
// it, whatever wrote it. Returns null for identity.
function localMatrix(el) {
  var p = el.parentElement;
  if (!el.getScreenCTM || !p || !p.getScreenCTM) { return null; }
  var me = el.getScreenCTM(), up = p.getScreenCTM();
  if (!me || !up) { return null; }
  var m = up.inverse().multiply(me);
  var v = [m.a, m.b, m.c, m.d, m.e, m.f].map(function (x) {
    return Math.round(x * 10000) / 10000;
  });
  if (v[0] === 1 && v[1] === 0 && v[2] === 0 && v[3] === 1 &&
      v[4] === 0 && v[5] === 0) { return null; }
  return 'matrix(' + v.join(' ') + ')';
}

function nextPaint() {
  return new Promise(function (r) {
    requestAnimationFrame(function () { requestAnimationFrame(r); });
  });
}

window.F = {
  // The panel svg itself. make_panels.py writes data-key on every panel's
  // outer svg, so this finds the panel however the viewer wraps it.
  root: function (k) {
    if (k.indexOf('nav-') === 0) {
      return document.getElementById('navsvg-' + k.slice(4));
    }
    return document.querySelector('svg[data-key="' + k + '"]');
  },
  frames: function (k) {
    return window.__ANIM[k] ? window.__ANIM[k].frames.length : 0;
  },
  seek: async function (k, n) {
    // A chart has no frames. It is brought forward so it is laid out, and no
    // node is left selected: in print the chart is an overview, not a place
    // the reader is standing. The next panel part reselects as it seeks.
    if (k.indexOf('nav-') === 0) {
      window.selectNavPage(k.slice(4));
      document.querySelectorAll('#navwrap .navnode.selected').forEach(function (e) {
        e.classList.remove('selected');
      });
      window.__figFrame = n;
      await nextPaint();
      return;
    }
    window.selectStep(k);
    // This engine's command is goto. selectStep has already reset the panel
    // and made it the one goto acts on.
    if (window.__ANIM[k]) { window.runAnimation('goto', n); }
    window.__figFrame = n;
    await nextPaint();
  },
  vis: function (k, sel) {
    var root = window.F.root(k), e = root && root.querySelector(sel);
    return !!e && !hiddenIn(e, root);
  },
  cls: function (k, sel, name) {
    var root = window.F.root(k), e = root && root.querySelector(sel);
    return !!e && e.classList.contains(name);
  },
  // Actor offsets live in the frame table and not the DOM, since a transform
  // of zero and no transform look the same. A scalar is an x offset.
  at: function (k, id) {
    var f = window.__figFrame, tab = window.__ANIM[k];
    if (!tab || f === undefined || f === null) { return null; }
    var e = (tab.frames[f].actors || {})[id];
    if (e === undefined) { return null; }
    return Array.isArray(e) ? [e[0], e[1]] : [e, 0];
  },
  home: function (k, id) {
    var a = window.F.at(k, id);
    return a !== null && a[0] === 0 && a[1] === 0;
  },
  // Full opacity on the named elements while on is true, and the stylesheet's
  // value back once it is false. Inline and important, so it wins over the
  // class that draws an arriving or fading wrapper at half strength. It does
  // nothing for a wrapper the stylesheet hides outright.
  solid: function (k, sels, on) {
    var root = window.F.root(k);
    if (!root) { return; }
    (sels || []).forEach(function (sel) {
      root.querySelectorAll(sel).forEach(function (e) {
        if (on) { e.style.setProperty('opacity', '1', 'important'); }
        else { e.style.removeProperty('opacity'); }
      });
    });
  },

  // win is [x0, x1] in panel units, or null for the whole panel. Everything
  // outside it is dropped and the height trim only sees what is left, which
  // is what makes this a zoom and not only a crop: a glyph cut off at the side
  // no longer holds the top or bottom of the part open.
  flatten: function (k, drop, props, trim, win) {
    var src = window.F.root(k);
    if (!src) { return null; }
    var clone = src.cloneNode(true);
    var vb = src.viewBox.baseVal, box = src.getBoundingClientRect();
    var sc = vb.width / box.width;
    var lim = {x0: win ? win[0] : vb.x, x1: win ? win[1] : vb.x + vb.width,
               y0: vb.y, y1: vb.y + vb.height};
    // Where the shapes sit, for centring titles on the drawing. Text is left
    // out because annotation would drag the centre off the molecule.
    var ink = {lo: 1e9, hi: -1e9};
    // Everything drawn, text included, which is what a trim has to clear.
    var full = {y0: 1e9, y1: -1e9};
    // The drawn extent of the molecules and their labels, leaving out the
    // substrate layers that run the full width of every panel by design:
    // zones, nucleosomes, strand bars and the complex track. This is what a
    // horizontal crop keeps, and where a title is centred.
    var core = {lo: 1e9, hi: -1e9};
    var BACKDROP = '.zonelayer, .nuclayer, .strandlayer, .cpxlayer';

    // Mark the descendants too. Removal takes the subtree either way, but the
    // extent measurement below tests each element on its own, and without this
    // the children of a dropped group would still count.
    (drop || []).forEach(function (sel) {
      clone.querySelectorAll(sel).forEach(function (e) {
        e.setAttribute('data-drop', '1');
        e.querySelectorAll('*').forEach(function (c) {
          c.setAttribute('data-drop', '1');
        });
      });
    });

    var a = src.querySelectorAll('*'), b = clone.querySelectorAll('*');
    for (var i = 0; i < a.length; i++) {
      var tag = a[i].tagName.toLowerCase(), inDefs = !!a[i].closest('defs');
      var cs = window.getComputedStyle(a[i]), bits = [];
      for (var j = 0; j < props.length; j++) {
        var v = cs.getPropertyValue(props[j]);
        if (keep(props[j], v)) { bits.push(props[j] + ':' + v); }
      }
      // Not in this frame: the engine has hidden it. Carried as invisible
      // markup it would sit in the file where an editor can find it and a
      // reader cannot.
      //
      // Its descendants go with it. Opacity does not inherit in the computed
      // style, so the children of a hidden group report themselves visible, and
      // without this their boxes still counted towards the crop and the trim.
      if (!inDefs && (cs.display === 'none' || cs.visibility === 'hidden' ||
                      parseFloat(cs.opacity) < 0.02)) {
        b[i].setAttribute('data-drop', '1');
        b[i].querySelectorAll('*').forEach(function (c) {
          c.setAttribute('data-drop', '1');
        });
      }
      var r = a[i].getBoundingClientRect(), drawn = r.width || r.height;
      var x0 = (r.left - box.left) * sc + vb.x, x1 = x0 + r.width * sc;
      var y0 = (r.top - box.top) * sc + vb.y, y1 = y0 + r.height * sc;
      // Outside the viewBox. A browser clips to it; Inkscape exports the
      // bounding box of the drawing instead and would put it back.
      if (!inDefs && drawn &&
          (x1 < lim.x0 || x0 > lim.x1 || y1 < lim.y0 || y0 > lim.y1)) {
        b[i].setAttribute('data-drop', '1');
      }
      var live = !inDefs && !b[i].hasAttribute('data-drop') &&
                 DRAWN.indexOf(tag) !== -1 && drawn;
      if (live && tag !== 'text') {
        var i0 = Math.max(x0, lim.x0), i1 = Math.min(x1, lim.x1);
        if (i1 > i0) { ink.lo = Math.min(ink.lo, i0); ink.hi = Math.max(ink.hi, i1); }
      }
      if (live && x1 > lim.x0 && x0 < lim.x1) {
        full.y0 = Math.min(full.y0, y0);
        full.y1 = Math.max(full.y1, y1);
        if (!a[i].closest(BACKDROP)) {
          core.lo = Math.min(core.lo, Math.max(x0, lim.x0));
          core.hi = Math.max(core.hi, Math.min(x1, lim.x1));
        }
      }
      if (!inDefs) {
        var m = localMatrix(a[i]);
        if (m) { b[i].setAttribute('transform', m); }
        else { b[i].removeAttribute('transform'); }
      }
      b[i].setAttribute('style', bits.join(';'));
      b[i].removeAttribute('class');
    }
    if (ink.hi > ink.lo) {
      clone.setAttribute('data-ink', Math.round(ink.lo) + ' ' + Math.round(ink.hi));
    }
    if (core.hi > core.lo) {
      clone.setAttribute('data-core',
                         Math.floor(core.lo) + ' ' + Math.ceil(core.hi));
    }
    // Trim to what is drawn. Anything left outside the new box is cut by the
    // clip the composer puts on every part.
    var ty = vb.y, th = vb.height;
    if (trim && full.y1 > full.y0) {
      var pad = 8;
      ty = Math.max(vb.y, Math.floor(full.y0 - pad));
      th = Math.min(vb.y + vb.height, Math.ceil(full.y1 + pad)) - ty;
    }
    clone.setAttribute('viewBox', lim.x0 + ' ' + ty + ' ' +
                       (lim.x1 - lim.x0) + ' ' + th);
    clone.querySelectorAll('[data-drop]').forEach(function (e) { e.remove(); });
    clone.removeAttribute('class');
    return clone.outerHTML;
  }
};
"""

# What the page has to provide, each as a check that names what is missing.
PAGE_CHECKS = [
    ("selectStep", "typeof selectStep === 'function'"),
    ("runAnimation", "typeof runAnimation === 'function'"),
    ("ANIM", "typeof ANIM !== 'undefined'"),
    ("a panel svg with data-key=\"step06\"",
     "!!document.querySelector('svg[data-key=\"step06\"]')"),
    ("selectNavPage", "typeof selectNavPage === 'function'"),
    ("the steps chart, id navsvg-steps", "!!document.getElementById('navsvg-steps')"),
]
# ===========================================================================
# MAIN CONTROLLER
# ===========================================================================

def build_figures(root=None, out_dir=None, only=None, viewer=None):
    """CONTROLLER: export every figure in FIGURES to out_dir as flattened SVG.

    Coordinates the base controllers below: open the viewer, resolve each part
    to a frame, capture it, measure the part titles, compose the parts into one
    figure, write it out.
    """
    root = root or _project_root()
    out_dir = out_dir or os.path.join(root, OUT_DIRNAME)

    # === CHECK INPUTS ===
    viewer = viewer or find_viewer(root)
    stale = newer_sources(root, viewer)
    if stale:
        sys.exit("%s is older than %d source file(s), including %s.\n"
                 "It does not carry the current panels and frame tables, so the "
                 "frame predicates\nwould test an old model. Rebuild first:\n"
                 "  python3 tools/make_panels.py\n"
                 "  python3 tools/make_shell.py\n"
                 "  python3 build.py"
                 % (os.path.relpath(viewer, root), len(stale),
                    ", ".join(stale[:3])))
    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        sys.exit("playwright not installed:\n"
                 "  pip install playwright && playwright install chromium")
    if not os.path.isdir(out_dir):
        os.makedirs(out_dir)

    todo = [f for f in FIGURES if only is None or f["id"] in only]
    if not todo:
        sys.exit("no figure matches %s. Known: %s"
                 % (sorted(only), ", ".join(f["id"] for f in FIGURES)))
    report, written = [], []

    # === COORDINATE BASE CONTROLLERS ===
    with sync_playwright() as pw:
        # FIG_CHROME names a Chromium build to use instead of the one
        # playwright installs, for machines where that download is blocked.
        browser = pw.chromium.launch(
            executable_path=os.environ.get("FIG_CHROME") or None)
        page = browser.new_context(reduced_motion="reduce").new_page()
        open_viewer(page, viewer)

        for fig in todo:
            parts = capture_figure(page, fig)
            widths = measure_title_words(page, fig)
            for n, (part, got) in enumerate(zip(fig["parts"], parts)):
                report.append("%-22s part %d  %-8s frame %s   %s   x %s"
                              % (fig["id"], n, part["panel"], got["frame"],
                                 got["why"], got["window"]))
            svg = compose_figure(fig, parts, widths)
            written.append(export_figure(out_dir, fig["id"], svg))
        browser.close()

    # === REPORT ===
    write_manifest(out_dir, viewer, report, written)
    for line in report:
        print(line)
    print("\nwrote %d figures to %s" % (len(written), out_dir))
    return written


# ===========================================================================
# BASE CONTROLLERS
# ===========================================================================

def find_viewer(root):
    """MODEL: the built viewer, if dist/ holds exactly one (TERMINAL).

    The viewer's file name is set by build.py, which this script does not
    read. One HTML file in dist/ is unambiguous; none or several stops the run
    and asks for --viewer rather than guessing.
    """
    found = sorted(glob.glob(os.path.join(root, "dist", "*.html")))
    if len(found) == 1:
        return found[0]
    if not found:
        sys.exit("no viewer in dist/. Run python3 build.py first.")
    sys.exit("several viewers in dist/, name one with --viewer:\n  %s"
             % "\n  ".join(os.path.relpath(p, root) for p in found))


def newer_sources(root, viewer):
    """MODEL: source files edited since the viewer was built (TERMINAL).

    The viewer inlines panels, frame tables, captions, scripts and styles at
    build time, so any of them being newer means the export would read a model
    that no longer exists. That failure otherwise surfaces as a predicate that
    matches nothing, with no hint that the cause is the build.
    """
    built = os.path.getmtime(viewer)
    src = os.path.join(root, "src")
    names = ["anim-data.js", "data.js", "animate.js", "controller.js",
             "controls.js", "cite.js", "style.css", "index.html", "refs.bib"]
    paths = [os.path.join(src, n) for n in names]
    paths += glob.glob(os.path.join(src, "panels", "*.svg"))
    return sorted(os.path.relpath(p, root) for p in paths
                  if os.path.isfile(p) and os.path.getmtime(p) > built)


def open_viewer(page, viewer):
    """SUB-CONTROLLER: load the viewer, confirm its API, install the helpers."""

    def load(page, viewer):
        """MODEL: open the page and wait for the controller to place the
        panels (TERMINAL).

        initWorkflow runs on DOMContentLoaded and appends the panels to #stage,
        so the load event alone can arrive before there is anything to find.
        """
        # as_uri gives file:///C:/... on Windows, where joining "file://" to a
        # path with a drive letter and backslashes does not make a valid URL.
        page.goto(pathlib.Path(viewer).resolve().as_uri())
        page.wait_for_load_state("load")
        try:
            page.wait_for_function(
                "() => document.querySelectorAll('#stage svg.panelsvg').length > 0",
                timeout=10000)
        except Exception:
            pass

    def missing(page):
        """MODEL: every part of the expected page API that is absent (TERMINAL)."""
        return [name for name, test in PAGE_CHECKS
                if not page.evaluate("() => { try { return %s; } "
                                     "catch (e) { return false; } }" % test)]

    def install(page):
        """MODEL: freeze motion and put the capture helpers on the page (TERMINAL)."""
        page.add_style_tag(content=FREEZE_CSS)
        page.evaluate("d => { window.__dropNone = d; }", DROPPABLE_NONE)
        page.evaluate(PAGE_API)

    load(page, viewer)
    gaps = missing(page)
    if gaps:
        sys.exit("%s does not provide: %s" % (os.path.basename(viewer),
                                              ", ".join(gaps)))
    install(page)


def resolve_frame(page, part):
    """SUB-CONTROLLER: turn a part's frame spec into a concrete index.

    Never returns an index the spec did not describe. A predicate that matches
    nothing is a spec that has fallen out of step with the model, and that has
    to stop the run rather than quietly export frame 0.
    """
    key = part["panel"]
    total = page.evaluate("k => F.frames(k)", key)
    spec = part.get("frame", "static")

    if total == 0:
        if spec != "static":
            sys.exit("%s has no frames but the spec asks for one" % key)
        return 0, "static panel"
    if spec == "static":
        return 0, "frame 0"
    if spec == "last":
        return total - 1, "last of %d" % total

    hits = find_matching_frames(page, key, total, spec["when"])
    if not hits:
        sys.exit("%s: no frame matches\n    %s\n"
                 "  The panel changed or the predicate did. Fix one of them."
                 % (key, spec["when"]))
    how = spec.get("pick", "first")
    return pick_from(hits, how), "%s of %d matching %s" % (how, len(hits), hits)


def capture_figure(page, fig):
    """SUB-CONTROLLER: capture every part of one figure, zoomed to its column.

    Two passes. The first captures each part at full width, which is only a
    measurement of where its molecules sit. The second captures it again inside
    the window its column shares, so the drop of everything outside and the
    height trim both happen at the zoom the figure prints at. Frames are
    resolved once and reused, since the predicates are the slow part.
    """
    parts = fig["parts"]
    frames = [resolve_frame(page, part) for part in parts]
    measured = [capture_frame(page, part, frame, n, None)
                for n, (part, (frame, _)) in enumerate(zip(parts, frames))]
    windows = column_windows([m["core"] for m in measured],
                             fig.get("cols", 1), fig.get("crop"))
    out = []
    for n, (part, (frame, why), win) in enumerate(zip(parts, frames, windows)):
        got = capture_frame(page, part, frame, n, win)
        got["why"], got["window"] = why, win
        out.append(got)
    return out


def capture_frame(page, part, frame, index, win):
    """SUB-CONTROLLER: seek one frame and return it with the cascade flattened.

    Ids are namespaced per part before anything is composed. fig-ddk shows
    step06 three times, and every firing panel carries fx-phos and the same
    marker ids, so without this a later definition would win for all of them.

    A part's solid selectors are raised to full opacity for the capture only
    and handed back to the stylesheet afterwards, so the next part to seek the
    same panel finds it as the engine left it.
    """
    key = part["panel"]
    solid = part.get("solid", [])

    # === CAPTURE ===
    page.evaluate("async ([k, n]) => { await F.seek(k, n); }", [key, frame])
    page.evaluate("([k, s]) => F.solid(k, s, true)", [key, solid])
    svg = page.evaluate(
        "([k, drop, props, trim, win]) => F.flatten(k, drop, props, trim, win)",
        [key, DROP_ALWAYS + part.get("drop", []), STYLE_PROPS,
         part.get("trim", True), list(win) if win else None])
    page.evaluate("([k, s]) => F.solid(k, s, false)", [key, solid])
    if not svg:
        sys.exit("%s: no panel in the page. Is it in KEYS?" % key)

    # === PACKAGE ===
    ink = read_span(svg, "data-ink")
    core = read_span(svg, "data-core")
    svg = re.sub(r'\s*data-(ink|core)="[^"]*"', "", svg, count=2)
    return {"svg": namespace_ids(svg, "f%d" % index), "frame": frame,
            "label": part.get("label"), "title": part.get("title"),
            "trim": part.get("trim", True), "ink": ink, "core": core,
            "panel": key}


def compose_figure(fig, parts, widths):
    """CONTROLLER: lay the captured parts out as one SVG and letter them.

    Parts keep their own viewBox and are placed by translation, so nothing is
    scaled and glyph sizes stay identical across every figure in the chapter.
    widths gives the printed width of every word in the part titles, and of a
    space, as the page measured them.
    """

    # === SUB-CONTROLLERS ===

    def lay_out(fig, parts, widths):
        """SUB-CONTROLLER: sizes, positions, title lines and title centres.

        A title wraps to the width of its column, so a long title takes a
        second line and the heading strip grows to hold it. Every part in a
        row takes the tallest strip in that row, so the parts in a row keep one
        top edge. The title centre is the drawing's centre, moved only as far
        as it takes to keep the title clear of the part letter on its left and
        of the next column on its right.
        """
        gap = 26 if fig.get("dividers") else 9
        lab_w, head_h = 34, 26
        cols = fig.get("cols", 1)
        boxes = [read_viewbox(p["svg"]) for p in parts]
        origins = [read_origin(p["svg"]) for p in parts]
        col_w = column_widths(boxes, cols)
        lines = [wrap_title(p.get("title"), widths, col_w[n % cols] + 2 * TITLE_CLEAR)
                 for n, p in enumerate(parts)]
        # A trimmed part has no empty band at its top, so a heading gets its
        # own strip above the part.
        heads = [(head_h + TITLE_LEAD * max(len(lines[n]) - 1, 0))
                 if (p["trim"] and (p.get("title") or p.get("label"))) else 0
                 for n, p in enumerate(parts)]
        heads = row_heads(heads, cols)
        grid = place_parts(boxes, heads, gap, lab_w, cols)
        centres = title_centres(parts, grid["spots"], origins)
        title_xs = [clamp_title(c, ln, widths, px, col_w[n % cols])
                    for n, (c, ln, (px, _)) in enumerate(zip(centres, lines, grid["spots"]))]
        return {"lab_w": lab_w, "boxes": boxes, "heads": heads, "lines": lines,
                "spots": grid["spots"], "rules": grid["rules"],
                "vrules": grid["vrules"], "title_xs": title_xs,
                "w": grid["w"], "h": grid["h"]}

    def assemble(fig, parts, lay):
        """SUB-CONTROLLER: render every piece into one svg."""
        body = ["<defs/>"]
        if fig.get("dividers"):
            body += [render_divider(ry, lay["w"]) for ry in lay["rules"]]
            body += [render_vdivider(rx, lay["h"]) for rx in lay["vrules"]]
        for n, part in enumerate(parts):
            (px, py), (w, h) = lay["spots"][n], lay["boxes"][n]
            hy = py - 9 if lay["heads"][n] else py + 75
            if part.get("label"):
                body.append(render_part_label(part["label"],
                                              px - lay["lab_w"] + 4, hy))
            if lay["lines"][n]:
                body.append(render_part_title(lay["lines"][n], lay["title_xs"][n], hy))
            body.append(render_clipped_part(part["svg"], "%s-%d" % (fig["id"], n),
                                            px, py, w, h))
        return render_figure_svg(lay["w"], lay["h"], body)

    # === COORDINATE SUB-CONTROLLERS ===

    layout = lay_out(fig, parts, widths)
    return assemble(fig, parts, layout)


def measure_title_words(page, fig):
    """MODEL: the printed width of every word in a figure's titles, and of a
    space, in the title face (TERMINAL).

    Measured in the page, which has the same fonts the export prints with, so
    a title is wrapped to its real width and not an estimate. Words are
    measured singly and joined with the measured space, which leaves out only
    the kerning across a space.
    """
    words = sorted(set(w for p in fig["parts"] for w in (p.get("title") or "").split()))
    if not words:
        return {}
    got = page.evaluate(
        """([words, font, size, weight]) => {
             const ns = 'http://www.w3.org/2000/svg';
             const svg = document.createElementNS(ns, 'svg');
             svg.setAttribute('style', 'position:absolute;left:-9999px;top:0');
             document.body.appendChild(svg);
             const t = document.createElementNS(ns, 'text');
             t.setAttribute('style', 'font-family:' + font + ';font-size:' + size +
                            'px;font-weight:' + weight + ';white-space:pre');
             svg.appendChild(t);
             const out = {};
             for (const w of words.concat(['a a', 'aa'])) {
               t.textContent = w;
               out[w] = t.getComputedTextLength();
             }
             svg.remove();
             return out;
           }""", [words, TITLE_FONT, TITLE_SIZE, TITLE_WEIGHT])
    got[" "] = got.pop("a a") - got.pop("aa")
    return got


def export_figure(out_dir, fig_id, svg):
    """VIEW: write the figure, and a PDF beside it when a converter exists."""
    path = os.path.join(out_dir, fig_id + ".svg")
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(svg)
    try:
        import cairosvg
        cairosvg.svg2pdf(bytestring=svg.encode("utf-8"),
                         write_to=os.path.join(out_dir, fig_id + ".pdf"))
    except Exception:
        # The SVG is the deliverable and carries no stylesheet, so any
        # converter handles it. A missing cairosvg is not a failed export.
        pass
    return path


# ===========================================================================
# SHARED FUNCTIONS
# ===========================================================================

def find_matching_frames(page, key, total, when):
    """MODEL: every frame index whose state satisfies the predicate (TERMINAL)."""
    return page.evaluate(
        """async ([k, total, when]) => {
             const F = window.F, hits = [];
             for (let i = 0; i < total; i++) {
               await F.seek(k, i);
               if (eval(when)) { hits.push(i); }
             }
             return hits;
           }""", [key, total, when])


def pick_from(hits, how):
    """MODEL: choose one index from the matching set (TERMINAL)."""
    if how == "first":
        return hits[0]
    if how == "last":
        return hits[-1]
    return hits[len(hits) // 2]


def place_parts(boxes, heads, gap, lab_w, cols):
    """MODEL: where each part goes in a grid of cols columns, filled row by
    row, and where the rules between rows and columns fall (TERMINAL).

    Every column is as wide as its widest part and every row as tall as its
    tallest part plus its heading strip, so parts in one column share a left
    edge and parts in one row share a heading line.
    """
    n = len(boxes)
    rows = (n + cols - 1) // cols
    col_w = [max([boxes[i][0] for i in range(c, n, cols)] or [0])
             for c in range(cols)]
    row_h = [max(heads[i] + boxes[i][1]
                 for i in range(r * cols, min(n, (r + 1) * cols)))
             for r in range(rows)]
    col_x, x = [], 0
    for c in range(cols):
        col_x.append(x + lab_w)
        x += lab_w + col_w[c] + gap
    row_y, y = [], 0
    for r in range(rows):
        row_y.append(y)
        y += row_h[r] + gap
    spots = [(col_x[i % cols], row_y[i // cols] + heads[i]) for i in range(n)]
    return {"spots": spots,
            "rules": [row_y[r] - gap / 2.0 for r in range(1, rows)],
            "vrules": [col_x[c] - lab_w - gap / 2.0 for c in range(1, cols)],
            "w": x - gap, "h": y - gap}


def column_widths(boxes, cols):
    """MODEL: the width of each column, its widest part (TERMINAL)."""
    n = len(boxes)
    return [max([boxes[i][0] for i in range(c, n, cols)] or [0]) for c in range(cols)]


def wrap_title(title, widths, max_w):
    """MODEL: a title broken into lines that fit max_w, at word boundaries
    (TERMINAL).

    A single word wider than max_w keeps a line of its own, since breaking a
    word would print something the title does not say.
    """
    if not title:
        return []
    lines, cur, cur_w = [], [], 0.0
    for word in title.split():
        w = widths.get(word, 0.0)
        trial = cur_w + (widths.get(" ", 0.0) if cur else 0.0) + w
        if cur and trial > max_w:
            lines.append(" ".join(cur))
            cur, cur_w = [word], w
        else:
            cur, cur_w = cur + [word], trial
    lines.append(" ".join(cur))
    return lines


def row_heads(heads, cols):
    """MODEL: every part's heading strip raised to the tallest in its row
    (TERMINAL)."""
    out = list(heads)
    for r in range(0, len(heads), cols):
        tall = max(heads[r:r + cols])
        for i in range(r, min(r + cols, len(heads))):
            out[i] = tall if heads[i] else 0
    return out


def clamp_title(centre, lines, widths, px, col_w):
    """MODEL: the title centre, moved to keep the widest line inside its
    column (TERMINAL).

    The left limit is the right end of the part letter, which sits in the
    strip left of px; the right limit is the column's right edge. A line wider
    than both allow is centred on the column.
    """
    if centre is None or not lines:
        return centre
    w = max(sum(widths.get(x, 0.0) for x in ln.split())
            + widths.get(" ", 0.0) * (len(ln.split()) - 1) for ln in lines)
    lo, hi = px - TITLE_CLEAR, px + col_w + TITLE_CLEAR
    if w >= hi - lo:
        return (lo + hi) / 2.0
    return min(max(centre, lo + w / 2.0), hi - w / 2.0)


def title_centres(parts, spots, origins):
    """MODEL: one title centre per column, taken from the drawings (TERMINAL).

    Centred on the molecules and not on the part box, and shared by every part
    in a column, because headings that nearly line up read as a mistake.
    """
    by_col = {}
    for p, (px, _), (ox, _) in zip(parts, spots, origins):
        span = p["core"] or p["ink"]
        if p.get("title") and span:
            by_col.setdefault(px, []).append(px - ox + sum(span) / 2.0)
    return [(sum(by_col[px]) / len(by_col[px])) if px in by_col else None
            for (px, _) in spots]


def namespace_ids(svg, prefix):
    """MODEL: make every id in one part unique to that part (TERMINAL)."""
    ids = set(re.findall(r'id="([^"]+)"', svg))
    for ident in sorted(ids, key=len, reverse=True):
        new = "%s-%s" % (prefix, ident)
        svg = svg.replace('id="%s"' % ident, 'id="%s"' % new)
        svg = svg.replace("url(#%s)" % ident, "url(#%s)" % new)
        svg = svg.replace('href="#%s"' % ident, 'href="#%s"' % new)
    return svg


def read_viewbox(svg):
    """MODEL: the part's drawn size, from its own viewBox (TERMINAL)."""
    m = re.search(r'viewBox="([\d.\-]+) ([\d.\-]+) ([\d.]+) ([\d.]+)"', svg)
    return (int(float(m.group(3))), int(float(m.group(4)))) if m else (880, 300)


def read_span(svg, attr):
    """MODEL: one horizontal extent the browser measured, as (x0, x1)
    (TERMINAL)."""
    m = re.search(r'%s="([\d.\-]+) ([\d.\-]+)"' % attr, svg)
    return (float(m.group(1)), float(m.group(2))) if m else None


def column_windows(cores, cols, pad):
    """MODEL: the x window each part is captured in (TERMINAL).

    One window per column: the union of that column's molecules, widened by
    pad and held inside the panel. Sharing it down a column keeps the pair at
    the same x from row to row, so a reader comparing panels vertically sees
    what changed and nothing else. Not sharing it across columns keeps one
    wide part from widening every part in the figure. pad None means no zoom.
    """
    if pad is None:
        return [None] * len(cores)
    wins = []
    for c in range(cols):
        spans = [cores[i] for i in range(c, len(cores), cols) if cores[i]]
        if not spans:
            wins.append(None)
            continue
        wins.append((int(max(0.0, min(s[0] for s in spans) - pad)),
                     int(round(min(880.0, max(s[1] for s in spans) + pad)))))
    return [wins[i % cols] for i in range(len(cores))]


def read_origin(svg):
    """MODEL: the part's viewBox origin, which trimming moves off zero (TERMINAL)."""
    m = re.search(r'viewBox="([\d.\-]+) ([\d.\-]+)', svg)
    return (float(m.group(1)), float(m.group(2))) if m else (0.0, 0.0)


def render_clipped_part(svg, clip_id, px, py, w, h):
    """VIEW: one part, translated into place and clipped to its box (TERMINAL).

    Dropping what lies outside the box handles whole elements. A shape
    straddling the edge is still half out, and Inkscape would export the half.
    The clip makes the edge hard whatever the converter does.
    """
    m = re.search(r'viewBox="([\d.\-]+) ([\d.\-]+)', svg)
    ox, oy = (float(m.group(1)), float(m.group(2))) if m else (0.0, 0.0)
    inner = re.sub(r"</svg>\s*$", "", re.sub(r"^\s*<svg[^>]*>", "", svg))
    return ('<clipPath id="clip-%s"><rect x="%d" y="%d" width="%d" height="%d"/>'
            '</clipPath><g clip-path="url(#clip-%s)" transform="translate(%d,%d)">'
            '%s</g>' % (clip_id, ox, oy, w, h, clip_id, px - ox, py - oy, inner))


def render_figure_svg(width, height, body):
    """VIEW: the outer svg element around the assembled parts (TERMINAL)."""
    return ('<svg xmlns="http://www.w3.org/2000/svg" '
            'xmlns:xlink="http://www.w3.org/1999/xlink" '
            'viewBox="0 0 %d %d" width="%d" height="%d">\n%s\n</svg>'
            % (width, height, width, height, "\n".join(body)))


def render_vdivider(x, height):
    """VIEW: a dotted rule between two columns of parts (TERMINAL)."""
    return ('<line x1="%d" y1="0" x2="%d" y2="%d" style="stroke:#bfbfbf;'
            "stroke-width:1;stroke-dasharray:2 5;stroke-linecap:round\"/>"
            % (x, x, height))


def render_part_label(text, x, y):
    """VIEW: the (A), (B) letter beside a part (TERMINAL)."""
    return ('<text x="%d" y="%d" style="font-family:\'Times New Roman\',Times,'
            'serif;font-size:15px;font-weight:700;fill:#111">%s</text>'
            % (x, y, text))


def render_part_title(lines, x, y):
    """VIEW: a part's title, centred over its drawing, one text per line with
    the last line on the heading baseline (TERMINAL)."""
    top = y - TITLE_LEAD * (len(lines) - 1)
    return "".join('<text x="%d" y="%d" style="font-family:%s;font-size:%dpx;'
                   'font-weight:%d;fill:#111;text-anchor:middle">%s</text>'
                   % (x, top + k * TITLE_LEAD, TITLE_FONT, TITLE_SIZE, TITLE_WEIGHT,
                      line.replace("&", "&amp;").replace("<", "&lt;"))
                   for k, line in enumerate(lines))


def render_divider(y, width):
    """VIEW: a dotted rule between two parts (TERMINAL)."""
    return ('<line x1="0" y1="%d" x2="%d" y2="%d" style="stroke:#bfbfbf;'
            "stroke-width:1;stroke-dasharray:2 5;stroke-linecap:round\"/>"
            % (y, width, y))


def write_manifest(out_dir, viewer, report, written):
    """VIEW: record what each part resolved to, beside the figures (TERMINAL)."""
    lines = ["Frames chosen by tools/make_figures.py from %s."
             % os.path.basename(viewer),
             "Predicates, not indices: check these against the spec whenever a",
             "frame table changes.", ""]
    lines += report
    lines += ["", "files:"] + ["  " + os.path.basename(p) for p in written]
    with open(os.path.join(out_dir, "manifest.txt"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines) + "\n")


def parse_args(argv):
    """MODEL: figure ids and an optional --viewer path from the command line
    (TERMINAL)."""
    viewer, only, rest = None, [], list(argv)
    while rest:
        arg = rest.pop(0)
        if arg == "--viewer":
            if not rest:
                sys.exit("--viewer needs a path")
            viewer = os.path.abspath(rest.pop(0))
        else:
            only.append(arg)
    return viewer, (set(only) or None)


def _project_root():
    """MODEL: the folder holding build.py, from this file's location (TERMINAL)."""
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


if __name__ == "__main__":
    VIEWER_ARG, ONLY = parse_args(sys.argv[1:])
    build_figures(only=ONLY, viewer=VIEWER_ARG)