// Solve RULE.capK, the cap-loss constant, so that the median cdc13-2 lineage
// first loses a cap at 37 divisions, the median division of death of
// telomerase-negative lineages in Xu et al. 2015 (37 +/- 12). Prints capK and
// what the lineages then show: the spread of that division and the length at
// which ends lose their caps, which the rule does not set.
//
//   node tools/tune_capping.js
global.window = {};
const R = require('../src/chrom-rule.js');
const N = 400, TARGET = 37;

function median(xs) { const s = xs.slice().sort((a, b) => a - b); return s[Math.floor(s.length / 2)]; }
function at(k) { return R.lineageStats({ cdc13_2: true }, N, k).map(x => (x.at === null ? Infinity : x.at)); }

let lo = Math.log(10), hi = Math.log(5000);
for (let i = 0; i < 18; i += 1) {
  const mid = (lo + hi) / 2, m = median(at(Math.exp(mid)));
  if (m > TARGET) { lo = mid; } else { hi = mid; }
}
const k = Math.round(Math.exp((lo + hi) / 2));
const st = R.lineageStats({ cdc13_2: true }, N, k);
const div = st.map(x => x.at).filter(x => x !== null), bp = st.map(x => x.bp).filter(x => x !== null);
const mean = div.reduce((a, b) => a + b, 0) / div.length;
const sd = Math.sqrt(div.reduce((a, b) => a + (b - mean) * (b - mean), 0) / div.length);
const q = (xs, f) => xs.slice().sort((a, b) => a - b)[Math.floor(f * xs.length)];
console.log('capK', k);
console.log('first cap loss, division: median', median(div), 'mean', mean.toFixed(1), 'sd', sd.toFixed(1));
console.log('length at cap loss, bp: median', median(bp), '10%', q(bp, 0.1), '90%', q(bp, 0.9));
