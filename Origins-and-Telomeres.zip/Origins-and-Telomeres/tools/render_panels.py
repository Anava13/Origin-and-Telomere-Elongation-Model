#!/usr/bin/env python3
"""Rasterise src/panels/*.svg to render/*.png for offline checking.

Limits worth knowing. This resolves plain and compound class selectors from
section 3 of the stylesheet, not descendant selectors. Most of the new glyph
vocabulary is styled through descendant rules such as ".mcmsub.m4 .mcmbody",
so subunit fills and several other colours are absent from these images. It
also paints the markup state only, so panels are shown at frame 0 with no
derived layer: zone tints, derived glyph positions, the kink rotation and the
status words all come from the engine and are not in these images.

These are a rough offline check and not a preview of the figure. For that,
open dist/origins-and-telomeres.html in a browser.
"""

import os
import re
import subprocess
import sys


def inline_style(svg, css):
    rules = {}
    for sel, body in re.findall(r'([^{}]+)\{([^}]*)\}', css):
        sel = sel.strip()
        if not sel or sel.startswith('@') or ' ' in sel or ':' in sel:
            continue
        rules.setdefault(sel, '')
        rules[sel] += body.strip()
    style = '\n'.join('%s{%s}' % (k, v) for k, v in rules.items())
    return svg.replace('<defs>', '<style>%s</style><defs>' % style, 1)


def main():
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    src = os.path.join(root, 'src')
    out = os.path.join(root, 'render')
    os.makedirs(out, exist_ok=True)
    with open(os.path.join(src, 'style.css')) as f:
        css = f.read()
    tool = None
    for candidate in ('rsvg-convert', 'inkscape', 'cairosvg'):
        if subprocess.call(['which', candidate], stdout=subprocess.DEVNULL,
                           stderr=subprocess.DEVNULL) == 0:
            tool = candidate
            break
    for name in sorted(os.listdir(os.path.join(src, 'panels'))):
        if not name.endswith('.svg'):
            continue
        with open(os.path.join(src, 'panels', name)) as f:
            svg = inline_style(f.read(), css)
        staged = os.path.join(out, name)
        with open(staged, 'w') as f:
            f.write(svg)
        png = staged[:-4] + '.png'
        if tool == 'rsvg-convert':
            subprocess.call(['rsvg-convert', '-w', '1400', staged, '-o', png])
        elif tool == 'inkscape':
            subprocess.call(['inkscape', staged, '--export-filename=' + png, '-w', '1400'])
        elif tool == 'cairosvg':
            subprocess.call(['cairosvg', staged, '-o', png, '-W', '1400'])
    if not tool:
        print('no rasteriser found. Wrote style-inlined SVGs to render/ instead.',
              file=sys.stderr)
    print('render/ updated')


if __name__ == '__main__':
    main()
