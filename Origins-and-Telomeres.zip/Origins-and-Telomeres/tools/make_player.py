"""Build the presentation player from the built viewer.

    python3 build.py && python3 tools/make_player.py
    python3 tools/make_player.py --viewer dist/other.html --out player/index.html

Writes one self-contained HTML file: the main-line panels, their frame tables,
the viewer's stylesheet and the viewer's animation engine, inside the shell in
tools/player-shell.html. The file needs no server and no network, so it can be
opened from disk or served from GitHub Pages and framed on a slide.

Why the live engine and not exported frames. make_figures.py flattens frames
because print needs a file with no stylesheet and no script. A player has no
such limit. Running the engine keeps the stylesheet's transitions, so a move
between frames of one panel is animated, and it means the player shows exactly
what the viewer shows.

What this reads from the viewer. Four things, each found by a marker and each
checked, so a change to the build that moves one stops this script with the
missing piece named:
    the first <style> block                     the whole stylesheet
    var INLINE_PANELS = {...};                  panel markup, JSON
    var ANIM = {...};                           frame tables, JSON
    the <script> holding function runAnimation  the engine, verbatim
Step titles come from META and the step order from ORDER.

Panels are cropped to CAMERA, one window for every step, so the substrate
never moves at a step boundary. The furniture make_figures.py drops for print
is hidden here with CSS and left in the markup, because the engine still
writes to it on every frame.
"""

import glob
import json
import os
import re
import sys

OUT_NAME = "replication-initiation-player.html"
SHELL_NAME = "player-shell.html"

# The panels the timeline runs through. None takes ORDER from the viewer, the
# eleven steps of the main line. A URL option narrows this per slide, so the
# file only needs to carry the widest range any slide uses.
STEPS = None

# Steps left out of the player. Step 2 seats Cdc6 in the ORC notch, which the
# viewer shows on its own panel; on a slide, step 3 opens with Cdc6 already
# seated and the crossfade from step 1 brings it in.
SKIP = ["step02"]

# Frames left out of a kept step, numbered from 1 as the viewer's frame
# counter shows them. The player plays the rest in order.
SKIP_FRAMES = {"step01": [5, 6, 7]}

# The player numbers the kept steps 1, 2, 3 in timeline order, so a skipped
# step leaves no gap. ?from=, ?to= and ?start= take these numbers.

# x, y, width, height in panel units. Every main-line panel is 880 by 300. The
# molecules on every frame of step01 to step11, with the furniture below
# hidden, fall between y 4 and y 261; the Cdt1 arc in step09 reaches higher
# and is clipped by the viewer as well.
CAMERA = (0, 0, 880, 268)

# Hidden on every panel. The same list as DROP_ALWAYS in make_figures.py: the
# status bar, the note under the panel, the pointer labels, the fit points and
# the complex-state track. Delete an entry to bring it back on the slides.
DROP = [".capbar", ".notelab", ".polelab", ".fitpt", ".cpxlayer"]


# ===========================================================================
# MAIN CONTROLLER
# ===========================================================================

def build_player(root=None, viewer=None, out=None):
    """CONTROLLER: read the viewer, select the steps, write the player."""
    root = root or _project_root()
    viewer = viewer or find_viewer(root)
    out = out or os.path.join(root, "dist", OUT_NAME)

    # === CHECK INPUTS ===
    stale = newer_sources(root, viewer)
    if stale:
        sys.exit("%s is older than %d source file(s), including %s.\n"
                 "Rebuild first: python3 build.py"
                 % (os.path.relpath(viewer, root), len(stale), ", ".join(stale[:3])))

    # === COORDINATE SUB-CONTROLLERS ===
    html = read_text(viewer)
    parts = extract_viewer_parts(html)
    steps = select_steps(parts)
    page = assemble_player(parts, steps, read_text(os.path.join(root, "tools", SHELL_NAME)))
    write_text(out, page)

    print("wrote %s: %d steps, %d frames, %d KB"
          % (os.path.relpath(out, root), len(steps),
             sum(max(1, len(s["frames"])) for s in steps), len(page.encode("utf-8")) // 1024))
    return out


# ===========================================================================
# BASE CONTROLLERS
# ===========================================================================

def extract_viewer_parts(html):
    """CONTROLLER: every piece of the viewer the player reuses."""

    def first_style(html):
        """MODEL: the viewer's stylesheet (TERMINAL)."""
        m = re.search(r"<style>(.*?)</style>", html, re.S)
        return m.group(1) if m else None

    def json_after(html, marker):
        """MODEL: the JSON value that follows a var declaration (TERMINAL)."""
        at = html.find(marker)
        if at < 0:
            return None
        at = html.index("{", at)
        value, _ = json.JSONDecoder().raw_decode(html, at)
        return value

    def engine_script(html):
        """MODEL: the script block that defines runAnimation, verbatim (TERMINAL)."""
        for body in re.findall(r"<script>(.*?)</script>", html, re.S):
            if "function runAnimation" in body and "function paintDerived" in body:
                return body
        return None

    def step_order(html):
        """MODEL: ORDER, the main line as the viewer walks it (TERMINAL)."""
        m = re.search(r"var ORDER = \[(.*?)\];", html, re.S)
        return re.findall(r"'([^']+)'", m.group(1)) if m else None

    def titles(html):
        """MODEL: each META entry's title (TERMINAL).

        META is JavaScript, not JSON, so the titles are read by pattern. Every
        entry opens with its key and then its title on the next line.
        """
        return dict(re.findall(r"\n  (\w+): \{\s*\n\s*title: '((?:[^'\\]|\\.)*)'", html))

    parts = {"style": first_style(html),
             "panels": json_after(html, "var INLINE_PANELS ="),
             "anim": json_after(html, "var ANIM ="),
             "engine": engine_script(html),
             "order": step_order(html),
             "titles": titles(html)}
    missing = [name for name, value in parts.items() if not value]
    if missing:
        sys.exit("the viewer does not provide: %s" % ", ".join(missing))
    return parts


def select_steps(parts):
    """MODEL: one record per step on the timeline, in order (TERMINAL).

    Stops on the first key the viewer cannot supply in full, since a step with
    no panel or no title would put a gap in the timeline that nobody sees
    until a slide is shown.
    """
    keys = [k for k in (STEPS or parts["order"]) if k not in SKIP]
    out, gaps = [], []
    for key in keys:
        if key not in parts["panels"] or key not in parts["titles"]:
            gaps.append(key)
            continue
        table = parts["anim"].get(key)
        total = len(table["frames"]) if table else 0
        drop = set(SKIP_FRAMES.get(key, []))
        bad = sorted(n for n in drop if not 1 <= n <= total)
        if bad:
            sys.exit("%s has %d frames; SKIP_FRAMES names %s" % (key, total, bad))
        kept = [i for i in range(total) if i + 1 not in drop]
        if total and not kept:
            sys.exit("SKIP_FRAMES leaves %s with no frames" % key)
        out.append({"key": key,
                    "num": len(out) + 1,
                    "title": parts["titles"][key].replace("\\'", "'"),
                    "frames": kept,
                    "fps": table.get("fps", 1.2) if table else 1.2})
    if gaps:
        sys.exit("no panel or no title in the viewer for: %s" % ", ".join(gaps))
    return out


def assemble_player(parts, steps, shell):
    """CONTROLLER: fill the shell with the selected panels and tables."""

    def crop_panel(svg):
        """MODEL: the panel with its outer viewBox set to CAMERA (TERMINAL)."""
        return re.sub(r'viewBox="[^"]*"', 'viewBox="%g %g %g %g"' % CAMERA, svg, count=1)

    def drop_css():
        """MODEL: one rule hiding every DROP selector inside the stage (TERMINAL)."""
        if not DROP:
            return ""
        return ("%s { display: none !important; }"
                % ", ".join("#stage " + sel for sel in DROP))

    def fill(shell, slots):
        """VIEW: substitute every slot, and stop on one the shell lacks (TERMINAL)."""
        for name, value in slots.items():
            token = "%%" + name + "%%"
            if token not in shell:
                sys.exit("%s has no %s slot" % (SHELL_NAME, token))
            shell = shell.replace(token, value)
        return shell

    keys = [s["key"] for s in steps]
    panels = "\n".join(crop_panel(parts["panels"][k]) for k in keys)
    anim = {k: parts["anim"][k] for k in keys if k in parts["anim"]}
    # A literal </script> inside the JSON would end the block early.
    as_js = lambda v: json.dumps(v, separators=(",", ":")).replace("</", "<\\/")
    return fill(shell, {"VIEWER_STYLE": parts["style"],
                        "DROP_CSS": drop_css(),
                        "PANELS": panels,
                        "ANIM": as_js(anim),
                        "STEPS": as_js(steps),
                        "ENGINE": parts["engine"]})


# ===========================================================================
# SHARED FUNCTIONS
# ===========================================================================

def find_viewer(root):
    """MODEL: the built viewer, if dist/ holds exactly one besides the player
    (TERMINAL)."""
    found = sorted(p for p in glob.glob(os.path.join(root, "dist", "*.html"))
                   if os.path.basename(p) != OUT_NAME)
    if len(found) == 1:
        return found[0]
    if not found:
        sys.exit("no viewer in dist/. Run python3 build.py first.")
    sys.exit("several viewers in dist/, name one with --viewer:\n  %s"
             % "\n  ".join(os.path.relpath(p, root) for p in found))


def newer_sources(root, viewer):
    """MODEL: source files edited since the viewer was built (TERMINAL)."""
    built = os.path.getmtime(viewer)
    src = os.path.join(root, "src")
    names = ["anim-data.js", "data.js", "animate.js", "style.css"]
    paths = [os.path.join(src, n) for n in names]
    paths += glob.glob(os.path.join(src, "panels", "*.svg"))
    return sorted(os.path.relpath(p, root) for p in paths
                  if os.path.isfile(p) and os.path.getmtime(p) > built)


def read_text(path):
    """MODEL: a file's text (TERMINAL)."""
    with open(path, encoding="utf-8") as fh:
        return fh.read()


def write_text(path, text):
    """VIEW: write a file, making its folder if needed (TERMINAL)."""
    folder = os.path.dirname(path)
    if folder and not os.path.isdir(folder):
        os.makedirs(folder)
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(text)


def parse_args(argv):
    """MODEL: --viewer and --out from the command line (TERMINAL)."""
    got, rest = {"viewer": None, "out": None}, list(argv)
    while rest:
        arg = rest.pop(0)
        if arg in ("--viewer", "--out") and rest:
            got[arg[2:]] = os.path.abspath(rest.pop(0))
        else:
            sys.exit("usage: make_player.py [--viewer PATH] [--out PATH]")
    return got


def _project_root():
    """MODEL: the folder holding build.py, from this file's location (TERMINAL)."""
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


if __name__ == "__main__":
    ARGS = parse_args(sys.argv[1:])
    build_player(viewer=ARGS["viewer"], out=ARGS["out"])
