"""Build the guided lesson from the built viewer.

    python3 build.py && python3 tools/make_tour.py
    python3 tools/make_tour.py --lesson tools/tour/lesson-hu.js --out dist/other-tour.html

Writes one self-contained HTML file: the whole viewer, unchanged, with the
tour layer added. The tour layer is five files in tools/tour:

    tour.css         the layout of the lesson: picture cells and the card
    tour.js          the runtime: beats, anchors, zoom, spotlight, predictions,
                     which chromosome features each beat shows
    lesson-hu.js     the lesson itself (TOUR_LESSON), data only
    figures.py       the model-key figures, drawn with make_panels.py's glyphs
    spindles.py      measured spindle extension, classed short or extended
                     within each experiment for the readout chapter
    mol3d.js         the WebGL drawing of the cryo-EM structures, which
                     tools/structures/structures-lesson.json supplies

Why the whole viewer and not extracted pieces. make_player.py extracts the
main-line panels for one linear process at one scale. A lesson moves between
the chromosome and its close-up, installs live runs of the rule, and draws a
second cell for comparison, so it needs the rule, the frame builder, the
close-up and the engine together; carrying the viewer whole keeps every
picture exactly what the viewer draws. The tour drives the viewer through
the functions it already exposes (selectStep, runAnimation, runChromLive,
applyFrame, buildChromFrames, CHROM_RULE) and hides the viewer's own chrome.

What this checks. The markers it inserts at must be present once each, and
every function the tour calls must be defined in the viewer, so a change to
the viewer that removes one stops this script with the missing piece named.
"""

import json
import os
import re
import subprocess
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'tour'))
import figures  # noqa: E402
import spindles  # noqa: E402
import grn  # noqa: E402

# Each Rad53 network panel and the measured strains whose class its end must match.
GRN_CHECK = {'wt': [('j4a-wt', 'all')], 'rad53': [('j4a-rad53', 'all')], 'r53zn': [('j4a-zn', 'all')],
             'r53mcm': [('j4a-mcm2', 'all')], 'sites': [('j5a-sites', 'all')], 'r53ctf19': [('j6d-rad53ctf19', 'all')],
             'r53exo1': [('j8e-rad53exo1', 'small'), ('j8e-rad53exo1', 'large')],
             'r53ako': [('j9b-rad53ako', 'small'), ('j9b-rad53ako', 'large')]}

ENCODING = 'utf-8'
OUT_NAME = 'origins-and-telomeres-tour.html'
NEEDS = ['function selectStep', 'function runAnimation', 'function runChromLive', 'function applyFrame',
         'function buildChromFrames', 'var CHROM_RULE', 'function medianRun', 'function findId',
         "command === 'cruise'", 'data-feat=']


def main():
    """BASE CONTROLLER: read the viewer and the tour files, check, inject, write."""

    def parse_args(argv):
        # MODEL: the viewer, lesson and output paths, defaults beside this script (TERMINAL)
        root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        args = {'viewer': os.path.join(root, 'dist', 'origins-and-telomeres.html'),
                'lesson': os.path.join(root, 'tools', 'tour', 'lesson-hu.js'),
                'out': os.path.join(root, 'dist', OUT_NAME),
                'tour': os.path.join(root, 'tools', 'tour')}
        for flag in ('viewer', 'lesson', 'out'):
            if '--' + flag in argv:
                args[flag] = argv[argv.index('--' + flag) + 1]
        return args

    def read_inputs(args):
        # MODEL: the viewer and the three tour files as text (TERMINAL)
        def read(path):
            with open(path, encoding=ENCODING) as f:
                return f.read()
        return {'root': os.path.dirname(os.path.dirname(os.path.abspath(args['tour']))),
                'viewer': read(args['viewer']), 'css': read(os.path.join(args['tour'], 'tour.css')),
                'js': read(os.path.join(args['tour'], 'tour.js')), 'lesson': read(args['lesson']),
                'mol3d': read(os.path.join(args['tour'], 'mol3d.js')),
                'pages': read(os.path.join(args['tour'], 'pages.js')),
                # Slide previews for the slide list, from tools/make_thumbs.js; none until it has run.
                'thumbs': (read(os.path.join(args['tour'], 'thumbs.json')).strip()
                           if os.path.exists(os.path.join(args['tour'], 'thumbs.json')) else 'null'),
                'structures': read(os.path.join(os.path.dirname(args['tour']), 'structures', 'structures-lesson.json'))}

    def typical_runs(root):
        # MODEL: every slide strain's typical run and its share of extended spindles over 301 runs (TERMINAL)
        # Computed once here with the rule itself, so the lesson opens without
        # running 3,600 cells and its bar charts carry the rule's own shares.
        script = ("var R=require(process.argv[1]);var o={};R.PRESETS.forEach(function(p){"
                  "var m=R.medianRun(p,301);o[p.key]={seed:m.seed,share:m.share,n:m.n,paper:p.paper,label:p.label,"
                  "checkpoint:p.checkpoint,alleles:p.alleles,ak:p.ak,when:p.when,outcome:m.outcome};});"
                  "process.stdout.write(JSON.stringify(o));")
        out = subprocess.run(['node', '-e', script, os.path.join(root, 'src', 'chrom-rule.js')],
                             capture_output=True, text=True, check=True)
        return json.loads(out.stdout)

    def check_viewer(html):
        # MODEL: every marker and function the tour relies on, present (TERMINAL)
        missing = [n for n in NEEDS if n not in html]
        for marker in ('</head>', '</body>'):
            if html.count(marker) != 1:
                missing.append('exactly one ' + marker)
        if missing:
            sys.exit('make_tour: the viewer lacks ' + ', '.join(missing))

    def check_spindles(presets):
        # MODEL: every measured strain classed within its own experiment, and the model agreeing with each (TERMINAL)
        # The readout chapter draws strains as short or extended. A strain
        # without both references, or one the model puts in the other class,
        # stops the build with the strain named.
        got, problems = spindles.classify()
        problems += spindles.check_model(got, presets)
        # A network panel ends where its strains were measured: short, extended,
        # or short in small buds and extended in large ones.
        for key, refs in GRN_CHECK.items():
            end = grn.states(grn.GENOTYPES[key])['end']
            want = [got[sid]['cls'][r] for sid, r in refs]
            ok = {'short': ['short'], 'extended': ['extended'], 'delayed': ['short', 'extended']}[end]
            if want != ok:
                problems.append('Rad53 network %s ends %s but the strains measured %s' % (key, end, want))
        if problems:
            sys.exit('make_tour: spindle classes: ' + '; '.join(problems))
        return got

    def inject(parts):
        # MODEL: the viewer with the tour's style in the head and its scripts at the end of the body (TERMINAL)
        html = parts['viewer']
        html = re.sub(r'<title>[^<]*</title>', '<title>HU Checkpoint Lesson</title>', html, count=1)
        html = html.replace('</head>', '<style>\n' + parts['css'] + '\n</style>\n</head>')
        presets = typical_runs(parts['root'])
        spindle = check_spindles(presets)
        figs = ('window.TOUR_FIGURES = ' + json.dumps(figures.build_figures(presets, spindle)) + ';\n'
                'window.TOUR_PRESETS = ' + json.dumps(presets) + ';\n'
                'window.TOUR_STRUCTURES = ' + parts['structures'].strip() + ';\n'
                'window.TOUR_THUMBS = ' + parts['thumbs'] + ';')
        script = ('<script>\n' + figs.replace('</', '<\\/') + '\n</script>\n'
                  '<script>\n' + parts['mol3d'].replace('</script', '<\\/script') + '\n</script>\n'
                  '<script>\n' + parts['pages'].replace('</script', '<\\/script') + '\n</script>\n'
                  '<script>\n' + parts['lesson'].replace('</script', '<\\/script') + '\n</script>\n'
                  '<script>\n' + parts['js'].replace('</script', '<\\/script') + '\n</script>\n')
        return html.replace('</body>', script + '</body>')

    def write_out(path, html):
        # VIEW: the lesson file (TERMINAL)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, 'w', encoding=ENCODING) as f:
            f.write(html)
        print('wrote %s' % path)

    args = parse_args(sys.argv[1:])
    parts = read_inputs(args)
    check_viewer(parts['viewer'])
    write_out(args['out'], inject(parts))


if __name__ == '__main__':
    main()
