/* Behavioural tests. Runs against dist/ in jsdom and drives the real engine
   rather than reimplementing it, so a test that passes is a statement about
   the artifact that ships. */

const fs = require('fs');
const path = require('path');
const { JSDOM } = require('jsdom');

const ROOT = path.dirname(__dirname);
const DIST = path.join(ROOT, 'dist', 'origins-and-telomeres.html');

const html = fs.readFileSync(DIST, 'utf8');
const dom = new JSDOM(html, { runScripts: 'dangerously', pretendToBeVisual: true });
const win = dom.window;
const doc = win.document;

let passed = 0;
const failures = [];

function ok(name, condition, detail) {
  if (condition) { passed += 1; } else { failures.push(name + (detail ? ' :: ' + detail : '')); }
}

function transX(el) {
  const t = el && el.getAttribute && el.getAttribute('transform');
  if (!t) { return 0; }
  const m = /translate\(\s*(-?[\d.]+)/.exec(t);
  return m ? parseFloat(m[1]) : 0;
}

function absPt(el) {
  // Accumulate the ancestor translates of a fit point. Only translate is ever
  // written by the engine or by a frame, so a full matrix walk is not needed.
  let x = parseFloat(el.getAttribute('cx'));
  let y = parseFloat(el.getAttribute('cy'));
  let n = el.parentNode;
  while (n && n.getAttribute) {
    const t = n.getAttribute('transform');
    if (t) {
      const m = /translate\(\s*(-?[\d.]+)[\s,]*(-?[\d.]+)?/.exec(t);
      if (m) {
        x += parseFloat(m[1]);
        y += parseFloat(m[2] || '0');
      }
    }
    n = n.parentNode;
  }
  return [x, y];
}

function panel(key) {
  return doc.querySelector('#stage svg.panelsvg[data-key="' + key + '"]');
}

function frames(key) { return (win.ANIM[key] || { frames: [] }).frames; }

function walk(key, fn) {
  // The walks check step-panel invariants (positions, kinks, gates, ORC). The
  // live chromosome panel draws none of those and has its own checks below,
  // and walking its hundred-odd frames took about a minute per walk.
  if (key === 'chrLIVE') { return; }
  win.selectStep(key);
  const total = Math.max(frames(key).length, 1);
  for (let i = 0; i < total; i += 1) {
    win.runAnimation('goto', i);
    fn(i, panel(key));
  }
}

// -- the shared walk ----------------------------------------------------------
// Painting every frame of every panel is the costly part of this suite: one
// pass over the figure takes about a minute in jsdom, and ten checks each made
// their own. A check that needs every frame now registers a visitor with
// everyFrame() and its report with afterWalk(). runSharedWalk() paints each
// replication panel frame once, hands it to every visitor, then runs the
// reports in the order they were registered. Visitors only read the page.
// The telomere panels (tw-) run on their own engine with their own
// invariants, and the live chromosome panel has its own checks, so neither is
// in this pass.
const VISITORS = [];
const REPORTS = [];
function everyFrame(fn) { VISITORS.push(fn); }
function afterWalk(fn) { REPORTS.push(fn); }
function isReplication(key) { return key !== 'chrLIVE' && !/^tw-/.test(key); }
function REP(key) { return !/^tw-/.test(key); }
function runSharedWalk() {
  win.PANEL_ORDER.filter(isReplication).forEach(function (key) {
    win.selectStep(key);
    const total = Math.max(frames(key).length, 1);
    for (let i = 0; i < total; i += 1) {
      win.runAnimation('goto', i);
      const root = panel(key);
      VISITORS.forEach(function (fn) { fn(key, i, root); });
    }
  });
  REPORTS.forEach(function (fn) { fn(); });
  VISITORS.length = 0;
  REPORTS.length = 0;
}

function lastFrame(key) {
  win.selectStep(key);
  const total = frames(key).length;
  win.runAnimation('goto', total ? total - 1 : 0);
  return panel(key);
}

// The document parses asynchronously, so the suite runs after the shell has
// mounted its panels.
setTimeout(run, 400);

function run() {

// === 1. GENERIC ASSERTIONS ================================================

const first = win.PANEL_ORDER[0];
win.selectStep(first);
ok('first panel renders at load', !!panel(first));
ok('first panel title rendered',
  doc.getElementById('steptitle').textContent.indexOf(win.META[first].title) === 0);

const actives = doc.querySelectorAll('#stage svg.panelsvg.active');
ok('exactly one panel visible', actives.length === 1, String(actives.length));

// -- transport -------------------------------------------------------------
const bar = doc.getElementById('transport');
win.selectStep('step04');
ok('transport arms on an animated panel', !bar.classList.contains('disarmed'));
ok('frame counter reports the total',
  doc.getElementById('framecount').textContent.indexOf('of ' + frames('step04').length) > 0,
  doc.getElementById('framecount').textContent);
win.selectStep('ctxORC');
ok('transport disarms on a static panel', bar.classList.contains('disarmed'));

// -- panel isolation -------------------------------------------------------
win.selectStep('step11');
win.runAnimation('goto', frames('step11').length - 1);
const otherStrand = panel('step10').querySelector('#l14-s');
const otherZone = panel('step10').querySelector('#l14-z');
ok('one panel animation does not touch another panel substrate element',
  otherStrand.classList.contains('duplex'), otherStrand.getAttribute('class'));
ok('one panel animation does not touch another panel derived element',
  !otherZone.classList.contains('z-replicated'), otherZone.getAttribute('class'));

// -- contract rows ---------------------------------------------------------
{
  const shellSrc = fs.readFileSync(path.join(ROOT, 'tools', 'make_shell.py'), 'utf8');
  const keys = JSON.parse('[' + /KEYS = \[([\s\S]*?)\]/.exec(shellSrc)[1]
    .replace(/'/g, '"').replace(/,\s*$/, '') + ']');
  ok('PANEL_ORDER equals KEYS in content and order',
    JSON.stringify(keys) === JSON.stringify(win.PANEL_ORDER),
    JSON.stringify(win.PANEL_ORDER));
  ok('PANEL_ORDER covers META exactly',
    win.PANEL_ORDER.slice().sort().join() === Object.keys(win.META).sort().join());
  ok('PANEL_ORDER has no repeats',
    new Set(win.PANEL_ORDER).size === win.PANEL_ORDER.length);
  ok('PANEL_ORDER is ORDER, then CONTEXT_ORDER, then MODEL_ORDER, then CHROM_ORDER, then TELOMERE_ORDER',
    JSON.stringify(win.ORDER.concat(win.CONTEXT_ORDER, win.MODEL_ORDER, win.CHROM_ORDER, win.TELOMERE_ORDER))
      === JSON.stringify(win.PANEL_ORDER));
  ok('the panel set is eleven main line, nineteen context, nine models and one live chromosome',
    win.ORDER.length === 11 && win.CONTEXT_ORDER.length === 19
      && win.MODEL_ORDER.length === 9 && win.CHROM_ORDER.length === 1,
    win.ORDER.length + ' + ' + win.CONTEXT_ORDER.length + ' + ' + win.MODEL_ORDER.length
      + ' + ' + win.CHROM_ORDER.length);

  const buildSrc = fs.readFileSync(path.join(ROOT, 'build.py'), 'utf8');
  const s1 = /SCRIPTS = \[([\s\S]*?)\]/.exec(shellSrc)[1].replace(/\s/g, '');
  const s2 = /SCRIPTS = \[([\s\S]*?)\]/.exec(buildSrc)[1].replace(/\s/g, '');
  ok('SCRIPTS agree between make_shell.py and build.py', s1 === s2);

  const panelSrc = fs.readFileSync(path.join(ROOT, 'tools', 'make_panels.py'), 'utf8');
  const pyParent = {};
  const block = /CONTEXT_PARENT = \{([\s\S]*?)\n\}/.exec(panelSrc)[1];
  block.replace(/'(\w+)':\s*'(\w+)'/g, function (_, a, b) { pyParent[a] = b; return ''; });
  ok('CONTEXT_PARENT agrees between Python and data.js',
    JSON.stringify(pyParent) === JSON.stringify(win.CONTEXT_PARENT),
    JSON.stringify(pyParent));
  const badParent = Object.keys(win.CONTEXT_PARENT)
    .filter(function (k) { return win.ORDER.indexOf(win.CONTEXT_PARENT[k]) < 0; });
  ok('every CONTEXT_PARENT entry names a real main-line key', !badParent.length,
    badParent.join());
  const unparented = win.CONTEXT_ORDER
    .filter(function (k) { return !win.CONTEXT_PARENT[k]; });
  ok('every context panel has a parent', !unparented.length, unparented.join());

  // The models hang badges off the steps they act at, from the same kind of
  // table, held to the same agreement.
  const pyModel = {};
  const mblock = /MODEL_PARENT = \{([\s\S]*?)\n\}/.exec(panelSrc)[1];
  mblock.replace(/'(\w+)':\s*'(\w+)'/g, function (_, a, b) { pyModel[a] = b; return ''; });
  ok('MODEL_PARENT agrees between Python and data.js',
    JSON.stringify(pyModel) === JSON.stringify(win.MODEL_PARENT),
    JSON.stringify(pyModel));
  const badModel = win.MODEL_ORDER.filter(function (k) {
    return win.ORDER.indexOf(win.MODEL_PARENT[k]) < 0;
  });
  ok('every model acts at a real main-line step', !badModel.length, badModel.join());
  const notModel = win.MODEL_ORDER.filter(function (k) { return win.META[k].kind !== 'model'; });
  ok('every panel on the models chart is of kind model', !notModel.length, notModel.join());
  const strayModel = win.ORDER.concat(win.CONTEXT_ORDER)
    .filter(function (k) { return win.META[k].kind === 'model'; });
  ok('no panel off the models chart is of kind model', !strayModel.length, strayModel.join());
}

// -- caption hygiene -------------------------------------------------------
{
  const src = fs.readFileSync(path.join(ROOT, 'src', 'data.js'), 'utf8');
  const bareCite = [];
  const badChars = [];
  Object.keys(win.META).forEach(function (k) {
    ['title', 'caption', 'note'].forEach(function (f) {
      const v = win.META[k][f];
      if (typeof v !== 'string') { return; }
      if (/(^|[^\\])cite\{/.test(v)) { bareCite.push(k + '.' + f); }
      if (/[\u2014\u2013]/.test(v)) { badChars.push(k + '.' + f); }
    });
  });
  ok('no caption, note or title contains a bare cite{', !bareCite.length,
    bareCite.join());
  ok('no banned characters in any caption, note or title', !badChars.length,
    badChars.join());
  const rawCount = (src.match(/String\.raw`/g) || []).length;
  // src/data.js holds the replication captions; the telomere captions are
  // String.raw literals in telomere/src/data.js and arrive through the port.
  const expected = Object.keys(win.META).filter(REP).length * 2;
  ok('every caption and note is a String.raw literal', rawCount === expected,
    rawCount + ' of ' + expected);
}

// -- citations actually render --------------------------------------------
{
  const bib = win.BIB;
  ok('the bibliography parsed', Object.keys(bib).length > 40,
    String(Object.keys(bib).length));

  const missing = [];
  Object.keys(win.META).forEach(function (k) {
    win.keysIn(win.META[k].caption + ' ' + win.META[k].note).forEach(function (c) {
      if (!bib[c]) { missing.push(k + ':' + c); }
    });
  });
  ok('every cited key resolves in refs.bib', !missing.length, missing.join());

  // The rendered output is checked, not the ledger. An earlier build stripped
  // the citation braces before the cite pattern ran, which left every marker
  // and every reference list empty while a ledger-only test still passed.
  const noMarker = [];
  const noList = [];
  const leaked = [];
  win.PANEL_ORDER.forEach(function (key) {
    win.selectStep(key);
    const cap = doc.getElementById('captiontext').innerHTML;
    const refs = doc.querySelectorAll('#refs li');
    const wanted = win.keysIn(win.META[key].caption).length;
    if (wanted && !/\[\d+\]/.test(cap)) { noMarker.push(key); }
    if (wanted && refs.length === 0) { noList.push(key); }
    if (/\\cite/.test(cap)) { leaked.push(key); }
  });
  ok('every caption with a citation renders a numbered marker', !noMarker.length,
    noMarker.join());
  ok('every caption with a citation renders a reference list', !noList.length,
    noList.join());
  ok('no raw cite command leaks into rendered text', !leaked.length, leaked.join());

  win.selectStep('step01');
  const html1 = doc.getElementById('refs').innerHTML;
  ok('no missing reference marker renders', html1.indexOf('missingref') < 0);
  const hrefs = Array.from(doc.querySelectorAll('#refs a')).map(function (a) {
    return a.getAttribute('href');
  });
  // Resolution runs DOI, then the entry's own URL, then a Scholar query, as
  // in the dissertation preamble, so a link is one of those three.
  ok('every reference link resolves to a DOI, a URL or a Scholar query',
    hrefs.length > 0 && hrefs.every(function (h) { return /^https?:\/\//.test(h); }),
    hrefs[0]);
  ok('no reference renders under two numbers', new Set(hrefs).size === hrefs.length);

  const n1 = doc.querySelectorAll('#refs li').length;
  win.selectStep('step02');
  win.selectStep('step01');
  ok('repainting a panel gives the same reference list length',
    doc.querySelectorAll('#refs li').length === n1);
  ok('repainting a panel gives the same citation markers',
    doc.getElementById('captiontext').innerHTML === (function () {
      return doc.getElementById('captiontext').innerHTML;
    }()));
}

// -- the note disclosure ---------------------------------------------------
{
  win.selectStep('step01');
  const wrap = doc.getElementById('notewrap');
  ok('the note disclosure shows on a panel with a note', !wrap.hidden);
  wrap.open = true;
  win.selectStep('step05');
  ok('the note disclosure keeps its open state across panels', wrap.open === true);
  ok('no note text leaks between panels',
    doc.getElementById('note').textContent.indexOf('searching initiator') < 0);
}

// -- text stays inside the canvas -----------------------------------------
{
  const bad = [];
  // The telomere panels draw unique sequence off the left edge for their
  // camera to pan to, so the bound is the replication panels'.
  win.PANEL_ORDER.filter(REP).forEach(function (key) {
    panel(key).querySelectorAll('text').forEach(function (t) {
      const x = parseFloat(t.getAttribute('x'));
      const y = parseFloat(t.getAttribute('y'));
      if (x < -40 || x > 920 || y < 0 || y > 300) {
        bad.push(key + ' ' + t.textContent.slice(0, 18));
      }
    });
  });
  ok('no text falls outside the viewBox', !bad.length, bad.slice(0, 3).join(', '));
}

// === 2. MODEL-SPECIFIC ASSERTIONS =========================================

// -- Python and the engine agree on the resting status --------------------
//
// A panel with no substrate has no tracks to derive four slots from, so it
// carries no status indicator either. The two travel together and the test
// below that one holds them to it.
function hasSubstrate(root) { return !!root.querySelector('.substrate'); }

{
  const bad = [];
  win.PANEL_ORDER.forEach(function (key) {
    win.selectStep(key);
    const root = panel(key);
    if (!hasSubstrate(root)) { return; }
    ['specification', 'licensing', 'activation', 'fork'].forEach(function (slot) {
      const el = root.querySelector('#cap-' + slot);
      const want = el.getAttribute('data-rest');
      const got = ['on', 'thin', 'off', 'na', 'lost'].find(function (s) {
        return el.classList.contains(s);
      });
      if (want !== got) { bad.push(key + '.' + slot + ' ' + want + '/' + got); }
    });
  });
  ok('resting status computed in Python equals the engine at frame 0', !bad.length,
    bad.slice(0, 4).join(', '));
}

{
  const bad = [];
  win.PANEL_ORDER.forEach(function (key) {
    const root = panel(key);
    if (!hasSubstrate(root)) { return; }
    ['specification', 'licensing', 'activation', 'fork'].forEach(function (slot) {
      if (!root.querySelector('#cap-' + slot)) { bad.push(key + '.' + slot); }
    });
  });
  ok('every panel with a substrate declares all four status slots', !bad.length,
    bad.join());

  // The substrate and its status indicator are the replication panels' own;
  // the telomere panels carry the telomere figure's cap bar instead.
  const mismatched = win.PANEL_ORDER.filter(REP).filter(function (key) {
    const root = panel(key);
    return hasSubstrate(root) !== !!root.querySelector('.capbar');
  });
  ok('the substrate and the status indicator are dropped together',
    !mismatched.length, mismatched.join());

  const noSub = win.PANEL_ORDER.filter(REP).filter(function (key) {
    return !hasSubstrate(panel(key));
  });
  ok('the two Mcm2-7 legends and the chromosome panels are the only panels without a substrate',
    noSub.join() === ['ctxMCM', 'ctxDH'].concat(win.CHROM_ORDER).join(), noSub.join());
}

// -- the complementary fits ------------------------------------------------
//
// A socket with no seat is allowed and is the point of the idiom: an unfilled
// socket is the statement that something is missing. A seat with no socket is
// not, because a partner drawn against nothing asserts an interaction the
// panel has not drawn the other half of.
{
  const EXEMPT = {
    // Dpb11 has delivered GINS and released the origin by the last frame, so
    // both of its fits are asserted at the frame the delivery happens instead,
    // just below. sld3-phos is the bridge to the mark on the clasp, and the
    // clasp is released in the same run of frames.
    'step09': ['dpb11-gins', 'sld3-phos']
  };
  const unmatched = [];
  const orphanSeats = [];
  win.PANEL_ORDER.forEach(function (key) {
    const root = lastFrame(key);
    const byName = {};
    root.querySelectorAll('.fitpt').forEach(function (el) {
      const n = el.getAttribute('data-fit');
      byName[n] = byName[n] || {};
      byName[n][el.getAttribute('data-role')] = absPt(el);
    });
    Object.keys(byName).forEach(function (n) {
      const v = byName[n];
      if (v.socket && v.seat) {
        const dx = Math.abs(v.socket[0] - v.seat[0]);
        const dy = Math.abs(v.socket[1] - v.seat[1]);
        if ((dx > 0.6 || dy > 0.6) && (EXEMPT[key] || []).indexOf(n) < 0) {
          unmatched.push(key + ':' + n + ' by ' + dx.toFixed(1) + ',' + dy.toFixed(1));
        }
      } else if (v.seat && !v.socket) {
        orphanSeats.push(key + ':' + n);
      }
    });
  });
  ok('every paired complementary fit matches to under 0.6 units', !unmatched.length,
    unmatched.slice(0, 4).join(', '));
  ok('no partner is drawn against a socket the panel does not draw',
    !orphanSeats.length, orphanSeats.join(', '));

  // The six fits the model claims are all actually drawn somewhere.
  const seen = new Set();
  win.PANEL_ORDER.forEach(function (key) {
    panel(key).querySelectorAll('.fitpt').forEach(function (el) {
      seen.add(el.getAttribute('data-fit').replace(/-\d$/, ''));
    });
  });
  ['cdc6-orc', 'cdt1-cdc6', 'cdt1-mcm3', 'cdc45-mcm2', 'cdc45-mcm5',
    'dpb11-sld2', 'dpb11-gins', 'sld3-dh-l', 'sld3-dh-r', 'sld3-cdk',
    'sld3-phos'].forEach(function (n) {
    ok('the fit ' + n + ' is drawn somewhere in the model', seen.has(n));
  });
  // The one fit that is exempt from the last-frame check is asserted at the
  // frame it is made, so exempting it does not leave it unasserted.
  // The module now descends from outside the frame, latches onto the Sld2 that
  // the previous panel left in the nucleoplasm, and travels to the origin, so
  // the frame it docks on is the fifth and not the fourth.
  win.selectStep('step09');
  win.runAnimation('goto', 4);
  ['dpb11-gins', 'sld3-phos'].forEach(function (name) {
    const root = panel('step09');
    const pts = {};
    root.querySelectorAll('.fitpt[data-fit="' + name + '"]').forEach(function (el) {
      pts[el.getAttribute('data-role')] = absPt(el);
    });
    ok('the fit ' + name + ' holds at the frame the module docks',
      pts.socket && pts.seat
      && Math.abs(pts.socket[0] - pts.seat[0]) < 0.6
      && Math.abs(pts.socket[1] - pts.seat[1]) < 0.6,
      JSON.stringify(pts));
  });

  ok('an adaptor cleft fit is drawn somewhere in the model',
    Array.from(seen).some(function (n) { return /-phos$/.test(n); }),
    Array.from(seen).join());
}

// -- adaptor clefts are empty or filled, never half filled -----------------
{
  const bad = [];
  win.PANEL_ORDER.forEach(function (key) {
    const root = lastFrame(key);
    root.querySelectorAll('.arch').forEach(function (arch) {
      const clefts = arch.querySelectorAll('.archcleft').length;
      const stars = arch.querySelectorAll('.phosstar').length;
      if (stars !== 0 && stars !== clefts) {
        bad.push(key + ' ' + stars + '/' + clefts);
      }
    });
  });
  ok('every adaptor is drawn with all clefts empty or all filled', !bad.length,
    bad.join(', '));
}

// -- the ARS block ---------------------------------------------------------
{
  const panelSrc = fs.readFileSync(path.join(ROOT, 'tools', 'make_panels.py'), 'utf8');
  const a = /ARS_A, ARS_B = '(\w+)', '(\w+)'/.exec(panelSrc);
  ok('ARS_A agrees between Python and the engine', a[1] === win.GEO.ARS_A);
  ok('ARS_B agrees between Python and the engine', a[2] === win.GEO.ARS_B);

  const span = [];
  for (let i = win.linOf(win.GEO.ARS_A); i <= win.linOf(win.GEO.ARS_B); i += 1) {
    span.push(win.chunkId(i));
  }
  const bad = [];
  const moved = [];
  everyFrame(function (key, fi, root) {
    if (!hasSubstrate(root)) { return; }
    const held = [];
    root.querySelectorAll('.arsblock').forEach(function (r) {
      const g = r.closest('.strand');
      const id = g.id.replace('-s', '');
      if (held.indexOf(id) < 0) { held.push(id); }
    });
    if (held.sort().join() !== span.slice().sort().join()) {
      bad.push(key + ' f' + fi + ' ' + held.join());
    }
    root.querySelectorAll('.arsblock').forEach(function (r) {
      if (transX(r) !== 0) { moved.push(key + ' f' + fi); }
    });
  });
  afterWalk(function () {
    ok('the ARS block spans exactly the declared positions in every panel', !bad.length,
      bad.slice(0, 2).join(', '));
    ok('the ARS block never carries an offset', !moved.length, moved.slice(0, 2).join());
  });
}

// -- kink is declared, never derived --------------------------------------
{
  const derivedKink = [];
  const transientOutside = [];
  const fixedTooEarly = [];
  everyFrame(function (key, fi, root) {
    root.querySelectorAll('.strand').forEach(function (g) {
      const has = ['kink-none', 'kink-transient', 'kink-fixed']
        .filter(function (c) { return g.classList.contains(c); });
      if (has.length !== 1) { derivedKink.push(key + ' f' + fi + ' ' + g.id); }
      if (g.classList.contains('kink-transient') && key !== 'step01' && key !== 'step02') {
        transientOutside.push(key);
      }
      if (g.classList.contains('kink-fixed') && key === 'step01') {
        fixedTooEarly.push(key + ' f' + fi);
      }
    });
  });
  afterWalk(function () {
    ok('every position carries exactly one kink state in every frame', !derivedKink.length,
      derivedKink.slice(0, 3).join(', '));
    ok('the transient kink appears only where ORC binds without Cdc6',
      !transientOutside.length, Array.from(new Set(transientOutside)).join());
    ok('the fixed kink never appears before Cdc6 seats', !fixedTooEarly.length,
      fixedTooEarly.slice(0, 2).join());
  });

  // A frame writes the kink, so it must be a token a frame can write.
  const t = win.ANIM.step02.frames[2].tracks;
  const sample = t[Object.keys(t)[0]];
  ok('a frame table can write a kink token', /kink-/.test(sample), sample);
}

// -- the NSD is declared, and the clasp reads it --------------------------
//
// Whether the Mcm4 NSD is seated, displaced, released or deleted is a claim
// about the step, so it is declared on the complex track like the gate, one
// value per run, and only a double hexamer carries one. offDDK is the panel
// that exists to show a seated NSD stopping the clasp, so it has to draw one.
{
  const missing = [];
  const split = [];
  const wrongFamily = [];
  everyFrame(function (key, fi, root) {
    if (!hasSubstrate(root)) { return; }
    let runVal = null;
    let runCpx = null;
    for (let i = 1; i <= win.GEO.NPOS; i += 1) {
      const el = root.querySelector('#' + win.chunkId(i) + '-c');
      if (!el) { continue; }
      const held = win.NSD_VALUES.filter((v) => el.classList.contains(v));
      if (held.length !== 1) {
        missing.push(key + ' f' + fi + ' ' + i + ' ' + held.join('+'));
        continue;
      }
      const cpx = ['naked', 'orc', 'occm', 'mcm1', 'mcm2', 'cmg']
        .find((v) => el.classList.contains(v));
      if (cpx !== 'mcm2' && held[0] !== 'nsd-na') {
        wrongFamily.push(key + ' f' + fi + ' ' + cpx + ' ' + held[0]);
      }
      if (cpx !== runCpx) { runCpx = cpx; runVal = held[0]; }
      else if (held[0] !== runVal) { split.push(key + ' f' + fi + ' at ' + i); }
    }
  });
  afterWalk(function () {
    ok('every position carries exactly one NSD value in every frame',
      !missing.length, missing.slice(0, 3).join(', '));
    ok('every complex run carries one NSD value', !split.length,
      split.slice(0, 3).join(', '));
    ok('only a double hexamer declares an NSD', !wrongFamily.length,
      wrongFamily.slice(0, 3).join(', '));
  });

  // A clasp drawn taking hold claims its fit, and a clasp drawn stopped or
  // held off claims none, or the mismatch stops being a statement.
  const claimed = [];
  const unclaimed = [];
  win.PANEL_ORDER.forEach(function (key) {
    const root = panel(key);
    if (!root.querySelector('.sld')) { return; }
    const seats = root.querySelectorAll('.fitpt[data-fit="sld3-dh-l"][data-role="seat"]');
    (seats.length ? claimed : unclaimed).push(key);
  });
  ok('the clasp claims its fit wherever it is drawn taking hold',
    claimed.indexOf('step07') >= 0 && claimed.indexOf('step08') >= 0,
    claimed.join());
  ok('the clasp claims no fit where it cannot take hold',
    unclaimed.indexOf('offDDK') >= 0 && unclaimed.indexOf('cstBOB1') >= 0,
    unclaimed.join());

  win.selectStep('offDDK');
  const seatedRun = panel('offDDK').querySelector('#o07-c');
  ok('the DDK-loss panel draws a pair with the NSD seated',
    seatedRun.classList.contains('nsd-seated'), seatedRun.getAttribute('class'));
  ok('the DDK-loss panel carries no phosphate anywhere',
    !panel('offDDK').querySelector('.phosstar'));
}

// -- MCM, ORC and the derived glyphs --------------------------------------
{
  // A hexamer is a ring seen edge on: three subunits on the near arc and three
  // on the far arc, in that many rows, and the two arcs live in different
  // layers so the strand bars pass between them.
  const GATE_ARC = ['2', '5', '3'];
  const SOLID_ARC = ['6', '4', '7'];
  const nums = (arc) => Array.prototype.map.call(
    arc.querySelectorAll('.mcmsub'),
    (s) => (s.getAttribute('class').match(/\bm([234567])\b/) || [])[1]);

  const bad = [];
  win.PANEL_ORDER.forEach(function (key) {
    panel(key).querySelectorAll('.mcmarc').forEach(function (arc) {
      const got = nums(arc).join('');
      if (got !== GATE_ARC.join('') && got !== SOLID_ARC.join('')) {
        bad.push(key + ' ' + got);
      }
      const face = arc.classList.contains('front') ? 'front' : 'back';
      if (arc.querySelectorAll('.mcmsub.' + face).length !== 3) {
        bad.push(key + ' face ' + face);
      }
    });
  });
  ok('every arc holds one of the two subunit triples, three deep', !bad.length,
    bad.slice(0, 3).join(', '));

  // The far arc goes in before the strand bars and the near arc after them, so
  // the DNA is drawn between the two walls of the ring and not in front of both.
  const layered = [];
  win.PANEL_ORDER.forEach(function (key) {
    const root = panel(key);
    root.querySelectorAll('.mcmarc.back').forEach(function (arc) {
      if (!arc.closest('.glyphlayer.back')) { layered.push(key + ' back'); }
    });
    root.querySelectorAll('.mcmarc.front').forEach(function (arc) {
      if (!arc.closest('.glyphlayer.front')) { layered.push(key + ' front'); }
    });
  });
  ok('the far arc is drawn under the substrate and the near arc over it',
    !layered.length, layered.slice(0, 3).join(', '));

  // The right hexamer of a pair is the left one turned about the vertical
  // axis, so it shows the other arc and no subunit ever faces itself.
  const dh = [];
  win.PANEL_ORDER.forEach(function (key) {
    panel(key).querySelectorAll('.mcmdh.front').forEach(function (g) {
      const arcs = g.querySelectorAll('.mcmarc');
      if (arcs.length !== 2) { dh.push(key + ' arcs ' + arcs.length); return; }
      const a = nums(arcs[0]).join('');
      const b = nums(arcs[1]).join('');
      if (a === b) { dh.push(key + ' both ' + a); }
      if (a !== GATE_ARC.join('') || b !== SOLID_ARC.join('')) {
        dh.push(key + ' ' + a + '/' + b);
      }
    });
  });
  ok('the two hexamers of a pair show different faces to the viewer',
    !dh.length, dh.slice(0, 3).join(', '));

  // One hexamer is two actor groups because its arcs sit in two layers. They
  // are one object, so they must never hold two positions.
  const split = [];
  everyFrame(function (key, fi, root) {
    root.querySelectorAll('[id$="-b"]').forEach(function (twin) {
      const main = root.querySelector('#' + twin.id.slice(0, -2));
      if (!main) { split.push(key + ' orphan ' + twin.id); return; }
      if (Math.abs(transX(twin) - transX(main)) > 0.01) {
        split.push(key + ' f' + fi + ' ' + twin.id);
      }
    });
  });
  afterWalk(function () {
    ok('an actor and its far-layer twin never hold two positions', !split.length,
      split.slice(0, 3).join(', '));
  });

  // The gate is declared on the complex track, one value for a whole run. A
  // run that disagreed with itself would put one hexamer in two states.
  const gates = [];
  everyFrame(function (key, fi, root) {
    if (!hasSubstrate(root)) { return; }
    let runVal = null;
    let runCpx = null;
    for (let i = 1; i <= 46; i += 1) {
      const el = root.querySelector('#' + win.chunkId(i) + '-c');
      if (!el) { continue; }
      const cpx = ['naked', 'orc', 'occm', 'mcm1', 'mcm2', 'cmg']
        .find((v) => el.classList.contains(v));
      const g = win.GATE_VALUES.find((v) => el.classList.contains(v));
      if (!g) { gates.push(key + ' f' + fi + ' no gate at ' + i); }
      if (cpx !== runCpx) { runCpx = cpx; runVal = g; }
      else if (g !== runVal) { gates.push(key + ' f' + fi + ' split run at ' + i); }
    }
  });
  afterWalk(function () {
    ok('every complex run carries one gate value', !gates.length,
      gates.slice(0, 3).join(', '));
  });

  // Each arc carries exactly one gate class, so nothing reads as open and
  // closed at the same time.
  const dup = [];
  everyFrame(function (key, fi, root) {
    root.querySelectorAll('.mcmarc').forEach(function (arc) {
      const held = win.GATE_VALUES.filter((v) => arc.classList.contains(v));
      if (held.length !== 1) { dup.push(key + ' f' + fi + ' ' + held.join('+')); }
    });
  });
  afterWalk(function () {
    ok('every arc holds exactly one gate state', !dup.length, dup.slice(0, 3).join(', '));
  });

  // Cdc45 and GINS across the gate is what sealed means, so a Cdc45 on an open
  // ring would be drawing a seal over a hole.
  const seal = [];
  everyFrame(function (key, fi, root) {
    root.querySelectorAll('.cdc45').forEach(function (c) {
      const holder = c.closest('.act') || root;
      const arc = holder.querySelector('.mcmarc');
      if (arc && arc.classList.contains('gate-open')) {
        seal.push(key + ' f' + fi);
      }
    });
  });
  afterWalk(function () {
    ok('Cdc45 never seats on an open ring', !seal.length, seal.slice(0, 3).join(', '));
  });

  const css = fs.readFileSync(path.join(ROOT, 'src', 'style.css'), 'utf8');
  ok('every MCM subunit has its own colour variable',
    ['2', '3', '4', '5', '6', '7'].every(function (n) {
      return css.indexOf('--mcm' + n + ':') >= 0;
    }));
  ok('no fill or stroke literal appears in the panel generator',
    !/fill\s*[:=]\s*['"]#/.test(fs.readFileSync(path.join(ROOT, 'tools', 'make_panels.py'), 'utf8')));

  const orcBad = [];
  win.PANEL_ORDER.forEach(function (key) {
    panel(key).querySelectorAll('.orcring').forEach(function (r) {
      const subs = r.querySelectorAll('.orcsub');
      const deg = r.querySelectorAll('.orcsub.deg');
      const non = r.querySelectorAll('.orcsub.non');
      if (subs.length !== 6 || deg.length !== 2 || non.length !== 1) {
        orcBad.push(key + ' ' + subs.length + '/' + deg.length + '/' + non.length);
      }
    });
  });
  ok('every ORC holds six subunits with Orc2 and Orc3 outlined and Orc6 apart',
    !orcBad.length, orcBad.slice(0, 3).join(', '));
}

// -- ORC never translocates, nucleosomes never move -----------------------
{
  const named = [];
  Object.keys(win.ANIM).forEach(function (key) {
    frames(key).forEach(function (f, i) {
      Object.keys(f.actors || {}).forEach(function (a) {
        if (a === 'actor-orc') { named.push(key + ' f' + i); }
      });
    });
  });
  ok('no frame table gives ORC an offset', !named.length, named.join());

  const drift = [];
  everyFrame(function (key, fi, root) {
    const el = root.querySelector('#actor-orc');
    if (el && !el.classList.contains('off') && Math.abs(transX(el)) > 0.6) {
      drift.push(key + ' f' + fi + ' ' + transX(el));
    }
  });
  afterWalk(function () {
    ok('ORC sits at its ARS position in every frame of every panel that draws it',
      !drift.length, drift.slice(0, 3).join(', '));
  });

  const nbad = [];
  everyFrame(function (key, fi, root) {
    root.querySelectorAll('.nuc').forEach(function (n) {
      if (transX(n) !== 0) { nbad.push(key + ' f' + fi + ' ' + n.id); }
    });
  });
  afterWalk(function () {
    ok('no nucleosome carries an offset anywhere', !nbad.length, nbad.join());
  });
}

// -- ejection ordering and signs ------------------------------------------
//
// Both loads eject the same two factors in the same order, so both are checked
// the same way. An animation that released them together would contradict the
// single-molecule ordering.
[['step03', 'actor-cdc6out', 'actor-cdt1out'],
  ['step05', 'actor-cdc6out2', 'actor-cdt1out2']].forEach(function (row) {
  const key = row[0];
  const cdc6 = [];
  const cdt1 = [];
  frames(key).forEach(function (f) {
    cdc6.push((f.actors || {})[row[1]]);
    cdt1.push((f.actors || {})[row[2]]);
  });
  // Offsets are [x, y] pairs since the factors leave on a slant; the claim is
  // about the side each leaves by, so the x component is what is read.
  const xs = function (a) {
    return a.filter(function (v) { return v !== undefined; })
      .map(function (v) { return Array.isArray(v) ? v[0] : v; });
  };
  const c6 = xs(cdc6), t1 = xs(cdt1);
  ok(key + ': Cdc6 leaves to the left',
    c6.length > 1 && c6[c6.length - 1] < c6[0] && c6[c6.length - 1] < 0, c6.join());
  ok(key + ': Cdt1 leaves to the right',
    t1.length > 1 && t1[t1.length - 1] > t1[0] && t1[t1.length - 1] > 0, t1.join());
  const moved = function (a) {
    return a.findIndex(function (v) { return v !== undefined && v !== 0; });
  };
  ok(key + ': Cdc6 leaves before Cdt1', moved(cdc6) >= 0 && moved(cdc6) < moved(cdt1),
    moved(cdc6) + ' then ' + moved(cdt1));
});

// -- arrival out of the nucleoplasm ---------------------------------------
//
// Both hexamers and the returning Cdc6 come down one arm of a parabola with
// its vertex at the landing site, so each descent has to lose height and close
// on the site at every step and end on it exactly. The second hexamer's
// descent is the first one over again, which is the drawn form of the claim
// that one route runs twice.
{
  const path = function (key, ident) {
    return frames(key).map(function (f) { return (f.actors || {})[ident]; })
      .filter(function (v) { return Array.isArray(v); });
  };
  const bad = [];
  [['step03', 'actor-hept'], ['step04', 'actor-cdc6in'],
    ['step05', 'actor-mcm-2']].forEach(function (row) {
    const p = path(row[0], row[1]);
    if (p.length < 3) { bad.push(row[0] + ' too few samples'); return; }
    for (let i = 1; i < p.length; i += 1) {
      if (Math.abs(p[i][0]) > Math.abs(p[i - 1][0]) || p[i][1] < p[i - 1][1]) {
        bad.push(row[0] + ' f' + i);
      }
    }
    const last = p[p.length - 1];
    if (last[0] !== 0 || last[1] !== 0) { bad.push(row[0] + ' does not land'); }
  });
  ok('every arrival loses height and closes on its landing site', !bad.length,
    bad.slice(0, 3).join(', '));

  const trim = function (p) {
    const out = [];
    for (let i = 0; i < p.length; i += 1) {
      out.push(p[i]);
      if (p[i][0] === 0 && p[i][1] === 0) { break; }
    }
    return out;
  };
  ok('the second delivery repeats the first',
    JSON.stringify(trim(path('step05', 'actor-mcm-2')))
      === JSON.stringify(trim(path('step03', 'actor-hept'))));
}

// -- the fixed camera ------------------------------------------------------
{
  const key = 'step11';
  const lefts = [];
  const rights = [];
  walk(key, function (fi, root) {
    lefts.push(transX(root.querySelector('#actor-cmg-l')));
    rights.push(transX(root.querySelector('#actor-cmg-r')));
  });
  const opposed = lefts.every(function (v, i) {
    return i === 0 || (v <= 0 && rights[i] >= 0);
  });
  ok('the two CMG offsets have opposite signs in every frame of step11', opposed,
    lefts.join() + ' / ' + rights.join());
  ok('the left fork travels left and the right fork travels right',
    lefts[lefts.length - 1] < lefts[1] && rights[rights.length - 1] > rights[1],
    lefts.join() + ' / ' + rights.join());
  ok('both forks reach the edge of the drawn region',
    lefts[lefts.length - 1] < -180 && rights[rights.length - 1] > 180,
    lefts[lefts.length - 1] + ' / ' + rights[rights.length - 1]);
  // The telomere figure pans in one branch (offD), on its own engine.
  ok('the replication panels use a fixed camera',
    !doc.querySelector('#stage svg.panelsvg:not(.telo) #actor-camera'));
}

// -- panel-to-panel handoffs ----------------------------------------------
{
  function at(key, frame, sel) {
    win.selectStep(key);
    win.runAnimation('goto', frame);
    const el = panel(key).querySelector(sel);
    return el ? transX(el) : null;
  }
  const pairs = [
    ['ORC across step01 and step02',
      at('step01', frames('step01').length - 1, '#actor-orc'), at('step02', 0, '#actor-orc')],
    ['the double hexamer across step05 and step06',
      at('step05', frames('step05').length - 1, '#actor-dh'), at('step06', 0, '#actor-dh')],
    ['the CMGs across step09 and step10',
      at('step09', frames('step09').length - 1, '#actor-cmg-l'), at('step10', 0, '#actor-cmg-l')],
    ['the CMGs across step10 and step11',
      at('step10', frames('step10').length - 1, '#actor-cmg-r'), at('step11', 0, '#actor-cmg-r')],
    ['the fork marks across step10 and step11',
      at('step10', frames('step10').length - 1, '#actor-fork-l'), at('step11', 0, '#actor-fork-l')]
  ];
  pairs.forEach(function (p) {
    ok('handoff matches for ' + p[0], p[1] !== null && Math.abs(p[1] - p[2]) < 0.6,
      p[1] + ' then ' + p[2]);
  });
}

// -- the shared DDK opening ------------------------------------------------
{
  function classesAt(key) {
    win.selectStep(key);
    const root = panel(key);
    return Array.from(root.querySelectorAll('.cpx')).map(function (c) {
      return c.getAttribute('class');
    }).join('|');
  }
  const a = classesAt('step06');
  const b = classesAt('offMCM4N');
  const c = classesAt('offPHOS');
  const d = classesAt('offBOB1');
  // The three bypasses differ from each other in the NSD and in nothing else
  // the tracks carry: deleted, displaced without a kinase, released. Their
  // parent opens on a seated NSD, so it differs from each of them in that one
  // family as well, and any other divergence means a branch has drifted from
  // the shared opening it is supposed to be a variation on.
  const noNsd = function (v) { return v.replace(/\bnsd-\w+/g, 'nsd'); };
  ok('the three DDK-bypass offshoots share derived classes at frame 0, NSD aside',
    noNsd(b) === noNsd(c) && noNsd(c) === noNsd(d), 'differ');
  ok('the shared opening differs from its parent only in the NSD',
    a !== d && noNsd(a) === noNsd(d),
    a === d ? 'identical' : 'differ by more than the NSD');
}

// -- idioms ----------------------------------------------------------------
{
  // The telomere chart keeps the telomere figure's idioms: its split bar and
  // its decision diamond. The rules hold on the replication charts.
  const REPCHARTS = '#navwrap .navpage:not([data-page="telomere"])';
  ok('no split bar is drawn on the replication charts', !doc.querySelector(REPCHARTS + ' .split'));
  ok('no polygon appears in the replication charts',
    !doc.querySelector(REPCHARTS + ' polygon'));

  const pairNodes = doc.querySelectorAll('#navwrap .navnode.pair');
  ok('the paired offshoot has exactly two members', pairNodes.length === 2,
    String(pairNodes.length));
  const ctxBracket = doc.querySelector('#navwrap .navpage[data-page="context"] .pairlab');
  ok('the second-load bracket exists and names what it relates',
    ctxBracket && /second load/.test(ctxBracket.textContent),
    ctxBracket ? ctxBracket.textContent : 'absent');
  const modelPair = doc.querySelectorAll('#navwrap .navnode.modelpair');
  ok('the ejection pair has exactly two members', modelPair.length === 2,
    String(modelPair.length));
  const modBracket = doc.querySelector('#navwrap .navpage[data-page="models"] .pairlab');
  ok('the ejection bracket exists and names what separates the two',
    modBracket && /Stn1 region/.test(modBracket.textContent),
    modBracket ? modBracket.textContent : 'absent');

  ok('no Cdt1 delivery node hangs under altDH02',
    !panel('altDH02').querySelector('.cdt1'));

  ok('the settled-mechanism glyph is absent from panels using the proposed idiom',
    !panel('offMCM4N').querySelector('.phosstar')
    && !panel('offBOB1').querySelector('.phosstar'));

  const regs = ['regCDK', 'regCDC6', 'regMCM', 'regCDT1'];
  ok('the regulation column uses inhibition bars and not arrows',
    regs.every(function (k) { return panel(k).querySelector('.inhbar'); }));
}

// -- scope guard -----------------------------------------------------------
{
  const banned = /Geminin|PCNA|Orc1 chromatin|re-?replication in metazoa/i;
  const hits = [];
  // The guard is for the replication model's metazoan comparison routes. A
  // telomere caption names PCNA for lagging-strand synthesis in yeast, which
  // the guard's PCNA was never about.
  Object.keys(win.META).filter(REP).forEach(function (k) {
    const v = win.META[k].caption + ' ' + win.META[k].note + ' ' + win.META[k].title;
    if (banned.test(v)) { hits.push(k); }
  });
  ok('no caption names a mechanism outside the budding yeast scope', !hits.length,
    hits.join());

  const bibText = win.INLINE_BIB || '';
  // fletcher2003structure is back: the bob1 panels cite it again for the
  // archaeal model the Pro83 proposal is built on.
  ok('the deleted entries are gone from the bibliography',
    ['mcgarry1998geminin', 'wu2014geminin', 'arias2006pcna',
      'quintana1997identification']
      .every(function (k) { return bibText.indexOf(k + ',') < 0; }));

  // Any caption citing a non-yeast entry has to name the organism in the same
  // caption, so a reader is never shown a claim without its source species.
  const unnamed = [];
  Object.keys(win.META).forEach(function (k) {
    const cap = win.META[k].caption;
    win.keysIn(cap).forEach(function (c) {
      const e = win.BIB[c];
      if (e && e.species && cap.indexOf(e.species) < 0) {
        unnamed.push(k + ':' + c + ' (' + e.species + ')');
      }
    });
  });
  ok('every caption citing a non-yeast entry names the organism', !unnamed.length,
    unnamed.join(', '));

  // No check that every entry is cited. The bibliography is the shared one
  // the dissertation uses, so most of it supports claims made elsewhere, and
  // the check that matters runs the other way: every key a caption cites
  // resolves, which is asserted above.
}

// -- the condition boundary ------------------------------------------------
{
  function trackString(root) {
    return Array.from(root.querySelectorAll('.cpx, .strand')).map(function (e) {
      return e.id + ':' + e.getAttribute('class');
    }).join('|');
  }
  win.selectStep('offCDT1N');
  win.runAnimation('goto', 0);
  const before = trackString(panel('offCDT1N'));
  win.runAnimation('goto', frames('offCDT1N').length - 1);
  const after = trackString(panel('offCDT1N'));
  ok('track values are identical across the condition boundary in offCDT1N',
    before === after);
  win.runAnimation('goto', 0);
  const strip0 = panel('offCDT1N').querySelector('#fx-cond-cdt1n');
  ok('the condition strip is revealed by the frames it covers',
    strip0.classList.contains('gone'));
}

// -- navigation ------------------------------------------------------------
{
  const pages = doc.querySelectorAll('#navwrap .navpage');
  ok('the navigation has exactly five pages', pages.length === 5, String(pages.length));
  ok('exactly one navigation page is visible',
    doc.querySelectorAll('#navwrap .navpage.active').length === 1);
  // The telomere chart carries the telomere figure's own cell-cycle rail.
  ok('every nav page carries the cell-cycle axis',
    Array.from(pages).every(function (p) {
      return p.querySelector(p.getAttribute('data-page') === 'telomere' ? '.cyband' : '.cycleaxis');
    }));

  // One tab per page, in page order, and the tab of the page on show is the
  // one marked, for the eye and for a screen reader.
  const tabs = Array.from(doc.querySelectorAll('#navtabs .navtab'));
  ok('there is one tab per page, in page order',
    JSON.stringify(tabs.map(function (t) { return t.getAttribute('data-page'); }))
      === JSON.stringify(Array.from(pages).map(function (p) {
        return p.getAttribute('data-page');
      })),
    tabs.map(function (t) { return t.getAttribute('data-page'); }).join());
  const tabBad = [];
  ['steps', 'context', 'models'].forEach(function (pg) {
    win.selectNavPage(pg);
    const on = tabs.filter(function (t) {
      return t.classList.contains('active') && t.getAttribute('aria-selected') === 'true';
    });
    if (on.length !== 1 || on[0].getAttribute('data-page') !== pg) { tabBad.push(pg); }
    if (doc.querySelector('#navwrap .navpage.active').getAttribute('data-page') !== pg) {
      tabBad.push(pg + ' page');
    }
  });
  ok('the tab of the page on show is the one marked', !tabBad.length, tabBad.join());
  ok('the old single toggle is gone', !doc.getElementById('navtoggle'));

  const stepKeys = Array.from(
    doc.querySelectorAll('#navwrap .navpage[data-page="steps"] .navnode')
  ).map(function (n) { return n.getAttribute('data-key'); });
  ok('the steps chart lists the main line and nothing else',
    JSON.stringify(stepKeys) === JSON.stringify(win.ORDER), stepKeys.join());
  const ctxKeys = Array.from(
    doc.querySelectorAll('#navwrap .navpage[data-page="context"] .navnode')
  ).map(function (n) { return n.getAttribute('data-key'); });
  ok('the context chart lists the context panels and nothing else',
    JSON.stringify(ctxKeys) === JSON.stringify(win.CONTEXT_ORDER), ctxKeys.join());
  const modKeys = Array.from(
    doc.querySelectorAll('#navwrap .navpage[data-page="models"] .navnode')
  ).map(function (n) { return n.getAttribute('data-key'); });
  ok('the models chart lists the models and nothing else',
    JSON.stringify(modKeys) === JSON.stringify(win.MODEL_ORDER), modKeys.join());

  // Every nav label has to sit inside the box it names. jsdom has no text
  // metrics, so the extent is estimated from the character count and the
  // anchor. That is coarse, but it catches the failure it exists to catch: a
  // stylesheet rule that re-anchors a label positioned from its box's left
  // edge, which hangs half the text outside the node.
  {
    const spill = [];
    doc.querySelectorAll('#navwrap .navnode').forEach(function (node) {
      const box = node.querySelector('.navbox');
      const bx = parseFloat(box.getAttribute('x'));
      const bw = parseFloat(box.getAttribute('width'));
      node.querySelectorAll('text').forEach(function (t) {
        const cs = win.getComputedStyle(t);
        const size = parseFloat(cs.fontSize) || 10;
        const anchor = cs.textAnchor || 'start';
        const w = t.textContent.length * size * 0.55;
        const x = parseFloat(t.getAttribute('x'));
        const left = anchor === 'middle' ? x - w / 2 : (anchor === 'end' ? x - w : x);
        if (left < bx || left + w > bx + bw) {
          spill.push(node.getAttribute('data-key') + ' "' + t.textContent + '" '
            + anchor + ' ' + left.toFixed(0) + '..' + (left + w).toFixed(0)
            + ' vs ' + bx + '..' + (bx + bw));
        }
      });
    });
    ok('every navigation label sits inside the node it names', !spill.length,
      spill.slice(0, 3).join(' | '));

    const wrongAnchor = [];
    ['.navtext', '.navnum', '.navgrouplab', '.caplab', '.capname'].forEach(function (sel) {
      const el = doc.querySelector('#navwrap ' + sel) || doc.querySelector(sel);
      if (el && win.getComputedStyle(el).textAnchor === 'middle') {
        wrongAnchor.push(sel);
      }
    });
    ok('labels positioned from a box edge are not centre anchored', !wrongAnchor.length,
      wrongAnchor.join());
  }

  const badges = doc.querySelectorAll('#navwrap .navbadge.ctxb[data-goto]');
  ok('every context panel has a badge on its parent step',
    badges.length === win.CONTEXT_ORDER.length, String(badges.length));
  const mbadges = Array.from(doc.querySelectorAll('#navwrap .navbadge.modelb[data-goto]'));
  // A model nested under a parent is drawn on its parent's panel and takes no badge.
  const unnested = win.MODEL_ORDER.filter(function (k) { return !win.MODEL_NEST[k]; });
  ok('every model that is not nested has a badge on the step it acts at',
    mbadges.length === unnested.length
      && mbadges.every(function (bdg) { return unnested.indexOf(bdg.getAttribute('data-goto')) >= 0; }),
    String(mbadges.length) + ' of ' + unnested.length);

  // Selecting a context panel from the steps page brings the other chart
  // forward, so the reader is never looking at a chart the selection is not on.
  win.selectNavPage('steps');
  win.selectStep('offBOB1');
  ok('selecting a context panel switches the chart',
    doc.querySelector('#navwrap .navpage.active').getAttribute('data-page') === 'context');
  win.selectStep('step06');
  ok('selecting a main-line panel switches back',
    doc.querySelector('#navwrap .navpage.active').getAttribute('data-page') === 'steps');
  win.selectStep('cstEJSS');
  ok('selecting a model brings the models chart forward',
    doc.querySelector('#navwrap .navpage.active').getAttribute('data-page') === 'models');
  win.selectStep('step01');

  ok('no phase band survives in the replication charts',
    !doc.querySelector('#navwrap .navpage:not([data-page="telomere"]) .band'));
  ok('no replication panel declares a phase',
    Object.keys(win.META).filter(REP).every(function (k) { return !win.META[k].phase; }));
}

// -- geometry contract -----------------------------------------------------
{
  const src = fs.readFileSync(path.join(ROOT, 'tools', 'make_panels.py'), 'utf8');
  function pick(name) {
    const m = new RegExp('^' + name + '\\s*=\\s*(\\d+)', 'm').exec(src);
    return m ? parseInt(m[1], 10) : null;
  }
  ok('X0 agrees between Python and the engine', pick('X0') === win.GEO.X0);
  ok('CW agrees between Python and the engine', pick('CW') === win.GEO.CW);
  ok('LEFT_CTX agrees between Python and the engine',
    pick('LEFT_CTX') === win.GEO.LEFT_CTX);
  ok('ORIGIN_N agrees between Python and the engine',
    pick('ORIGIN_N') === win.GEO.ORIGIN_N);
  ok('the id scheme agrees between Python and the engine',
    win.chunkId(1) === 'l14' && win.chunkId(14) === 'l01'
    && win.chunkId(15) === 'o01' && win.chunkId(32) === 'o18'
    && win.chunkId(33) === 'r01' && win.chunkId(46) === 'r14');
  ok('one hexamer is exactly three positions wide',
    win.GEO.MCM_W === 3 * win.GEO.CW, String(win.GEO.MCM_W));

  const sizes = {};
  win.PANEL_ORDER.forEach(function (key) {
    sizes[panel(key).getAttribute('viewBox')] = true;
  });
  ok('every panel uses one canvas size', Object.keys(sizes).length === 1,
    Object.keys(sizes).join());
}

// -- the derived layer stays out of the frame tables ----------------------
{
  const forbidden = [/-z$/, /^actor-orc$/, /^actor-occm$/, /^actor-mcm1$/, /^actor-dh$/,
    /^actor-cmg-/, /^actor-fork-/, /^actor-rpa-/, /^actor-pola-/, /^actor-pole-/,
    /^cap-/, /-b$/];
  const bad = [];
  Object.keys(win.ANIM).forEach(function (key) {
    frames(key).forEach(function (f, i) {
      ['tracks', 'fx', 'actors'].forEach(function (sec) {
        Object.keys(f[sec] || {}).forEach(function (id) {
          if (forbidden.some(function (re) { return re.test(id); })) {
            bad.push(key + ' f' + i + ' ' + id);
          }
        });
      });
    });
  });
  ok('no frame table names anything in the derived layer', !bad.length,
    bad.slice(0, 3).join(', '));

  const noFx = [];
  Object.keys(win.ANIM).forEach(function (key) {
    // The close-up registers tables for copies it makes on demand (ciorigin,
    // step07b and the rest); they have no panel on the stage to read.
    const root = panel(key);
    if (!root) { return; }
    // Each id is checked once, through one index of the panel's ids. The live
    // panel names over a thousand ids in each of its frames, and looking each
    // one up in the page per frame took about eleven minutes in jsdom.
    const ids = new Set();
    frames(key).forEach(function (f) { Object.keys(f.fx || {}).forEach(function (id) { ids.add(id); }); });
    if (!ids.size) { return; }
    const byId = new Map();
    root.querySelectorAll('[id]').forEach(function (el) { if (!byId.has(el.id)) { byId.set(el.id, el); } });
    ids.forEach(function (id) {
      const el = byId.get(id);
      if (el && !el.classList.contains('fx')) { noFx.push(key + ' ' + id); }
    });
  });
  ok('every element a frame fades carries .fx', !noFx.length, noFx.slice(0, 3).join(', '));
}

// -- the kinase reaches what it marks --------------------------------------
//
// A mark that appears while the kinase is somewhere else is two events drawn
// as one, and the panel it appears on is the panel about the transfer. So the
// burst has to be on its substrate in the frame the mark lands, for both
// substrates, and they are in different places.
{
  function absXY(el) {
    let x = parseFloat(el.getAttribute('x'));
    let y = parseFloat(el.getAttribute('y'));
    let n = el.parentNode;
    while (n && n.getAttribute) {
      const t = n.getAttribute('transform');
      if (t) {
        const m = /translate\(\s*(-?[\d.]+)[\s,]*(-?[\d.]+)?/.exec(t);
        if (m) { x += parseFloat(m[1]); y += parseFloat(m[2] || '0'); }
      }
      n = n.parentNode;
    }
    return [x, y];
  }
  function absC(el) { return absPt(el); }
  const KIN_R = 30;                 // the outer radius of the burst
  const KIN_ARROW = 40;             // the longest arrow a transfer is drawn with
  const reach = [];
  [['fx-sld2p', 'Sld2'], ['fx-sld3p', 'Sld3']].forEach(function (row) {
    let landed = -1;
    let gap = null;
    walk('step08', function (fi, root) {
      const mark = root.querySelector('#' + row[0]);
      if (landed >= 0 || !mark || mark.classList.contains('gone')) { return; }
      landed = fi;
      const core = root.querySelector('#actor-scdk .kincore');
      const star = mark.querySelector('text');
      if (!core || !star) { return; }
      const a = absC(core);
      const b = absXY(star);
      gap = Math.sqrt(Math.pow(a[0] - b[0], 2) + Math.pow(a[1] - b[1], 2));
      const arrow = root.querySelector('#fx-kin-' + row[1].toLowerCase());
      if (!arrow || arrow.classList.contains('gone')) { gap = Infinity; }
    });
    if (gap === null || gap > KIN_R + KIN_ARROW) {
      reach.push(row[1] + ' f' + landed + ' by ' + (gap === null ? 'never' : gap.toFixed(1)));
    }
  });
  // S-CDK stops beside each substrate and an arrow draws the transfer to the
  // mark, on the frame the mark arrives (tools/make_panels.py audit_kinase
  // holds the arrow to that frame and the kinase to its drawn offset). So the
  // kinase must be beside the mark, within the burst plus one arrow's reach,
  // and its arrow must show on that frame.
  ok('S-CDK is beside each substrate, its arrow drawn, in the frame that substrate is marked',
    !reach.length, reach.join(', '));

  // The inhibition that used to sit on this panel belongs on the regulation
  // chart with the other things one kinase activity blocks, and drawing it
  // twice would have made one edge look like two.
  const stray = [];
  win.PANEL_ORDER.forEach(function (key) {
    panel(key).querySelectorAll('text').forEach(function (t) {
      if (/Sic1/.test(t.textContent) && key !== 'regCDK') { stray.push(key); }
    });
  });
  ok('Sic1 is not drawn on the main line', !stray.length, stray.join());
}

// -- the module is assembled on the page -----------------------------------
//
// Sld2 is marked in one panel and delivered in the next, so it has to be the
// same molecule in the same place at the boundary. Dpb11 and GINS come to it
// from outside the frame, and the three travel to the origin as one thing
// once they are joined.
{
  function labelPt(key, frame, text) {
    win.selectStep(key);
    win.runAnimation('goto', frame);
    const els = Array.from(panel(key).querySelectorAll('text'));
    const el = els.filter(function (e) { return e.textContent.trim() === text; })[0];
    if (!el) { return null; }
    let x = parseFloat(el.getAttribute('x'));
    let y = parseFloat(el.getAttribute('y'));
    let n = el.parentNode;
    while (n && n.getAttribute) {
      const t = n.getAttribute('transform');
      if (t) {
        const m = /translate\(\s*(-?[\d.]+)[\s,]*(-?[\d.]+)?/.exec(t);
        if (m) { x += parseFloat(m[1]); y += parseFloat(m[2] || '0'); }
      }
      n = n.parentNode;
    }
    return [x, y];
  }
  const was = labelPt('step08', frames('step08').length - 1, 'Sld2');
  const now = labelPt('step09', 0, 'Sld2');
  ok('Sld2 opens step09 where step08 left it',
    was && now && Math.abs(was[0] - now[0]) < 0.6 && Math.abs(was[1] - now[1]) < 0.6,
    JSON.stringify(was) + ' then ' + JSON.stringify(now));

  const path = function (ident) {
    return frames('step09').map(function (f) { return (f.actors || {})[ident]; });
  };
  const dpb = path('actor-dpb11');
  const gins = path('actor-ginsfree');
  const sld2 = path('actor-sld2c');
  ok('Dpb11 and GINS enter step09 from above the frame',
    dpb[0][1] < -150 && gins[0][1] < -150, JSON.stringify([dpb[0], gins[0]]));
  ok('Dpb11 and GINS descend without turning back',
    dpb.every(function (v, i) { return i === 0 || v[1] >= dpb[i - 1][1] || i > 4; }),
    JSON.stringify(dpb));
  const latched = dpb.map(function (v, i) {
    return v[0] === sld2[i][0] && v[1] === sld2[i][1];
  });
  ok('Dpb11 and Sld2 hold one offset from the latch onward',
    latched.slice(2).every(Boolean) && !latched[0], JSON.stringify(latched));
  const docked = dpb.findIndex(function (v) { return v[0] === 0 && v[1] === 0; });
  ok('the module docks after it is assembled', docked > 2, String(docked));
}

// -- the substrate opens by one amount -------------------------------------
//
// melted and extruded open the bars different distances and carry different
// colours, which is what says the two are different states. A position left at
// melted with extruded positions on both sides is therefore drawing DNA that
// the fork opened and then did not, which is an artefact of the frame table
// and never a claim.
{
  const stranded = [];
  everyFrame(function (key, fi, root) {
    const v = [];
    for (let i = 1; i <= win.GEO.NPOS; i += 1) {
      const el = root.querySelector('#' + win.chunkId(i) + '-s');
      v[i] = el ? ['duplex', 'melted', 'extruded', 'replicated']
        .filter(function (c) { return el.classList.contains(c); })[0] : null;
    }
    const open = function (s) { return s === 'extruded' || s === 'replicated'; };
    for (let i = 2; i < win.GEO.NPOS; i += 1) {
      if (v[i] !== 'melted') { continue; }
      const left = v.slice(1, i).some(open);
      const right = v.slice(i + 1).some(open);
      if (left && right) { stranded.push(key + ' f' + fi + ' ' + win.chunkId(i)); }
    }
  });
  afterWalk(function () {
    ok('no position is left melted inside a region that has opened',
      !stranded.length, stranded.slice(0, 3).join(', '));
  });
}

// -- new DNA ---------------------------------------------------------------
//
// The daughter strands are drawn inside the strand groups so each rides the
// parental bar it was copied from, and they are drawn only where a panel can
// declare a position replicated. A panel that declared the state without the
// bars would be reporting synthesis it does not draw.
{
  const orphan = [];
  const missing = [];
  const malformed = [];
  win.PANEL_ORDER.forEach(function (key) {
    const root = panel(key);
    root.querySelectorAll('.nasc').forEach(function (r) {
      if (!r.closest('.strand')) { orphan.push(key); }
      const kind = ['dna', 'primer'].filter(function (c) { return r.classList.contains(c); });
      const face = ['top', 'bot'].filter(function (c) { return r.classList.contains(c); });
      if (kind.length !== 1 || face.length !== 1) { malformed.push(key); }
    });
  });
  everyFrame(function (key, fi, r2) {
    const any = r2.querySelectorAll('.strand.replicated').length > 0;
    if (any && !r2.querySelector('.nasc')) { missing.push(key + ' f' + fi); }
  });
  ok('every daughter bar sits inside the strand group that opens it', !orphan.length,
    orphan.slice(0, 3).join());
  ok('every daughter bar names one polymer and one face', !malformed.length,
    malformed.slice(0, 3).join());
  afterWalk(function () {
    ok('no panel declares a position replicated without drawing the new DNA',
      !missing.length, missing.slice(0, 3).join(', '));
  });

  // One fork makes one strand continuously and the other in pieces, and which
  // is which follows from the direction the fork travels. The leading strand
  // therefore carries the single primer that started it and the lagging strand
  // carries one per fragment.
  const root = lastFrame('step11');
  const count = function (side, face, kind) {
    let n = 0;
    for (let i = 1; i <= win.GEO.NPOS; i += 1) {
      if ((side === 'l') !== (i <= 23)) { continue; }
      const g = root.querySelector('#' + win.chunkId(i) + '-s');
      if (g) { n += g.querySelectorAll('.nasc.' + kind + '.' + face).length; }
    }
    return n;
  };
  ok('the left fork copies the top strand continuously and the bottom in pieces',
    count('l', 'top', 'primer') === 1 && count('l', 'bot', 'primer') > 1,
    count('l', 'top', 'primer') + ' / ' + count('l', 'bot', 'primer'));
  ok('the right fork is the mirror of the left',
    count('r', 'bot', 'primer') === 1 && count('r', 'top', 'primer') > 1,
    count('r', 'bot', 'primer') + ' / ' + count('r', 'top', 'primer'));
}

// -- both polymerases on both forks ----------------------------------------
{
  const root = lastFrame('step11');
  const yOf = function (id) {
    const t = root.querySelector('#actor-' + id + ' text');
    return t ? parseFloat(t.getAttribute('y')) : null;
  };
  const axis = (win.GEO.ROW_T + win.GEO.ROW_B + win.GEO.BAR_H) / 2;
  ok('each fork carries a leading and a lagging polymerase',
    ['pole-l', 'pola-l', 'pole-r', 'pola-r'].every(function (id) {
      return root.querySelector('#actor-' + id);
    }));
  ok('each polymerase is drawn on the strand it copies',
    yOf('pole-l') < axis && yOf('pola-l') > axis
    && yOf('pole-r') > axis && yOf('pola-r') < axis,
    [yOf('pole-l'), yOf('pola-l'), yOf('pole-r'), yOf('pola-r')].join());
}

// -- nucleosomes come off at the fork --------------------------------------
//
// Eviction is derived from both tracks and writes both ways, so scrubbing back
// through a panel restores what scrubbing forward removed.
{
  const gone = function (root) {
    return Array.from(root.querySelectorAll('.nuc'))
      .filter(function (n) { return n.classList.contains('gone'); }).length;
  };
  ok('no nucleosome is displaced before a fork exists', gone(lastFrame('step09')) === 0,
    String(gone(lastFrame('step09'))));
  const end = lastFrame('step11');
  ok('every nucleosome the forks reach has come off', gone(end) === 4, String(gone(end)));
  win.runAnimation('goto', 0);
  ok('eviction is derived and not latched', gone(panel('step11')) === 0,
    String(gone(panel('step11'))));

  const early = [];
  walk('step11', function (fi, root) {
    root.querySelectorAll('.nuc').forEach(function (n) {
      const span = (n.getAttribute('data-span') || '').split(' ');
      let touched = false;
      for (let i = win.linOf(span[0]); i <= win.linOf(span[1]); i += 1) {
        const s = root.querySelector('#' + win.chunkId(i) + '-s');
        if (s && !s.classList.contains('duplex')) { touched = true; }
      }
      if (n.classList.contains('gone') !== touched) { early.push(fi + ' ' + n.id); }
    });
  });
  ok('a nucleosome is off exactly when the fork has reached its span',
    !early.length, early.slice(0, 3).join(', '));
}

// -- lagging synthesis runs against the fork -------------------------------
//
// The leading strand is made continuously and keeps up with the helicase. The
// lagging strand is made as fragments primed where the fork is and extended
// backward toward the origin, so within one fragment the piece the fork
// reaches first is laid first and the pieces behind it follow. Nothing about
// that order can be declared per position, because it is the reverse of the
// order the fork reaches them, so it is derived and these are the checks on
// the derivation.
{
  const N = 8;                       // positions per fragment, GEO.OKAZAKI_N
  const SPLIT = 23;                  // the position the forks part at
  function laidSet(root) {
    const out = [];
    for (let i = 1; i <= win.GEO.NPOS; i += 1) {
      const g = root.querySelector('#' + win.chunkId(i) + '-s');
      if (g && g.querySelector('.nasc.lag.laid')) { out.push(i); }
    }
    return out;
  }
  function openEnds(root) {
    let lo = 0, hi = 0;
    for (let i = 1; i <= win.GEO.NPOS; i += 1) {
      const g = root.querySelector('#' + win.chunkId(i) + '-s');
      if (g && !g.classList.contains('duplex')) { if (!lo) { lo = i; } hi = i; }
    }
    return [lo, hi];
  }
  const outOfReach = [];
  const outOfOrder = [];
  const byFrame = [];
  walk('step11', function (fi, root) {
    const laid = laidSet(root);
    const ends = openEnds(root);
    byFrame.push(laid.length);
    const dOf = function (i) { return i <= SPLIT ? SPLIT - i + 1 : i - SPLIT; };
    laid.forEach(function (i) {
      // Nothing is laid past the fork that would have primed it.
      if (i < ends[0] || i > ends[1]) { outOfReach.push(fi + ' ' + win.chunkId(i)); }
    });
    // Within a fragment, a laid piece implies every piece outward of it in the
    // same fragment is laid, because filling runs from the fork end inward.
    const isLaid = {};
    laid.forEach(function (i) { isLaid[i] = true; });
    for (let i = 1; i <= win.GEO.NPOS; i += 1) {
      if (!isLaid[i]) { continue; }
      const d = dOf(i);
      const k = (d - 1) % N + 1;
      for (let kk = k + 1; kk <= N; kk += 1) {
        const outward = i <= SPLIT ? i - (kk - k) : i + (kk - k);
        if (outward >= 1 && outward <= win.GEO.NPOS && dOf(outward) <= 23
            && !isLaid[outward]) {
          outOfOrder.push(fi + ' ' + win.chunkId(i) + ' before ' + win.chunkId(outward));
        }
      }
    }
  });
  ok('no lagging piece is laid where no fork has passed', !outOfReach.length,
    outOfReach.slice(0, 3).join(', '));
  ok('each fragment fills from its fork end back toward the origin',
    !outOfOrder.length, outOfOrder.slice(0, 3).join(', '));
  ok('lagging synthesis only ever gains ground',
    byFrame.every(function (n, i) { return i === 0 || n >= byFrame[i - 1]; }),
    byFrame.join());
  ok('the lagging strand starts empty and is still unfinished at the end',
    byFrame[0] === 0 && byFrame[byFrame.length - 1] > 0
    && byFrame[byFrame.length - 1] < win.GEO.NPOS,
    byFrame[0] + ' then ' + byFrame[byFrame.length - 1]);

  // The leading strand has no such lag: every position a fork has passed
  // carries one, right up to the helicase.
  const end = lastFrame('step11');
  const bare = [];
  for (let i = 1; i <= win.GEO.NPOS; i += 1) {
    const g = end.querySelector('#' + win.chunkId(i) + '-s');
    if (!g || g.classList.contains('duplex')) { continue; }
    if (!g.querySelector('.nasc.lead')) { bare.push(win.chunkId(i)); }
    const shown = g.classList.contains('extruded') || g.classList.contains('replicated');
    if (!shown) { bare.push(win.chunkId(i) + ' not opened'); }
  }
  ok('every position a fork has passed carries a leading strand', !bare.length,
    bare.slice(0, 3).join());
}

// -- ORC is never taken away ----------------------------------------------
//
// Budding yeast ORC stays bound through S and G2/M, and the dim it takes once
// the pair has left is the only thing any frame does to it. A frame that took
// an ARS run to gone would draw an eviction the model rejects.
{
  const gone = [];
  Object.keys(win.ANIM).forEach(function (key) {
    frames(key).forEach(function (f, i) {
      Object.keys(f.tracks || {}).forEach(function (id) {
        const v = String(f.tracks[id]);
        if (/-c$/.test(id) && /\borc\b/.test(v) && /\bgone\b/.test(v)) {
          gone.push(key + ' f' + i + ' ' + id);
        }
      });
    });
  });
  ok('no frame table takes ORC to gone', !gone.length, gone.slice(0, 3).join(', '));
}

// Every visitor registered above runs here, in one pass over the figure.
runSharedWalk();

// === 3. THE FIRING MODELS FOR CST ==========================================

// -- CST is drawn only where a model is, and is cut to nothing -------------
{
  const isModel = function (k) { return win.MODEL_ORDER.indexOf(k) >= 0; };
  // The telomere panels draw CST where it acts, at the telomere.
  const stray = win.PANEL_ORDER.filter(REP).filter(function (k) {
    return !isModel(k) && panel(k).querySelector('.cst');
  });
  ok('CST is drawn on model panels and on no other replication panel', !stray.length, stray.join());
  const absent = win.MODEL_ORDER.filter(function (k) { return !panel(k).querySelector('.cst'); });
  ok('every model panel draws CST', !absent.length, absent.join());
  const fitted = win.MODEL_ORDER.filter(function (k) {
    return panel(k).querySelector('.cst .fitpt');
  });
  ok('CST claims no fit anywhere', !fitted.length, fitted.join());

  // ORC is left off the models, which act after the pair has left it, and the
  // complex track still reports it.
  const withOrc = win.MODEL_ORDER.filter(function (k) {
    return panel(k).querySelector('.orcring');
  });
  ok('no model panel draws ORC', !withOrc.length, withOrc.join());

  // The two ejection mechanisms differ in which region of Stn1 is drawn, and
  // that is the whole difference between them.
  const pieces = function (k) {
    return ['cdc13', 'stn1c', 'stn1n', 'ten1'].filter(function (c) {
      return panel(k).querySelector('.cstpiece.' + c);
    }).join(',');
  };
  const whole = win.MODEL_ORDER.filter(function (k) {
    return pieces(k) !== 'cdc13,stn1c,stn1n,ten1';
  });
  ok('every model draws the whole complex', !whole.length, whole.join());
  ok('Stn1 is split in the Pol alpha model alone, with its linker',
    win.MODEL_ORDER.every(function (k) {
      return !!panel(k).querySelector('.cstlinker') === (k === 'cstPOLA');
    }));
}

// -- CST sits where the two-hybrid scores put it ----------------------------
//
// All three subunits score with Mcm2 and Stn1 and Ten1 also with Mcm5, so in
// every model Stn1 and Ten1 lie on the near face of the left ring across the
// boundary between the Mcm2 and Mcm5 rows, and Cdc13, where it is on the face,
// lies above that boundary on the Mcm2 row. The boundary is 142.5 on the left
// hexamer of a pair and 147 on a CMG, which carries no skew (face_boundary in
// tools/make_panels.py). Each model is read on a frame that draws CST.
{
  const shown = { cstEJSS: 5, cstEJPR: 5, cstCONF: 6, cstCDC7: 6, cstRIF1: 8, cstBOB1: 8, cstPOLA: 5 };
  const off = [];
  win.MODEL_ORDER.forEach(function (key) {
    win.selectStep(key);
    if (frames(key).length) { win.runAnimation('goto', shown[key]); }
    const root = panel(key);
    const cmg = root.querySelector('#actor-cmg-l');
    const yb = cmg ? 147 : 142.5;
    const c = 413 + (cmg ? transX(cmg) : 0);
    const holder = root.querySelector('#actor-cst');
    const dx = holder ? transX(holder) : 0;
    function span(sel) {
      const r = root.querySelector(sel + ' rect');
      if (!r) { return null; }
      const x = parseFloat(r.getAttribute('x')) + dx;
      const y = parseFloat(r.getAttribute('y'));
      return [x, y, x + parseFloat(r.getAttribute('width')),
        y + parseFloat(r.getAttribute('height'))];
    }
    function onFace(b) {
      return b && b[1] < yb && b[3] > yb && b[0] >= c - 27 && b[2] <= c + 30;
    }
    ['stn1n', 'ten1'].forEach(function (n) {
      if (!onFace(span('.cstpiece.' + n))) { off.push(key + ' ' + n); }
    });
    const cHalf = span('.cstpiece.stn1c');
    if (onFace(cHalf)) {
      const d = root.querySelector('.cstpiece.cdc13 path').getAttribute('d')
        .match(/-?[\d.]+/g).map(Number);
      // M x y L x y A r r rot large sweep x y: the three vertices' y values.
      const ys = [d[1], d[3], d[10]];
      if (Math.max.apply(null, ys) > yb - 0.01) { off.push(key + ' cdc13 below the boundary'); }
    } else if (key !== 'cstPOLA') {
      off.push(key + ' stn1c');
    }
  });
  ok('Stn1 and Ten1 lie across the Mcm2-Mcm5 boundary of the left ring in every model',
    !off.length, off.join(', '));
  win.selectStep('step01');

  // The Pol alpha model hangs the Stn1 C half on the polymerase the engine
  // places, so the generator and the engine hold one offset.
  const pySrc = fs.readFileSync(path.join(ROOT, 'tools', 'make_panels.py'), 'utf8');
  const jsSrc = fs.readFileSync(path.join(ROOT, 'src', 'animate.js'), 'utf8');
  const py = /POLA_DX = ([\d.]+)/.exec(pySrc);
  const jl = /actor-pola-l'[^\n]*xl \+ (\d+)/.exec(jsSrc);
  const jr = /actor-pola-r'[^\n]*xr - (\d+)/.exec(jsSrc);
  ok('Pol alpha sits POLA_DX behind its fork in the engine and the generator',
    py && jl && jr && parseFloat(py[1]) === parseFloat(jl[1])
      && parseFloat(jl[1]) === parseFloat(jr[1]),
    JSON.stringify([py && py[1], jl && jl[1], jr && jr[1]]));
}

// -- the ejected strand ------------------------------------------------------
//
// Drawn only in the two ejection panels, only on the left CMG, whose gate
// faces the viewer, and always at the height the bar it stands for has in the
// strand state of that frame.
{
  // Only the ssDNA-binding mechanism makes the strand CST's partner, so only
  // that panel draws it; both panels run the same frames otherwise.
  const ej = ['cstEJSS', 'cstEJPR'];
  const where = win.PANEL_ORDER.filter(function (k) { return panel(k).querySelector('.ejectbar'); });
  // cstDOWN is the parent that draws its nested models together, so it draws
  // the strand where the ssDNA-binding model acts.
  ok('the ejected strand is drawn in the ssDNA-binding panel and its parent only',
    JSON.stringify(where.slice().sort()) === JSON.stringify(['cstDOWN', 'cstEJSS']), where.join());
  const offCmg = ['cstEJSS'].filter(function (k) {
    return Array.from(panel(k).querySelectorAll('.ejectbar')).some(function (r) {
      return !r.closest('#actor-cmg-l');
    });
  });
  ok('the ejected strand rides the left CMG', !offCmg.length, offCmg.join());

  const mismatch = [];
  const early = [];
  const late = [];
  const drift = [];
  ej.forEach(function (key) {
    const piece = '#actor-cst';
    let gap = null;
    walk(key, function (fi, root) {
      const on = function (el) { return !el.classList.contains('gone'); };
      const strand = root.querySelector('#o07-s');
      const cst = root.querySelector('#fx-cst');
      const mcm10 = root.querySelector('#fx-mcm10');
      if (key === 'cstEJSS') {
        const melt = root.querySelector('#fx-eject-melt');
        const open = root.querySelector('#fx-eject-open');
        if (on(melt) && !strand.classList.contains('melted')) { mismatch.push(key + ' f' + fi + ' melt'); }
        if (on(open) && !strand.classList.contains('extruded')) { mismatch.push(key + ' f' + fi + ' open'); }
        // CST binds once there is something ejected to act on.
        if (on(cst) && !on(melt) && !on(open)) { early.push(key + ' f' + fi); }
      } else if (on(cst) && !strand.classList.contains('melted')
          && !strand.classList.contains('extruded')) {
        // With no strand drawn, CST still arrives only once the origin is open.
        early.push(key + ' f' + fi);
      }
      if (mcm10.classList.contains('gone') && on(cst)) { late.push(key + ' f' + fi); }
      // The piece rides the helicase: its offset from the left CMG holds.
      if (on(cst)) {
        const d = transX(root.querySelector(piece)) - transX(root.querySelector('#actor-cmg-l'));
        if (gap === null) { gap = d; } else if (Math.abs(gap - d) > 0.6) {
          drift.push(key + ' f' + fi + ' ' + d.toFixed(1) + ' vs ' + gap.toFixed(1));
        }
      }
    });
  });
  ok('the ejected strand is drawn at the height of the strand state', !mismatch.length,
    mismatch.join(', '));
  ok('CST arrives no earlier than the ejection', !early.length, early.join(', '));
  ok('CST leaves no later than Mcm10', !late.length, late.join(', '));
  ok('CST rides the left CMG through passage', !drift.length, drift.join(', '));

  // The engine and the generator hold the same two drops; the stylesheet is
  // what actually moves the bars.
  const pySrc = fs.readFileSync(path.join(ROOT, 'tools', 'make_panels.py'), 'utf8');
  const cssSrc = fs.readFileSync(path.join(ROOT, 'src', 'style.css'), 'utf8');
  const drops = /EJECT_DROP = \{'melt': ([\d.]+), 'open': ([\d.]+)\}/.exec(pySrc);
  const melted = /\.strand\.melted \.bar\.bot[^{]*\{ transform: translateY\((\d+)px\)/.exec(cssSrc);
  const opened = /\.strand\.extruded \.bar\.bot,[\s\S]*?translateY\((\d+)px\)/.exec(cssSrc);
  ok('the ejected strand drops by the amounts the stylesheet moves the bars',
    drops && melted && opened && parseFloat(drops[1]) === parseFloat(melted[1])
      && parseFloat(drops[2]) === parseFloat(opened[1]),
    JSON.stringify([drops && drops.slice(1), melted && melted[1], opened && opened[1]]));
}

// -- the model panels keep their base panels' tracks -----------------------
//
// A model is a proposal set on a step the reader has already seen, so what a
// model panel declares on the substrate at rest is what its base declares.
{
  function trackClasses(key, frame) {
    win.selectStep(key);
    if (frames(key).length) { win.runAnimation('goto', frame); }
    // As sets of classes: a frame writes its tokens in the order the engine
    // applies them, which says nothing about the state.
    return Array.from(panel(key).querySelectorAll('.cpx, .strand')).map(function (e) {
      return e.id + ':' + e.getAttribute('class').split(/\s+/).sort().join(' ');
    }).join('|');
  }
  // The DDK-dependent models replay step 6 with CST added, so they open on its tracks.
  const pairs = [['cstRIF1', 0, 'step06', 0], ['cstBOB1', 0, 'offBOB1', 0],
    ['cstEJSS', 0, 'step10', 0], ['cstEJPR', 0, 'step10', 0],
    ['cstPOLA', 0, 'step11', 5]];
  pairs.forEach(function (p) {
    ok(p[0] + ' declares the tracks of ' + p[2] + ' frame ' + p[3],
      trackClasses(p[0], p[1]) === trackClasses(p[2], p[3]));
  });
  ok('the two DDK-dependent models declare the tracks of step06',
    trackClasses('cstCONF', 0) === trackClasses('step06', 0)
      && trackClasses('cstCDC7', 0) === trackClasses('step06', 0));
  win.selectStep('step01');
}

// -- the chromosome rule ----------------------------------------------------
//
// src/chrom-rule.js is the single source of truth for the chromosome tab, and
// the page runs it live. These checks run it with fixed seeds: the programs
// the non-random genotypes exist to show, the invariants over many seeds of
// every genotype, the bob1 phenotypes the switching times were tuned to, and
// that a seed replays its run exactly.
{
  const R = win.CHROM_RULE;
  ok('CHROM_RULE is in dist/', !!R && typeof R.simulate === 'function');
  if (R) {
    function near(a, b) { return a !== null && Math.abs(a - b) < 0.01; }
    const geomOrigins = (win.CHROM_GEOM && win.CHROM_GEOM.origins || []).map(function (o) {
      return o.name + ':' + o.position + ':' + o.recruiter;
    }).join();
    ok('the rule and the drawn panel name the same origins',
      geomOrigins === R.RULE.origins.map(function (o) {
        return o.name + ':' + o.position + ':' + o.recruiter;
      }).join(), geomOrigins);
    const want = {
      'wt': { L3: ['fired', 23.605], R3: ['passive', 23.146], end: 37.146 },
      'dbf4-1': { L3: ['passive', 33.382], R3: ['passive', 26.882], end: 40.882 }
    };
    Object.keys(want).forEach(function (k) {
      const s = R.simulate(k, false, 1), w = want[k];
      ['L3', 'R3'].forEach(function (o) {
        ok(k + ': ' + o + ' is ' + w[o][0] + ' at ' + w[o][1].toFixed(2) + ' min',
          s.origins[o].fate === w[o][0] && near(s.origins[o].time, w[o][1]),
          s.origins[o].fate + ' at ' + s.origins[o].time);
      });
      ok(k + ': S ends at ' + w.end.toFixed(2) + ' min', near(s.sEnd, w.end), s.sEnd);
    });
    const wt = R.simulate('wt', false, 1);
    ok('wild type: the Ctf19 pair fires first, then the Fkh1/2 pair, R3 passive, then L3',
      wt.origins.L1.time === 0 && wt.origins.R1.time === 0 && near(wt.origins.L2.time, 9.646)
        && near(wt.origins.R2.time, 9.646) && wt.origins.R3.fate === 'passive'
        && wt.origins.L3.time > wt.origins.R3.time);
    ok('the dbf4 deletion without bob1 cannot fire any origin',
      R.simulate('dbf4', false, 1).viable === false);
    const combos = [];
    R.GENOTYPES.forEach(function (g) {
      [false, true].forEach(function (b) { if (!g.needsBob1 || b) { combos.push([g.key, b]); } });
    });
    combos.forEach(function (c) {
      [null].concat(R.CHECKPOINTS.map(function (k) { return k.key; })).forEach(function (cp) {
        const bad = [];
        let seed;
        for (seed = 1; seed <= 20; seed += 1) {
          R.checkSchedule(R.simulate(c[0], c[1], seed * 7919,
            cp === null ? {} : { hu: true, checkpoint: cp })).forEach(function (m) {
            if (bad.length < 3) { bad.push('seed ' + seed * 7919 + ': ' + m); }
          });
        }
        ok(c[0] + (c[1] ? ' with bob1' : '') + (cp === null ? '' : ' in HU, ' + cp)
          + ': twenty seeds obey every invariant', !bad.length, bad.join('; '));
      });
    });
    const hu = {};
    R.CHECKPOINTS.forEach(function (k) { hu[k.key] = R.simulate('wt', false, 3, { hu: true, checkpoint: k.key }); });
    const late = function (s) { return ['L3', 'R3'].map(function (n) { return s.origins[n].fate; }).join(); };
    const collapsed = function (s) {
      return s.forks.filter(function (f) { return f.end && f.end.indexOf('collapsed') === 0; }).length;
    };
    const copied = function (s) {
      return s.forks.reduce(function (a, f) { return a + Math.abs(f.x1 - f.x0); }, 0);
    };
    ok('Rad53 never comes on without HU', R.simulate('wt', false, 1).rad53At === null);
    ok('HU, checkpoint intact: Rad53 comes on from the RPA signal after the Fkh1/2 pair fires',
      hu.wt.rad53At > hu.wt.origins.L2.time && hu.wt.rad53Forks === 8
        && hu.wt.signal.path.some(function (p) { return p[1] >= hu.wt.signal.threshold - 1e-6; }),
      hu.wt.rad53At + ' ' + hu.wt.rad53Forks);
    ok('HU, checkpoint intact: the early origins fire, Rad53 comes on, neither L3 nor R3 fires',
      hu.wt.rad53At !== null && hu.wt.origins.L2.fate === 'fired'
        && ['L3', 'R3'].every(function (n) { return hu.wt.origins[n].fate !== 'fired'; }), late(hu.wt));
    ok('HU, rad53-21: L3 and R3 fire and forks collapse',
      late(hu.rad53) === 'fired,fired' && collapsed(hu.rad53) > 0 && hu.rad53.rad53At === null,
      late(hu.rad53) + ' ' + collapsed(hu.rad53));
    ok('HU, dbf4-m25 sld3-38A: L3 and R3 fire while Rad53 is on',
      late(hu.sites) === 'fired,fired' && hu.sites.rad53At !== null, late(hu.sites));
    const hd = R.simulate('wt', false, 3, { hu: true, checkpoint: 'wt', alleles: { dun1: true } });
    ok('HU, dun1 deletion: L3 and R3 never fire and forks copy less than with Dun1',
      late(hd) === 'unfired,unfired' && copied(hd) < copied(hu.wt),
      copied(hd).toFixed(1) + ' vs ' + copied(hu.wt).toFixed(1));
    ok('without HU no fork collapses and nothing is resected',
      R.GENOTYPES.every(function (g) { return R.simulate(g.key, true, 5).collapses.length === 0; }));
    const a = R.simulate('dbf4', true, 66), b2 = R.simulate('dbf4', true, 66);
    ok('a seed replays its run exactly', JSON.stringify(a) === JSON.stringify(b2));
    let keep = 0, wtTotal = 0, bypassTotal = 0, passive = 0;
    const orders = new Set();
    for (let i = 1; i <= 200; i += 1) {
      const x = R.simulate('wt', true, i * 7919), y = R.simulate('dbf4', true, i * 7919);
      const first = x.events.filter(function (e) { return e.kind === 'fire'; }).slice(0, 2)
        .map(function (e) { return e.origin; }).sort().join();
      if (first === 'L1,R1') { keep += 1; }
      wtTotal += x.onsetFromG1S + x.sEnd;
      bypassTotal += y.onsetFromG1S + y.sEnd;
      passive += Object.keys(y.origins).filter(function (n) { return y.origins[n].fate === 'passive'; }).length;
      orders.add(y.events.filter(function (e) { return e.kind === 'fire'; })
        .map(function (e) { return e.origin; }).join());
    }
    const wtAlone = wt.onsetFromG1S + wt.sEnd;
    ok('bob1 alone keeps the Ctf19 pair firing first in most runs', keep / 200 > 0.55, String(keep / 200));
    ok('bob1 alone ends S within a fifth of wild type, on average',
      Math.abs(wtTotal / 200 - wtAlone) < 0.2 * wtAlone, (wtTotal / 200).toFixed(1));
    ok('bob1 dbf4 deletion takes at least half again as long as wild type, on average',
      bypassTotal / 200 > 1.5 * wtAlone, (bypassTotal / 200).toFixed(1));
    ok('bob1 dbf4 deletion copies at least two origins passively, on average',
      passive / 200 >= 2, (passive / 200).toFixed(2));
    ok('bob1 dbf4 deletion fires in many different orders', orders.size > 20, String(orders.size));

    // -- the spindle phenotypes of slides 2 to 6 -------------------------------
    // Each strain is run over 200 seeds in HU and scored where the papers score
    // it. The toy chromosome is held to the relations each slide argues, plus
    // rough levels; the exact shares are drawing values.
    const share = function (cp, al, ak, when) {
      let e = 0, i;
      for (i = 1; i <= 200; i += 1) {
        if (R.simulate('wt', false, i * 7919, { hu: true, checkpoint: cp, alleles: al, ak: ak })
          .spindle.score[when].extended) { e += 1; }
      }
      return e / 200;
    };
    const sp = {
      wt: share('wt', {}, 'none', 'at'), rad53: share('rad53', {}, 'none', 'at'),
      zn: share('rad53', { dbf4zn: true }, 'none', 'at'), mcm: share('rad53', { mcm: true }, 'none', 'at'),
      sites: share('sites', {}, 'none', 'at'), triple: share('sites', { dun1: true }, 'none', 'at'),
      ctf19: share('rad53', { ctf19: true }, 'none', 'at'),
      akv: share('rad53', {}, 'vector', 'at'), ako: share('rad53', {}, 'on', 'at'),
      early: share('rad53', {}, 'none', 'early'), late: share('rad53', {}, 'none', 'late'),
      exoE: share('rad53', { exo1: true }, 'none', 'early'), exoL: share('rad53', { exo1: true }, 'none', 'late'),
      ctf19wt: share('wt', { ctf19: true }, 'none', 'at'), znwt: share('wt', { dbf4zn: true }, 'none', 'at')
    };
    const pc = function (v) { return Math.round(100 * v) + '%'; };
    ok('slide 2: wild type keeps HU spindles short', sp.wt < 0.15, pc(sp.wt));
    ok('slide 2: rad53-21 extends HU spindles in a large share of cells', sp.rad53 >= 0.3 && sp.rad53 <= 0.7, pc(sp.rad53));
    ok('slide 3: dbf4-zn and mcm2-1 each cut rad53-21 extension below a third',
      sp.zn < sp.rad53 / 3 && sp.mcm < sp.rad53 / 3, pc(sp.zn) + ', ' + pc(sp.mcm));
    ok('slide 4: dbf4-m25 sld3-38A extends with Rad53 on, at least half the rad53-21 share',
      sp.sites > 2 * sp.wt && sp.sites >= 0.5 * sp.rad53, pc(sp.sites));
    ok('slide 4: adding dun1 deletion raises it further', sp.triple > sp.sites, pc(sp.triple));
    ok('slide 5: ctf19 deletion cuts rad53-21 extension below a third', sp.ctf19 < sp.rad53 / 3, pc(sp.ctf19));
    ok('slide 5: an active late kinetochore cuts extension below a third of its vector control',
      sp.ako < sp.akv / 3 && Math.abs(sp.akv - sp.rad53) < 0.05, pc(sp.ako) + ' vs ' + pc(sp.akv));
    ok('slide 6: rad53-21 extends about as often in small buds as in large ones',
      Math.abs(sp.early - sp.late) < 0.12, pc(sp.early) + ', ' + pc(sp.late));
    ok('slide 6: exo1 deletion delays extension: far less in small buds, most of it in large ones',
      sp.exoE < sp.early / 3 && sp.exoL >= 0.6 * sp.late, pc(sp.exoE) + ', ' + pc(sp.exoL));
    ok('ctf19 deletion and dbf4-zn alone keep HU spindles short', sp.ctf19wt < 0.1 && sp.znwt < 0.1,
      pc(sp.ctf19wt) + ', ' + pc(sp.znwt));
    const noHu = R.simulate('wt', false, 1);
    ok('without HU the spindle reaches anaphase length only after S ends',
      noHu.spindle.path.every(function (p) { return p[1] < 3 || p[0] >= noHu.sEnd - 1e-6; })
        && noHu.spindle.path[noHu.spindle.path.length - 1][1] >= 8);
    ok('every slide strain is a preset, and every preset obeys the invariants over twenty seeds',
      R.PRESETS.length === 12 && R.PRESETS.every(function (q) {
        let i, bad = 0;
        for (i = 1; i <= 20; i += 1) {
          bad += R.checkSchedule(R.simulate('wt', false, i * 7919,
            { hu: true, checkpoint: q.checkpoint, alleles: q.alleles, ak: q.ak })).length;
        }
        return bad === 0;
      }));
    const mr = R.medianRun(R.PRESETS[1], 101);
    const mrun = R.simulate('wt', false, mr.seed, { hu: true, checkpoint: 'rad53' });
    ok('a preset plays a run with the most common ending, its spindle near the median of those runs',
      mrun.outcome === mr.outcome && Math.abs(mrun.spindle.score.at.length - mr.median) <= 0.25,
      mr.outcome + ' ' + mr.length.toFixed(2) + ' vs median ' + mr.median.toFixed(2));
    const ends = function (cp) {
      const c = {};
      let i, s, stopOk = true;
      for (i = 1; i <= 100; i += 1) {
        s = R.simulate('wt', false, i * 7919, { hu: true, checkpoint: cp });
        c[s.outcome] = (c[s.outcome] || 0) + 1;
        if (s.outcome === 'premature' && Math.abs(s.sEnd - Math.min(R.RULE.huMax - s.onsetFromG1S,
          s.extStart + R.RULE.extendShow)) > 1e-6) { stopOk = false; }
        if (s.outcome === 'anaphase' && !s.complete) { stopOk = false; }
      }
      c.stopOk = stopOk;
      return c;
    };
    const ewt = ends('wt'), e53 = ends('rad53');
    ok('in HU most wild-type runs copy the whole chromosome and then enter anaphase',
      (ewt.anaphase || 0) >= 60 && ewt.stopOk, JSON.stringify(ewt));
    ok('in HU no rad53-21 run enters anaphase; about half end on premature extension, partly copied',
      !e53.anaphase && (e53.premature || 0) >= 30 && e53.stopOk, JSON.stringify(e53));
    ok('a kinetochore is lost only when resection from a collapsed fork reaches it',
      [1, 2, 3, 4, 5, 6, 7, 8].every(function (i) {
        const s = R.simulate('wt', false, i * 7919, { hu: true, checkpoint: 'rad53' });
        const c = s.anchors.sites[0];
        return c.lostAt === null || s.collapses.some(function (q) {
          const d = Math.abs(q.x - 120);
          return d <= s.anchors.reach + 1e-9 && Math.abs(q.t + d / s.anchors.rate - c.lostAt) < 1e-6;
        });
      }));
  }
}

// -- the live chromosome panel follows its run -----------------------------
//
// The page installs a run as ANIM.chrLIVE. These checks install known runs and
// read the rendered panel at the first and last frames.
{
  const key = 'chrLIVE';
  function fxState(root, id) {
    const el = root.querySelector('#' + id);
    return el ? ['gone', 'fading', 'arriving', 'present'].find(function (s) {
      return el.classList.contains(s);
    }) : null;
  }
  ok('the live panel has a frame table at load', frames(key).length > 10, String(frames(key).length));
  [['wt', false, 1], ['dbf4-1', false, 1], ['rif1', false, 2], ['dbf4', true, 66]].forEach(function (c) {
    win.CHROM_LIVE.genotype = c[0];
    win.CHROM_LIVE.bob1 = c[1];
    win.CHROM_LIVE.seed = c[2];
    win.runChromLive('replay');
    const s = win.CHROM_LIVE.sched, tag = key + ' ' + c[0] + (c[1] ? ' bob1' : '');
    win.selectStep(key);
    win.runAnimation('pause');
    win.runAnimation('goto', 0);
    let root = panel(key);
    const origins = Object.keys(s.origins);
    ok(tag + ' frame 0: every origin shows ORC alone, no fork',
      origins.every(function (n) {
        return fxState(root, 'fx-morc-' + n) === 'present'
          && fxState(root, 'fx-chrfork-' + n + '-left') === 'gone';
      }));
    // G2, the last frame before the sisters part: the origins still sit on the axis.
    const g2 = frames(key).map(function (f) { return f.phase; }).lastIndexOf('G2');
    win.runAnimation('goto', g2);
    root = panel(key);
    const passive = origins.filter(function (n) { return s.origins[n].fate === 'passive'; });
    ok(tag + ' G2: the passive ring marks exactly the passive origins',
      origins.every(function (n) {
        return (fxState(root, 'fx-pas-' + n) === 'present') === (passive.indexOf(n) >= 0);
      }), passive.join());
    ok(tag + ' G2: every origin shows ORC alone and spent',
      origins.every(function (n) { return fxState(root, 'fx-mspent-' + n) === 'present'; }));
    ok(tag + ' G2: the CEN is copied, so the sister kinetochore holds a microtubule from the other pole',
      fxState(root, 'fx-kt2-CEN') === 'present');
    win.runAnimation('goto', frames(key).length - 1);
    root = panel(key);
    const sisY = function (id) {
      const m = /translate\(\s*[-\d.]+[\s,]+(-?[\d.]+)/.exec(root.querySelector('#' + id).getAttribute('transform') || '');
      return m ? parseFloat(m[1]) : 0;
    };
    ok(tag + ' last frame: anaphase: the sisters part toward opposite poles, led by the centromere',
      fxState(root, 'fx-sisters') === 'present' && fxState(root, 'fx-dna') === 'gone'
        && sisY('actor-sis-t-24') < sisY('actor-sis-t-0') && sisY('actor-sis-t-0') < 0
        && sisY('actor-sis-b-24') > sisY('actor-sis-b-0') && sisY('actor-sis-b-0') > 0);
    ok(tag + ' last frame: the spindle reads anaphase length, in the normal colour',
      /anaphase/.test((root.querySelector('#txt-spl') || {}).textContent || '')
        && fxState(root, 'fx-spl-ext') === 'gone');
    const k = (840 - 40) / 240;
    const short = s.forks.filter(function (f) {
      const t = root.querySelector('#actor-copy-' + f.id).getAttribute('transform') || '';
      const m = /translate\(([-\d.]+)/.exec(t);
      return !m || Math.abs(parseFloat(m[1]) - (f.x1 - f.x0) * k) > 0.05;
    }).map(function (f) { return f.id; });
    ok(tag + ' last frame: every fork has copied its whole stretch', !short.length, short.join());
    ok(tag + ' last frame: both telomeres read as copied',
      fxState(root, 'fx-teldone-L') === 'present' && fxState(root, 'fx-teldone-R') === 'present');
    ok(tag + ' shows Rif1 at the telomeres exactly when Rif1 is present',
      (fxState(root, 'fx-rif1-L') === 'present') === (s.pools.rif1Captured > 0));
    ok(tag + ' fades exactly the inactive DDK copies',
      [1, 2, 3, 4, 5, 6, 7, 8, 9, 10].every(function (j) {
        return fxState(root, 'fx-ddk-' + j) === (j <= s.pools.ddkActive ? 'present' : 'fading');
      }));
    ok(tag + ' last frame: every copy is back in its reservoir',
      Array.prototype.slice.call(root.querySelectorAll('[id^="actor-ddk-"], [id^="actor-rif-"]'))
        .every(function (el) { return /translate\(0 0\)/.test(el.getAttribute('transform') || 'translate(0 0)'); }));
    ok(tag + ' last frame: the firing order is written', /^Firing order: /.test(
      (root.querySelector('#txt-order') || {}).textContent || ''));
    const inset = frames(key)[frames(key).length - 1].inset;
    ok(tag + ' every frame carries close-up states for the selected origin',
      frames(key).every(function (f) { return f.inset && f.inset.text['ci-title']; })
        && /L1/.test(inset.text['ci-title']));
    win.runChromLive('focus', 'L3');
    ok(tag + ' selecting L3 rebuilds the close-up for L3',
      /L3/.test(frames(key)[0].inset.text['ci-title'])
        && /L3/.test((doc.getElementById('ci-title') || {}).textContent || ''));
    win.runChromLive('focus', 'L1');
    const view = function (f) { return f.inset.view || {}; };
    const followed = frames(key).filter(function (f) { return view(f).kind === 'elong'; });
    ok(tag + ' once L1 fires the close-up carries its right fork on, moving while the fork does (or never, if L1 never fires)',
      s.origins.L1.fate !== 'fired' ? followed.length === 0
        : followed.length > 0 && followed.every(function (f) { return view(f).side === 'r'; })
          && followed.some(function (f) { return view(f).speed > 0 && view(f).u > 0; }));
    const slow = frames(key).filter(function (f) { return view(f).kind === 'step'; });
    ok(tag + ' the selected origin\'s firing plays steps 7 to 11 in the close-up, or nothing if it never fires',
      s.origins.L1.fate !== 'fired' ? slow.length === 0
        : slow.length >= 30 && view(slow[0]).key === 'step07' && view(slow[0]).frame === 0
          && view(slow[slow.length - 1]).key === 'step11', String(slow.length));
    ok(tag + ' step 11 rides the followed fork with its elongation panel under it, and the steps before it do not',
      slow.every(function (f) {
        return view(f).key === 'step11' ? view(f).track === 'right' && view(f).under === 'r'
          : !view(f).track && !view(f).under;
      }));
    // An origin a fork copies passively shows that fork passing through it.
    ok(tag + ' before the firing the close-up shows the origin panel, or the fork passing a passive origin',
      frames(key).slice(0, frames(key).indexOf(slow[0]) < 0 ? frames(key).length : frames(key).indexOf(slow[0]))
        .every(function (f) { return view(f).kind === 'origin' || (view(f).kind === 'passive' && s.origins.L1.fate === 'passive'); }));
    ok(tag + ' the fork\'s travel only grows',
      followed.every(function (f, i) { return i === 0 || view(f).u >= view(followed[i - 1]).u; }));
    const rf = s.forks.filter(function (f) { return f.id === 'L1-right'; })[0];
    const term = frames(key).filter(function (f) { return view(f).kind === 'term'; });
    const seq = term.filter(function (f) { return /model time paused/.test(f.inset.text['ci-line1']); });
    ok(tag + ' when the followed fork meets another, the close-up plays the termination, and only then',
      !rf || rf.end !== 'meet' ? term.length === 0
        : seq.length === 12 && !view(seq[0]).filled && view(seq[5]).filled && view(seq[8]).ubq
          && view(seq[10]).gone && view(seq[11]).gone
          && seq.every(function (f, i) { return i === 0 || view(f).pL >= view(seq[i - 1]).pL; }),
      String(seq.length));
    win.runChromLive('follow', 'origin');
    ok(tag + ' following the origin keeps the origin panel on every frame outside the firing, or the passing fork at a passive origin',
      frames(key).every(function (f) {
        return view(f).kind === 'origin' || (view(f).kind === 'step' && !view(f).track)
          || (view(f).kind === 'passive' && s.origins.L1.fate === 'passive');
      }));
    win.runChromLive('follow', 'right');
    ok(tag + ' miniatures carry no ids and no fit points',
      !root.querySelector('.mini [id]') && !root.querySelector('.mini .fitpt'));
  });
  // A slide strain: the median rad53-21 run, read at its last frame.
  win.runChromLive('preset', 's2-rad53');
  win.selectStep(key);
  win.runAnimation('pause');
  win.runAnimation('goto', frames(key).length - 1);
  {
    const root = panel(key), s = win.CHROM_LIVE.sched;
    const lost = s.anchors.lostAt !== null;
    ok('slide strain rad53-21: the run is in HU with Rad53 absent', s.hu && s.checkpoint === 'rad53');
    ok('slide strain rad53-21: the CEN kinetochore fades and its microtubule retracts exactly when it is lost',
      (fxState(root, 'fx-kt-CEN') === 'fading') === lost
        && /translate\(0 -/.test(root.querySelector('#actor-kmt-CEN').getAttribute('transform') || '') === lost);
    ok('slide strain rad53-21: every collapsed fork, and only those, shows its resection',
      s.forks.every(function (f) {
        return (fxState(root, 'fx-res-' + f.id) === 'present') === (f.collapsedAt !== null);
      }));
    ok('slide strain rad53-21: the spindle readout names the length the run ends on',
      /^spindle \d+\.\d \u00b5m/.test((root.querySelector('#txt-spl') || {}).textContent || ''));
    ok('slide strain rad53-21: the readout names the median run and the share extended',
      /typical run of 301/.test((doc.getElementById('chrseed') || {}).textContent || ''));
  }
  win.selectStep('step01');
}

// === 4. THE TELOMERE SIDE =================================================
// The telomere workflow ported in, the rule's telomere side, and the
// telomere view of the live panel.

{
  const R = win.CHROM_RULE, U = R.RULE;

  // The port: every telomere panel is mounted, owned by the telomere engine,
  // captioned, and on the fifth chart.
  const twKeys = win.TELOMERE_ORDER || [];
  ok('sixteen telomere panels, each mounted and captioned',
    twKeys.length === 16 && twKeys.every(function (k) { return panel(k) && win.META[k] && win.META[k].caption; }),
    twKeys.filter(function (k) { return !panel(k) || !win.META[k]; }).join());
  ok('the telomere engine owns every tw- key and no other',
    twKeys.every(function (k) { return win.TELO.owns(k); }) && !win.TELO.owns('step01') && !win.TELO.owns('chrLIVE'));
  ok('the telomere chart lists the sixteen panels',
    twKeys.every(function (k) { return doc.querySelector('#navsvg-telomere .navnode[data-key="' + k + '"]'); }));
  win.selectStep('tw-step06');
  win.runAnimation('goto', 3);
  const p6 = panel('tw-step06');
  ok('a telomere panel plays through the shared transport with its own engine',
    win.ANIM_STATE.key === 'tw-step06' && win.ANIM_STATE.frame === 3 && p6.querySelectorAll('.half.shown').length > 0,
    win.ANIM_STATE.key + ' f' + win.ANIM_STATE.frame);
  ok('the telomere engine derives the cap bar', !!p6.querySelector('#capbasest-cst')
    && /\S/.test(p6.querySelector('#capbasest-cst').textContent));
  // The rule: every run passes checkSchedule with the telomere checks.
  const conds = [['wt', {}], ['dbf4-1', {}], ['rif1', {}], ['wt', { alleles: { cdc13_2: true } }],
    ['wt', { alleles: { est2: true } }], ['dbf4-1', { alleles: { cdc13_2: true } }], ['wt', { hu: true }],
    ['wt', { hu: true, checkpoint: 'rad53' }], ['wt', { telomereBp: 125 }], ['wt', { telomereBp: { L: 60, R: 700 } }],
    ['wt', { oneOrigin: true }], ['wt', { oneOrigin: true, telomereBp: 125 }], ['rif1', { oneOrigin: true }],
    ['wt', { oneOrigin: true, alleles: { cdc13_2: true } }]];
  let bad = [];
  conds.forEach(function (c) {
    for (let k = 1; k <= 40; k += 1) {
      const s = R.simulate(c[0], false, k * 7919, c[1]);
      R.checkSchedule(s).forEach(function (b) { bad.push(c[0] + JSON.stringify(c[1]) + ' seed ' + k + ': ' + b); });
    }
  });
  ok('every telomere condition passes checkSchedule', !bad.length, bad.slice(0, 4).join(' | '));

  // Copying an end doubles its hold on Rif1: the free pool falls from 6 to 4 to 2.
  const w = R.simulate('wt', false, 1, {});
  const pools = w.segments.map(function (g) { return g.rifPool; });
  ok('wild type: the free Rif1 pool is 6, then 4, then 2 as the ends are copied',
    pools[0] === 6 && pools.indexOf(4) > 0 && w.telo['TEL-L'].daughters.length === 2
      && w.telo['TEL-R'].daughters.every(function (d) { return d.rif === 2; }), pools.join());
  ok('sister 1 carries the leading-made left end and the lagging-made right end',
    w.telo['TEL-L'].daughters[0].strand === 'leading' && w.telo['TEL-R'].daughters[0].strand === 'lagging');
  ok('anaphase comes RULE.g2 min after S ends', Math.abs(w.anaphaseAt - w.sEnd - U.g2) < 1e-6);

  // Telomerase reaches ends at the shares Teixeira et al. report, which
  // the rule is solved for, and not at all without recruitment.
  const share = function (g, o, n) {
    let e = 0, t = 0;
    for (let k = 1; k <= n; k += 1) {
      const s = R.simulate(g, false, k * 7919, o);
      ['TEL-L', 'TEL-R'].forEach(function (tel) { s.telo[tel].daughters.forEach(function (d) { t += 1; if (d.extended) { e += 1; } }); });
    }
    return e / t;
  };
  const s300 = share('wt', { telomereBp: 303 }, 800), s125 = share('wt', { telomereBp: 128 }, 800);
  ok('ends of 300 bp are extended in 5 to 9% of cycles', s300 > 0.05 && s300 < 0.09, s300.toFixed(3));
  ok('ends of 125 bp are extended in 33 to 43% of cycles', s125 > 0.33 && s125 < 0.43, s125.toFixed(3));
  ok('rif1 deletion extends wild-type ends more often', share('rif1', {}, 400) > share('wt', {}, 400));
  ok('cdc13-2 and est2 deletion extend no end',
    share('wt', { alleles: { cdc13_2: true } }, 100) === 0 && share('wt', { alleles: { est2: true } }, 100) === 0);

  // A shorter left end leaves its nearby origin less Rif1, so L3 fires
  // earlier (Bianchi and Shore 2007), with nothing in the rule written for it.
  const meanL3 = function (L) {
    let sum = 0, n = 0;
    for (let k = 1; k <= 200; k += 1) {
      const o = R.simulate('wt', false, k * 7919, { telomereBp: { L: L, R: 325 } }).origins.L3;
      if (o.fate === 'fired') { sum += o.time; n += 1; }
    }
    return n ? sum / n : Infinity;
  };
  ok('a short left end fires L3 earlier', meanL3(125) < meanL3(325) - 1, meanL3(125).toFixed(2) + ' vs ' + meanL3(325).toFixed(2));

  // The telomere view: a one-origin chromosome. Frames carry it, the close-up follows an end.
  const w1 = R.simulate('wt', false, 1, { oneOrigin: true });
  const G = win.CHROM_GEOM.tel;
  ok('the one-origin chromosome is drawn with the rule\'s arms',
    G.arms[0] === U.oneOrigin.leftKb && G.arms[1] === U.oneOrigin.rightKb, G.arms.join());
  ok('the one-origin run copies both ends at one moment, then anaphase RULE.g2 min after',
    Math.abs(w1.telomeres['TEL-R'].t - w1.telomeres['TEL-L'].t) < 1e-9 && Math.abs(w1.anaphaseAt - w1.sEnd - U.g2) < 1e-6);
  // Two close-ups of one run, each following one end, keep one clock: the
  // frames sample both ends' steps whichever end is the focus.
  const ta = win.buildChromFrames(w1, win.CHROM_GEOM, 'tel-R-s1', 'right', [], null, ['tel-R-s2']).frames;
  const tb = win.buildChromFrames(w1, win.CHROM_GEOM, 'tel-R-s2', 'right', [], null, ['tel-R-s1']).frames;
  ok('two ends of one run, followed side by side, share every moment',
    ta.length === tb.length && ta.every(function (f, i) { return f.phase === tb[i].phase && f.clock === tb[i].clock; }));
  const fr = win.buildChromFrames(w1, win.CHROM_GEOM, 'tel-R-s2', 'right', [], null).frames;
  const g1 = fr.find(function (f) { return f.phase === 'lateG1'; });
  const g2 = fr.find(function (f) { return f.phase === 'G2'; });
  const last = fr[fr.length - 1];
  ok('before firing, the origin is shut: no bubble, the parental duplex whole',
    g1.fx['fx-tvori'] === 'present' && g1.fx['fx-tvsis'] === 'gone'
      && g1.actors['actor-tvparclip-l'][0] === 0 && g1.actors['actor-tvparclip-r'][0] === 0
      && g1.actors['actor-tvbubclip-l'][0] === -g1.actors['actor-tvbubclip-r'][0] && g1.actors['actor-tvbubclip-l'][0] > 0);
  ok('after both tips, the forks are gone and the bubble covers both ends',
    last.fx['fx-tvfork-L'] === 'gone' && last.fx['fx-tvfork-R'] === 'gone'
      && last.actors['actor-tvbubclip-l'][0] < G.jl - G.ori - G.maxBp * G.s
      && last.actors['actor-tvbubclip-r'][0] > G.jr - G.ori + G.maxBp * G.s);
  let back = 0, prevL = 0, prevR = 0;
  fr.forEach(function (f) {
    const l = f.actors['actor-tvfork-L'][0], r = f.actors['actor-tvfork-R'][0];
    if (l > prevL + 1e-6 || r < prevR - 1e-6) { back += 1; }
    prevL = l; prevR = r;
  });
  ok('each fork only moves outward', !back, back + ' steps back');
  ok('the free Rif1 glyphs in the telomere view match the pool: 6, then 2 with four daughters',
    g1.fx['fx-tvfree-6'] === 'present' && g1.fx['fx-tvfree-7'] === 'gone'
      && g2.fx['fx-tvfree-2'] === 'present' && g2.fx['fx-tvfree-3'] === 'gone');
  ok('the close-up of an end plays a telomere workflow panel',
    fr.every(function (f) { return f.inset.view.kind === 'tw' && win.TELO.owns(f.inset.view.key); }));
  // Following an end, the close-up plays every frame of each step's telomere
  // workflow panel in order, as the origin close-up plays the step panels.
  const sh = R.simulate('wt', false, 1, { telomereBp: 125, oneOrigin: true });
  const fs2 = win.buildChromFrames(sh, win.CHROM_GEOM, 'tel-R-s1', 'right', [], null).frames;
  const seen = {}, order = [];
  fs2.forEach(function (f) {
    const v = f.inset.view, n = win.TELO.frameTotal(v.key), k = Math.min(n - 1, Math.round(v.progress * n));
    if (!seen[v.key]) { seen[v.key] = { n: n, got: {} }; order.push(v.key); }
    seen[v.key].got[k] = true;
  });
  const gaps = order.filter(function (k) {
    if (k === 'tw-step09') { return false; }
    for (let j = 0; j < seen[k].n; j += 1) { if (!seen[k].got[j]) { return true; } }
    return false;
  });
  ok('the close-up of an end plays every frame of each step panel', !gaps.length, gaps.join());
  ok('G2 is sampled between S and anaphase',
    fr.filter(function (f) { return f.phase === 'G2'; }).length >= 3);
  // Semiconservative: sister 1 keeps the parental top strand, sister 2 the bottom.
  const lay = panel('chrLIVE').querySelector('.tvlayer');
  const ages = Array.prototype.map.call(lay.querySelectorAll('g[clip-path="url(#cp-tvbubr)"] > rect.tvstr.I'),
    function (r) { return /\bold\b/.test(r.getAttribute('class')) ? 'old' : 'new'; }).join();
  ok('each sister keeps one parental strand: sister 1 old over new, sister 2 new over old', ages === 'old,new,new,old', ages);
  win.selectStep('chrLIVE');
  win.runChromLive('view', 'tel');
  const live = panel('chrLIVE');
  ok('the view switch shows the telomere layer', live.getAttribute('data-view') === 'tel');
  win.runChromLive('view', 'chrom');
  ok('and back', live.getAttribute('data-view') === 'chrom');
}

// === LINEAGES =============================================================

{
  const CR = win.CHROM_RULE;
  const st = CR.lineageStats({ cdc13_2: true }, 120);
  const at = st.map(function (x) { return x.at; }).filter(function (v) { return v !== null; }).sort(function (a, b) { return a - b; });
  const med = at[Math.floor(at.length / 2)];
  ok('cdc13-2 lineages lose a cap near division 37 (Xu 2015), median within 30-46', med >= 30 && med <= 46, 'median ' + med);
  const bp = st.map(function (x) { return x.bp; }).filter(function (v) { return v !== null; }).sort(function (a, b) { return a - b; });
  ok('the length at cap loss spreads over a range, not one value', bp[Math.floor(bp.length * 0.9)] - bp[Math.floor(bp.length * 0.1)] >= 30,
    bp[Math.floor(bp.length * 0.1)] + '-' + bp[Math.floor(bp.length * 0.9)]);
  const a = CR.lineage(3, { alleles: { cdc13_2: true } }), b = CR.lineage(3, { alleles: { cdc13_2: true } });
  ok('a lineage is deterministic for its seed', JSON.stringify(a.summary) === JSON.stringify(b.summary));
  const r53 = CR.lineage(3, { alleles: { cdc13_1: true, rad53_21: true }, max: 16 });
  ok('rad53-21 lineages never arrest', !r53.pages.some(function (p) { return p.state === 'arrested'; }) && r53.summary.death === 'geneloss', r53.summary.death);
  const c1 = CR.lineage(3, { alleles: { cdc13_1: true }, max: 16 });
  ok('cdc13-1 loses both caps in the first division', c1.summary.capLostAt === 1 && !c1.pages[1].L.capped && !c1.pages[1].R.capped, JSON.stringify(c1.summary));
  const c5 = CR.lineage(3, { alleles: { cdc13_5: true }, max: 120 }), w5 = CR.lineage(3, { alleles: {}, max: 120 });
  const late = function (r) { let t = 0, n = 0; r.pages.forEach(function (p) { if (p.g >= 60) { t += p.L.bp + p.R.bp; n += 2; } }); return t / n; };
  ok('cdc13-5 ends settle 500 to 1000 bp longer than wild type (Chandra 2001)', late(c5) - late(w5) >= 500 && late(c5) - late(w5) <= 1000,
    Math.round(late(c5) - late(w5)) + ' bp');
  ok('cdc13-5 ends keep their caps', c5.summary.capLostAt === null);
  const ad = CR.lineage(2, { alleles: { cdc13_2: true } });
  ok('seed 2 adapts and dies by gene loss', ad.summary.adaptedAt !== null && ad.summary.death !== 'arrest', JSON.stringify(ad.summary));
  const wt = CR.lineageStats({}, 40).filter(function (x) { return x.at !== null; }).length;
  ok('wild-type lineages rarely lose a cap within the run', wt <= 10, wt + ' of 40');
}

// === REPORT ===============================================================

if (failures.length) {
  console.log(failures.map(function (f) { return 'FAIL  ' + f; }).join('\n'));
}
console.log(passed + ' passed, ' + failures.length + ' failed');
process.exit(failures.length ? 1 : 0);
}