// Screenshot every slide of the built tour for the slide list's hover
// previews, and write them to tools/tour/thumbs.json, which make_tour.py
// embeds. Each preview is the slide's visual column a few seconds after the
// slide opens, at half scale, as a JPEG. The file records each slide's title,
// so the tour shows a preview only while the slide it was taken from is
// still the slide at that place.
//
//   python3 tools/make_tour.py && node tools/make_thumbs.js && python3 tools/make_tour.py
const path = require('path');
const fs = require('fs');
const { chromium } = require('playwright');

const ROOT = path.dirname(__dirname);
const TOUR = path.join(ROOT, 'dist', 'origins-and-telomeres-tour.html');
const OUT = path.join(ROOT, 'tools', 'tour', 'thumbs.json');
const WAIT = 2600, MAX_H = 760;

(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1500, height: 1000 }, deviceScaleFactor: 0.5 });
  await page.goto('file://' + TOUR);
  await page.waitForTimeout(1500);
  const titles = await page.evaluate(() => TOUR.lesson.beats.map((b) => b.title));
  const images = [];
  for (let i = 0; i < titles.length; i += 1) {
    await page.evaluate((k) => runTour('go', k), i);
    await page.waitForTimeout(WAIT);
    const box = await page.evaluate(() => {
      const r = document.querySelector('#tour .tvis').getBoundingClientRect();
      return { x: r.left, y: r.top, width: r.width, height: r.height };
    });
    box.height = Math.min(box.height, MAX_H);
    const buf = await page.screenshot({ type: 'jpeg', quality: 62, clip: box });
    images.push('data:image/jpeg;base64,' + buf.toString('base64'));
    process.stdout.write('.');
  }
  fs.writeFileSync(OUT, JSON.stringify({ titles: titles, images: images }));
  console.log('\nwrote ' + images.length + ' previews, ' + Math.round(fs.statSync(OUT).size / 1024) + ' KB');
  await browser.close();
})();
