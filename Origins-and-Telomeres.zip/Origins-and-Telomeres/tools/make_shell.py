#!/usr/bin/env python3
"""Emit src/index.html.

KEYS must equal PANEL_ORDER in src/data.js in content and order, and SCRIPTS
must equal SCRIPTS in build.py in content and order. Both are contract rows in
handbook section 4 and both are asserted by the test suite.

The navigation carries five charts, one per page, and a row of five tabs
that switches between them: the main line, the context panels, the firing
models for CST, the whole-chromosome view, and the telomere workflow, which
tools/port_telomere.js brings in from telomere/. PAGES names them in tab order
and is the one place the order is set.

Every file is read and written as UTF-8, as build.py does, so the shell does
not depend on the platform's default codec (cp1252 on Windows). A chart label
carrying a Greek letter or a superscript would otherwise be mangled there.
"""

import os

KEYS = ['step01', 'step02', 'step03', 'step04', 'step05', 'step06',
        'step07', 'step08', 'step09', 'step10', 'step11',
        'ctxARS', 'ctxORC', 'ctxMCM', 'ctxDH', 'ctxCHROM',
        'regCDK', 'regCDC6', 'regMCM', 'regCDT1', 'regRIF1',
        'altDH01', 'altDH02',
        'offQC', 'offATP', 'offCDT1N', 'offDDK', 'offMCM4N', 'offPHOS', 'offBOB1',
        'cstDDK', 'cstCONF', 'cstCDC7', 'cstRIF1',
        'cstBOB1', 'cstDOWN', 'cstEJSS', 'cstEJPR', 'cstPOLA',
        'chrLIVE',
        'tw-step01', 'tw-lag01', 'tw-step02', 'tw-step03', 'tw-lag03', 'tw-step04',
        'tw-step05', 'tw-step06', 'tw-step07', 'tw-step08', 'tw-step09',
        'tw-offA', 'tw-offB', 'tw-offC', 'tw-offD', 'tw-offE']

SCRIPTS = ['data.js', 'anim-data.js', 'telo-engine.js', 'chrom-geom.js', 'chrom-rule.js', 'chrom-frames.js',
           'cite.js', 'animate.js', 'controls.js', 'controller.js', 'chrom-live.js']

# (page, tab label, chart file), in tab order. The first page is the one
# shown at load.
PAGES = [('steps', 'Steps', 'nav-steps.svg'),
         ('context', 'Additional context', 'nav-context.svg'),
         ('models', 'Firing models for CST', 'nav-models.svg'),
         ('chromosome', 'Chromosome', 'nav-chromosome.svg'),
         ('telomere', 'Telomere', 'nav-telomere.svg')]

ENCODING = 'utf-8'

TITLE = 'Origins and telomeres in Saccharomyces cerevisiae'
STANDFIRST = ('Origin specification through bidirectional fork formation. Eleven '
              'steps on the main line, with legends, regulation, two accounts of '
              'the second load and seven perturbations on a second chart. Shape '
              'carries function: where two proteins bind, the outline of one is '
              'cut to receive the other. Content follows Parker, Botchan and '
              'Berger (2017), the work it cites, and later structural and in vivo '
              'work named in the captions. The third chart is different in kind: '
              'it draws the firing models for CST that this dissertation proposes, '
              'set on the steps they would act at, and none of them is an '
              'established mechanism. The chromosome chart runs the model: six '
              'origins and two telomeres, which origins and telomeres share Rif1 '
              'across. The fifth chart is the telomere workflow, one end from its '
              'copying to its cap.')


def shell(charts):
    """VIEW: the page markup, given each chart's markup by page name (TERMINAL)"""
    scripts = '\n  '.join('<script src="%s"></script>' % s for s in SCRIPTS)
    tabs = '\n      '.join(
        '<button class="navtab%s" type="button" role="tab" data-page="%s" '
        'aria-selected="%s">%s</button>'
        % (' active' if n == 0 else '', page, 'true' if n == 0 else 'false', label)
        for n, (page, label, _) in enumerate(PAGES))
    pages = '\n    '.join(
        '<div class="navpage%s" data-page="%s" role="tabpanel">%s</div>'
        % (' active' if n == 0 else '', page, charts[page])
        for n, (page, _, _) in enumerate(PAGES))
    return '''<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>%s</title>
<link rel="stylesheet" href="style.css">
<link rel="stylesheet" href="telo-style.css">
</head>
<body>
<div id="app">
  <header class="fig">
    <h1>%s</h1>
    <p>%s</p>
    <p id="loaderror" class="loaderror" hidden></p>
  </header>

  <div id="navwrap">
    <div id="navtabs" role="tablist" aria-label="Charts">
      %s
    </div>
    %s
  </div>

  <div id="stagewrap">
    <h2 id="steptitle"></h2>
    <div id="stage"></div>

    <div id="chrcontrols" hidden>
      <span id="chrview" class="chrfollow" role="group" aria-label="view">View
        <button type="button" data-view="chrom" class="on">Chromosome</button>
        <button type="button" data-view="tel">Telomeres</button></span>
      <label>Slide strain <select id="chrpreset" aria-label="slide strain"></select></label>
      <label>Genotype <select id="chrgeno" aria-label="genotype"></select></label>
      <label><input id="chrbob1" type="checkbox"> mcm5-bob1</label>
      <label>Checkpoint <select id="chrcheck" aria-label="checkpoint allele"></select></label>
      <label><input id="chrhu" type="checkbox"> hydroxyurea</label>
      <span id="chralleles"></span>
      <label>Kinetochore site <select id="chrak" aria-label="artificial kinetochore"></select></label>
      <label>Telomere length <input id="chrtelbp" type="number" min="0" max="1000" step="1"
        placeholder="325" aria-label="telomere length in bp" style="width:5em"> bp</label>
      <button id="chrnew" type="button">New run</button>
      <button id="chrreplay" type="button">Replay this run</button>
      <span id="chrseed"></span>
    </div>

    <div id="transport" class="disarmed" data-playing="no">
      <button id="playbtn" type="button">Play</button>
      <button id="backbtn" type="button">Back</button>
      <button id="fwdbtn" type="button">Forward</button>
      <button id="resetbtn" type="button">Reset</button>
      <input id="scrub" type="range" min="0" max="0" value="0" aria-label="frame">
      <span id="framecount">static panel</span>
    </div>

    <div id="caption">
      <p id="captiontext"></p>
      <ol id="refs"></ol>
      <details id="notewrap" hidden>
        <summary>Drawing note</summary>
        <div id="note"></div>
      </details>
    </div>
  </div>
</div>
  %s
</body>
</html>
''' % (TITLE, TITLE, STANDFIRST, tabs, pages, scripts)


def main():
    """CONTROLLER: read the four charts, compose the page, write it."""

    # === MODEL AND VIEW ===

    def read_charts(root):
        """MODEL: each chart's markup by page name (TERMINAL)"""
        charts = {}
        for page, _, name in PAGES:
            with open(os.path.join(root, 'src', name), encoding=ENCODING) as f:
                charts[page] = f.read()
        # The origin close-up sits under the chromosome chart.
        with open(os.path.join(root, 'src', 'chrom-inset.svg'), encoding=ENCODING) as f:
            charts['chromosome'] += ('<div id="chrinsetwrap" data-view="chrom"><p class="chrinsethint chronly">'
                                     'Click an origin on the chromosome to show it here. Once it fires, '
                                     'the camera follows a fork.</p><p class="chrinsethint tvonly">Click '
                                     'an end in the telomere view to show it here: the telomere '
                                     'workflow panel of the step it is at.</p>'
                                     '<div id="chrfollow" class="chrfollow chronly">'
                                     '<button type="button" data-follow="origin">origin</button>'
                                     '<button type="button" data-follow="left">left fork</button>'
                                     '<button type="button" data-follow="right" class="on">right fork'
                                     '</button><button type="button" data-follow="cen">centromere</button>'
                                     '</div>%s</div>' % f.read())
        return charts

    def write_page(root, html):
        """VIEW: write src/index.html and report it (TERMINAL)"""
        with open(os.path.join(root, 'src', 'index.html'), 'w', encoding=ENCODING) as f:
            f.write(html)
        print('wrote src/index.html with %d panel keys and %d charts'
              % (len(KEYS), len(PAGES)))

    # === COORDINATE ===

    here = os.path.dirname(os.path.abspath(__file__))
    root = os.path.dirname(here)
    charts = read_charts(root)
    write_page(root, shell(charts))


if __name__ == '__main__':
    main()
