#!/usr/bin/env python3
"""Regenerate the panels and the shell, then inline src/ into one
distributable HTML file.

    python3 build.py                 the whole pipeline
    python3 build.py --inline-only   inline src/ as it stands

The pipeline runs in the order the README requires: tools/port_telomere.js
brings the telomere workflow in from telomere/, tools/make_panels.py
writes the panels, the four charts and src/chrom-geom.js, tools/make_shell.py
inlines the charts into src/index.html, and this script inlines everything into
dist/. The chromosome tab computes its runs in the page (src/chrom-rule.js), so
no generator computes a schedule. Each
generator runs in its own interpreter, so it fails the build exactly as it
fails on its own, layout guard and audits included. --inline-only skips the
two generators, for a build from src/ files that are already current.

dist/origins-and-telomeres.html is overwritten on every build and is never
hand-edited. SCRIPTS must equal SCRIPTS in tools/make_shell.py in content and
order, or dist/ keeps script tags pointing at files that are not beside it.

Every file is read and written as UTF-8 so the build does not depend on the
platform's default codec (cp1252 on Windows).
"""

import json
import os
import re
import subprocess
import sys

SCRIPTS = ['data.js', 'anim-data.js', 'telo-engine.js', 'chrom-geom.js', 'chrom-rule.js', 'chrom-frames.js',
           'cite.js', 'animate.js', 'controls.js', 'controller.js', 'chrom-live.js']

OUTPUT = 'origins-and-telomeres.html'

ENCODING = 'utf-8'


GENERATORS = [os.path.join('tools', 'port_telomere.js'),
              os.path.join('tools', 'make_panels.py'),
              os.path.join('tools', 'make_shell.py')]


def regenerate(root):
    """Run the generators in order, stopping on the first failure."""
    for script in GENERATORS:
        runner = 'node' if script.endswith('.js') else sys.executable
        done = subprocess.run([runner, os.path.join(root, script)], cwd=root)
        if done.returncode != 0:
            sys.exit('%s failed; dist/ was not rebuilt' % script)


def main():
    root = os.path.dirname(os.path.abspath(__file__))
    if '--inline-only' not in sys.argv[1:]:
        regenerate(root)
    src = os.path.join(root, 'src')
    with open(os.path.join(src, 'index.html'), encoding=ENCODING) as f:
        html = f.read()

    with open(os.path.join(src, 'style.css'), encoding=ENCODING) as f:
        css = f.read()
    with open(os.path.join(src, 'telo-style.css'), encoding=ENCODING) as f:
        css += '\n' + f.read()
    html = html.replace('<link rel="stylesheet" href="telo-style.css">\n', '')
    html = html.replace('<link rel="stylesheet" href="style.css">',
                        '<style>\n%s\n</style>' % css)

    panels = {}
    for name in sorted(os.listdir(os.path.join(src, 'panels'))):
        if name.endswith('.svg'):
            with open(os.path.join(src, 'panels', name),
                      encoding=ENCODING) as f:
                panels[name[:-4]] = f.read()
    # The telomere panels, which tools/port_telomere.js writes with their tw- keys.
    for name in sorted(os.listdir(os.path.join(src, 'tw-panels'))):
        if name.endswith('.svg'):
            with open(os.path.join(src, 'tw-panels', name), encoding=ENCODING) as f:
                panels[name[:-4]] = f.read()
    with open(os.path.join(src, 'refs.bib'), encoding=ENCODING) as f:
        bib = f.read()
    with open(os.path.join(src, 'telo-refs.bib'), encoding=ENCODING) as f:
        bib += '\n' + f.read()

    body = ['<script>',
            'var INLINE_PANELS = %s;' % json.dumps(panels),
            'var INLINE_BIB = %s;' % json.dumps(bib),
            'window.INLINE_PANELS = INLINE_PANELS;',
            'window.INLINE_BIB = INLINE_BIB;',
            '</script>']
    for name in SCRIPTS:
        with open(os.path.join(src, name), encoding=ENCODING) as f:
            body.append('<script>\n%s\n</script>' % f.read())
    for name in SCRIPTS:
        html = html.replace('<script src="%s"></script>' % name, '')
    html = re.sub(r'\n\s*\n\s*</body>', '\n</body>', html)
    html = html.replace('</body>', '\n'.join(body) + '\n</body>')

    dist = os.path.join(root, 'dist')
    os.makedirs(dist, exist_ok=True)
    with open(os.path.join(dist, OUTPUT), 'w', encoding=ENCODING) as f:
        f.write(html)
    print('wrote dist/%s (%d panels inlined)' % (OUTPUT, len(panels)))


if __name__ == '__main__':
    main()