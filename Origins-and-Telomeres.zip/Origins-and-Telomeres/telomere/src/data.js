/* Panel metadata. One entry per node in the workflow.

   Two tracks in the resection region. step01 to step03 are the leading-strand
   end and lag01 to lag03 are the lagging-strand end; both are produced by one
   fork passage, and both converge on step04. lag02 does not exist, and the gap
   is the claim: that end needs no incision.

   Every long string is a String.raw template literal, and that is load-bearing
   rather than a style choice. In an ordinary JS string "\cite{x}" evaluates to
   "cite{x}", because \c is not a recognised escape and JavaScript drops the
   backslash without complaint. String.raw keeps it, so a caption can be pasted
   out of a word processor exactly as written for the dissertation. The cost is
   that a caption can never contain a real escape sequence, a backtick, or the
   two characters ${; none of those belong in prose.

   caption: the text shown under the panel. \cite{key} and \cite{keyA, keyB}
   resolve against src/refs.bib at load time. Nothing here needs to know what
   number a reference will get.

   note: the drawing rationale, why this panel is drawn the way it is rather
   than what it depicts. Optional, shown behind a disclosure, and kept separate
   so the caption can stay free of commentary about the figure itself.

   There is no refs field. It used to list the BibTeX keys backing a caption
   and nothing read it; the keys are now in the prose, so a second copy could
   only ever disagree with the first.
*/

const META = {

  step01: {
    num:        "1",
    title:      "Leading-strand synthesis: blunt terminus",
    phase:      "resection",
    phaseLabel: "Leading-strand end",
    caption:    String.raw`Gross telomere structure involves a stretch of telomeric repeats characterized by a G rich array ending in 3' OH at the chromosomal end, and a C rich tract ending in a 5' end. The two ends of a chromosome are built by different halves of the replication fork and terminate differently \cite{parenteau2002differential}. Telomere elongation overall is restricted to the S/G2 phase of the cell cycle, when Clb-Cdk1 activity is high \cite{bonetti2014telomere}.

Leading-strand synthesis via Pol ε copies the parental C-rich strand to the chromosome terminus \cite{pospiech2003dna}, producing a blunt or nearly blunt end \cite{nelson2012blunt, wu2012telomeric}. Telomere elongation first requires resection of blunt ended chromosomes to produce the 3' G rich overhang \cite{wellinger1996evidence, dionne1998processing} that lagging strand elongation produces as a result of the End Replication problem \cite{lingner1995telomerase, levy1992telomere}.

Rap1 occupies the duplex repeat array at roughly one molecule per 18 bp \cite{conrad1990rap1}, with its C-terminal domain recruiting Rif1 proximally and Rif2 distally \cite{shi2013rif1}. At full telomere length, Rif2 occupancy is maximal, limiting MRX residence at the junction and excluding Tel1 \cite{roisne2021mechanism}. Rap1 acting with Rif2 suppresses non homologous end joining at the telomere \cite{marcand2008multiple}.

Ku is a core end joining factor \cite{boulton1996identification} that binds duplex termini \cite{kazda2012chromosome} and protects against nucleolytic degradation \cite{gravel1998yeast} by restraining Exo1 access to the terminus \cite{mimitou2010ku, bertuch2004exo1}. In S. cerevisiae, the lack of Ku increases the amount of telomeric ssDNA overhangs, but only in the G1 phase of the cell cycle \cite{bonetti2010shelterin, vodenicharov2010telomere}.

The SIR complex assembles on Rap1 and promotes transcriptional silencing of regions proximal to the telomeric repeats \cite{gartenberg2016nuts}.

The telomeric cap is the occupancy of both telomeric substrates by telomere-specific proteins. At this end the duplex array carries Rap1 \cite{conrad1990rap1} and Ku sits at the terminus \cite{gravel1998yeast}. Cdc13 is absent, since its substrate is single-stranded TG1-3 \cite{lin1996saccharomyces} and no such tract exists here.`,
    note:       String.raw`Resection initially appears to undo the work of leading-strand synthesis, since leading-strand replication reaches the chromosome terminus and avoids the conventional end-replication problem. The resulting overhang is nevertheless required for capping. Cdc13 binds single-stranded TG1-3 DNA, whereas a blunt terminus provides no CST substrate. Resection therefore converts the blunt leading-strand product into the structure required for capping, and telomerase gains access to the chromosome end through the same exposed G strand. Capping must occur at every chromosome end, regardless of whether that end undergoes telomerase extension.

Resection removes C-strand DNA without removing sequence from the newly synthesized G strand. Leading-strand synthesis copies the parental C strand to its 5' terminus, and resection subsequently removes C-strand DNA. The sequence exposed by resection remains on the G strand as single-stranded DNA and is restored to duplex DNA by fill-in at step 8.

The panel does not draw a primer because leading-strand synthesis is initiated once at the subtelomeric origin from which the fork entered the region. That origin lies beyond the unique sequence and outside the left edge of the frame. Primer removal and gap filling occur at that origin, outside the region shown. Drawing a primer within the unique sequence would instead imply an origin at that position and incorrectly suggest that the newly synthesized G strand begins there.

Rap1 binds as each pair of telomeric repeats becomes duplex. Ku and MRX appear only in the final frame, after a chromosome end has formed. At full telomere length, Rif2 occupancy is maximal, limiting MRX residence at the junction and excluding Tel1.`
  },

  lag01: {
    num:        "1*",
    title:      "Lagging-strand synthesis: 3' overhang",
    phase:      "lagging",
    phaseLabel: "Lagging-strand end",
    caption:    String.raw`Gross telomere structure involves a stretch of telomeric repeats characterized by a G rich array ending in 3' OH at the chromosomal end, and a C rich tract ending in a 5' end. The two ends of a chromosome are built by different halves of the replication fork and terminate differently \cite{parenteau2002differential}.

Lagging strand synthesis terminates the C-strand wherever the last primer landed, leaving a short overhang set by primer placement.

The C-strand arrives as a series of Okazaki fragments. Pol α/primase lays an RNA primer and a short DNA segment at the distal edge of each fragment, and Pol δ extends it back toward the centromere after the RFC/PCNA switch \cite{ayyagari2003okazaki}. Pol α displaces the 5' primer of the fragment ahead of it into a flap, and Rad27 cleaves that flap at the junction between single and double stranded DNA, with a double flap carrying a 1 nt 3' tail as the preferred substrate \cite{kao2002cleavage}. Cdc9 seals the nicks that remain \cite{ayyagari2003okazaki}. Rad27, along with Dna2 or Exo1 removes the primers placed by Pol α/primase \cite{budd2013dna2}. The primer at the terminus has no fragment distal to it, so it is never displaced into a flap and no polymerase extends into the gap left when it is removed. The activity responsible for that removal is not established in S. cerevisiae. Ends replicated by lagging strand synthesis are processed differently from those replicated by leading strand synthesis \cite{parenteau2002differential, faure2010cdc13}.

Rap1 occupies the duplex repeat array at roughly one molecule per 18 bp \cite{conrad1990rap1}, with its C-terminal domain recruiting Rif1 proximally and Rif2 distally \cite{shi2013rif1}. At full telomere length, Rif2 occupancy is maximal, limiting MRX residence at the junction and excluding Tel1 \cite{roisne2021mechanism}. Rap1 acting with Rif2 also suppresses non homologous end joining at the telomere \cite{marcand2008multiple}. Ku binds the chromosome terminus, where it protects the end from nucleolytic degradation and contributes to telomerase recruitment through TLC1 \cite{gravel1998yeast, peterson2001function}. The SIR complex assembles on Rap1 and promotes transcriptional silencing of regions proximal to the telomeric repeats. \cite{gartenberg2016nuts}`,
    note:       String.raw`This end carries the end-replication problem, the panel draws its mechanism directly. The parental G-rich strand serves as the template for lagging-strand synthesis, so the new C strand is assembled from Okazaki fragments. Each fragment is primed at its distal edge and extended toward the centromere, placing the priming sites progressively closer to the terminus while synthesis proceeds in the opposite direction. The primer nearest the terminus therefore has no fragment distal to it. When that primer is removed, no upstream 3' hydroxyl is available to fill the resulting gap, leaving the corresponding stretch of parental G strand uncopied.

The difference between internal and terminal primers arises from their position within the lagging-strand array. An internal primer is displaced into a flap by polymerase arriving from the distal side, Rad27 cleaves the flap, and Cdc9 seals the resulting nick. The DNA that replaces an internal primer is retained because an upstream 3' end is available for every internal gap. The terminal primer has no downstream fragment to displace it and therefore does not enter this pathway. The panel consequently shows primer removal at the terminus without assigning the reaction to a specific nuclease, since the responsible activity has not been established in S. cerevisiae. Rad27 is shown without implying that Rad27 alone is sufficient. Dna2 and Exo1 also contribute to lagging-strand maturation at telomeres and are indicated in step 3*.

Panel 1 accounts for an absent primer, whereas this panel accounts for a primer whose removal leaves an unfillable gap. Leading-strand synthesis at the other daughter end begins from an origin outside the frame, and primer removal there is followed by ordinary gap filling because an upstream 3' end remains available. The terminal primer is shown here because its removal produces the structure on which the subsequent processing reactions act.

The product is a 3' overhang on the parental G strand. This end reaches the capping substrate directly, whereas the leading-strand end must generate the same structure by incision and bidirectional resection. The amount of parental sequence left uncopied is determined by the position of the terminal primer.

The sequence loss from incomplete replication is small. The final Okazaki fragments are initiated close to the chromosome terminus, and telomerase-negative strains shorten by 3 to 5 bp per population doubling from a tract of approximately 300 bp. Shortening therefore represents a small fraction of the repeat tract and depends on the length of the terminal gap left after primer removal. One passage of a single replication fork produces two daughter ends, but only the lagging-strand product emerges directly with the single-stranded structure required for capping.`
  },

  step02: {
    num:        "2",
    title:      "Cdk1 phosphorylates Sae2; Sae2-P activates Mre11",
    phase:      "resection",
    phaseLabel: "Leading-strand end",
    caption:    String.raw`Two Mre11 subunits and two Rad50 ATPase domains form a globular head that binds the telomeric repeat DNA. The Xrs2 C-terminus contains a protein-interaction region that recruits partner proteins to the chromosome end \cite{nakada2003atm}, and no partner occupies that region here. The Mre11-Rad50 head therefore provides the DNA binding and catalytic activities of the complex, while Xrs2 extends its reach to proteins that act on the end \cite{hopfner2001structural, williams2008mre11}.

Cyclin-dependent kinase activity confines incision to late S phase and G2. Cdk1 phosphorylates Sae2 at S267 \cite{huertas2008cdk}, and phosphorylated Sae2 stimulates the Mre11 endonuclease to incise the 5' C-strand DNA at a position internal to the chromosome end \cite{cannavo2019stepwise}. Sae2 acts as a cofactor to promote Mre11 endonuclease activity.`,
    note:       String.raw`Three functions of the complex are omitted from the panel but determine how the drawn complex behaves. Xrs2 provides the nuclear localization signal required for Mre11 import, so the assembled Mre11-Rad50-Xrs2 complex depends on Xrs2 before it can reach the chromosome end \cite{tsukamoto2005xrs2}. Mre11 also carries a 3'-5' exonuclease activity that degrades duplex DNA in addition to the structure-specific endonuclease activity that produces the initial nick. Both activities are manganese-dependent and reside in the N-terminal region of Mre11 \cite{furuse1998distinct, trujillo2001dna}. The Mre11 C-terminus binds single- and double-stranded DNA in a structure- and sequence-dependent manner \cite{ghosal2005saccharomyces, usui1998complex, furuse1998distinct}.

The incision model is well established at double-strand breaks, but its contribution at a natural telomere is less certain. Nuclease-dead mre11 alleles produce telomeres of nearly normal length, whereas mre11 deletion produces short telomeres \cite{moreau1999nuclease, ritchie2000mre11}. The difference indicates that Mre11 contributes to telomere maintenance through functions that do not require its nuclease activity, consistent with a role in DNA-end binding and recruitment. The incision itself is nevertheless supported by the biochemical behavior of the complex: Mre11 incision in vitro requires phosphorylated Sae2 together with a protein block at the DNA end \cite{cannavo2014sae2}, a condition present at a telomere. The position of the incision at a natural telomere has not been mapped. The panel therefore places the nick at a defined position for clarity, without implying a measured distance from the terminus. The subsequent overhang length is determined by the extent of resection from that nick, not by a fixed incision position.

The complex is also simplified to show only the features relevant to a single chromosome end. Rad50 normally extends a long antiparallel coiled-coil from the Mre11 head, with a CXXC motif at its apex coordinating zinc to dimerize Rad50 molecules within one complex or bridge two complexes \cite{hopfner2002rad50, hohl2011rad50}. That structure is omitted because its established bridging function concerns interactions between DNA ends, whereas the panel contains only one chromosome end. The vertical element represents the C-terminus of Xrs2 rather than the Rad50 coiled-coil. The head is likewise drawn with a single Rad50 lobe instead of the Rad50 dimer, leaving out the ATP-binding and hydrolysis cycle that opens and closes the Mre11-Rad50 head \cite{lammens2011mre11, mockel2012atp}.`
  },

  step03: {
    num:        "3",
    title:      "Bidirectional resection generates the 3' overhang",
    phase:      "resection",
    phaseLabel: "Leading-strand end",
    caption:    String.raw`Mre11 endonuclease activity incises the C-strand DNA internal to the chromosome terminus \cite{cannavo2019stepwise}, producing a 3' end on the distal fragment and a 5' end on the proximal fragment. Mre11 degrades the distal fragment 3' to 5' toward the terminus \cite{trujillo2001dna}. Exo1 and Sgs1-Dna2 degrade the proximal fragment 5' to 3' toward the chromosome interior, and these two 5' to 3' pathways act redundantly with each other. Resection therefore proceeds in both directions from a single internal incision \cite{garcia2011bidirectional}.

As the C-strand DNA is removed, RPA binds the exposed G-strand DNA and supports continued 5' to 3' degradation, and Dna2 requires an RPA-Dna2 complex for processive activity \cite{zhou2015dna2}. Removal of the C strand converts duplex TG1-3 DNA into single-stranded DNA and eliminates the Rap1 binding sites that the degraded tract carried, so the bound array shortens as the front advances. The reaction yields a 3' G-strand overhang \cite{larrivee2004generation, wellinger1996evidence}.`,
    note:       String.raw`Ku competes with Exo1 for access to the chromosome terminus, so occupancy at the end rather than a counted distance determines the final overhang length \cite{mimitou2010ku}. Loss of Exo1 or Sgs1, and hypomorphic dna2 alleles, shorten G-tails without eliminating them \cite{bertuch2004exo1}, which is the genetic form of the redundancy the panel draws as two boxes travelling together. The panel therefore draws no fixed stopping position, because none has been mapped.

RPA appears as the C-strand DNA is removed rather than after resection completes. Dna2 requires an RPA-Dna2 complex at the 5' end for processive degradation \cite{zhou2015dna2}, which places RPA inside the resection machinery instead of downstream of it. The panel accordingly lands one RPA unit at a time behind the advancing front.

MRX and the incision site leave the panel once the distal fragment has been degraded. Residence of MRX at a DNA end depends on the Rad50 ATP cycle, and Rif2 shortens that residence by stimulating hydrolysis of the ATP-bound state \cite{cassani2016tel1}. Sae2 provides a second route to release through activation of the Mre11 incision reaction, since Mre11 residence is prolonged at double-strand breaks when Sae2 cannot activate incision \cite{clerici2005saccharomyces}. That second observation comes from break repair and has not been measured at a telomere, which is the same limitation the Panel 2 note states for the incision itself.

MRX does not travel with the resection front. Its action remains local to the chromosome end, and its contribution to long-range degradation is the loading of Exo1 and Sgs1-Dna2, which occurs independently of Mre11 nuclease activity and is complete once the front has passed \cite{shim2010saccharomyces}. The complex drawn at the subtelomeric junction in later panels is a separate binding event and not the same molecule carried along the tract.

Placement of the complexes at either position is inferred from their substrates. The telomeric repeat tract spans a few hundred base pairs, and the assays applied to it do not resolve the chromosome terminus from the subtelomeric junction.

Wild-type cells generate long G-tails in late S phase and do not arrest the cell cycle \cite{wellinger1996evidence}, so the processing drawn here occurs on a telomere that remains capped throughout.`
  },

  lag03: {
    num:        "3*",
    title:      "Unidirectional resection on the lagging-strand end",
    phase:      "lagging",
    phaseLabel: "Lagging-strand end",
    caption:    String.raw`The lagging-strand end carries a recessed 5' C-strand terminus following removal of the terminal RNA primer \cite{bonetti2014telomere}, so the substrate for long-range resection is present without an incision. Exo1 and Sgs1-Dna2 degrade the C strand 5' to 3' toward the chromosome interior, extending the existing overhang. RPA binds the exposed G strand as the C strand is removed and supports continued degradation \cite{zhou2015dna2}. Cdk1 activity confines resection at both chromosome ends to late S phase and G2 \cite{frank2006regulation, vodenicharov2006dna, huertas2008cdk}. Cdc13 binding at the lagging-strand end does not require MRX, whereas Cdc13 binding at the leading-strand end does \cite{faure2010cdc13}. Ku binds the duplex terminus and restrains Exo1, and deletion of \textit{YKU70} or \textit{YKU80} produces long single-stranded G-tails throughout the cell cycle \cite{gravel1998yeast, bertuch2004exo1, mimitou2010ku}.`,
    note:       String.raw`The panel repeats step 3 on a different substrate. Mre11 has nothing to cut here and no distal fragment to clear, so the drawing carries the inward arm alone: Exo1 and Sgs1-Dna2 on the 5' end left by primer removal, moving toward the centromere, with RPA landing behind them one repeat at a time. The glyphs, stacking, and cadence match step 3, because the machinery is the same.

MRX is drawn without an incision beside it, which is the only position in the figure where the panel can show what MRX contributes to long-range resection apart from its nuclease. Cdc13 binding at this end proceeds without MRX, while Cdc13 binding at the leading-strand end requires it, which locates the MRX requirement in the generation of the substrate rather than in the loading of the downstream nucleases at an end that already has one.

MRX fades as the front passes. Rif2 binds the Rad50 ATPase head in its ATP-bound resting state and blocks the transition to the DNA-bound state, so an MRX complex that approaches the telomere returns to the resting state and diffuses away without capturing the end. The complex drawn here is a dwell, and the same mechanism operates in step 3.

Whether this end undergoes resection beyond primer removal is an inference. The affirmative case is that Ku restrains Exo1 at telomeres and \textit{yku} deletion produces long tails throughout the cycle, and that the constitutive tail is uniform while the position of the last primer would not be, so something normalizes it. Bulk assays cannot separate the two daughter ends, and differential processing of the two has been reported. If this end is not resected, this panel is where the figure is wrong, and the branch would reach step 4 by a shorter route.

The overhangs at the two ends are drawn at comparable lengths. That comparability is an inference from bulk G-tail measurements, which do not resolve the two daughters.`
  },

  step04: {
    num:        "4",
    title:      "Cdc13 alone loads on the G-overhang",
    phase:      "processing",
    phaseLabel: "End processing",
    caption:    String.raw`Cdc13 binds the single stranded G rich overhang through its DNA-binding OB-3 fold with sequence specificity and sub-nanomolar affinity \cite{lin1996saccharomyces}. Overhang occupancy by Cdc13 serves as one element of the telomeric cap. Cdc13 prevents the telomere being read as a resected break, and loss of that occupancy in cdc13-1 at restrictive temperature produces runaway resection and checkpoint arrest \cite{addinall2008genomewide}. Cdc13 competes with RPA for access to the limited single stranded G rich overhang \cite{mitton2004structural, spegg2023phase}. Both bind single-stranded DNA \cite{iftode1999replication}, but only Cdc13 reads the sequence \cite{lin1996saccharomyces}. RPA is present at telomeres with maximal association in S phase, and it is required for Est1 to reach the end \cite{schramke2004rpa}.`,
    note:       String.raw`Both branches converge here, and the convergence is the point of splitting them: the leading end paid an incision and a 3' to 5' arm to reach a structure the lagging end was born with, and after resection the two daughter ends are the same substrate. Cdc13 binds single-stranded TG1-3 through its DNA-binding OB fold with sequence specificity and sub-nanomolar affinity. Occupancy is the capping event: an overhang bound by Cdc13 is not read as a resected break, and loss of that occupancy in cdc13-1 at restrictive temperature produces runaway resection and checkpoint arrest. MRX is drawn at the duplex-to-overhang junction because that is the only position in this picture carrying its substrate, not because it travelled there; the complex that was at the terminus in step 3 released, and this is a separate binding event, which may or may not be the same trimer out of the nucleoplasm. Stn1 and Ten1 are drawn only at fill-in. That is a display choice for legibility, not a claim that the trimer assembles sequentially. Cdc13 takes the repeat it occupies from RPA, and RPA coats the rest of the overhang. This is a handoff of one site rather than an eviction from the tail: RPA is present at telomeres with maximal association in S phase, and it is required for Est1 to reach the end. Both bind single-stranded DNA, but only Cdc13 reads the sequence, which is what makes occupancy a capping event rather than a coating event.`
  },

  step05: {
    num:        "5",
    title:      "MRX retained; Tel1 recruited through Xrs2's C terminus",
    phase:      "elongation",
    phaseLabel: "G-strand elongation",
    caption:    String.raw`At a short telomere, fewer telomeric repeats provide binding sites for fewer Rap1 molecules and consequently fewer Rif2 molecules. The reduced Rif2 occupancy allows the MRX complex to bind more readily to the telomere, leading to accumulation of Tel1. At longer telomeres, Rap1 and Rif2 occupy the repeat tract more extensively, and Rif2 limits Tel1 recruitment by competing with Tel1 for binding to the C-terminal region of Xrs2 within the MRX complex \cite{ritchie1999interactions}.

Cdc13 carries at least five characterized phosphorylation sites, three of which have been connected to telomerase recruitment. Cdk1 phosphorylates T308 in late S phase, and loss of that mark reduces Cdc13 association with Est1, which makes it a timing switch: Cdc13 already bound at the 3' overhang becomes competent to recruit telomerase at the point in the cycle when the end is available \cite{li2009cdk1}. Mec1 and Tel1 both phosphorylate S249 and S255 in vitro. Removing both sites abolishes de novo telomere addition and produces senescence, while substituting aspartate or glutamate restores stable telomere length, so what these positions supply is negative charge \cite{tseng2006telomerase}. The two residues flank E252, the site of the recruitment-defective cdc13-2 allele, and all three sites lie in the telomerase recruitment domain. Fusing Est1 to Cdc13 bypasses the defects of all three. S225 and S306, phosphorylated by Mec1 and, for S225, by Tel1 as well, carry no phenotype alone; removing them alongside S249 and S255 escalates the defect from senescence to inviability \cite{tseng2006telomerase}.`,
    note:       String.raw`The arrow to S249 and S255 carries no phosphate mark because the mechanism is unresolved in three separate ways. The kinase assignments come from immunoprecipitated Mec1 or Tel1 acting on recombinant GST-Cdc13 fragments, which tests capability rather than occupancy; no mass spectrometry or phospho-specific antibody places either mark on Cdc13 in vivo. The rescue by aspartate and glutamate means the experiments cannot separate phosphorylation from negative charge at those positions. And no direct measurement of Cdc13-Est1 binding has been made at S249 or S255, so the surface interpretation rests on proximity to E252 and on the fusion bypass rather than on a binding defect.

Which kinase acts at the telomere is a further open question. Tel1 and Mec1 associate with telomeres reciprocally across the cycle, Tel1 in late S and Mec1 in G2/M, so a mark placed by Mec1 would have to be carried into the window this panel draws rather than made in it. Tseng and colleagues raise the possibility that Cdc13 is modified before loading. The panel therefore names both kinases in the caption and draws neither in the figure.

S225 and S306 are omitted from the panel. Their only phenotypes are combinatorial, and the terminal one is lethality on tetrad dissection, which is faster than telomere attrition and so is unlikely to be a recruitment defect. The folding control in that study was run on the S249 S255 double only, leaving misfolding of the triple and quadruple alanine mutants unexcluded.`
  },

  step06: {
    num:        "6",
    title:      "Est1 bridges TLC1 to Cdc13; Est2 copies the template",
    phase:      "elongation",
    phaseLabel: "G-strand elongation",
    caption:    String.raw`At a telomere selected for elongation through the coordinated phosphorylation of bound Cdc13, telomerase extends the G-strand from the 3' terminus. Est2, the catalytic subunit of the telomerase holoenzyme, copies the TLC1 template into DNA one repeat at a time \cite{lingner1997reverse, singer1994tlc1}. The telomerase holoenzyme contains Est1, Est2, and Est3 together with the RNA Tlc1 and travels along the growing G-rich strand, adding a mean of approximately 40 nucleotides during a single extension event \cite{teixeira2004telomere}. Cdk1 phosphorylation of Cdc13 at T308 promotes telomerase recruitment through the interaction between Cdc13 and Est1 \cite{li2009cdk1}. The Cdc13--Est1 interaction has an apparent affinity of approximately 250 nM \cite{wu2011telomeric}, whereas Cdc13 binds telomeric ssDNA with an affinity of 310 pM \cite{anderson2002delineation}. Cdc13 therefore remains bound to the telomeric ssDNA while Est1 dissociates with the telomerase holoenzyme. Telomerase extension produces the G-rich overhang, which is subsequently bound by RPA \cite{schramke2004rpa, luciano2012rpa}.`
  },

  step07: {
    num:        "7",
    title:      "Pif1 and Ipl1 remove telomerase",
    phase:      "fillin",
    phaseLabel: "C-strand fill-in",
    caption:    String.raw`After G-strand elongation, telomerase must be removed from the elongated G-rich overhang to allow C-strand fill-in by DNA polymerase α. Telomerase removal involves three discrete steps. First, the DNA--RNA hybrid between Tlc1 and the newly elongated G-strand must be disrupted. Pif1 mediates this disruption \cite{boule2007yeast}. Second, Ipl1 disrupts the Est1--Tlc1 interaction, dissolving the telomerase holoenzyme complex \cite{shen2014pp2a}. Third, further recruitment of telomerase subunits must be prevented. CST assembly establishes this block to additional telomerase recruitment \cite{chandra2001cdc13}.`
  },

  step08: {
    num:        "8",
    title:      "Stn1-Ten1 join Cdc13; Pol alpha fills in the C-strand",
    phase:      "fillin",
    phaseLabel: "C-strand fill-in",
    caption:    String.raw`Stn1 and Ten1 assemble with Cdc13 and recruit Pol α--primase through contacts with Cdc13 and the Pol12 subunit \cite{cai2023cst, rice2016structure, qi2000saccharomyces, grossi2004pol12, sun2011structural}. Cdk1 phosphorylation of Stn1 promotes assembly \cite{gopalakrishnan2017sequential}, K909 SUMOylation strengthens the Stn1--Cdc13 interaction \cite{hang2011sumoylation}, and dephosphorylation of the Cdc13 recruitment domain promotes Stn1 association \cite{shen2014pp2a}. The resulting CST complex therefore assembles on a Cdc13 molecule in a different covalent state from the T308-phosphorylated Cdc13 molecule that remains bound to the telomeric repeats after telomerase recruitment. Pol α--primase contains two catalytic activities: Pri1 and Pri2 synthesize the RNA primer, and Pol1 extends the primer with DNA \cite{grossi2004pol12, meunier2021role}. Pol12 serves as the noncatalytic B subunit and provides the contact with Stn1 \cite{grossi2004pol12, sun2011structural, meunier2021role}. CST assembly also terminates further telomerase recruitment because the Est1 and Stn1--Ten1 binding surfaces on Cdc13 are mutually incompatible \cite{li2009cdk1, ge2020structural}. RPA occupies the G-rich overhang when C-strand synthesis begins, and Pol α--primase displaces RPA progressively along the overhang ahead of DNA synthesis \cite{greetham2015proteins}.`
  },

  step09: {
    num:        "9",
    title:      "Capped: the resting state",
    phase:      "resting",
    phaseLabel: "Capped",
    caption:    String.raw`The telomere at rest is capped. Capping refers to the activities that a functional telomere prevents: recognition as DNA damage, checkpoint activation, repair by homologous recombination or non-homologous end joining, and extension by telomerase \cite{lebel2005, hug2006telomere}. Capping depends on three features: a sufficient amount of species-specific repeat DNA, an appropriate terminal structure, and the proteins that recognize the repeat DNA and terminal structure \cite{lebel2005, hug2006telomere, longhese2008, palm2008}.

Three protein systems contribute to capping here. CST (Cdc13-Stn1-Ten1) binds the single-stranded 3' overhang with high affinity and has been proposed to function as a telomere-specific counterpart to RPA, limiting access of the canonical ssDNA-binding machinery that would otherwise promote damage signaling \cite{wellinger2009, gao2007rpa}. Rap1 occupies the duplex repeat array and limits both telomere-telomere fusion by NHEJ and nucleolytic degradation \cite{pardo2005, vodenicharov2010telomere}. Ku protects the chromosome terminus from nucleases through a mechanism distinct from those of CST and Rap1 \cite{gravel1998yeast, maringele2002, longhese2008}. These systems are therefore not interchangeable, and their contributions change across the cell cycle. CST-mediated capping is dispensable in G1, when Ku and Rap1 are sufficient to protect the chromosome end \cite{vodenicharov2006dna, vodenicharov2007, vodenicharov2010telomere}.

Telomere length does not by itself report capping status because telomere length is affected by pathways that are separate from the mechanisms that protect the chromosome end \cite{palm2008}. The indicator above each panel therefore reports the highest level of capping established by the evidence at that step, rather than the number of capping proteins present.

Click a glowing protein to see how loss of that protein affects telomere capping.`,
    note:       String.raw`Capping is drawn as three separable slots because loss of the three capping systems produces separable defects. Conditional ablation of CST, Ku, or Rap1 produces a different terminal defect, and CST and Ku are required at different phases of the cell cycle \cite{vodenicharov2006dna, vodenicharov2007, vodenicharov2010telomere, gravel1998yeast, pardo2005}. A single capped-or-uncapped state would therefore not represent the three branches that follow.

The slots are graded for the same reason that the underlying capping states are graded. Telomeres near wild-type length contain more telomeric chromatin than is required to maintain capping. Progressive sequence loss then moves a telomere through a state in which checkpoint activation and repair remain suppressed but telomerase can gain access, followed by a state in which the telomeric repeats are exhausted, the damage response is engaged, and telomerase can no longer act \cite{hug2006telomere, teixeira2004telomere, ijpma2003}. The intermediate state is poorly defined and transient in the source literature, so the figure does not represent it as a discrete step.

An unlit slot does not mean that the corresponding protein is absent from the telomere. It means that the evidence does not justify placing that protein in the drawing at that step. Only "na" and "lost" indicate absence. Both describe structural absence: "na" indicates that the substrate required for binding is not present, whereas "lost" indicates that the corresponding capping system has been removed by the perturbation.`
  },

offB: {
    num:        "B",
    title:      "Offshoot: long telomere",
    phase:      "processing",
    phaseLabel: "End processing",
    caption:    String.raw`Rif2 contains a short motif that binds Rad50 and competes with the Xrs2 C-terminus for the same Rad50 surface \cite{roisne2021mechanism}. Rap1 occupancy scales with the length of the duplex repeat array, and the Rap1 C-terminal domain recruits Rif2 \cite{conrad1990rap1, shi2013rif1}. At a long telomere, Rif2 occupancy therefore limits Xrs2 association with Rad50 and reduces Tel1 recruitment, which reaches the chromosome end through the Xrs2 C-terminus \cite{roisne2021mechanism, nakada2003atm}. The Rif2-Rad50 interaction also stimulates Rad50 ATPase activity and promotes release from the ATP-bound state \cite{cassani2016tel1, roisne2021mechanism}. This provides the basis for the transient MRX residence at chromosome ends represented by the fading complexes in steps 3 and 3*. Cdc13 lacks T308 phosphorylation in this branch and therefore does not reach the state required for Est1 binding, so telomerase is not recruited. The relevant modification is T308, a Cdk1 phosphorylation site \cite{li2009cdk1}; the model does not assign phosphorylation states to S249 or S255 \cite{tseng2006telomerase}. The two panels therefore differ by a single modification on the same Cdc13 position. Cdc13 remains bound at the chromosome end \cite{lin1996saccharomyces, anderson2002delineation}, and the end still requires C-strand fill-in, so this branch rejoins the main pathway at step 8.`
  },

  offC: {
    num:        "C",
    title:      "Cap failure: CST lost",
    phase:      "resting",
    phaseLabel: "Capped",
    caption:    String.raw`Loss of CST causes progressive resection of the C strand at the telomere, producing a very long G-rich 3' overhang \cite{garvik1995single, wellinger2009}. RPA coats the exposed single-stranded DNA in place of Cdc13. The RPA-coated overhang activates a DNA damage checkpoint pathway involving Ddc2 and Mec1, followed by Rad9 and Rad53, leading to metaphase arrest \cite{gao2007rpa, zou2003sensing, paciotti2000}. Resection can continue past the last telomeric repeat and into unique sequence, so the exposed strand eventually loses the telomeric sequence required for CST binding \cite{garvik1995single}. Ku remains bound to the duplex DNA behind the resection front, but Ku does not prevent the resection caused by CST loss \cite{gravel1998yeast, longhese2008}. The effect of CST loss therefore extends beyond loss of a telomere-binding complex: the chromosome end is converted into an RPA-coated ssDNA substrate that activates the checkpoint.`,
    note:       String.raw`The camera pans because the claim of this branch is that resection crosses the telomeric repeat array. Resection that stops within the array produces a shorter telomere, but telomere length alone does not establish loss of capping because telomere length is affected by pathways unrelated to capping \cite{palm2008}. Resection that continues into unique sequence provides a direct indication that the resection front has passed beyond the telomeric array. The crossing shown here comes from the primary result of Garvik et al. \cite{garvik1995single}. The review literature describes progressive 5' resection as the telltale consequence of CST loss but does not establish where the resection front terminates.

RPA coats the exposed single-stranded DNA rather than leaving the overhang unoccupied. This distinguishes this branch from branch E. The competition between RPA and CST also defines the substrate on which the two proteins act: the same single-stranded telomeric DNA can bind either occupant, and the identity of the bound protein determines whether the chromosome end enters the damage-signaling pathway \cite{gao2007rpa}.

CST loss is drawn as terminal in this branch because persistent loss of CST is generally incompatible with continued proliferation. It is not, however, an absolute endpoint. Cells that maintain telomeres by recombination, or cells lacking particular checkpoint proteins or nucleases, can tolerate Cdc13 loss and continue dividing despite persistent telomere damage \cite{larrivee2006, zubko2006linear}.`
  },

  offA: {
    num:        "A",
    title:      "Offshoot: no telomerase",
    phase:      "elongation",
    phaseLabel: "G-strand elongation",
    caption:    String.raw`Cells lacking telomerase lose telomeric repeats at every division because the lagging-strand end cannot copy the sequence beneath its terminal primer and no enzyme restores the missing sequence. Deletion of any of the EST genes, or of the RNA component, produces the same progressive shortening and eventual senescence \cite{singer1994tlc1, lendvay1996}. The catalytic subunit and its template therefore act in the same telomere-maintenance pathway.

Shortening does not immediately uncap the telomere. Telomeres lose repeats for many divisions while the cap remains functional, and the damage response is engaged only when the repeat tract becomes too short for the bound proteins to protect the chromosome end \cite{hug2006telomere, ijpma2003}. Once the repeat tract is exhausted, the same loss that exposes the chromosome end also removes the substrate required for telomerase-mediated extension. The chromosome end therefore cannot be rescued by telomerase even if telomerase is present.

A chromosome end in this state is a one-sided break, and a single uncapped end is more likely to engage recombination than end-to-end ligation \cite{kanaar2008, mceachern2006}. In a telomerase-negative population, many chromosome ends cross the uncapping threshold over the same period, making a second eroded end available for ligation. The two ends can then be joined by non-homologous end joining \cite{ferreira2004indecent}. The resulting chromosome fusion is unstable and can break again during the following mitosis, converting the initial fusion into a continuing source of chromosome instability \cite{osullivan2010}.

Fusion is not the only outcome. A minority of cells maintain their telomeres through recombination and continue dividing as survivors \cite{mceachern2006, larrivee2006}.`,
    note:       String.raw`This branch is not an offshoot of panel 9 and is drawn from elongation for that reason. Panel 9 introduces the cap as three elements bound to two substrates, and branches C, D, and E each remove one of those elements. Nothing is removed here. The three binding sites disappear because the sequence to which all three elements bind is consumed. The loss of the binding sites is therefore produced by erosion of the substrate rather than by removal of another cap element. Placing this branch beneath panel 9 with branches C, D, and E would make the four branches read as alternative ways in which the cap can be lost.

The cap indicator carries no declared loss for the same reason. Branch D declares loss of Rap1 because the duplex DNA remains and the missing Rap1 element would otherwise be the only change represented. Here, rewriting the Rap1 slot as lacking duplex DNA is the claim being made by the branch. Declaring a separate Rap1 loss would represent the consequence as an independent event rather than as the result of repeat erosion.

Erosion is drawn to the end of the array rather than stopped partway. A telomere with ten duplex repeats remaining is short, but it is not necessarily uncapped. Telomere length and end protection are controlled by distinct processes \cite{palm2008}. The array therefore has to be exhausted before the branch reaches the uncapped state shown here.

MRX is drawn as three complexes appearing and disappearing at successive positions rather than as one complex moving along the array. MRX residence at a chromosome end is governed by the Rad50 ATP cycle, and the complex has no translocase activity. MRX therefore acts locally at the end rather than traversing the array. A single glyph moving along the array would instead imply a trajectory that is not supported by the mechanism represented in steps 3 and 3*.

The checkpoint background is specified here rather than in the caption. Fusion frequency in senescing cells depends on the checkpoint and repair genotype, so a fusion rate measured in one genetic background cannot be assumed to apply to another \cite{mieczkowski2003}. Deletion of \textit{DNL4} likewise does not alter the rate at which a telomerase-negative population senesces \cite{hackett2001telomere}. These observations place fusion as one outcome of the eroded state rather than as the usual endpoint of telomere loss.
`
  },

offD: {
    num:        "D",
    title:      "Cap failure: Rap1 depleted",
    phase:      "resting",
    phaseLabel: "Capped",
    caption:    String.raw`Conditional depletion of Rap1 removes the protein from an array that retains all of its repeats. Rap1 blocks non-homologous end joining at chromosome ends, and telomeres in Rap1-depleted cells fuse at lengths close to their normal length. The fusions require the Mre11 complex together with Ku and Lig4, whereas Sae2 and Tel1 do not affect their frequency \cite{pardo2005}. Deletion of \textit{LIF1} restores viability to Rap1-depleted cells, placing the lethal event downstream of fusion \cite{pardo2005}. The chromosomes are joined, and the joined chromosomes are what the cell cannot survive.

The chromosome terminus does change, but the change is small. Rap1 also suppresses nucleolytic degradation of the C strand, and depletion produces single-stranded G-rich tails in both dividing and non-dividing cells \cite{vodenicharov2010telomere}. The degradation remains within the telomeric repeat array, does not extend into subtelomeric sequence, and does not activate Rad53 \cite{vodenicharov2010telomere}. An end in this state is structurally similar to the end in branch E, where the end is re-capped and tolerated. The two branches therefore differ in whether Rap1 remains bound to the intact repeat array, rather than in the extent of C-strand resection.

Rap1 inhibits end joining through more than one pathway. The Rap1 C-terminal domain recruits Rif2 and Sir4, which provide parallel inhibitory routes to end joining \cite{marcand2008multiple}. CST remains bound to the single-stranded overhang and Ku remains bound at the chromosome end, so the depletion removes Rap1 without removing the other capping components \cite{wellinger2010caps}.`, 
       note:       String.raw``
  },

  offE: {
    num:        "E",
    title:      "Cap failure: Ku lost",
    phase:      "resting",
    phaseLabel: "Capped",
    caption:    String.raw`Loss of Ku at a resting end. Absence of Ku changes the structure of the terminal telomeric DNA, which places it in a protective role against nucleases that is separate from the roles of CST and Rap1 \cite{gravel1998yeast, maringele2002, longhese2008}. The C strand is degraded and the single-stranded G tail extends inward, so the duplex array shortens as the tail grows and the Rap1 slot falls with it. Induced loss of Ku produces the responses expected of a DNA end, recognition as such and strand-specific 5' resection, though that resection is slow and inefficient, so re-capping is the usual outcome before more serious consequences follow \cite{vodenicharov2010telomere, bonetti2010shelterin}. The ssDNA generated in cells lacking Ku is Exo1-dependent and activates subsets of the DNA damage and spindle checkpoint pathways \cite{maringele2002}. CST remains on the tail throughout, and the shift to restrictive temperature in the final frames changes nothing on the DNA: capping in this window does not run through CST, whose loss has virtually no short-term consequence for telomere structure or viability, and runs through Ku and Rap1 instead \cite{vodenicharov2006dna, vodenicharov2007, vodenicharov2010telomere}. Where an end in this state is not re-capped, inappropriate fusion remains the expected outcome \cite{ferreira2004indecent}.`,
    note:       String.raw`The single-strand region grows as the 5' end of the C strand moves inward while the 3' terminus remains fixed. The earlier version extended the G strand instead. An extending G strand would imply telomerase action followed by incomplete fill-in, neither of which is reported for Rap1 depletion. The evidence for C-strand loss is that the same single-stranded G-rich signal appears in quiescent cells. Est1 is degraded on exit from G2/M and telomerase is restricted to late S, so G0 cells have no telomerase available, yet \textit{rap1-td} telomeres in G0 still carry single-stranded G-rich DNA \cite{vodenicharov2010telomere}. In cycling cells, the same signal depends on Exo1, a 5' to 3' exonuclease, consistent with loss of the C strand. There is no evidence here for a lesion that uncouples G-strand extension from C-strand fill-in. CST remains on the overhang and Pol alpha recruitment occurs through Cdc13. The nuclease responsible for C-strand loss in G0 has not been identified: Exo1 is required in cycling cells but not in G0, and Mre11 was not tested in this background \cite{vodenicharov2010telomere}.

The recession is drawn short. Fusion junctions retain 240 plus or minus 80 bp of telomeric tract compared with native telomere lengths of 270 to 330 nt, giving a deficit on the order of tens of bases rather than loss of the array \cite{pardo2005}. The array therefore remains visibly intact when fusion occurs, which separates this branch from branch A.

Telomeres in Rap1-depleted cells lengthen \cite{vodenicharov2010telomere}, but that result is carried here in the interpretation rather than in the drawing. Rap1 recruits Rif2, and Rif2 competes with the Xrs2 C-terminus for Rad50. This interaction limits Tel1 association with long telomeres in step 3 and branch B. Without Rap1, Rif2 is absent from the telomere, removing this route of length-dependent Tel1 exclusion. Telomerase can therefore act at ends that would otherwise be extended less frequently. The resulting change is a change in the frequency of extension events measured across a population over successive divisions. This figure follows one telomere through one cycle, so that population-level change has no direct representation. Drawing extension in a panel whose phase is resting would also place telomerase outside the cell-cycle window in which telomerase acts. Lighting Tel1 on the Xrs2 C-terminus was considered as an alternative representation but rejected because it would introduce the length-regulation machinery into a capping panel and could make the panel read as a statement about telomere length.

Branch A remains the panel that must be distinguished from this branch. The distinction follows from the sequence and the partner end. In branch A, the telomeric sequence is lost and the proteins bound to that sequence are lost with it. Here, Rap1 is lost while the telomeric sequence remains. In branch A, the partner is unique sequence at an exhausted chromosome end. Here, the partner is another chromosome end that retains a full telomeric array. Both branches produce chromosome fusion, but the state of the two telomeric arrays distinguishes the events.

Branch E now leaves a chromosome end structurally similar to this one, which is why the two branches should not be separated by the extent of resection. Single-stranded tract lengths in \textit{rap1-td} and \textit{yku70-td} are indistinguishable by the same assay \cite{vodenicharov2010telomere}. Drawing one recession as longer than the other would therefore imply a difference that the measurement does not support. The branches instead separate by what happens to the end and by which component is lost. In branch E, the repeat array shortens far enough to remove the Rap1-binding site, and the end is usually re-capped. Here, the repeat array remains intact, Rap1 is absent, and the end is ligated.

Rap1 is the only component declared as lost in this branch. The duplex DNA occupied by Rap1 remains on the page, so the disappearance of the Rap1 slot cannot be inferred from sequence loss. The declared loss therefore represents the experimental perturbation directly. This is the converse of branch A, where declaring a Rap1 loss would obscure the fact that Rap1 is lost because its binding site has been eroded.

The Rap1 middle rung on the indicator, which represents suppression of end joining and resection as a function of the length of the bound array, is not established by the experiments used here. Rif2 and Sir4 provide parallel mechanisms for inhibiting end joining, but these interactions do not measure inhibition as a function of array length \cite{marcand2008multiple}. A source showing how Rap1-dependent protection changes with the amount of bound telomeric array would be required to retain that rung.

The \textit{rap1} C-terminal truncation is not used as a Rap1-loss allele and is not drawn or named in this figure. The truncation removes the C-terminal domain while retaining the DNA-binding domain, and the resulting telomeres are not deprotected in the same manner as telomeres in Rap1-depleted cells \cite{marcand2008multiple}.

The fusion drawn here requires Ku, whereas branch E removes Ku. The two branches therefore differ in whether the factor that inhibits end joining or one of the factors that carries out end joining is removed. This branch removes Rap1-dependent inhibition while retaining Ku-dependent repair; branch E removes Ku while retaining Rap1-dependent inhibition.

The camera pans left, which no other panel does. Two full-length telomeres cannot fit within an 880 viewBox at once, so the full array is established before the fusion is drawn and the proximal portion of the array leaves the frame during the fusion sequence. Widening the viewBox for every panel would instead change the framing of the entire figure.`
  }

};
/* Keyboard traversal and the initial selection. The leading-strand route plus
   the shared tail below the merge, which is the one path running from a fresh
   daughter end to a capped one with no gap in it.

   lag01 and lag03 are not in it, and they are not offshoots either. The split
   at the top of the nav is not a decision: one fork passage makes both ends, so
   neither track is the exception to the other. But arrow keys walk a line, and
   a line has to pick one. The lagging track is reached by clicking, and step04
   is where either route lands. */
const ORDER = ["step01", "step02", "step03", "step04",
               "step05", "step06", "step07", "step08", "step09"];

/* Reading order for the whole figure, both tracks and every branch. ORDER is
   the keyboard line and skips six panels, so it cannot be what citation
   numbering walks. Kept in the same order as KEYS in tools/make_shell.py, and
   the test suite fails if the two disagree. */
const PANEL_ORDER = ["step01", "lag01", "step02", "step03", "lag03", "step04",
                     "step05", "step06", "step07", "step08", "step09",
                     "offA", "offB", "offC", "offD", "offE"];