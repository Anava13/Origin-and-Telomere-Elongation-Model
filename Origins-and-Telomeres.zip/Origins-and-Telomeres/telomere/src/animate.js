/* Animation engine.

   One base-level controller. Playing, scrubbing, and resetting are all the
   same process: put the panel into the state a given frame describes. Nothing
   here knows what resection or elongation mean; it applies whatever
   anim-data.js declares, so a new animated panel needs a frame table and no
   new code.

   MODEL and VIEW functions are terminal.
*/

var animState = { key: null, frame: 0, timer: null, playing: false };


function runAnimation(command, arg) {
    // CONTROLLER: single entry point for every animation action.
    //
    // command: "load" | "play" | "pause" | "toggle" | "seek" | "step" | "reset"

    if (command === "load")   { loadPanelAnimation(arg); return; }
    if (!animState.key)       { return; }

    if (command === "play")   { startPlayback(); }
    if (command === "pause")  { stopPlayback(); }
    if (command === "toggle") { animState.playing ? stopPlayback() : startPlayback(); }
    if (command === "seek")   { stopPlayback(); gotoFrame(arg); }
    if (command === "step")   { stopPlayback(); gotoFrame(animState.frame + arg); }
    if (command === "reset")  { stopPlayback(); gotoFrame(0); }

    function loadPanelAnimation(key) {
        // SUB-CONTROLLER: arm the engine for a panel, or stand down if that
        // panel has no animation.
        stopPlayback();
        animState.key = ANIM[key] ? key : null;
        animState.frame = 0;
        if (animState.key) {
            gotoFrame(0);
        } else {
            clearAnimationClasses(panelRoot(key));
            paintDerived(panelRoot(key));
            paintTransport();
        }
    }

    function startPlayback() {
        // SUB-CONTROLLER: advance frames on a timer, stopping at the end.
        stopPlayback();
        if (animState.frame >= frameCount(animState.key) - 1) { gotoFrame(0); }
        animState.playing = true;
        paintTransport();
        animState.timer = setInterval(function () {
            if (animState.frame >= frameCount(animState.key) - 1) {
                stopPlayback();
            } else {
                gotoFrame(animState.frame + 1);
            }
        }, frameInterval(animState.key));
    }

    function stopPlayback() {
        // SUB-CONTROLLER: halt the timer and reflect that in the transport.
        if (animState.timer) { clearInterval(animState.timer); }
        animState.timer = null;
        animState.playing = false;
        paintTransport();
    }

    function gotoFrame(n) {
        // SUB-CONTROLLER: render frame n and update the transport to match.
        var total = frameCount(animState.key);
        animState.frame = Math.max(0, Math.min(total - 1, n));
        var frame = frameAt(animState.key, animState.frame);

        var root = panelRoot(animState.key);
        clearAnimationClasses(root);
        paintHalves(root, frame.halves);
        paintActors(root, frame.actors);
        paintDerived(root);
        paintTransport();
    }
}


/* ---- models (terminal) ------------------------------------------------- */

function frameCount(key) {
    // MODEL: how many frames a panel's animation has (TERMINAL)
    return ANIM[key] ? ANIM[key].frames.length : 0;
}

function frameAt(key, n) {
    // MODEL: one frame, with missing fields filled in (TERMINAL)
    var f = ANIM[key].frames[n] || {};
    return { halves: f.halves || {}, actors: f.actors || {} };
}

function frameInterval(key) {
    // MODEL: milliseconds per frame (TERMINAL)
    return Math.round(1000 / (ANIM[key].fps || 1.2));
}

function isAnimated(key) {
    // MODEL: does this panel animate at all (TERMINAL)
    return !!ANIM[key];
}

function placeEndLabel(el, lastChunk, y, dx, anchorOut) {
    // VIEW: park a 3' or 5' mark on the end of a strand (TERMINAL)
    //
    // lastChunk is the rightmost chunk still present on that strand, or null if
    // the strand is gone entirely, in which case there is no end to mark and the
    // label is hidden rather than left at a stale coordinate.
    //
    // The block is drawn CW - 2 wide inside a CW pitch, so its right edge is
    // X0 + i * CW - 2, and dx is measured from there. The two marks sit
    // differently on purpose. The 3' end is the outermost point of the
    // molecule, so its label goes past the last block, in the clear. The 5' end
    // is recessed behind it, and the space beyond it belongs to the overhang
    // and to whatever is bound there, so its label tucks under the block
    // instead. Both hug the block they belong to rather than floating in the
    // gap after it, where a reader would have to work out which side was meant.
    if (!el) { return; }
    if (lastChunk === null || lastChunk === undefined) {
        el.setAttribute('class', 'endlab off');
        return;
    }
    el.setAttribute('class', anchorOut ? 'endlab out' : 'endlab');
    el.setAttribute('x', String(50 + lastChunk * 42 - 2 + dx));
    el.setAttribute('y', String(y));
}

function chunkId(i) {
    // MODEL: element id stem for chunk i (TERMINAL)
    //
    // Positive indices are telomeric repeats. Zero and below are unique
    // sequence to the left of the array, named u01 outward. Mirrors chunk_id()
    // in tools/make_panels.py; if one changes the other must.
    if (i >= 1) { return 'c' + (i < 10 ? '0' + i : String(i)); }
    var n = 1 - i;
    return 'u' + (n < 10 ? '0' + n : String(n));
}

function panelRoot(key) {
    // MODEL: the DOM subtree for one panel (TERMINAL)
    //
    // Chunk ids repeat across panels on purpose, so anim-data.js can say
    // "c11-b" rather than "step03__c11-b". Every panel is in the document at
    // once, so a document-wide lookup would find the first match and animate
    // the wrong figure. Every query below is scoped to one panel.
    return document.getElementById('p-' + key);
}


/* ---- views (terminal) -------------------------------------------------- */

function clearAnimationClasses(root) {
    // VIEW: return every half, effect glyph, and actor in one panel to rest
    // (TERMINAL)
    //
    // ".fx" is anything other than a strand half that a frame table turns on
    // and off, such as the RPA units deposited during resection. It carries
    // the same four states, so paintHalves needs no change; without it here
    // the state would survive a reset and smear between frames.
    if (!root) { return; }
    root.querySelectorAll('.half, .fx').forEach(function (el) {
        el.classList.remove('gone', 'fading', 'arriving', 'shown');
    });
    root.querySelectorAll('[id^="actor-"]').forEach(function (el) {
        el.removeAttribute('transform');
    });
}

function paintHalves(root, halves) {
    // VIEW: apply per-chunk visual states within one panel (TERMINAL)
    //
    // "shown" exists to beat the "pending" class the generator puts on slots
    // that do not exist at rest. Without it an arriving chunk stays invisible,
    // because pending sets opacity to zero and nothing removes it.
    if (!root) { return; }
    Object.keys(halves).forEach(function (id) {
        var el = root.querySelector('#' + id);
        if (!el) { return; }
        switch (halves[id]) {
            case 'gone':     el.classList.add('gone'); break;
            case 'fading':   el.classList.add('shown', 'fading'); break;
            case 'arriving': el.classList.add('shown', 'arriving'); break;
            case 'present':  el.classList.add('shown'); break;
        }
    });
}

function paintActors(root, actors) {
    // VIEW: translate moving glyphs within one panel (TERMINAL)
    if (!root) { return; }
    Object.keys(actors).forEach(function (id) {
        var el = root.querySelector('#' + id);
        if (el) { el.setAttribute('transform', 'translate(' + actors[id] + ',0)'); }
    });
}

function paintDerived(root) {
    // VIEW: zone tints and Ku position, computed from the DNA (TERMINAL)
    //
    // Neither is declared in a frame table. A repeat is duplex when both
    // halves are visible, overhang when only the top is, and absent when
    // neither. Ku threads onto duplex ends, so it belongs flush against the
    // last duplex repeat. Deriving both here means they cannot disagree with
    // the strands they describe, and adding an animated panel still needs no
    // new code.
    //
    // The three numbers repeat make_panels.py's geometry: first chunk left
    // edge, chunk width, slot count.
    if (!root) { return; }

    var X0 = 50, CW = 42, SLOTS = 18;
    // Strand rows, mirroring TOP_Y, BOT_Y, SH in tools/make_panels.py.
    var TOP_Y = 139, BOT_Y = 161, SH = 13;

    // How far left the array runs. Panels that draw unique sequence declare it
    // on the .dna group, and the loop starts there instead of at chunk 1.
    // Without this the derivation stops at the boundary: Ku would park on the
    // first repeat while the resection front carried on into unique sequence,
    // which is the one thing branch C exists to show.
    var dna = root.querySelector('.dna');
    var nUnique = dna ? parseInt(dna.getAttribute('data-unique'), 10) : 0;
    if (!(nUnique > 0)) { nUnique = 0; }

    // "None found" can no longer be written as zero, because zero is now a
    // chunk. A telomere resected to its first repeat would otherwise read as
    // having no duplex at all and Ku would stop tracking one chunk early.
    var lastDuplex = 0, foundDuplex = false;
    // Rightmost chunk still present on each strand. These are the two ends of
    // the molecule: the 3' end is the far side of the last G block, the 5' end
    // the far side of the last C block, and the gap between them is the
    // overhang. Neither is a fixed coordinate. Elongation moves the first out
    // and resection moves the second in, so both are read rather than declared.
    var lastTop = null, lastBot = null;
    var duplex = {};
    // How many telomeric repeats are duplex, which is how many Rap1 can be
    // loaded. Counted over chunks 1 and up only: unique sequence is not Rap1
    // substrate, and branch C resects into it.
    var duplexCount = 0;

    for (var i = 1 - nUnique; i <= SLOTS; i++) {
        var id = chunkId(i);
        var top = isShowing(root.querySelector('#' + id + '-t'));
        var bot = isShowing(root.querySelector('#' + id + '-b'));
        var zone = root.querySelector('#z-' + id);
        duplex[i] = top && bot;
        if (zone) {
            zone.setAttribute('class',
                'zone ' + (top && bot ? 'dup' : (top ? 'ov' : 'off')));
        }
        if (top && bot) { lastDuplex = i; foundDuplex = true; }
        if (top && bot && i >= 1) { duplexCount++; }
        if (top) { lastTop = i; }
        if (bot) { lastBot = i; }
    }

    placeEndLabel(root.querySelector('#end3'), lastTop, TOP_Y + SH, 8, true);
    placeEndLabel(root.querySelector('#end5'), lastBot, BOT_Y + SH + 12, -1, false);

    // Rap1 binds double-stranded DNA, so a box goes when either of its two
    // repeats stops being duplex. This only ever hides: a frame may already
    // have hidden a box for its own reason, as the Rap1-loss branch does, and
    // the derivation must not put it back.
    root.querySelectorAll('.rap1[data-span]').forEach(function (box) {
        var st = parseInt(box.getAttribute('data-span'), 10);
        if (!(duplex[st] && duplex[st + 1])) { box.classList.add('gone'); }
    });

    // With no duplex left in the drawn region the junction is somewhere off to
    // the left of it, so Ku goes one chunk past the lower bound. Holding the
    // previous position is not an option: clearAnimationClasses strips every
    // actor transform at the start of each frame, so "leave it alone" sends Ku
    // back to its resting coordinate, which in a panned panel is off the far
    // right edge at the exact moment it should be furthest left.
    if (!foundDuplex) { lastDuplex = (1 - nUnique) - 1; }

    var kuGlyph = root.querySelector('#actor-ku');
    if (kuGlyph) {
        var base = parseFloat(kuGlyph.getAttribute('data-basex'));
        var junction = X0 + lastDuplex * CW - 20;
        if (!isNaN(base)) {
            kuGlyph.setAttribute('transform',
                'translate(' + (junction - base) + ',0)');
        }
    }

    paintCapBar(root, duplexCount, lastTop, lastBot, isShowing(kuGlyph));

    function isShowing(el) {
        // MODEL: is this half visible in the current frame (TERMINAL)
        //
        // Handles both rest and mid-animation. "pending" survives a reset, so
        // a pending slot counts only once a frame has added "shown".
        if (!el) { return false; }
        if (el.classList.contains('gone')) { return false; }
        return !el.classList.contains('pending') ||
                el.classList.contains('shown');
    }
}

// The threshold and the words repeat CAP_FULL_ARRAY and CAP_WORDS in
// tools/make_panels.py. Both sides derive the same states from the same
// quantities: Python for the resting picture a static panel keeps and the
// rasteriser resolves, this for every frame. tools/test_engine.js asserts the
// two agree at frame 0 of every panel, which is what keeps the duplication from
// drifting the way X0 and CW would.
var CAP_FULL_ARRAY = 12;
var CAP_WORDS = {
    rap1: { on: 'full array', thin: 'short array', off: 'none bound',
            na: 'no duplex', lost: 'array lost' },
    cst:  { on: 'assembled', thin: 'Cdc13 only', off: 'none established',
            na: 'no overhang', lost: 'CST lost' },
    ku:   { on: 'bound', thin: 'partial', off: 'none established',
            na: 'no junction', lost: 'Ku lost' }
};
var CAP_CLASSES = ['on', 'thin', 'off', 'na', 'lost'];

function paintCapBar(root, duplexCount, lastTop, lastBot, kuShown) {
    // VIEW: the three cap slots, from the DNA and what is drawn on it
    // (TERMINAL)
    //
    // Declared per panel, these went stale the moment a frame table changed the
    // telomere under them: branch C ended with a visibly receded array and a
    // pill still claiming a complete one. Derived, they cannot.
    //
    // Four states derive. lost does not, because absence of a glyph is not
    // evidence of loss and because it is an experimental condition rather than
    // a rung on the ladder. A slot whose declared loss pill is showing is left
    // alone entirely, or the derivation would quietly rewrite branch D's lost
    // array to "no duplex" once erosion took the substrate away, which is the
    // causal claim that branch exists to make.
    if (!root) { return; }

    var overhang = lastTop !== null && (lastBot === null || lastTop > lastBot);
    var hasTrimer = shownIn('.cst');
    var hasCdc13 = shownIn('.cdc13');

    var state = {
        rap1: duplexCount <= 0 ? 'na'
                               : (duplexCount >= CAP_FULL_ARRAY ? 'on' : 'thin'),
        cst: hasTrimer ? 'on'
                       : (hasCdc13 ? 'thin' : (overhang ? 'off' : 'na')),
        ku: kuShown ? 'on' : (duplexCount > 0 ? 'off' : 'na')
    };

    Object.keys(state).forEach(function (slot) {
        var flip = root.querySelector('#capflip-' + slot);
        if (flip && flip.classList.contains('shown')) { return; }
        setSlot(slot, state[slot]);
    });

    function setSlot(slot, st) {
        // VIEW: write one slot's state onto its pill, label and word (TERMINAL)
        ['capbase-', 'capbaselab-', 'capbasest-'].forEach(function (prefix) {
            var el = root.querySelector('#' + prefix + slot);
            if (!el) { return; }
            CAP_CLASSES.forEach(function (c) { el.classList.remove(c); });
            el.classList.add(st);
        });
        var word = root.querySelector('#capbasest-' + slot);
        if (word) { word.textContent = CAP_WORDS[slot][st]; }
    }

    function shownIn(sel) {
        // MODEL: is any element matching sel visible in this frame (TERMINAL)
        var found = false;
        root.querySelectorAll(sel).forEach(function (el) {
            if (el.classList.contains('gone')) { return; }
            if (el.classList.contains('pending') &&
                !el.classList.contains('shown')) { return; }
            // A glyph inside a group the frame table has hidden is hidden too,
            // which is how branch C removes the trimer: the fade is on the
            // wrapper and not on .cst itself.
            var p = el.parentNode;
            while (p && p.classList) {
                if (p.classList.contains('gone')) { return; }
                if (p.classList.contains('pending') &&
                    !p.classList.contains('shown')) { return; }
                p = p.parentNode;
            }
            found = true;
        });
        return found;
    }
}

function paintTransport() {
    // VIEW: sync the play button and scrubber to engine state (TERMINAL)
    var bar = document.getElementById('transport');
    if (!bar) { return; }

    if (!animState.key) {
        bar.classList.remove('on');
        return;
    }
    bar.classList.add('on');

    var total = frameCount(animState.key);
    var btn = document.getElementById('playbtn');
    btn.textContent = animState.playing ? 'Pause' : 'Play';
    btn.setAttribute('aria-label', animState.playing ? 'Pause' : 'Play');

    var slider = document.getElementById('scrub');
    slider.max = total - 1;
    slider.value = animState.frame;

    document.getElementById('framelab').textContent =
        ANIM[animState.key].label + ' \u2014 frame ' +
        (animState.frame + 1) + ' of ' + total;
}