/* Animation frame tables.

   One entry per animated panel. Each frame declares the COMPLETE state of
   every half it touches, rather than a change from the previous frame. That is
   verbose and much easier to debug, and it means any single frame renders
   correctly on its own, which matters when a frame is pulled out as a static
   dissertation figure.

   Half states
     "gone"      not present, invisible
     "fading"    mid-removal, gray
     "arriving"  mid-addition, gray
     "present"   normal DNA

   A half the frame does not name keeps whatever the panel markup gave it:
   visible for chunks that exist at rest, hidden for slots the generator marked
   pending. So removal animations only name the halves they remove, and
   addition animations must name every slot they will eventually fill.

   actors   ids of glyph groups mapped to an x offset in panel units.

   Chunks 1-10 are duplex throughout. 11-14 are the overhang region. 15-18 are
   the slots elongation fills.

   The three loss branches all open on the step 9 state and take it apart, so
   their frame 0 is the same picture. Nothing in them names a zone or a Rap1
   box: both are derived from chunk visibility in animate.js, so removing DNA
   is enough to make the array recede with it.

   Ids beginning rpa- or fx- are not strand halves. Neither is actor-pola,
   which appears in both maps: "actors" moves it and "halves" turns it off once
   fill-in is done. An id may legitimately be in both.

   Ids beginning rpa- are not strand halves. They are ".fx" glyphs, which carry
   the same four states and are driven by the same engine code; the only thing
   that knows the difference is the reset in animate.js.
*/

const ANIM = {

  /* Leading-strand synthesis. The parental C-strand is there at frame 0 and
     the G-strand is not; the replisome enters from the unique block and the
     new strand arrives left to right until it reaches the terminus.

     Nothing here names a Rap1 box, a zone tint, or Ku. All three are derived
     from chunk visibility in animate.js, so the array populates and the
     junction advances as a consequence of the DNA arriving rather than as a
     second declaration that could disagree with it.

     Ku and MRX are the exception, and they are wrapped in fx rather than
     placed. Derived from visibility alone Ku would sit at the growing end and
     travel with the fork, which is a claim about loading that nothing
     supports. Both appear on the last frame, on an end that exists. */
  step01: {
    fps: 1.4,
    label: "Leading-strand synthesis",
    frames: [
      { actors: { "actor-repl": 0 },
        halves: { "c01-t": "gone", "c02-t": "gone", "c03-t": "gone", "c04-t": "gone", "c05-t": "gone",
                  "c06-t": "gone", "c07-t": "gone", "c08-t": "gone", "c09-t": "gone", "c10-t": "gone",
                  "c11-t": "gone", "c12-t": "gone", "c13-t": "gone", "c14-t": "gone" } },

      { actors: { "actor-repl": 84 },
        halves: { "c01-t": "arriving", "c02-t": "arriving", "c03-t": "gone", "c04-t": "gone", "c05-t": "gone",
                  "c06-t": "gone", "c07-t": "gone", "c08-t": "gone", "c09-t": "gone", "c10-t": "gone",
                  "c11-t": "gone", "c12-t": "gone", "c13-t": "gone", "c14-t": "gone" } },

      { actors: { "actor-repl": 168 },
        halves: { "c01-t": "present", "c02-t": "present", "c03-t": "arriving", "c04-t": "arriving", "c05-t": "gone",
                  "c06-t": "gone", "c07-t": "gone", "c08-t": "gone", "c09-t": "gone", "c10-t": "gone",
                  "c11-t": "gone", "c12-t": "gone", "c13-t": "gone", "c14-t": "gone" } },

      { actors: { "actor-repl": 252 },
        halves: { "c01-t": "present", "c02-t": "present", "c03-t": "present", "c04-t": "present", "c05-t": "arriving",
                  "c06-t": "arriving", "c07-t": "gone", "c08-t": "gone", "c09-t": "gone", "c10-t": "gone",
                  "c11-t": "gone", "c12-t": "gone", "c13-t": "gone", "c14-t": "gone" } },

      { actors: { "actor-repl": 336 },
        halves: { "c01-t": "present", "c02-t": "present", "c03-t": "present", "c04-t": "present", "c05-t": "present",
                  "c06-t": "present", "c07-t": "arriving", "c08-t": "arriving", "c09-t": "gone", "c10-t": "gone",
                  "c11-t": "gone", "c12-t": "gone", "c13-t": "gone", "c14-t": "gone" } },

      { actors: { "actor-repl": 420 },
        halves: { "c01-t": "present", "c02-t": "present", "c03-t": "present", "c04-t": "present", "c05-t": "present",
                  "c06-t": "present", "c07-t": "present", "c08-t": "present", "c09-t": "arriving", "c10-t": "arriving",
                  "c11-t": "gone", "c12-t": "gone", "c13-t": "gone", "c14-t": "gone" } },

      { actors: { "actor-repl": 504 },
        halves: { "c01-t": "present", "c02-t": "present", "c03-t": "present", "c04-t": "present", "c05-t": "present",
                  "c06-t": "present", "c07-t": "present", "c08-t": "present", "c09-t": "present", "c10-t": "present",
                  "c11-t": "arriving", "c12-t": "arriving", "c13-t": "gone", "c14-t": "gone" } },

      { actors: { "actor-repl": 588 },
        halves: { "c01-t": "present", "c02-t": "present", "c03-t": "present", "c04-t": "present", "c05-t": "present",
                  "c06-t": "present", "c07-t": "present", "c08-t": "present", "c09-t": "present", "c10-t": "present",
                  "c11-t": "present", "c12-t": "present", "c13-t": "arriving", "c14-t": "arriving" } },

      /* The blunt product. The replisome is gone rather than parked, because
         panel 2 opens on this frame and has no fork in it; Ku and MRX arrive
         on an end that now exists; and the bracket and the terminus label are
         statements about a finished array, so they wait for one. */
      { actors: { "actor-repl": 588 },
        halves: { "c01-t": "present", "c02-t": "present", "c03-t": "present", "c04-t": "present", "c05-t": "present",
                  "c06-t": "present", "c07-t": "present", "c08-t": "present", "c09-t": "present", "c10-t": "present",
                  "c11-t": "present", "c12-t": "present", "c13-t": "present", "c14-t": "present",
                  "actor-repl": "gone",
                  "fx-ku01": "present", "fx-mrx01": "present",
                  "fx-blunt01": "present", "fx-bracket01": "present" } }
    ]
  },

  /* Lagging-strand synthesis. The other half of the same fork passage, on
     the strand that cannot be copied continuously.

     Frame 0 is the parental G-strand alone. Five Okazaki fragments follow,
     each primed at its distal edge and extended leftward until it meets the
     one before it, so the priming sites march toward the terminus while
     synthesis runs the other way. Pol alpha-primase is the same glyph panel 8
     uses and points the same way, because it is the same enzyme doing the same
     thing.

     The last three frames are the part that matters. Rad27 clears the four
     internal primers and the DNA that replaces them stays, so nothing on the
     strand changes. RNase H2 takes the terminal primer, and no polymerase can
     fill that gap because there is no 3' end distal to it. Chunk 14 goes bare
     and stays bare. That is the overhang, and it is also the end-replication
     problem: what is lost is set by where the last primer landed. */
  lag01: {
    fps: 1.4,
    label: "Lagging-strand synthesis",
    frames: [
      { actors: { "actor-lagpol": 0, "actor-lagpold": 0 },
        halves: { "c01-b": "gone", "c02-b": "gone", "c03-b": "gone", "c04-b": "gone", "c05-b": "gone",
                  "c06-b": "gone", "c07-b": "gone", "c08-b": "gone", "c09-b": "gone", "c10-b": "gone",
                  "c11-b": "gone", "c12-b": "gone", "c13-b": "gone", "c14-b": "gone",
                  "pr-c03": "gone", "pr-c06": "gone", "pr-c09": "gone", "pr-c12": "gone", "pr-c14": "gone" } },

      { actors: { "actor-lagpol": 0, "actor-lagpold": 0 },
        halves: { "c01-b": "gone", "c02-b": "gone", "c03-b": "arriving", "c04-b": "gone", "c05-b": "gone",
                  "c06-b": "gone", "c07-b": "gone", "c08-b": "gone", "c09-b": "gone", "c10-b": "gone",
                  "c11-b": "gone", "c12-b": "gone", "c13-b": "gone", "c14-b": "gone",
                  "pr-c03": "present", "pr-c06": "gone", "pr-c09": "gone", "pr-c12": "gone", "pr-c14": "gone" } },

      /* The alpha-segment is down, so the handoff can be drawn. */
      { actors: { "actor-lagpol": 0, "actor-lagpold": 0 },
        halves: { "c01-b": "arriving", "c02-b": "arriving", "c03-b": "present", "c04-b": "gone", "c05-b": "gone",
                  "c06-b": "gone", "c07-b": "gone", "c08-b": "gone", "c09-b": "gone", "c10-b": "gone",
                  "c11-b": "gone", "c12-b": "gone", "c13-b": "gone", "c14-b": "gone",
                  "pr-c03": "present", "pr-c06": "gone", "pr-c09": "gone", "pr-c12": "gone", "pr-c14": "gone",
                  "fx-poldelta": "arriving" } },

      { actors: { "actor-lagpol": 126, "actor-lagpold": 126 },
        halves: { "c01-b": "present", "c02-b": "present", "c03-b": "present", "c04-b": "gone", "c05-b": "gone",
                  "c06-b": "arriving", "c07-b": "gone", "c08-b": "gone", "c09-b": "gone", "c10-b": "gone",
                  "c11-b": "gone", "c12-b": "gone", "c13-b": "gone", "c14-b": "gone",
                  "pr-c03": "present", "pr-c06": "present", "pr-c09": "gone", "pr-c12": "gone", "pr-c14": "gone",
                  "fx-poldelta": "present" } },

      { actors: { "actor-lagpol": 126, "actor-lagpold": 126 },
        halves: { "c01-b": "present", "c02-b": "present", "c03-b": "present", "c04-b": "arriving", "c05-b": "arriving",
                  "c06-b": "present", "c07-b": "gone", "c08-b": "gone", "c09-b": "gone", "c10-b": "gone",
                  "c11-b": "gone", "c12-b": "gone", "c13-b": "gone", "c14-b": "gone",
                  "pr-c03": "present", "pr-c06": "present", "pr-c09": "gone", "pr-c12": "gone", "pr-c14": "gone",
                  "fx-poldelta": "present" } },

      { actors: { "actor-lagpol": 252, "actor-lagpold": 252 },
        halves: { "c01-b": "present", "c02-b": "present", "c03-b": "present", "c04-b": "present", "c05-b": "present",
                  "c06-b": "present", "c07-b": "gone", "c08-b": "gone", "c09-b": "arriving", "c10-b": "gone",
                  "c11-b": "gone", "c12-b": "gone", "c13-b": "gone", "c14-b": "gone",
                  "pr-c03": "present", "pr-c06": "present", "pr-c09": "present", "pr-c12": "gone", "pr-c14": "gone",
                  "fx-poldelta": "present" } },

      { actors: { "actor-lagpol": 252, "actor-lagpold": 252 },
        halves: { "c01-b": "present", "c02-b": "present", "c03-b": "present", "c04-b": "present", "c05-b": "present",
                  "c06-b": "present", "c07-b": "arriving", "c08-b": "arriving", "c09-b": "present", "c10-b": "gone",
                  "c11-b": "gone", "c12-b": "gone", "c13-b": "gone", "c14-b": "gone",
                  "pr-c03": "present", "pr-c06": "present", "pr-c09": "present", "pr-c12": "gone", "pr-c14": "gone",
                  "fx-poldelta": "present" } },

      { actors: { "actor-lagpol": 378, "actor-lagpold": 378 },
        halves: { "c01-b": "present", "c02-b": "present", "c03-b": "present", "c04-b": "present", "c05-b": "present",
                  "c06-b": "present", "c07-b": "present", "c08-b": "present", "c09-b": "present", "c10-b": "gone",
                  "c11-b": "gone", "c12-b": "arriving", "c13-b": "gone", "c14-b": "gone",
                  "pr-c03": "present", "pr-c06": "present", "pr-c09": "present", "pr-c12": "present", "pr-c14": "gone",
                  "fx-poldelta": "present" } },

      { actors: { "actor-lagpol": 378, "actor-lagpold": 378 },
        halves: { "c01-b": "present", "c02-b": "present", "c03-b": "present", "c04-b": "present", "c05-b": "present",
                  "c06-b": "present", "c07-b": "present", "c08-b": "present", "c09-b": "present", "c10-b": "arriving",
                  "c11-b": "arriving", "c12-b": "present", "c13-b": "gone", "c14-b": "gone",
                  "pr-c03": "present", "pr-c06": "present", "pr-c09": "present", "pr-c12": "present", "pr-c14": "gone",
                  "fx-poldelta": "present" } },

      { actors: { "actor-lagpol": 462, "actor-lagpold": 462 },
        halves: { "c01-b": "present", "c02-b": "present", "c03-b": "present", "c04-b": "present", "c05-b": "present",
                  "c06-b": "present", "c07-b": "present", "c08-b": "present", "c09-b": "present", "c10-b": "present",
                  "c11-b": "present", "c12-b": "present", "c13-b": "gone", "c14-b": "arriving",
                  "pr-c03": "present", "pr-c06": "present", "pr-c09": "present", "pr-c12": "present", "pr-c14": "present",
                  "fx-poldelta": "present" } },

      { actors: { "actor-lagpol": 462, "actor-lagpold": 462 },
        halves: { "c01-b": "present", "c02-b": "present", "c03-b": "present", "c04-b": "present", "c05-b": "present",
                  "c06-b": "present", "c07-b": "present", "c08-b": "present", "c09-b": "present", "c10-b": "present",
                  "c11-b": "present", "c12-b": "present", "c13-b": "arriving", "c14-b": "present",
                  "pr-c03": "present", "pr-c06": "present", "pr-c09": "present", "pr-c12": "present", "pr-c14": "present",
                  "fx-poldelta": "present" } },

      /* Every fragment laid, every primer still in place. Both polymerase
         arrows go together, because the handoff they draw is finished.

         The four frames from here to the terminal primer are the maturation
         sequence, and the order in them is the claim. Both agents are on
         screen and at full opacity before any primer clears, so a reader sees
         who does the work before seeing the work done. Clearing a primer on
         the frame its agent fades in would read as the primer going of its own
         accord, with the box arriving to describe it after the fact. */
      { actors: {},
        halves: { "c01-b": "present", "c02-b": "present", "c03-b": "present", "c04-b": "present", "c05-b": "present",
                  "c06-b": "present", "c07-b": "present", "c08-b": "present", "c09-b": "present", "c10-b": "present",
                  "c11-b": "present", "c12-b": "present", "c13-b": "present", "c14-b": "present",
                  "pr-c03": "present", "pr-c06": "present", "pr-c09": "present", "pr-c12": "present", "pr-c14": "present",
                  "actor-lagpol": "gone", "fx-poldelta": "gone", "fx-rad27": "arriving" } },

      /* Rad27 at full opacity, Cdc9 fading in beside it. Nothing on the
         strand yet. */
      { actors: {},
        halves: { "c01-b": "present", "c02-b": "present", "c03-b": "present", "c04-b": "present", "c05-b": "present",
                  "c06-b": "present", "c07-b": "present", "c08-b": "present", "c09-b": "present", "c10-b": "present",
                  "c11-b": "present", "c12-b": "present", "c13-b": "present", "c14-b": "present",
                  "pr-c03": "present", "pr-c06": "present", "pr-c09": "present", "pr-c12": "present", "pr-c14": "present",
                  "actor-lagpol": "gone", "fx-poldelta": "gone", "fx-rad27": "present", "fx-cdc9": "arriving" } },

      /* Both agents up, both labels readable, every primer still in place.
         This frame changes nothing and exists for that reason: it is the beat
         that separates naming the agents from showing what they do. */
      { actors: {},
        halves: { "c01-b": "present", "c02-b": "present", "c03-b": "present", "c04-b": "present", "c05-b": "present",
                  "c06-b": "present", "c07-b": "present", "c08-b": "present", "c09-b": "present", "c10-b": "present",
                  "c11-b": "present", "c12-b": "present", "c13-b": "present", "c14-b": "present",
                  "pr-c03": "present", "pr-c06": "present", "pr-c09": "present", "pr-c12": "present", "pr-c14": "present",
                  "actor-lagpol": "gone", "fx-poldelta": "gone", "fx-rad27": "present", "fx-cdc9": "present" } },

      /* Now the internal primers clear. Nothing else on the strand changes,
         which is the point: each of these four gaps is fillable because it has
         a 3' end upstream of it, and the DNA underneath the hatching was drawn
         all along. What goes is the overlay, not a repeat. */
      { actors: {},
        halves: { "c01-b": "present", "c02-b": "present", "c03-b": "present", "c04-b": "present", "c05-b": "present",
                  "c06-b": "present", "c07-b": "present", "c08-b": "present", "c09-b": "present", "c10-b": "present",
                  "c11-b": "present", "c12-b": "present", "c13-b": "present", "c14-b": "present",
                  "pr-c03": "gone", "pr-c06": "gone", "pr-c09": "gone", "pr-c12": "gone", "pr-c14": "present",
                  "actor-lagpol": "gone", "fx-poldelta": "gone", "fx-rad27": "present", "fx-cdc9": "present" } },

      /* The terminal primer starts to go, and it gets its own beat because
         its fate is the one that differs. */
      { actors: {},
        halves: { "c01-b": "present", "c02-b": "present", "c03-b": "present", "c04-b": "present", "c05-b": "present",
                  "c06-b": "present", "c07-b": "present", "c08-b": "present", "c09-b": "present", "c10-b": "present",
                  "c11-b": "present", "c12-b": "present", "c13-b": "present", "c14-b": "present",
                  "pr-c03": "gone", "pr-c06": "gone", "pr-c09": "gone", "pr-c12": "gone", "pr-c14": "fading",
                  "actor-lagpol": "gone", "fx-poldelta": "gone", "fx-rad27": "present", "fx-cdc9": "present", "fx-termprimer": "arriving" } },

      /* It goes and nothing replaces it. No protein glyph arrives with it:
         which activity removes it is not established in yeast, so the panel
         shows the event and leaves the agent unnamed. Ku appears on the
         junction that now exists, and the bracket names the tail. */
      { actors: {},
        halves: { "c01-b": "present", "c02-b": "present", "c03-b": "present", "c04-b": "present", "c05-b": "present",
                  "c06-b": "present", "c07-b": "present", "c08-b": "present", "c09-b": "present", "c10-b": "present",
                  "c11-b": "present", "c12-b": "present", "c13-b": "present", "c14-b": "gone",
                  "pr-c03": "gone", "pr-c06": "gone", "pr-c09": "gone", "pr-c12": "gone", "pr-c14": "gone",
                  "actor-lagpol": "gone", "fx-poldelta": "gone", "fx-rad27": "present", "fx-cdc9": "present", "fx-termprimer": "present", "fx-ku-lag": "present", "fx-lagtail": "present" } },
    ]
  },

  /* Resection. Exo1 and Sgs1-Dna2 start near the terminus and travel inward,
     5' to 3' along the C-strand, clearing it and leaving the G-strand as the
     overhang. Offsets are negative because the enzymes move leftward, in step
     with the chunks they are removing. Each chunk grays out one frame before
     it vanishes, so the eye can follow which unit went.

     RPA lands on each repeat the frame after that repeat's C-strand half is
     gone, following the nucleases inward. Chunks 13 and 14 get no RPA: Mre11
     is clearing 14 and Rad50 covers 13, so only 12 and 11 are drawn. The last
     frame adds no motion; it exists so the finished state shows both units at
     full colour rather than mid-arrival. */
  step03: {
    fps: 1.3,
    label: "Resection",
    frames: [
      /* The cap indicator changes state inside this panel, which is what the
         flip slots are for. Frames 0 and 1 still have a C-strand running to the
         terminus, so there is no single-stranded TG1-3 anywhere and the CST
         slot reads na. From frame 2 there is, and nothing telomere-specific is
         on it: RPA holds that strand and RPA is not CST. The slot reads off
         from there, and panel 4 is where it stops being true. */
      { actors: { "actor-exo1": 0, "actor-sgs1": 0 },
        halves: { "rpa-c13": "gone", "rpa-c12": "gone", "rpa-c11": "gone",
                  "actor-mrx": "present", "fx-nick03": "present" } },

      /* Mre11 parts its two lobes over the repeat distal to the nick, which is
         the one it clears going 3' to 5' toward the terminus. Without this the
         panel claims bidirectionality in the caption and shows one direction:
         everything else on screen travels left. */
      { actors: { "actor-exo1": -42, "actor-sgs1": -42,
                  "actor-mrx-lobeL": -11, "actor-mrx-lobeR": 11 },
        halves: { "c14-b": "fading",
                  "rpa-c13": "gone", "rpa-c12": "gone", "rpa-c11": "gone",
                  "actor-mrx": "present", "fx-nick03": "present" } },

      /* Lobes back together, the distal fragment is gone, and MRX starts to
         leave on the same frame.

         The release is not housekeeping. MRX residence at an end is a dwell
         governed by the Rad50 ATP cycle rather than a fixture, which is the
         handle Rif2 pulls in panel 1 and branch B by discharging the ATP-bound
         state; and the cut is what licenses the release, since Mre11 residence
         at a break is prolonged when Sae2 cannot activate the incision. By this
         frame MRX has made its cut, cleared the fragment it was going to clear,
         and loaded the two nucleases that do the rest, and that loading
         contribution is nuclease-independent and already made.

         What it must not do is stay. The repeat under it is single-stranded
         now, which is not its substrate, and a complex parked there competes
         with the panel 4 claim about who occupies that strand. What it must
         not do either is follow the front: MRX has no translocase and does not
         track resection, and the thing loaded at the leading edge is 9-1-1 and
         RPA. So it fades where it stands, and panel 4's junction MRX is a
         separate binding event.

         The nick goes with it. Once the 5' end has been carried past the
         incision site there is no discontinuity there to draw.

         This is also the frame the first single-stranded repeat exists on, so
         the CST slot flips here. */
      { actors: { "actor-exo1": -84, "actor-sgs1": -84 },
        halves: { "c14-b": "gone", "c13-b": "fading",
                  "rpa-c13": "gone", "rpa-c12": "gone", "rpa-c11": "gone",
                  "actor-mrx": "fading", "fx-nick03": "fading" } },

      /* Chunk 13 comes off and its RPA lands on the same beat, which is the
         cadence the rest of the panel already runs and the one panel 3* runs
         throughout. MRX is gone by now, so nothing is over this repeat. */
      { actors: { "actor-exo1": -126, "actor-sgs1": -126 },
        halves: { "c14-b": "gone", "c13-b": "gone", "c12-b": "fading",
                  "rpa-c13": "arriving", "rpa-c12": "gone", "rpa-c11": "gone",
                  "actor-mrx": "gone", "fx-nick03": "gone" } },

      { actors: { "actor-exo1": -168, "actor-sgs1": -168 },
        halves: { "c14-b": "gone", "c13-b": "gone", "c12-b": "gone",
                  "c11-b": "fading",
                  "rpa-c13": "present", "rpa-c12": "arriving", "rpa-c11": "gone",
                  "actor-mrx": "gone", "fx-nick03": "gone" } },

      { actors: { "actor-exo1": -180, "actor-sgs1": -180 },
        halves: { "c14-b": "gone", "c13-b": "gone", "c12-b": "gone",
                  "c11-b": "gone",
                  "rpa-c13": "present", "rpa-c12": "present",
                  "rpa-c11": "arriving",
                  "actor-mrx": "gone", "fx-nick03": "gone" } },

      { actors: { "actor-exo1": -180, "actor-sgs1": -180 },
        halves: { "c14-b": "gone", "c13-b": "gone", "c12-b": "gone",
                  "c11-b": "gone",
                  "rpa-c13": "present", "rpa-c12": "present",
                  "rpa-c11": "present",
                  "actor-mrx": "gone", "fx-nick03": "gone" } }
    ]
  },

  /* Unidirectional resection, on the lagging-strand end.

     Panel 3's inward arm, on its own. There is no incision to flash and no
     Mre11 3' to 5' arm, because the 5' end these two load on was left by
     primer removal rather than made by a cut. The offsets, the stacking and
     the RPA cadence are panel 3's, because it is the same reaction.

     MRX fades on the same schedule as in panel 3 and for the same reason,
     minus the incision half of it: its contribution here is loading Exo1 and
     Sgs1-Dna2, that contribution is nuclease-independent and made at the end,
     and the complex neither tracks the front nor belongs on the strand behind
     it.

     Ends with the C-strand at chunk 10, which is where panel 3 ends. */
  lag03: {
    fps: 1.3,
    label: "Resection",
    frames: [
      { actors: { "actor-exo1": 0, "actor-sgs1": 0 },
        halves: { "rpa-c13": "gone", "rpa-c12": "gone", "rpa-c11": "gone",
                  "actor-mrx": "present" } },

      { actors: { "actor-exo1": 0, "actor-sgs1": 0 },
        halves: { "c13-b": "fading",
                  "rpa-c13": "gone", "rpa-c12": "gone", "rpa-c11": "gone",
                  "actor-mrx": "present" } },

      { actors: { "actor-exo1": -42, "actor-sgs1": -42 },
        halves: { "c13-b": "gone", "c12-b": "fading",
                  "rpa-c13": "arriving", "rpa-c12": "gone", "rpa-c11": "gone",
                  "actor-mrx": "fading" } },

      { actors: { "actor-exo1": -84, "actor-sgs1": -84 },
        halves: { "c13-b": "gone", "c12-b": "gone", "c11-b": "fading",
                  "rpa-c13": "present", "rpa-c12": "arriving", "rpa-c11": "gone",
                  "actor-mrx": "gone" } },

      { actors: { "actor-exo1": -126, "actor-sgs1": -126 },
        halves: { "c13-b": "gone", "c12-b": "gone", "c11-b": "gone",
                  "rpa-c13": "present", "rpa-c12": "present",
                  "rpa-c11": "arriving",
                  "actor-mrx": "gone" } },

      { actors: { "actor-exo1": -126, "actor-sgs1": -126 },
        halves: { "c13-b": "gone", "c12-b": "gone", "c11-b": "gone",
                  "rpa-c13": "present", "rpa-c12": "present",
                  "rpa-c11": "present",
                  "actor-mrx": "gone" } }
    ]
  },

  /* Licensing, in three beats.

     The panel used to draw four events at once: the kinase acting, the mark it
     leaves, the flag flying, and both of Tel1's consequences. All of it was
     true at the same time and none of it was legible, so the frames take one
     claim each.

     Frame 1 is Cdk1 on T308. The mark arrives on this frame rather than being
     drawn from the start, which is what makes it an outcome, and the kinase
     leaves with its arrow immediately afterwards: Cdk1 acts on Cdc13 and is not
     a telomere component, so a box parked at the end for the rest of the panel
     would say it stays.

     Frame 2 is Tel1 taking the docked Xrs2 C-terminus. Frame 3 is what follows
     from that occupancy, both halves of it on one beat because they are one
     event seen twice: the socket Tel1 flies from is the socket Rif2 wants, so
     the exclusion mark and the elongation arrow arrive together.

     The order of frames 1 and 2 is a drawing decision. Cdk1 phosphorylation of
     the recruitment domain and Tel1 occupancy at a short end are both late S
     and nothing establishes a dependency in either direction. The panel carries
     that in its bottom right corner, because the frame numbers are the only
     thing here that asserts a sequence. */
  step05: {
    fps: 0.85,
    label: "Licensing",
    frames: [
      { actors: {},
        halves: { "fx-cdk1": "arriving", "fx-t308": "gone",
                  "fx-tel1": "gone", "fx-tel1arrow": "gone",
                  "fx-socket": "gone" } },

      { actors: {},
        halves: { "fx-cdk1": "present", "fx-t308": "present",
                  "fx-tel1": "arriving", "fx-tel1arrow": "gone",
                  "fx-socket": "gone" } },

      { actors: {},
        halves: { "fx-cdk1": "gone", "fx-t308": "present",
                  "fx-tel1": "present", "fx-tel1arrow": "arriving",
                  "fx-socket": "present" } }
    ]
  },

  /* Elongation. Est2 copies the TLC1 template into DNA, so G-strand chunks
     arrive one at a time and the whole telomerase assembly translocates with
     the growing end rather than sitting still.

     RPA trails it. Cdc13 starts over chunks 11 and 12 and ends over 15 and 16,
     and every repeat the wedge vacates is single-stranded DNA that something
     has to hold, so a unit lands one frame after the wedge clears it. The panel
     therefore ends with the four units panel 7 opens with, and the two can be
     stepped through without RPA appearing from nowhere in between. */
  step06: {
    fps: 1.3,
    label: "Extension",
    frames: [
      /* Telomerase advances. Cdc13 does not. The recruiting molecule made the
         contact that brought the enzyme here and has no further job during
         extension, so it keeps its position and its T308 mark while the enzyme
         runs out past it. Nothing in the model now translocates on DNA except
         enzymes with a documented direction. */
      { actors: { "actor-tel":0 }, halves: {
          "c15-t":"gone", "c16-t":"gone", "c17-t":"gone", "c18-t":"gone" } },

      /* Each new repeat is single-stranded TG1-3 the moment it is made, and
         something binds it. RPA lands one repeat behind the enzyme, the same
         relationship it has to the nucleases in panel 3: substrate appears, a
         binding protein occupies it, and the enzyme owes it nothing.

         Whether new Cdc13 also loads on these repeats is a real question the
         panel does not answer. Both proteins bind single-stranded telomeric
         DNA, and the exclusion argument in panel 4 is stated for the resting
         overhang, not for a tail being extruded. Drawing only RPA is a choice
         to leave that open, not a claim that Cdc13 stays off. */
      { actors: { "actor-tel":30 }, halves: {
          "c15-t":"arriving", "c16-t":"gone", "c17-t":"gone", "c18-t":"gone" } },

      { actors: { "actor-tel":72 }, halves: {
          "c15-t":"present", "c16-t":"arriving", "c17-t":"gone", "c18-t":"gone",
          "rpa-c15":"arriving" } },

      { actors: { "actor-tel":114 }, halves: {
          "c15-t":"present", "c16-t":"present", "c17-t":"arriving", "c18-t":"gone",
          "rpa-c15":"present", "rpa-c16":"arriving" } },

      { actors: { "actor-tel":156 }, halves: {
          "c15-t":"present", "c16-t":"present", "c17-t":"present", "c18-t":"arriving",
          "rpa-c15":"present", "rpa-c16":"present", "rpa-c17":"arriving" } },

      /* Chunk 18 is made but stays bare: the enzyme is on it. That is what
         panel 7 has to remove before the capping complex can take the
         terminus, and it is why CST assembles distally in panel 8 rather than
         arriving from somewhere. */
      { actors: { "actor-tel":168 }, halves: {
          "c15-t":"present", "c16-t":"present", "c17-t":"present", "c18-t":"present",
          "rpa-c15":"present", "rpa-c16":"present", "rpa-c17":"present" } }
    ]
  },

  step08: {
    fps: 1.3,
    label: "Fill-in",
    frames: [
      /* Cdk1 arrives. The DNA is panel 7's telomere untouched, and the
         Cdc13-Est1 block is not on the page yet: it is a consequence of the
         phosphorylation and cannot precede it. */
      { actors: { "actor-pola":0 }, halves: {
          "c17-b":"gone", "c16-b":"gone", "c15-b":"gone", "c14-b":"gone", "c13-b":"gone",
          "c12-b":"gone", "c11-b":"gone", "fx-cdk1":"arriving", "fx-stn1p":"gone",
          "fx-est1block":"gone", "fx-est1lab":"gone" } },

      /* The act. T223 and S250 together on one mark, and still no block. */
      { actors: { "actor-pola":0 }, halves: {
          "c17-b":"gone", "c16-b":"gone", "c15-b":"gone", "c14-b":"gone", "c13-b":"gone",
          "c12-b":"gone", "c11-b":"gone", "fx-cdk1":"present", "fx-stn1p":"present",
          "fx-est1block":"gone", "fx-est1lab":"gone" } },

      /* The kinase leaves and the block appears, which is where the panel
         used to open. Everything from here is unchanged. */
      { actors: { "actor-pola":0 }, halves: {
          "c17-b":"gone", "c16-b":"gone", "c15-b":"gone", "c14-b":"gone", "c13-b":"gone",
          "c12-b":"gone", "c11-b":"gone", "fx-cdk1":"fading", "fx-stn1p":"present",
          "fx-est1block":"present", "fx-est1lab":"present" } },

      { actors: { "actor-pola":0 }, halves: {
          "c17-b":"arriving", "c16-b":"gone", "c15-b":"gone", "c14-b":"gone", "c13-b":"gone",
          "c12-b":"gone", "c11-b":"gone", "rpa-c17":"gone", "fx-cdk1":"gone",
          "fx-stn1p":"present", "fx-est1block":"present", "fx-est1lab":"present" } },

      { actors: { "actor-pola":-42 }, halves: {
          "c17-b":"present", "c16-b":"arriving", "c15-b":"gone", "c14-b":"gone",
          "c13-b":"gone", "c12-b":"gone", "c11-b":"gone", "rpa-c17":"gone", "rpa-c16":"gone",
          "fx-cdk1":"gone", "fx-stn1p":"present", "fx-est1block":"present", "fx-est1lab":"present" } },

      { actors: { "actor-pola":-84 }, halves: {
          "c17-b":"present", "c16-b":"present", "c15-b":"arriving", "c14-b":"gone",
          "c13-b":"gone", "c12-b":"gone", "c11-b":"gone", "rpa-c17":"gone", "rpa-c16":"gone",
          "rpa-c15":"gone", "fx-cdk1":"gone", "fx-stn1p":"present", "fx-est1block":"present", "fx-est1lab":"present" } },

      { actors: { "actor-pola":-126 }, halves: {
          "c17-b":"present", "c16-b":"present", "c15-b":"present", "c14-b":"arriving",
          "c13-b":"gone", "c12-b":"gone", "c11-b":"gone", "rpa-c17":"gone", "rpa-c16":"gone",
          "rpa-c15":"gone", "rpa-c14":"gone", "fx-cdk1":"gone", "fx-stn1p":"present",
          "fx-est1block":"present", "fx-est1lab":"present" } },

      { actors: { "actor-pola":-168 }, halves: {
          "c17-b":"present", "c16-b":"present", "c15-b":"present", "c14-b":"present",
          "c13-b":"arriving", "c12-b":"gone", "c11-b":"gone", "rpa-c17":"gone",
          "rpa-c16":"gone", "rpa-c15":"gone", "rpa-c14":"gone", "rpa-c13":"gone",
          "fx-cdk1":"gone", "fx-stn1p":"present", "fx-est1block":"present", "fx-est1lab":"present" } },

      { actors: { "actor-pola":-210 }, halves: {
          "c17-b":"present", "c16-b":"present", "c15-b":"present", "c14-b":"present",
          "c13-b":"present", "c12-b":"arriving", "c11-b":"gone", "rpa-c17":"gone",
          "rpa-c16":"gone", "rpa-c15":"gone", "rpa-c14":"gone", "rpa-c13":"gone",
          "fx-cdk1":"gone", "fx-stn1p":"present", "fx-est1block":"present", "fx-est1lab":"present" } },

      { actors: { "actor-pola":-252 }, halves: {
          "c17-b":"present", "c16-b":"present", "c15-b":"present", "c14-b":"present",
          "c13-b":"present", "c12-b":"present", "c11-b":"arriving", "rpa-c17":"gone",
          "rpa-c16":"gone", "rpa-c15":"gone", "rpa-c14":"gone", "rpa-c13":"gone",
          "actor-cdc13-p":"gone", "fx-cdk1":"gone", "fx-stn1p":"present",
          "fx-est1block":"present", "fx-est1lab":"present" } },

      { actors: { "actor-pola":-252 }, halves: {
          "c17-b":"present", "c16-b":"present", "c15-b":"present", "c14-b":"present",
          "c13-b":"present", "c12-b":"present", "c11-b":"present", "rpa-c17":"gone",
          "rpa-c16":"gone", "rpa-c15":"gone", "rpa-c14":"gone", "rpa-c13":"gone",
          "actor-pola":"gone", "fx-primerlab":"present", "actor-cdc13-p":"gone",
          "fx-cdk1":"gone", "fx-stn1p":"present", "fx-est1block":"present", "fx-est1lab":"present" } },
    ]
  },

  offC: {
    fps: 1.6,
    label: "Uncapping",
    frames: [
      /* The step 9 telomere. Every loss branch opens here, so the mutation is
         something that happens to an intact cap. */
      { actors: {}, halves: {} },

      /* The loss itself, given its own beat. The three branches all open on an
         intact cap, so the mutation has to be visible as an event rather than
         as a difference between frame 0 and whatever frame 1 already does.
         The indicator does not flip yet: the protein is still on the page. */
      { actors: {}, halves: { "actor-cst":"fading" } },

      /* CST lost. Cdc13 goes with it, since Cdc13 is what puts Stn1-Ten1 on the DNA. */
      { actors: {},
        halves: { "capbase-cst":"gone", "capbaselab-cst":"gone", "capbasest-cst":"gone",
                  "capflip-cst":"present", "capfliplab-cst":"present", "capflipst-cst":"present",
                  "actor-cst":"gone", "fx-exo1":"present" } },

      /* Runaway resection, two repeats per frame. Rap1 recedes with the
         C-strand without being named here: paintDerived hides a box once either
         of its repeats stops being duplex. */
      { actors: { "actor-exo1":-84 },
        halves: { "capbase-cst":"gone", "capbaselab-cst":"gone", "capbasest-cst":"gone",
                  "capflip-cst":"present", "capfliplab-cst":"present", "capflipst-cst":"present",
                  "actor-cst":"gone", "fx-exo1":"present", "c17-b":"fading",
                  "c16-b":"fading" } },

      { actors: { "actor-exo1":-168 },
        halves: { "capbase-cst":"gone", "capbaselab-cst":"gone", "capbasest-cst":"gone",
                  "capflip-cst":"present", "capfliplab-cst":"present", "capflipst-cst":"present",
                  "actor-cst":"gone", "fx-exo1":"present", "c17-b":"gone",
                  "rpa-c17":"present", "c16-b":"gone", "rpa-c16":"present",
                  "c15-b":"fading", "c14-b":"fading" } },

      { actors: { "actor-exo1":-252 },
        halves: { "capbase-cst":"gone", "capbaselab-cst":"gone", "capbasest-cst":"gone",
                  "capflip-cst":"present", "capfliplab-cst":"present", "capflipst-cst":"present",
                  "actor-cst":"gone", "fx-exo1":"present", "c17-b":"gone",
                  "rpa-c17":"present", "c16-b":"gone", "rpa-c16":"present",
                  "c15-b":"gone", "rpa-c15":"present", "c14-b":"gone",
                  "rpa-c14":"present", "c13-b":"fading", "c12-b":"fading" } },

      { actors: { "actor-exo1":-336 },
        halves: { "capbase-cst":"gone", "capbaselab-cst":"gone", "capbasest-cst":"gone",
                  "capflip-cst":"present", "capfliplab-cst":"present", "capflipst-cst":"present",
                  "actor-cst":"gone", "fx-exo1":"present", "c17-b":"gone",
                  "rpa-c17":"present", "c16-b":"gone", "rpa-c16":"present",
                  "c15-b":"gone", "rpa-c15":"present", "c14-b":"gone",
                  "rpa-c14":"present", "c13-b":"gone", "rpa-c13":"present",
                  "c12-b":"gone", "rpa-c12":"present", "c11-b":"fading",
                  "c10-b":"fading" } },

      { actors: { "actor-exo1":-420 },
        halves: { "capbase-cst":"gone", "capbaselab-cst":"gone", "capbasest-cst":"gone",
                  "capflip-cst":"present", "capfliplab-cst":"present", "capflipst-cst":"present",
                  "actor-cst":"gone", "fx-exo1":"present", "c17-b":"gone",
                  "rpa-c17":"present", "c16-b":"gone", "rpa-c16":"present",
                  "c15-b":"gone", "rpa-c15":"present", "c14-b":"gone",
                  "rpa-c14":"present", "c13-b":"gone", "rpa-c13":"present",
                  "c12-b":"gone", "rpa-c12":"present", "c11-b":"gone",
                  "rpa-c11":"present", "c10-b":"gone", "rpa-c10":"present",
                  "c09-b":"fading", "c08-b":"fading" } },

      { actors: { "actor-exo1":-504 },
        halves: { "capbase-cst":"gone", "capbaselab-cst":"gone", "capbasest-cst":"gone",
                  "capflip-cst":"present", "capfliplab-cst":"present", "capflipst-cst":"present",
                  "actor-cst":"gone", "fx-exo1":"present", "c17-b":"gone",
                  "rpa-c17":"present", "c16-b":"gone", "rpa-c16":"present",
                  "c15-b":"gone", "rpa-c15":"present", "c14-b":"gone",
                  "rpa-c14":"present", "c13-b":"gone", "rpa-c13":"present",
                  "c12-b":"gone", "rpa-c12":"present", "c11-b":"gone",
                  "rpa-c11":"present", "c10-b":"gone", "rpa-c10":"present",
                  "c09-b":"gone", "rpa-c09":"present", "c08-b":"gone",
                  "rpa-c08":"present", "c07-b":"fading", "c06-b":"fading" } },

      { actors: { "actor-exo1":-588 },
        halves: { "capbase-cst":"gone", "capbaselab-cst":"gone", "capbasest-cst":"gone",
                  "capflip-cst":"present", "capfliplab-cst":"present", "capflipst-cst":"present",
                  "actor-cst":"gone", "fx-exo1":"present", "c17-b":"gone",
                  "rpa-c17":"present", "c16-b":"gone", "rpa-c16":"present",
                  "c15-b":"gone", "rpa-c15":"present", "c14-b":"gone",
                  "rpa-c14":"present", "c13-b":"gone", "rpa-c13":"present",
                  "c12-b":"gone", "rpa-c12":"present", "c11-b":"gone",
                  "rpa-c11":"present", "c10-b":"gone", "rpa-c10":"present",
                  "c09-b":"gone", "rpa-c09":"present", "c08-b":"gone",
                  "rpa-c08":"present", "c07-b":"gone", "rpa-c07":"present",
                  "c06-b":"gone", "rpa-c06":"present", "c05-b":"fading",
                  "c04-b":"fading" } },

      /* The camera starts to pan, and only now, because Exo1 has reached the
         point where the box it travels in would otherwise leave the viewBox.
         Everything anchored to the DNA moves with it; the cap indicator, the
         notes and the checkpoint chain do not. The pan costs the distal end of
         the array, which by this frame is resected G-strand under RPA and is no
         longer what the panel is about. */
      { actors: { "actor-exo1":-672, "actor-camera":84 },
        halves: { "fx-uniquespan":"present",
                  "capbase-cst":"gone", "capbaselab-cst":"gone", "capbasest-cst":"gone",
                  "capflip-cst":"present", "capfliplab-cst":"present", "capflipst-cst":"present",
                  "actor-cst":"gone", "fx-exo1":"present", "c17-b":"gone",
                  "rpa-c17":"present", "c16-b":"gone", "rpa-c16":"present",
                  "c15-b":"gone", "rpa-c15":"present", "c14-b":"gone",
                  "rpa-c14":"present", "c13-b":"gone", "rpa-c13":"present",
                  "c12-b":"gone", "rpa-c12":"present", "c11-b":"gone",
                  "rpa-c11":"present", "c10-b":"gone", "rpa-c10":"present",
                  "c09-b":"gone", "rpa-c09":"present", "c08-b":"gone",
                  "rpa-c08":"present", "c07-b":"gone", "rpa-c07":"present",
                  "c06-b":"gone", "rpa-c06":"present", "c05-b":"gone",
                  "rpa-c05":"present", "c04-b":"gone", "rpa-c04":"present",
                  "c03-b":"fading", "c02-b":"fading" } },

      /* The front reaches chunk 1 and the first unique chunk together. Ku has
         no frame-table entry here either: paintDerived reads the lower bound off
         the .dna group, so it keeps tracking the junction across the boundary
         instead of stopping on the last repeat. */
      { actors: { "actor-exo1":-756, "actor-camera":168 },
        halves: { "fx-uniquespan":"present",
                  "capbase-cst":"gone", "capbaselab-cst":"gone", "capbasest-cst":"gone",
                  "capflip-cst":"present", "capfliplab-cst":"present", "capflipst-cst":"present",
                  "actor-cst":"gone", "fx-exo1":"present", "c17-b":"gone",
                  "rpa-c17":"present", "c16-b":"gone", "rpa-c16":"present",
                  "c15-b":"gone", "rpa-c15":"present", "c14-b":"gone",
                  "rpa-c14":"present", "c13-b":"gone", "rpa-c13":"present",
                  "c12-b":"gone", "rpa-c12":"present", "c11-b":"gone",
                  "rpa-c11":"present", "c10-b":"gone", "rpa-c10":"present",
                  "c09-b":"gone", "rpa-c09":"present", "c08-b":"gone",
                  "rpa-c08":"present", "c07-b":"gone", "rpa-c07":"present",
                  "c06-b":"gone", "rpa-c06":"present", "c05-b":"gone",
                  "rpa-c05":"present", "c04-b":"gone", "rpa-c04":"present",
                  "c03-b":"gone", "rpa-c03":"present", "c02-b":"gone",
                  "rpa-c02":"present", "c01-b":"fading", "u01-b":"fading" } },

      { actors: { "actor-exo1":-840, "actor-camera":252 },
        halves: { "fx-uniquespan":"present",
                  "capbase-cst":"gone", "capbaselab-cst":"gone", "capbasest-cst":"gone",
                  "capflip-cst":"present", "capfliplab-cst":"present", "capflipst-cst":"present",
                  "actor-cst":"gone", "fx-exo1":"present", "c17-b":"gone",
                  "rpa-c17":"present", "c16-b":"gone", "rpa-c16":"present",
                  "c15-b":"gone", "rpa-c15":"present", "c14-b":"gone",
                  "rpa-c14":"present", "c13-b":"gone", "rpa-c13":"present",
                  "c12-b":"gone", "rpa-c12":"present", "c11-b":"gone",
                  "rpa-c11":"present", "c10-b":"gone", "rpa-c10":"present",
                  "c09-b":"gone", "rpa-c09":"present", "c08-b":"gone",
                  "rpa-c08":"present", "c07-b":"gone", "rpa-c07":"present",
                  "c06-b":"gone", "rpa-c06":"present", "c05-b":"gone",
                  "rpa-c05":"present", "c04-b":"gone", "rpa-c04":"present",
                  "c03-b":"gone", "rpa-c03":"present", "c02-b":"gone",
                  "rpa-c02":"present", "c01-b":"gone", "rpa-c01":"present",
                  "u01-b":"gone", "rpa-u01":"present", "u02-b":"fading",
                  "u03-b":"fading" } },

      { actors: { "actor-exo1":-882, "actor-camera":294 },
        halves: { "fx-uniquespan":"present",
                  "capbase-cst":"gone", "capbaselab-cst":"gone", "capbasest-cst":"gone",
                  "capflip-cst":"present", "capfliplab-cst":"present", "capflipst-cst":"present",
                  "actor-cst":"gone", "fx-exo1":"present", "c17-b":"gone",
                  "rpa-c17":"present", "c16-b":"gone", "rpa-c16":"present",
                  "c15-b":"gone", "rpa-c15":"present", "c14-b":"gone",
                  "rpa-c14":"present", "c13-b":"gone", "rpa-c13":"present",
                  "c12-b":"gone", "rpa-c12":"present", "c11-b":"gone",
                  "rpa-c11":"present", "c10-b":"gone", "rpa-c10":"present",
                  "c09-b":"gone", "rpa-c09":"present", "c08-b":"gone",
                  "rpa-c08":"present", "c07-b":"gone", "rpa-c07":"present",
                  "c06-b":"gone", "rpa-c06":"present", "c05-b":"gone",
                  "rpa-c05":"present", "c04-b":"gone", "rpa-c04":"present",
                  "c03-b":"gone", "rpa-c03":"present", "c02-b":"gone",
                  "rpa-c02":"present", "c01-b":"gone", "rpa-c01":"present",
                  "u01-b":"gone", "rpa-u01":"present", "u02-b":"gone",
                  "rpa-u02":"present", "u03-b":"gone", "rpa-u03":"present",
                  "u04-b":"fading" } },

      /* Degradation has run through the array and into non-telomeric DNA,
         which is what cdc13-1 does at restrictive temperature. Nothing in the
         drawn region is duplex now, so Ku holds its last junction rather than
         jumping: there is no site left on screen for it to be flush against. */
      { actors: { "actor-exo1":-924, "actor-camera":294 },
        halves: { "fx-uniquespan":"present",
                  "capbase-cst":"gone", "capbaselab-cst":"gone", "capbasest-cst":"gone",
                  "capflip-cst":"present", "capfliplab-cst":"present", "capflipst-cst":"present",
                  "actor-cst":"gone", "fx-exo1":"present", "c17-b":"gone",
                  "rpa-c17":"present", "c16-b":"gone", "rpa-c16":"present",
                  "c15-b":"gone", "rpa-c15":"present", "c14-b":"gone",
                  "rpa-c14":"present", "c13-b":"gone", "rpa-c13":"present",
                  "c12-b":"gone", "rpa-c12":"present", "c11-b":"gone",
                  "rpa-c11":"present", "c10-b":"gone", "rpa-c10":"present",
                  "c09-b":"gone", "rpa-c09":"present", "c08-b":"gone",
                  "rpa-c08":"present", "c07-b":"gone", "rpa-c07":"present",
                  "c06-b":"gone", "rpa-c06":"present", "c05-b":"gone",
                  "rpa-c05":"present", "c04-b":"gone", "rpa-c04":"present",
                  "c03-b":"gone", "rpa-c03":"present", "c02-b":"gone",
                  "rpa-c02":"present", "c01-b":"gone", "rpa-c01":"present",
                  "u01-b":"gone", "rpa-u01":"present", "u02-b":"gone",
                  "rpa-u02":"present", "u03-b":"gone", "rpa-u03":"present",
                  "u04-b":"gone", "rpa-u04":"present", "fx-bracketC":"present" } },

      /* Ddc2 loads on the RPA-coated strand and brings Mec1. The substrate that
         marks the lost cap is the substrate that starts the checkpoint. */
      { actors: { "actor-exo1":-924, "actor-camera":294 },
        halves: { "fx-uniquespan":"present",
                  "capbase-cst":"gone", "capbaselab-cst":"gone", "capbasest-cst":"gone",
                  "capflip-cst":"present", "capfliplab-cst":"present", "capflipst-cst":"present",
                  "actor-cst":"gone", "fx-exo1":"present", "c17-b":"gone",
                  "rpa-c17":"present", "c16-b":"gone", "rpa-c16":"present",
                  "c15-b":"gone", "rpa-c15":"present", "c14-b":"gone",
                  "rpa-c14":"present", "c13-b":"gone", "rpa-c13":"present",
                  "c12-b":"gone", "rpa-c12":"present", "c11-b":"gone",
                  "rpa-c11":"present", "c10-b":"gone", "rpa-c10":"present",
                  "c09-b":"gone", "rpa-c09":"present", "c08-b":"gone",
                  "rpa-c08":"present", "c07-b":"gone", "rpa-c07":"present",
                  "c06-b":"gone", "rpa-c06":"present", "c05-b":"gone",
                  "rpa-c05":"present", "c04-b":"gone", "rpa-c04":"present",
                  "c03-b":"gone", "rpa-c03":"present", "c02-b":"gone",
                  "rpa-c02":"present", "c01-b":"gone", "rpa-c01":"present",
                  "u01-b":"gone", "rpa-u01":"present", "u02-b":"gone",
                  "rpa-u02":"present", "u03-b":"gone", "rpa-u03":"present",
                  "u04-b":"gone", "rpa-u04":"present", "fx-bracketC":"present",
                  "fx-ddc2":"present", "fx-mec1":"present" } },

      { actors: { "actor-exo1":-924, "actor-camera":294 },
        halves: { "fx-uniquespan":"present",
                  "capbase-cst":"gone", "capbaselab-cst":"gone", "capbasest-cst":"gone",
                  "capflip-cst":"present", "capfliplab-cst":"present", "capflipst-cst":"present",
                  "actor-cst":"gone", "fx-exo1":"present", "c17-b":"gone",
                  "rpa-c17":"present", "c16-b":"gone", "rpa-c16":"present",
                  "c15-b":"gone", "rpa-c15":"present", "c14-b":"gone",
                  "rpa-c14":"present", "c13-b":"gone", "rpa-c13":"present",
                  "c12-b":"gone", "rpa-c12":"present", "c11-b":"gone",
                  "rpa-c11":"present", "c10-b":"gone", "rpa-c10":"present",
                  "c09-b":"gone", "rpa-c09":"present", "c08-b":"gone",
                  "rpa-c08":"present", "c07-b":"gone", "rpa-c07":"present",
                  "c06-b":"gone", "rpa-c06":"present", "c05-b":"gone",
                  "rpa-c05":"present", "c04-b":"gone", "rpa-c04":"present",
                  "c03-b":"gone", "rpa-c03":"present", "c02-b":"gone",
                  "rpa-c02":"present", "c01-b":"gone", "rpa-c01":"present",
                  "u01-b":"gone", "rpa-u01":"present", "u02-b":"gone",
                  "rpa-u02":"present", "u03-b":"gone", "rpa-u03":"present",
                  "u04-b":"gone", "rpa-u04":"present", "fx-bracketC":"present",
                  "fx-ddc2":"present", "fx-mec1":"present", "fx-rad9":"present" } },

      /* Rad53, and metaphase arrest. */
      { actors: { "actor-exo1":-924, "actor-camera":294 },
        halves: { "fx-uniquespan":"present",
                  "capbase-cst":"gone", "capbaselab-cst":"gone", "capbasest-cst":"gone",
                  "capflip-cst":"present", "capfliplab-cst":"present", "capflipst-cst":"present",
                  "actor-cst":"gone", "fx-exo1":"present", "c17-b":"gone",
                  "rpa-c17":"present", "c16-b":"gone", "rpa-c16":"present",
                  "c15-b":"gone", "rpa-c15":"present", "c14-b":"gone",
                  "rpa-c14":"present", "c13-b":"gone", "rpa-c13":"present",
                  "c12-b":"gone", "rpa-c12":"present", "c11-b":"gone",
                  "rpa-c11":"present", "c10-b":"gone", "rpa-c10":"present",
                  "c09-b":"gone", "rpa-c09":"present", "c08-b":"gone",
                  "rpa-c08":"present", "c07-b":"gone", "rpa-c07":"present",
                  "c06-b":"gone", "rpa-c06":"present", "c05-b":"gone",
                  "rpa-c05":"present", "c04-b":"gone", "rpa-c04":"present",
                  "c03-b":"gone", "rpa-c03":"present", "c02-b":"gone",
                  "rpa-c02":"present", "c01-b":"gone", "rpa-c01":"present",
                  "u01-b":"gone", "rpa-u01":"present", "u02-b":"gone",
                  "rpa-u02":"present", "u03-b":"gone", "rpa-u03":"present",
                  "u04-b":"gone", "rpa-u04":"present", "fx-bracketC":"present",
                  "fx-ddc2":"present", "fx-mec1":"present", "fx-rad9":"present",
                  "fx-rad53":"present" } }
    ]
  },

  /* Branch D: the Rap1 array lost. Erosion precedes fusion, which is both the
     reported order and what frees the right-hand side of the viewBox. */
  /* Branch A: no telomerase. The array erodes to nothing and two exhausted
     ends are ligated.

     Nothing here names a Rap1 box, a zone tint, a cap slot or Ku. All four are
     derived from chunk visibility in animate.js, so removing DNA is the whole
     of it: the array recedes, the slots fall, and Ku follows the junction back
     into unique sequence on its own. This branch declares no loss at all,
     because telomerase is not a cap element and nothing was deleted from the
     cap. What ran out was the substrate.

     Erosion runs the entire array, two repeats a frame, chunk 18 to chunk 1.
     Stopping partway leaves ten duplex repeats and the Rap1 slot reads short
     array, which is a shorter telomere rather than an exhausted one.

     The camera holds at 0 until the end has retreated to 470 and then steps 84
     per frame, which keeps the end at 470 for the rest of the panel. Same
     idiom as branch C, in the other direction.

     MRX does not translate. Three complexes at cx(15), cx(9) and cx(3) appear
     and fade as the end passes each of them, which is a sequence of binding
     events at successive ends and not one complex walking inward. */
  offA: {
    fps: 1.5,
    label: "Erosion and fusion",
    frames: [
      /* The step 9 telomere. Same opening beat as C, D and E, and the same
         reason: what follows has to read as something that happened to this
         chromosome and not as a different one. */
      { actors: { "actor-camera":0 }, halves: {} },

      { actors: { "actor-camera":0 },
        halves: {
        "c18-t":"fading", "c18-b":"fading", "c17-t":"fading", "c17-b":"fading",
        "actor-cst":"fading", "fx-mrxA1":"arriving" } },

      { actors: { "actor-camera":0 },
        halves: {
        "c18-t":"gone", "c18-b":"gone", "c17-t":"gone", "c17-b":"gone", "c16-t":"fading",
        "c16-b":"fading", "c15-t":"fading", "c15-b":"fading", "actor-cst":"gone",
        "fx-mrxA1":"present" } },

      { actors: { "actor-camera":0 },
        halves: {
        "c18-t":"gone", "c18-b":"gone", "c17-t":"gone", "c17-b":"gone", "c16-t":"gone",
        "c16-b":"gone", "c15-t":"gone", "c15-b":"gone", "c14-t":"fading", "c14-b":"fading",
        "c13-t":"fading", "c13-b":"fading", "actor-cst":"gone", "fx-mrxA1":"fading" } },

      { actors: { "actor-camera":0 },
        halves: {
        "c18-t":"gone", "c18-b":"gone", "c17-t":"gone", "c17-b":"gone", "c16-t":"gone",
        "c16-b":"gone", "c15-t":"gone", "c15-b":"gone", "c14-t":"gone", "c14-b":"gone",
        "c13-t":"gone", "c13-b":"gone", "c12-t":"fading", "c12-b":"fading", "c11-t":"fading",
        "c11-b":"fading", "actor-cst":"gone", "fx-mrxA1":"gone", "fx-mrxA2":"arriving" } },

      { actors: { "actor-camera":0 },
        halves: {
        "c18-t":"gone", "c18-b":"gone", "c17-t":"gone", "c17-b":"gone", "c16-t":"gone",
        "c16-b":"gone", "c15-t":"gone", "c15-b":"gone", "c14-t":"gone", "c14-b":"gone",
        "c13-t":"gone", "c13-b":"gone", "c12-t":"gone", "c12-b":"gone", "c11-t":"gone",
        "c11-b":"gone", "c10-t":"fading", "c10-b":"fading", "c09-t":"fading",
        "c09-b":"fading", "actor-cst":"gone", "fx-mrxA1":"gone", "fx-mrxA2":"present" } },

      { actors: { "actor-camera":84 },
        halves: {
        "fx-uniquespan":"present", "c18-t":"gone", "c18-b":"gone", "c17-t":"gone", "c17-b":"gone", "c16-t":"gone",
        "c16-b":"gone", "c15-t":"gone", "c15-b":"gone", "c14-t":"gone", "c14-b":"gone",
        "c13-t":"gone", "c13-b":"gone", "c12-t":"gone", "c12-b":"gone", "c11-t":"gone",
        "c11-b":"gone", "c10-t":"gone", "c10-b":"gone", "c09-t":"gone", "c09-b":"gone",
        "c08-t":"fading", "c08-b":"fading", "c07-t":"fading", "c07-b":"fading",
        "actor-cst":"gone", "fx-mrxA1":"gone", "fx-mrxA2":"fading" } },

      { actors: { "actor-camera":168 },
        halves: {
        "fx-uniquespan":"present", "c18-t":"gone", "c18-b":"gone", "c17-t":"gone", "c17-b":"gone", "c16-t":"gone",
        "c16-b":"gone", "c15-t":"gone", "c15-b":"gone", "c14-t":"gone", "c14-b":"gone",
        "c13-t":"gone", "c13-b":"gone", "c12-t":"gone", "c12-b":"gone", "c11-t":"gone",
        "c11-b":"gone", "c10-t":"gone", "c10-b":"gone", "c09-t":"gone", "c09-b":"gone",
        "c08-t":"gone", "c08-b":"gone", "c07-t":"gone", "c07-b":"gone", "c06-t":"fading",
        "c06-b":"fading", "c05-t":"fading", "c05-b":"fading", "actor-cst":"gone",
        "fx-mrxA1":"gone", "fx-mrxA2":"gone", "fx-mrxA3":"arriving" } },

      { actors: { "actor-camera":252 },
        halves: {
        "fx-uniquespan":"present", "c18-t":"gone", "c18-b":"gone", "c17-t":"gone", "c17-b":"gone", "c16-t":"gone",
        "c16-b":"gone", "c15-t":"gone", "c15-b":"gone", "c14-t":"gone", "c14-b":"gone",
        "c13-t":"gone", "c13-b":"gone", "c12-t":"gone", "c12-b":"gone", "c11-t":"gone",
        "c11-b":"gone", "c10-t":"gone", "c10-b":"gone", "c09-t":"gone", "c09-b":"gone",
        "c08-t":"gone", "c08-b":"gone", "c07-t":"gone", "c07-b":"gone", "c06-t":"gone",
        "c06-b":"gone", "c05-t":"gone", "c05-b":"gone", "c04-t":"fading", "c04-b":"fading",
        "c03-t":"fading", "c03-b":"fading", "actor-cst":"gone", "fx-mrxA1":"gone",
        "fx-mrxA2":"gone", "fx-mrxA3":"present" } },

      { actors: { "actor-camera":336 },
        halves: {
        "fx-uniquespan":"present", "c18-t":"gone", "c18-b":"gone", "c17-t":"gone", "c17-b":"gone", "c16-t":"gone",
        "c16-b":"gone", "c15-t":"gone", "c15-b":"gone", "c14-t":"gone", "c14-b":"gone",
        "c13-t":"gone", "c13-b":"gone", "c12-t":"gone", "c12-b":"gone", "c11-t":"gone",
        "c11-b":"gone", "c10-t":"gone", "c10-b":"gone", "c09-t":"gone", "c09-b":"gone",
        "c08-t":"gone", "c08-b":"gone", "c07-t":"gone", "c07-b":"gone", "c06-t":"gone",
        "c06-b":"gone", "c05-t":"gone", "c05-b":"gone", "c04-t":"gone", "c04-b":"gone",
        "c03-t":"gone", "c03-b":"gone", "c02-t":"fading", "c02-b":"fading", "c01-t":"fading",
        "c01-b":"fading", "actor-cst":"gone", "fx-mrxA1":"gone", "fx-mrxA2":"gone",
        "fx-mrxA3":"fading" } },

      /* Every repeat is gone. The array slot reads no duplex, the CST slot
         reads no overhang, and Ku sits on the unique sequence behind what
         used to be the junction. None of that is declared. */
      { actors: { "actor-camera":420 },
        halves: {
        "fx-uniquespan":"present", "c18-t":"gone", "c18-b":"gone", "c17-t":"gone", "c17-b":"gone", "c16-t":"gone",
        "c16-b":"gone", "c15-t":"gone", "c15-b":"gone", "c14-t":"gone", "c14-b":"gone",
        "c13-t":"gone", "c13-b":"gone", "c12-t":"gone", "c12-b":"gone", "c11-t":"gone",
        "c11-b":"gone", "c10-t":"gone", "c10-b":"gone", "c09-t":"gone", "c09-b":"gone",
        "c08-t":"gone", "c08-b":"gone", "c07-t":"gone", "c07-b":"gone", "c06-t":"gone",
        "c06-b":"gone", "c05-t":"gone", "c05-b":"gone", "c04-t":"gone", "c04-b":"gone",
        "c03-t":"gone", "c03-b":"gone", "c02-t":"gone", "c02-b":"gone", "c01-t":"gone",
        "c01-b":"gone", "fx-mrxA1":"gone", "fx-mrxA2":"gone", "fx-mrxA3":"gone",
        "actor-cst":"gone" } },

      /* A second end in the same state. In a telomerase null many ends reach
         the threshold together, so this one is not a coincidence. */
      { actors: { "actor-camera":420 },
        halves: {
        "fx-uniquespan":"present", "c18-t":"gone", "c18-b":"gone", "c17-t":"gone", "c17-b":"gone", "c16-t":"gone",
        "c16-b":"gone", "c15-t":"gone", "c15-b":"gone", "c14-t":"gone", "c14-b":"gone",
        "c13-t":"gone", "c13-b":"gone", "c12-t":"gone", "c12-b":"gone", "c11-t":"gone",
        "c11-b":"gone", "c10-t":"gone", "c10-b":"gone", "c09-t":"gone", "c09-b":"gone",
        "c08-t":"gone", "c08-b":"gone", "c07-t":"gone", "c07-b":"gone", "c06-t":"gone",
        "c06-b":"gone", "c05-t":"gone", "c05-b":"gone", "c04-t":"gone", "c04-b":"gone",
        "c03-t":"gone", "c03-b":"gone", "c02-t":"gone", "c02-b":"gone", "c01-t":"gone",
        "c01-b":"gone", "fx-mrxA1":"gone", "fx-mrxA2":"gone", "fx-mrxA3":"gone",
        "actor-cst":"gone", "fx-partner":"present" } },

      { actors: { "actor-camera":420 },
        halves: {
        "fx-uniquespan":"present", "c18-t":"gone", "c18-b":"gone", "c17-t":"gone", "c17-b":"gone", "c16-t":"gone",
        "c16-b":"gone", "c15-t":"gone", "c15-b":"gone", "c14-t":"gone", "c14-b":"gone",
        "c13-t":"gone", "c13-b":"gone", "c12-t":"gone", "c12-b":"gone", "c11-t":"gone",
        "c11-b":"gone", "c10-t":"gone", "c10-b":"gone", "c09-t":"gone", "c09-b":"gone",
        "c08-t":"gone", "c08-b":"gone", "c07-t":"gone", "c07-b":"gone", "c06-t":"gone",
        "c06-b":"gone", "c05-t":"gone", "c05-b":"gone", "c04-t":"gone", "c04-b":"gone",
        "c03-t":"gone", "c03-b":"gone", "c02-t":"gone", "c02-b":"gone", "c01-t":"gone",
        "c01-b":"gone", "fx-mrxA1":"gone", "fx-mrxA2":"gone", "fx-mrxA3":"gone",
        "actor-cst":"gone", "fx-partner":"present", "fx-nhej":"present" } },

      { actors: { "actor-camera":420 },
        halves: {
        "fx-uniquespan":"present", "c18-t":"gone", "c18-b":"gone", "c17-t":"gone", "c17-b":"gone", "c16-t":"gone",
        "c16-b":"gone", "c15-t":"gone", "c15-b":"gone", "c14-t":"gone", "c14-b":"gone",
        "c13-t":"gone", "c13-b":"gone", "c12-t":"gone", "c12-b":"gone", "c11-t":"gone",
        "c11-b":"gone", "c10-t":"gone", "c10-b":"gone", "c09-t":"gone", "c09-b":"gone",
        "c08-t":"gone", "c08-b":"gone", "c07-t":"gone", "c07-b":"gone", "c06-t":"gone",
        "c06-b":"gone", "c05-t":"gone", "c05-b":"gone", "c04-t":"gone", "c04-b":"gone",
        "c03-t":"gone", "c03-b":"gone", "c02-t":"gone", "c02-b":"gone", "c01-t":"gone",
        "c01-b":"gone", "fx-mrxA1":"gone", "fx-mrxA2":"gone", "fx-mrxA3":"gone",
        "actor-cst":"gone", "fx-partner":"present", "fx-nhej":"present",
        "fx-ligate":"present" } },
    ]
  },

  /* Branch D: Rap1 removed from a telomere that keeps its length.

     The array does not recede. Fusions after Rap1 loss happen between telomeres
     of near wild-type length, so every repeat stays and only the protein goes.
     That is the one loss in this figure the drawing cannot derive: the duplex
     the protein sat on is still on the page, so absence of a box is not
     evidence of anything. Hence the declared pill, and hence Rap1 being the
     only slot this branch names. CST and Ku derive to on throughout.

     What changes at the terminus is the C strand, and only the C strand. Its 5'
     end moves inward across three repeats while the 3' terminus holds position,
     so the single strand region grows and the molecule's rightmost extent never
     moves. An earlier version added repeats to the G strand instead. The two
     are not interchangeable: an extending G strand reads as telomerase acting
     with fill-in failing behind it, and this panel's phase is resting, which is
     outside the window telomerase acts in at all.

     Three repeats, against branch E's nine. Both panels now show a C strand
     receding, which is correct, but E takes it far enough that the Rap1 slot
     falls with it and that is E's signal. Here the array has to still read full
     when it fuses, because that is what separates this panel from branch A.

     Nothing names a zone tint, a Ku position or the CST slot. Ku follows the
     junction inward because the derivation puts it at the last duplex chunk,
     and CST stays lit because the overhang it holds got longer rather than
     shorter.

     The camera holds at 0 through all of it and moves only for the fusion. With
     the terminus fixed there is nothing to follow until the partner arrives.

     fx-repress and fx-nhejoff are on the page at frame 0 and leave, which is the
     panel 5 case: they cannot start hidden, so they are drawn without pending
     and the frames take them off. The repression goes on the same beat the
     array fades, because it is the same event, and the lit NHEJ box arrives on
     the beat the protein is gone. Nothing sits between the two states. */
  offD: {
    fps: 1.4,
    label: "Fusion at full length",
    frames: [
      /* The step 9 telomere, before the degron is induced. */
      { actors: { "actor-camera":0 }, halves: {} },

      /* The shift. The array fades before it goes, the same beat branch C
         loses CST on and branch E loses Ku on. */
      { actors: { "actor-camera":0 },
        halves: {
        "fx-repress":"fading", "fx-nhejoff":"present",
        "rap1-01":"fading", "rap1-03":"fading", "rap1-05":"fading", "rap1-07":"fading",
        "rap1-09":"fading", "rap1-11":"fading", "rap1-13":"fading", "rap1-15":"fading",
        "fx-condition":"present" } },

      /* The protein goes and Rif1 and Rif2 go with it, because both load off
         the Rap1 C-terminus. Every repeat stays: this is the panel where the
         sequence is not what is lost. */
      { actors: { "actor-camera":0 },
        halves: {
        "fx-repress":"gone", "fx-nhejoff":"gone", "fx-nhejon":"present",
        "rap1-01":"gone", "rap1-03":"gone", "rap1-05":"gone", "rap1-07":"gone",
        "rap1-09":"gone", "rap1-11":"gone", "rap1-13":"gone", "rap1-15":"gone",
        "fx-condition":"present", "capbase-rap1":"gone", "capbaselab-rap1":"gone",
        "capbasest-rap1":"gone", "capflip-rap1":"present", "capfliplab-rap1":"present",
        "capflipst-rap1":"present" } },

      /* Only the -b half moves. The 3' terminus is fixed for the whole
         panel, so nothing is added at the end and the rightmost extent of
         the molecule never changes. */
      { actors: { "actor-camera":0 },
        halves: {
        "fx-repress":"gone", "fx-nhejoff":"gone", "fx-nhejon":"present",
        "rap1-01":"gone", "rap1-03":"gone", "rap1-05":"gone", "rap1-07":"gone",
        "rap1-09":"gone", "rap1-11":"gone", "rap1-13":"gone", "rap1-15":"gone",
        "fx-condition":"present", "capbase-rap1":"gone", "capbaselab-rap1":"gone",
        "capbasest-rap1":"gone", "capflip-rap1":"present", "capfliplab-rap1":"present",
        "capflipst-rap1":"present", "c17-b":"fading", "fx-ssbracket":"present" } },

      { actors: { "actor-camera":0 },
        halves: {
        "fx-repress":"gone", "fx-nhejoff":"gone", "fx-nhejon":"present",
        "rap1-01":"gone", "rap1-03":"gone", "rap1-05":"gone", "rap1-07":"gone",
        "rap1-09":"gone", "rap1-11":"gone", "rap1-13":"gone", "rap1-15":"gone",
        "fx-condition":"present", "capbase-rap1":"gone", "capbaselab-rap1":"gone",
        "capbasest-rap1":"gone", "capflip-rap1":"present", "capfliplab-rap1":"present",
        "capflipst-rap1":"present", "c17-b":"gone", "rpa-c17":"arriving",
        "fx-ssbracket":"present", "c16-b":"fading" } },

      { actors: { "actor-camera":0 },
        halves: {
        "fx-repress":"gone", "fx-nhejoff":"gone", "fx-nhejon":"present",
        "rap1-01":"gone", "rap1-03":"gone", "rap1-05":"gone", "rap1-07":"gone",
        "rap1-09":"gone", "rap1-11":"gone", "rap1-13":"gone", "rap1-15":"gone",
        "fx-condition":"present", "capbase-rap1":"gone", "capbaselab-rap1":"gone",
        "capbasest-rap1":"gone", "capflip-rap1":"present", "capfliplab-rap1":"present",
        "capflipst-rap1":"present", "c17-b":"gone", "rpa-c17":"arriving",
        "fx-ssbracket":"present", "c16-b":"gone", "rpa-c16":"arriving", "c15-b":"fading" } },

      /* The recession is complete and the overhang has settled. CST is still
         on it and Ku has followed the junction inward on its own. */
      { actors: { "actor-camera":0 },
        halves: {
        "fx-repress":"gone", "fx-nhejoff":"gone", "fx-nhejon":"present",
        "rap1-01":"gone", "rap1-03":"gone", "rap1-05":"gone", "rap1-07":"gone",
        "rap1-09":"gone", "rap1-11":"gone", "rap1-13":"gone", "rap1-15":"gone",
        "fx-condition":"present", "capbase-rap1":"gone", "capbaselab-rap1":"gone",
        "capbasest-rap1":"gone", "capflip-rap1":"present", "capfliplab-rap1":"present",
        "capflipst-rap1":"present", "c17-b":"gone", "rpa-c17":"present",
        "fx-ssbracket":"present", "c16-b":"gone", "rpa-c16":"present", "c15-b":"gone",
        "rpa-c15":"present" } },

      /* MRX arrives, on duplex behind the junction. It is a requirement of
         the fusion, not an agent of the recession, which is finished. */
      { actors: { "actor-camera":0 },
        halves: {
        "fx-repress":"gone", "fx-nhejoff":"gone", "fx-nhejon":"present",
        "rap1-01":"gone", "rap1-03":"gone", "rap1-05":"gone", "rap1-07":"gone",
        "rap1-09":"gone", "rap1-11":"gone", "rap1-13":"gone", "rap1-15":"gone",
        "fx-condition":"present", "capbase-rap1":"gone", "capbaselab-rap1":"gone",
        "capbasest-rap1":"gone", "capflip-rap1":"present", "capfliplab-rap1":"present",
        "capflipst-rap1":"present", "c17-b":"gone", "rpa-c17":"present",
        "fx-ssbracket":"present", "c16-b":"gone", "rpa-c16":"present", "c15-b":"gone",
        "rpa-c15":"present", "fx-mrxD":"present" } },

      /* Only now does the second end enter, and only now does the camera
         move. Overlapping the two would invite the reading that the
         recession causes the fusion, which is the opposite of the claim. */
      { actors: { "actor-camera":-126 },
        halves: {
        "fx-repress":"gone", "fx-nhejoff":"gone", "fx-nhejon":"present",
        "rap1-01":"gone", "rap1-03":"gone", "rap1-05":"gone", "rap1-07":"gone",
        "rap1-09":"gone", "rap1-11":"gone", "rap1-13":"gone", "rap1-15":"gone",
        "fx-condition":"present", "capbase-rap1":"gone", "capbaselab-rap1":"gone",
        "capbasest-rap1":"gone", "capflip-rap1":"present", "capfliplab-rap1":"present",
        "capflipst-rap1":"present", "c17-b":"gone", "rpa-c17":"present",
        "fx-ssbracket":"present", "c16-b":"gone", "rpa-c16":"present", "c15-b":"gone",
        "rpa-c15":"present", "fx-mrxD":"present", "fx-partner":"present" } },

      { actors: { "actor-camera":-252 },
        halves: {
        "fx-repress":"gone", "fx-nhejoff":"gone", "fx-nhejon":"present",
        "rap1-01":"gone", "rap1-03":"gone", "rap1-05":"gone", "rap1-07":"gone",
        "rap1-09":"gone", "rap1-11":"gone", "rap1-13":"gone", "rap1-15":"gone",
        "fx-condition":"present", "capbase-rap1":"gone", "capbaselab-rap1":"gone",
        "capbasest-rap1":"gone", "capflip-rap1":"present", "capfliplab-rap1":"present",
        "capflipst-rap1":"present", "c17-b":"gone", "rpa-c17":"present",
        "fx-ssbracket":"present", "c16-b":"gone", "rpa-c16":"present", "c15-b":"gone",
        "rpa-c15":"present", "fx-mrxD":"present", "fx-partner":"present",
        "fx-nhej":"present" } },

      { actors: { "actor-camera":-252 },
        halves: {
        "fx-repress":"gone", "fx-nhejoff":"gone", "fx-nhejon":"present",
        "rap1-01":"gone", "rap1-03":"gone", "rap1-05":"gone", "rap1-07":"gone",
        "rap1-09":"gone", "rap1-11":"gone", "rap1-13":"gone", "rap1-15":"gone",
        "fx-condition":"present", "capbase-rap1":"gone", "capbaselab-rap1":"gone",
        "capbasest-rap1":"gone", "capflip-rap1":"present", "capfliplab-rap1":"present",
        "capflipst-rap1":"present", "c17-b":"gone", "rpa-c17":"present",
        "fx-ssbracket":"present", "c16-b":"gone", "rpa-c16":"present", "c15-b":"gone",
        "rpa-c15":"present", "fx-mrxD":"present", "fx-partner":"present",
        "fx-nhej":"present", "fx-ligate":"present" } },
    ]
  },

  /* Branch E: Ku lost. Partial uncapping, so the cap indicator loses one slot
     and the other two stay lit.

     RPA follows Exo1 inward, exactly as in panel 3 and branch C. The tail here
     is single-stranded DNA and single-stranded DNA is never bare; leaving it
     uncovered drew the deprotected state this branch exists to distinguish
     itself from. Chunk 18 gets no unit: that is the resting tail, and CST is
     still on it, which is the whole difference from branch C. */
  offE: {
    fps: 1.5,
    label: "Long G-tail",
    frames: [
      /* Same opening as C and D. */
      { actors: {}, halves: {} },

      /* Ku fades. Same beat as branch C loses CST and branch D loses the
         array. */
      { actors: {}, halves: { "actor-ku":"fading" } },

      /* Ku lost, and the pair arrives at the end of the C-strand. Nothing has
         been removed yet, so this frame is the resting telomere with the
         enzymes on it. */
      { actors: { "actor-exo1":0, "actor-sgs1":0 },
        halves: { "capbase-ku":"gone", "capbaselab-ku":"gone", "capbasest-ku":"gone",
                  "capflip-ku":"present", "capfliplab-ku":"present", "capflipst-ku":"present",
                  "actor-ku":"gone", "fx-exo1":"present",
                  "fx-sgs1":"present" } },

      /* One repeat per frame from here, which is panel 3's rate. Each C-strand
         half grays out on the frame the pair reaches it and is gone on the
         next, and RPA lands on the repeat the frame after the strand goes, so
         no unit is ever drawn over duplex DNA. The two offsets are identical
         in every frame: this is one activity with two enzymes in it. */
      { actors: { "actor-exo1":-42, "actor-sgs1":-42 },
        halves: { "capbase-ku":"gone", "capbaselab-ku":"gone", "capbasest-ku":"gone",
                  "capflip-ku":"present", "capfliplab-ku":"present", "capflipst-ku":"present",
                  "actor-ku":"gone", "fx-exo1":"present",
                  "fx-sgs1":"present", "c17-b":"fading" } },

      { actors: { "actor-exo1":-84, "actor-sgs1":-84 },
        halves: { "capbase-ku":"gone", "capbaselab-ku":"gone", "capbasest-ku":"gone",
                  "capflip-ku":"present", "capfliplab-ku":"present", "capflipst-ku":"present",
                  "actor-ku":"gone", "fx-exo1":"present",
                  "fx-sgs1":"present", "c17-b":"gone", "c16-b":"fading",
                  "rpa-c17":"arriving" } },

      { actors: { "actor-exo1":-126, "actor-sgs1":-126 },
        halves: { "capbase-ku":"gone", "capbaselab-ku":"gone", "capbasest-ku":"gone",
                  "capflip-ku":"present", "capfliplab-ku":"present", "capflipst-ku":"present",
                  "actor-ku":"gone", "fx-exo1":"present",
                  "fx-sgs1":"present", "c17-b":"gone", "c16-b":"gone",
                  "c15-b":"fading", "rpa-c17":"present", "rpa-c16":"arriving" } },

      { actors: { "actor-exo1":-168, "actor-sgs1":-168 },
        halves: { "capbase-ku":"gone", "capbaselab-ku":"gone", "capbasest-ku":"gone",
                  "capflip-ku":"present", "capfliplab-ku":"present", "capflipst-ku":"present",
                  "actor-ku":"gone", "fx-exo1":"present",
                  "fx-sgs1":"present", "c17-b":"gone", "c16-b":"gone",
                  "c15-b":"gone", "c14-b":"fading", "rpa-c17":"present",
                  "rpa-c16":"present", "rpa-c15":"arriving" } },

      { actors: { "actor-exo1":-210, "actor-sgs1":-210 },
        halves: { "capbase-ku":"gone", "capbaselab-ku":"gone", "capbasest-ku":"gone",
                  "capflip-ku":"present", "capfliplab-ku":"present", "capflipst-ku":"present",
                  "actor-ku":"gone", "fx-exo1":"present",
                  "fx-sgs1":"present", "c17-b":"gone", "c16-b":"gone",
                  "c15-b":"gone", "c14-b":"gone", "c13-b":"fading",
                  "rpa-c17":"present", "rpa-c16":"present", "rpa-c15":"present",
                  "rpa-c14":"arriving" } },

      { actors: { "actor-exo1":-252, "actor-sgs1":-252 },
        halves: { "capbase-ku":"gone", "capbaselab-ku":"gone", "capbasest-ku":"gone",
                  "capflip-ku":"present", "capfliplab-ku":"present", "capflipst-ku":"present",
                  "actor-ku":"gone", "fx-exo1":"present",
                  "fx-sgs1":"present", "c17-b":"gone", "c16-b":"gone",
                  "c15-b":"gone", "c14-b":"gone", "c13-b":"gone",
                  "c12-b":"fading", "rpa-c17":"present", "rpa-c16":"present",
                  "rpa-c15":"present", "rpa-c14":"present", "rpa-c13":"arriving" } },

      { actors: { "actor-exo1":-294, "actor-sgs1":-294 },
        halves: { "capbase-ku":"gone", "capbaselab-ku":"gone", "capbasest-ku":"gone",
                  "capflip-ku":"present", "capfliplab-ku":"present", "capflipst-ku":"present",
                  "actor-ku":"gone", "fx-exo1":"present",
                  "fx-sgs1":"present", "c17-b":"gone", "c16-b":"gone",
                  "c15-b":"gone", "c14-b":"gone", "c13-b":"gone",
                  "c12-b":"gone", "c11-b":"fading", "rpa-c17":"present",
                  "rpa-c16":"present", "rpa-c15":"present", "rpa-c14":"present",
                  "rpa-c13":"present", "rpa-c12":"arriving" } },

      { actors: { "actor-exo1":-336, "actor-sgs1":-336 },
        halves: { "capbase-ku":"gone", "capbaselab-ku":"gone", "capbasest-ku":"gone",
                  "capflip-ku":"present", "capfliplab-ku":"present", "capflipst-ku":"present",
                  "actor-ku":"gone", "fx-exo1":"present",
                  "fx-sgs1":"present", "c17-b":"gone", "c16-b":"gone",
                  "c15-b":"gone", "c14-b":"gone", "c13-b":"gone",
                  "c12-b":"gone", "c11-b":"gone", "c10-b":"fading",
                  "rpa-c17":"present", "rpa-c16":"present", "rpa-c15":"present",
                  "rpa-c14":"present", "rpa-c13":"present", "rpa-c12":"present",
                  "rpa-c11":"arriving" } },

      { actors: { "actor-exo1":-378, "actor-sgs1":-378 },
        halves: { "capbase-ku":"gone", "capbaselab-ku":"gone", "capbasest-ku":"gone",
                  "capflip-ku":"present", "capfliplab-ku":"present", "capflipst-ku":"present",
                  "actor-ku":"gone", "fx-exo1":"present",
                  "fx-sgs1":"present", "c17-b":"gone", "c16-b":"gone",
                  "c15-b":"gone", "c14-b":"gone", "c13-b":"gone",
                  "c12-b":"gone", "c11-b":"gone", "c10-b":"gone",
                  "c09-b":"fading", "rpa-c17":"present", "rpa-c16":"present",
                  "rpa-c15":"present", "rpa-c14":"present", "rpa-c13":"present",
                  "rpa-c12":"present", "rpa-c11":"present", "rpa-c10":"arriving" } },

      /* A short last step rather than a full repeat: chunk 9 is the deepest
         the tail runs, and the pair has to clear it without starting on 8. */
      { actors: { "actor-exo1":-390, "actor-sgs1":-390 },
        halves: { "capbase-ku":"gone", "capbaselab-ku":"gone", "capbasest-ku":"gone",
                  "capflip-ku":"present", "capfliplab-ku":"present", "capflipst-ku":"present",
                  "actor-ku":"gone", "fx-exo1":"present",
                  "fx-sgs1":"present", "c17-b":"gone", "c16-b":"gone",
                  "c15-b":"gone", "c14-b":"gone", "c13-b":"gone",
                  "c12-b":"gone", "c11-b":"gone", "c10-b":"gone",
                  "c09-b":"gone", "rpa-c17":"present", "rpa-c16":"present",
                  "rpa-c15":"present", "rpa-c14":"present", "rpa-c13":"present",
                  "rpa-c12":"present", "rpa-c11":"present", "rpa-c10":"present",
                  "rpa-c09":"arriving" } },

      /* Long through the whole cycle, not only in late S. CST still holds the
         end, so the checkpoint arm of branch C never fires. No motion here;
         the frame exists so the finished state shows every unit at full colour
         rather than mid-arrival.

         The old table also set "fx-bracketE" here. No element in offE carries
         that id, and paintHalves skips a miss without complaint, so the line
         had been doing nothing. Dropped rather than carried forward. */
      { actors: { "actor-exo1":-390, "actor-sgs1":-390 },
        halves: { "capbase-ku":"gone", "capbaselab-ku":"gone", "capbasest-ku":"gone",
                  "capflip-ku":"present", "capfliplab-ku":"present", "capflipst-ku":"present",
                  "actor-ku":"gone", "fx-exo1":"present",
                  "fx-sgs1":"present", "c17-b":"gone",
                  "c16-b":"gone", "c15-b":"gone", "c14-b":"gone",
                  "c13-b":"gone", "c12-b":"gone", "c11-b":"gone",
                  "c10-b":"gone", "c09-b":"gone", "rpa-c17":"present",
                  "rpa-c16":"present", "rpa-c15":"present", "rpa-c14":"present",
                  "rpa-c13":"present", "rpa-c12":"present", "rpa-c11":"present",
                  "rpa-c10":"present", "rpa-c09":"present" } },

      /* A different experiment from the eleven frames before it, which is what
         the condition strip is for. Nothing further happens to the DNA in these
         three: RPA still sits on chunks 9 through 17 and the pair has not moved.
         The same lesion crosses a threshold, and Ddc2 reads the substrate that
         was already there. */
      { actors: { "actor-exo1":-390, "actor-sgs1":-390 },
        halves: { "capbase-ku":"gone", "capbaselab-ku":"gone", "capbasest-ku":"gone", "capflip-ku":"present",
                  "capfliplab-ku":"present", "capflipst-ku":"present", "actor-ku":"gone", "fx-exo1":"present",
                  "fx-sgs1":"present", "c17-b":"gone", "c16-b":"gone", "c15-b":"gone",
                  "c14-b":"gone", "c13-b":"gone", "c12-b":"gone", "c11-b":"gone",
                  "c10-b":"gone", "c09-b":"gone", "rpa-c17":"present",
                  "rpa-c16":"present", "rpa-c15":"present", "rpa-c14":"present",
                  "rpa-c13":"present", "rpa-c12":"present", "rpa-c11":"present",
                  "rpa-c10":"present", "rpa-c09":"present", "fx-condition":"present",
                  "fx-ddc2":"present", "fx-mec1":"present" } },

      /* Rad9 carries the signal on. Branch C reaches this chain by taking the
         cap off the terminus; this one reaches it by letting the tail run, which
         is why the two panels share the glyphs and not the cause. */
      { actors: { "actor-exo1":-390, "actor-sgs1":-390 },
        halves: { "capbase-ku":"gone", "capbaselab-ku":"gone", "capbasest-ku":"gone", "capflip-ku":"present",
                  "capfliplab-ku":"present", "capflipst-ku":"present", "actor-ku":"gone", "fx-exo1":"present",
                  "fx-sgs1":"present", "c17-b":"gone", "c16-b":"gone", "c15-b":"gone",
                  "c14-b":"gone", "c13-b":"gone", "c12-b":"gone", "c11-b":"gone",
                  "c10-b":"gone", "c09-b":"gone", "rpa-c17":"present",
                  "rpa-c16":"present", "rpa-c15":"present", "rpa-c14":"present",
                  "rpa-c13":"present", "rpa-c12":"present", "rpa-c11":"present",
                  "rpa-c10":"present", "rpa-c09":"present", "fx-condition":"present",
                  "fx-ddc2":"present", "fx-mec1":"present", "fx-rad9":"present" } },

      /* Rad53 and arrest. The exo1 suppression data is what licenses this arm:
         deleting EXO1 rescues yku70 temperature sensitivity, so the tail is the
         lesion rather than a correlate of it. */
      { actors: { "actor-exo1":-390, "actor-sgs1":-390 },
        halves: { "capbase-ku":"gone", "capbaselab-ku":"gone", "capbasest-ku":"gone", "capflip-ku":"present",
                  "capfliplab-ku":"present", "capflipst-ku":"present", "actor-ku":"gone", "fx-exo1":"present",
                  "fx-sgs1":"present", "c17-b":"gone", "c16-b":"gone", "c15-b":"gone",
                  "c14-b":"gone", "c13-b":"gone", "c12-b":"gone", "c11-b":"gone",
                  "c10-b":"gone", "c09-b":"gone", "rpa-c17":"present",
                  "rpa-c16":"present", "rpa-c15":"present", "rpa-c14":"present",
                  "rpa-c13":"present", "rpa-c12":"present", "rpa-c11":"present",
                  "rpa-c10":"present", "rpa-c09":"present", "fx-condition":"present",
                  "fx-ddc2":"present", "fx-mec1":"present", "fx-rad9":"present",
                  "fx-rad53":"present" } }
    ]
  }
};