/* Telomere workflow controller.

   Nested MVC. Two base-level controllers:

     initWorkflow    startup: load panels and the bibliography, build transport,
                     wire events
     selectStep      respond to a selection and update every surface

   Animation lives in animate.js behind runAnimation(), the transport lives in
   controls.js, and citation rendering lives in cite.js behind initCitations(),
   renderCitedText() and renderReferenceList(). This file coordinates them but
   does not reach inside any of them.

   MODEL and VIEW functions are terminal. A controller that calls model
   functions calls only model functions; likewise for view.
*/

function initWorkflow() {
    // CONTROLLER: startup sequence.

    loadSources(function () {
        initTransport();
        wireInteractions();
        selectStep(ORDER[0]);
    });

    function loadSources(onDone) {
        // SUB-CONTROLLER: panels and bibliography, then hand back.
        //
        // Both must be in before the first selectStep. The panels because
        // paintStage reveals one, and the bibliography because the caption
        // resolves \cite markers against it, and a caption painted before the
        // parse would render every reference as [?] and never repaint.

        var pending = 2;

        loadPanels(settle);
        initCitations(settle);

        function settle() {
            if (--pending === 0) { onDone(); }
        }
    }

    function loadPanels(onDone) {
        // SUB-CONTROLLER: pull each panel SVG in, then hand back.

        var slots = Array.prototype.slice.call(
            document.querySelectorAll('.panel[data-src]'));
        var remaining = slots.length;

        if (!remaining) { onDone(); return; }

        slots.forEach(function (slot) {
            fetch(slot.dataset.src)
                .then(function (r) { return r.text(); })
                .then(function (svg) {
                    injectPanel(slot, svg);
                    if (--remaining === 0) { onDone(); }
                })
                .catch(function (err) {
                    reportPanelFailure(slot, err);
                    if (--remaining === 0) { onDone(); }
                });
        });

        function injectPanel(slot, svg) {
            // VIEW: place one panel's markup (TERMINAL)
            slot.innerHTML = svg;
        }

        function reportPanelFailure(slot, err) {
            // VIEW: surface a missing panel rather than failing silently (TERMINAL)
            slot.innerHTML = '<p class="panelerror">Could not load ' +
                slot.dataset.src + '. Serve the folder over http, not file://.</p>';
            console.error('panel load failed:', slot.dataset.src, err);
        }
    }

    function wireInteractions() {
        // SUB-CONTROLLER: attach node clicks, the note disclosure, and
        // keyboard traversal.

        document.querySelectorAll('.node').forEach(function (node) {
            node.addEventListener('click', function () {
                selectStep(node.dataset.key);
            });
            node.addEventListener('keydown', function (e) {
                if (e.key === 'Enter') { selectStep(node.dataset.key); }
            });
        });

        // Cap elements in panel 9 carry data-goto. Wired here rather than in
        // the panel, because a panel is markup and knows nothing about which
        // step it is in.
        document.querySelectorAll('[data-goto]').forEach(function (el) {
            el.addEventListener('click', function () {
                selectStep(el.dataset.goto);
            });
            el.addEventListener('keydown', function (e) {
                if (e.key === 'Enter' || e.key === ' ') {
                    selectStep(el.dataset.goto);
                    e.preventDefault();
                }
            });
        });

        // The note disclosure is one control for every panel rather than one
        // per panel, so its open state survives moving between steps. Someone
        // reading the drawing rationale is usually comparing panels.
        var toggle = document.getElementById('notetoggle');
        if (toggle) {
            toggle.addEventListener('click', function () {
                setNoteOpen(!isNoteOpen());
            });
        }

        // The cap indicator key. One dialog for the whole figure, for the same
        // reason the note disclosure is one control: what it explains does not
        // change between panels.
        bindCapKey();

        document.addEventListener('keydown', function (e) {
            if (e.key === 'Escape' && isCapKeyOpen()) {
                setCapKeyOpen(false);
                e.preventDefault();
                return;
            }
            // Arrow keys move between panels, and they must not do that while
            // the dialog has the reader's attention.
            if (isCapKeyOpen()) { return; }
            var next = resolveKeyTarget(e.key, currentStep);
            if (next) { selectStep(next); e.preventDefault(); }
        });

        function bindCapKey() {
            // SUB-CONTROLLER: open and close the cap indicator key
            var open = document.getElementById('capkeybtn');
            var close = document.getElementById('capkeyclose');
            var modal = document.getElementById('capkey');
            if (open) {
                open.addEventListener('click', function () { setCapKeyOpen(true); });
            }
            if (close) {
                close.addEventListener('click', function () { setCapKeyOpen(false); });
            }
            if (modal) {
                // Backdrop only. A click inside the box is a click on the text.
                modal.addEventListener('click', function (e) {
                    if (e.target === modal) { setCapKeyOpen(false); }
                });
            }
        }

        function resolveKeyTarget(key, from) {
            // MODEL: which step an arrow key leads to (TERMINAL)
            var i = ORDER.indexOf(from);
            if (key === 'ArrowDown' || key === 'ArrowRight') {
                return ORDER[Math.min(ORDER.length - 1, i < 0 ? 0 : i + 1)];
            }
            if (key === 'ArrowUp' || key === 'ArrowLeft') {
                return ORDER[Math.max(0, i < 0 ? 0 : i - 1)];
            }
            return null;
        }
    }
}


var currentStep = null;

function selectStep(key) {
    // CONTROLLER: render one step across nav, header, stage, caption, notes,
    // references and transport.

    if (!META[key]) { return; }
    currentStep = key;

    var view = buildStepView(key);

    paintNav(view);
    paintHeader(view);
    paintStage(view);
    paintCaptionRegion(view);

    runAnimation('load', key);
    paintDerived(document.getElementById(view.panelId));

    function buildStepView(key) {
        // MODEL: assemble everything the views need (TERMINAL)
        var m = META[key];
        var off = key.indexOf('off') === 0;
        return {
            key:        key,
            num:        m.num + '.',
            title:      m.title,
            caption:    m.caption,
            note:       m.note || '',
            hasNote:    !!(m.note && m.note.trim()),
            phase:      m.phase,
            phaseLabel: m.phaseLabel,
            panelId:    'p-' + key,
            animated:   isAnimated(key),
            hint:       (off ? 'Offshoot branch, not on the main line. ' : '') +
                        (isAnimated(key)
                            ? 'Animated. Press play, or scrub frame by frame.' : '')
        };
    }

    function paintNav(view) {
        // VIEW: selected node and lit phase band (TERMINAL)
        document.querySelectorAll('.node').forEach(function (n) {
            n.classList.toggle('sel', n.dataset.key === view.key);
        });
        document.querySelectorAll('.band').forEach(function (b) {
            b.classList.toggle('on', b.dataset.phase === view.phase);
        });
    }

    function paintHeader(view) {
        // VIEW: phase chip, number, title (TERMINAL)
        var chip = document.getElementById('chip');
        chip.className = 'chip ' + view.phase;
        chip.textContent = view.phaseLabel;
        document.getElementById('num').textContent = view.num;
        document.getElementById('title').textContent = view.title;
    }

    function paintStage(view) {
        // VIEW: reveal the matching panel (TERMINAL)
        document.querySelectorAll('.panel').forEach(function (p) {
            p.classList.toggle('on', p.id === view.panelId);
        });
    }

    function paintCaptionRegion(view) {
        // SUB-CONTROLLER: caption, hint, drawing note and reference list.
        //
        // A sub-controller rather than a view, because the caption and the
        // note are cited text and cite.js owns how a \cite marker becomes a
        // link. Everything terminal below it is still a view.

        renderCitedText(document.getElementById('cap'), view.caption, view.key);
        paintHint(view);
        paintNote(view);
        renderReferenceList(document.getElementById('refs'), view.key);

        function paintHint(view) {
            // VIEW: the playback and offshoot hint (TERMINAL)
            document.getElementById('hint').textContent = view.hint;
        }

        function paintNote(view) {
            // SUB-CONTROLLER: the drawing rationale and its disclosure.

            var wrap = document.getElementById('notewrap');
            var body = document.getElementById('note');

            if (!wrap || !body) { return; }

            if (!view.hasNote) {
                hideNote(wrap, body);
                return;
            }

            showNote(wrap);
            renderCitedText(body, view.note, view.key);
            setNoteOpen(isNoteOpen());

            function hideNote(wrap, body) {
                // VIEW: no note for this panel, so no control for it, and no
                // stale text left behind the collapsed disclosure (TERMINAL)
                wrap.classList.remove('has');
                while (body.firstChild) { body.removeChild(body.firstChild); }
            }

            function showNote(wrap) {
                // VIEW: reveal the disclosure control (TERMINAL)
                wrap.classList.add('has');
            }
        }
    }
}


/* === SHARED FUNCTIONS ================================================== */

function isNoteOpen() {
    // MODEL: whether the drawing note is currently expanded (TERMINAL)
    var wrap = document.getElementById('notewrap');
    return !!(wrap && wrap.classList.contains('open'));
}

function setNoteOpen(open) {
    // VIEW: expand or collapse the drawing note (TERMINAL)
    var wrap = document.getElementById('notewrap');
    var toggle = document.getElementById('notetoggle');
    if (!wrap || !toggle) { return; }

    wrap.classList.toggle('open', !!open);
    toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    toggle.textContent = open ? 'Hide More Context'
                              : 'More Context';
}

function isCapKeyOpen() {
    // MODEL: is the cap indicator key showing (TERMINAL)
    var modal = document.getElementById('capkey');
    return !!modal && modal.classList.contains('open');
}

function setCapKeyOpen(open) {
    // VIEW: show or hide the cap indicator key (TERMINAL)
    //
    // Focus goes to the close button on open and back to the opener on close,
    // so the dialog is usable without a mouse and does not strand the reader
    // at the top of the document afterwards.
    var modal = document.getElementById('capkey');
    var btn = document.getElementById('capkeybtn');
    if (!modal) { return; }

    modal.classList.toggle('open', !!open);
    if (btn) { btn.setAttribute('aria-expanded', open ? 'true' : 'false'); }

    if (open) {
        var close = document.getElementById('capkeyclose');
        if (close) { close.focus(); }
    } else if (btn) {
        btn.focus();
    }
}

initWorkflow();