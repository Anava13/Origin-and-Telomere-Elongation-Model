/* Citations and LaTeX-subset rendering for the workflow captions.

   Captions and drawing notes in src/data.js are LaTeX source, in the same
   form as the dissertation. So are the field values in src/refs.bib. Both are
   parsed by parseTeX into a node list, and that node list is then emitted
   either as DOM, for the caption and the note, or as plain text, for the
   reference lines and the link titles.

   Before this, the two paths were separate scanners with disjoint coverage:
   the caption path knew \cite and nothing else, and the bibliography path
   knew accents and escaped literals and nothing else. A caption containing
   -- or \% or an accented surname rendered its source verbatim, and a
   bibliography field containing \textit lost its braces silently. One parser
   and two emitters removes both failures, because a command is either in the
   table for every string in the figure or in none of them.

   Anything the parser does not recognise is emitted as a visible marker
   rather than dropped. The old brace-stripping pass ended by deleting every
   surviving brace, which meant an unrecognised command quietly ate its own
   argument delimiters and nobody found out. An unknown command is now as
   visible as an unresolved cite key, and for the same reason.

   Link resolution mirrors the \cite command in the dissertation preamble:
   doi if present, else url, else a Google Scholar title-plus-author search.
   If the figure and the PDF resolved the same key differently that would be a
   bug nobody would ever see, so the order is deliberately identical.

   Nested MVC. Three base-level controllers, because these are three separate
   jobs rather than three stages of one:

     initCitations       load refs.bib, parse it, assign every number
     renderCitedText     paint one raw string into an element
     renderReferenceList paint the reference list for one panel

   Shared functions sit at the bottom, at base level, because more than one
   controller calls each of them.

   Two notes on the terminal rule, both of which this file relies on.

   First, parseTeX and the node walkers call themselves. A function that calls
   only itself has one edge, that edge is visible in its own body, and the
   whole subtree is one unit at the call site, which is what the terminal rule
   is protecting. Flattening the recursion into an explicit stack would satisfy
   the letter of the rule and produce a brace-matching state machine that is
   harder to check than the recursion it replaced. So: a model function may
   call itself, and nothing else.

   Second, the shared model functions at the bottom compose with each other:
   deTeX calls parseTeX, and citeFormatReference calls deTeX. That was already
   true of this file before the rewrite. They are pure, they have no side
   effects, and they return values rather than touching the document, so they
   behave as a library rather than as a hidden call graph. The controller and
   view separation above them is unchanged and strict.

   REMOVED: citeSegments. It scanned a raw string into alternating prose and
   cite segments, and both of its callers now walk the parse tree instead.
   Nothing else in src/ referenced it, but grep tools/test_engine.js before
   deleting the old file: a test asserting on segment shape would fail with a
   ReferenceError rather than a diff.
*/

/* Numbering scope. "panel" restarts at [1] in every panel and puts the list of
   that panel's references directly under its caption, which is self-contained:
   the reader only ever sees one panel, and never has to resolve a number
   against a list somewhere else. "global" numbers once across the whole figure
   in PANEL_ORDER, so a paper keeps one number everywhere, at the cost of the
   numbers under a panel starting somewhere in the twenties.

   Changing this string is the whole switch. Nothing else reads scope. */
const CITE_SCOPE = "panel";

/* Populated by initCitations. Nothing may read these before its callback. */
var BIB = {};          // key -> parsed entry
var CITE_NUMBERS = {}; // panelKey -> { citeKey: number }
var CITE_LIST = {};    // panelKey -> [citeKey], in order of first appearance
var CITE_MISSING = []; // keys cited by a caption with no entry in refs.bib


/* === LATEX SUBSET TABLES =============================================== */
/* Data, not code. parseTeX reads these and nothing else decides what the
   accepted language is, so adding a command means adding a row here.

   The subset stops short of math mode on purpose. The panels already resolve
   primes and arrows as numeric entities, so the captions can reach the same
   glyphs through TEX_SYMBOLS, and accepting $...$ would mean implementing
   spacing and script positioning with no natural place to stop. */

/* Characters that are only themselves once escaped. */
var TEX_LITERALS = {
    "&": "&", "%": "%", "$": "$", "_": "_", "#": "#",
    "{": "{", "}": "}"
};

/* Explicit spacing commands. Thin spaces stay thin, because \, in a caption is
   usually separating a number from a unit. */
var TEX_SPACES = {
    ",": "\u2009", ";": "\u2009", ":": "\u2009", " ": " "
};

/* Accent markers that are punctuation rather than letters, so \'e needs no
   separator. */
var TEX_MARKERS = "'`\"^~=.";

/* Accent markers that are letters, so \c c and \v{s} both need the argument
   read separately. */
var TEX_LETTER_ACCENTS = { c: true, v: true, u: true, H: true, r: true };

/* marker + letter -> character. Covers the accents in this bibliography plus
   the ones a yeast reference list tends to acquire. */
var TEX_ACCENTS = {
    "'a": "\u00e1", "'e": "\u00e9", "'i": "\u00ed", "'o": "\u00f3",
    "'u": "\u00fa", "'y": "\u00fd", "'n": "\u0144", "'c": "\u0107",
    "'s": "\u015b", "'z": "\u017a",
    "'A": "\u00c1", "'E": "\u00c9", "'I": "\u00cd", "'O": "\u00d3",
    "'U": "\u00da", "'N": "\u0143", "'C": "\u0106", "'S": "\u015a",

    "`a": "\u00e0", "`e": "\u00e8", "`i": "\u00ec", "`o": "\u00f2",
    "`u": "\u00f9",
    "`A": "\u00c0", "`E": "\u00c8", "`O": "\u00d2", "`U": "\u00d9",

    '"a': "\u00e4", '"e': "\u00eb", '"i': "\u00ef", '"o': "\u00f6",
    '"u': "\u00fc", '"y': "\u00ff",
    '"A': "\u00c4", '"E': "\u00cb", '"I': "\u00cf", '"O': "\u00d6",
    '"U': "\u00dc",

    "^a": "\u00e2", "^e": "\u00ea", "^i": "\u00ee", "^o": "\u00f4",
    "^u": "\u00fb",
    "^A": "\u00c2", "^E": "\u00ca", "^I": "\u00ce", "^O": "\u00d4",
    "^U": "\u00db",

    "~n": "\u00f1", "~a": "\u00e3", "~o": "\u00f5",
    "~N": "\u00d1", "~A": "\u00c3", "~O": "\u00d5",

    "=a": "\u0101", "=e": "\u0113", "=i": "\u012b", "=o": "\u014d",
    "=u": "\u016b",

    ".z": "\u017c", ".c": "\u010b", ".e": "\u0117",

    "cc": "\u00e7", "cC": "\u00c7", "cs": "\u015f", "ct": "\u0163",
    "vs": "\u0161", "vc": "\u010d", "vz": "\u017e", "vr": "\u0159",
    "vS": "\u0160", "vC": "\u010c", "vZ": "\u017d", "ve": "\u011b",
    "un": "\u0148", "ug": "\u011f",
    "Ho": "\u0151", "Hu": "\u0171",
    "ra": "\u00e5", "rA": "\u00c5", "ru": "\u016f"
};

/* Standalone glyph commands. Each takes no argument, though LaTeX allows an
   empty group after it, which the parser swallows as an empty group. */
var TEX_SYMBOLS = {
    ss: "\u00df", aa: "\u00e5", AA: "\u00c5", o: "\u00f8", O: "\u00d8",
    l: "\u0142", L: "\u0141", ae: "\u00e6", AE: "\u00c6",
    oe: "\u0153", OE: "\u0152",

    alpha: "\u03b1", beta: "\u03b2", gamma: "\u03b3", delta: "\u03b4",
    epsilon: "\u03b5", zeta: "\u03b6", eta: "\u03b7", theta: "\u03b8",
    kappa: "\u03ba", lambda: "\u03bb", mu: "\u03bc", nu: "\u03bd",
    xi: "\u03be", pi: "\u03c0", rho: "\u03c1", sigma: "\u03c3",
    tau: "\u03c4", phi: "\u03c6", chi: "\u03c7", psi: "\u03c8",
    omega: "\u03c9",
    Gamma: "\u0393", Delta: "\u0394", Theta: "\u0398", Lambda: "\u039b",
    Xi: "\u039e", Pi: "\u03a0", Sigma: "\u03a3", Phi: "\u03a6",
    Psi: "\u03a8", Omega: "\u03a9",

    rightarrow: "\u2192", leftarrow: "\u2190", leftrightarrow: "\u2194",
    Rightarrow: "\u21d2", Leftarrow: "\u21d0",
    uparrow: "\u2191", downarrow: "\u2193",

    prime: "\u2032", degree: "\u00b0", times: "\u00d7", cdot: "\u00b7",
    pm: "\u00b1", approx: "\u2248", neq: "\u2260", leq: "\u2264",
    geq: "\u2265", sim: "\u223c", infty: "\u221e",

    ldots: "\u2026", dots: "\u2026",
    textperiodcentered: "\u00b7", textendash: "\u2013",
    textemdash: "\u2014", textquoteright: "\u2019", textquoteleft: "\u2018",
    textbackslash: "\\", textasciitilde: "~", textbar: "|",
    textmu: "\u03bc", textdegree: "\u00b0", texttimes: "\u00d7",
    nbsp: "\u00a0"
};

/* Commands that wrap a run of text. tag is the element the DOM emitter builds;
   the plain-text emitter ignores all of this and keeps only the body.

   textit maps to i rather than em because the thing it marks in this figure is
   a species or gene name, which is offset text and not emphasis. emph keeps em
   for the cases that really are emphasis, so the two stay distinguishable in
   the source and in the output. */
var TEX_STYLES = {
    textbf:    { tag: "strong" },
    textit:    { tag: "i" },
    emph:      { tag: "em" },
    texttt:    { tag: "code" },
    underline: { tag: "u" },
    textsc:    { tag: "span", cls: "smallcaps" },
    textsuperscript: { tag: "sup" },
    textsubscript:   { tag: "sub" }
};


function initCitations(onDone) {
    // CONTROLLER: get refs.bib in, parse it, assign every number.

    readBibSource(function (text) {
        BIB = parseBibtex(text);
        assignNumbers();
        onDone();
    });

    function readBibSource(receive) {
        // SUB-CONTROLLER: the source is an inlined block in dist/ and a file
        // over http in src/. Same text either way.

        var inlined = document.getElementById("bibsrc");

        if (inlined) {
            receive(inlined.textContent);
            return;
        }

        fetch("refs.bib")
            .then(function (r) { return r.text(); })
            .then(receive)
            .catch(function (err) {
                reportBibFailure(err);
                receive("");
            });

        function reportBibFailure(err) {
            // VIEW: surface a missing bibliography rather than rendering
            // fifteen captions full of [?] with no explanation (TERMINAL)
            var cap = document.getElementById("cap");
            if (cap) {
                cap.innerHTML = '<p class="panelerror">Could not load refs.bib. ' +
                    'Serve the folder over http, not file://.</p>';
            }
            console.error("bibliography load failed:", err);
        }
    }

    function parseBibtex(text) {
        // SUB-CONTROLLER: BibTeX text to an object keyed by cite key.
        //
        // Field values are stored as raw source. deTeX runs at display time
        // rather than here, so the stored entry stays the thing that was
        // written and any change to the command tables takes effect without
        // reparsing the bibliography.

        var bib = {};
        var i = 0;

        while (i < text.length) {
            var at = findNextEntry(text, i);
            if (at < 0) { break; }
            var entry = readEntry(text, at);
            if (!entry) { break; }
            bib[entry.key] = entry.fields;
            i = entry.end;
        }

        return bib;

        function findNextEntry(text, from) {
            // MODEL: index of the next @ that starts an entry rather than
            // sitting inside a comment line (TERMINAL)
            var i = from;
            while (i < text.length) {
                var ch = text.charAt(i);
                if (ch === "%") {
                    var nl = text.indexOf("\n", i);
                    i = nl < 0 ? text.length : nl + 1;
                    continue;
                }
                if (ch === "@") { return i; }
                i++;
            }
            return -1;
        }

        function readEntry(text, at) {
            // MODEL: one @type{key, field=..., ...} block (TERMINAL)
            var open = text.indexOf("{", at);
            if (open < 0) { return null; }

            // walk to the matching close brace, so nested braces in a value
            // cannot end the entry early
            var depth = 0;
            var close = -1;
            for (var i = open; i < text.length; i++) {
                var ch = text.charAt(i);
                if (ch === "{") { depth++; }
                else if (ch === "}") {
                    depth--;
                    if (depth === 0) { close = i; break; }
                }
            }
            if (close < 0) { return null; }

            var body = text.slice(open + 1, close);
            var comma = body.indexOf(",");
            if (comma < 0) { return null; }

            var key = body.slice(0, comma).trim();
            var rest = body.slice(comma + 1);
            var fields = {};

            var pos = 0;
            while (pos < rest.length) {
                var eq = rest.indexOf("=", pos);
                if (eq < 0) { break; }

                var name = rest.slice(pos, eq).replace(/^[\s,]+|[\s,]+$/g, "").toLowerCase();
                var vi = eq + 1;
                while (vi < rest.length && /\s/.test(rest.charAt(vi))) { vi++; }

                var value = "";
                var opener = rest.charAt(vi);

                if (opener === "{") {
                    var d = 0;
                    var vs = vi;
                    for (var j = vi; j < rest.length; j++) {
                        var c = rest.charAt(j);
                        if (c === "{") { d++; }
                        else if (c === "}") {
                            d--;
                            if (d === 0) {
                                value = rest.slice(vs + 1, j);
                                pos = j + 1;
                                break;
                            }
                        }
                    }
                    if (d !== 0) { break; }
                } else if (opener === '"') {
                    var end = rest.indexOf('"', vi + 1);
                    if (end < 0) { break; }
                    value = rest.slice(vi + 1, end);
                    pos = end + 1;
                } else {
                    var stop = vi;
                    while (stop < rest.length && rest.charAt(stop) !== ",") { stop++; }
                    value = rest.slice(vi, stop);
                    pos = stop + 1;
                }

                if (name) { fields[name] = value.replace(/\s+/g, " ").trim(); }
            }

            return { key: key, fields: fields, end: close + 1 };
        }
    }

    function assignNumbers() {
        // SUB-CONTROLLER: fill CITE_NUMBERS, CITE_LIST and CITE_MISSING.
        //
        // Runs once, before the first selectStep. renderCitedText only ever
        // reads what this leaves behind, so repainting a panel, or the same
        // panel repeatedly, cannot renumber anything.

        var order = orderedPanels();

        if (CITE_SCOPE === "global") {
            numberGlobally(order);
        } else {
            numberPerPanel(order);
        }

        recordMissingKeys(order);

        function orderedPanels() {
            // MODEL: the reading order numbering walks (TERMINAL)
            if (typeof PANEL_ORDER !== "undefined" && PANEL_ORDER.length) {
                return PANEL_ORDER.slice();
            }
            return Object.keys(META);
        }

        function numberPerPanel(order) {
            // MODEL: each panel restarts at 1 (TERMINAL)
            order.forEach(function (key) {
                var keys = citeKeysIn(citedTextOf(key));
                var map = {};
                keys.forEach(function (k, i) { map[k] = i + 1; });
                CITE_NUMBERS[key] = map;
                CITE_LIST[key] = keys;
            });
        }

        function numberGlobally(order) {
            // MODEL: one sequence across the whole figure (TERMINAL)
            var seen = {};
            var next = 1;

            order.forEach(function (key) {
                var keys = citeKeysIn(citedTextOf(key));
                keys.forEach(function (k) {
                    if (!seen.hasOwnProperty(k)) { seen[k] = next++; }
                });
                CITE_LIST[key] = keys;
            });

            order.forEach(function (key) { CITE_NUMBERS[key] = seen; });
        }

        function recordMissingKeys(order) {
            // MODEL: keys cited by a caption that refs.bib does not define
            // (TERMINAL)
            var seen = {};
            order.forEach(function (key) {
                (CITE_LIST[key] || []).forEach(function (k) {
                    if (!BIB[k] && !seen[k]) {
                        seen[k] = true;
                        CITE_MISSING.push(k);
                    }
                });
            });
            if (CITE_MISSING.length) {
                console.warn("cite: no refs.bib entry for " + CITE_MISSING.join(", "));
            }
        }
    }
}


function renderCitedText(el, rawText, panelKey) {
    // CONTROLLER: paint one raw caption or note into an element.
    //
    // Paragraphs are split before parsing, so a command may not span a blank
    // line. That is the same constraint LaTeX itself puts on \textbf, and it
    // keeps the parser working on one paragraph at a time rather than having
    // to carry an open group across a paragraph break.

    clearElement(el);

    if (!rawText) { return; }

    splitParagraphs(rawText).forEach(function (para) {
        var p = appendParagraph(el);
        paintNodes(p, parseTeX(para), panelKey);
    });

    function paintNodes(parent, nodes, panelKey) {
        // SUB-CONTROLLER: walk one node list into one element.
        //
        // Calls itself for the body of a style command, which is the only
        // place nesting occurs.

        nodes.forEach(function (node) {
            if (node.type === "text") {
                appendText(parent, node.value);
            } else if (node.type === "style") {
                paintNodes(openStyle(parent, node), node.body, panelKey);
            } else if (node.type === "cite") {
                appendCitation(parent, node.keys, panelKey);
            } else {
                appendUnknownCommand(parent, node.name);
            }
        });

        function appendText(parent, value) {
            // VIEW: a run of prose (TERMINAL)
            parent.appendChild(document.createTextNode(value));
        }

        function openStyle(parent, node) {
            // VIEW: the element a style command wraps its body in, returned so
            // the walk can descend into it (TERMINAL)
            var spec = TEX_STYLES[node.name] || { tag: "span" };
            var el = document.createElement(spec.tag);
            if (spec.cls) { el.className = spec.cls; }
            parent.appendChild(el);
            return el;
        }

        function appendUnknownCommand(parent, name) {
            // VIEW: a command with no row in the tables. Visible, and carrying
            // its own name, because the failure this replaces was a command
            // silently rendering as its own source or losing its braces
            // (TERMINAL)
            var span = document.createElement("span");
            span.className = "texunknown";
            span.textContent = "\\" + name;
            span.title = "No rule for \\" + name + " in the LaTeX subset";
            parent.appendChild(span);
        }

        function appendCitation(parent, keys, panelKey) {
            // SUB-CONTROLLER: one bracketed group, one link per key.

            appendBracket(parent, "[");

            keys.forEach(function (key, i) {
                if (i) { appendBracket(parent, ","); }
                appendOneLink(parent, key, panelKey);
            });

            appendBracket(parent, "]");

            function appendBracket(parent, value) {
                // VIEW: the punctuation around a citation group, plain text so
                // a reader dragging to select a sentence gets the sentence
                // rather than a partly-selected anchor (TERMINAL)
                parent.appendChild(document.createTextNode(value));
            }

            function appendOneLink(parent, key, panelKey) {
                // SUB-CONTROLLER: resolve then draw a single reference.

                var entry = BIB[key];
                var num = citeNumberFor(key, panelKey);

                if (!entry) {
                    appendBrokenCitation(parent, key);
                    return;
                }

                appendCitationLink(parent, {
                    num:   num,
                    href:  citeHref(key, entry),
                    label: citeFormatReference(key, entry)
                });

                function appendBrokenCitation(parent, key) {
                    // VIEW: a cited key with no entry, visible rather than
                    // silently dropped (TERMINAL)
                    var span = document.createElement("span");
                    span.className = "citemissing";
                    span.textContent = "?";
                    span.title = "No entry for " + key + " in refs.bib";
                    parent.appendChild(span);
                }

                function appendCitationLink(parent, spec) {
                    // VIEW: the numbered anchor (TERMINAL)
                    var a = document.createElement("a");
                    a.className = "citeref";
                    a.href = spec.href;
                    a.target = "_blank";
                    a.rel = "noopener noreferrer";
                    a.textContent = String(spec.num);
                    a.title = spec.label;
                    parent.appendChild(a);
                }
            }
        }
    }

    function clearElement(el) {
        // VIEW: empty a container without leaving detached listeners behind
        // (TERMINAL)
        while (el.firstChild) { el.removeChild(el.firstChild); }
    }

    function splitParagraphs(rawText) {
        // MODEL: blank-line separated blocks (TERMINAL)
        return rawText.split(/\n[ \t]*\n/)
            .map(function (s) { return s.replace(/\s*\n\s*/g, " ").trim(); })
            .filter(function (s) { return s.length > 0; });
    }

    function appendParagraph(el) {
        // VIEW: one paragraph container (TERMINAL)
        var p = document.createElement("p");
        el.appendChild(p);
        return p;
    }
}


function renderReferenceList(el, panelKey) {
    // CONTROLLER: paint the reference list belonging to one panel.

    var keys = CITE_LIST[panelKey] || [];

    emptyList(el);

    if (!keys.length) {
        hideList(el);
        return;
    }

    showList(el);
    addListHeading(el);
    keys.forEach(function (key) { addListEntry(el, key, panelKey); });

    function addListEntry(el, key, panelKey) {
        // SUB-CONTROLLER: one numbered, linked reference line.

        var entry = BIB[key];

        if (!entry) {
            addBrokenEntry(el, key, citeNumberFor(key, panelKey));
            return;
        }

        addResolvedEntry(el, {
            num:   citeNumberFor(key, panelKey),
            href:  citeHref(key, entry),
            label: citeFormatReference(key, entry)
        });

        function addBrokenEntry(el, key, num) {
            // VIEW: a reference with no entry (TERMINAL)
            var li = document.createElement("li");
            li.className = "refitem broken";
            li.value = num;
            li.textContent = key + " (no entry in refs.bib)";
            el.appendChild(li);
        }

        function addResolvedEntry(el, spec) {
            // VIEW: a reference line whose text is the link (TERMINAL)
            var li = document.createElement("li");
            li.className = "refitem";
            li.value = spec.num;

            var a = document.createElement("a");
            a.href = spec.href;
            a.target = "_blank";
            a.rel = "noopener noreferrer";
            a.textContent = spec.label;

            li.appendChild(a);
            el.appendChild(li);
        }
    }

    function emptyList(el) {
        // VIEW: clear the list (TERMINAL)
        while (el.firstChild) { el.removeChild(el.firstChild); }
    }

    function hideList(el) {
        // VIEW: no references, no heading, no empty box (TERMINAL)
        el.classList.remove("on");
    }

    function showList(el) {
        // VIEW: reveal the list (TERMINAL)
        el.classList.add("on");
    }

    function addListHeading(el) {
        // VIEW: the word References, as a list item so the <ol> stays valid
        // markup and the heading cannot be numbered (TERMINAL)
        var head = document.createElement("li");
        head.className = "refhead";
        head.textContent = "References";
        el.appendChild(head);
    }
}


/* === SHARED FUNCTIONS ================================================== */

function parseTeX(raw) {
    // MODEL: a LaTeX-subset string as a node list. Self-recursive on brace
    // groups and command arguments, and on nothing else. (TERMINAL)
    //
    // Node types:
    //   { type: "text",    value }              a run of prose
    //   { type: "cite",    keys }               \cite or \citeu
    //   { type: "style",   name, body }         a command wrapping a body
    //   { type: "unknown", name }               a command with no rule
    //
    // A brace group with no command in front of it contributes its contents
    // and disappears, which is how BibTeX capitalisation protection, {DNA},
    // renders as DNA rather than as {DNA} or as a stripped brace pair that
    // took an unrecognised command's argument with it.

    if (!raw) { return []; }

    var out = [];
    var buf = "";
    var i = 0;
    var n = raw.length;

    while (i < n) {
        var ch = raw.charAt(i);
        var j;

        // --- brace group with no command ---------------------------------
        if (ch === "{") {
            var gdepth = 0;
            var gclose = -1;
            for (j = i; j < n; j++) {
                var gc = raw.charAt(j);
                if (gc === "{") { gdepth++; }
                else if (gc === "}") {
                    gdepth--;
                    if (gdepth === 0) { gclose = j; break; }
                }
            }
            if (gclose < 0) { buf += ch; i++; continue; }

            if (buf) { out.push({ type: "text", value: buf }); buf = ""; }
            var inner = parseTeX(raw.slice(i + 1, gclose));
            for (j = 0; j < inner.length; j++) { out.push(inner[j]); }
            i = gclose + 1;
            continue;
        }

        // A close brace with no opener. Dropped rather than shown, because it
        // is almost always the tail of a construct the parser already handled.
        if (ch === "}") { i++; continue; }

        // --- non-command punctuation -------------------------------------
        if (ch === "~") { buf += "\u00a0"; i++; continue; }

        if (ch === "-") {
            var run = 0;
            while (i + run < n && raw.charAt(i + run) === "-") { run++; }
            if (run >= 3) { buf += "\u2014"; i += 3; }
            else if (run === 2) { buf += "\u2013"; i += 2; }
            else { buf += "-"; i += 1; }
            continue;
        }

        if (ch !== "\\") { buf += ch; i++; continue; }

        // --- everything after a backslash --------------------------------
        var next = i + 1 < n ? raw.charAt(i + 1) : "";

        if (next === "") { i++; continue; }

        if (TEX_LITERALS.hasOwnProperty(next)) {
            buf += TEX_LITERALS[next];
            i += 2;
            continue;
        }

        if (TEX_SPACES.hasOwnProperty(next)) {
            buf += TEX_SPACES[next];
            i += 2;
            continue;
        }

        // Punctuation accent: \'e, \"{o}, \~n
        if (TEX_MARKERS.indexOf(next) >= 0) {
            var mk = i + 2;
            while (mk < n && raw.charAt(mk) === " ") { mk++; }
            var mbraced = raw.charAt(mk) === "{";
            if (mbraced) { mk++; }
            var mletter = raw.charAt(mk) || "";
            var mafter = mk + 1;
            if (mbraced && raw.charAt(mafter) === "}") { mafter++; }
            buf += TEX_ACCENTS[next + mletter] || mletter;
            i = mafter;
            continue;
        }

        var nameMatch = /^[A-Za-z]+/.exec(raw.slice(i + 1));

        // A lone backslash in front of something that is not a command.
        if (!nameMatch) {
            if (buf) { out.push({ type: "text", value: buf }); buf = ""; }
            out.push({ type: "unknown", name: next });
            i += 2;
            continue;
        }

        var name = nameMatch[0];
        var pos = i + 1 + name.length;

        // Letter accent: \c c, \v{s}
        if (TEX_LETTER_ACCENTS.hasOwnProperty(name)) {
            var lk = pos;
            while (lk < n && raw.charAt(lk) === " ") { lk++; }
            var lbraced = raw.charAt(lk) === "{";
            if (lbraced) { lk++; }
            var lletter = raw.charAt(lk) || "";
            var lafter = lk + 1;
            if (lbraced && raw.charAt(lafter) === "}") { lafter++; }
            buf += TEX_ACCENTS[name + lletter] || lletter;
            i = lafter;
            continue;
        }

        // Standalone glyph: \alpha, \ss, \rightarrow
        if (TEX_SYMBOLS.hasOwnProperty(name)) {
            buf += TEX_SYMBOLS[name];
            i = pos;
            // A control word swallows the whitespace after it, and an empty
            // group is the usual way of putting that space back.
            while (i < n && raw.charAt(i) === " ") { i++; }
            if (raw.charAt(i) === "{" && raw.charAt(i + 1) === "}") { i += 2; }
            continue;
        }

        // Everything below takes one braced argument. Find it, or fall
        // through to the unknown case if there is nothing to take.
        var ak = pos;
        while (ak < n && /\s/.test(raw.charAt(ak))) { ak++; }

        var aclose = -1;
        if (raw.charAt(ak) === "{") {
            var adepth = 0;
            for (j = ak; j < n; j++) {
                var ac = raw.charAt(j);
                if (ac === "{") { adepth++; }
                else if (ac === "}") {
                    adepth--;
                    if (adepth === 0) { aclose = j; break; }
                }
            }
        }

        // \cite{a, b} and \citeu{a}. \citeu is accepted alongside \cite and
        // rendered identically: the unverified-source distinction is handled
        // before anything is pasted in here, so a stray \citeu is a leftover
        // rather than a statement, and dropping it would be worse than
        // treating it as a citation.
        if (name === "cite" || name === "citeu" || name === "citeU") {
            if (aclose < 0) {
                if (buf) { out.push({ type: "text", value: buf }); buf = ""; }
                out.push({ type: "unknown", name: name });
                i = pos;
                continue;
            }
            var keys = raw.slice(ak + 1, aclose).split(",")
                .map(function (s) { return s.trim(); })
                .filter(function (s) { return s.length > 0; });
            if (keys.length) {
                if (buf) { out.push({ type: "text", value: buf }); buf = ""; }
                out.push({ type: "cite", keys: keys });
            }
            i = aclose + 1;
            continue;
        }

        if (TEX_STYLES.hasOwnProperty(name) && aclose >= 0) {
            if (buf) { out.push({ type: "text", value: buf }); buf = ""; }
            out.push({
                type: "style",
                name: name,
                body: parseTeX(raw.slice(ak + 1, aclose))
            });
            i = aclose + 1;
            continue;
        }

        // No rule for this command. The marker goes in, and any argument is
        // parsed and kept, so the failure is visible without costing the
        // reader the words inside it.
        if (buf) { out.push({ type: "text", value: buf }); buf = ""; }
        out.push({ type: "unknown", name: name });
        i = pos;

        if (aclose >= 0) {
            var kept = parseTeX(raw.slice(ak + 1, aclose));
            for (j = 0; j < kept.length; j++) { out.push(kept[j]); }
            i = aclose + 1;
        }
    }

    if (buf) { out.push({ type: "text", value: buf }); }

    return out;
}


function texNodesToPlain(nodes) {
    // MODEL: a node list as display text, for the places that need a string
    // rather than a tree: the reference lines, the link titles and the Scholar
    // query. Style commands contribute their body and nothing else, and an
    // unknown command contributes its own name so a bad field is as visible
    // in the reference list as it is in a caption. Self-recursive on style
    // bodies. (TERMINAL)

    var out = "";

    for (var i = 0; i < nodes.length; i++) {
        var node = nodes[i];
        if (node.type === "text") {
            out += node.value;
        } else if (node.type === "style") {
            out += texNodesToPlain(node.body);
        } else if (node.type === "cite") {
            out += "[" + node.keys.join(", ") + "]";
        } else {
            out += "\\" + node.name;
        }
    }

    return out;
}


function citedTextOf(panelKey) {
    // MODEL: every string in one panel that may carry markers, in the order
    // numbering should walk them (TERMINAL)
    var m = META[panelKey];
    if (!m) { return ""; }
    return (m.caption || "") + "\n\n" + (m.note || "");
}


function citeKeysIn(rawText) {
    // MODEL: every key in a raw string, deduplicated, in order of first
    // appearance. Walks the parse tree, so a key inside \textbf{...} is found
    // rather than hidden by the command wrapping it. (TERMINAL)

    var seen = {};
    var out = [];

    collect(parseTeX(rawText));

    return out;

    function collect(nodes) {
        for (var i = 0; i < nodes.length; i++) {
            var node = nodes[i];
            if (node.type === "cite") {
                for (var j = 0; j < node.keys.length; j++) {
                    var k = node.keys[j];
                    if (!seen[k]) { seen[k] = true; out.push(k); }
                }
            } else if (node.type === "style") {
                collect(node.body);
            }
        }
    }
}


function citeNumberFor(key, panelKey) {
    // MODEL: the number this key carries in this panel (TERMINAL)
    var map = CITE_NUMBERS[panelKey];
    if (map && map.hasOwnProperty(key)) { return map[key]; }
    return "?";
}


function citeHref(key, entry) {
    // MODEL: the three-tier fallback, in the same order as the dissertation
    // \cite command: doi, then url, then a Scholar title-plus-author search.
    //
    // The query is percent-encoded here, which the LaTeX version cannot do.
    // That tier fires only for an entry carrying neither doi nor url.
    // (TERMINAL)
    if (entry.doi) {
        return "https://doi.org/" + entry.doi.replace(/^https?:\/\/(dx\.)?doi\.org\//, "");
    }
    if (entry.url) {
        return entry.url;
    }
    var q = deTeX(entry.title || key) + " " + citeFirstSurname(entry);
    return "https://scholar.google.com/scholar?q=" + encodeURIComponent(q.trim());
}


function citeFirstSurname(entry) {
    // MODEL: the surname of the first listed author (TERMINAL)
    if (!entry.author) { return ""; }
    var first = entry.author.split(/\s+and\s+/)[0] || "";
    first = deTeX(first).trim();
    if (first.indexOf(",") >= 0) { return first.slice(0, first.indexOf(",")).trim(); }
    var parts = first.split(/\s+/);
    return parts[parts.length - 1] || "";
}


function citeFormatReference(key, entry) {
    // MODEL: one reference rendered as a single line (TERMINAL)
    if (!entry) { return key; }

    var names = (entry.author || "").split(/\s+and\s+/)
        .map(function (n) { return deTeX(n).trim(); })
        .filter(function (n) { return n.length > 0; });

    var surnames = names.map(function (n) {
        if (n === "others") { return "others"; }
        if (n.indexOf(",") >= 0) { return n.slice(0, n.indexOf(",")).trim(); }
        var parts = n.split(/\s+/);
        return parts[parts.length - 1];
    });

    var who;
    if (!surnames.length) {
        who = "";
    } else if (surnames.length === 1) {
        who = surnames[0];
    } else if (surnames.length === 2 && surnames[1] !== "others") {
        who = surnames[0] + " and " + surnames[1];
    } else {
        who = surnames[0] + " et al.";
    }

    var bits = [];
    if (who) { bits.push(who); }
    if (entry.year) { bits.push("(" + entry.year + ")"); }

    var head = bits.join(" ");
    var title = deTeX(entry.title || "");
    var venue = deTeX(entry.journal || entry.school || entry.publisher || "");

    var where = venue;
    if (entry.volume) {
        where += " " + entry.volume;
        if (entry.pages) { where += ", " + deTeX(entry.pages); }
    } else if (entry.pages) {
        where += ", " + deTeX(entry.pages);
    }

    var line = head;
    if (title) { line += (line ? ". " : "") + title; }
    if (where.trim()) { line += (line ? ". " : "") + where.trim(); }

    return line.replace(/\.\s*$/, "") + ".";
}


function deTeX(s) {
    // MODEL: BibTeX field source to display text.
    //
    // Kept as a name and a signature because three model functions above call
    // it, but it is now the plain-text emitter over the shared parser rather
    // than a second set of substitutions. Anything the captions can render,
    // a bibliography field can render, and the reverse. (TERMINAL)
    if (!s) { return ""; }
    return texNodesToPlain(parseTeX(s)).replace(/\s+/g, " ").trim();
}