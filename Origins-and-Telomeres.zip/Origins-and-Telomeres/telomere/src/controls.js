/* Playback transport.

   Its own base-level controller, for the reason you gave when we discussed
   sliders: creation, user-driven callbacks, and programmatic position updates
   are three different concerns and do not belong in one function. Creation and
   wiring live here. Programmatic position updates live in animate.js as
   paintTransport, because the engine is what knows the position.
*/

function initTransport() {
    // CONTROLLER: build the transport and connect it to the engine.

    var host = document.getElementById('transport');
    if (!host) { return; }

    buildTransport(host);
    wireTransport();

    function buildTransport(host) {
        // VIEW: lay out the controls (TERMINAL)
        host.innerHTML =
            '<button id="playbtn" type="button">Play</button>' +
            '<button id="prevbtn" type="button" aria-label="Previous frame">&#8249;</button>' +
            '<input id="scrub" type="range" min="0" max="1" step="1" value="0" ' +
                   'aria-label="Animation frame">' +
            '<button id="nextbtn" type="button" aria-label="Next frame">&#8250;</button>' +
            '<span id="framelab"></span>';
    }

    function wireTransport() {
        // SUB-CONTROLLER: route each control to a single engine command.

        document.getElementById('playbtn').addEventListener('click', function () {
            runAnimation('toggle');
        });
        document.getElementById('prevbtn').addEventListener('click', function () {
            runAnimation('step', -1);
        });
        document.getElementById('nextbtn').addEventListener('click', function () {
            runAnimation('step', 1);
        });
        document.getElementById('scrub').addEventListener('input', function (e) {
            runAnimation('seek', parseInt(e.target.value, 10));
        });

        document.addEventListener('keydown', function (e) {
            if (e.key === ' ' && !isTypingTarget(e.target)) {
                runAnimation('toggle');
                e.preventDefault();
            }
        });

        function isTypingTarget(el) {
            // MODEL: should the spacebar be left alone (TERMINAL)
            var tag = (el.tagName || '').toLowerCase();
            return tag === 'input' || tag === 'textarea' || tag === 'select';
        }
    }
}
