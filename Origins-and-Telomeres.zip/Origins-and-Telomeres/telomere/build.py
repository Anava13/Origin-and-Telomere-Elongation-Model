#!/usr/bin/env python3
"""Inline the source tree back into one distributable HTML file.

Edit files in src/. Run tools/make_panels.py if you touched the glyph
vocabulary, then tools/make_shell.py if nav.svg changed, then this. Writes
dist/telomere_workflow.html, which is the version to hand to anyone else.
Nothing in dist/ is edited by hand; it is overwritten on every build.

Note that editing src/data.js or src/refs.bib needs no build step at all. The
browser fetches refs.bib and reads data.js directly over Live Server, so a
caption or a bibliography entry is one save away from being on screen. This
script is only for producing the shareable single file.
"""
import os, re, json

HERE = os.path.dirname(os.path.abspath(__file__))
SRC  = os.path.join(HERE, "src")
DIST = os.path.join(HERE, "dist")
os.makedirs(DIST, exist_ok=True)

# Must match SCRIPTS in tools/make_shell.py exactly, in content and order. The
# replacement below is a single string operation over the joined tags, so a
# mismatch would not raise on its own; the assertion after the join is what
# turns that into a failure instead of a silently broken dist file.
SCRIPTS = ["data.js", "anim-data.js", "animate.js", "controls.js",
           "cite.js", "controller.js"]

html = open(os.path.join(SRC, "index.html"), encoding="utf-8").read()

# stylesheet -> inline <style>
css = open(os.path.join(SRC, "style.css"), encoding="utf-8").read()
html = html.replace('<link rel="stylesheet" href="style.css">',
                    "<style>\n" + css + "</style>")

# phase lookup, read from data.js so there is one source of truth
data_js = open(os.path.join(SRC, "data.js"), encoding="utf-8").read()

def phase_of(key):
    block = re.search(r"\b%s:\s*\{(.*?)\n  \}" % re.escape(key), data_js, re.S)
    if not block:
        raise SystemExit("build: no META entry for %s in data.js" % key)
    return re.search(r'phase:\s*"([^"]+)"', block.group(1)).group(1)

# panel placeholders -> inline <svg>
def inline_panel(m):
    key = m.group(1)
    path = os.path.join(SRC, "panels", key + ".svg")
    if not os.path.exists(path):
        raise SystemExit("build: missing panel %s. Run tools/make_panels.py." % path)
    svg = open(path, encoding="utf-8").read().strip()
    return ('<div class="panel" id="p-%s" data-phase="%s">%s</div>'
            % (key, phase_of(key), svg))

html, n_panels = re.subn(
    r'<div class="panel" id="p-([^"]+)" data-src="[^"]*"></div>', inline_panel, html)

# bibliography -> an inlined block cite.js reads instead of fetching.
#
# type="text/plain" rather than a data attribute or a JS string: the file is
# literal BibTeX, and a script element with an unknown type is not executed,
# not parsed, and does not need any escaping beyond the closing-tag sequence.
bib = open(os.path.join(SRC, "refs.bib"), encoding="utf-8").read()
if "</script" in bib.lower():
    raise SystemExit("build: refs.bib contains a closing script tag")
bib_block = ('<script id="bibsrc" type="text/plain">\n' + bib + "\n</script>")

# scripts -> one inline block, with the fetch loader short-circuited
js = "\n".join(open(os.path.join(SRC, s), encoding="utf-8").read() for s in SCRIPTS)
js = js.replace("loadPanels(settle);", "settle();")

tags = "\n".join('<script src="%s"></script>' % s for s in SCRIPTS)
if tags not in html:
    raise SystemExit(
        "build: script tags in src/index.html do not match SCRIPTS.\n"
        "       SCRIPTS here and in tools/make_shell.py must agree, and\n"
        "       src/index.html must be regenerated after either changes.")

html = html.replace(tags, bib_block + "\n<script>\n" + js + "</script>")

out = os.path.join(DIST, "telomere_workflow.html")
open(out, "w", encoding="utf-8").write(html)
print("wrote %s (%d KB, %d panels inlined, %d bib chars)"
      % (out, len(html) // 1024, n_panels, len(bib)))