"""Build the presentation player from the built telomere viewer.

    python3 build.py && python3 tools/make_player.py
    python3 tools/make_player.py --viewer dist/other.html --out player/index.html

Writes one self-contained HTML file: the timeline panels, their frame tables,
the viewer's stylesheet and the viewer's animation engine, inside the shell in
tools/player-shell.html. The file needs no server and no network, so it can be
opened from disk or served from GitHub Pages and framed on a slide.

Why the live engine and not exported frames. make_figures.py flattens frames
because print needs a file with no stylesheet and no script. A player has no
such limit. Running the engine keeps the stylesheet's transitions, so a move
between frames of one panel is animated, and it means the player shows exactly
what the viewer shows.

What this reads from the viewer. Each piece is found by a marker and checked,
so a change to the build that moves one stops this script with the missing
piece named:
    the first <style> block                       the whole stylesheet
    <div class="panel" id="p-KEY"><svg>...</svg>  one panel per key
    the <script> holding const META               META, ORDER and ANIM
    /* Animation engine. ... /* Playback transport.  the engine, verbatim

META, ORDER and ANIM are JavaScript with comments, unquoted keys and String.raw
captions, so they are evaluated by node and handed back as JSON. The engine is
a slice of the viewer's one script block, because the same block ends by
starting the viewer's own controller, which needs page furniture the player
does not have.

The split steps. One fork passage makes two daughter ends, and the viewer
draws them as two tracks that converge at step 4. Until they converge, a stop
on the timeline drives two panels stacked in one composite: the leading-strand
end above, the lagging-strand end below. A panel's kept frames are spread
across the step's stops in proportion, so both halves start and finish
together.

Panels are cropped to CAMERA, one window for every step, so the substrate
never moves at a step boundary. Furniture in DROP is hidden with CSS and left
in the markup, because the engine still writes to it on every frame.
"""

import glob
import json
import os
import re
import subprocess
import sys

OUT_NAME = "telomere-workflow-player.html"
SHELL_NAME = "player-shell.html"

# The timeline, one entry per step, in order. A step lists the panels it shows:
# one is a single panel, two is the split view. A panel given as
# {"key": ..., "hold": "last"} shows only the last frame of its table.
#
# Step 4 is left out. Everything it draws is on step 5's first frame (Cdc13 on
# the overhang, MRX at the junction, CST reading Cdc13 only), and the crossfade
# out of the split view brings Cdc13 in.
#
# Split 2 holds the lagging end on its last frame while the leading end is
# incised. The viewer has no lag02, and the still lower half carries that.
#
# A title of None takes the title of the first panel from META.
TIMELINE = [
    {"panels": ["step01", "lag01"], "title": "Replication makes two different ends"},
    {"panels": ["step02", {"key": "lag01", "hold": "last"}], "title": None},
    {"panels": ["step03", "lag03"], "title": "Resection at both ends"},
    {"panels": ["step05"], "title": None},
    {"panels": ["step06"], "title": None},
    {"panels": ["step07"], "title": None},
    {"panels": ["step08"], "title": None},
    {"panels": ["step09"], "title": None},
]

# Frames left out of a panel, numbered from 1 as the viewer's frame counter
# shows them. lag01 frame 14 changes nothing on the page; it is a reading beat
# between naming Rad27 and Cdc9 and showing what they do.
SKIP_FRAMES = {"lag01": [14]}

# x, y, width, height in panel units. Every panel is 880 by 300. With the notes
# below hidden, the cap indicator starts at y 0 and the lowest molecule on any
# kept frame is Rad27 in lag01.
CAMERA = (0, 0, 880, 284)

# Vertical space between the two halves of a split step, in panel units.
SPLIT_GAP = 14

# Hidden on every panel. The sentence notes, as in the initiation player, and
# panel 9's instruction to click, which a slide cannot honour. The cap
# indicator stays: its states carry the argument here.
DROP = [".notelab", ".affordance"]


# ===========================================================================
# MAIN CONTROLLER
# ===========================================================================

def build_player(root=None, viewer=None, out=None):
    """CONTROLLER: read the viewer, lay out the timeline, write the player."""
    root = root or _project_root()
    viewer = viewer or find_viewer(root)
    out = out or os.path.join(root, "dist", OUT_NAME)

    # === CHECK INPUTS ===
    stale = newer_sources(root, viewer)
    if stale:
        sys.exit("%s is older than %d source file(s), including %s.\n"
                 "Rebuild first: python3 build.py"
                 % (os.path.relpath(viewer, root), len(stale), ", ".join(stale[:3])))

    # === COORDINATE SUB-CONTROLLERS ===
    html = read_text(viewer)
    parts = extract_viewer_parts(html)
    steps = select_steps(parts)
    page = assemble_player(parts, steps, read_text(os.path.join(root, "tools", SHELL_NAME)))
    write_text(out, page)

    print("wrote %s: %d steps, %d stops, %d KB"
          % (os.path.relpath(out, root), len(steps),
             sum(s["count"] for s in steps), len(page.encode("utf-8")) // 1024))
    return out


# ===========================================================================
# BASE CONTROLLERS
# ===========================================================================

def extract_viewer_parts(html):
    """CONTROLLER: every piece of the viewer the player reuses."""

    def first_style(html):
        """MODEL: the viewer's stylesheet (TERMINAL)."""
        m = re.search(r"<style>(.*?)</style>", html, re.S)
        return m.group(1) if m else None

    def inline_panels(html):
        """MODEL: each panel's svg, keyed by the id on its wrapper (TERMINAL)."""
        found = re.findall(r'<div class="panel" id="p-(\w+)"[^>]*>(<svg.*?</svg>)</div>',
                           html, re.S)
        return dict(found) or None

    def script_data(html):
        """MODEL: META titles and end labels, ORDER and ANIM, evaluated by node
        and returned as one JSON object (TERMINAL)."""
        block = next((b for b in re.findall(r"<script>(.*?)</script>", html, re.S)
                      if "const META" in b and "const ANIM" in b), None)
        if block is None or "/* Animation engine." not in block:
            return None
        data = block.split("/* Animation engine.", 1)[0]
        code = (data + "\n;process.stdout.write(JSON.stringify({"
                "meta: Object.fromEntries(Object.keys(META).map(function (k) {"
                "return [k, {title: META[k].title, end: META[k].phaseLabel}]; })),"
                "order: ORDER, anim: ANIM}));")
        try:
            run = subprocess.run(["node", "-"], input=code, capture_output=True,
                                 text=True, check=True)
        except FileNotFoundError:
            sys.exit("node is needed to read META and ANIM from the viewer.")
        except subprocess.CalledProcessError as err:
            sys.exit("node could not evaluate the viewer's data:\n" + err.stderr)
        return json.loads(run.stdout)

    def engine_slice(html):
        """MODEL: the viewer's animation engine, verbatim (TERMINAL)."""
        m = re.search(r"(/\* Animation engine\..*?)/\* Playback transport\.", html, re.S)
        if not m:
            return None
        body = m.group(1)
        if "function runAnimation" not in body or "function paintDerived" not in body:
            return None
        return body

    data = script_data(html) or {}
    parts = {"style": first_style(html),
             "panels": inline_panels(html),
             "meta": data.get("meta"),
             "anim": data.get("anim"),
             "engine": engine_slice(html)}
    missing = [name for name, value in parts.items() if not value]
    if missing:
        sys.exit("the viewer does not provide: %s" % ", ".join(missing))
    return parts


def select_steps(parts):
    """CONTROLLER: one record per step on the timeline, in order.

    Each panel a step shows gets the frame it is on at every stop of the step.
    A key that appears in more than one step gets an alias from its second
    appearance on, because every panel is in the page at once and the engine
    finds a panel by its id.
    """

    def resolve_spec(panel):
        """MODEL: a panel entry as {key, hold} (TERMINAL)."""
        if isinstance(panel, str):
            return {"key": panel, "hold": None}
        return {"key": panel["key"], "hold": panel.get("hold")}

    def check_present(specs, parts):
        """MODEL: stop on a key the viewer cannot supply in full (TERMINAL)."""
        gaps = [s["key"] for s in specs
                if s["key"] not in parts["panels"] or s["key"] not in parts["meta"]]
        if gaps:
            sys.exit("no panel or no META entry in the viewer for: %s" % ", ".join(gaps))

    def kept_frames(spec, anim):
        """MODEL: the frame indices a panel plays, after SKIP_FRAMES and any
        hold; empty for a static panel (TERMINAL)."""
        table = anim.get(spec["key"])
        total = len(table["frames"]) if table else 0
        drop = set(SKIP_FRAMES.get(spec["key"], []))
        bad = sorted(n for n in drop if not 1 <= n <= total)
        if bad:
            sys.exit("%s has %d frames; SKIP_FRAMES names %s" % (spec["key"], total, bad))
        kept = [i for i in range(total) if i + 1 not in drop]
        if total and not kept:
            sys.exit("SKIP_FRAMES leaves %s with no frames" % spec["key"])
        return kept[-1:] if spec["hold"] == "last" else kept

    def spread(kept, count):
        """MODEL: the frame shown at each of count stops, so the first and last
        kept frames land on the first and last stops; None where the panel is
        static (TERMINAL)."""
        if not kept:
            return [None] * count
        if len(kept) == 1 or count == 1:
            return [kept[-1]] * count
        return [kept[int(round(i * (len(kept) - 1) / float(count - 1)))]
                for i in range(count)]

    seen, out = {}, []
    for entry in TIMELINE:
        specs = [resolve_spec(p) for p in entry["panels"]]
        check_present(specs, parts)
        tables = [kept_frames(s, parts["anim"]) for s in specs]
        count = max(1, max(len(t) for t in tables))
        panels = []
        for spec, kept in zip(specs, tables):
            seen[spec["key"]] = seen.get(spec["key"], 0) + 1
            alias = spec["key"] if seen[spec["key"]] == 1 else \
                "%s__%d" % (spec["key"], seen[spec["key"]])
            panels.append({"key": alias, "source": spec["key"],
                           "end": parts["meta"][spec["key"]]["end"],
                           "frames": spread(kept, count)})
        longest = max(zip(tables, specs), key=lambda ts: len(ts[0]))[1]["key"]
        table = parts["anim"].get(longest)
        first = specs[0]["key"]
        out.append({"view": first if len(specs) == 1 else "split%d" % (len(out) + 1),
                    "num": len(out) + 1,
                    "title": entry["title"] or parts["meta"][first]["title"],
                    "fps": table.get("fps", 1.2) if table else 1.2,
                    "count": count,
                    "panels": panels})
    return out


def assemble_player(parts, steps, shell):
    """CONTROLLER: fill the shell with the timeline's panels and tables."""

    def retag(svg, attrs):
        """MODEL: a panel's opening tag rewritten: viewer class off, viewBox set
        to CAMERA, attrs added (TERMINAL)."""
        head, rest = svg.split(">", 1)
        head = re.sub(r'\s*class="panelsvg"', "", head)
        head = re.sub(r'viewBox="[^"]*"', 'viewBox="%g %g %g %g"' % CAMERA, head, count=1)
        return head + " " + attrs + ">" + rest

    def single_panel(step, parts):
        """MODEL: a one-panel step, the panel itself on the stage (TERMINAL)."""
        p = step["panels"][0]
        return retag(parts["panels"][p["source"]],
                     'class="panelsvg" id="p-%s" data-key="%s"' % (p["key"], step["view"]))

    def split_panel(step, parts):
        """MODEL: a split step, its panels stacked in one composite, each half
        named by the end it draws (TERMINAL)."""
        w, h = CAMERA[2], CAMERA[3]
        n = len(step["panels"])
        total = n * h + (n - 1) * SPLIT_GAP
        body = []
        for i, p in enumerate(step["panels"]):
            y = i * (h + SPLIT_GAP)
            body.append(retag(parts["panels"][p["source"]],
                              'id="p-%s" x="0" y="%d" width="%g" height="%g"'
                              % (p["key"], y, w, h)))
            body.append('<text class="endtag" x="12" y="%d">%s</text>' % (y + 19, p["end"]))
            if i:
                body.append('<line class="splitrule" x1="0" y1="%g" x2="%g" y2="%g"/>'
                            % (y - SPLIT_GAP / 2.0, w, y - SPLIT_GAP / 2.0))
        return ('<svg class="panelsvg split" data-key="%s" viewBox="0 0 %g %g" '
                'preserveAspectRatio="xMidYMid meet" xmlns="http://www.w3.org/2000/svg">'
                '\n%s\n</svg>' % (step["view"], w, total, "\n".join(body)))

    def drop_css():
        """MODEL: one rule hiding every DROP selector inside the stage (TERMINAL)."""
        if not DROP:
            return ""
        return ("%s { display: none !important; }"
                % ", ".join("#stage " + sel for sel in DROP))

    def fill(shell, slots):
        """VIEW: substitute every slot, and stop on one the shell lacks (TERMINAL)."""
        for name, value in slots.items():
            token = "%%" + name + "%%"
            if token not in shell:
                sys.exit("%s has no %s slot" % (SHELL_NAME, token))
            shell = shell.replace(token, value)
        return shell

    panels = "\n".join(single_panel(s, parts) if len(s["panels"]) == 1
                       else split_panel(s, parts) for s in steps)
    anim = {}
    for s in steps:
        for p in s["panels"]:
            if p["source"] in parts["anim"]:
                anim[p["key"]] = parts["anim"][p["source"]]
    records = [{k: v if k != "panels" else
                [{"key": p["key"], "frames": p["frames"]} for p in v]
                for k, v in s.items()} for s in steps]
    # A literal </script> inside the JSON would end the block early.
    as_js = lambda v: json.dumps(v, separators=(",", ":")).replace("</", "<\\/")
    return fill(shell, {"VIEWER_STYLE": parts["style"],
                        "DROP_CSS": drop_css(),
                        "PANELS": panels,
                        "ANIM": as_js(anim),
                        "STEPS": as_js(records),
                        "ENGINE": parts["engine"]})


# ===========================================================================
# SHARED FUNCTIONS
# ===========================================================================

def find_viewer(root):
    """MODEL: the built viewer, if dist/ holds exactly one besides the player
    (TERMINAL)."""
    found = sorted(p for p in glob.glob(os.path.join(root, "dist", "*.html"))
                   if os.path.basename(p) != OUT_NAME)
    if len(found) == 1:
        return found[0]
    if not found:
        sys.exit("no viewer in dist/. Run python3 build.py first.")
    sys.exit("several viewers in dist/, name one with --viewer:\n  %s"
             % "\n  ".join(os.path.relpath(p, root) for p in found))


def newer_sources(root, viewer):
    """MODEL: source files edited since the viewer was built (TERMINAL)."""
    built = os.path.getmtime(viewer)
    src = os.path.join(root, "src")
    names = ["anim-data.js", "data.js", "animate.js", "style.css"]
    paths = [os.path.join(src, n) for n in names]
    paths += glob.glob(os.path.join(src, "panels", "*.svg"))
    return sorted(os.path.relpath(p, root) for p in paths
                  if os.path.isfile(p) and os.path.getmtime(p) > built)


def read_text(path):
    """MODEL: a file's text (TERMINAL)."""
    with open(path, encoding="utf-8") as fh:
        return fh.read()


def write_text(path, text):
    """VIEW: write a file, making its folder if needed (TERMINAL)."""
    folder = os.path.dirname(path)
    if folder and not os.path.isdir(folder):
        os.makedirs(folder)
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(text)


def parse_args(argv):
    """MODEL: --viewer and --out from the command line (TERMINAL)."""
    got, rest = {"viewer": None, "out": None}, list(argv)
    while rest:
        arg = rest.pop(0)
        if arg in ("--viewer", "--out") and rest:
            got[arg[2:]] = os.path.abspath(rest.pop(0))
        else:
            sys.exit("usage: make_player.py [--viewer PATH] [--out PATH]")
    return got


def _project_root():
    """MODEL: the folder holding build.py, from this file's location (TERMINAL)."""
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


if __name__ == "__main__":
    ARGS = parse_args(sys.argv[1:])
    build_player(viewer=ARGS["viewer"], out=ARGS["out"])
