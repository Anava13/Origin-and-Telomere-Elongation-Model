"""Export dissertation figures from the built animation.

    python3 build.py && python3 tools/make_figures.py

Writes one SVG per figure into figures/, plus figures/manifest.txt recording
which frame each part resolved to.

Why a browser. A frame is not a file. src/panels/*.svg holds every element in
its resting state with everything else pending, and a frame only exists once
src/animate.js has applied the frame table and run paintDerived, which computes
the zone tints, Ku's position, the 3' and 5' marks, the cap bar words and the
camera transform. None of that is on disk. So this drives the real page and
reads the result, which means the figures cannot drift from the animation and
none of the engine is reimplemented here.

Why the styles get flattened. tools/render_panels.py resolves CSS itself and its
selector filter rejects anything containing a space, so every ".prot.X .protbody"
rule in the sheet is invisible to it. Letting the browser resolve the cascade and
writing the computed values onto each element removes that whole class of error,
and leaves an SVG with no stylesheet, which converts to PDF cleanly.

Frames are chosen by predicate, never by index. Frame tables get edited; indices
move. A predicate either matches or fails loudly, and the manifest says what it
picked so a wrong choice is visible rather than silent.
"""

import os
import re
import sys
import json

VIEWER = "dist/telomere_workflow.html"
OUT_DIRNAME = "telomere-figures"

# How many unique-sequence blocks of context to leave to the left of the
# content. The panels carry fourteen so the chromosome never visibly ends,
# which is right on screen and wasteful in print: a panned panel spends half
# its width on grey blocks and the telomere ends up too small to read. Three
# still says "this continues" without paying for eleven more.
#
# The count is from the leftmost content, not from the array. Branch C
# resects past the repeats and branch A erodes into them, so in both the
# unique blocks under the action are content and are kept.
KEEP_U = 3

# Screen-only marks, removed from every figure. Panel 9 tells the reader to
# click the glowing elements, which is true of the page and false of a printed
# figure. Anything else carrying the affordance class goes the same way.
DROP_ALWAYS = [".affordance"]

# Glyphs that come off the two-ends figure. The point there is geometric, and
# every one of these is introduced later in the chapter.
DROP_PROTEINS = ['[id^="actor-"]', ".rap1array", ".capbar", ".prot", ".rpa",
                 ".nuclease", ".repl", ".mrx", ".ku", ".cst", ".notelab"]

# ---------------------------------------------------------------------------
# The figure list. Each part names a panel and how to find its frame:
#
#   "frame": "last" | "static" | {"when": <js>, "pick": "first"|"middle"|"last"}
#
# The js runs in the page with F.vis(key, sel) for whether an element is
# visible, and F.off(key, id) for an actor's x offset on that frame.
# ---------------------------------------------------------------------------
FIGURES = [
    {"id": "fig-two-ends", "layout": "stack",
     "parts": [
         # Trimmed. Stripping the proteins leaves each 300-tall panel with about
         # 200 of empty band, so untrimmed the two drawings sit 172 apart with
         # only 9 of that being the gap between them. Trimming to the drawn
         # content is the only thing that closes it, and it roughly doubles the
         # height the DNA prints at for a given text width.
         {"panel": "step01", "frame": "last", "drop": DROP_PROTEINS, "trim": True,
          "label": "(a)", "title": "Blunt-Ended Leading Strand Telomere"},
         {"panel": "lag01", "frame": "last", "drop": DROP_PROTEINS, "trim": True,
          "label": "(b)",
          "title": "Overhang-Containing Lagging Strand Telomere"}]},

    {"id": "fig-erp", "layout": "stack",
     "parts": [
         # Every Okazaki primer on the page at once, terminal one included.
         {"panel": "lag01", "label": "(a)",
          "frame": {"when": "F.vis(k,'#pr-c03') && F.vis(k,'#pr-c06') && "
                            "F.vis(k,'#pr-c09') && F.vis(k,'#pr-c12') && "
                            "F.vis(k,'#pr-c14')", "pick": "last"}},
         {"panel": "lag01", "frame": "last", "label": "(b)"}]},

    # Panel 2 is static and the nick is a CSS animation, not a frame. The
    # browser runs with prefers-reduced-motion, which the stylesheet already
    # answers by switching the animation off, so the nick lands solid.
    {"id": "fig-incision", "layout": "stack",
     "parts": [{"panel": "step02", "frame": "static"}]},

    {"id": "fig-resection", "layout": "stack",
     "parts": [
         # The lobes part on exactly one frame, and no RPA has landed by then:
         # the first unit arrives two beats later, after the lobes have closed.
         # So "both arms in motion with RPA already down" is not a frame this
         # panel has. This takes the lobe-parting frame, which is the one thing
         # only this panel shows. If the figure needs RPA in the same picture it
         # has to be a two-frame strip, not one frame.
         {"panel": "step03", "label": "(a)",
          "frame": {"when": "F.off(k,'actor-mrx-lobeL') !== undefined",
                    "pick": "first"}},
         # First inward beat, so the nucleases sit at the same offset as (a).
         {"panel": "lag03", "label": "(b)",
          "frame": {"when": "F.off(k,'actor-exo1') < 0", "pick": "first"}}]},

    {"id": "fig-cdc13-load", "layout": "stack",
     "parts": [{"panel": "step04", "frame": "static"}]},

    {"id": "fig-tel1", "layout": "stack",
     "parts": [
         # Keep the frame-order disclaimer: it is drawn into the panel, so it
         # comes along on its own as long as nothing drops it.
         {"panel": "step05", "frame": "last", "label": "(a)"},
         {"panel": "offB", "frame": "static", "label": "(b)"}]},

    # Telomerase translocates across these frames. The trail draws it at two
    # earlier positions in reduced opacity, which is the .faint reading the
    # figure already uses for transient, so it needs no new legend entry.
    {"id": "fig-extension", "layout": "stack",
     "parts": [{"panel": "step06", "frame": "last",
                "trail": {"ids": ["actor-tel"], "back": [4, 2],
                          "opacity": [0.2, 0.38]}}]},

    {"id": "fig-termination", "layout": "stack",
     "parts": [{"panel": "step07", "frame": "static"}]},

    # Part way along, so displaced and undisplaced RPA are both on the page.
    # The final frame loses that, which is the whole point of the figure.
    {"id": "fig-fillin", "layout": "stack",
     "parts": [{"panel": "step08",
                "frame": {"when": "F.off(k,'actor-pola') < 0 && "
                                  "F.vis(k,'#rpa-c13') && !F.vis(k,'#rpa-c16')",
                          "pick": "middle"},
                "trail": {"ids": ["actor-pola"], "back": [2],
                          "opacity": [0.28]}}]},

    # Reference panel. It has no cap indicator, no Ku and no frames, so it is
    # not in KEYS or META and the viewer never shows it. It is read straight
    # from src/panels/ instead, which is why it carries "file".
    {"id": "fig-structure", "layout": "stack",
     "parts": [{"panel": "figstructure", "frame": "static", "file": True,
                "trim": True, "keep_u": None}]},

    {"id": "fig-capped", "layout": "stack",
     "parts": [{"panel": "step09", "frame": "static"}]},

    # All four open on the panel 9 state, so the cap indicator makes them
    # directly comparable. Nothing is dropped from these.
    #
    # Stacked, not gridded. Every panel is 880 by 300, so a 2x2 put two arrays
    # on a line and halved the width each got on the page; stacking keeps all
    # four at full width and puts the four termini in one column, which is where
    # the differences are. The figure runs portrait at roughly 914 by 1254.
    {"id": "fig-branches", "layout": "stack", "dividers": True,
     "parts": [
         # Branch A first. It is the only one of the four that removes no cap
         # element, so it reads as the counterfactual the other three are
         # perturbations against, and putting it last made it look like a fourth
         # kind of loss. Note that this renumbers the parts against the chapter
         # to-do, which lists them C, D, E, A.
         {"panel": "offA", "frame": "last", "label": "(a)"},
         {"panel": "offC", "frame": "last", "label": "(b)"},
         {"panel": "offD", "frame": "last", "label": "(c)"},
         {"panel": "offE", "frame": "last", "label": "(d)"}]},
]

# Panels that do not exist yet. fig:structure and fig:supply are specified in
# this figure's own glyph vocabulary, so they belong in tools/make_panels.py as
# p_* functions kept out of KEYS and the nav. Add their keys here once they
# exist and they export with everything else.
PENDING_BUILDS = [
    {"id": "fig-supply", "layout": "stack",
     "parts": [{"panel": "figsupply", "frame": "static"}]},
]

# Properties worth carrying onto each element. Anything not here is either a
# default or has no effect on how an SVG prints.
# "none" is a real value for fill and the SVG default is black, so dropping it
# turns every bracket and every unfilled block into a solid bar. It is only safe
# to drop where the initial value is already none.
DROPPABLE_NONE = ["filter", "stroke-dasharray"]

STYLE_PROPS = ["fill", "fill-opacity", "fill-rule", "stroke", "stroke-width",
               "stroke-opacity", "stroke-dasharray", "stroke-linecap",
               "stroke-linejoin", "opacity", "font-family", "font-size",
               "font-weight", "font-style", "letter-spacing", "text-anchor",
               "dominant-baseline", "filter", "visibility"]

PAGE_API = """
// ANIM and the panel data are top-level const in their scripts, so they live in
// the global lexical scope and never appear on window. They are reachable by
// bare reference from any script in the same realm, which is what this does
// once, so nothing below has to care.
window.__ANIM = (typeof ANIM !== 'undefined') ? ANIM : {};
// A reference panel is loaded into a bare page with no controller, so there is
// nothing to select. The stub lets everything below run unchanged instead of
// branching on which kind of page it is looking at.
if (typeof window.selectStep !== 'function') { window.selectStep = function () {}; }
// Move the left edge in, and carry the panel furniture with it. Furniture is
// positioned against an 880 box, so each piece has to keep the edge it was
// anchored to: the genotype label stays at the left margin, the cap indicator
// stays at the right, and everything centred stays centred, which is a shift of
// half the crop. The DNA itself is untouched; the blocks that fall outside the
// new viewBox are simply not in the picture.
var DRAWN = ['rect', 'circle', 'ellipse', 'path', 'line', 'polygon',
             'polyline', 'text', 'use'];

window.__crop = function (src, clone, k, keepU) {
  var left = window.F.contentLeft(k);
  if (left === null) { return 0; }
  var vb = src.viewBox.baseVal;
  var cut = Math.floor(left - keepU * 42);
  if (cut <= vb.x + 1) { return 0; }        // nothing to gain on this panel
  var half = Math.round(cut / 2);
  // data-moved marks these as no longer where the live tree has them. The
  // out-of-view test below measures the live element, so without it a piece of
  // furniture the crop just pulled into frame gets dropped for sitting where it
  // used to be. That is what took the genotype label off branch A.
  clone.querySelectorAll('.allelelab').forEach(function (e) {
    e.setAttribute('x', parseFloat(e.getAttribute('x')) + cut);
    e.setAttribute('data-moved', '1');
  });

  // Centred furniture shifts by half the crop, which keeps its offset from the
  // middle. That is right until the line is wider than what is left of the box,
  // and branch A's note lines are: 475 wide in a 577 box, placed 110 left of
  // centre, so they ran off the left edge. Each one is clamped inside the new
  // box using its measured width, and centred if it cannot fit any other way.
  //
  // Only furniture. A notelab inside the camera names something on the DNA, and
  // moving branch A's partner label pushed it off the right edge.
  var box = src.getBoundingClientRect(), sc = vb.width / box.width;
  var pad = 8, right = vb.x + vb.width;
  var SEL = '.notelab, .condstrip, .condlab';
  var live = src.querySelectorAll(SEL), copy = clone.querySelectorAll(SEL);
  for (var i = 0; i < live.length; i++) {
    if (live[i].closest('#actor-camera')) { continue; }
    var r = live[i].getBoundingClientRect();
    if (!r.width) { continue; }
    var x = parseFloat(copy[i].getAttribute('x'));
    var lead = ((r.left - box.left) * sc + vb.x) - x;   // left edge, from x
    var w = r.width * sc, nx = x + half;
    if (w + 2 * pad > vb.width - cut) {
      nx = cut + (vb.width - cut) / 2 - lead - w / 2;   // too wide: centre it
    } else {
      if (nx + lead < cut + pad) { nx = cut + pad - lead; }
      if (nx + lead + w > right - pad) { nx = right - pad - lead - w; }
    }
    copy[i].setAttribute('x', Math.round(nx));
    copy[i].setAttribute('data-moved', '1');
  }
  clone.setAttribute('viewBox',
    cut + ' ' + vb.y + ' ' + (vb.width - cut) + ' ' + vb.height);
  return cut;
};

function keep(prop, v) {
  if (!v || v === 'normal' || v === 'auto') { return false; }
  if (v === 'none') { return window.__dropNone.indexOf(prop) === -1; }
  return true;
}
window.F = {
  panel: function (k) { return document.getElementById('p-' + k); },
  frames: function (k) {
    return window.__ANIM[k] ? window.__ANIM[k].frames.length : 0;
  },
  seek: function (k, n) {
    window.selectStep(k);
    if (window.__ANIM[k]) { window.runAnimation('seek', n); }
  },
  vis: function (k, sel) {
    var e = document.querySelector('#p-' + k + ' ' + sel);
    if (!e) { return false; }
    return window.getComputedStyle(e).opacity > 0.05;
  },
  off: function (k, id) {
    var f = window.__ANIM[k] && window.__figFrame;
    if (f === undefined || f === null) { return undefined; }
    return (window.__ANIM[k].frames[f].actors || {})[id];
  },
  // Leftmost user-space x of anything on the DNA that is not bare unique
  // sequence. Zones, the unique band and brackets are excluded because all
  // three span the whole region by design and would pin this at the far left.
  contentLeft: function (k) {
    var src = document.querySelector('#p-' + k + ' svg');
    var cam = document.querySelector('#p-' + k + ' #actor-camera');
    if (!src || !cam) { return null; }
    var box = src.getBoundingClientRect(), vb = src.viewBox.baseVal;
    var scale = vb.width / box.width, best = null;
    cam.querySelectorAll('*').forEach(function (e) {
      // Only things that draw. A group's box is the union of its children, so
      // measuring .dna would put the left edge back on the first unique block
      // and defeat the whole exclusion.
      if (DRAWN.indexOf(e.tagName.toLowerCase()) === -1) { return; }
      if (e.closest('.ustrand, .zones, .bracket')) { return; }
      if (e.classList.contains('uniqueband')) { return; }
      if (window.getComputedStyle(e).opacity < 0.05) { return; }
      var r = e.getBoundingClientRect();
      if (!r.width && !r.height) { return; }
      var x = (r.left - box.left) * scale + vb.x;
      if (best === null || x < best) { best = x; }
    });
    return best;
  },

  flatten: function (k, drop, props, keepU, trim) {
    var src = document.querySelector('#p-' + k + ' svg');
    if (!src) { return null; }
    var clone = src.cloneNode(true);
    // Crop first, while the clone still has its classes to be found by.
    var cut = keepU ? window.__crop(src, clone, k, keepU) : 0;
    // What the viewBox actually shows, after any crop.
    var vb = src.viewBox.baseVal, box = src.getBoundingClientRect();
    var sc = vb.width / box.width;
    var lim = {x0: vb.x + cut, x1: vb.x + vb.width,
               y0: vb.y, y1: vb.y + vb.height};
    // Where the drawing actually sits, for anything that needs to be centred on
    // it. Shapes only: the annotation text is scattered and would drag the
    // centre off the molecule it is annotating.
    var ink = {lo: 1e9, hi: -1e9};
    // And the whole drawn extent, text included, which is what a trim has to
    // clear. The two differ: annotation sits outside the molecule, and a trim
    // that cut to the shapes would take the labels with it.
    var full = {x0: 1e9, y0: 1e9, x1: -1e9, y1: -1e9};
    // Mark the descendants too. Removal takes the whole subtree either way, but
    // the ink measurement below tests each element on its own, and without this
    // the children of a dropped group still counted. That is what put the cap
    // indicator's rects into the drawing extent of a figure it had been cut from.
    (drop || []).forEach(function (sel) {
      clone.querySelectorAll(sel).forEach(function (e) {
        e.setAttribute('data-drop', '1');
        e.querySelectorAll('*').forEach(function (c) {
          c.setAttribute('data-drop', '1');
        });
      });
    });
    var a = src.querySelectorAll('*'), b = clone.querySelectorAll('*');
    for (var i = 0; i < a.length; i++) {
      var cs = window.getComputedStyle(a[i]), bits = [];
      for (var j = 0; j < props.length; j++) {
        var v = cs.getPropertyValue(props[j]);
        if (keep(props[j], v)) { bits.push(props[j] + ':' + v); }
      }
      // An element the engine has taken to zero, or one inside a group it has,
      // is not in this frame. Carrying it as invisible markup would leave the
      // file full of things the reader cannot see and an editor can.
      if (parseFloat(cs.opacity) < 0.02) { b[i].setAttribute('data-drop', '1'); }
      // And anything outside the viewBox goes too. Every panel carries fourteen
      // unique blocks so the chromosome never visibly ends, and most of them sit
      // at negative x, off the left of the box. A browser clips to the viewBox
      // and shows two. Inkscape, which is what converts an SVG for LaTeX, exports
      // the bounding box of the drawing instead, so it puts all fourteen back and
      // the figure that looked right locally comes out with the full tract.
      if (!a[i].closest('defs') && !b[i].hasAttribute('data-moved')) {
        var r = a[i].getBoundingClientRect();
        if (r.width || r.height) {
          var x0 = (r.left - box.left) * sc + vb.x, x1 = x0 + r.width * sc;
          var y0 = (r.top - box.top) * sc + vb.y, y1 = y0 + r.height * sc;
          if (x1 < lim.x0 || x0 > lim.x1 || y1 < lim.y0 || y0 > lim.y1) {
            b[i].setAttribute('data-drop', '1');
          }
        }
      }
      if (!b[i].hasAttribute('data-drop') && !a[i].closest('defs') &&
          a[i].tagName.toLowerCase() !== 'text' &&
          DRAWN.indexOf(a[i].tagName.toLowerCase()) !== -1) {
        var ir = a[i].getBoundingClientRect();
        if (ir.width || ir.height) {
          var i0 = Math.max((ir.left - box.left) * sc + vb.x, lim.x0);
          var i1 = Math.min(i0 + ir.width * sc, lim.x1);
          if (i1 > i0) {
            ink.lo = Math.min(ink.lo, i0);
            ink.hi = Math.max(ink.hi, i1);
          }
        }
      }
      if (!b[i].hasAttribute('data-drop') && !a[i].closest('defs') &&
          (DRAWN.indexOf(a[i].tagName.toLowerCase()) !== -1)) {
        var fr = a[i].getBoundingClientRect();
        if (fr.width || fr.height) {
          var fy0 = (fr.top - box.top) * sc + vb.y;
          var fx0 = (fr.left - box.left) * sc + vb.x;
          if (fx0 + fr.width * sc > lim.x0 && fx0 < lim.x1) {
            full.y0 = Math.min(full.y0, fy0);
            full.y1 = Math.max(full.y1, fy0 + fr.height * sc);
          }
        }
      }
      b[i].setAttribute('style', bits.join(';'));
      b[i].removeAttribute('class');
    }
    if (ink.hi > ink.lo) {
      clone.setAttribute('data-ink', Math.round(ink.lo) + ' ' + Math.round(ink.hi));
    }
    // Trim to what is drawn. Anything left outside the new box stays in the
    // markup and is cut by the clip the composer puts on every part, which is
    // the same guard that keeps the off-canvas unique blocks out of a PDF.
    if (trim && full.y1 > full.y0) {
      var pad = 12;
      var ty = Math.max(vb.y, Math.floor(full.y0 - pad));
      var th = Math.min(vb.y + vb.height, Math.ceil(full.y1 + pad)) - ty;
      var cvb = clone.getAttribute('viewBox').split(/\s+/);
      clone.setAttribute('viewBox', cvb[0] + ' ' + ty + ' ' + cvb[2] + ' ' + th);
    }
    clone.querySelectorAll('[data-drop]').forEach(function (e) { e.remove(); });
    clone.querySelectorAll('[data-moved]').forEach(function (e) {
      e.removeAttribute('data-moved');
    });
    clone.removeAttribute('class');
    return clone.outerHTML;
  },
  grab: function (k, ids, props) {
    var out = {};
    ids.forEach(function (id) {
      var src = document.querySelector('#p-' + k + ' #' + id);
      if (!src) { return; }
      var clone = src.cloneNode(true);
      var a = src.querySelectorAll('*'), b = clone.querySelectorAll('*');
      var all = [src].concat(Array.prototype.slice.call(a));
      var cl = [clone].concat(Array.prototype.slice.call(b));
      for (var i = 0; i < all.length; i++) {
        var cs = window.getComputedStyle(all[i]), bits = [];
        for (var j = 0; j < props.length; j++) {
          var v = cs.getPropertyValue(props[j]);
          if (v && v !== 'none' && v !== 'normal' && v !== 'auto') {
            bits.push(props[j] + ':' + v);
          }
        }
        cl[i].setAttribute('style', bits.join(';'));
        cl[i].removeAttribute('class');
        cl[i].removeAttribute('id');
      }
      out[id] = clone.outerHTML;
    });
    return out;
  }
};
"""


# ===========================================================================
# MAIN CONTROLLER
# ===========================================================================

def build_figures(root=None, out_dir=None, only=None):
    """Export every figure in FIGURES to out_dir as flattened SVG.

    Coordinates the four base controllers below: resolve a part to a concrete
    frame, capture it, compose the parts into one figure, write it out.
    """
    root = root or _project_root()
    out_dir = out_dir or os.path.join(root, OUT_DIRNAME)
    viewer = os.path.join(root, VIEWER)

    # === CHECK INPUTS ===
    if not os.path.isfile(viewer):
        sys.exit("no %s. Run python3 build.py first." % VIEWER)
    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        sys.exit("playwright not installed:\n"
                 "  pip install playwright && playwright install chromium")

    if not os.path.isdir(out_dir):
        os.makedirs(out_dir)

    todo = [f for f in FIGURES if only is None or f["id"] in only]
    report, written = [], []

    # === COORDINATE BASE CONTROLLERS ===
    with sync_playwright() as pw:
        browser = pw.chromium.launch()
        # The stylesheet already answers prefers-reduced-motion by switching off
        # the capglow pulse, the nick flash and every transition. Asking for it
        # here means no waiting for a transition to settle and no catching the
        # flashing nick mid-cycle, using code that is already in the sheet.
        page = browser.new_context(reduced_motion="reduce").new_page()
        page.goto("file://" + os.path.abspath(viewer))
        page.wait_for_function("() => typeof selectStep === 'function' "
                       "&& typeof ANIM !== 'undefined'")
        install_api(page)
        scratch = None

        for fig in todo:
            parts = []
            for n, part in enumerate(fig["parts"]):
                if part.get("file"):
                    if scratch is None:
                        scratch = browser.new_context(
                            reduced_motion="reduce").new_page()
                        install_api(scratch)
                    load_reference(scratch, part["panel"], root)
                    captured = capture_part(scratch, part, n)
                else:
                    captured = capture_part(page, part, n)
                parts.append(captured)
                report.append("%-16s part %d  %-9s frame %s   %s"
                              % (fig["id"], n, part["panel"],
                                 captured["frame"], captured["why"]))
            svg = compose_figure(fig, parts)
            written.append(export_figure(out_dir, fig["id"], svg))
        browser.close()

    # === REPORT ===
    write_manifest(out_dir, report, written)
    for line in report:
        print(line)
    print("\nwrote %d figures to %s" % (len(written), out_dir))
    if PENDING_BUILDS:
        print("not built yet: %s"
              % ", ".join(f["id"] for f in PENDING_BUILDS))
    return written


# ===========================================================================
# BASE CONTROLLERS
# ===========================================================================

def install_api(page):
    """Put the capture helpers on a page. Both kinds of page get the same set."""
    page.evaluate("d => { window.__dropNone = d; }", DROPPABLE_NONE)
    page.evaluate(PAGE_API)


def load_reference(page, key, root):
    """Put a reference panel into a bare page, wrapped so capture sees a panel.

    Reference panels are diagrams, not moments: no cap indicator, no Ku, no
    frames. They are deliberately out of KEYS and META, so the built viewer does
    not contain them and there is nothing to select. Reading the generated SVG
    and giving it the id the rest of this file expects means the flattening, the
    trim and the ink measurement all work on it unchanged.
    """
    svg = os.path.join(root, "src", "panels", key + ".svg")
    if not os.path.isfile(svg):
        sys.exit("no %s. Is %s in PANEL_FNS?" % (svg, key))
    with open(svg, encoding="utf-8") as fh:
        body = fh.read()
    with open(os.path.join(root, "src", "style.css"), encoding="utf-8") as fh:
        css = fh.read()
    page.set_content('<style>%s</style><div id="p-%s">%s</div>'
                     % (css, key, body))
    install_api(page)


def resolve_frame(page, part):
    """Turn a part's frame spec into a concrete index, or fail loudly.

    Never returns an index the spec did not actually describe. A predicate that
    matches nothing is a spec that has fallen out of step with the model, and
    that has to stop the run rather than quietly export frame 0.
    """
    key = part["panel"]
    total = page.evaluate("k => F.frames(k)", key)
    spec = part.get("frame", "static")

    if spec == "static" or total == 0:
        if spec not in ("static", "last") and total == 0:
            sys.exit("%s is static but the spec asks for a frame in it" % key)
        return 0, "static panel" if total == 0 else "frame 0"
    if spec == "last":
        return total - 1, "last of %d" % total

    hits = find_matching_frames(page, key, total, spec["when"])
    if not hits:
        sys.exit("%s: no frame matches\n    %s\n"
                 "  The panel changed or the predicate did. Fix one of them."
                 % (key, spec["when"]))
    return pick_from(hits, spec.get("pick", "first")), \
        "%s of %d matching %s" % (spec.get("pick", "first"), len(hits), hits)


def find_matching_frames(page, key, total, when):
    """MODEL: every frame index whose state satisfies the predicate (TERMINAL).

    __figFrame is set before each test so F.off can read the frame table for
    the frame currently on screen. Offsets live in the table and not the DOM,
    since a transform of zero and no transform look the same.
    """
    return page.evaluate(
        """([k, total, when]) => {
             const F = window.F, hits = [];
             for (let i = 0; i < total; i++) {
               F.seek(k, i);
               window.__figFrame = i;
               if (eval(when)) { hits.push(i); }
             }
             return hits;
           }""", [key, total, when])


def pick_from(hits, how):
    """MODEL: choose one index from the matching set (TERMINAL)."""
    if how == "first":
        return hits[0]
    if how == "last":
        return hits[-1]
    return hits[len(hits) // 2]


def capture_part(page, part, index):
    """Seek one part's frame and return its SVG with the cascade flattened.

    Ids are namespaced per part here, before anything is composed. Panels carry
    marker ids like step01-arrow, and a figure that shows the same panel twice
    (the end-replication pair does) would otherwise emit the same id twice and
    let the second definition win for both.
    """
    key = part["panel"]
    frame, why = resolve_frame(page, part)

    # === CAPTURE ===
    page.evaluate("([k, n]) => { F.seek(k, n); window.__figFrame = n; }",
                  [key, frame])
    svg = page.evaluate(
        "([k, drop, props, keepU, trim]) => "
        "F.flatten(k, drop, props, keepU, trim)",
        [key, DROP_ALWAYS + part.get("drop", []), STYLE_PROPS,
         part.get("keep_u", KEEP_U), bool(part.get("trim"))])
    if not svg:
        sys.exit("%s: no panel in the page. Is it in KEYS?" % key)

    # === ADD MOTION, IF THIS PART IMPLIES IT ===
    if part.get("trail"):
        svg = add_trail(page, part, frame, svg)

    prefix = "f%d" % index
    ink = read_ink(svg)
    svg = re.sub(r'\s*data-ink="[^"]*"', "", svg, count=1)
    return {"svg": namespace_ids(svg, prefix), "frame": frame, "why": why,
            "label": part.get("label"), "title": part.get("title"),
            "trim": bool(part.get("trim")), "ink": ink, "panel": key}


def add_trail(page, part, frame, svg):
    """Draw a moving actor at its earlier positions, behind where it ends up.

    Print cannot animate, and arrows are already carrying genetic interactions
    in this figure, so another arrow would be read as one. Reduced opacity is
    already the vocabulary for transient, which is what an earlier position is.

    Each ghost goes immediately before the live element, so it paints behind it
    and behind nothing else. Ids are stripped from the ghosts by F.grab, since
    they are copies of an element that is still in the file.
    """
    trail = part["trail"]
    key, ids = part["panel"], trail["ids"]
    opac = trail.get("opacity", [])

    for n, back in enumerate(trail["back"]):
        at = frame - back
        if at < 0:
            continue
        page.evaluate("([k, i]) => { F.seek(k, i); window.__figFrame = i; }",
                      [key, at])
        grabbed = page.evaluate("([k, ids, props]) => F.grab(k, ids, props)",
                                [key, ids, STYLE_PROPS])
        alpha = opac[n] if n < len(opac) else 0.3
        for ident, html in grabbed.items():
            ghost = '<g opacity="%s">%s</g>' % (alpha, html)
            svg = insert_before_element(svg, ident, ghost)

    # Put the live frame back so the caller's state is what it asked for.
    page.evaluate("([k, n]) => { F.seek(k, n); window.__figFrame = n; }",
                  [key, frame])
    return svg


def compose_figure(fig, parts):
    """Lay the captured parts out as one SVG and letter them.

    Parts keep their own viewBox and are placed by translation, so nothing is
    scaled and the glyph sizes stay identical across every figure in the
    chapter. That is the whole reason for laying out here instead of in LaTeX.
    """
    # One baseline for both, so the part letter and the part title read as one
    # line across the top of the drawing. The title sits inside the part box
    # rather than in a band above it, which is why nothing is reserved here.
    # 75 puts it down near the molecule instead of up at the box edge, where the
    # panel's own empty top band left it floating.
    # A divider needs room on both sides or it reads as an underline on the
    # panel above it, so a figure that draws them gets a wider gap.
    gap = 26 if fig.get("dividers") else 9
    lab_w, head_y, head_h = 34, 75, 26
    boxes = [read_viewbox(p["svg"]) for p in parts]
    cols = 2 if fig.get("layout") == "grid" and len(parts) > 2 else 1

    # An untrimmed part has an empty band at the top of its panel and the
    # heading goes in it, at head_y. A trimmed part has no such band, because
    # trimming is what removed it, so the heading gets a reserved strip above
    # the part instead.
    heads = [head_h if (p["trim"] and (p.get("title") or p.get("label"))) else 0
             for p in parts]

    # === PLACE ===
    spots, rules, x, y, row_h = [], [], 0, 0, 0
    for n, (w, h) in enumerate(boxes):
        if n and n % cols == 0:
            rules.append(y + row_h + gap / 2)
            x, y, row_h = 0, y + row_h + gap, 0
        spots.append((x + lab_w, y + heads[n]))
        x += w + gap + lab_w
        row_h = max(row_h, h + heads[n])
    total_w = max(sx + w for (sx, _), (w, _) in zip(spots, boxes))
    total_h = max(sy + h for (_, sy), (_, h) in zip(spots, boxes))

    # === CENTRE THE TITLES ===
    # On the drawing, not on the panel box. A panel is 880 wide and its molecule
    # occupies about the left 720, so a title centred on the box reads as pushed
    # right. One centre is shared by every title in the figure: the parts' own
    # ink centres differ by enough to look misaligned when stacked, and two
    # headings that nearly line up read as a mistake.
    centres = [px - read_origin(p["svg"])[0] + sum(p["ink"]) / 2
               for p, (px, _) in zip(parts, spots) if p.get("title") and p["ink"]]
    title_x = sum(centres) / len(centres) if centres else None

    # === ASSEMBLE ===
    body = ["<defs/>"]
    if fig.get("dividers"):
        body += [render_divider(ry, total_w) for ry in rules]
    for n, (part, (px, py), (w, h)) in enumerate(zip(parts, spots, boxes)):
        hy = py - 9 if heads[n] else py + head_y
        if part.get("label"):
            body.append(render_part_label(part["label"], px - lab_w + 4, hy))
        if part.get("title"):
            body.append(render_part_title(part["title"], title_x, hy))
        ox, oy = read_origin(part["svg"])
        # Dropping what lies outside the box handles whole elements. A block
        # straddling the edge is still half out, and Inkscape would export the
        # half. The clip makes the edge hard whatever the converter does.
        clip = "clip-%s-%d" % (fig["id"], n)
        body.append('<clipPath id="%s"><rect x="%d" y="%d" width="%d" '
                    'height="%d"/></clipPath>' % (clip, ox, oy, w, h))
        body.append('<g clip-path="url(#%s)" transform="translate(%d,%d)">%s</g>'
                    % (clip, px - ox, py - oy, strip_svg_wrapper(part["svg"])))
    return ('<svg xmlns="http://www.w3.org/2000/svg" '
            'xmlns:xlink="http://www.w3.org/1999/xlink" '
            'viewBox="0 0 %d %d" width="%d" height="%d">\n%s\n</svg>'
            % (total_w, total_h, total_w, total_h, "\n".join(body)))


def export_figure(out_dir, fig_id, svg):
    """VIEW: write the figure, and a PDF beside it when a converter exists."""
    path = os.path.join(out_dir, fig_id + ".svg")
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(svg)
    try:
        import cairosvg
        cairosvg.svg2pdf(bytestring=svg.encode("utf-8"),
                         write_to=os.path.join(out_dir, fig_id + ".pdf"))
    except Exception:
        # The SVG is the deliverable and carries no stylesheet, so any
        # converter handles it. A missing cairosvg is not a failed export.
        pass
    return path


# ===========================================================================
# SHARED FUNCTIONS
# ===========================================================================

def namespace_ids(svg, prefix):
    """MODEL: make every id in one part unique to that part (TERMINAL)."""
    ids = set(re.findall(r'id="([^"]+)"', svg))
    for ident in sorted(ids, key=len, reverse=True):
        new = "%s-%s" % (prefix, ident)
        svg = svg.replace('id="%s"' % ident, 'id="%s"' % new)
        svg = svg.replace("url(#%s)" % ident, "url(#%s)" % new)
        svg = svg.replace('href="#%s"' % ident, 'href="#%s"' % new)
    return svg


def insert_before_element(svg, ident, markup):
    """MODEL: splice markup in just ahead of the element with this id (TERMINAL)."""
    at = svg.find('id="%s"' % ident)
    if at < 0:
        return svg
    start = svg.rfind("<", 0, at)
    return svg[:start] + markup + svg[start:]


def read_viewbox(svg):
    """MODEL: the part's drawn size, from its own viewBox (TERMINAL)."""
    m = re.search(r'viewBox="([\d.\-]+) ([\d.\-]+) ([\d.]+) ([\d.]+)"', svg)
    return (int(float(m.group(3))), int(float(m.group(4)))) if m else (880, 300)


def read_ink(svg):
    """MODEL: the drawn extent the browser measured, as (x0, x1) (TERMINAL)."""
    m = re.search(r'data-ink="([\d.\-]+) ([\d.\-]+)"', svg)
    return (float(m.group(1)), float(m.group(2))) if m else None


def read_origin(svg):
    """MODEL: the part's viewBox origin, which cropping moves off zero (TERMINAL)."""
    m = re.search(r'viewBox="([\d.\-]+) ([\d.\-]+)', svg)
    return (float(m.group(1)), float(m.group(2))) if m else (0.0, 0.0)


def strip_svg_wrapper(svg):
    """MODEL: the contents of a part, without its own svg element (TERMINAL)."""
    return re.sub(r"</svg>\s*$", "", re.sub(r"^\s*<svg[^>]*>", "", svg))


def render_part_label(text, x, y):
    """VIEW: the (a), (b) letter beside a part (TERMINAL)."""
    return ('<text x="%d" y="%d" style="font-family:\'Times New Roman\',Times,'
            'serif;font-size:15px;font-weight:700;fill:#111">%s</text>'
            % (x, y, text))


def render_divider(y, width):
    """VIEW: a dotted rule between two rows of parts (TERMINAL).

    Light enough to separate without competing: the panels are already dense,
    and a solid rule at any weight that showed up would read as part of the
    drawing. Round caps on a short dash give dots rather than dashes.
    """
    return ('<line x1="0" y1="%d" x2="%d" y2="%d" style="stroke:#bfbfbf;'
            "stroke-width:1;stroke-dasharray:2 5;stroke-linecap:round\"/>"
            % (y, width, y))


def render_part_title(text, x, y):
    """VIEW: a part's title, centred over its drawing (TERMINAL).

    Shares its baseline with the part letter. It sits inside the part box, in
    the band above the DNA, so a part that still carries its cap indicator has
    no room for one; only the stripped panels use titles at present.
    """
    return ('<text x="%d" y="%d" style="font-family:\'Times New Roman\',Times,'
            'serif;font-size:16px;font-weight:600;fill:#111;text-anchor:middle">'
            "%s</text>" % (x, y, text))


def write_manifest(out_dir, report, written):
    """VIEW: record what each part resolved to, beside the figures (TERMINAL)."""
    lines = ["Frames chosen by tools/make_figures.py.",
             "Predicates, not indices: check these against the spec whenever a",
             "frame table changes.", ""]
    lines += report
    lines += ["", "files:"] + ["  " + os.path.basename(p) for p in written]
    with open(os.path.join(out_dir, "manifest.txt"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines) + "\n")


def _project_root():
    """MODEL: the folder holding build.py, from this file's location (TERMINAL)."""
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


if __name__ == "__main__":
    build_figures(only=set(sys.argv[1:]) or None)
