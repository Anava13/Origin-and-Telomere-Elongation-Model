#!/usr/bin/env python3
"""Regenerate src/index.html.

The shell embeds nav.svg, which tools/make_panels.py writes. Rather than keep
two copies of the flowchart in sync by hand, this pulls the current nav.svg in
each time. Run it after make_panels.py.

SCRIPTS below must stay identical, in content and order, to SCRIPTS in
build.py. build.py joins that list into script tags and replaces the whole
block in one string operation, so a mismatch does not raise: it silently
leaves the src/ tags in the dist/ file, and the distributable then points at
five files that are not beside it. The two lists are asserted equal at build
time for that reason.

The caption region is a row wrapper holding two columns: the caption and its
hint on the left, the drawing note on the right. Whether that row is one column
or two is a CSS decision and lives in style.css; the markup is the same either
way. The reference list and the key legend stay below the row at full width.
"""
import os

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
SRC = os.path.join(ROOT, "src")

# Order here only decides the order of the placeholder divs, but keeping the
# two resection tracks adjacent makes the generated file readable. This is also
# the reading order citation numbering walks; PANEL_ORDER in src/data.js is the
# same list, and tools/test_engine.js fails if the two disagree.
KEYS = ["step01", "lag01", "step02", "step03", "lag03", "step04", "step05",
        "step06", "step07", "step08", "step09",
        "offA", "offB", "offC", "offD", "offE"]

# cite.js sits before controller.js because controller.js calls initWorkflow()
# at the bottom of its own body, so everything it reaches for must already be
# defined by the time that line runs.
SCRIPTS = ["data.js", "anim-data.js", "animate.js", "controls.js",
           "cite.js", "controller.js"]

nav = open(os.path.join(SRC, "nav.svg"), encoding="utf-8").read().strip()
panel_divs = "\n".join(
    '      <div class="panel" id="p-%s" data-src="panels/%s.svg"></div>' % (k, k)
    for k in KEYS)
script_tags = "\n".join('<script src="%s"></script>' % s for s in SCRIPTS)

html = '''<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Telomere end-processing workflow</title>
<link rel="stylesheet" href="style.css">
</head>
<body>

<header>
  <h1>Telomere end processing in <i>S.&nbsp;cerevisiae</i></h1>
  <p>Click a step to render it. One fork passage makes two daughter ends, so
     the top of the chart is a split rather than a decision and both tracks are
     live; they converge at step 4. One decision point below that, where the
     long-telomere branch skips elongation and rejoins at fill-in.</p>
</header>

<div class="wrap">

  <div class="nav">
%s
  </div>

  <div class="display">
    <span class="chip" id="chip"></span>
    <h2><span class="num" id="num"></span><span id="title"></span></h2>

    <div class="stage">
%s
    </div>

    <div id="transport"></div>

    <!-- The cap indicator sits inside every panel and its five states are the
         same in all of them, so the explanation is a dialog opened from here
         instead of a legend printed beside the drawing. -->
    <button type="button" class="capkeybtn" id="capkeybtn"
            aria-haspopup="dialog">What the cap indicator means</button>

    <!-- Caption left, drawing note right. The note column is a permanent flex
         item: panels with no note leave it empty rather than collapsing it, so
         the caption keeps the same measure as you step through panels that do
         and do not carry one. controller.js addresses cap, hint, notewrap,
         note and notetoggle by id only, so this nesting is invisible to it. -->
    <div class="caprow">
      <div class="capcol">
        <div class="cap" id="cap"></div>
        <p class="hint" id="hint"></p>
      </div>
      <div class="notecol">
        <div class="notewrap" id="notewrap">
          <button type="button" class="notetoggle" id="notetoggle"
                  aria-expanded="false" aria-controls="note">More Context</button>
          <div class="note" id="note"></div>
        </div>
      </div>
    </div>

    <ol class="refs" id="refs"></ol>

    <div class="keys">Arrow keys move through the leading-strand route and the
      shared tail below the merge. The lagging-strand track, 1* and 3*, is
      reached by clicking. Space plays or pauses an animation. D1 is a decision
      point, not a panel, and the bar at the top is a split rather than a
      decision: both arms always happen.</div>
  </div>

</div>

  <div class="capkey" id="capkey" role="dialog" aria-modal="true"
       aria-labelledby="capkeytitle">
    <div class="capkeybox">
      <h3 id="capkeytitle">The cap indicator</h3>
      <p>Three slots, in the same corner of every panel: Rap1 on the duplex
         array, CST on the 3&#8242; overhang, Ku at the junction between them.
         The cap is those three bound at once, so each slot reports one of
         them.</p>
      <p>A slot reports the highest level of capping the evidence establishes at
         that step. It is not a count of molecules. Every protein here sits in
         an equilibrium and biology is leaky, so a slot reading
         <b>none established</b> says the drawing has no warrant for putting the
         element there, not that no copy of it is bound. Only <b>no substrate</b>
         and the loss states are claims that nothing is bound, and they are
         structural: with no site there is nothing to bind, and in a loss branch
         the element is gone by construction.</p>
      <table>
        <tr><th>State</th><th>Rap1 (duplex array)</th>
            <th>CST (overhang)</th><th>Ku (junction)</th></tr>
        <tr><td class="st on">complete</td><td>full array</td>
            <td>assembled</td><td>bound</td></tr>
        <tr><td class="st thin">partial</td><td>short array</td>
            <td>Cdc13 only</td><td>&#8212;</td></tr>
        <tr><td class="st off">unoccupied</td><td>none bound</td>
            <td>none established</td><td>none established</td></tr>
        <tr><td class="st na">no site</td><td>no duplex</td>
            <td>no overhang</td><td>no junction</td></tr>
        <tr><td class="st lost">lost</td><td>array lost</td>
            <td>CST lost</td><td>Ku lost</td></tr>
      </table>
      <p>Only CST has a middle rung in the usual sense, because it is the only
         element that assembles from separately regulated subunits. Rap1's
         middle rung is a different axis: array length. NHEJ inhibition and
         resection suppression are proportional to how long the Rap1-bound array
         next to the end is, so a short array is marginal protection and a full
         one is not, and the cut between them is a drawing convention placed
         between the two lengths the figure has to tell apart. Ku is an obligate
         heterodimer and has no middle rung.</p>
      <p>The states are read off the drawing every frame, so a panel whose
         telomere changes under it reports the change. Loss is the exception and
         is declared, because a missing glyph is not evidence of loss.</p>
      <button type="button" class="capkeyclose" id="capkeyclose">Close</button>
    </div>
  </div>

%s
</body>
</html>
''' % (nav, panel_divs, script_tags)

open(os.path.join(SRC, "index.html"), "w", encoding="utf-8").write(html)
print("wrote src/index.html")