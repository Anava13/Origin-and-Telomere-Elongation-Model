#!/usr/bin/env python3
"""Rasterise panels for visual inspection by resolving CSS classes to inline
style attributes, because cairosvg's stylesheet support is unreliable."""
import cairosvg, re, os, sys

HERE = os.path.dirname(os.path.abspath(__file__))
SRCDIR = os.path.join(os.path.dirname(HERE), 'src')
OUTDIR = os.path.join(os.path.dirname(HERE), 'render')
os.makedirs(OUTDIR, exist_ok=True)

css = open(os.path.join(SRCDIR, 'style.css')).read()
css = re.sub(r'/\*.*?\*/', '', css, flags=re.S)

rules = {}
for m in re.finditer(r'([^{}]+)\{([^{}]+)\}', css):
    body = m.group(2).strip()
    for sel in m.group(1).split(','):
        sel = sel.strip()
        if re.fullmatch(r'(?:\.[\w-]+)+', sel):
            # compound selectors like .half.pending need every class present
            rules.setdefault(tuple(sorted(sel.split('.')[1:])), []).append(body)

# resolve var() against :root
root = {}
for m in re.finditer(r'(--[\w-]+)\s*:\s*([^;}]+)', css):
    root[m.group(1)] = m.group(2).strip()
def deref(t):
    return re.sub(r'var\((--[\w-]+)\)', lambda m: root.get(m.group(1), '#000'), t)

def style_for(classes):
    have = set(classes)
    out = []
    for key, bodies in rules.items():
        if set(key) <= have:
            out.extend(deref(b) for b in bodies)
    return ';'.join(out)

def inline(svg):
    def rep(m):
        tag, attrs = m.group(1), m.group(2)
        cm = re.search(r'class="([^"]+)"', attrs)
        if not cm: return m.group(0)
        st = style_for(cm.group(1).split())
        if not st: return m.group(0)
        return '<%s%s style="%s"' % (tag, attrs, st)
    return re.sub(r'<(\w+)((?:\s+[\w:-]+="[^"]*")*)', rep, svg)

keys = sys.argv[1:] or sorted(
    f[:-4] for f in os.listdir(os.path.join(SRCDIR, "panels")))
for k in keys:
    raw = open(os.path.join(SRCDIR, 'panels', k + '.svg')).read()
    head, body = raw.split('>', 1)          # leave the root <svg> alone:
    svg = head + '>' + inline(body)         # .panelsvg sets height:auto
    cairosvg.svg2png(bytestring=svg.encode(),
                     write_to=os.path.join(OUTDIR, k + '.png'),
                     output_width=1200, background_color='white')
print("rendered %d panel(s) to render/" % len(keys))
