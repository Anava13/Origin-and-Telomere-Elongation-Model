#!/usr/bin/env python3
"""Generate every panel SVG and the nav flowchart from one glyph vocabulary.

Run from the project root:

    python3 tools/make_panels.py

Writes src/panels/*.svg and src/nav.svg. Nothing in those files is edited by
hand: change a glyph function here and regenerate, so a change to Rad50 or the
Rap1 box lands in all ten panels at once.

Geometry
--------
DNA runs left to right. Left is centromere-proximal, right is the terminus.
The array is a row of repeat units ("chunks"), each drawn as two halves: a top
half (G-strand, TG1-3) and a bottom half (C-strand, C1-3A). Every half carries
its own id, cNN-t or cNN-b, so the animation engine can address it.
"""
import math
import os

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
PANELS = os.path.join(ROOT, "src", "panels")
os.makedirs(PANELS, exist_ok=True)

# ---------------------------------------------------------------- geometry --
VB_W, VB_H = 880, 300
CW = 42                     # chunk width
X0 = 50                     # first chunk left edge
TOP_Y, BOT_Y, SH = 139, 161, 13   # strand y positions and height
MID = 155                   # duplex centre line
N_DUPLEX = 10               # chunks 1..10 stay duplex throughout
N_START = 14                # chunks present before elongation
N_MAX = 18                  # chunks after elongation
N_UNIQUE = 14               # non-telomeric chunks to the left of the array, at
                            # indices 0 down to -13. This is the rest of the
                            # chromosome, so the panel must never show it ending.
                            # offA pans the camera to 420, which is the furthest
                            # any panel goes, and cx(-13) is -538, still 118 off
                            # the left edge at full pan. That is the same
                            # clearance branch C has at its own 294. Raise the
                            # pan and this has to rise with it.
                            # cx(0) is 8, so one chunk pokes into the 50px
                            # gutter at rest. That sliver is deliberate: it gives
                            # the pan something to pull from rather than having
                            # unique sequence appear out of nowhere.
C_UNIQUE_REACHED = 4        # how far into it branch C's front actually runs.
                            # Resection crossing the boundary is the claim;
                            # consuming the chromosome is not, so the front stops
                            # here and the chunks beyond it stay duplex.

CDC13_R = 52                # one Cdc13 radius everywhere, so the glyph that
                            # ends elongation is the same object that starts
                            # fill-in
RPA_R = 22                  # Rfa1 OB fold. Sized to fit one repeat unit, so RPA
                            # can be deposited chunk by chunk during resection
                            # rather than parked beside the DNA.
RPA_CHUNKS = (13, 12, 11)   # which repeats resection deposits RPA on in panel
                            # 3, distal first. Chunk 13 used to be left out on
                            # the grounds that Rad50 and Mre11 sit over it. That
                            # is true of frames 0 to 2 and false from frame 3,
                            # where MRX has faded and c13-b has gone on the same
                            # beat, so the unit lands on bare strand with nothing
                            # over it. Panel 3* has always deposited three for
                            # the same stretch of ssDNA, and two panels covering
                            # the same substrate differently is a claim neither
                            # caption makes. Chunk 14 stays bare in both: it is
                            # cleared by Mre11 travelling the other way and the
                            # captions say so.
RPA_OVERHANG = (13, 14)     # the overhang repeats RPA holds once Cdc13 is on.
                            # RPA is not a resection leftover that Cdc13 evicts:
                            # it stays on the overhang and is required for Est1
                            # to reach the end, so the two occupy the tail
                            # together. Chunks 11 and 12 are under the Cdc13
                            # wedge in these panels, so only 13 and 14 are drawn.

LAG_RPA_CHUNKS = (13, 12, 11)   # the repeats panel 3* deposits RPA on, distal
                            # first. Same three as panel 3, which is the point:
                            # both branches expose 11 to 14 and both hand the
                            # same occupied strand to panel 4. The two panels
                            # still differ on 14, which panel 3 clears with the
                            # Mre11 arm and this one had single-stranded before
                            # it opened.

MRX_X = 596                 # incision-site MRX, for the panels whose C-strand
                            # still runs to the terminus (1, 2, 3). Equals
                            # cx(N_START), so it sits on the last duplex repeat.
MRX_JUNCTION = 395          # MRX from panel 4 onward. Not a destination MRX
                            # travels to: the complex has no translocase and
                            # does not track a receding front. Once the C-strand
                            # stops at chunk 10 the junction is the only place
                            # in the drawing with MRX's substrate, so that is
                            # where a rebound complex sits. MRX_X is by then the
                            # middle of the overhang. Drawn mirrored here, so
                            # Xrs2 and the flagpole hang left over the duplex
                            # instead of into Cdc13.
MRX_JUNCTION_LONG = MRX_JUNCTION + 4 * CW   # the junction on the branch B
                            # telomere. Branch B is the long-telomere
                            # counterfactual to panel 5, so the two panels have
                            # to differ in array length and in nothing else: the
                            # overhang is the same four repeats, and every glyph
                            # anchored to the junction moves by the four repeats
                            # the array is longer. Deriving it from
                            # MRX_JUNCTION keeps that difference at one number.
LONG_OFFSET = 4 * CW        # the same shift, for Cdc13 and anything else on
                            # branch B that panel 5 places by hand.
NICK_CHUNK = 14             # the Mre11 incision falls on the left edge of this
                            # chunk, which is cx(NICK_CHUNK). That puts chunk 14
                            # distal to the cut (Mre11 clears it, 3' to 5') and
                            # 13 inward (Exo1 and Sgs1-Dna2, 5' to 3').
KU_INSET = 20               # Ku threads onto duplex ends and its footprint sits
                            # inboard of the terminus, so it is drawn flush
                            # against the junction on the duplex side. Its real
                            # position is derived at run time from which chunks
                            # are duplex; this is only where it starts.
N_REST = N_MAX - 1          # duplex chunks at rest. Fill-in runs the whole
                            # overhang, then primer removal returns the last
                            # chunk to single-stranded, so the resting telomere
                            # carries a one-chunk 3' tail rather than a blunt
                            # end.

# Cdc13 hands off from panel 6 to panel 8 without moving. Panel 6 starts it at
# CDC13_REST and the elongation frames carry it CDC13_TRAVEL to the right;
# panel 8 starts CST at CST_REST and its first frame offsets it by the same
# amount, so both land on the same corner.
CDC13_REST = 486
CDC13_TRAVEL = 168
CST_REST = 470
CST_START_OFFSET = CDC13_REST + CDC13_TRAVEL - CST_REST

# Panel 7 sits between the two, showing the fully extended G-strand with
# telomerase being displaced, so its Cdc13 must be drawn where elongation left
# it rather than where elongation started it.
CDC13_EXTENDED = CDC13_REST + CDC13_TRAVEL

# Cdc13 binds the single-stranded G-strand, so its wedge corner sits flush
# with the underside of the G block rather than on the duplex centre line or
# on top of the block. Flush means the flat top edge of the wedge is the same
# line as the bottom edge of the repeat it is bound to, which reads as bound
# rather than as overlapping. CST uses the same line through its own default y,
# so the wedge is at one altitude everywhere in the model.
CDC13_TOP = TOP_Y + SH
CDC13_Y = CDC13_TOP + 30


# The two fusion branches, which are the only panels whose DNA outgrows the
# viewBox in either direction.
#
# offA erodes the whole array, so its end retreats from end_x(18) to end_x(0)
# and the camera follows it right. It holds at 0 until the end reaches 470 and
# then steps 84 per pair of repeats, which keeps the end at 470 for the rest of
# the panel and lands the camera at A_PAN. Branch C's idiom, in the other
# direction and for the same reason: the enzyme and the end both have to stay
# where they can be read.
A_PAN = 420
A_END = 470                 # where the eroding end parks once the camera moves
A_PARTNER_GAP = 60          # the gap the ligation closes

# offD does neither. Its 3' terminus does not move at all: the C-strand recedes
# and the single-strand region grows inward, so the molecule's rightmost extent
# is fixed for the whole panel and the camera has nothing to follow until the
# partner arrives. An earlier version extended the G-strand outward, which reads
# as telomerase acting and fill-in failing to follow. This panel's phase is
# resting, which is outside the window telomerase acts in, so that drawing
# depicted an event the panel's own cycle position forbids.
D_RECEDE = 3                # repeats of C-strand lost, distal first
D_PAN = -252                # full pan at the fusion frames
D_PARTNER_REPEATS = 7

# offA's partner is unique sequence, offD's is a telomere. Both run off the
# right edge, and both sit inside the camera, because a partner anchored to
# panel coordinates would drift away from the end it fuses with the moment the
# camera moved. The old branch D drew its partner outside the camera and got
# away with it only because that panel never panned.


def cx(i):
    """Left edge of chunk i (1-based)."""
    return X0 + (i - 1) * CW


def end_x(n):
    """Right edge of chunk n."""
    return cx(n) + CW


def chunk_id(i):
    """Element id stem for chunk i.

    Positive indices are telomeric repeats, numbered from the proximal end of
    the drawn array. Indices of zero or below are unique sequence to the left
    of it, named u01 outward, so the id stays a legal CSS identifier where
    "c00" and "c-01" would read as part of the same series and invite arithmetic
    that is wrong.

    animate.js has the same mapping. If one changes the other must.
    """
    return "c%02d" % i if i >= 1 else "u%02d" % (1 - i)


# ------------------------------------------------------------------ glyphs --
def chunks(n_top=N_START, n_bot=N_START, n_slots=N_MAX, n_unique=N_UNIQUE):
    """The repeat array, and the unique sequence it sits on.

    n_top / n_bot: how many chunks are present on each strand at rest.
    n_slots: how many chunk slots exist at all. Slots past n_top or n_bot are
    emitted with class "pending" so elongation and fill-in have something to
    turn on rather than having to create nodes.

    n_unique: how many non-telomeric chunks to draw to the left of chunk 1, at
    indices 0 and below. Every panel gets them, because every panel is a picture
    of a telomere on a chromosome and the array does not begin at the edge of
    the page. Only branch C ever pans far enough to look at them. Unique
    sequence is duplex like everything else, so each one gets both halves; only
    the C-strand is ever degraded, which is the claim branch C makes when its
    front crosses the boundary. Both halves carry U rather than G and C, since
    the sequence is not TG1-3 and lettering it as though it were would say the
    repeats run further than they do.

    Each half is a group, not a bare rect, because it carries a strand letter.
    The animation engine sets classes on the element that holds the id, and
    fill and opacity both inherit, so wrapping the rect and the letter together
    means the letter grays and vanishes with the block it belongs to.

    data-unique on the .dna group is how animate.js learns the lower bound of
    the array. Without it the derivation loop starts at chunk 1, and Ku would
    stop at the boundary while the resection front kept going.
    """
    lo = 1 - n_unique

    out = []
    # The region band and its bracket sit behind everything and travel with the
    # chunks they describe. The band is taller than the zone tints so its margin
    # still reads once a zone is filled: sequence identity does not change, and
    # strand state does, so they are two marks rather than one.
    if n_unique:
        out.append('<rect class="uniqueband" x="%d" y="%d" width="%d" height="%d"/>'
                   % (cx(lo) - 6, TOP_Y - 22, (end_x(0) - cx(lo)) + 12,
                      (BOT_Y + SH + 22) - (TOP_Y - 22)))
        out.append(unique_bracket(n_unique))

    # Zone tints go in next so they sit behind the strands. Their state is
    # not declared anywhere: animate.js derives it from chunk visibility, so a
    # zone cannot disagree with the DNA it is describing.
    out.append('<g class="zones">')
    for i in range(lo, n_slots + 1):
        out.append('<rect class="zone" id="z-%s" x="%d" y="%d" width="%d" '
                   'height="%d"/>' % (chunk_id(i), cx(i), TOP_Y - 8, CW - 2,
                                      (BOT_Y + SH + 8) - (TOP_Y - 8)))
    out.append("</g>")

    out.append('<g class="dna" data-unique="%d">' % n_unique)
    for i in range(lo, n_slots + 1):
        x = cx(i)
        for half, y, cls, lab, letter in (("t", TOP_Y, "gstrand", "glab", "G"),
                                          ("b", BOT_Y, "cstrand", "clab", "C")):
            if i < 1:
                cls, lab, letter = "ustrand", "ulab", "U"
                state = ""
            else:
                limit = n_top if half == "t" else n_bot
                state = "" if i <= limit else " pending"
            out.append(
                '<g id="%s-%s" class="half %s%s">'
                '<rect class="halfbody" x="%d" y="%d" width="%d" height="%d"/>'
                '<text class="halflab %s" x="%d" y="%d">%s</text>'
                "</g>"
                % (chunk_id(i), half, cls, state, x, y, CW - 2, SH,
                   lab, x + (CW - 2) // 2, y + SH - 4, letter))
    out.append("</g>")

    # The two ends of the molecule, positioned by animate.js rather than here.
    # Which chunk is rightmost on each strand changes as chunks are added and
    # removed, so a static x would be wrong the moment anything moved: after
    # resection the 5' end is the front, several chunks left of where it started.
    # Same reasoning as the zone tints and Ku. paintDerived reads the same
    # visibility it reads for everything else, so an end label cannot disagree
    # with the strand it is marking.
    out.append('<text class="endlab off" id="end3">3&#8242;</text>')
    out.append('<text class="endlab off" id="end5">5&#8242;</text>')
    return "\n".join(out)


def unique_bracket(n_unique=N_UNIQUE):
    """Names the unique block, open at the left, and only once it is on screen.

    bracket() closes both ends, which is right for a region that has two of
    them. This one does not: it is the rest of the chromosome, and the pan never
    reaches its far side. So the left tick is dropped and the line runs off with
    the chunks, and the label sits near the boundary rather than centred on a
    span whose midpoint is off the page.

    Starts hidden. Every panel draws the block, but at rest the label is at
    x -33, which puts its right half over the left edge of the viewBox: a
    permanent fragment of clipped text in all fourteen panels. Frames that pan
    turn it on, so it exists exactly where it can be read.

    Stops 8px short of chunk 1, because the array bracket in panel 9 starts at
    cx(1) on the same row and two collinear brackets that touch read as one span
    with a label at each end. The gap is where the repeats begin.
    """
    x2 = end_x(0) - 8
    return ('<g class="bracket fx pending" id="fx-uniquespan">'
            '<path d="M %d %d H %d v -8"/>'
            '<text class="brlab" x="%d" y="%d">unique sequence</text>'
            "</g>" % (cx(1 - n_unique), 200, x2, x2 - 75, 222))


def rap1_array(pairs, rif1_on=True, rif2_on=True, sir_on=True):
    """Rap1 boxes on the duplex, each spanning two chunks.

    Rif1 loads proximal (drawn left on the box) and Rif2 distal (drawn right),
    both off the Rap1 C-terminus. The Sir2-3-4 complex loads on the most
    centromere-proximal Rap1 only. It does not change across these figures, but
    leaving it out implies the C-terminus has just two clients.
    """
    o = ['<g class="rap1array">']
    for n, start in enumerate(pairs):
        x = cx(start) + 3
        w = 2 * CW - 8
        # data-span lets paintDerived hide a box once its two repeats stop
        # being duplex. Rap1 binds double-stranded DNA, so the array has to
        # recede with the C-strand rather than hang over exposed tail.
        o.append('<g class="rap1 fx" id="rap1-%02d" data-span="%d">' % (start, start))
        o.append('<rect class="rap1box" x="%d" y="108" width="%d" height="24" rx="5"/>'
                 % (x, w))
        o.append('<text class="glyphlab" x="%d" y="124">Rap1</text>' % (x + w / 2))
        o.append('<line class="rct" x1="%d" y1="132" x2="%d" y2="139"/>'
                 % (x + w / 2, x + w / 2))
        # r 12, not 9. At 9 the socket was 18 across and "Rif1" only fits it at
        # 8px, which is the smallest type in the figure and sits in the most
        # repeated glyph in it. 24 across takes the label to 11px with room. The
        # sockets stay inside the box horizontally (14 from each end on a
        # 76-wide box) and clear each other by 12 between adjacent boxes.
        if rif1_on:
            o.append('<circle class="rif1" cx="%d" cy="97" r="12"/>' % (x + 14))
            o.append('<text class="glyphlab sm" x="%d" y="101">Rif1</text>' % (x + 14))
        if rif2_on:
            o.append('<circle class="rif2" cx="%d" cy="97" r="12"/>' % (x + w - 14))
            o.append('<text class="glyphlab sm" x="%d" y="101">Rif2</text>' % (x + w - 14))
        if sir_on and n == 0:
            # The Sir box moves up 10 to keep off the taller sockets. Its stem
            # gets longer by the same amount; nothing else in any panel occupies
            # x 56 to 124 above the array.
            o.append('<line class="rct" x1="%d" y1="108" x2="%d" y2="78"/>'
                     % (x + w / 2, x + w / 2))
            o.append('<rect class="sir" x="%d" y="56" width="66" height="22" rx="5"/>'
                     % (x + w / 2 - 33))
            o.append('<text class="glyphlab" x="%d" y="72">Sir2-3-4</text>' % (x + w / 2))
        o.append("</g>")
    o.append("</g>")
    return "\n".join(o)


def ku(n_duplex, lost=False):
    """Ku at the duplex-to-overhang junction.

    Ku threads onto double-stranded ends and has little affinity for
    single-stranded DNA, so it is drawn on the duplex side of the junction
    rather than out on the overhang. n_duplex is the panel's resting duplex
    length; data-basex records where that put it, and animate.js translates
    from there to wherever the junction actually is in the current frame. That
    makes Ku the marker of the junction in every frame with no frame-table
    entries, and it is the same derivation that drives the zone tints.

    Ku tracking a receding junction during resection is a drawing convention,
    not a measured trajectory. The captions say so.
    """
    x = end_x(n_duplex) - KU_INSET
    # "fx" as well as an actor id. Branch E fades Ku out, and clearAnimationClasses
    # only resets elements matching ".half, .fx", so without it the faded state
    # would survive a reset and smear into the next scrub.
    cls = "ku fx lost" if lost else "ku fx"
    return ('<g class="%s" id="actor-ku" data-basex="%d">'
            '<circle class="kuouter" cx="%d" cy="%d" r="21"/>'
            '<circle class="kuinner" cx="%d" cy="%d" r="11"/>'
            '<text class="glyphlab" x="%d" y="%d">Ku</text>'
            "</g>" % (cls, x, x, MID, x, MID, x, MID - 27))


def mrx(x, seated=True, tel1=False, rif2_socket=False, faint=False,
        mirror=False, contested=False, staged=False, ident="actor-mrx"):
    """MRX on the duplex.

    All three subunits are always drawn, because MRX is a constitutive complex:
    Mre11 dimer on the DNA, Rad50 above it, Xrs2 alongside. What changes is not
    whether Xrs2 is present but whether its C-terminus is docked.

    Rad50 carries a socket. The Xrs2 C-terminus plugs into it and becomes the
    flagpole Tel1 flies from. Rif2 competes for that same surface, so when Rif2
    takes the socket the C-terminus is displaced and hangs unseated: the
    subunit is still there, but there is no pole and therefore no flag.

    mirror puts Xrs2 and the flagpole on the left of Rad50 instead of the right.
    Panels 1 to 3 draw MRX at the terminus with the duplex to its left, so the
    accessories hang right into empty canvas. From panel 4 the complex sits at
    the junction with Cdc13 immediately to its right, so the same layout would
    put Xrs2 through the Cdc13 wedge; mirrored, it hangs back over the duplex.

    contested draws the losing candidate for the socket as well as the winning
    one, using the idiom panel 8 already uses for Est1 and CST: the contact that
    is not being made is ghosted, and a blunt bar runs from whatever is blocking
    it. With the C-terminus seated the loser is Rif2, which is otherwise not on
    the complex at all, so it is drawn ghosted beside the socket. With Rif2 in
    the socket the loser is the C-terminus, which is already on the page as the
    unseated pole, so that case adds the bar alone and nothing is drawn twice.

    Neither bar carries a label. Panel 8 does not label its exclusion mark
    either, and what makes the competition legible is the number of Rif2
    molecules on the array above it, which is a property of the panel and not of
    this glyph.

    staged puts the Tel1 flag and the exclusion mark in addressable groups that
    start invisible, so a frame table can bring them in one at a time. They stay
    inside the complex, because both are statements about the socket and would
    detach from it the moment a frame moved MRX. Panel 5 is the only user: it
    stages the same picture the other panels draw at once.

    The two Mre11 lobes carry their own actor ids so a frame table can part them.
    Panel 3 uses that to show Mre11 taking the repeat distal to the incision,
    which is the only way the bidirectional claim is visible rather than stated.
    """
    # "fx" as well as an actor id. Panel 3 fades the complex out once the
    # incision is made and the distal fragment cleared, and
    # clearAnimationClasses only resets elements matching ".half, .fx", so
    # without it the faded state would survive a reset.
    cls = "mrx fx faint" if faint else "mrx fx"
    s = -1 if mirror else 1
    o = ['<g class="%s" id="%s">' % (cls, ident)]

    # Mre11 dimer, on the DNA. Two ids, one per lobe, so the pair can separate.
    o.append('<g id="%s-lobeL"><ellipse class="mre11" cx="%d" cy="%d" '
             'rx="19" ry="12"/></g>' % (ident, x - 12, MID))
    o.append('<g id="%s-lobeR"><ellipse class="mre11" cx="%d" cy="%d" '
             'rx="19" ry="12"/></g>' % (ident, x + 12, MID))
    o.append('<text class="glyphlab" x="%d" y="%d">Mre11</text>' % (x, MID + 4))

    # Rad50, with the contested socket on top
    o.append('<circle class="rad50" cx="%d" cy="118" r="17"/>' % x)
    o.append('<text class="glyphlab" x="%d" y="122">Rad50</text>' % x)
    o.append('<rect class="socket" x="%d" y="97" width="15" height="9" rx="2"/>' % (x - 7))

    # Xrs2 body, always present
    o.append('<ellipse class="xrs2" cx="%d" cy="132" rx="20" ry="13"/>' % (x + s * 44))
    o.append('<text class="glyphlab" x="%d" y="136">Xrs2</text>' % (x + s * 44))

    def stage(ident_, body):
        # Addressable and invisible when the panel stages its socket, plain
        # markup when it does not.
        if not staged:
            return body
        return '<g class="fx pending" id="%s">%s</g>' % (ident_, body)

    if rif2_socket:
        # Rif2 in the socket; the Xrs2 C-terminus is displaced and hangs free
        o.append('<path class="pole unseated" d="M %d 122 L %d 96 L %d 78"/>'
                 % (x + s * 34, x + s * 58, x + s * 64))
        o.append('<text class="polelab" x="%d" y="72">C-term displaced</text>'
                 % (x + 40 if not mirror else x - 116))
        o.append('<circle class="rif2 seated" cx="%d" cy="101" r="10"/>' % x)
        o.append('<text class="glyphlab sm" x="%d" y="104">Rif2</text>' % x)
        if contested:
            # From Rif2 to the base of the displaced pole. The bar lands on the
            # C-terminus, which is the thing being kept out.
            o.append(stage("fx-socket", inhibit(x + s * 9, 105, x + s * 28, 118)))
    elif seated:
        # C-terminus docked in the socket, continuing up as the flagpole
        o.append('<path class="pole" d="M %d 124 L %d 101 L %d 48"/>'
                 % (x + s * 34, x, x))
        o.append('<text class="polelab" x="%d" y="84">Xrs2 C-term</text>'
                 % (x + 6 if not mirror else x - 140))
        if contested:
            # Rif2 on the same side as the Xrs2 body, outboard of it. The other
            # side carries the Tel1 arrow in the one panel that uses this, and
            # a ghost sitting under that arrow reads as its target.
            gx = x + s * 52
            o.append(stage("fx-socket",
                           ghost('<circle class="rif2" cx="%d" cy="101" r="10"/>'
                                 '<text class="glyphlab sm" x="%d" y="104">Rif2</text>'
                                 % (gx, gx))
                           + inhibit(x + s * 16, 103, x + s * 40, 101)))
        if tel1:
            o.append(stage("fx-tel1",
                           '<polygon class="tel1flag" points="%d,48 %d,48 %d,66 %d,66"/>'
                           '<text class="glyphlab" x="%d" y="61">Tel1</text>'
                           % (x, x + s * 62, x + s * 62, x, x + s * 31)))
    o.append("</g>")
    return "\n".join(o)


def nick(i, flashing=False, ident=None):
    """The Mre11 incision, on the C-strand at the left edge of chunk i.

    A cut is a discontinuity, not a missing block, so it is a mark across the
    strand rather than a removed half. Panel 2 flashes it because making the cut
    is what that panel is about; panel 3 carries the same mark static, so its
    first frame already shows two C-strand fragments and the two nucleases
    leaving from between them.

    ident makes the mark addressable, and carries the "fx" class with it. Panel
    3 retires the mark on the same frame it retires MRX: once Exo1 and
    Sgs1-Dna2 have carried the 5' end past it, there is no longer a
    discontinuity there to draw, and leaving it behind would put a cut in the
    middle of a strand that no longer reaches it.
    """
    x = cx(i)
    cls = "nick flashing" if flashing else "nick"
    if ident:
        cls += " fx"
        cls = '%s" id="%s' % (cls, ident)
    # Runs well below the C-strand. Mre11 sits on the DNA at the incision site
    # and covers the top two thirds of the mark, so a line bounded by the strand
    # is invisible in exactly the panel that is about making the cut.
    return ('<line class="%s" x1="%d" y1="%d" x2="%d" y2="%d"/>'
            % (cls, x - 1, BOT_Y - 3, x - 1, BOT_Y + SH + 12))


def wedge(x, y, r, cls, label, rot=0, labdx=0, labdy=0):
    """Quarter-disc glyph: flat top and left, curved lower right.

    This is the OB-fold shape from the original figures. Corner sits at (x, y),
    flat edge runs right, curve sweeps down and back.
    """
    t = ' transform="rotate(%d %d %d)"' % (rot, x, y) if rot else ""
    return ('<g%s><path class="%s" d="M %d %d h %d a %d %d 0 0 1 -%d %d z"/>'
            '<text class="glyphlab" x="%d" y="%d">%s</text></g>'
            % (t, cls, x, y, r, r, r, r, r,
               x + r * 0.42 + labdx, y + r * 0.55 + labdy, label))


def halfdisc(cxx, cyy, r, cls, label):
    """Dome sitting flat on a line. Used for subunits riding the TLC1 shaft."""
    return ('<g><path class="%s" d="M %d %d a %d %d 0 0 1 %d 0 z"/>'
            '<text class="glyphlab sm" x="%d" y="%d">%s</text></g>'
            % (cls, cxx - r, cyy, r, r, 2 * r, cxx, cyy - 5, label))


def cdc13_mark(x, y, kind, anchor, ident=None, pending=False, site=None):
    """The covalent mark that says which job this Cdc13 is configured for.

    Two marks, two states, and a third state that is the absence of both.

    "p" is Cdk1 phosphorylation at T308, which promotes Est1 binding and
    telomerase recruitment. Same phosphate glyph as Sae2 S267, because the
    site is established and the model reserves that glyph for settled sites.

    "s" is SUMOylation at K909, which strengthens the Stn1 contact. Different
    shape as well as different colour, so the two states stay apart in
    greyscale.

    Both sit above the wedge rather than on it, aligned to the x of the
    molecule they belong to. On the glyph they covered the Cdc13 label, and in
    the trimer a centred mark reads as belonging to the whole complex rather
    than to its large subunit. The cost is that a mark floating above the
    strand can be misread as bound to DNA; the x alignment is what carries the
    attachment, so nothing else should be drawn directly above a Cdc13.

    Nothing here is S249 or S255. Those stay unmarked and keep the labelled
    arrow of panel 5, which is the whole point of having two treatments: a
    reader can now tell the established site from the contested one by looking.
    """
    # Leader down to the wedge. The mark sits above the strand and the wedge
    # below it, so the line crosses the repeat; that is the same crossing the
    # Rap1 stems already make and it is what stops a floating mark reading as
    # bound to DNA. anchor is the wedge's flat top.
    def leader(y0):
        return ('<line class="marklink" x1="%d" y1="%d" x2="%d" y2="%d"/>'
                % (x, y0, x, anchor))

    # ident makes the mark something a frame table can deposit, and carries the
    # "fx" class with it so clearAnimationClasses can reset it. Panel 5 uses
    # that: the phosphate is the outcome of the first frame, so it must not be
    # on the glyph before the kinase has acted.
    cls = "cmark"
    if ident:
        cls += " fx pending" if pending else " fx"
    idattr = ' id="%s"' % ident if ident else ""

    if kind == "p":
        return ('<g class="%s"%s>%s<circle class="phos" cx="%d" cy="%d" r="9"/>'
                '<text class="glyphlab sm" x="%d" y="%d">P</text>'
                '<text class="glyphlab sm mk" x="%d" y="%d">%s</text></g>'
                % (cls, idattr, leader(y + 9), x, y, x, y + 3, x, y - 14,
                   site or "T308"))
    if kind == "s":
        return ('<g class="%s"%s>%s<rect class="sumo" x="%d" y="%d" width="18" '
                'height="14" rx="3"/>'
                '<text class="glyphlab sm" x="%d" y="%d">SU</text>'
                '<text class="glyphlab sm mk" x="%d" y="%d">%s</text></g>'
                % (cls, idattr, leader(y + 7), x - 9, y - 7, x, y + 3, x, y - 14,
                   site or "K909"))
    return ""


def cdc13(x, y=CDC13_Y, ident="actor-cdc13", label="Cdc13", mark=None,
          faint=False, mark_ident=None, mark_pending=False):
    """Cdc13 OB fold on the single-stranded overhang.

    The default y puts the wedge corner on the top strand rather than on the
    duplex centre line, because the protein binds single-stranded TG1-3. Every
    panel that draws Cdc13 uses the same corner height, so the glyph does not
    change altitude as you step through the workflow.

    mark selects the covalent state; see cdc13_mark. faint draws a molecule
    that is present but is not the subject of the panel, which in panel 8 is
    the recruiting Cdc13 left behind on repeats fill-in is about to copy.
    """
    # "fx" as well as an actor id: clearAnimationClasses only resets
    # ".half, .fx", so without it a frame that removes this molecule would
    # leave "gone" behind and it would stay missing on the next scrub.
    cls = "cdc13 fx faint" if faint else "cdc13 fx"
    return ('<g class="%s" id="%s">%s%s</g>'
            % (cls, ident, wedge(x, y - 30, CDC13_R, "ob", label),
               cdc13_mark(x + 26, y - 30 - 26, mark, y - 30,
                          ident=mark_ident, pending=mark_pending)))


def cst(x, y=CDC13_TOP, ident="actor-cst", extra="", mark=None, cls="",
        stn1_mark="p", stn1_ident=None, stn1_pending=False):
    """Cdc13-Stn1-Ten1. Cdc13 is the wedge; Stn1 sits above Ten1 to its right,
    and the three are contiguous so the trimer reads as one unit.

    extra goes inside the group, so anything drawn relative to the trimer moves
    with it. Panel 8 puts the blocked Est1 contact there: Est1 would bind Cdc13,
    so where that contact would have been is wherever Cdc13 is, and an exclusion
    mark anchored to a fixed coordinate detaches from the thing doing the
    excluding as soon as the panel animates.

    Stn1 carries a phosphate of its own. Cdk1 phosphorylates it at T223 and
    S250, in vitro and in vivo, so the same glyph the Cdc13 sites use goes above
    Stn1, aligned to the middle of its box the way the Cdc13 mark aligns to its
    wedge. Two sites on one mark, which is new: the alternative was two circles
    over a 48-wide box.

    Panel 8 is the only caller that wants it deposited rather than drawn, since
    that is the panel where the phosphorylation happens, so it passes an ident
    and pending and a frame turns it on.
    """
    return ('<g class="cst fx%s" id="%s">%s%s'
            '<rect class="stn1" x="%d" y="%d" width="48" height="24" rx="3"/>'
            '<text class="glyphlab" x="%d" y="%d">Stn1</text>'
            '<rect class="ten1" x="%d" y="%d" width="48" height="20" rx="3"/>'
            '<text class="glyphlab" x="%d" y="%d">Ten1</text>'
            "%s%s</g>"
            % ((" " + cls) if cls else "", ident, wedge(x, y, CDC13_R, "ob", "Cdc13"),
               cdc13_mark(x + 26, y - 26, mark, y),
               # The box runs from x + CDC13_R for 48, so its middle is x + 76.
               # The label used to sit at x + 63, which is 13 left of centre.
               x + CDC13_R, y, x + 76, y + 16,
               x + 40, y + 24, x + 63, y + 38,
               cdc13_mark(x + 76, y - 26, stn1_mark, y, ident=stn1_ident,
                          pending=stn1_pending, site="T223/S250")
               if stn1_mark else "", extra))


def rpa_unit(i, y=TOP_Y, ident=None, faint=False, pending=False):
    """One RPA bound to one repeat unit.

    Small enough to sit on a single chunk, which is what lets the frame table
    deposit it as the C-strand comes off. The wedge is Rfa1 and the bump to its
    right stands for Rfa2 and Rfa3 together; the subunit names are in the
    caption. Same silhouette as cst() at a quarter the size, because CST is the
    RPA-like complex and the shape is the argument.

    pending starts the unit invisible so a frame can turn it on. faint draws it
    on its way off, which is the panel 4 case.
    """
    x = cx(i)
    cls = "fx rpa" + (" faint" if faint else "") + (" pending" if pending else "")
    idattr = ' id="%s"' % ident if ident else ""
    return ('<g class="%s"%s>'
            '<path class="rfa1" d="M %d %d h %d a %d %d 0 0 1 -%d %d z"/>'
            '<rect class="rfa23" x="%d" y="%d" width="14" height="11" rx="2"/>'
            '<text class="glyphlab sm" x="%d" y="%d">RPA</text>'
            "</g>"
            % (cls, idattr,
               x + 2, y - 9, RPA_R, RPA_R, RPA_R, RPA_R, RPA_R,
               x + 2 + RPA_R, y - 9,
               x + 20, y - 13))


def pol_alpha(xtail, ybot, xtip, ident="actor-pola", label="Pol &#945;-primase"):
    """Pol alpha-primase as a left-pointing arrow, drawn as the enzyme alone.

    The L-shape this replaces had a vertical leg running up the right side of
    CST, which said the polymerase is held by the trimer and travels with it.
    The trimer no longer travels: it holds the terminal Cdc13 footprint, which
    is the one stretch of the overhang that is never copied. The polymerase
    does translocate, along its template, so this glyph keeps its offset in the
    frame table and the trimer loses its own.

    The product is not drawn here. It is the C-strand halves arriving one
    repeat at a time, which is the thing that actually grows.
    """
    pts = "%d,%d %d,%d %d,%d %d,%d %d,%d %d,%d %d,%d" % (
        xtail, ybot, xtail, ybot + 20,
        xtip + 34, ybot + 20, xtip + 34, ybot + 30,
        xtip, ybot + 10, xtip + 34, ybot - 10,
        xtip + 34, ybot)
    # "fx" as well as an actor id: the frame table both moves it and, once
    # fill-in is done, turns it off. An id may appear in both maps.
    return ('<g class="pola fx" id="%s">'
            '<polygon class="polabody" points="%s"/>'
            '<text class="glyphlab" x="%d" y="%d">%s</text>'
            "</g>" % (ident, pts, (xtip + 34 + xtail) / 2, ybot + 14, label))


def telomerase(x, y, rotated=False, ident="actor-tel", shaft=196):
    """Telomerase, drawn as in the reference layout.

    TLC1 is a thick ring with a straight shaft running right and an arrowhead
    at its end, so the RNA itself carries the direction of extension. Est2 and
    Est3 ride the shaft as domes. Est1 is a wedge above the ring, reaching up
    to meet Cdc13; that contact is the Est4 function, so it is shown by
    adjacency rather than by a labelled arrow.

    (x, y) is the ring centre. rotated tips the whole assembly 45 degrees so
    the stem-loop meets Ku and the RNA points up and away from the DNA, which
    is how the G1 panel says the enzyme is present but not engaged.
    """
    rot = ' transform="rotate(-45 %d %d)"' % (x, y) if rotated else ""
    r = 28
    # Where the shaft leaves the ring, on the circle itself, so the lower lip
    # of the loop and the base of the arrow are one continuous stroke.
    dy = 20
    dx = int(round((r * r - dy * dy) ** 0.5))
    sy, xe = y + dy, x + shaft
    o = ['<g class="telomerase" id="%s"%s>' % (ident, rot)]
    o.append('<path class="tlc1" d="M %d %d A %d %d 0 1 0 %d %d H %d"/>'
             % (x + dx, y - dy, r, r, x + dx, sy, xe))
    o.append('<polygon class="tlc1head" points="%d,%d %d,%d %d,%d"/>'
             % (xe, sy - 17, xe + 32, sy, xe, sy + 17))
    o.append('<text class="glyphlab lt" x="%d" y="%d">TLC1</text>' % (x - 6, y + 2))
    o.append(halfdisc(x + 56, sy, 18, "est2", "Est2"))
    o.append(halfdisc(x + 92, sy, 18, "est3", "Est3"))
    o.append(wedge(x + 30, y - 50, 52, "est1", "Est1"))
    o.append("</g>")
    return "\n".join(o)


def nuclease(x, y, label, ident, direction="right", show_arrow=True):
    """A translocating nuclease or helicase, or any enzyme drawn in that idiom.

    show_arrow draws the travel-direction tick. Turn it off where the animation
    already carries the direction, as in panel 3, or where the glyph is not
    translocating at all, as with Ipl1 in panel 7.
    """
    tip = 18 if direction == "right" else -18
    arrowhead = ('<line class="nucarrow" x1="%d" y1="%d" x2="%d" y2="%d" '
                 'marker-end="url(#p-arrow)"/>'
                 % (x + 38, y + 34, x + 38 + tip, y + 34)) if show_arrow else ""
    return ('<g class="nuclease" id="%s">'
            '<rect class="nucbody" x="%d" y="%d" width="76" height="24" rx="6"/>'
            '<text class="glyphlab" x="%d" y="%d">%s</text>'
            "%s</g>" % (ident, x, y, x + 38, y + 16, label, arrowhead))


def protein(x, y, w, label, cls, ident=None, phos=False):
    """Generic labelled protein box, with an optional phosphate marker."""
    i = ' id="%s"' % ident if ident else ""
    out = ['<g class="prot %s"%s>' % (cls, i)]
    out.append('<rect class="protbody" x="%d" y="%d" width="%d" height="26" rx="6"/>'
               % (x, y, w))
    out.append('<text class="glyphlab" x="%d" y="%d">%s</text>' % (x + w / 2, y + 17, label))
    if phos:
        out.append('<circle class="phos" cx="%d" cy="%d" r="8"/>' % (x + w, y))
        out.append('<text class="glyphlab sm" x="%d" y="%d">P</text>' % (x + w, y + 3))
    out.append("</g>")
    return "\n".join(out)


def inhibit(x1, y1, x2, y2, label=""):
    """A blocked interaction. Same role as arrow(), one mark per causal step,
    but with a blunt bar in place of the arrowhead."""
    dx, dy = x2 - x1, y2 - y1
    n = (dx * dx + dy * dy) ** 0.5 or 1.0
    px, py = -dy / n * 7, dx / n * 7
    lab = ('<text class="arrowlab" x="%d" y="%d">%s</text>'
           % ((x1 + x2) / 2, (y1 + y2) / 2 - 7, label)) if label else ""
    return ('<g class="inhibit"><path class="inhibitline" d="M %d %d L %d %d"/>'
            '<path class="inhibitline" d="M %d %d L %d %d"/></g>%s'
            % (x1, y1, x2, y2,
               x2 + px, y2 + py, x2 - px, y2 - py, lab))


def link(x1, y1, x2, y2):
    """Plain connector between two glyphs that are bound to each other. Carries
    no direction and claims no causality; arrow() and inhibit() do that."""
    return '<line class="link" x1="%d" y1="%d" x2="%d" y2="%d"/>' % (x1, y1, x2, y2)


def ghost(body):
    """Draw a glyph as the contact that is not being made."""
    return '<g class="ghost">%s</g>' % body


def arrow(x1, y1, x2, y2, label="", curve=0,
          labelrot=False, labelt=0.5, labelgap=9, labelside=None):
    """Labelled effect arrow. One arrow per causal step, never one per chain.

    By default the label is horizontal, above the midpoint. That is fine for a
    long shallow arrow and wrong for a short steep one, where horizontal text
    beside a diagonal line reads as belonging to whatever else sits on that
    row. labelrot runs the label along the arrow instead.

    labelt slides the label along the arrow, 0 at the tail and 1 at the head,
    which is the escape hatch when one end of a short arrow is crowded.
    labelgap is the perpendicular clearance, always taken on the upper side so
    the label never ends up under the line it belongs to.

    labelside is the third option, and it exists for the case the other two
    both handle badly: a vertical arrow. labelrot there sets the text on its
    side, which a reader has to tilt their head to follow, and the default puts
    horizontal text across the midpoint, which is the line itself. labelside
    keeps the text horizontal and pushes it clear instead. "left" and "right"
    move it off the line at the labelt point and re-anchor it so it grows away
    from the arrow rather than back across it; "above" and "below" centre it
    past the head or the tail. Anchoring is a class rather than an attribute,
    because .arrowlab sets text-anchor in CSS and a presentation attribute
    would lose to it.

    Both the anchor and the angle come off the curve itself rather than the
    chord, so a curved arrow gets its label on the arc and tangent to it.
    """
    mx, my = (x1 + x2) / 2, (y1 + y2) / 2 - curve
    if curve:
        d = "M %d %d Q %d %d %d %d" % (x1, y1, mx, my, x2, y2)
    else:
        d = "M %d %d L %d %d" % (x1, y1, x2, y2)

    if not label:
        lab = ""
    elif labelside:
        t = labelt
        bx = (1 - t) ** 2 * x1 + 2 * t * (1 - t) * mx + t * t * x2
        by = (1 - t) ** 2 * y1 + 2 * t * (1 - t) * my + t * t * y2
        if labelside == "left":
            # 3.5 is half the cap height at this font size, so the text sits
            # centred on the point rather than hanging below it
            lx, ly, cls = bx - labelgap, by + 3.5, " lab-l"
        elif labelside == "right":
            lx, ly, cls = bx + labelgap, by + 3.5, " lab-r"
        elif labelside == "above":
            lx, ly, cls = bx, min(y1, y2) - labelgap, ""
        elif labelside == "below":
            lx, ly, cls = bx, max(y1, y2) + labelgap + 8, ""
        else:
            raise ValueError("labelside must be left, right, above or below")
        lab = ('<text class="arrowlab%s" x="%d" y="%d">%s</text>'
               % (cls, lx, ly, label))
    elif not labelrot:
        lab = ('<text class="arrowlab" x="%d" y="%d">%s</text>'
               % ((x1 + x2) / 2, (y1 + y2) / 2 - curve / 2 - 7, label))
    else:
        t = labelt
        # point on the quadratic, and its tangent. With curve = 0 the control
        # point is the midpoint and both reduce to the straight line, so there
        # is one code path rather than two.
        bx = (1 - t) ** 2 * x1 + 2 * t * (1 - t) * mx + t * t * x2
        by = (1 - t) ** 2 * y1 + 2 * t * (1 - t) * my + t * t * y2
        tx = 2 * (1 - t) * (mx - x1) + 2 * t * (x2 - mx)
        ty = 2 * (1 - t) * (my - y1) + 2 * t * (y2 - my)
        n = math.hypot(tx, ty) or 1.0
        px, py = ty / n, -tx / n
        if py > 0:
            px, py = -px, -py
        lx, ly = bx + px * labelgap, by + py * labelgap
        ang = math.degrees(math.atan2(ty, tx))
        # keep the text upright: a leftward arrow would otherwise set it upside
        # down, and the reader should not have to tilt their head past vertical
        if ang > 90 or ang < -90:
            ang += 180
        lab = ('<text class="arrowlab" x="%d" y="%d" '
               'transform="rotate(%.1f %d %d)">%s</text>'
               % (lx, ly, ang, lx, ly, label))
    return '<path class="effect" d="%s" marker-end="url(#p-arrow)"/>%s' % (d, lab)


def bracket(x1, x2, y, label):
    """Span marker under the DNA, for naming a region."""
    return ('<g class="bracket">'
            '<path d="M %d %d v 8 H %d v -8"/>'
            '<text class="brlab" x="%d" y="%d">%s</text>'
            "</g>" % (x1, y, x2, (x1 + x2) / 2, y + 22, label))


def repression_target(x, y, w, label, ident_off, ident_on):
    """A named process, off and then on. The target half of a repression
    statement; the bar comes from whatever is doing the repressing.

    Two copies at the same coordinates, on the capbar base-and-flip idiom: the
    grey one is on the page at frame 0 and leaves, the lit one is pending and a
    frame turns it on. One box restyled in place would need a class the frame
    engine does not set, since it only moves fx groups between shown, fading and
    gone.

    The lit state is a steady glow, not the pulse panel 9 uses. That pulse means
    the element is clickable, and reusing it would offer an affordance that does
    not exist.

    Panel furniture. NHEJ is an outcome and not a molecule, so it has no
    coordinate on the DNA and does not ride the camera.
    """
    return "\n".join([
        fx(ident_off, protein(x, y, w, label, "nhejoff"), pending=False),
        fx(ident_on, protein(x, y, w, label, "nhejon"))])


# ---------------------------------------------------------------------------
# Reference panels. These are diagrams rather than moments: no cap indicator,
# no Ku, no derived marks, and no entry in KEYS or META, so the animation never
# shows them and the suite's every-panel rules do not apply. They exist so a
# figure that needs the glyph vocabulary can have it without the vocabulary
# having to pretend the figure is a telomere at a point in the cycle.
#
# One consequence to keep in mind: these panels declare what every other panel
# derives. The 3' and 5' marks are written in rather than computed from chunk
# visibility. That inverts the rule the rest of the figure runs on, and it is
# safe here only because there is no state to disagree with.

NUC_R = 15                  # the octamer
NUC_IN, NUC_OUT = 19, 23    # the two strands, wrapped
RIBBON = 4                  # strand separation once the duplex has converged


def nucleosome(cx0, cy=MID + 2):
    """DNA wrapped on a histone octamer, seen down the superhelical axis.

    Face-on, because that puts the wrap in the plane of the page and needs no
    perspective. The octamer is a solid disc: viewed down the axis it is solid,
    and a hole would imply the DNA threads it, which is not what happens.

    The two strands cannot both wrap at their block-row spacing. They sit 22
    apart there, symmetric about the duplex centre, so wrapping each at its own
    distance from the centre gives two rings of the same radius drawn on top of
    each other. So the duplex converges to a ribbon of RIBBON before the run and
    separates again after it, and the strands wrap at NUC_IN and NUC_OUT. That
    convergence is the one place in the whole figure where the DNA leaves the
    horizontal axis, and it is what buys the wrap.

    The wrap sits outside the octamer, which is where it is: the DNA runs on the
    surface of the histone core, so face-on there is nothing for the core to
    hide. What makes it read as wrapped is the linkers meeting the ring where
    the ring is horizontal, so the strand entering is continuous with the strand
    going round. The two arcs are kept close, at NUC_IN and NUC_OUT, so they
    read as one duplex rather than two rings.

    Entry and exit are both at cy, so a run of these chains without the caller
    having to know anything about the glyph.
    """
    o = ['<g class="nucleosome">']

    def half(r, cls, top):
        # Semicircle, left to right over the top or under the bottom. Sweep 1 is
        # clockwise in SVG's y-down space, which is clockwise to the reader.
        return ('<path class="nucwrap %s" d="M %d %d A %d %d 0 0 %d %d %d"/>'
                % (cls, cx0 - r, cy, r, r, 1 if top else 0, cx0 + r, cy))

    # far half of both strands
    o.append(half(NUC_OUT, "g", True))
    o.append(half(NUC_IN, "c", True))
    # the octamer, over them
    o.append('<circle class="nucdisc" cx="%d" cy="%d" r="%d"/>' % (cx0, cy, NUC_R))
    # near half of both strands, over the octamer
    o.append(half(NUC_OUT, "g", False))
    o.append(half(NUC_IN, "c", False))
    o.append("</g>")
    return "\n".join(o)


def ribbon(x1, x2, cy=MID + 2):
    """The duplex between two nucleosomes, or up to the first one."""
    return "\n".join(
        '<path class="nucwrap %s" d="M %d %d H %d"/>'
        % (cls, x1, cy + dy, x2)
        for cls, dy in (("g", -RIBBON // 2), ("c", RIBBON // 2)))


def ribbon_taper(x1, x2, cy=MID + 2, opening=False):
    """Where the block rows become a ribbon, or the ribbon becomes block rows.

    The strand that is on top stays on top. Nothing crosses here: the taper is
    a change of spacing and not a change of which strand is which.
    """
    rows = ((("g"), TOP_Y + SH // 2, cy - RIBBON // 2),
            (("c"), BOT_Y + SH // 2, cy + RIBBON // 2))
    out = []
    for cls, ry, cyy in rows:
        a, b = (x1, x2) if not opening else (x2, x1)
        y0, y1 = (ry, cyy) if not opening else (cyy, ry)
        out.append('<path class="nucwrap %s" d="M %d %d C %d %d %d %d %d %d"/>'
                   % (cls, a, y0, a + (b - a) * 0.5, y0,
                      a + (b - a) * 0.5, y1, b, y1))
    return "\n".join(out)


def ars_mark(x, y, label="ARS"):
    """The last origin before the end. Nothing else in the figure marks one."""
    return ('<g class="ars"><rect class="arsbody" x="%d" y="%d" width="46" '
            'height="20" rx="10"/>'
            '<text class="glyphlab" x="%d" y="%d">%s</text>'
            '<line class="arsstem" x1="%d" y1="%d" x2="%d" y2="%d"/></g>'
            % (x, y, x + 23, y + 14, label, x + 23, y + 20, x + 23, MID - 12))


def allele_label(text, x=12, y=22):
    """The genotype the panel is drawn under, in the top left corner.

    Red bold italic, which no other mark in the figure uses: the strand colours
    name molecules, grey names annotation, and the one other red in the
    vocabulary is the incision, which is a line and never text. So a reader can
    tell a genotype from a label about the drawing without being told.

    The corner, and left-anchored, which nothing else in a panel is. It shares
    its row with the cap indicator at the opposite edge, so the two things a
    reader checks first sit on one line: what was done to this telomere, and
    what state the cap is in. The genotype is the first thing read, so it takes
    the corner and the condition strip starts to the right of it.

    Panel furniture, so it stays outside the camera.
    """
    return '<text class="allelelab" x="%d" y="%d">%s</text>' % (x, y, text)


def terminus_label(x, text):
    return '<text class="endlab" x="%d" y="%d">%s</text>' % (x, MID + 46, text)


def replisome(x, y=196, ident="actor-repl"):
    """The fork, drawn as one box travelling toward the terminus.

    Leading-strand synthesis at a telomere is not primed at the telomere. The
    fork arrives from a subtelomeric origin and the new G-strand is continuous
    from wherever that fork fired, so what enters the frame is a replisome
    already synthesising, not a primer being laid down. Drawing a primer in the
    unique block would assert an origin at that exact spot.

    Right-pointing, because the leading strand runs toward the terminus. The
    lagging panel uses pol_alpha() instead, which points left, because each
    Okazaki fragment is extended back toward the centromere.
    """
    # Shaft 100 wide so the label sits inside it rather than spilling past the
    # tail, head beyond that. At the last frame the tip lands at 772, which is
    # inside the 880 viewBox.
    return ('<g class="repl fx" id="%s">'
            '<polygon class="replbody" points="%d,%d %d,%d %d,%d %d,%d %d,%d %d,%d %d,%d"/>'
            '<text class="glyphlab" x="%d" y="%d">replisome, Pol &#949;</text>'
            "</g>"
            % (ident,
               x, y, x, y + 24, x + 100, y + 24, x + 100, y + 34,
               x + 134, y + 12, x + 100, y - 10, x + 100, y,
               x + 50, y + 16))


def primer(i, ident=None, y=BOT_Y):
    """One RNA primer, drawn over the C-strand half it occupies.

    A hatched overlay rather than a differently coloured block, because the
    primer is RNA sitting in the place a C-strand half will end up rather than
    a different kind of repeat. Three of the four internal ones are replaced by
    DNA when Rad27 processes the flap and the block underneath simply stays;
    the terminal one is removed by RNase H2 and nothing fills it, which is the
    overhang.
    """
    idattr = ' id="%s"' % ident if ident else ""
    x = cx(i)
    return ('<g class="fx rnaprimer pending"%s>'
            '<rect class="primerbody" x="%d" y="%d" width="%d" height="%d" rx="2"/>'
            '<text class="glyphlab sm primerlab" x="%d" y="%d">RNA</text>'
            "</g>" % (idattr, x, y - 1, CW - 2, SH + 2,
                      x + (CW - 2) // 2, y + SH - 3))


# ------------------------------------------------------------------- frame --
CAP_FULL_ARRAY = 12         # duplex telomeric repeats a complete Rap1 array
                            # needs. The underlying relationship is continuous:
                            # NHEJ inhibition and resection suppression are
                            # proportional to the length of the Rap1-bound array
                            # next to the end, and MRX reads short blocks
                            # differently from long ones. So no threshold is
                            # given by the biology and this one is a drawing
                            # convention, placed between the two states the
                            # figure has to tell apart: panel 5 sits at 10
                            # duplex repeats and branch B at 14. Panel 9's
                            # capped telomere carries 17.

# What each state is called, per element. The ladder has the same shape in every
# slot and the rungs do not mean the same thing, so the words are per element
# rather than shared. CST is the only element with a documented intermediate,
# since it is the only one that assembles from separately regulated subunits;
# Rap1's middle rung is a count on one substrate, which is a different axis; Ku
# is an obligate heterodimer and has no middle rung at all.
CAP_WORDS = {
    "rap1": {"on": "full array", "thin": "short array", "off": "none bound",
             "na": "no duplex", "lost": "array lost"},
    "cst":  {"on": "assembled", "thin": "Cdc13 only", "off": "none established",
             "na": "no overhang", "lost": "CST lost"},
    "ku":   {"on": "bound", "thin": "partial", "off": "none established",
             "na": "no junction", "lost": "Ku lost"},
}


def cap_state_rap1(n_duplex):
    """MODEL: Rap1 slot from the duplex telomeric repeat count (TERMINAL).

    Rap1 binds duplex TG1-3, so its substrate is the duplex part of the array
    and its occupancy is how much of that there is. Both of the things this slot
    reports come from the same steric mechanism: the length of the Rap1 array
    next to the end is what suppresses MRX, which is why a short array is read
    as marginal protection here and as a free Rad50 socket in panel 5.

    Counted rather than measured against total repeat length, because resection
    is what makes the terminal repeats stop being Rap1 substrate. A telomere
    mid-resection has fewer loadable sites near the end than the same telomere
    before it, and that is the state panels 4 to 7 are in.
    """
    if n_duplex <= 0:
        return "na"
    return "on" if n_duplex >= CAP_FULL_ARRAY else "thin"


def cap_state_cst(n_g, n_duplex, cst=None):
    """MODEL: CST slot from the overhang and what is drawn on it (TERMINAL).

    cst is None, "cdc13" for the recruitment-competent monomer alone, or
    "trimer" for the assembled complex. The rungs are the assembly ladder, and
    off is the rung that says the substrate is there and nothing on it is
    established. That is a claim about the evidence at this step and not a count
    of molecules: Cdc13 associates with telomeres through the cycle and rises in
    late S, so no slot except na and lost should be read as zero.
    """
    if cst == "trimer":
        return "on"
    if cst == "cdc13":
        return "thin"
    return "off" if n_g > n_duplex else "na"


def cap_state_ku(n_duplex, ku=True):
    """MODEL: Ku slot from the junction and whether Ku is drawn (TERMINAL).

    Ku threads onto duplex ends, so its substrate is the junction, which exists
    wherever duplex does.
    """
    if ku:
        return "on"
    return "off" if n_duplex > 0 else "na"


def capbar(n_g, n_duplex, cst=None, ku=True, lost=()):
    """Three-slot cap status, in the same corner of every panel.

    The cap is occupancy of two substrates plus the junction, so it has exactly
    three slots and every panel declares all three. Five states, because
    "absent" is not one thing: on is the element complete on its substrate, thin
    is present and reduced, off is a substrate that exists with nothing
    established on it, na is no substrate to occupy yet, lost is failed.

    The axis is epistemic. A slot reports the highest level of capping the
    evidence establishes at that step, not a molecular count, which is the same
    footing as the labelled arrow with no mark on the target that panel 5 uses
    for the contested Tel1 sites. Biology is leaky and every protein here sits
    in an equilibrium, so a slot reading off is not a claim that nothing is
    bound. Panel 9's caption carries that sentence once for the whole figure.

    The states are derived, not declared. Four of them come from the drawing:
    the duplex repeat count, whether an overhang exists, and what is drawn on
    it. animate.js recomputes them per frame in paintDerived, so a panel whose
    telomere changes under it reports the change. What is computed here is the
    resting state, which is what a static panel keeps and what the rasteriser
    resolves, and tools/test_engine.js asserts the two agree at frame 0.

    lost is the exception and stays declared, because absence of a glyph is not
    evidence of loss: Ku missing in branch E looks exactly like Ku never drawn.
    It is also a genotype rather than a rung, so it sits off the ladder, and it
    dominates. A slot named in lost gets a second pill that starts invisible and
    a frame table reveals, and the derivation leaves that slot alone from the
    frame the second pill appears.
    """
    state = {"rap1": cap_state_rap1(n_duplex),
             "cst": cap_state_cst(n_g, n_duplex, cst),
             "ku": cap_state_ku(n_duplex, ku)}
    o = ['<g class="capbar">',
         '<text class="capbarlab" x="600" y="31">cap</text>']
    for n, (key, lab) in enumerate((("rap1", "Rap1"), ("cst", "CST"),
                                    ("ku", "Ku"))):
        x = 616 + n * 84
        st = state[key]
        # The state class rides on the shapes, not on a wrapper, so
        # tools/render_panels.py resolves it too.
        o.append('<g class="capslot">')
        base = ' fx' if key in lost else ''
        o.append('<rect class="capslotbox %s%s" id="capbase-%s" x="%d" y="16" '
                 'width="78" height="21" rx="10"/>' % (st, base, key, x))
        o.append('<text class="capslotlab %s%s" id="capbaselab-%s" x="%d" y="31">%s</text>'
                 % (st, base, key, x + 39, lab))
        # The word carries the state and the pill carries the element, so the
        # colour stops being the only channel the state is in and no legend is
        # needed to read a panel.
        o.append('<text class="capslotst %s%s" id="capbasest-%s" x="%d" y="11">%s</text>'
                 % (st, base, key, x + 39, CAP_WORDS[key][st]))
        if key in lost:
            o.append('<rect class="capslotbox lost fx pending" id="capflip-%s" x="%d" '
                     'y="16" width="78" height="21" rx="10"/>' % (key, x))
            o.append('<text class="capslotlab lost fx pending" id="capfliplab-%s" '
                     'x="%d" y="31">%s</text>' % (key, x + 39, lab))
            o.append('<text class="capslotst lost fx pending" id="capflipst-%s" '
                     'x="%d" y="11">%s</text>'
                     % (key, x + 39, CAP_WORDS[key]["lost"]))
        o.append("</g>")
    o.append("</g>")
    return "\n".join(o)


def fx(ident, body, pending=True):
    """Wrap anything a frame table turns on or off.

    Invisible at rest by default, which is the common case: most staged content
    arrives. pending=False is for content that is on the page at frame 0 and
    leaves, which panel 5 needs for Cdk1: the kinase acts on the first frame and
    is gone by the last, so it cannot start hidden.
    """
    cls = "fx pending" if pending else "fx"
    return '<g class="%s" id="%s">%s</g>' % (cls, ident, body)


def camera(body):
    """The view frame, as an actor.

    Everything anchored to the DNA goes inside: the chunks, the zone tints, the
    region band, the proteins bound to the strands, the nucleases that travel
    with them, and any bracket naming a span of sequence. A frame table then
    translates the whole group, and the content off the left edge comes into
    view rather than the drawing having to grow leftward.

    Panel furniture stays outside. The cap indicator, the free notes and the
    checkpoint chain are statements about the panel rather than features of the
    molecule, so they must not slide.

    No engine support is needed for the movement itself: the id prefix already
    puts it in paintActors' reach, [id^="actor-"] already carries the transform
    transition, and that rule is already inside the reduced-motion block.
    Nested actors compose, so Exo1 keeps its own offset inside a moving frame.
    """
    return '<g id="actor-camera">%s</g>' % body


def condition_strip(label, ident="fx-condition"):
    """A band naming the condition the frames under it are run at.

    Every other panel is one condition throughout, so nothing in the vocabulary
    said "and now a different experiment". Branch E needs that: its last frames
    are the restrictive temperature, not the end of the steady state that
    precedes them, and without a marker they read as the same run continuing.

    Sits between the genotype label and the cap indicator, which occupy the two
    corners of the same row: the label runs from x 12 and the indicator from
    x 600. The strip used to start at x 30, which is where the label is now, and
    both panels that carry a strip also carry a genotype. Starting at 210 clears
    the longest label either of them has with room over.
    """
    return ('<g class="fx pending" id="%s">'
            '<rect class="condstrip" x="210" y="8" width="330" height="22" rx="4"/>'
            '<text class="condlab" x="375" y="23">%s</text>'
            "</g>" % (ident, label))


def cap_element(body, goto, label):
    """One element of the cap, in the panel where the cap is the subject.

    Glows, and opens the branch where it is lost. tabindex and role are here so
    the mutate affordance is reachable without a mouse, the same way the nav
    nodes are.
    """
    return ('<g class="capglow" data-goto="%s" tabindex="0" role="button" '
            'aria-label="%s">%s</g>' % (goto, label, body))


def defs(key):
    """Per-panel defs. Marker ids must be unique because every panel is inlined
    into one document, and a repeated id makes every reference resolve to the
    first match."""
    return ('<defs><marker id="%s-arrow" viewBox="0 0 10 10" refX="9" refY="5" '
            'markerWidth="7" markerHeight="7" orient="auto-start-reverse">'
            '<path d="M0,1 L9,5 L0,9 z" class="arrowhead"/></marker></defs>' % key)


def panel(key, body):
    body = body.replace("url(#p-arrow)", "url(#%s-arrow)" % key)
    return ('<svg class="panelsvg" viewBox="0 0 %d %d" '
            'preserveAspectRatio="xMidYMid meet" xmlns="http://www.w3.org/2000/svg">\n'
            "%s\n%s\n</svg>\n" % (VB_W, VB_H, defs(key), body))


RAP1_PAIRS = [1, 3, 5, 7, 9]
# Okazaki priming sites in panel 1*, distal edge of each fragment, in the order
# the fork reaches them. Four three-repeat fragments and a terminal two-repeat
# one: the last primer sits on chunk 14 and its fragment reaches back to 13, so
# removing it leaves the C-strand ending at 13 and chunk 14 bare. That is the
# overhang, and it is also exactly the state panel 3* opens on.
LAG_PRIMERS = [3, 6, 9, 12, 14]
CAP_PAIRS = RAP1_PAIRS + [11, 13, 15]   # the full array on a capped telomere
# Branch B's array. Panel 5 draws boxes over chunks 1 to 6 and puts MRX at
# chunk 9, so the array stops four repeats short of the complex and the duplex
# under MRX is bare. Branch B is that panel with four more repeats, so it holds
# the same relationship: boxes over chunks 1 to 10, MRX at chunk 13. Pairs at 11
# and 13 would be drawn through Rad50 and the socket, and a Rif2 circle sitting
# on top of the socket it is competing for is the one thing this panel cannot
# afford to draw ambiguously. That makes the list identical to RAP1_PAIRS and
# the name is kept because the two are equal by coincidence of layout and not
# by intent: panel 5 draws RAP1_PAIRS[:3].
LONG_PAIRS = list(RAP1_PAIRS)
# and the overhang repeats its RPA holds. Panel 5 uses 13 and 14 because the
# Cdc13 wedge covers 11 and 12; the same two repeats out from the wedge here are
# 17 and 18.
LONG_OVERHANG = (17, 18)

# ------------------------------------------------------------------ panels --
def p_step01(key="step01"):
    """Leading-strand synthesis, ending blunt.

    Starts with the parental C-strand alone. The G-strand is the new strand and
    arrives left to right as the fork runs out to the terminus, so the panel is
    an animation of one half of the end-replication problem rather than a
    picture of its product.

    Rap1 and Ku need no frame-table entries. paintDerived hides a Rap1 box until
    both its repeats are duplex and puts Ku flush against the last duplex one,
    so the array populates and the junction advances as a consequence of the
    DNA rather than as a second declaration that could disagree with it. Ku and
    MRX are wrapped in fx and revealed only on the last frame: derived from
    visibility alone, Ku would ride the fork, and a Ku glyph travelling with a
    replisome says something about loading that is not true.
    """
    b = [chunks(0, N_START, N_START),
         rap1_array(RAP1_PAIRS),
         # Ku threads onto a duplex end. There is no such end until the last
         # frame, so the glyph waits for one.
         fx("fx-ku01", ku(N_START)),
         # MRX binds the end for the same reason, and faintly: at full length
         # the Rif2 load is maximal, so residence here is brief.
         fx("fx-mrx01", mrx(MRX_X, seated=True, faint=True)),
         replisome(cx(1)),
         # Zero and zero, because this panel builds its DNA from nothing: every
         # chunk is pending at rest and the frames lay them down. What capbar
         # computes is the resting picture, which here is an empty stage, and
         # the engine derives the rest as the strands arrive.
         capbar(0, 0),
         fx("fx-blunt01", terminus_label(end_x(N_START) - 40, "blunt terminus")),
         '<text class="notelab" x="%d" y="68">Rif2 load maximal &#8594; MRX residence brief</text>'
         % (end_x(N_START) - 150),
         '<text class="notelab" x="320" y="50">the fork arrives from a subtelomeric '
         'origin: no primer is laid at the telomere on this strand</text>',
         '<text class="notelab" x="300" y="284">new G-strand runs to the terminus, '
         'so the daughter end is blunt and carries no overhang</text>',
         fx("fx-bracket01",
            bracket(cx(1), end_x(N_START), 190,
                    "duplex TG1-3 array, Rap1 ~1 per 18 bp"))]
    return panel(key, "\n".join(b))


def p_lag01(key="lag01"):
    """Lagging-strand synthesis, ending with a 3' overhang.

    The mirror of panel 1 and the other half of the same replication event.
    Starts with the parental G-strand alone, which is the template here. The
    C-strand arrives as five Okazaki fragments, each primed at its distal edge
    and extended leftward until it meets the one before it, so priming sites
    march toward the terminus while synthesis runs the other way.

    Each fragment is begun by Pol alpha, which lays the RNA primer and a short
    stretch of DNA, and finished by Pol delta after the RFC/PCNA switch. The
    distal fragment carries both arrows; the shorter one is the alpha-segment.

    The asymmetry this panel turns on is a substrate asymmetry, not an enzyme
    asymmetry. Internal primers are displaced into flaps by the polymerase
    arriving from the distal side, Rad27 cleaves them, and Cdc9 seals the
    nicks. The terminal primer has nothing distal to it, so it never becomes a
    flap and nothing extends into the gap it leaves behind. That gap is the
    overhang, and where the last primer landed is what sets how much of the
    parental strand goes uncopied. Which activity removes that terminal primer
    is not established in S. cerevisiae, so the panel shows the removal and
    leaves the agent unnamed.

    Rad27 is drawn without a claim of sufficiency. Budd and Campbell (2013)
    report that FEN1 alone does not account for lagging-strand maturation at
    telomeres and that Dna2 or Exo1 supplements it there. Those two appear as
    glyphs in lag03 rather than here, so the point is carried by a note.

    Pol delta is wrapped twice, and both wrappers are load-bearing. The fx
    group is what a frame table turns on, so the second arrow does not exist
    until the alpha-segment is finished. The actor group inside it is what
    carries the offset, because the handoff happens once per fragment and the
    two arrows have to move together; drawn at a fixed coordinate the delta
    arrow would line up with Pol alpha on the first fragment and sit further
    behind it on each one after that. Nested actors compose, so actor-lagpold
    takes the same offsets as actor-lagpol and the suite asserts they match
    frame by frame.

    The terminal fragment is two repeats rather than three. Its primer sits on
    chunk 14 and the fragment reaches back to 13; when the primer goes, the
    C-strand ends at 13 and chunk 14 is bare, which is the state panel 3*
    opens on.
    """
    b = [chunks(N_START, 0, N_START),
         rap1_array(RAP1_PAIRS),
         fx("fx-ku-lag", ku(N_START - 1)),
         # One per fragment, at the distal edge of the fragment it primes.
         "\n".join(primer(i, ident="pr-%s" % chunk_id(i))
                    for i in LAG_PRIMERS),
         # Pol alpha now covers the alpha-segment only: the RNA primer plus a
         # short DNA stretch, roughly one chunk in from the distal edge. It
         # points the same way panel 8 points it, because it is the same
         # enzyme starting the same kind of fragment.
         pol_alpha(end_x(LAG_PRIMERS[0]), 196, cx(LAG_PRIMERS[0] - 1),
                   ident="actor-lagpol"),
         # Pol delta picks the fragment up where Pol alpha stops and carries it
         # to the inner edge, which is where the single arrow used to end.
         # The label is the enzyme name only. The arrow is 76 wide and sits at
         # the left edge of the panel on the first fragment, so a phrase
         # centred on it runs off the frame, and one long enough to say what
         # the switch is would sit over Pol alpha's own shaft and read as
         # labelling that instead. What the handoff is happens in the caption.
         fx("fx-poldelta",
            '<g id="actor-lagpold">'
            + arrow(cx(LAG_PRIMERS[0] - 1), 196,
                    cx(LAG_PRIMERS[0] - 2) - 34, 196,
                    "Pol &#948;", labelside="above")
            + '</g>'),
         capbar(N_START, 0),
         # These three arrows are vertical, so labelrot would set the text on
         # its side and the default would run it across the line. labelside
         # keeps it horizontal and clear of both. Rad27 and Cdc9 put theirs to
         # the right, in the gap between one protein box and the next.
         fx("fx-rad27", protein(130, 252, 84, "Rad27", "rad27") +
                        arrow(152, 250, 152, 190, "Primers removed",
                              labelt=0.45, labelside="right")),
         fx("fx-cdc9", protein(340, 252, 76, "Cdc9", "cdc9") +
                       arrow(378, 250, 378, 190, "nicks sealed",
                             labelt=0.45, labelside="right")),
         # No protein glyph: the activity that removes the terminal primer is
         # not established in yeast, so the event is shown and the agent is
         # not named. The arrow keeps its original position and timing.
         # This one comes in from the right of the terminus rather than
         # straight up at it. The bracket naming the tail occupies chunk 14,
         # and a vertical arrow there runs through its label. Approaching from
         # the empty space past the end also puts the arrowhead on the side the
         # missing 3' end would have been.
         #
         # Its label sits below the arrow, on the row the other two clearing
         # steps put a protein box on. That makes the absent box the thing a
         # reader notices, which is the claim: the removal is drawn and the
         # agent is not named.
         fx("fx-termprimer",
            arrow(724, 250, 652, 196,
                  "terminal primer removed, no 3&#8242; end to fill behind it",
                  labelside="below")),
         fx("fx-lagtail",
            bracket(cx(N_START), end_x(N_START), 200, "3&#8242; overhang, unfilled")),
         '<text class="notelab" x="250" y="45">each fragment is primed distally '
         'and extended leftward until it meets the one before it</text>',
         # Both notes share the bottom row. VB_H is 300, so anything below that
         # is outside the panel and simply does not render.
         '<text class="notelab" x="620" y="292">no incision and no MRX arm needed '
         'here; this end already has a recessed 5&#8242; terminus</text>']
    return panel(key, "\n".join(b))


def p_step02(key="step02"):
    b = [chunks(N_START, N_START),
         rap1_array(RAP1_PAIRS),
         ku(N_START),
         mrx(MRX_X, seated=True),
         capbar(N_START, N_START),
         protein(60, 30, 74, "Cdk1", "cdk1", ident="actor-cdk1"),
         protein(214, 30, 84, "Sae2", "sae2", ident="actor-sae2", phos=True),
         '<text class="notelab" x="256" y="22">S267</text>',
         arrow(138, 43, 210, 43, "phosphorylates"),
         arrow(300, 52, MRX_X - 26, MID - 16, "activates", curve=34),
         # The cut itself. Drawn after MRX so the complex does not cover it.
         nick(NICK_CHUNK, flashing=True),
         '<text class="notelab" x="300" y="222">Sae2-P is a cofactor here, '
         'not the nuclease</text>',
         terminus_label(MRX_X + 14, "incision, internal to the end")]
    return panel(key, "\n".join(b))


def p_step03(key="step03"):
    # Ku is emitted before MRX, so MRX paints over it. Ku threads onto the
    # duplex end and Mre11 sits on the DNA at the same place; drawing Ku on top
    # put the ring in front of the nuclease that is cutting under it.
    b = [chunks(N_START, N_START),
         rap1_array(RAP1_PAIRS),
         ku(N_START),
         mrx(MRX_X, seated=True),
         # Addressable, so it goes when MRX goes. Once the 5' end has been
         # carried past the incision there is no discontinuity there to draw.
         nick(NICK_CHUNK, ident="fx-nick03"),
         # Both slots that move in this panel move on their own. Frame 0 is a
         # blunt end, so CST reads na and the array is complete; by the last
         # frame there is an overhang with nothing established on it and four
         # fewer duplex repeats under the array. Neither is declared here or in
         # the frame table.
         capbar(N_START, N_START),
         # RPA is deposited, not parked. Each unit starts invisible and the
         # frame table turns it on as its own C-strand half goes, so the panel
         # is true at frame 0 (no ssDNA, no RPA) and at the last frame.
         "\n".join(rpa_unit(i, ident="rpa-c%02d" % i, pending=True)
                   for i in RPA_CHUNKS),
         # Both nucleases sit below the duplex so they stay clear of the Xrs2
         # pole, and both travel left, with the chunks they are removing. They
         # start one chunk right of where they used to, so the box sits under
         # the repeat it is clearing rather than one ahead of it. No direction
         # tick: the frames carry the direction, and a static arrow beside a
         # moving box says the same thing twice.
         nuclease(562, 198, "Exo1", "actor-exo1", "left", show_arrow=False),
         nuclease(562, 236, "Sgs1-Dna2", "actor-sgs1", "left", show_arrow=False),
         '<text class="notelab" x="716" y="96">Mre11: 3&#8242; &#8594; 5&#8242;, '
         'toward the end</text>',
         '<text class="notelab" x="250" y="284">Exo1 and Sgs1-Dna2: '
         '5&#8242; &#8594; 3&#8242; on the C-strand, travelling inward</text>',
         '<text class="notelab" x="440" y="70">RPA coats the strand until Cdc13 '
         'takes it in panel 4: no CST here, and none needed yet</text>']
    return panel(key, "\n".join(b))


def p_lag03(key="lag03"):
    """Unidirectional resection, on the lagging-strand end.

    The same reaction as panel 3 on a different substrate. Panel 3 spends an
    incision and an Mre11 3' to 5' arm to convert a blunt end into one with a
    recessed 5' terminus. This end already has one, so neither is drawn and the
    panel is the inward arm alone: Exo1 and Sgs1-Dna2 on the 5' end, running
    toward the centromere, with RPA landing behind them.

    MRX is here with no nick beside it, which is the only place in the figure
    that claim can be shown rather than asserted. MRX promotes Exo1 and
    Sgs1-Dna2 resection by facilitating their recruitment to the end, and that
    contribution is independent of Mre11 nuclease activity: Exo1 and Dna2
    binding at a break is close to unchanged in nuclease-dead mre11. The
    complex fades as the front passes it for the same reason it fades in panel
    3. Its loading contribution is made at the end and made once, and nothing
    it does is processive.

    Ends with the C-strand at chunk 10, which is where panel 3 ends, so the two
    branches converge on panel 4 rather than near it.
    """
    b = [chunks(N_START, N_START - 1),
         rap1_array(RAP1_PAIRS),
         ku(N_START - 1),
         mrx(MRX_X, seated=True),
         # This end already carries a bare chunk 14 at frame 0, so CST opens off
         # where panel 3 opens na. The two converge, which is what panel 4 takes
         # over from.
         capbar(N_START, N_START - 1),
         "\n".join(rpa_unit(i, ident="rpa-c%02d" % i, pending=True)
                   for i in LAG_RPA_CHUNKS),
         # Same stacking and the same height relative to the duplex as panel 3,
         # because it is the same pair doing the same thing. They start one
         # chunk left of panel 3's pair, since the 5' end they load on is at
         # the edge of chunk 13 rather than at the terminus.
         nuclease(520, 198, "Exo1", "actor-exo1", "left", show_arrow=False),
         nuclease(520, 236, "Sgs1-Dna2", "actor-sgs1", "left", show_arrow=False),
         '<text class="notelab" x="250" y="284">Exo1 and Sgs1-Dna2: '
         '5&#8242; &#8594; 3&#8242; on the C-strand, travelling inward</text>',
         '<text class="notelab" x="300" y="44">no incision here: the 5&#8242; end '
         'the nucleases load on was left by primer removal</text>',
         '<text class="notelab" x="300" y="66">MRX loads Exo1 and Sgs1-Dna2 '
         'without cutting, then leaves</text>']
    return panel(key, "\n".join(b))


def p_step04(key="step04"):
    # The C-strand now stops at chunk 10, so MRX_X is out on the overhang.
    # MRX binds duplex ends, so it moves to the junction and mirrors.
    b = [chunks(N_START, N_DUPLEX),
         rap1_array(RAP1_PAIRS[:3]),
         ku(N_DUPLEX),
         mrx(MRX_JUNCTION, seated=True, mirror=True),
         cdc13(478),
         capbar(N_START, N_DUPLEX, cst="cdc13"),
         # RPA holds the rest of the overhang. Only the repeat Cdc13 has taken
         # is handed off, and the faint unit lifting clear is that one. Both
         # proteins bind the same substrate; only Cdc13 reads the sequence, and
         # that is what the exchange is about. It is a handoff of one site, not
         # an eviction from the tail: RPA is required for Est1 to reach the end.
         "\n".join(rpa_unit(i) for i in RPA_OVERHANG),
         rpa_unit(N_DUPLEX + 2, y=TOP_Y - 40, faint=True),
         arrow(540, 134, 530, 118, "handed off"),
         bracket(cx(N_DUPLEX + 1), end_x(N_START), 200, "3&#8242; G-overhang"),
         '<text class="notelab" x="420" y="246">occupancy is the capping event; '
         'Stn1-Ten1 are drawn only at fill-in</text>']
    return panel(key, "\n".join(b))


def p_step05(key="step05"):
    """MRX retained, Tel1 recruited, Cdc13 made Est1-competent.

    Staged in three frames because the panel was carrying four separate events
    at once and reading as a crowd. Nothing about the drawing changes; what
    changes is that the reader gets one claim per beat.

    Frame 1 is Cdk1 phosphorylating T308, and the kinase leaves after it: Cdk1
    acts on Cdc13 wherever Cdc13 is and is not a telomere component, so a box
    parked beside the end for the rest of the panel says it stays. Frame 2 is
    Tel1 taking the docked Xrs2 C-terminus. Frame 3 is what Tel1 then does, both
    of it: the socket it occupies is the socket Rif2 wants, and the end is
    marked for elongation.

    The order of frames 1 and 2 is not evidence. Cdk1 phosphorylation of the
    recruitment domain and Tel1 occupancy at the end are both late S events and
    nothing establishes a dependency in either direction, so the panel says so
    in the corner rather than letting the frame numbers assert it. The caption
    carries the same statement at length.
    """
    # No phosphate. Tel1 acting on Cdc13 through S249/S255 is contested: the
    # serines are required, the phosphorylation is not established, and the
    # cdc13-Q250A/Q256A allele separates the two. So this uses the panel 2
    # idiom for an unresolved mechanism, a labelled arrow with no mark on the
    # target, and keeps the phosphate glyph for sites that are settled.
    #
    # The arrow leaves the Tel1 flag from the side facing Cdc13. MRX now sits
    # left of Cdc13 rather than right of it, so that is the east edge.
    b = [chunks(N_START, N_DUPLEX),
         rap1_array(RAP1_PAIRS[:3]),
         ku(N_DUPLEX),
         mrx(MRX_JUNCTION, seated=True, tel1=True, mirror=True, contested=True,
             staged=True),
         # Two separate events land on Cdc13 in this panel and only one of
         # them is drawn on the protein. Tel1 marks the telomere, with no
         # phosphate, because the route from Tel1 to the Cdc13-Est1 contact is
         # unsettled. Cdk1 phosphorylates T308, with a phosphate, because that
         # site is established and promotes Est1 binding. The mark is deposited
         # by the frame that draws the kinase acting, so frame 1 opens on an
         # unmodified Cdc13 and the phosphate is an outcome instead of a
         # premise.
         cdc13(478, mark="p", mark_ident="fx-t308", mark_pending=True),
         "\n".join(rpa_unit(i) for i in RPA_OVERHANG),
         capbar(N_START, N_DUPLEX, cst="cdc13"),
         # Emitted before the Cdk1 arrow, because the suite reads the first
         # .effect in the panel as the Tel1 arrow.
         #
         # Ends short of the T308 phosphate on the Cdc13 rim. Landing beside
         # that mark is the whole confusion this panel is trying to undo: one
         # arrow would appear to deposit the phosphate the other one names.
         fx("fx-tel1arrow",
            # The label sits level, right of the arrow near its tail, in the
            # clear band above Ku and T308; run along the arrow it crossed Rad50.
            arrow(MRX_JUNCTION, 66, 452, 120, "promotes elongation",
                  labelside="right", labelt=0.25)),
         # And this one ends on Cdc13, with the site named, because that is the
         # target and the site is settled. Kinase and arrow go together: the
         # arrow is the act, not a standing relationship.
         fx("fx-cdk1",
            protein(550, 50, 62, "Cdk1", "cdk1")
            + arrow(550, 65, 510, 120, "phosphorylates T308", labelt=0.6),
            pending=False),
         '<text class="notelab" x="300" y="264">short telomere: fewer Rap1, less Rif2, '
         'so the Xrs2 C-terminus wins the socket and Rif2 is kept out</text>',
         '<text class="notelab" x="300" y="286">T308 is a Cdk1 site and is drawn; '
         'S249 and S255 are the contested Tel1 sites and are not</text>',
         # Bottom right, clear of the two notes above, which end at x 572. The
         # frame numbers are the one thing in this panel that asserts an order
         # nobody has measured, so the disclaimer sits with them rather than in
         # the caption alone.
         '<text class="notelab" x="730" y="274">frames 1 and 2 are drawn in '
         'sequence;</text>',
         '<text class="notelab" x="730" y="290">no evidence establishes that '
         'order</text>']
    return panel(key, "\n".join(b))


def p_step06(key="step06"):
    # MRX and Tel1 stay. Panel 5 argues that a free socket retains MRX and
    # accumulates Tel1, and this is the panel where that has its effect: MRX
    # and Tel1 are both required for normal Est1 and Est2 telomere association.
    # Dropping them here made the licensing complex vanish at the moment it
    # matters. Faint, because they are the reason for the panel and not its
    # subject.
    b = [chunks(N_START, N_DUPLEX, N_MAX),
         rap1_array(RAP1_PAIRS[:3]),
         ku(N_DUPLEX),
         mrx(MRX_JUNCTION, seated=True, tel1=True, faint=True, mirror=True),
         # Cdc13 does not move. It is a recruitment factor, not a processivity
         # factor: the Est1 contact is required to bring the enzyme to an end
         # it would not otherwise find, which is what cdc13-2 shows, and
         # nothing requires it to stay with Est2 once extension is running. It
         # carries the T308 mark that made it Est1-competent and it keeps that
         # mark and that position through the panel.
         cdc13(CDC13_REST, mark="p"),
         # RPA lands behind the enzyme, on repeats telomerase has just made.
         # It is not tracking a vacating Cdc13, because nothing vacates: new
         # single-stranded TG1-3 appears and something binds it. Chunk 18 stays
         # bare because telomerase is still sitting on it, which is why panel 7
         # has to remove the enzyme before CST can occupy the terminus.
         "\n".join(rpa_unit(i) for i in RPA_OVERHANG),
         "\n".join(rpa_unit(i, ident="rpa-c%02d" % i, pending=True)
                   for i in (15, 16, 17)),
         capbar(N_START, N_DUPLEX, cst="cdc13"),
         telomerase(456, 238, shaft=140),
         '<text class="notelab" x="440" y="292">non-processive: a minority of '
         'telomeres is extended per cycle, and the shortest preferentially</text>',
         '<text class="notelab" x="230" y="44">Cdc13-T308 recruits and stays; '
         'telomerase leaves it behind as it extends</text>',
         '<text class="notelab" x="%d" y="112">repeats added</text>'
         % ((cx(N_START + 1) + end_x(N_MAX)) / 2)]
    return panel(key, "\n".join(b))


def p_step07(key="step07"):
    # Cdc13 is where elongation left it, not where elongation started it.
    # Telomerase sits to the right of that, clear of the Est1 wedge, because
    # the contact this panel is about is the one being broken.
    b = [chunks(N_MAX, N_DUPLEX, N_MAX),
         rap1_array(RAP1_PAIRS[:3]),
         ku(N_DUPLEX),
         # Where elongation left it is where elongation started it. The
         # recruiting molecule never travelled, so this panel draws it at
         # CDC13_REST with its T308 mark, on repeats that predate the
         # extension.
         cdc13(CDC13_REST, mark="p"),
         # The extended overhang behind the enzyme, held by RPA. Chunk 18 is
         # under telomerase and is the ground CST takes in panel 8, so
         # removing the enzyme is not only the end of extension, it is what
         # frees the terminus for the capping complex.
         "\n".join(rpa_unit(i, ident="rpa-c%02d" % i) for i in (13, 14, 15, 16, 17)),
         capbar(N_MAX, N_DUPLEX, cst="cdc13"),
         telomerase(725, 238, shaft=110),
         # Two agents, one outcome, different contacts. Pif1 unwinds the
         # TLC1-DNA hybrid; Ipl1 breaks Est1 from TLC1. Neither touches the
         # Cdc13-Est1 bond, which is panel 8's job. No direction tick on Pif1:
         # the removal arrow already carries the direction, and Ipl1 is not
         # translocating at all.
         nuclease(556, 206, "Pif1", "actor-pif1", show_arrow=False),
         nuclease(556, 242, "Ipl1", "actor-ipl1", show_arrow=False),
         arrow(640, 226, 694, 224, "remove"),
         '<text class="notelab" x="330" y="292">Pif1 and Ipl1 take different '
         'contacts; removing the enzyme frees the terminal repeat</text>']
    return panel(key, "\n".join(b))


def p_step08(key="step08"):
    """C-strand fill-in, with the trimer stationary.

    Priming is internal to the terminal Cdc13 footprint. That is the premise
    the rest of the panel rests on, and it is a choice: Chapter 1 has the new
    strand's 5' end joined to the original telomere 5' end, which puts the
    primer at the extreme distal position instead. Internal priming is drawn
    here because it is the only arrangement in which capping is continuous,
    and because it makes the resting tail one Cdc13 footprint rather than a
    coincidence of primer length. If the terminal version is right, there is a
    window each cycle with no single-stranded telomeric DNA anywhere on this
    chromosome end, and claim 9.4 is wrong.

    Consequences, all visible: chunk 18 is never filled, so the reversion that
    used to stand for primer removal is gone; there are two single-stranded
    regions during synthesis, the permanent terminal footprint and the
    shrinking gap ahead of the polymerase; and Ku moves outward on its own,
    since animate.js derives its position from the last duplex repeat and that
    repeat advances as fill-in runs.

    What links the stationary trimer to the advancing polymerase is not drawn,
    because it is not known. Occupancy turnover, protein tethering through the
    Pol1 and Pol12 contacts, and two looping models are all live.
    """
    x = cx(N_MAX)
    b = [chunks(N_MAX, N_DUPLEX, N_MAX),
         rap1_array(RAP1_PAIRS[:3]),
         ku(N_DUPLEX),
         # The capping molecule, on the terminal repeat telomerase vacated in
         # panel 7. K909 SUMOylation strengthens the Stn1 contact and the
         # recruitment domain is unphosphorylated, which is the configuration
         # that assembles the trimer. It is not the molecule that recruited
         # telomerase; that one is still at CDC13_REST wearing T308.
         # The blocked contact rides inside the trimer, at coordinates offset
         # from the wedge corner at cx(N_MAX). The base of the mark sits on
         # the Cdc13 quarter-disc, which is what makes it read as Est1 being
         # excluded from Cdc13 rather than a mark floating beside the complex.
         # The Stn1 phosphate is deposited here rather than drawn, because this
         # is the panel where it happens. Every other panel that draws the
         # trimer has it already on.
         #
         # The exclusion mark is now conditional for the same reason. Cdk1
         # phosphorylates Stn1 at T223 and S250, and the block on the Cdc13-Est1
         # contact follows that; drawing it from frame 0 put the consequence on
         # the page before its cause.
         cst(x, mark="s", stn1_ident="fx-stn1p", stn1_pending=True,
             extra=fx("fx-est1block",
                      ghost(wedge(x - 40, 52, 40, "est1", "Est1")) +
                      inhibit(x + 30, 165, x - 15, 100))),
         # Kinase and arrow together, the panel 5 idiom: the arrow is the act
         # and not a standing relationship, so both leave once it has acted. The
         # sites are on the mark, so the arrow only has to name the target.
         fx("fx-cdk1",
            protein(676, 44, 62, "Cdk1", "cdk1")
            + arrow(716, 70, 816, 104, "phosphorylates Stn1", labelt=0.46)),
         # The recruiter, left behind on repeats the polymerase is about to
         # copy. Its fate is unresolved: it either releases during fill-in or
         # is one of the internal footprints that gets consumed. Drawn faint
         # because the panel cannot say which.
         cdc13(CDC13_REST, ident="actor-cdc13-p", mark="p", faint=True),
         # RPA holds the stretch of overhang that is bare, which is 13 to 17.
         # Chunks 11 and 12 are under the recruiting Cdc13 and chunk 18 is the
         # capping footprint, so neither carries a unit. Panel 7 opens with the
         # same five, which is the handoff.
         "\n".join(rpa_unit(i, ident="rpa-c%02d" % i)
                   for i in (13, 14, 15, 16, 17)),
         capbar(N_MAX, N_DUPLEX, cst="trimer"),
         # Primed at the left edge of chunk 17, immediately internal to the
         # footprint, and running inward from there.
         pol_alpha(end_x(N_REST), 196, cx(N_REST) - 20),
         # The sentence follows the mark. Left unconditional it stated the block
         # in the two frames before the phosphorylation that produces it, which
         # is the same order problem the mark had.
         fx("fx-est1lab",
            '<text class="notelab" x="470" y="96">Stn1-Ten1 block the Cdc13-Est1 '
            'contact</text>'),
         '<text class="fx notelab pending" id="fx-primerlab" x="640" y="122">'
         'primer internal to the footprint</text>',
         '<text class="notelab" x="250" y="60">new C-strand restores Rap1 sites, '
         'and with them the Rif1 / Rif2 load</text>',
         '<text class="notelab" x="300" y="252">CST occupies the terminal footprint; '
         'the polymerase runs inward and Ku follows the new junction</text>']
    return panel(key, "\n".join(b))


def p_step09(key="step09"):
    """The resting state, and the definition of the cap.

    Equals the last frame of panel 8, so the handoff discipline holds. The
    three glowing groups are the cap: Rap1 on the duplex, CST on the residual
    overhang, Ku at the junction. Clicking one opens the branch where it is
    lost.
    """
    # This panel does not use capped_start(), because the three cap elements
    # are individually wrapped in cap_element() for the mutate affordance. It
    # draws the same DNA through the same calls, which is what the zone
    # comparison against C, D, E and A rests on.
    b = [camera("\n".join([
             chunks(N_MAX, N_REST, N_MAX),
             cap_element(rap1_array(CAP_PAIRS), "offD",
                         "Lose the Rap1 array"),
             cap_element(cst(cx(N_MAX), mark="s"), "offC", "Lose CST"),
             cap_element(ku(N_REST), "offE", "Lose Ku"),
             bracket(cx(1), end_x(N_REST), 200, "duplex TG1-3 array"),
             bracket(cx(N_MAX), end_x(N_MAX), 232, "residual 3&#8242; tail")])),
         capbar(N_MAX, N_REST, cst="trimer"),
         '<text class="notelab" x="330" y="52">the cap is these three bound at once, '
         'on the two substrates and the junction between them</text>',
         # affordance: this line is an instruction for the reader of the page,
         # not a statement about the telomere, and it is false on paper. The
         # class marks it so the figure exporter can take it out; anything else
         # that tells a reader to do something gets the same class.
         '<text class="notelab affordance" x="330" y="286">click any glowing element to see what '
         'its loss does</text>']
    return panel(key, "\n".join(b))


def p_offB(key="offB"):
    """The long-telomere counterfactual to panel 5.

    Length is the variable, so length is what has to be on the page. This panel
    used to draw the panel 5 telomere exactly, fourteen repeats with three Rap1
    boxes and three Rif2, and assert the difference in a note. That put the same
    Rif2 load in both panels and left the mechanism, which is occupancy, visible
    nowhere.

    Drawn here with the G-strand at full length and the C-strand recessed by the
    same four repeats panel 5 recesses, so the overhang, the enzymes that made
    it and the state of the cap are the panel 5 state and the array under them
    is longer. Five Rap1 boxes against three, and therefore five Rif2 against
    three, which is the argument. Everything anchored to the junction shifts by
    the four repeats that difference adds.
    """
    b = [chunks(N_MAX, N_START, N_MAX),
         rap1_array(LONG_PAIRS),
         ku(N_START),
         mrx(MRX_JUNCTION_LONG, rif2_socket=True, mirror=True, contested=True),
         # No mark. The claim is about T308, which is the site that would make
         # this Cdc13 Est1-competent, and not about S249 or S255, which the
         # model declines to assert anywhere. Panel 5 draws the phosphate on
         # the same glyph on the same repeat of the overhang, so the difference
         # between the two panels is the length of the array and the one mark
         # that length costs.
         cdc13(478 + LONG_OFFSET),
         "\n".join(rpa_unit(i) for i in LONG_OVERHANG),
         capbar(N_MAX, N_START, cst="cdc13"),
         bracket(cx(N_START + 1), end_x(N_MAX), 200, "3&#8242; G-overhang"),
         # Centred on the viewBox and kept to roughly ninety characters. A
         # notelab is centre-anchored, so a longer string at the old x ran off
         # the left edge of the panel.
         '<text class="notelab" x="440" y="246">long telomere: five Rap1 boxes and '
         'five Rif2 against three in panel 5, so Rif2 wins the socket</text>',
         '<text class="notelab" x="440" y="268">the Xrs2 C-terminus is held out, so no '
         'pole, no Tel1 flag, and no T308 on Cdc13</text>']
    return panel(key, "\n".join(b))


def capped_start(extra="", cst_cls=""):
    """The step 9 telomere, which is where every loss branch begins.

    Each branch draws this at rest and its frame table takes it apart, so
    frame 0 of C, D and E is the same picture as panel 9 and the mutation is
    visibly something that happens to an intact cap rather than a different
    telomere. The suite enforces that by comparing every zone class across the
    four, which is also why the unique block belongs here and not in branch C
    alone: adding it to one panel would break the comparison that makes the
    shared opening mean anything.

    extra is DNA-anchored content the branch adds, and goes inside the camera
    with everything else. Anything that should not slide with the DNA belongs
    in the panel body instead.
    """
    return [camera("\n".join([
        chunks(N_MAX, N_REST, N_MAX),
        rap1_array(CAP_PAIRS),
        cst(cx(N_MAX), mark="s", cls=cst_cls),
        ku(N_REST),
        extra]))]


def p_offC(key="offC"):
    """CST lost. The claim panel 4 makes about occupancy, drawn.

    Rap1 binds duplex, so the array recedes with the C-strand. That is derived
    from chunk visibility rather than declared, which is why the frame table
    only has to remove DNA. RPA fills the exposed strand using the same unit as
    panel 3, and that is what makes the checkpoint drawable: the substrate that
    marks the lost cap is the substrate Ddc2 reads.
    """
    # Everything bound to or travelling with the DNA goes inside the camera:
    # the RPA units, Exo1, and the bracket naming the region that was
    # degraded. The checkpoint chain and the cap indicator do not, because they
    # are statements about the panel rather than features of the molecule.
    dna_fx = "\n".join([
        "\n".join(rpa_unit(i, ident="rpa-%s" % chunk_id(i), pending=True)
                  for i in range(1 - C_UNIQUE_REACHED, 18)),
        # No direction tick. Branch C translates actor-exo1 across ten frames,
        # so the tick was repeating what the motion already says. Panel 3's
        # rule, applied to the panel that had drifted from it.
        fx("fx-exo1", nuclease(660, 240, "Exo1", "actor-exo1", "left",
                               show_arrow=False)),
        # Spans what was actually degraded, from the deepest unique chunk out
        # to the last repeat that kept its C-strand. The old version ran to the
        # terminus and stopped at chunk 7, which asserted a depth the frames
        # never reached and a right-hand edge the camera now carries off-screen.
        fx("fx-bracketC", bracket(cx(1 - C_UNIQUE_REACHED), end_x(6), 236,
                                  "5&#8242; strand degraded past the repeats"))])

    b = capped_start(extra=dna_fx) + [
        capbar(N_MAX, N_REST, cst="trimer", lost=("cst",)),
        allele_label("cdc13-1 at 37 &#176;C (or stn1-13, ten1-31)"),
        fx("fx-mec1", protein(452, 62, 66, "Mec1", "mec1")),
        fx("fx-ddc2", protein(452, 88, 66, "Ddc2", "ddc2") +
                      link(485, 114, 485, 128)),
        fx("fx-rad9", protein(588, 62, 70, "Rad9", "rad9") +
                      arrow(524, 75, 584, 75, "activates")),
        fx("fx-rad53", protein(752, 62, 76, "Rad53", "rad53", phos=True) +
                       arrow(662, 75, 748, 75, "phosphorylates") +
                       '<text class="notelab" x="790" y="110">metaphase arrest</text>'),
        '<text class="notelab" x="330" y="272">no Cdc13 on the overhang, so nothing '
        'stops resection at the array</text>',
        '<text class="notelab" x="330" y="292">the substrate that marks the lost cap '
        'is the substrate that starts the checkpoint</text>']
    return panel(key, "\n".join(b))


def p_offA(key="offA"):
    """No telomerase. The array erodes to nothing and the ends fuse.

    This is not a failure of one of the three cap elements, which is why it
    hangs off elongation and not off panel 9. Nothing is deleted from the cap.
    The substrate the cap is built on runs out, and all three slots follow the
    DNA down on their own: Rap1 to no duplex once the last repeat goes, CST to
    no overhang once both strands read the same last chunk, Ku to wherever the
    junction ends up, which is the unique sequence behind it. That is the whole
    argument for deriving the indicator instead of declaring it, and it is why
    this panel passes no lost argument to capbar(). Telomerase is not a cap
    element, so nothing here is lost in capbar's sense.

    Erosion runs the whole array, chunk 18 to chunk 1, two repeats per frame.
    Stopping partway would leave ten duplex repeats and the Rap1 slot would read
    short array, which is a shorter telomere and not an exhausted one. The claim
    is exhaustion, so the frames have to reach it.

    MRX is drawn as three separate complexes at cx(15), cx(9) and cx(3), each
    appearing and fading as the end passes it, with a gap between. The old
    branch D translated one complex inward across eight frames, which is the
    slide the rest of the model rejects, and at nine erosion frames and 756px of
    travel it would be worse here. Three binding events at successive ends is
    the reading the complex actually supports: it has no translocase and its
    action is local to the end. Nothing carries an offset, so this panel goes in
    the suite's forbidden list instead of holding its exemption.

    The partner is unique sequence for the same reason it was in the old branch
    D, and it is correct here in a way it was not there: in a telomerase null
    many ends reach the threshold together, so a second ligatable end exists.
    It rides the camera, and at full pan it sits at screen 530, which is where
    the old panel drew it.
    """
    px = end_x(0) + A_PARTNER_GAP       # DNA 110, screen 530 at full pan
    partner = ['<g class="partner">']
    # Nine blocks from px reaches DNA 486, which is 906 on screen at full pan
    # and so runs off the right edge. That is the claim: this end is the rest of
    # a chromosome and not a fragment, the same rule the left-hand block follows.
    #
    # The U letters are the second claim: this end has lost its repeats too,
    # which is this panel's own order of events applied to the partner. Erosion
    # is what makes the ends ligatable. Drawn in strand colours with no letters
    # it would read as telomeric repeat DNA being joined to eroded unique
    # sequence, which is not what fuses.
    #
    # No ids. Nothing addresses these individually, the group is already inside
    # fx-partner, and the u-series belongs to the chromosome the camera is on.
    for j in range(9):
        x = px + j * CW
        for y in (TOP_Y, BOT_Y):
            partner.append('<g class="half ustrand">'
                           '<rect class="halfbody" x="%d" y="%d" width="%d" height="%d"/>'
                           '<text class="halflab ulab" x="%d" y="%d">U</text>'
                           "</g>" % (x, y, CW - 2, SH,
                                     x + (CW - 2) // 2, y + SH - 4))
    partner.append('<text class="notelab" x="%d" y="204">second chromosome end, '
                   'repeats already eroded</text>' % (px + 150))
    partner.append("</g>")

    # Everything here is anchored to the DNA, so all of it rides the camera.
    dna_fx = "\n".join([
        # Three complexes, not one moving. Each sits on duplex that still exists
        # when it appears and is at the end by the time it fades.
        fx("fx-mrxA1", mrx(cx(15), seated=True, ident="actor-mrxA1")),
        fx("fx-mrxA2", mrx(cx(9), seated=True, ident="actor-mrxA2")),
        fx("fx-mrxA3", mrx(cx(3), seated=True, ident="actor-mrxA3")),
        fx("fx-partner", "\n".join(partner)),
        # In DNA coordinates, over the gap the ligation closes. At full pan the
        # boxes land at screen 511 and 611, clear of the cap bar at y 16 to 37.
        fx("fx-nhej", protein(91, 60, 92, "Dnl4-Lif1", "lig4") +
                      protein(191, 60, 62, "Nej1", "nej1")),
        # Short and steep, so the label runs along it, and slid off the tail
        # where the Dnl4-Lif1 box would crowd it. The head lands in the gap
        # rather than on either end.
        fx("fx-ligate", arrow(124, 92, 92, 146, "ligates",
                              labelrot=True, labelt=0.35))])

    b = capped_start(extra=dna_fx) + [
        # No lost argument. All three slots derive, and the Rap1 slot falling to
        # no duplex is the claim rather than something to protect against.
        capbar(N_MAX, N_REST, cst="trimer"),
        allele_label("tlc1&#916; (or est2&#916;)"),
        '<text class="notelab" x="330" y="252">no telomerase, so every division '
        'takes repeats off and nothing puts them back</text>',
        '<text class="notelab" x="330" y="278">the cap has lost no element here; '
        'it has run out of the sequence all three bind</text>']
    return panel(key, "\n".join(b))


def p_offD(key="offD"):
    """Rap1 removed from a telomere that keeps its length.

    The counterfactual to offA, and drawn as its opposite so the two cannot be
    read as one picture. There the sequence goes and the proteins follow; here
    the protein goes and the sequence stays. There the partner is unique
    sequence at an exhausted end; here it is a telomere with a full array. Both
    end in a fusion, and the arrays are what tell them apart.

    The terminus does change, and the change is small. The 5' end of the C
    strand moves inward while the 3' terminus holds position, so the single
    strand region grows by D_RECEDE repeats and the molecule's rightmost extent
    never moves. That direction is the whole point. An extending G strand would
    read as telomerase acting with fill-in failing behind it, and this panel's
    phase is resting, which is outside the window telomerase acts in at all.

    Short, and deliberately shorter than branch E's. Fusion junctions retain
    most of the native tract, so the array has to read as full when it fuses;
    that is what separates this panel from branch A at a glance. Branch E takes
    its recession far enough that the Rap1 slot falls with it, which is that
    panel's signal and not this one's.

    Only Rap1 is declared lost, and it is the one slot the drawing cannot
    derive: the duplex the protein sat on is still there, so absence of a box is
    not evidence of anything. CST stays on the overhang, which the recession
    lengthens rather than removes, and Ku stays at the duplex to single strand
    junction, which it finds on its own because the derivation puts it at the
    last duplex chunk.

    Nothing here draws telomerase, Est proteins, Tel1, or Pol alpha. Telomeres
    in these cells do lengthen, but that is a change in how often ends get
    extended, measured across a population over many divisions, and this figure
    follows one telomere through one cycle. It is in the note.

    The camera holds still through all of that and pans left only for the
    fusion, which is the price of two full-length telomeres in an 880 viewBox.
    At full pan the array still shows thirteen repeats.
    """
    lastdup = N_REST - D_RECEDE         # 14: where the duplex now ends
    # The repression statement. NHEJ_SRC_X is the midpoint of the Rap1 box over
    # chunks 7 and 8, which is where the bar leaves the array; the box sits
    # directly above it, in the band between the condition strip and the Sir
    # complex.
    NHEJ_W = 64
    NHEJ_SRC_X = cx(7) + 3 + (2 * CW - 8) // 2
    NHEJ_X, NHEJ_Y = NHEJ_SRC_X - NHEJ_W // 2, 36
    px = end_x(N_MAX) + A_PARTNER_GAP   # DNA 866, and it does not move

    partner = ['<g class="partnertel">']
    # Repeat vocabulary, both strands, no Rap1 boxes. Seven repeats from px reach
    # DNA 1160, which is 908 at full pan and so runs off the right edge, the
    # same rule offA's partner follows even though the sequence is not.
    for j in range(D_PARTNER_REPEATS):
        x = px + j * CW
        for y, cls, lab, letter in ((TOP_Y, "gstrand", "glab", "G"),
                                    (BOT_Y, "cstrand", "clab", "C")):
            partner.append('<g class="half %s">'
                           '<rect class="halfbody" x="%d" y="%d" width="%d" height="%d"/>'
                           '<text class="halflab %s" x="%d" y="%d">%s</text>'
                           "</g>" % (cls, x, y, CW - 2, SH,
                                     lab, x + (CW - 2) // 2, y + SH - 4, letter))
    partner.append('<text class="notelab" x="%d" y="204">second telomere, '
                   'full length, Rap1 also depleted</text>' % (px + 130))
    partner.append("</g>")

    dna_fx = "\n".join([
        # The repression runs off the array itself, not off a second Rap1 drawn
        # for the purpose: the thing holding end joining down is the protein on
        # this molecule, and a duplicate in the corner would let a reader take
        # them for two pools. So the bar is DNA-anchored and lives in the
        # camera, while the NHEJ boxes are furniture and do not, which is the
        # one place in this figure a single mark spans both coordinate systems.
        # They agree because the camera is at 0 for both frames the bar exists,
        # and it would keep agreeing if the pan schedule moved, since the bar is
        # gone six frames before anything pans.
        #
        # It drops onto the Rap1 box over chunks 7 and 8, between that box's two
        # Rif circles. Rif1 and Rif2 sit 48 apart on a 76-wide box, so the
        # midpoint clears both by 15. Any box would do; a middle one says the
        # array rather than an end of it.
        fx("fx-repress",
           inhibit(NHEJ_SRC_X, 108, NHEJ_SRC_X, NHEJ_Y + 30), pending=False),
        # One unit per repeat the C strand vacates, deposited as it goes. Same
        # convention branch E uses over its own recession. Chunk 18 gets none:
        # that repeat was already single-stranded at rest and CST is on it.
        "\n".join(rpa_unit(i, ident="rpa-c%02d" % i, pending=True)
                   for i in range(lastdup + 1, N_MAX)),
        # Behind the junction, on duplex, and mirrored so the Xrs2 pole hangs
        # back over the array instead of through the single strand region. It
        # arrives after the array has gone, so it never sits on a Rap1 box. The
        # fusions require the Mre11 complex along with Ku and Lig4, so MRX
        # belongs on the page. It is stationary: nothing here is resecting on
        # its account, and the panel makes no claim about where it sits at the
        # moment of joining.
        fx("fx-mrxD", mrx(end_x(lastdup) - 80, seated=True, mirror=True)),
        fx("fx-ssbracket",
           bracket(cx(lastdup + 1), end_x(N_MAX), 200,
                   "3&#8242; overhang, C strand receded")),
        fx("fx-partner", "\n".join(partner)),
        # Over the gap between the two telomeres, in DNA coordinates.
        fx("fx-nhej", protein(847, 60, 92, "Dnl4-Lif1", "lig4") +
                      protein(947, 60, 62, "Nej1", "nej1")),
        fx("fx-ligate", arrow(880, 92, 848, 146, "ligates",
                              labelrot=True, labelt=0.35))])

    # CST is muted for the whole panel. It is bound throughout and the caption
    # says so; it is simply not what this panel is about, and at full opacity a
    # three-colour trimer at the terminus pulls the eye away from an array
    # losing its protein. Distinct from faint(), which every other use of
    # reduced opacity in the figure means: faint is transient, a beat where
    # something is on its way off. This is constant across all eleven frames,
    # and the constancy is what says the difference.
    b = capped_start(extra=dna_fx, cst_cls="muted") + [
        capbar(N_MAX, N_REST, cst="trimer", lost=("rap1",)),
        # What Rap1 was doing, stated where the molecule cannot state it. The
        # panel's claim is not that Rap1 left but that end joining was being
        # held off and now is not, and the array going quiet says only the first
        # half of that. The bar that carries the other half is in dna_fx,
        # because it comes off the array.
        repression_target(NHEJ_X, NHEJ_Y, NHEJ_W, "NHEJ",
                          "fx-nhejoff", "fx-nhejon"),
        # The degron is a shift, so this is the second user of the strip. Unlike
        # branch E, the DNA does change after it, which is why the suite's
        # no-change assertion stays scoped to branch E.
        condition_strip("degron induced"),
        allele_label("rap1 degron (or rap1-td)"),
        '<text class="notelab" x="330" y="252">the array keeps every repeat; the '
        'protein goes and the C strand gives ground behind a fixed 3&#8242; end</text>',
        '<text class="notelab" x="330" y="278">fusion here needs Ku, which is '
        'the element branch E removes</text>']
    return panel(key, "\n".join(b))


def p_offE(key="offE"):
    """Ku lost. Partial uncapping rather than acute.

    The tail grows inward while CST stays at the terminus, because Cdc13 binds
    the 3' end and the single-stranded region extends behind it. That is the
    phenotype: without Ku restraining resection the tail is long through the
    whole cycle, not only in late S. CST still occupies the end, so the checkpoint
    arm of branch C does not fire here.

    The nuclease pair and its motion are panel 3's, reused. Exo1 is the enzyme
    the yku70 suppression data names, and Sgs1-Dna2 is drawn beside it because
    the panel is showing the same 5' to 3' activity, not because the two are
    claimed to be derepressed to the same extent. The caption says resection
    rather than Exo1 for that reason.
    """
    dna_fx = "\n".join([
        # The tail that grows here is single-stranded DNA, and single-stranded
        # DNA is not bare. RPA follows Exo1 inward using the same unit as panels
        # 3 and C. Drawing it does not blur E into C: RPA is on the strand in
        # both, and what separates them is that C has no CST at the terminus and
        # runs past the repeats into unique sequence. That is the panel 4 claim
        # reapplied, that only the sequence-specific occupancy is capping.
        "\n".join(rpa_unit(i, ident="rpa-c%02d" % i, pending=True)
                  for i in range(9, 18)),
        # The same activity as panel 3, not a second version of it: both
        # nucleases, stacked the same way and travelling in lockstep. The box is
        # 76 wide, so x = 688 puts its right edge on the right edge of chunk 17,
        # which is where the C-strand ends at rest. Panel 3 uses the same
        # relationship at its own terminus. No direction tick on either: the
        # frames carry the direction, and a static arrow beside a moving box
        # says it twice. What does not carry over from panel 3 is Mre11 running
        # the other way. MRX has left by the resting state, so this is the
        # inward 5' to 3' arm only.
        #
        # The rows are 180 and 212 rather than panel 3's 198 and 236, and this
        # is the one panel where the absolute heights do not match. The pair
        # travels 390 to the left here, so the lower box sweeps the full width
        # of the panel at whatever row it sits on, and at 236 it occupied y 236
        # to 260 across the whole frame. That is the row the note block needs,
        # and no horizontal position clears a box that crosses the panel. So the
        # stack moved up by 18 and the relationship to the duplex is what gave.
        # Exo1 still sits below the C-strand and the pair is still stacked in
        # the panel 3 order at the panel 3 spacing.
        fx("fx-exo1", nuclease(688, 180, "Exo1", "actor-exo1", "left",
                               show_arrow=False)),
        fx("fx-sgs1", nuclease(688, 212, "Sgs1-Dna2", "actor-sgs1", "left",
                               show_arrow=False))])

    b = capped_start(extra=dna_fx) + [
        capbar(N_MAX, N_REST, cst="trimer", lost=("ku",)),
        allele_label("yku70&#916; (or yku80&#916;)"),
        # The same four glyphs branch C uses, at the same coordinates, because
        # this is the same chain reading the same substrate. What differs is
        # the condition it takes to get there, which is why the strip exists.
        condition_strip("shifted to 37 &#176;C"),
        fx("fx-mec1", protein(452, 62, 66, "Mec1", "mec1")),
        fx("fx-ddc2", protein(452, 88, 66, "Ddc2", "ddc2") +
                      link(485, 114, 485, 128)),
        fx("fx-rad9", protein(588, 62, 70, "Rad9", "rad9") +
                      arrow(524, 75, 584, 75, "activates")),
        # Not at branch C's y 110. CST is still on the terminus here, and its
        # K909 mark sits at exactly that x and y; branch C has the space
        # because it has lost the trimer by this frame.
        fx("fx-rad53", protein(752, 62, 76, "Rad53", "rad53", phos=True) +
                       arrow(662, 75, 748, 75, "phosphorylates") +
                       '<text class="notelab" x="790" y="54">arrest</text>'),
        # All three notes are one block at the foot of the panel. This line was
        # at y 46, which kept it clear of the checkpoint chain at y 62 to 114 but
        # put the panel's plainest statement as far from the other two as the
        # frame allows. It reads as part of the same argument, so it sits with
        # them. The row it needs is the one the Sgs1-Dna2 box used to sweep,
        # which is why that pair moved up.
        '<text class="notelab" x="330" y="252">no Ku at the junction, so resection '
        'is not restrained and the tail is long outside late S as well</text>',
        '<text class="notelab" x="330" y="270">telomeres are also shorter, and TLC1 '
        'leaves the nucleus</text>',
        '<text class="notelab" x="330" y="292">CST still occupies the overhang at either '
        'temperature; what changes is whether the tail crosses the threshold</text>']
    return panel(key, "\n".join(b))

def p_figstructure(key="figstructure"):
    """A map of the telomeric region, in the vocabulary of every other figure.

    Reference panel: excluded from KEYS, META and the nav, so the animation
    never shows it and the every-panel rules never apply. It is exported by
    tools/make_figures.py alone.

    Nothing here is to scale, and nothing in the rest of the figure ever was.
    A block is an abstraction of a stretch of one strand, not a repeat and not a
    fixed number of bases, so the subtelomeric region and the repeat tract are
    drawn at whatever width makes them readable. Lengths that matter are stated
    in the brackets, where a reader can see they are being told rather than
    invited to measure.

    Left to right: unique sequence running off the edge, the subtelomeric region
    with its chromatin and the last origin, the repeat tract with Rap1 and no
    nucleosomes, and the 3' overhang with Cdc13 on it. The nucleosome-free tract
    against the nucleosomal subtelomere is the one mechanistic claim the panel
    makes; everything else is layout.
    """
    UBLK = [-20, 22, 64, 106]
    SUB0, SUB1 = 176, 440
    TRACT0, NT = 470, 6
    NUC_X = [216, 282, 348, 414]

    o = []

    # === UNIQUE SEQUENCE ===
    # Same blocks and the same U as every panel, running off the left edge to
    # say the region has only one end.
    for x in UBLK:
        for y, lab in ((TOP_Y, "U"), (BOT_Y, "U")):
            o.append('<g class="half ustrand">'
                     '<rect class="halfbody" x="%d" y="%d" width="%d" height="%d"/>'
                     '<text class="halflab ulab" x="%d" y="%d">%s</text></g>'
                     % (x, y, CW - 2, SH, x + (CW - 2) // 2, y + SH - 4, lab))

    # === SUBTELOMERIC REGION ===
    o.append(ribbon_taper(UBLK[-1] + CW - 2, SUB0))
    edges = [SUB0] + [v for x in NUC_X for v in (x - NUC_OUT, x + NUC_OUT)] + [SUB1]
    for a, b in zip(edges[0::2], edges[1::2]):
        o.append(ribbon(a, b))
    for x in NUC_X:
        o.append(nucleosome(x))
    o.append(ars_mark(NUC_X[1] + 26, 92))
    o.append(ribbon_taper(SUB1, TRACT0, opening=True))

    # === DUPLEX REPEAT TRACT ===
    for i in range(NT):
        x = TRACT0 + i * CW
        for y, cls, lab, letter in ((TOP_Y, "gstrand", "glab", "G"),
                                    (BOT_Y, "cstrand", "clab", "C")):
            o.append('<g class="half %s">'
                     '<rect class="halfbody" x="%d" y="%d" width="%d" height="%d"/>'
                     '<text class="halflab %s" x="%d" y="%d">%s</text></g>'
                     % (cls, x, y, CW - 2, SH, lab,
                        x + (CW - 2) // 2, y + SH - 4, letter))
    # Rap1 along the tract. No Rif sockets and no Sir complex: this panel is
    # about what the region is, and those are about what regulates it.
    for i in range(0, NT - 1, 2):
        x = TRACT0 + i * CW
        o.append('<rect class="rap1box" x="%d" y="108" width="%d" height="24" '
                 'rx="5"/>' % (x + 3, 2 * CW - 8))
        o.append('<text class="glyphlab" x="%d" y="125">Rap1</text>' % (x + CW - 1))

    # === TERMINUS ===
    ohx = TRACT0 + NT * CW
    o.append('<g class="half gstrand">'
             '<rect class="halfbody" x="%d" y="%d" width="%d" height="%d"/>'
             '<text class="halflab glab" x="%d" y="%d">G</text></g>'
             % (ohx, TOP_Y, CW - 2, SH, ohx + (CW - 2) // 2, TOP_Y + SH - 4))
    # Under the overhang, the way panel 9 seats it, so the wedge reads as bound
    # to the single strand above it rather than parked beside the molecule.
    o.append(cdc13(ohx))
    # Declared, not derived. There is no frame table here to derive them from,
    # and nothing on this panel changes, so there is no state to disagree with.
    o.append('<text class="endlab" x="%d" y="%d">3&#8242;</text>'
             % (ohx + CW + 4, TOP_Y + 4))
    o.append('<text class="endlab" x="%d" y="%d">5&#8242;</text>'
             % (ohx - 4, BOT_Y + SH + 13))

    # === NAMES ===
    o.append(bracket(SUB0, SUB1, 208, "subtelomeric region, nucleosomal"))
    o.append(bracket(TRACT0, ohx, 208,
                     "duplex TG1-3 tract, 275 to 375 bp, no nucleosomes"))
    o.append(bracket(ohx, ohx + CW - 2, 246,
                     "3&#8242; overhang, 12 to 14 nt"))
    o.append('<text class="notelab" x="440" y="286">not to scale; block widths '
             'are an abstraction, as they are in every panel</text>')
    return panel(key, "\n".join(o))


PANEL_FNS = {
    "step01": p_step01, "lag01": p_lag01,
    "step02": p_step02, "step03": p_step03, "lag03": p_lag03,
    "step04": p_step04,
    "step05": p_step05, "step06": p_step06, "step07": p_step07, "step08": p_step08,
    "step09": p_step09,
    "offA": p_offA, "offB": p_offB, "offC": p_offC,
    # Reference panel: written to src/panels/ for the figure
    # exporter, and deliberately absent from KEYS and META.
    "figstructure": p_figstructure,
    "offD": p_offD, "offE": p_offE,
}

# --------------------------------------------------------------------- nav --
# Three columns. The leading-strand route and the shared tail run down the
# left, the lagging-strand route runs beside it for as long as it is a separate
# route, and conditional branches sit on the right.
#
# The split at the top is not a decision. D1 used to ask "Cdk1 active?", which
# is a condition the cell is either in or not, and the answer sends you one way
# or the other. Leading and lagging are not alternatives: one fork passage
# produces both, on the same chromosome, at the same time. A diamond would
# assert an exclusivity that is not there, so this is a bar with two live arms.
COL_LEAD, COL_LAG, COL_OFF = 40, 226, 414
NODE_W, OFF_W = 160, 164
MID_LEAD, MID_LAG, MID_OFF = 120, 306, 496
# The gutter between the offshoot column's right edge at 578 and the
# cell-cycle band at 598. Branch B's rejoin edge drops down here, because
# the column itself is now occupied at that height.
REJOIN_X = 588

NAV_NODES = [
    ("step01", 80, "1", ["Leading synthesis:", "blunt terminus"]),
    ("step02", 176, "2", ["Sae2-P activates", "Mre11 endonuclease"]),
    ("step03", 272, "3", ["Bidirectional", "resection"]),
    ("step04", 396, "4", ["Cdc13 alone loads", "on the overhang"]),
    ("step05", 600, "5", ["MRX retained; Tel1", "phosphorylates Cdc13"]),
    ("step06", 696, "6", ["Est1 bridges TLC1;", "Est2 copies template"]),
    ("step07", 806, "7", ["Pif1 and Ipl1", "remove telomerase"]),
    ("step08", 902, "8", ["Stn1-Ten1 join;", "Pol alpha-primase fills in"]),
    ("step09", 998, "9", ["Capped: Rap1, CST,", "Ku all bound"]),
]

# The parallel track. Two nodes, not three, and the gap where 2 would be is the
# claim: this end needs no incision, because primer removal already left it a
# recessed 5' terminus.
NAV_LAG = [
    ("lag01", 80, "1*", ["Lagging synthesis:", "3-prime overhang"]),
    ("lag03", 272, "3*", ["Unidirectional", "resection"]),
]

NAV_OFFSHOOTS = [
    # offA hangs off elongation, not off panel 9. It is not a failure of one of
    # the three cap elements; it is the pathway's own counterfactual, the end
    # that never got extended. Hung off 9 with the other three it would read as
    # a fourth cap element.
    ("offA", 696, "A", ["No telomerase: repeats", "erode, ends fuse"]),
    ("offB", 492, "B", ["Long telomere: Rif2", "takes the socket"]),
    ("offC", 998, "C", ["CST lost: resection,", "checkpoint, arrest"]),
    # Not "array lost": the array keeps every repeat and the protein is what
    # goes, and there is no over-elongation in the panel any more.
    ("offD", 1060, "D", ["Rap1 depleted:", "fusion at full length"]),
    ("offE", 1122, "E", ["Ku lost: long tails,", "short telomeres"]),
]

# Two bands cover the split region rather than one. Resection is drawn in blue
# everywhere in this figure, and the blunt-end route is what that blue names;
# the lagging route is a different substrate reaching the same place, so it
# gets its own ground rather than borrowing the leading route's.
NAV_BANDS = [("resection", 24, 40, 190, 330),
             ("lagging", 222, 40, 190, 330),
             ("processing", 24, 376, 554, 200),
             ("elongation", 24, 584, 554, 196),
             ("fillin", 24, 788, 554, 186),
             ("resting", 24, 982, 554, 210)]

# The split region's two bands sit side by side, so their names go inside them
# horizontally. Everything below the merge is one column wide and keeps the
# rotated label in the left margin.
BAND_HEADERS = [(MID_LEAD, 60, "Leading strand"),
                (MID_LAG, 60, "Lagging strand")]
BAND_LABELS = [("END PROCESSING", 476), ("G-STRAND ELONGATION", 682),
               ("C-STRAND FILL-IN", 881), ("CAPPED", 1087)]

# The cell-cycle column. Replication and everything from incision to extension
# sit inside one window, which equal-width nodes actively hide.
CYCLE_BANDS = [("LATE S", 8, 772), ("LATE S \u2192 G2", 788, 186),
               ("G2/M \u2192 G1", 982, 210)]


def nav_svg():
    o = ['<svg id="flow" viewBox="0 0 660 1210" xmlns="http://www.w3.org/2000/svg">',
         '<defs>']
    for mid, cls in (("ah", "navhead"), ("ahg", "navheadg"), ("ahr", "navheadr")):
        o.append('<marker id="%s" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" '
                 'markerHeight="6" orient="auto-start-reverse">'
                 '<path d="M0,1 L9,5 L0,9 z" class="%s"/></marker>' % (mid, cls))
    o.append("</defs>")

    for phase, x, y, w, h in NAV_BANDS:
        o.append('<rect class="band" data-phase="%s" x="%d" y="%d" width="%d" '
                 'height="%d"/>' % (phase, x, y, w, h))
    for x, y, label in BAND_HEADERS:
        o.append('<text class="bandhead" x="%d" y="%d">%s</text>' % (x, y, label))
    for label, y in BAND_LABELS:
        o.append('<text class="bandlab" x="20" y="%d" transform="rotate(-90 20 %d)">%s</text>'
                 % (y, y, label))

    for label, y, h in CYCLE_BANDS:
        o.append('<rect class="cyband" x="598" y="%d" width="44" height="%d"/>' % (y, h))
        o.append('<text class="cylab" x="620" y="%d" transform="rotate(-90 620 %d)">%s</text>'
                 % (y + h / 2, y + h / 2, label))

    # the split, and its two arms
    o.append('<g class="split"><rect class="splitbar" x="60" y="8" width="306" '
             'height="18" rx="4"/>'
             '<text class="splitlab" x="213" y="21">'
             'replication fork passes: two daughter ends</text></g>')
    o.append('<path class="edge" d="M%d,26 L%d,80" marker-end="url(#ah)"/>'
             % (MID_LEAD, MID_LEAD))
    o.append('<path class="edge lagedge" d="M%d,26 L%d,80" marker-end="url(#ah)"/>'
             % (MID_LAG, MID_LAG))

    # leading column, and the shared tail below the merge
    for y1, y2 in [(144, 176), (240, 272), (336, 396), (460, 492),
                   (550, 600), (664, 696), (760, 806), (870, 902), (966, 998)]:
        o.append('<path class="edge" d="M%d,%d L%d,%d" marker-end="url(#ah)"/>'
                 % (MID_LEAD, y1, MID_LEAD, y2))

    # lagging column: one long edge across the slot where step 2 would be, and
    # a note saying why the slot is empty rather than leaving it unexplained
    o.append('<path class="edge lagedge" d="M%d,144 L%d,272" marker-end="url(#ah)"/>'
             % (MID_LAG, MID_LAG))
    # The only three-line label in the chart, and the other place 12px baselines
    # stopped working when the type grew.
    o.append('<text class="yn lag" x="%d" y="210">no incision step:</text>' % (MID_LAG + 8))
    o.append('<text class="yn lag" x="%d" y="224">5-prime end already</text>' % (MID_LAG + 8))
    o.append('<text class="yn lag" x="%d" y="238">recessed</text>' % (MID_LAG + 8))

    # the merge into step 4
    o.append('<path class="edge lagedge" d="M%d,336 L%d,368 L%d,368" '
             'marker-end="url(#ah)"/>' % (MID_LAG, MID_LAG, MID_LEAD + 2))
    o.append('<text class="yn lag" x="%d" y="362">both ends converge here</text>'
             % (MID_LEAD + 22))

    # the one remaining decision
    o.append('<g class="dec" data-dec="D1">'
             '<polygon points="%d,492 %d,521 %d,550 %d,521"/>'
             '<text class="dn" x="%d" y="517">D1</text>'
             '<text class="dt" x="%d" y="532">Rif2 load low?</text></g>'
             % (MID_LEAD, MID_LEAD + 68, MID_LEAD, MID_LEAD - 68,
                MID_LEAD, MID_LEAD))
    o.append('<text class="yn" x="%d" y="580">yes (short)</text>' % (MID_LEAD + 7))
    o.append('<path class="sedge" d="M%d,521 L%d,521" marker-end="url(#ahg)"/>'
             % (MID_LEAD + 65, COL_OFF - 4))
    o.append('<text class="yn g" x="%d" y="514">no (long)</text>' % (MID_LEAD + 72))
    # Out to REJOIN_X before dropping. It used to run straight down MID_OFF,
    # which is the middle of the offshoot column, and offA now occupies that
    # column two rows below. REJOIN_X is the gutter between the column's right
    # edge at 578 and the cell-cycle band at 598.
    o.append('<path class="sedge" d="M%d,524 L%d,524 L%d,930 L%d,930" '
             'marker-end="url(#ahg)"/>'
             % (COL_OFF + OFF_W, REJOIN_X, REJOIN_X, MID_LEAD + NODE_W / 2 + 3))
    o.append('<text class="yn g" x="%d" y="923">rejoins fill-in</text>' % (MID_OFF - 130))

    # elongation to offA: the branch this figure takes when there is no enzyme
    o.append('<path class="sedge" d="M%d,728 L%d,728" marker-end="url(#ahg)"/>'
             % (COL_LEAD + NODE_W, COL_OFF - 4))
    o.append('<text class="yn g" x="%d" y="721">no telomerase</text>'
             % (COL_LEAD + NODE_W + 12))

    # the three cap elements branch off step 9, one per element
    o.append('<path class="sedge" d="M%d,1030 L%d,1030"/>' % (COL_LEAD + NODE_W, 214))
    o.append('<path class="sedge" d="M214,1027 L214,1151"/>')
    for y in (1027, 1089, 1151):
        o.append('<path class="sedge" d="M214,%d L%d,%d" marker-end="url(#ahg)"/>'
                 % (y, COL_OFF - 4, y))
    o.append('<text class="yn g" x="220" y="1178">lose one cap element</text>')

    # feedback and the close of the cycle
    o.append('<path class="fb" d="M%d,1046 L232,1046 L232,536 L%d,536" '
             'marker-end="url(#ahr)"/>' % (COL_LEAD + NODE_W, MID_LEAD + 62))
    o.append('<text class="yn r" x="242" y="770" transform="rotate(-90 242 770)">'
             'added repeats restore the Rif2 load</text>')
    # Out at x 8, clear of the rotated band labels at x 20, and its own label
    # sits in the split region where there is no band label to collide with.
    o.append('<path class="edge" d="M%d,1030 L8,1030 L8,17 L60,17" '
             'marker-end="url(#ah)"/>' % COL_LEAD)
    o.append('<text class="yn" x="16" y="290" transform="rotate(-90 16 290)">'
             'next S phase</text>')

    def node(key, x, y, w, mid, num, lines, cls):
        g = ['<g class="%s" data-key="%s" tabindex="0" role="button">' % (cls, key)]
        h = 52 if len(lines) == 1 else 64
        g.append('<rect x="%d" y="%d" width="%d" height="%d" rx="5"/>' % (x, y, w, h))
        g.append('<text class="nn" x="%d" y="%d">%s</text>' % (mid, y + 22, num))
        for j, ln in enumerate(lines):
            # 14 between baselines, not 12. At 12px type, 12 is zero leading and
            # the two lines of a node touch. 36 and 50 inside a 64-tall box puts
            # the descenders of the second line 11 clear of the bottom edge.
            g.append('<text class="nt" x="%d" y="%d">%s</text>' % (mid, y + 36 + j * 14, ln))
        g.append("</g>")
        return g

    for key, y, num, lines in NAV_NODES:
        o += node(key, COL_LEAD, y, NODE_W, MID_LEAD, num, lines, "node")
    for key, y, num, lines in NAV_LAG:
        o += node(key, COL_LAG, y, NODE_W, MID_LAG, num, lines, "node lag")
    for key, y, num, lines in NAV_OFFSHOOTS:
        o += node(key, COL_OFF, y, OFF_W, MID_OFF, num, lines, "node off")

    o.append("</svg>")
    return "\n".join(o)


# -------------------------------------------------------------------- main --
if __name__ == "__main__":
    for key, fn in PANEL_FNS.items():
        open(os.path.join(PANELS, key + ".svg"), "w", encoding="utf-8").write(fn())
    open(os.path.join(ROOT, "src", "nav.svg"), "w", encoding="utf-8").write(nav_svg() + "\n")
    print("wrote %d panels + nav.svg" % len(PANEL_FNS))