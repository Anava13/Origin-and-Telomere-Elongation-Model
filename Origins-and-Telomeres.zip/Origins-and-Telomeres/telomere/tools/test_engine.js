const { JSDOM } = require('jsdom');
const fs = require('fs');

const html = fs.readFileSync('dist/telomere_workflow.html', 'utf8');
const dom = new JSDOM(html, { runScripts: 'dangerously', pretendToBeVisual: true });
const { window } = dom;
const doc = window.document;

let fails = [];
const ok = (c, m) => { if (!c) fails.push(m); };

// ANIM, META and ORDER are script-level const bindings, so they live in the
// window's global lexical scope rather than on the window object. eval inside
// the realm is how a test reaches them.
const ANIM  = window.eval('ANIM');
const META  = window.eval('META');
const ORDER = window.eval('ORDER');

// --- initial render
ok(doc.getElementById('title').textContent.includes('blunt'), 'step01 not shown at load');
ok(doc.querySelector('.panel.on').id === 'p-step01', 'wrong panel visible at load');
// Step 1 is animated now, so the transport is armed at load. Step 2 is the
// static panel that proves the transport disarms.
ok(doc.getElementById('transport').classList.contains('on'),
   'transport not armed for step01, which animates the fork');
window.selectStep('step02');
ok(!doc.getElementById('transport').classList.contains('on'),
   'transport visible on a non-animated panel');
window.selectStep('step01');

// --- selecting an animated panel arms the transport
window.selectStep('step03');
ok(doc.querySelector('.panel.on').id === 'p-step03', 'step03 panel not revealed');
ok(doc.getElementById('transport').classList.contains('on'), 'transport not armed for step03');
ok(doc.getElementById('framelab').textContent.includes('frame 1 of 7'),
   'wrong frame label: ' + doc.getElementById('framelab').textContent);

// --- resection: scrub to last frame, C-strand chunks 11-14 must be gone,
//     and the equivalent chunks in OTHER panels must be untouched
window.runAnimation('seek', 5);
const p3 = doc.getElementById('p-step03');
['c11-b','c12-b','c13-b','c14-b'].forEach(id => {
  ok(p3.querySelector('#'+id).classList.contains('gone'), 'step03 '+id+' should be gone');
});
ok(p3.querySelector('#c10-b') && !p3.querySelector('#c10-b').classList.contains('gone'),
   'step03 c10-b (duplex) must survive resection');
const p1 = doc.getElementById('p-step01');
ok(!p1.querySelector('#c14-b').classList.contains('gone'),
   'LEAK: resection modified step01 chunks');

// --- actors moved, and only in the right panel
ok(p3.querySelector('#actor-exo1').getAttribute('transform') === 'translate(-180,0)',
   'exo1 should travel leftward, with the resection: got ' +
   p3.querySelector('#actor-exo1').getAttribute('transform'));
const xf = n => parseInt((p3.querySelector('#actor-exo1').getAttribute('transform')||'translate(0,0)').match(/-?\d+/)[0], 10);
window.runAnimation('seek', 1); const x1 = xf();
window.runAnimation('seek', 4); const x4 = xf();
ok(x4 < x1, 'exo1 must move in the same direction as chunk removal');
window.runAnimation('seek', 5);
// Ku carries a derived transform in every panel, so absence is not the leak
// test. Step 1 is animated now and its junction depends on which of its own
// frames it is showing, so the invariant is that panel 3 running cannot change
// it: read it, run panel 3 again, read it back.
{
  const kuOff = () => parseFloat(
    (p1.querySelector('#actor-ku').getAttribute('transform') || 'translate(0,0)')
      .match(/-?\d+(\.\d+)?/)[0]);
  const before = kuOff();
  window.selectStep('step03');
  window.runAnimation('seek', 5);
  ok(kuOff() === before,
     'LEAK: step01 Ku moved to ' + kuOff() + ' from ' + before + ' while step03 ran');
}

// Step 1 ends blunt, so on its last frame the junction is its own terminus and
// Ku's offset is zero. That is the state panel 2 opens on.
{
  window.selectStep('step01');
  window.runAnimation('seek', ANIM.step01.frames.length - 1);
  const off = parseFloat(
    (p1.querySelector('#actor-ku').getAttribute('transform') || 'translate(0,0)')
      .match(/-?\d+(\.\d+)?/)[0]);
  ok(off === 0, 'step01 does not finish blunt: Ku ends at offset ' + off);
}

// --- elongation: arriving chunks must be visible (the pending/shown bug)
window.selectStep('step06');
const p6 = doc.getElementById('p-step06');
ok(p6.querySelector('#c15-t').classList.contains('gone'), 'step06 c15-t should start gone');
window.runAnimation('seek', 1);
ok(p6.querySelector('#c15-t').classList.contains('shown'), 'arriving chunk not shown');
ok(p6.querySelector('#c15-t').classList.contains('arriving'), 'arriving chunk not gray');
window.runAnimation('seek', 5);
['c15-t','c16-t','c17-t','c18-t'].forEach(id => {
  const el = p6.querySelector('#'+id);
  ok(el.classList.contains('shown') && !el.classList.contains('gone'),
     'step06 '+id+' should be present at end');
});
ok(p6.querySelector('#actor-tel').getAttribute('transform') === 'translate(168,0)',
   'telomerase did not move with the growing end');

// --- fill-in runs right to left, starting internal to the Cdc13 footprint
window.selectStep('step08');
const p8 = doc.getElementById('p-step08');
// Found from the table, not counted from the front. Panel 8 opens on the Cdk1
// beats now, so the first synthesis frame is no longer frame 1 and would move
// again if anything else were prepended.
const p8start = ANIM.step08.frames.findIndex(f =>
  (f.halves || {})['c17-b'] === 'arriving');
ok(p8start > -1, 'step08 never starts filling in');
window.runAnimation('seek', p8start);
ok(p8.querySelector('#c17-b').classList.contains('arriving'),
   'fill-in should start at the repeat internal to the footprint');
ok(p8.querySelector('#c11-b').classList.contains('gone'), 'proximal should still be empty');
window.runAnimation('seek', ANIM.step08.frames.length - 1);
['c11-b','c17-b'].forEach(id =>
  ok(p8.querySelector('#'+id).classList.contains('shown'), 'fill-in incomplete at '+id));

// The trimer is stationary and the polymerase is not. This used to assert that
// the two carry the same offset in every frame, which read as CST tracking the
// enzyme along the DNA. The contacts behind that assertion, Cdc13 OB1 to Pol1
// and Stn1 to Pol12, are recruitment contacts; nothing in them makes CST
// translocate. What links the stationary trimer to the advancing polymerase is
// not settled, so the figure draws neither linkage and asserts only that one
// moves and the other does not.
// Once the polymerase starts it does not stop, and where it starts is read from
// the table rather than assumed. The frames before it are the kinase beats and
// the opening state, and it is legitimately stationary in those.
const polaGo = ANIM.step08.frames.findIndex(
  f => ((f.actors || {})['actor-pola'] || 0) !== 0);
ok(polaGo > -1, 'step08 never advances the polymerase');
for (let f = 0; f < ANIM.step08.frames.length; f++) {
  window.runAnimation('seek', f);
  const c = p8.querySelector('#actor-cst').getAttribute('transform');
  const a = p8.querySelector('#actor-pola').getAttribute('transform');
  ok(!c || /translate\(0[ ,]/.test(c),
     'frame ' + f + ': CST (' + c + ') is travelling; the trimer holds the footprint');
  ok(f < polaGo || (a && !/translate\(0[ ,]/.test(a)),
     'frame ' + f + ': Pol alpha (' + a + ') is not advancing');
}

// MRX is a constitutive complex: all three subunits in every panel that has it
['step01','step02','step03','lag03','step04','step05','step06','offB'].forEach(k => {
  const panel = doc.getElementById('p-' + k);
  const txt = panel.textContent;
  ['Mre11','Rad50','Xrs2'].forEach(sub =>
    ok(txt.includes(sub), k + ' missing MRX subunit ' + sub));
});
// Tel1 flies only where the socket is free. Check the glyph, not the label
// text, because the offB note legitimately mentions Tel1 in the negative.
ok(doc.querySelector('#p-step05 .tel1flag'), 'step05 should fly the Tel1 flag');
ok(!doc.querySelector('#p-offB .tel1flag'),
   'offB must not fly Tel1: the socket is taken');
ok(doc.querySelector('#p-offB .rif2.seated'), 'offB missing Rif2 in the socket');
ok(doc.querySelector('#p-offB .pole.unseated'),
   'offB should show the Xrs2 C-terminus displaced, not absent');
ok(doc.querySelector('#p-step05 .pole') &&
   !doc.querySelector('#p-step05 .pole.unseated'), 'step05 pole should be seated');

// The socket is contested in both panels, and the contest has to be on the
// page rather than only in the note. Same idiom as Est1 and CST in panel 8:
// the contact that is not being made is ghosted, and a blunt bar runs from
// whatever is blocking it.
{
  const ghosted = doc.querySelector('#p-step05 .ghost .rif2');
  ok(ghosted, 'step05 draws a free socket but not the thing that would take it');
  ok(!doc.querySelector('#p-step05 .ghost .rif2.seated'),
     'step05 ghosts a Rif2 that is in the socket, which is branch B');
  ok(doc.querySelector('#p-step05 .mrx .inhibit'),
     'step05 has no exclusion mark, so Rif2 reads as merely absent');
  ok(doc.querySelector('#p-offB .mrx .inhibit'),
     'offB has no exclusion mark, so the displaced C-terminus reads as merely loose');
  // One Rif2 per state. Branch B draws the winner and panel 5 the loser, and
  // neither draws both.
  ok(!doc.querySelector('#p-offB .ghost .rif2'),
     'offB ghosts a Rif2 as well as seating one');

  // The mark rides inside the complex, so it travels with the socket it is
  // about. Anchored outside, it detaches the moment a frame moves MRX.
  ['step05','offB'].forEach(k =>
    ok(doc.querySelector('#p-' + k + ' .mrx .inhibit'),
       k + ': the exclusion mark is outside the MRX group'));
}

// Branch B is the long-telomere counterfactual, so the array under it has to
// be longer. Occupancy is the mechanism, and the two panels drawing the same
// number of Rif2 molecules was the figure asserting the mechanism in a note
// and denying it in the drawing.
{
  const rif2 = k => doc.querySelectorAll('#p-' + k + ' .rap1array .rif2').length;
  const rap1 = k => doc.querySelectorAll('#p-' + k + ' .rap1[data-span]').length;
  ok(rap1('offB') > rap1('step05'),
     'offB has ' + rap1('offB') + ' Rap1 boxes against step05 ' + rap1('step05') +
     ': the long telomere is not drawn longer');
  ok(rif2('offB') > rif2('step05'),
     'offB has ' + rif2('offB') + ' Rif2 against step05 ' + rif2('step05') +
     ': the Rif2 load is the mechanism and it is drawn the same in both');
  ok(rif2('offB') === rap1('offB'),
     'offB draws Rif2 on some Rap1 boxes and not others');
  // and every box it draws has to be on duplex, or the derivation hides it and
  // the count the panel argues from is not the count on screen.
  window.selectStep('offB');
  const showing = [...doc.querySelectorAll('#p-offB .rap1')]
                    .filter(g => !g.classList.contains('gone')).length;
  ok(showing === rap1('offB'),
     'offB emits ' + rap1('offB') + ' Rap1 boxes and shows ' + showing +
     ': some are over the overhang');
}

// The overhang must be visible: top strand extends past the bottom strand.
// This is the bug that made panels 4 and B look like blunt duplex. Branch B
// carries the same four-repeat overhang on a longer array, so the repeats it
// falls on are four further out.
const OVERHANG = { step04: [11,12,13,14], step05: [11,12,13,14],
                   step06: [11,12,13,14], offB: [15,16,17,18] };
Object.keys(OVERHANG).forEach(k => {
  const panel = doc.getElementById('p-' + k);
  OVERHANG[k].forEach(n => {
    const i = String(n);
    const t = panel.querySelector('#c' + i + '-t');
    const b = panel.querySelector('#c' + i + '-b');
    ok(t && !t.classList.contains('pending'),
       k + ': overhang chunk c' + i + '-t must be visible');
    ok(b && b.classList.contains('pending'),
       k + ': c' + i + '-b must be absent, or there is no overhang');
  });
  // and it is four repeats everywhere, or the panels are not comparable
  ok(OVERHANG[k].length === 4, k + ': overhang is not four repeats');
});

// MRX must actually be present and on-canvas, not just defined
['step04','step05','step06','offB'].forEach(k => {
  const g = doc.querySelector('#p-' + k + ' .mrx');
  ok(g, k + ': MRX group missing');
  if (g) {
    const rad = g.querySelector('.rad50');
    const cxv = parseFloat(rad.getAttribute('cx'));
    ok(cxv > 0 && cxv < 880, k + ': Rad50 off-canvas at cx=' + cxv);
  }
});

// Telomerase carries its own direction: ring, shaft, arrowhead, Est1/2/3
['step06','step07'].forEach(k => {
  const t = doc.querySelector('#p-' + k + ' .telomerase');
  ok(t, k + ': telomerase missing');
  if (t) {
    // The loop and the shaft are one continuous stroke, so there is exactly
    // one .tlc1 path and its data must contain both the arc and the run.
    const paths = t.querySelectorAll('.tlc1');
    ok(paths.length === 1, k + ': TLC1 should be one path, found ' + paths.length);
    if (paths.length === 1) {
      const d = paths[0].getAttribute('d');
      ok(/A .* H /.test(d), k + ': TLC1 loop is not joined to the shaft: ' + d);
    }
    ok(t.querySelector('.tlc1head'), k + ': TLC1 shaft needs an arrowhead');
    ['est1','est2','est3'].forEach(sub =>
      ok(t.querySelector('.' + sub), k + ': telomerase missing ' + sub));
  }
});

// The handoff: where Cdc13 finishes elongation must be exactly where it
// starts fill-in, so the glyph does not jump between the two panels.
function cdc13Corner(panelKey, groupSel, frame) {
  window.selectStep(panelKey);
  window.runAnimation('seek', frame);
  const g = doc.querySelector('#p-' + panelKey + ' ' + groupSel);
  const d = g.querySelector('.ob').getAttribute('d');
  const m = d.match(/M\s+(-?\d+)\s+(-?\d+)/);
  const t = (g.getAttribute('transform') || 'translate(0,0)').match(/-?\d+/);
  return [parseInt(m[1], 10) + parseInt(t[0], 10), parseInt(m[2], 10)];
}
const endOfElongation = cdc13Corner('step06', '.cdc13', 5);
const afterDisplacement = cdc13Corner('step07', '.cdc13', 0);
const startOfFillIn    = cdc13Corner('step08', '#actor-cdc13-p', 0);
// The recruiting molecule is the one that has to hand off cleanly, and it hands
// off to itself: it never moves in panel 6, so panels 6, 7 and 8 all draw it at
// the same corner. The capping trimer in panel 8 is a different molecule in a
// different covalent state on a different repeat, so it is not part of this
// check and must not be at the same corner.
ok(endOfElongation[0] === startOfFillIn[0] && endOfElongation[1] === startOfFillIn[1],
   'Cdc13 jumps between panels: elongation ends at [' + endOfElongation +
   '] but fill-in starts at [' + startOfFillIn + ']');
{
  const cappingCorner = cdc13Corner('step08', '.cst', 0);
  ok(cappingCorner[0] !== startOfFillIn[0],
     'step08 draws the capping trimer on top of the recruiting Cdc13');

  // The recruiting molecule needs single-stranded telomeric DNA, so it cannot
  // still be drawn once the polymerase has copied the repeat it sits on. The
  // capping trimer must survive the same test, because its footprint is never
  // copied; if both went, capping would be interrupted and claim 9.4 with it.
  window.selectStep('step08');
  const p8h = doc.getElementById('p-step08');
  const goneAt = f => {
    window.runAnimation('seek', f);
    return p8h.querySelector('#actor-cdc13-p').classList.contains('gone');
  };
  ok(!goneAt(0), 'step08 opens without the recruiting Cdc13');
  const last8 = ANIM.step08.frames.length - 1;
  ok(goneAt(last8), 'step08 ends with the recruiting Cdc13 still on copied DNA');
  for (let f = 0; f <= last8; f++) {
    window.runAnimation('seek', f);
    const c11 = p8h.querySelector('#c11-b');
    const copied = c11.classList.contains('shown') && !c11.classList.contains('gone');
    const stillThere = !p8h.querySelector('#actor-cdc13-p').classList.contains('gone');
    ok(!(copied && stillThere),
       'step08 frame ' + f + ': Cdc13 is drawn on chunk 11 after it went duplex');
    ok(!p8h.querySelector('#actor-cst').classList.contains('gone'),
       'step08 frame ' + f + ': the capping trimer went; capping must be continuous');
  }
}
// Panel 7 sits between the two and is static, so it is the easiest place for
// the handoff to drift unnoticed. It shows the fully extended G-strand, so its
// Cdc13 belongs where elongation left it, not where elongation started it.
ok(afterDisplacement[0] === endOfElongation[0] &&
   afterDisplacement[1] === endOfElongation[1],
   'step07 Cdc13 at [' + afterDisplacement + '] but elongation ended at [' +
   endOfElongation + ']');

// Pif1 displaces telomerase, so the Est1 wedge must not still be touching
// Cdc13 in panel 7 the way it does in panel 6.
{
  const w = doc.querySelector('#p-step07 .est1').getAttribute('d');
  const est1x = parseInt(w.match(/M (-?\d+)/)[1], 10);
  ok(est1x > afterDisplacement[0] + 52,
     'step07: Est1 at ' + est1x + ' still overlaps Cdc13 at ' + afterDisplacement[0]);
}

// Cdc13 binds ssDNA, so its corner sits at the same height in every panel.
['step04','step05','step06','step07','offB'].forEach(k => {
  const d = doc.querySelector('#p-' + k + ' .cdc13 .ob').getAttribute('d');
  const y = parseInt(d.match(/M -?\d+ (-?\d+)/)[1], 10);
  ok(y === startOfFillIn[1],
     k + ': Cdc13 corner at y=' + y + ', but fill-in draws it at y=' + startOfFillIn[1]);
});

// MRX has two resting places, not one, and must not drift within either.
// Panels 1-3 still have a C-strand running to the terminus, so MRX sits on the
// last duplex repeat at the incision site. From panel 4 the C-strand stops at
// chunk 10, so the same coordinate would be the middle of the overhang; MRX
// binds duplex ends, so it moves to the junction and stays there.
{
  const cx = k => parseFloat(doc.querySelector('#p-' + k + ' .rad50').getAttribute('cx'));
  const term = ['step01','step02','step03','lag03'].map(cx);
  ok(term.every(v => v === term[0]),
     'MRX drifts across the terminus panels: ' + term);

  const junc = ['step04','step05','step06'].map(cx);
  ok(junc.every(v => v === junc[0]),
     'MRX drifts across the junction panels: ' + junc);

  ok(junc[0] < term[0],
     'MRX should move inward once resection has run, not stay at the terminus');

  // and the junction position must actually be on duplex. The C-strand ends at
  // chunk 10, so the right edge of the duplex is 50 + 10 * 42.
  ok(junc[0] < 50 + 10 * 42,
     'junction MRX at ' + junc[0] + ' is out on the overhang');

  // Branch B is the same panel on a longer array, so its junction is the panel
  // 5 junction moved out by the four repeats the array gains, and it has to be
  // on that panel's own duplex, which ends at chunk 14.
  ok(cx('offB') === junc[0] + 4 * 42,
     'offB junction at ' + cx('offB') + ' is not panel 5 shifted by the extra array');
  ok(cx('offB') < 50 + 14 * 42,
     'offB junction MRX at ' + cx('offB') + ' is out on the overhang');

  // Mirrored there, or the Xrs2 body and the flagpole run through Cdc13.
  ['step04','step05','step06','offB'].forEach(k => {
    const g = doc.querySelector('#p-' + k + ' .mrx');
    const xrs2 = parseFloat(g.querySelector('.xrs2').getAttribute('cx'));
    ok(xrs2 < cx(k), k + ': Xrs2 is right of Rad50, so it points into Cdc13');
  });
  ['step01','step02','step03','lag03'].forEach(k => {
    const g = doc.querySelector('#p-' + k + ' .mrx');
    const xrs2 = parseFloat(g.querySelector('.xrs2').getAttribute('cx'));
    ok(xrs2 > cx(k), k + ': terminus MRX should not be mirrored');
  });
}

// Panel 6 is the reason MRX matters: panel 5 argues a free socket retains MRX
// and accumulates Tel1, and this is where that has its effect. Faint, because
// it is the cause and not the subject.
{
  const g = doc.querySelector('#p-step06 .mrx');
  ok(g, 'step06: MRX missing, so the licensing complex vanishes at the moment it acts');
  ok(g && g.classList.contains('faint'),
     'step06 MRX should be faint: it is the reason for the panel, not its subject');
  ok(doc.querySelector('#p-step06 .tel1flag'),
     'step06 should keep Tel1: MRX and Tel1 are both required for Est1/Est2 association');
}

// MRX association is late-S specific, so it leaves before fill-in. Panels 7-9
// must not draw it, and panel 9 in particular has to stay down to three things.
['step07','step08','step09'].forEach(k =>
  ok(!doc.querySelector('#p-' + k + ' .mrx'),
     k + ': MRX is drawn after its window has closed'));

// The Mre11 lobes are separately addressable, or panel 3 cannot part them.
['step01','step02','step03','lag03','step04','step05','step06','offB'].forEach(k => {
  ['lobeL','lobeR'].forEach(l =>
    ok(doc.querySelector('#p-' + k + ' #actor-mrx-' + l),
       k + ': Mre11 ' + l + ' has no actor id'));
});

// The incision. Panel 2 makes the cut and flashes it; panel 3 carries the same
// mark static, so its first frame already shows two C-strand fragments rather
// than asserting a cut it never drew.
{
  const n2 = doc.querySelector('#p-step02 .nick');
  const n3 = doc.querySelector('#p-step03 .nick');
  ok(n2, 'step02 asserts an incision but never draws it');
  ok(n3, 'step03 opens on a cut C-strand, so the nick has to be there');
  ok(n2 && n2.classList.contains('flashing'),
     'step02 nick should flash: making the cut is what the panel is about');
  ok(n3 && !n3.classList.contains('flashing'),
     'step03 nick should be static: the cut already happened');
  if (n2 && n3) {
    ok(n2.getAttribute('x1') === n3.getAttribute('x1'),
       'the incision site moves between panels 2 and 3');
  }
  // The cut falls on the C-strand, between the repeat Mre11 clears and the one
  // Exo1 starts from. Chunk 14 is distal, so the mark sits at its left edge.
  if (n3) {
    ok(parseFloat(n3.getAttribute('x1')) === 50 + 13 * 42 - 1,
       'nick is not at the boundary the frame table resects from');
    ok(parseFloat(n3.getAttribute('y1')) < parseFloat(n3.getAttribute('y2')),
       'nick should run across the strand, not along it');
  }
  // No other panel may pick one up by accident
  ['step01','lag01','lag03','step04','step05','step09'].forEach(k =>
    ok(!doc.querySelector('#p-' + k + ' .nick'), k + ': unexpected incision mark'));
}

// Bidirectionality has to be visible, not just captioned. Everything else in
// panel 3 travels left; Mre11 parts over the distal repeat and closes again.
{
  window.selectStep('step03');
  const p3m = doc.getElementById('p-step03');
  const off = id => {
    const t = p3m.querySelector('#' + id).getAttribute('transform');
    return t ? parseFloat(t.match(/-?\d+(\.\d+)?/)[0]) : 0;
  };
  window.runAnimation('seek', 0);
  ok(off('actor-mrx-lobeL') === 0 && off('actor-mrx-lobeR') === 0,
     'step03: Mre11 is already parted at frame 0');
  window.runAnimation('seek', 1);
  const l = off('actor-mrx-lobeL'), r = off('actor-mrx-lobeR');
  ok(l < 0 && r > 0, 'step03: Mre11 lobes did not part on the frame that takes c14-b');
  ok(p3m.querySelector('#c14-b').classList.contains('fading'),
     'step03: the lobes part on a frame that is not clearing the distal repeat');
  window.runAnimation('seek', 2);
  ok(off('actor-mrx-lobeL') === 0 && off('actor-mrx-lobeR') === 0,
     'step03: Mre11 lobes never snap back');
  // The nucleases go the other way on the same frames, or nothing is bidirectional
  ok(off('actor-exo1') < 0,
     'step03: Exo1 should travel left while Mre11 works right');
}

// A direction tick and an animated offset say the same thing twice, so a
// nuclease that a frame table translates does not get one. This used to name
// offC and offE as static panels, which neither has been since both branches
// started moving actor-exo1. The rule is now read off the frame tables rather
// than listed by hand, so it cannot go stale again the same way.
['step03','offC','offD','offE'].forEach(k => {
  const moves = ANIM[k] && ANIM[k].frames.some(f =>
    Object.keys(f.actors || {}).some(id => id === 'actor-exo1' || id === 'actor-sgs1'));
  const tick = !!doc.querySelector('#p-' + k + ' .nucarrow');
  if (moves) {
    ok(!tick, k + ': a nuclease that translates should not carry a direction tick');
  }
});

// Panel E runs panel 3's activity, so the two enzymes travel together. Same
// rule as CST and Pol alpha in fill-in: if one offset drifts from the other
// the panel is drawing two separate events.
{
  window.selectStep('offE');
  const pE2 = doc.getElementById('p-offE');
  for (let f = 0; f < ANIM.offE.frames.length; f++) {
    window.runAnimation('seek', f);
    const e = pE2.querySelector('#actor-exo1').getAttribute('transform');
    const g = pE2.querySelector('#actor-sgs1').getAttribute('transform');
    ok(e === g, 'offE frame ' + f + ': Exo1 (' + e + ') and Sgs1-Dna2 (' + g +
                ') are not travelling together');
    const shownE = pE2.querySelector('#fx-exo1').classList.contains('shown');
    const shownG = pE2.querySelector('#fx-sgs1').classList.contains('shown');
    ok(shownE === shownG,
       'offE frame ' + f + ': one nuclease is drawn without the other');
  }
}

// Panel E moves one repeat per frame, which is panel 3's rate. Two per frame
// reads as a different activity however the glyphs are drawn.
{
  const offs = ANIM.offE.frames
    .map(f => (f.actors || {})['actor-exo1'])
    .filter(v => typeof v === 'number');
  const steps = offs.slice(1).map((v, i) => offs[i] - v).filter(d => d > 0);
  ok(steps.every(d => d <= 42),
     'offE advances ' + Math.max.apply(null, steps) + ' per frame, more than one repeat');
}

// Panel 5 now draws one mark and withholds another, which is the point. T308
// is a Cdk1 site, established, and gets the phosphate glyph. S249 and S255 are
// the contested Tel1 sites and get the panel 2 idiom instead: a labelled arrow
// with no mark on the target. The old rule was no phosphate anywhere on Cdc13,
// which kept the contested site out and the established one too.
{
  ok(doc.querySelector('#p-step05 .cdc13 .phos'),
     'step05 should mark Cdc13 at T308, which is a settled Cdk1 site');
  ok(doc.getElementById('p-step05').textContent.includes('T308'),
     'step05 draws a phosphate without naming the site it stands for');
  ok(!doc.getElementById('p-step05').textContent.includes('S249:'),
     'step05 still names the contested phosphosites as though settled');
  ok(doc.querySelector('#p-step05 .effect'), 'step05 lost the Tel1 arrow entirely');
  // The label runs along the arrow. Horizontal text beside a steep short arrow
  // reads as belonging to whatever else sits on that row, which in this panel
  // is the Tel1 flag.
  {
    const path = doc.querySelector('#p-step05 .effect').getAttribute('d');
    const m = path.match(/M (-?\d+) (-?\d+) L (-?\d+) (-?\d+)/);
    ok(m, 'step05 Tel1 arrow is not a straight segment: ' + path);
    const lab = [...doc.querySelectorAll('#p-step05 .arrowlab')]
                  .find(t => t.textContent.includes('elongation'));
    ok(lab, 'step05 Tel1 arrow lost its label');
    if (m && lab) {
      const tr = lab.getAttribute('transform');
      ok(tr && tr.indexOf('rotate') === 0,
         'step05 arrow label is not rotated: ' + tr);
      const ang = parseFloat(tr.match(/rotate\((-?\d+(?:\.\d+)?)/)[1]);
      const want = Math.atan2(+m[4] - +m[2], +m[3] - +m[1]) * 180 / Math.PI;
      ok(Math.abs(ang - want) < 1.5,
         'step05 label is rotated ' + ang + ' but the arrow runs at ' + want.toFixed(1));
      // upright, never past vertical either way
      ok(ang > -90 && ang < 90, 'step05 label is rotated past vertical: ' + ang);
    }
  }
  // The default stays horizontal, or every other arrow in the figure moves
  {
    const flat = [...doc.querySelectorAll('#p-step02 .arrowlab')];
    ok(flat.length >= 1, 'step02 lost its arrow labels');
    flat.forEach(t => ok(!t.getAttribute('transform'),
       'step02 arrow label picked up a rotation it did not ask for'));
  }
  // The phosphate glyph is still reserved for settled sites
  ok(doc.querySelector('#p-step02 .phos'),
     'step02 should keep its phosphate: Sae2 S267 is not in dispute');
  // The arrow leaves the Tel1 flag from the side facing Cdc13
  const flagX = [...doc.querySelectorAll('#p-step05 .tel1flag')]
                  .map(f => f.getAttribute('points').split(/[ ,]/).map(Number))[0];
  const d = doc.querySelector('#p-step05 .effect').getAttribute('d');
  const start = parseFloat(d.match(/M\s+(-?\d+)/)[1]);
  ok(start >= Math.min(...flagX.filter((_, i) => i % 2 === 0)),
     'step05 Tel1 arrow does not start on the flag');
}

// Panel 5 is staged. It was carrying four events at once and reading as a
// crowd, so the frames take one claim each: the kinase acting, then Tel1
// binding, then what Tel1 does.
{
  ok(ANIM.step05 && ANIM.step05.frames.length === 3,
     'step05 should run in three beats, found ' +
     (ANIM.step05 ? ANIM.step05.frames.length : 'none'));

  const p5 = doc.getElementById('p-step05');
  const shown = id => {
    const el = p5.querySelector('#' + id);
    return !!el && el.classList.contains('shown') && !el.classList.contains('gone');
  };

  // The staged pieces have to be inside the complex, or they detach from the
  // socket they are about the moment a frame moves MRX. Same rule as the
  // blocked Est1 contact riding inside cst() in panel 8.
  ['fx-tel1', 'fx-socket'].forEach(id =>
    ok(p5.querySelector('.mrx #' + id), 'step05: ' + id + ' is outside the MRX group'));

  // The mark is an outcome, so it must not be on the glyph before the kinase
  // has acted. Checked against a parse with no scripts run, which is the
  // resting picture the generator wrote.
  {
    const rest = new JSDOM(html).window.document;
    const mark = rest.querySelector('#p-step05 #fx-t308');
    ok(mark && mark.classList.contains('pending'),
       'step05 draws T308 at rest, so the phosphate is a premise and not a result');
    ok(mark && mark.classList.contains('fx'),
       'step05 T308 mark is not .fx, so a reset cannot clear it');
  }

  window.selectStep('step05');
  window.runAnimation('seek', 0);
  ok(shown('fx-cdk1'), 'step05 frame 1: the kinase is not on the page');
  ok(shown('fx-t308'), 'step05 frame 1: the phosphate does not land on the frame that deposits it');
  ['fx-tel1', 'fx-tel1arrow', 'fx-socket'].forEach(id =>
    ok(!shown(id), 'step05 frame 1: ' + id + ' is already showing'));

  window.runAnimation('seek', 1);
  ok(p5.querySelector('#fx-cdk1').classList.contains('fading'),
     'step05 frame 2: Cdk1 should be leaving once it has acted');
  ok(shown('fx-tel1'), 'step05 frame 2: Tel1 has not taken the C-terminus');
  ok(shown('fx-t308'), 'step05 frame 2: the mark should persist after the kinase goes');
  ['fx-tel1arrow', 'fx-socket'].forEach(id =>
    ok(!shown(id), 'step05 frame 2: ' + id + ' arrives before Tel1 is bound'));

  window.runAnimation('seek', 2);
  ok(p5.querySelector('#fx-cdk1').classList.contains('gone'),
     'step05 frame 3: Cdk1 is still parked at the end');
  ['fx-tel1', 'fx-tel1arrow', 'fx-socket', 'fx-t308'].forEach(id =>
    ok(shown(id), 'step05 frame 3: ' + id + ' missing from the last frame'));

  // The kinase and its arrow are one group, because the arrow is the act and
  // not a standing relationship: an arrow left behind after Cdk1 goes says the
  // enzyme is still working on a target it has left.
  {
    const g = p5.querySelector('#fx-cdk1');
    ok(g && g.querySelector('.prot.cdk1'), 'step05: Cdk1 is not in the staged group');
    ok(g && g.querySelector('.effect'),
       'step05: the Cdk1 arrow can outlive the kinase that draws it');
  }

  // The frame numbers are the one thing in this panel asserting a sequence, so
  // the disclaimer sits with them.
  {
    const t = p5.textContent;
    ok(t.indexOf('frames 1 and 2') !== -1 && t.indexOf('no evidence') !== -1,
       'step05 stages two events in an order it cannot support and does not say so');
    // bottom right, clear of the notes that run along the bottom left
    const note = [...p5.querySelectorAll('.notelab')]
      .find(n => n.textContent.indexOf('frames 1 and 2') !== -1);
    ok(note && parseFloat(note.getAttribute('x')) > 640,
       'step05: the ordering note is not in the bottom right corner');
    ok(note && parseFloat(note.getAttribute('y')) > 250 &&
       parseFloat(note.getAttribute('y')) < 300,
       'step05: the ordering note is outside the panel or above the note band');
  }
}

// Panel 7 removes telomerase by two routes, not one, and neither is the
// Cdc13-Est1 bond: that one is closed in panel 8.
{
  const p7 = doc.getElementById('p-step07');
  ok(p7.querySelector('#actor-pif1'), 'step07 missing Pif1');
  ok(p7.querySelector('#actor-ipl1'), 'step07 missing Ipl1');
  ok(p7.textContent.includes('Ipl1'), 'step07 does not label Ipl1');
  ok(p7.querySelectorAll('.nuclease').length === 2,
     'step07 should draw two agents, found ' +
     p7.querySelectorAll('.nuclease').length);
  ok(!p7.querySelector('.nucarrow'),
     'step07: Pif1 keeps a travel tick that the removal arrow already carries');
  ok(META.step07.title.includes('Ipl1'), 'step07 title still credits one agent');
  ok(doc.querySelector('.node[data-key="step07"]').textContent.includes('Ipl1'),
     'the nav node for step07 still credits one agent');
}

// RPA is not a resection leftover that Cdc13 evicts. It stays on the overhang
// alongside Cdc13 and is required for Est1 to reach the end, so every panel
// with an exposed overhang has to occupy it. Bare single-stranded DNA is the
// deprotected state, and none of these panels is claiming that.
['step04','step05','step07','step08','offB'].forEach(k => {
  const units = [...doc.querySelectorAll('#p-' + k + ' .rpa')]
                  .filter(u => !u.classList.contains('faint'));
  ok(units.length >= 2,
     k + ': ' + units.length + ' resident RPA units on the overhang, expected several');
});

// Panel 6 deposits RPA behind the advancing wedge, and has to end where panel 7
// begins, or RPA appears from nowhere between two adjacent panels.
{
  window.selectStep('step06');
  const p6r = doc.getElementById('p-step06');
  const shown = c => {
    const u = p6r.querySelector('#rpa-c' + c);
    return u && u.classList.contains('shown');
  };
  window.runAnimation('seek', 0);
  [15,16,17].forEach(c =>
    ok(!shown(c), 'step06 frame 0: rpa-c' + c + ' is on a repeat telomerase has not made'));
  // proximal first, because that is the order telomerase makes them in: a unit
  // cannot land on a repeat before the repeat exists
  window.runAnimation('seek', 3);
  ok(shown(15) && !shown(17),
     'step06: RPA is not landing behind the enzyme proximal to distal');
  // no unit ever lands on a repeat whose G-strand half is still absent
  for (let f = 0; f < ANIM.step06.frames.length; f++) {
    window.runAnimation('seek', f);
    [15,16,17].forEach(c => {
      const top = p6r.querySelector('#c' + c + '-t');
      const made = top && !top.classList.contains('gone') &&
                   (!top.classList.contains('pending') || top.classList.contains('shown'));
      ok(!(shown(c) && !made),
         'step06 frame ' + f + ': rpa-c' + c + ' is on a repeat that does not exist yet');
    });
  }
  window.runAnimation('seek', ANIM.step06.frames.length - 1);
  const end6 = [13,14,15,16,17].filter(c =>
    { const u = p6r.querySelector('#rpa-c' + c); return !u || u.classList.contains('shown'); }).length;
  const start7 = doc.querySelectorAll('#p-step07 .rpa').length;
  ok(end6 === 5, 'step06 ends with ' + end6 + ' RPA units, expected 5');
  ok(end6 === start7,
     'step06 ends with ' + end6 + ' RPA units but step07 opens with ' + start7);
  // and never on a repeat the Cdc13 wedge is still covering
  for (let f = 0; f < ANIM.step06.frames.length; f++) {
    window.runAnimation('seek', f);
    const t = p6r.querySelector('.cdc13').getAttribute('transform');
    const corner = 486 + (t ? parseFloat(t.match(/-?\d+/)[0]) : 0);
    [11,12,13,14].forEach(c => {
      const left = 50 + (c - 1) * 42 + 2, right = left + 36;
      const overlap = corner < right && corner + 52 > left;
      ok(!(overlap && shown(c)),
         'step06 frame ' + f + ': RPA on c' + c + ', which Cdc13 still covers');
    });
  }
}

// Panel 4 is a handoff of one site, not an eviction from the tail: a faint unit
// lifting off the repeat Cdc13 took, and resident units on the rest.
{
  const p4 = doc.getElementById('p-step04');
  ok(p4.querySelector('.rpa.faint'), 'step04 lost the unit being handed off');
  ok([...p4.querySelectorAll('.rpa')].some(u => !u.classList.contains('faint')),
     'step04 still shows RPA leaving the whole overhang rather than one repeat');
  ok(!p4.textContent.includes('displaced'),
     'step04 still calls the exchange a displacement');
}

// Panel 8: the polymerase has to displace RPA rather than write onto bare
// strand, so each unit goes on the frame its own C-strand half arrives.
{
  window.selectStep('step08');
  const p8r = doc.getElementById('p-step08');
  const shown = id => {
    const u = p8r.querySelector('#' + id);
    return u && !u.classList.contains('gone');
  };
  window.runAnimation('seek', 0);
  [13,14,15,16,17].forEach(c =>
    ok(shown('rpa-c' + c), 'step08 frame 0: rpa-c' + c + ' should be resident'));
  // 11 and 12 are under the recruiting Cdc13, 18 is under the capping trimer
  [11, 12, 18].forEach(c =>
    ok(!p8r.querySelector('#rpa-c' + c),
       'step08 draws RPA on chunk ' + c + ', which a Cdc13 already occupies'));
  // chunk 18 is the Cdc13 footprint and carries no RPA in any frame
  // distal first, following the polymerase leftward
  window.runAnimation('seek', 3);
  ok(!shown('rpa-c17') && shown('rpa-c13'),
     'step08: RPA is not coming off in step with synthesis');
  // The trimer no longer travels, so the old overlap check no longer bites.
  // The rule it enforced still holds and is now stronger: CST sits on chunk 18
  // in every frame and RPA never appears under it.
  for (let f = 0; f < ANIM.step08.frames.length; f++) {
    window.runAnimation('seek', f);
    const t = p8r.querySelector('.cst').getAttribute('transform');
    ok(!t || /translate\(0[ ,]/.test(t),
       'step08 frame ' + f + ': CST has an offset; the trimer must not travel');
    [13,14,15,16,17].forEach(c => {
      const left = 50 + (c - 1) * 42 + 2, right = left + 36;
      const corner = 50 + (18 - 1) * 42;
      const overlap = corner < right && corner + 52 > left;
      ok(!(overlap && shown('rpa-c' + c)),
         'step08 frame ' + f + ': CST wedge is drawn over rpa-c' + c);
    });
  }
  window.runAnimation('seek', ANIM.step08.frames.length - 1);
  [11,12,13,14].forEach(c =>
    ok(!shown('rpa-c' + c), 'step08: rpa-c' + c + ' survives fill-in'));
  // and it must never sit on a repeat that is already duplex
  for (let f = 0; f < ANIM.step08.frames.length; f++) {
    window.runAnimation('seek', f);
    [11,12,13,14].forEach(c => {
      const id = 'c' + String(c).padStart(2, '0');
      const b = p8r.querySelector('#' + id + '-b');
      const duplex = b && !b.classList.contains('gone') &&
                     (!b.classList.contains('pending') || b.classList.contains('shown'));
      ok(!(duplex && shown('rpa-' + id)),
         'step08 frame ' + f + ': RPA still on ' + id + ', which is duplex');
    });
  }
}

// Branch E: the tail it grows is single-stranded, so RPA follows Exo1 onto it.
// Chunk 18 gets none, because CST is still there and that is the whole
// difference from branch C.
{
  window.selectStep('offE');
  const pE = doc.getElementById('p-offE');
  const units = pE.querySelectorAll('.rpa');
  ok(units.length >= 4,
     'offE has ' + units.length + ' RPA units, so the long tail is drawn bare');
  window.runAnimation('seek', 0);
  units.forEach(u => ok(!u.classList.contains('shown'),
     'offE RPA is on the strand before the tail has grown'));
  window.runAnimation('seek', ANIM.offE.frames.length - 1);
  units.forEach(u => ok(u.classList.contains('shown'),
     'offE: the lengthened tail is still partly bare at the end'));
  ok(!pE.querySelector('#rpa-c18'),
     'offE puts RPA on the resting tail, which CST still holds');
  // RPA never lands on a repeat whose C-strand is still there
  for (let f = 0; f < ANIM.offE.frames.length; f++) {
    window.runAnimation('seek', f);
    for (let c = 9; c <= 17; c++) {
      const id = 'c' + String(c).padStart(2, '0');
      const b = pE.querySelector('#' + id + '-b');
      const u = pE.querySelector('#rpa-' + id);
      const duplex = b && !b.classList.contains('gone') &&
                     (!b.classList.contains('pending') || b.classList.contains('shown'));
      ok(!(duplex && u && u.classList.contains('shown')),
         'offE frame ' + f + ': RPA on ' + id + ', which is still duplex');
    }
  }
}

// Every repeat half carries its strand letter, and the letter is inside the
// group that the engine classes, so it fades with the block. Unique chunks are
// exempt and checked separately: they carry U on both halves on purpose.
['step01','step03','step06','step08'].forEach(k => {
  const panel = doc.getElementById('p-' + k);
  panel.querySelectorAll('.half').forEach(g => {
    if (!/^c\d\d-/.test(g.id)) { return; }
    const t = g.querySelector('.halflab');
    ok(t, k + ' ' + g.id + ': missing strand letter');
    if (t) {
      ok(t.textContent === (g.id.endsWith('-t') ? 'G' : 'C'),
         k + ' ' + g.id + ': letter is ' + t.textContent);
    }
  });
});
// The letter must ride inside the animated element, not beside it
window.selectStep('step03');
window.runAnimation('seek', 5);
{
  const g = doc.querySelector('#p-step03 #c14-b');
  ok(g.classList.contains('gone') && g.querySelector('.halflab'),
     'strand letter is not inside the element the engine hides');
}

// RPA is deposited during resection, so it must be absent at frame 0 and
// present at the end. This is the whole point of the .fx mechanism.
window.selectStep('step03');
const p3r = doc.getElementById('p-step03');
['rpa-c11','rpa-c12','rpa-c13'].forEach(id => {
  const g = p3r.querySelector('#' + id);
  ok(g, 'step03: ' + id + ' missing');
  if (g) {
    ok(g.classList.contains('fx'), id + ' must be .fx or the reset cannot see it');
    ok(g.classList.contains('pending'), id + ' must start invisible');
    ok(!g.classList.contains('shown'), id + ' visible before any ssDNA exists');
  }
});
window.runAnimation('seek', 6);
['rpa-c11','rpa-c12','rpa-c13'].forEach(id =>
  ok(p3r.querySelector('#' + id).classList.contains('shown'),
     'step03: ' + id + ' not deposited by the last frame'));

// The two resection branches expose the same four repeats and hand the same
// occupied strand to panel 4, so they must end with RPA on the same ones. This
// is the check that would have caught panel 3 ending with two units and panel
// 3* with three.
{
  const held = k => {
    window.selectStep(k);
    window.runAnimation('seek', ANIM[k].frames.length - 1);
    return [...doc.querySelectorAll('#p-' + k + ' .rpa')]
             .filter(u => u.classList.contains('shown'))
             .map(u => u.id).sort().join(',');
  };
  const lead = held('step03'), lag = held('lag03');
  ok(lead === lag,
     'the two resection branches end with different RPA: ' + lead + ' vs ' + lag);
  ok(lead.split(',').length === 3,
     'resection ends with ' + lead.split(',').length + ' RPA units on four exposed repeats');
  // Chunk 14 stays bare in both. Panel 3 clears it with the Mre11 arm and 3*
  // had it single-stranded before it opened, and both captions say so.
  ok(lead.indexOf('rpa-c14') === -1, 'resection deposits RPA on chunk 14');
}

// Distal to proximal, one unit per beat, and each one lands on the frame its
// own C-strand half goes. A unit that arrives early is sitting on duplex.
{
  window.selectStep('step03');
  [[3, 'c13-b', 'rpa-c13'], [4, 'c12-b', 'rpa-c12'], [5, 'c11-b', 'rpa-c11']]
    .forEach(([f, half, unit]) => {
      window.runAnimation('seek', f - 1);
      ok(!p3r.querySelector('#' + unit).classList.contains('shown'),
         'step03 frame ' + (f - 1) + ': ' + unit + ' is on a repeat that is still duplex');
      window.runAnimation('seek', f);
      ok(p3r.querySelector('#' + half).classList.contains('gone'),
         'step03 frame ' + f + ': ' + half + ' should be gone by the beat ' + unit + ' lands');
      ok(p3r.querySelector('#' + unit).classList.contains('shown'),
         'step03 frame ' + f + ': ' + unit + ' did not land with its own repeat');
    });
}
// Distal first: RPA follows the nucleases inward, so 12 lands before 11
window.runAnimation('seek', 4);
ok(p3r.querySelector('#rpa-c12').classList.contains('shown') &&
   !p3r.querySelector('#rpa-c11').classList.contains('shown'),
   'step03: RPA deposition order is not distal to proximal');
// No RPA on a repeat whose C-strand is still there
window.runAnimation('seek', 0);
ok(!p3r.querySelector('#rpa-c12').classList.contains('shown'),
   'step03: RPA present at frame 0, where there is no ssDNA');
// The reset has to reach .fx glyphs, not just strand halves
window.runAnimation('seek', 6);
window.selectStep('step01');
window.selectStep('step03');
ok(!p3r.querySelector('#rpa-c11').classList.contains('shown'),
   'stale .fx state survived the reset');

// One RPA unit has to fit inside one repeat, or it cannot be deposited.
// A quarter-disc of radius r is r wide, not 2r, and the bump sits beside it.
{
  const g = p3r.querySelector('#rpa-c11');
  const d = g.querySelector('.rfa1').getAttribute('d');
  const left = parseInt(d.match(/M (-?\d+)/)[1], 10);
  const r = parseInt(d.match(/h (\d+)/)[1], 10);
  const bump = g.querySelector('.rfa23');
  const right = parseFloat(bump.getAttribute('x')) +
                parseFloat(bump.getAttribute('width'));
  ok(right - left <= 40,
     'RPA unit is ' + (right - left) + ' wide, chunk is 40');
  ok(r <= 40, 'RPA wedge ' + r + ' is wider than a chunk');
}

// Panel 4 shows the exchange: RPA leaving as Cdc13 takes the overhang
ok(doc.querySelector('#p-step04 .rpa.faint'),
   'step04 should draw RPA on its way off, not resident');
ok(!doc.querySelector('#p-step03 .rpa.faint'),
   'step03 RPA should be resident, not faint');
// RPA and Cdc13 must be separable, so they cannot share the OB wedge class
ok(!doc.querySelector('#p-step04 .rpa .ob'),
   'RPA is drawing Cdc13\'s wedge class');

// Cdc13 is a recruitment factor, not a processivity factor, so it stays where
// it bound while telomerase runs out past it. This used to assert the
// opposite, that the two travel together, which was a mechanism the model had
// no way to support: a Cdc13 sliding along DNA behind a polymerase is not
// something anyone has measured at a yeast telomere.
window.selectStep('step06');
const p6b = doc.getElementById('p-step06');
for (let f = 0; f < 6; f++) {
  window.runAnimation('seek', f);
  const c = p6b.querySelector('.cdc13').getAttribute('transform');
  const t = p6b.querySelector('.telomerase').getAttribute('transform');
  ok(!c || /translate\(0[ ,]/.test(c),
     'step06 frame ' + f + ': Cdc13 (' + c + ') is travelling; it should not');
  ok(f === 0 || (t && !/translate\(0[ ,]/.test(t)),
     'step06 frame ' + f + ': telomerase (' + t + ') is not advancing');
}

// Est1 bridges Cdc13 to Est2, so it has to be big enough to reach both.
const est1 = doc.querySelector('#p-step06 .est1');
const r1 = parseInt(est1.getAttribute('d').match(/a (\d+)/)[1], 10);
ok(r1 >= 48, 'Est1 radius ' + r1 + ' is too small to bridge Cdc13 and Est2');

// The Est4 contact is shown by adjacency now, not a labelled arrow
ok(!doc.getElementById('p-step06').textContent.includes('Est4'),
   'step06 should no longer carry an Est4 label');

// Ku binds the end and is named in the panel 3 caption as competing with
// Exo1, so it has to be drawn wherever a bindable end exists.
['step01','lag01','step02','step03','lag03'].forEach(k =>
  ok(doc.querySelector('#p-' + k + ' .ku'), k + ': Ku missing at the end'));

// Sir complex on the most proximal Rap1
ok(doc.getElementById('p-step01').textContent.includes('Sir2-3-4'),
   'step01 missing the Sir complex');

// --- switching away resets cleanly
window.selectStep('step02');
ok(!doc.getElementById('transport').classList.contains('on'),
   'transport still armed after leaving an animated panel');
window.selectStep('step03');
ok(doc.getElementById('framelab').textContent.includes('frame 1 of 7'),
   'animation did not reset on re-entry');
ok(!p3.querySelector('#c14-b').classList.contains('gone'),
   'stale gone class survived reset');

// The trimer's arrival is the off switch for recruitment, not just the start
// of fill-in. Panel 8 has to say so, and the Est1 it draws must be the contact
// that cannot form rather than a second real one.
{
  const p8s = doc.getElementById('p-step08');
  ok(p8s.querySelector('.inhibit'), 'step08 missing the exclusion mark');
  ok(p8s.querySelectorAll('.inhibit .inhibitline').length === 2,
     'an inhibition mark is a line plus a blunt bar');
  const est = p8s.querySelector('.est1');
  ok(est, 'step08 should draw the Est1 contact it is blocking');
  ok(est && est.closest('.ghost'),
     'step08 Est1 must be drawn as a ghost, or it reads as bound');
  // The mark and the blocked contact ride inside the trimer. Anchored to fixed
  // coordinates they detach from CST the moment the panel animates, and the
  // base of an exclusion mark has to be on the thing doing the excluding.
  ok(p8s.querySelector('#actor-cst .inhibit'),
     'step08 exclusion mark is not inside the CST group, so it will not travel');
  ok(est && est.closest('#actor-cst'),
     'step08 ghosted Est1 is not inside the CST group');
  // and the base has to sit inside the Cdc13 quarter-disc, not beside it
  {
    const d = p8s.querySelector('#actor-cst .inhibitline').getAttribute('d');
    const m = d.match(/M (-?\d+) (-?\d+)/);
    const dx = parseInt(m[1], 10) - (50 + 17 * 42), dy = parseInt(m[2], 10) - (139 + 13);
    ok(dx > 0 && dy > 0 && Math.sqrt(dx * dx + dy * dy) < 52,
       'step08 exclusion mark starts outside the Cdc13 wedge at [' +
       m[1] + ',' + m[2] + ']');
  }
  // it must travel with CST, frame for frame
  {
    window.selectStep('step08');
    const cstG = doc.querySelector('#p-step08 #actor-cst');
    for (let f = 0; f < ANIM.step08.frames.length; f++) {
      window.runAnimation('seek', f);
      ok(!!cstG.querySelector('.inhibit'),
         'step08 frame ' + f + ': exclusion mark left the trimer');
    }
  }
  ok(p8s.textContent.includes('Cdc13-Est1'),
     'step08 does not name what is being blocked');
  // No other panel should acquire a ghost by accident
  ['step06','step07'].forEach(k =>
    ok(!doc.querySelector('#p-' + k + ' .ghost'), k + ': unexpected ghost glyph'));
}

// --- offC: the capping claim panel 4 makes, drawn
{
  const pC = doc.getElementById('p-offC');
  ok(pC, 'offC panel missing');
  ok(doc.querySelector('.node[data-key="offC"]'), 'offC has no nav node');
  ok(!pC.querySelector('.cdc13'),
     'offC draws Cdc13, which is the one thing the branch is defined by lacking');
  ['mec1','ddc2','rad9','rad53'].forEach(sub =>
    ok(pC.querySelector('.prot.' + sub), 'offC missing ' + sub));
  // The checkpoint needs RPA-coated ssDNA to read. The units are deposited
  // during the branch animation now, so they start invisible and must all be
  // showing by the last frame.
  const units = pC.querySelectorAll('.rpa');
  ok(units.length >= 4, 'offC has ' + units.length + ' RPA units, expected several');
  window.selectStep('offC');
  window.runAnimation('seek', 0);
  units.forEach(u => ok(!u.classList.contains('shown'),
     'offC RPA is present before the cap is lost'));
  window.runAnimation('seek', ANIM.offC.frames.length - 1);
  units.forEach(u => ok(u.classList.contains('shown'),
     'offC RPA missing once resection has run'));
  // Rap1 binds duplex, so the array cannot extend over the resected region.
  // It is derived now, so count only the boxes still showing.
  window.selectStep('offC');
  window.runAnimation('seek', ANIM.offC.frames.length - 1);
  const rap1 = [...pC.querySelectorAll('.rap1')]
                 .filter(g => !g.classList.contains('gone')).length;
  // Mid-animation a half is hidden by "gone" rather than by "pending", so the
  // rest-state shortcut no longer answers this. Ask the same question the
  // engine asks.
  let lastDuplex = 0;
  for (let i = 1; i <= 18; i++) {
    const b = pC.querySelector('#c' + String(i).padStart(2, '0') + '-b');
    const shown = b && !b.classList.contains('gone') &&
                  (!b.classList.contains('pending') || b.classList.contains('shown'));
    if (shown) { lastDuplex = i; }
  }
  ok(rap1 * 2 <= lastDuplex,
     'offC: ' + rap1 + ' Rap1 boxes span past the duplex, which ends at chunk ' +
     lastDuplex);
  // The end state is stronger than it used to be. Resection no longer stops
  // inside the array, so no repeat keeps its C-strand and the caption's "past
  // the telomeric repeats into unique sequence" is drawn rather than asserted.
  // lastDuplex of 0 here means no repeat is duplex, not that none was checked.
  ok(lastDuplex === 0,
     'offC: chunk ' + lastDuplex + ' still has its C-strand, so resection ' +
     'stopped inside the array');
  ok(rap1 === 0, 'offC: ' + rap1 + ' Rap1 boxes survive a fully resected array');
}
window.selectStep('offC');
ok(doc.getElementById('num').textContent === 'C.', 'offC numbering wrong');
ok(doc.getElementById('hint').textContent.includes('Offshoot'), 'offC hint wrong');
ok(doc.getElementById('hint').textContent.includes('Animated'),
   'offC is animated now; the hint should say so');
ok(doc.getElementById('transport').classList.contains('on'),
   'offC is animated; transport should be on');

// --- the cap: three elements, three loss branches, one resting panel

// Panel 9 must equal the last frame of panel 8. If it does not, the figure is
// claiming an event happened between them that it never draws.
{
  window.selectStep('step08');
  const p8 = doc.getElementById('p-step08');
  const last = ANIM.step08.frames.length - 1;
  window.runAnimation('seek', last);
  const cst8 = p8.querySelector('#actor-cst').getAttribute('transform');
  const ku8  = p8.querySelector('#actor-ku').getAttribute('transform');
  const zon8 = [...p8.querySelectorAll('.zone')].map(z => z.getAttribute('class')).join('|');

  window.selectStep('step09');
  const p9 = doc.getElementById('p-step09');
  const zon9 = [...p9.querySelectorAll('.zone')].map(z => z.getAttribute('class')).join('|');
  ok(zon8 === zon9, 'step09 zones differ from the last frame of step08');

  // Priming is internal to the terminal Cdc13 footprint, so chunk 18 is never
  // filled in any frame rather than filled and then reverted. Capping is
  // continuous only if that holds, which is why this is checked across every
  // frame and not just the last one.
  window.selectStep('step08');
  for (let f = 0; f <= last; f++) {
    window.runAnimation('seek', f);
    ok(p8.querySelector('#z-c18').getAttribute('class').includes('ov'),
       'step08 frame ' + f + ': the terminal footprint is not single-stranded');
  }
  window.runAnimation('seek', last);
  ok(p8.querySelector('#actor-pola').classList.contains('gone'),
     'Pol alpha-primase is still drawn after fill-in has finished');
  // and the primer note appears for exactly one frame
  let primerFrames = 0;
  for (let f = 0; f <= last; f++) {
    window.runAnimation('seek', f);
    if (p8.querySelector('#fx-primerlab').classList.contains('shown')) { primerFrames++; }
  }
  ok(primerFrames === 1,
     'primer note shows on ' + primerFrames + ' frames, expected exactly 1');
  ok(ku8, 'step08 final frame leaves Ku unpositioned');
}

// Zones are derived, never declared. No frame table may name one.
{
  const A = ANIM;
  const declared = Object.keys(A).some(k =>
    A[k].frames.some(f => Object.keys(f.halves || {}).some(id => id.indexOf('z-') === 0)));
  ok(!declared, 'a frame table declares a zone; zones must stay derived');
}

// Ku is in every panel, and its base position is readable, or the derivation
// silently does nothing.
Object.keys(META).forEach(k => {
  const g = doc.querySelector('#p-' + k + ' #actor-ku');
  ok(g, k + ': Ku missing');
  if (g) {
    ok(!isNaN(parseFloat(g.getAttribute('data-basex'))),
       k + ': Ku has no usable data-basex');
  }
});

// Ku sits on the duplex side of the junction, never out on the overhang.
['step03', 'step06', 'step08'].forEach(k => {
  window.selectStep(k);
  const root = doc.getElementById('p-' + k);
  const g = root.querySelector('#actor-ku');
  const base = parseFloat(g.getAttribute('data-basex'));
  const m = (g.getAttribute('transform') || 'translate(0,0)').match(/-?\d+(\.\d+)?/g);
  const kuX = base + parseFloat(m[0]);
  let lastDuplex = 0;
  for (let i = 1; i <= 18; i++) {
    const id = 'c' + String(i).padStart(2, '0');
    const b = root.querySelector('#' + id + '-b');
    if (b && !b.classList.contains('gone') &&
        (!b.classList.contains('pending') || b.classList.contains('shown'))) {
      lastDuplex = i;
    }
  }
  ok(kuX <= 50 + lastDuplex * 42,
     k + ': Ku at ' + kuX + ' is past the junction at ' + (50 + lastDuplex * 42));
});

// The cap indicator: three slots, every panel, exactly one state each.
const CAP_STATES = ['on', 'thin', 'off', 'na', 'lost'];
Object.keys(META).forEach(k => {
  const slots = doc.querySelectorAll('#p-' + k + ' .capslot');
  ok(slots.length === 3, k + ': ' + slots.length + ' cap slots, expected 3');
  slots.forEach(sl => {
    const box = sl.querySelector('.capslotbox');
    const states = CAP_STATES.filter(st => box.classList.contains(st));
    ok(states.length === 1, k + ': cap slot has states [' + states + ']');
  });
});

// The indicator must agree with what the panel actually draws. This is the
// invariant the whole cap axis rests on: a slot reading "on" while only Cdc13
// is on the page was the original contradiction.
Object.keys(META).forEach(k => {
  const root = doc.getElementById('p-' + k);
  const box = root.querySelector('#capbase-cst');
  const state = CAP_STATES.find(st => box.classList.contains(st));
  const hasCST = !!root.querySelector('.cst');
  const hasCdc13 = !!root.querySelector('.cdc13');
  if (state === 'on') {
    ok(hasCST, k + ': CST reads on but the trimer is not drawn');
  }
  if (state === 'thin') {
    ok(!hasCST, k + ': CST reads thin but the assembled trimer is drawn');
  }
  if (state === 'off' || state === 'na' || state === 'lost') {
    ok(!hasCST && !hasCdc13,
       k + ': CST reads ' + state + ' but something is drawn on the overhang');
  }
});

// off and na are not interchangeable, and the resection panels are where the
// difference is load-bearing. na says there is no single-stranded TG1-3 for
// Cdc13 to bind; off says there is, and nothing telomere-specific is established
// on it. Reading either as thin says RPA is a reduced CST, which it is not.
//
// Both are now read off the DNA every frame, so these check the transition and
// not a declaration: panel 3 opens blunt and has to cross from one to the other
// on the frame the first repeat goes single-stranded.
{
  const cst = k => CAP_STATES.find(st =>
    doc.querySelector('#p-' + k + ' #capbase-cst').classList.contains(st));

  // Panel 2 is blunt throughout, so it never leaves na.
  window.selectStep('step02');
  ok(cst('step02') === 'na',
     'step02 should read na: a blunt end has nowhere for Cdc13 to bind');

  // Panel 3* opens on an end that already carries a bare chunk.
  window.selectStep('lag03');
  window.runAnimation('seek', 0);
  ok(cst('lag03') === 'off',
     'lag03 should read off at frame 0: the overhang is there before the panel opens');

  // Panel 3 opens blunt and crosses over when the first repeat is cleared.
  window.selectStep('step03');
  window.runAnimation('seek', 0);
  ok(cst('step03') === 'na', 'step03 should open na: frame 0 is still a blunt end');
  window.runAnimation('seek', 1);
  ok(cst('step03') === 'na',
     'step03 reports a CST substrate on a frame where the C-strand is still there');
  window.runAnimation('seek', 2);
  ok(cst('step03') === 'off',
     'step03: the first repeat is single-stranded and the slot has not moved');
  window.runAnimation('seek', ANIM.step03.frames.length - 1);
  ok(cst('step03') === 'off', 'step03 does not end on an unoccupied overhang');

  // No panel declares a CST flip any more: the whole ladder below lost is read
  // off the drawing.
  ['step02', 'step03', 'lag03', 'offA', 'offD'].forEach(k =>
    ok(!doc.querySelector('#p-' + k + ' #capflip-cst'),
       k + ' still declares a CST state that the engine derives'));
}

// The cap slots are derived twice, once in tools/make_panels.py for the resting
// picture and once in src/animate.js for every frame, from the same quantities.
// Nothing makes the two agree except this check, which is the same arrangement
// X0, CW and chunk_id are under.
{
  const WORDS = {
    rap1: { on: 'full array', thin: 'short array', off: 'none bound',
            na: 'no duplex', lost: 'array lost' },
    cst:  { on: 'assembled', thin: 'Cdc13 only', off: 'none established',
            na: 'no overhang', lost: 'CST lost' },
    ku:   { on: 'bound', thin: 'partial', off: 'none established',
            na: 'no junction', lost: 'Ku lost' }
  };
  const slots = ['rap1', 'cst', 'ku'];
  const stateOf = (k, sl) => {
    const el = doc.querySelector('#p-' + k + ' #capbase-' + sl);
    return CAP_STATES.find(st => el.classList.contains(st));
  };

  // What the generator wrote. Read from a second parse with no scripts run,
  // because by this point in the suite most panels have been selected and
  // painted, and the live DOM no longer holds the resting picture.
  const pristine = new JSDOM(html).window.document;
  const atRest = {};
  Object.keys(META).forEach(k => {
    atRest[k] = slots.map(sl => {
      const el = pristine.querySelector('#p-' + k + ' #capbase-' + sl);
      return CAP_STATES.find(st => el.classList.contains(st));
    }).join(',');
  });

  Object.keys(META).forEach(k => {
    window.selectStep(k);
    if (ANIM[k]) { window.runAnimation('seek', 0); }
    const painted = slots.map(sl => stateOf(k, sl)).join(',');
    ok(painted === atRest[k],
       k + ': make_panels.py writes [' + atRest[k] + '] and animate.js derives [' +
       painted + '] at frame 0');
  });

  // and every slot carries the word for the state it is in, in both pills
  Object.keys(META).forEach(k => {
    window.selectStep(k);
    slots.forEach(sl => {
      const st = stateOf(k, sl);
      const word = doc.querySelector('#p-' + k + ' #capbasest-' + sl);
      ok(word, k + ' ' + sl + ': no state word');
      if (word) {
        ok(word.textContent === WORDS[sl][st],
           k + ' ' + sl + ': reads "' + word.textContent + '" in state ' + st);
      }
      const flip = doc.querySelector('#p-' + k + ' #capflipst-' + sl);
      if (flip) {
        ok(flip.textContent === WORDS[sl].lost,
           k + ' ' + sl + ': loss pill reads "' + flip.textContent + '"');
      }
    });
  });
}

// The Rap1 slot is a count of duplex telomeric repeats, not of drawn boxes.
// Panel 5 draws three boxes and branch B five, but those counts were set by
// where MRX needs to sit; the states have to come from the DNA or the indicator
// reports the layout.
{
  const FULL = 12;                        // CAP_FULL_ARRAY in make_panels.py
  const duplexCount = k => {
    const r = doc.getElementById('p-' + k);
    let n = 0;
    for (let i = 1; i <= 18; i++) {
      const id = 'c' + String(i).padStart(2, '0');
      const t = r.querySelector('#' + id + '-t'), b = r.querySelector('#' + id + '-b');
      const on = el => el && !el.classList.contains('gone') &&
        (!el.classList.contains('pending') || el.classList.contains('shown'));
      if (on(t) && on(b)) { n++; }
    }
    return n;
  };
  const rap1 = k => {
    const el = doc.querySelector('#p-' + k + ' #capbase-rap1');
    return CAP_STATES.find(st => el.classList.contains(st));
  };

  Object.keys(META).forEach(k => {
    window.selectStep(k);
    const d = duplexCount(k);
    const want = d <= 0 ? 'na' : (d >= FULL ? 'on' : 'thin');
    const flip = doc.querySelector('#p-' + k + ' #capflip-rap1');
    if (flip && flip.classList.contains('shown')) { return; }
    ok(rap1(k) === want,
       k + ': ' + d + ' duplex repeats should read ' + want + ', reads ' + rap1(k));
  });

  // The comparison the branch exists to make. Same stage, same overhang, and
  // the only difference is how much array is left behind it.
  window.selectStep('step05');
  const short5 = rap1('step05');
  window.selectStep('offB');
  ok(short5 === 'thin' && rap1('offB') === 'on',
     'step05 reads ' + short5 + ' and offB ' + rap1('offB') +
     ': the long telomere is not reading as better capped');
  ok(duplexCount('offB') > duplexCount('step05'),
     'offB does not carry more duplex array than step05');

  // Fill-in is what restores the array, because Rap1 binds duplex and
  // telomerase makes single strand. So the slot recovers in panel 8 and not
  // in panel 6.
  window.selectStep('step06');
  window.runAnimation('seek', ANIM.step06.frames.length - 1);
  ok(rap1('step06') === 'thin',
     'step06 ends with the array restored, but extension makes single strand');
  window.selectStep('step08');
  window.runAnimation('seek', 0);
  const before = rap1('step08');
  window.runAnimation('seek', ANIM.step08.frames.length - 1);
  ok(before === 'thin' && rap1('step08') === 'on',
     'step08 goes ' + before + ' to ' + rap1('step08') + ': fill-in should restore the array');

  // Resection takes it the other way, in the panel that does the resecting.
  window.selectStep('step03');
  window.runAnimation('seek', 0);
  const openWith = rap1('step03');
  window.runAnimation('seek', ANIM.step03.frames.length - 1);
  ok(openWith === 'on' && rap1('step03') === 'thin',
     'step03 goes ' + openWith + ' to ' + rap1('step03') +
     ': resection removes duplex from under the array');
}

// Loss is declared where the drawing cannot show it. Branch D keeps every
// repeat and only loses the protein, so the duplex the array sat on is still on
// the page and a derivation left to itself would go on reporting a full array.
// That is the case the declared pill exists for.
{
  window.selectStep('offD');
  window.runAnimation('seek', ANIM.offD.frames.length - 1);
  const flip = doc.querySelector('#p-offD #capflip-rap1');
  ok(flip && flip.classList.contains('shown'), 'offD never declares the Rap1 loss');
  const base = doc.querySelector('#p-offD #capbase-rap1');
  ok(base.classList.contains('gone'),
     'offD shows both Rap1 pills at once');
  ok(doc.querySelector('#p-offD #capflipst-rap1').textContent === 'array lost',
     'offD loss pill does not say what was lost');
  // and the two slots the branch does not name derive to on, because the
  // overhang and the junction are both untouched here
  ['cst', 'ku'].forEach(sl => {
    const el = doc.querySelector('#p-offD #capbase-' + sl);
    ok(CAP_STATES.find(st => el.classList.contains(st)) === 'on',
       'offD: the ' + sl + ' slot reads ' +
       CAP_STATES.find(st => el.classList.contains(st)) + ', but nothing took it');
  });
}

// Branch A is the inverse and declares nothing at all. Telomerase is not a cap
// element, so no slot is lost in capbar's sense; the substrate runs out and all
// three slots follow the DNA down on their own. A declared pill here would
// overwrite the claim instead of protecting it.
{
  ok(!doc.querySelector('#p-offA [id^="capflip-"]'),
     'offA declares a cap loss, but nothing was removed from the cap');
  window.selectStep('offA');
  window.runAnimation('seek', ANIM.offA.frames.length - 1);
  const st = sl => {
    const el = doc.querySelector('#p-offA #capbase-' + sl);
    return CAP_STATES.find(c => el.classList.contains(c));
  };
  ok(st('rap1') === 'na',
     'offA: the Rap1 slot reads ' + st('rap1') + ', so the array was not exhausted');
  ok(st('cst') === 'na',
     'offA: the CST slot reads ' + st('cst') + ', but there is no overhang left');
  ok(doc.querySelector('#p-offA #capbasest-rap1').textContent === 'no duplex',
     'offA: the Rap1 slot does not say the duplex is what went');
}

// Branch C is the case that made the declared version wrong: the array recedes
// with the C strand and the pill used to claim a complete one throughout.
{
  window.selectStep('offC');
  const rap1C = () => CAP_STATES.find(st =>
    doc.querySelector('#p-offC #capbase-rap1').classList.contains(st));
  window.runAnimation('seek', 0);
  ok(rap1C() === 'on', 'offC does not open on an intact array');
  const seen = new Set();
  for (let f = 0; f < ANIM.offC.frames.length; f++) {
    window.runAnimation('seek', f);
    seen.add(rap1C());
  }
  ok(seen.has('thin'), 'offC never passes through a partial array');
  ok(rap1C() === 'na', 'offC ends with duplex gone but the slot reads ' + rap1C());
}

// The cap indicator key: one dialog, closed at load, reachable and dismissable.
{
  const btn = doc.getElementById('capkeybtn');
  const modal = doc.getElementById('capkey');
  ok(btn && modal, 'the cap indicator key is missing');
  ok(modal && !modal.classList.contains('open'), 'the cap key is open at load');
  ok(modal && modal.getAttribute('role') === 'dialog', 'the cap key is not a dialog');
  // every state and every slot is explained, or the figure needs a legend after all
  const text = modal ? modal.textContent : '';
  ['full array', 'short array', 'none bound', 'no duplex', 'array lost',
   'assembled', 'Cdc13 only', 'none established', 'no overhang', 'CST lost',
   'bound', 'no junction', 'Ku lost'].forEach(w =>
    ok(text.indexOf(w) !== -1, 'the cap key does not explain "' + w + '"'));

  btn.dispatchEvent(new window.Event('click', { bubbles: true }));
  ok(modal.classList.contains('open'), 'the cap key does not open');
  const esc = new window.KeyboardEvent('keydown', { key: 'Escape', bubbles: true });
  doc.dispatchEvent(esc);
  ok(!modal.classList.contains('open'), 'Escape does not close the cap key');
  btn.dispatchEvent(new window.Event('click', { bubbles: true }));
  doc.getElementById('capkeyclose').dispatchEvent(
    new window.Event('click', { bubbles: true }));
  ok(!modal.classList.contains('open'), 'the close button does not close the cap key');
}
window.selectStep('step01');

// Elongation runs on a telomere in the extendable state, which is defined by
// the trimer not being assembled on Cdc13. Panels 4 through 7 draw Cdc13
// alone, so none of them may claim a complete CST.
['step04', 'step05', 'step06', 'step07', 'offB'].forEach(k => {
  const box = doc.querySelector('#p-' + k + ' #capbase-cst');
  ok(box.classList.contains('thin'),
     k + ': CST should read thin while Stn1-Ten1 are off the telomere');
});

// Rif1 is not a cap element. It is drawn on the Rap1 boxes, so the only place
// this can be asserted is the indicator.
Object.keys(META).forEach(k => {
  ok(!doc.querySelector('#p-' + k + ' .capbar').textContent.includes('Rif1'),
     k + ': Rif1 is in the cap indicator, but it does not do protection');
});

// Processing happens on a capped telomere. If any main-line panel reads "lost",
// the figure is claiming wild-type cells uncap every S phase.
ORDER.forEach(k => {
  ok(!doc.querySelector('#p-' + k + ' .capslotbox.lost'),
     k + ': a main-line panel reports a lost cap element');
});
['step03', 'lag03'].forEach(k =>
  ok(!doc.querySelector('#p-' + k + ' #capbase-cst').classList.contains('thin'),
     k + ': CST reads thin, which says RPA is a reduced CST'));

// Clicking a cap element opens the branch where it is lost.
{
  const gotos = [...doc.querySelectorAll('#p-step09 [data-goto]')]
                  .map(el => el.dataset.goto);
  ok(gotos.length === 3, 'step09 has ' + gotos.length + ' mutate targets, expected 3');
  ['offC', 'offD', 'offE'].forEach(t => {
    ok(gotos.indexOf(t) !== -1, 'step09 has no way to reach ' + t);
    ok(META[t], t + ' has no metadata');
    ok(doc.getElementById('p-' + t), t + ' has no panel');
    ok(doc.querySelector('.node[data-key="' + t + '"]'), t + ' has no nav node');
  });
  // and the affordance has to be reachable without a mouse
  [...doc.querySelectorAll('#p-step09 [data-goto]')].forEach(el =>
    ok(el.getAttribute('tabindex') === '0', 'a mutate target is not focusable'));
}

// Each loss branch must lose exactly the element it is named for.
[['offC', 'CST'], ['offD', 'Rap1'], ['offE', 'Ku']].forEach(pair => {
  const lost = [...doc.querySelectorAll('#p-' + pair[0] + ' .capslotbox.lost')];
  ok(lost.length === 1, pair[0] + ': ' + lost.length + ' elements lost, expected 1');
  const lab = doc.querySelector('#p-' + pair[0] + ' .capslotlab.lost');
  ok(lab && lab.textContent === pair[1],
     pair[0] + ' loses ' + (lab && lab.textContent) + ', expected ' + pair[1]);
});

// The three branches share an opening beat. Frame 0 of each must be the step 9
// telomere, or the mutation reads as a different chromosome rather than as
// something that happened to this one.
{
  window.selectStep('step09');
  const shape = k => [...doc.querySelectorAll('#p-' + k + ' .zone')]
                       .map(z => z.getAttribute('class')).join('|');
  const capped = shape('step09');
  // Branch A opens on the same telomere as the three loss branches, because it
  // is the same chromosome before anything has happened to it. It is not in the
  // second list: it removes no cap element and so declares no flip.
  ['offA', 'offC', 'offD', 'offE'].forEach(k => {
    ok(ANIM[k], k + ' should be animated now');
    window.selectStep(k);
    window.runAnimation('seek', 0);
    ok(shape(k) === capped, k + ' frame 0 is not the step 9 telomere');
    // and the cap must start whole, whatever it loses later
    const boxes = ['rap1', 'cst', 'ku'].map(sl =>
      doc.querySelector('#p-' + k + ' #capbase-' + sl));
    ok(boxes.every(b => b.classList.contains('on') && !b.classList.contains('gone')),
       k + ' frame 0 does not show an intact cap');
  });
  ['offC', 'offD', 'offE'].forEach(k => {
    window.selectStep(k);
    window.runAnimation('seek', 0);
    // exactly one slot flips, and only after frame 0
    const flips = doc.querySelectorAll('#p-' + k + ' [id^="capflip-"]');
    ok(flips.length >= 1, k + ' has no cap slot that changes');
    flips.forEach(f => ok(!f.classList.contains('shown'),
       k + ' flips a cap slot on frame 0, before the mutation'));
  });
}

// Each loss branch fades its element out before anything follows from it, so
// the mutation reads as an event rather than as a difference between frame 0
// and whatever frame 1 was already doing.
{
  const beats = [['offC', '#actor-cst'], ['offD', '#rap1-01'], ['offE', '#actor-ku']];
  beats.forEach(pair => {
    const key = pair[0], sel = pair[1];
    window.selectStep(key);
    const el = () => doc.querySelector('#p-' + key + ' ' + sel);
    ok(el(), key + ': ' + sel + ' missing, so nothing can fade');
    window.runAnimation('seek', 0);
    ok(el() && !el().classList.contains('fading') && !el().classList.contains('gone'),
       key + ' frame 0 should show the element intact');
    window.runAnimation('seek', 1);
    ok(el() && el().classList.contains('fading'),
       key + ' frame 1 should fade the element it is named for');
    ok(el() && !el().classList.contains('gone'),
       key + ' frame 1 removes the element outright instead of fading it');
    window.runAnimation('seek', ANIM[key].frames.length - 1);
    ok(el() && el().classList.contains('gone'),
       key + ': the faded element never actually goes');
  });
}

// The fade needs the element to be resettable, or the state smears into the
// next scrub. clearAnimationClasses only reaches ".half, .fx".
['offC','offD','offE'].forEach(k => {
  ['#actor-cst','#actor-ku'].forEach(sel => {
    const el = doc.querySelector('#p-' + k + ' ' + sel);
    if (el) {
      ok(el.classList.contains('fx'),
         k + ' ' + sel + ' is not .fx, so a faded state survives the reset');
    }
  });
});
{
  window.selectStep('offC');
  window.runAnimation('seek', ANIM.offC.frames.length - 1);
  window.selectStep('step09');
  window.selectStep('offC');
  const cstC = doc.querySelector('#p-offC #actor-cst');
  ok(!cstC.classList.contains('gone') && !cstC.classList.contains('fading'),
     'offC: stale CST loss state survived the reset');
}

// The indicator flips after the fade, not with it: on the beat where the
// element fades it is still on the page, so the cap is still whole.
['offC','offD','offE'].forEach(k => {
  window.selectStep(k);
  window.runAnimation('seek', 1);
  doc.querySelectorAll('#p-' + k + ' [id^="capflip-"]').forEach(f =>
    ok(!f.classList.contains('shown'),
       k + ' flips the cap indicator while the element is still drawn'));
});

// Rap1 recedes because it is derived, not because a frame says so. Branch C
// never names a Rap1 box, and the array still has to shrink.
{
  const named = ANIM.offC.frames.some(f =>
    Object.keys(f.halves || {}).some(id => id.indexOf('rap1-') === 0));
  ok(!named, 'offC declares a Rap1 box; in branch C the array must be derived');
  window.selectStep('offC');
  const count = () => [...doc.querySelectorAll('#p-offC .rap1')]
                        .filter(g => !g.classList.contains('gone')).length;
  window.runAnimation('seek', 0);
  const before = count();
  window.runAnimation('seek', ANIM.offC.frames.length - 1);
  ok(count() < before,
     'offC: the Rap1 array did not recede with the C-strand (' + before +
     ' boxes throughout)');
}

// The two partners are drawn in opposite vocabularies, and that is the whole
// distinction between the branches. Branch A fuses two ends that ran out of
// repeats, so its partner is unique sequence. Branch D fuses two ends that kept
// theirs and lost the protein, so its partner is a telomere. Both run off the
// right edge, because both are the rest of a chromosome and neither is a
// fragment, and both ride the camera, so their coordinates are DNA coordinates
// and the edge test has to add the pan.
{
  const panOf = k => Math.max.apply(null,
    ANIM[k].frames.map(f => Math.abs((f.actors || {})['actor-camera'] || 0)));
  const edge = (k, sel, dir) => {
    const blocks = [...doc.querySelectorAll('#p-' + k + ' ' + sel + ' .half')];
    const right = Math.max(...blocks.map(g => {
      const r = g.querySelector('.halfbody');
      return parseFloat(r.getAttribute('x')) + parseFloat(r.getAttribute('width'));
    }));
    return right + dir * panOf(k);
  };

  const pA = doc.querySelector('#p-offA .partner');
  ok(pA, 'offA has no partner end');
  const blocksA = [...pA.querySelectorAll('.half')];
  ok(blocksA.length >= 8,
     'offA partner is ' + blocksA.length + ' halves, which cannot reach the edge');
  blocksA.forEach(g => {
    ok(g.classList.contains('ustrand'), 'offA partner block is not unique sequence');
    const t = g.querySelector('.halflab');
    ok(t && t.textContent === 'U',
       'offA partner block is lettered ' + (t && t.textContent) + ', expected U');
    ok(!g.id, 'offA partner block carries an id, which collides with the u-series');
  });
  ok(edge('offA', '.partner', 1) > 880,
     'offA partner ends at ' + edge('offA', '.partner', 1) +
     ' on screen, inside the 880 viewBox');

  const pD = doc.querySelector('#p-offD .partnertel');
  ok(pD, 'offD has no partner telomere');
  const blocksD = [...pD.querySelectorAll('.half')];
  ok(blocksD.length >= 8,
     'offD partner is ' + blocksD.length + ' halves, which cannot reach the edge');
  ok(blocksD.some(g => g.classList.contains('gstrand')) &&
     blocksD.some(g => g.classList.contains('cstrand')),
     'offD partner is not drawn in repeat vocabulary, which is what separates it from A');
  ok(!blocksD.some(g => g.classList.contains('ustrand')),
     'offD partner carries unique sequence, which is branch A\u0027s claim and not this one');
  ok(!pD.querySelector('.rap1'),
     'offD partner carries Rap1, but the depletion is not chromosome-specific');
  blocksD.forEach(g =>
    ok(!g.id, 'offD partner block carries an id, which collides with the c-series'));
  ok(edge('offD', '.partnertel', -1) > 880,
     'offD partner ends at ' + edge('offD', '.partnertel', -1) +
     ' on screen, inside the 880 viewBox');
}

// Each branch has to clear the space its partner needs before the partner
// arrives, and the two clear it in opposite ways: A by erosion, D by panning.
{
  window.selectStep('offA');
  window.runAnimation('seek', ANIM.offA.frames.length - 1);
  const rap1A = [...doc.querySelectorAll('#p-offA .rap1')]
                  .filter(g => !g.classList.contains('gone')).length;
  ok(rap1A === 0, 'offA still shows ' + rap1A + ' Rap1 boxes on an exhausted array');
  ok(doc.querySelector('#p-offA #fx-partner').classList.contains('shown'),
     'offA never brings in a second chromosome end');
  const namedA = ANIM.offA.frames.some(f =>
    Object.keys(f.halves || {}).some(id => id.indexOf('rap1-') === 0));
  ok(!namedA, 'offA declares a Rap1 box; here the array must recede with the DNA');
  const partnerA = ANIM.offA.frames.findIndex(f =>
    (f.halves || {})['fx-partner'] === 'present');
  const erosionA = ANIM.offA.frames.findIndex(f =>
    (f.halves || {})['c18-t'] === 'fading' || (f.halves || {})['c18-t'] === 'gone');
  ok(erosionA > -1 && partnerA > erosionA,
     'offA: the partner end arrives before erosion has freed the space');
  // and the erosion has to reach the first repeat, not stop in the array
  const last = ANIM.offA.frames[ANIM.offA.frames.length - 1].halves || {};
  ok(last['c01-t'] === 'gone' && last['c01-b'] === 'gone',
     'offA leaves chunk 1 standing, so the array is short and not exhausted');
}
{
  window.selectStep('offD');
  window.runAnimation('seek', ANIM.offD.frames.length - 1);
  const showing = [...doc.querySelectorAll('#p-offD .rap1')]
                    .filter(g => !g.classList.contains('gone')).length;
  ok(showing === 0, 'offD still shows ' + showing + ' Rap1 boxes after the loss');
  ok(doc.querySelector('#p-offD #fx-partner').classList.contains('shown'),
     'offD never brings in a second telomere');
  // Mirrors tools/make_panels.py: the resting C strand stops one repeat short
  // of the G strand, which is the overhang the panel starts with.
  const N_REST = 17;
  const shown = el => el && !el.classList.contains('gone') &&
                (!el.classList.contains('pending') || el.classList.contains('shown'));
  // No repeat is lost. Branch A takes the sequence away and the proteins follow;
  // this panel takes the protein away and the sequence stays, and the G strand
  // is where that shows.
  for (let i = 1; i <= 18; i++) {
    const id = 'c' + String(i).padStart(2, '0');
    ok(shown(doc.querySelector('#p-offD #' + id + '-t')),
       'offD: ' + id + ' lost a repeat, but this array keeps all of them');
  }
  // The 3' terminus is fixed. Nothing is added past where elongation stops, and
  // an earlier version grew the G strand outward, which reads as telomerase
  // acting in a panel whose phase is outside the window telomerase acts in.
  ANIM.offD.frames.forEach((f, n) => Object.keys(f.halves || {}).forEach(id => {
    const m = /^c(\d\d)-t$/.exec(id);
    ok(!m || +m[1] <= N_REST,
       'offD frame ' + n + ': ' + id + ' extends the G strand past the resting terminus');
  }));
  // What moves is the C strand, inward, and it stops well short of branch E's.
  const cGone = i => !shown(doc.querySelector('#p-offD #c' +
                            String(i).padStart(2, '0') + '-b'));
  let receded = 0;
  for (let i = N_REST; i >= 1 && cGone(i); i--) { receded++; }
  ok(receded > 0, 'offD: the C strand never recedes, so there is no overhang to hold');
  ok(receded <= 4,
     'offD: the C strand receded ' + receded + ' repeats, which is branch E territory');
  const eRec = (() => {
    window.selectStep('offE');
    window.runAnimation('seek', ANIM.offE.frames.length - 1);
    let n = 0;
    for (let i = N_REST; i >= 1; i--) {
      const el = doc.querySelector('#p-offE #c' + String(i).padStart(2, '0') + '-b');
      if (shown(el)) { break; }
      n++;
    }
    return n;
  })();
  ok(eRec > receded,
     'offE recedes ' + eRec + ' and offD ' + receded +
     ': E has to run further, because its slot falls and D declares');
  window.selectStep('offD');
  window.runAnimation('seek', ANIM.offD.frames.length - 1);
  // and the recession has to finish before the partner arrives, or the panel
  // reads as though the resection caused the fusion
  const lastRec = ANIM.offD.frames.reduce((acc, f, n) =>
    Object.keys(f.halves || {}).some(id =>
      /^c\d\d-b$/.test(id) && f.halves[id] === 'fading') ? n : acc, -1);
  const partnerD = ANIM.offD.frames.findIndex(f =>
    (f.halves || {})['fx-partner'] === 'present');
  ok(lastRec > -1 && partnerD > lastRec + 1,
     'offD: the second telomere enters before the recession has settled');
  // the camera holds still until then: with the terminus fixed there is
  // nothing for it to follow
  ok(ANIM.offD.frames.slice(0, partnerD)
       .every(f => (f.actors || {})['actor-camera'] === 0),
     'offD pans before the fusion, but nothing moved for it to follow');
}

// Branch E keeps CST on the terminus while the tail grows inward.
{
  window.selectStep('offE');
  window.runAnimation('seek', ANIM.offE.frames.length - 1);
  const cst = doc.querySelector('#p-offE .cst');
  ok(cst && !cst.classList.contains('gone'),
     'offE should keep CST on the end: this is partial uncapping');
  ok(doc.querySelector('#p-offE #capbase-cst').classList.contains('on'),
     'offE should not report CST lost');
}

// --- unique sequence and the camera

const N_UNIQUE = 14;          // mirrors tools/make_panels.py
const MAX_PAN = 420;          // the furthest any panel pans, which is offA
const CAPPED = ['step09', 'offA', 'offC', 'offD', 'offE'];

// Every panel is a picture of a telomere on a chromosome, so every panel draws
// the sequence the array sits on. Only the capped ones carry a camera, because
// only branch C ever looks at it.
Object.keys(META).forEach(k => {
  window.selectStep(k);
  const root = doc.getElementById('p-' + k);
  const dna = root.querySelector('.dna');
  ok(dna && dna.getAttribute('data-unique') === String(N_UNIQUE),
     k + ' declares data-unique="' + (dna && dna.getAttribute('data-unique')) + '"');
  ok(root.querySelector('.uniqueband'), k + ' has no unique region band');
  for (let n = 1; n <= N_UNIQUE; n++) {
    const id = 'u' + String(n).padStart(2, '0');
    const t = root.querySelector('#' + id + '-t');
    const b = root.querySelector('#' + id + '-b');
    ok(t && b, k + ': ' + id + ' is missing a half');
    // Unique sequence is duplex at rest everywhere. Only branch C degrades a
    // C-strand out here, and only as far as its front reaches.
    ok(t && !t.classList.contains('pending'), k + ': ' + id + '-t starts hidden');
    ok(b && !b.classList.contains('pending'), k + ': ' + id + '-b starts hidden');
    ok(t && t.querySelector('.halflab').textContent === 'U',
       k + ': ' + id + ' is not lettered U');
  }
});

// The block is the rest of the chromosome, so the pan must never reach its end.
// cx(i) = 50 + (i - 1) * 42, and the leftmost chunk is at index 1 - N_UNIQUE.
{
  const leftEdge = 50 + ((1 - N_UNIQUE) - 1) * 42;
  ok(leftEdge + MAX_PAN < 0,
     'the unique block ends on camera: its left edge reaches ' +
     (leftEdge + MAX_PAN) + ' at full pan, and anything above 0 is visible');
  const pans = Object.keys(ANIM).flatMap(k =>
    ANIM[k].frames.map(f => (f.actors || {})['actor-camera'] || 0));
  ok(Math.max.apply(null, pans) <= MAX_PAN,
     'a frame table pans past ' + MAX_PAN + ', which the block was sized for');
  // A leftward pan cannot bring the left edge on, but it can carry the far end
  // of the array off the right one, which is branch D's cost and is bounded by
  // what that panel needs rather than by the block.
  ok(Math.min.apply(null, pans) >= -252,
     'a frame table pans further left than branch D was laid out for');
}

CAPPED.forEach(k => {
  const root = doc.getElementById('p-' + k);
  ok(root.querySelector('#actor-camera'), k + ' has no camera group');
});
['step01', 'step03', 'step06', 'step08'].forEach(k => {
  const root = doc.getElementById('p-' + k);
  ok(!root.querySelector('#actor-camera'),
     k + ' has a camera it never moves');
});

// The region label is only readable once the pan has brought it in. At rest it
// sits at x -33, so an always-on bracket puts clipped text at the left edge of
// every panel in the figure. It must therefore appear exactly when the camera
// moves, and never otherwise.
{
  Object.keys(META).forEach(k => {
    window.selectStep(k);
    const lab = doc.querySelector('#p-' + k + ' #fx-uniquespan');
    ok(lab, k + ' has no unique-region bracket at all');
    ok(lab && !lab.classList.contains('shown'),
       k + ' shows the unique-region label at rest, where it is off the page');
  });
  // The test is the pan direction and not the pan. A rightward pan is what
  // brings the block on screen, so branch C and branch A both have to turn the
  // label on. Branch D pans the other way, which sends the block further off the
  // left edge, so its label must stay off throughout.
  ['offA', 'offC', 'offD'].forEach(k => {
    window.selectStep(k);
    ANIM[k].frames.forEach((f, i) => {
      const panned = ((f.actors || {})['actor-camera'] || 0) > 0;
      window.runAnimation('seek', i);
      const on = doc.querySelector('#p-' + k + ' #fx-uniquespan')
                    .classList.contains('shown');
      ok(on === panned,
         k + ' frame ' + i + ': label ' + (on ? 'on' : 'off') +
         ' while the camera is ' + (panned ? 'panned' : 'at rest'));
    });
  });
}

// The camera moves the DNA and nothing else. Panel furniture that slid with it
// would be claiming to be part of the molecule.
{
  const root = doc.getElementById('p-offC');
  const cam = root.querySelector('#actor-camera');
  const inside = sel => !!cam.querySelector(sel);
  ['.dna', '.zones', '.uniqueband', '#actor-ku', '#actor-cst', '#fx-exo1',
   '#fx-bracketC', '#rpa-u04'].forEach(sel =>
    ok(inside(sel), 'offC: ' + sel + ' should ride the camera'));
  ['.capbar', '#fx-mec1', '#fx-ddc2', '#fx-rad9', '#fx-rad53'].forEach(sel =>
    ok(!inside(sel), 'offC: ' + sel + ' must not ride the camera'));
}

// The camera holds still until it has to move, then never goes back. A pan that
// reversed would be the panel changing its mind about where it is looking.
{
  // Three panels move the camera and each moves it one way only. A pan that
  // reversed would be the panel changing its mind about where it is looking.
  // Branch A and branch C follow their ends right; branch D follows its tail and
  // then its partner left.
  [['offA', 1], ['offC', 1], ['offD', -1]].forEach(pair => {
    const key = pair[0], dir = pair[1];
    const c = ANIM[key].frames.map(f => (f.actors || {})['actor-camera'] || 0);
    ok(c[0] === 0, key + ' opens with the camera already panned');
    for (let i = 1; i < c.length; i++) {
      ok(dir * c[i] >= dir * c[i - 1],
         key + ' frame ' + i + ': camera reversed, ' + c[i - 1] + ' to ' + c[i]);
    }
    ok(dir * c[c.length - 1] > 0, key + ' never actually pans');
  });
  const cams = ANIM.offC.frames.map(f => (f.actors || {})['actor-camera'] || 0);
  // Exo1 must stay in the viewBox once the camera is following it. The box is
  // drawn at x 660 and is 76 wide.
  ANIM.offC.frames.forEach((f, i) => {
    const ex = (f.actors || {})['actor-exo1'];
    if (ex === undefined) { return; }
    const left = 660 + ex + ((f.actors || {})['actor-camera'] || 0);
    ok(left > 0 && left < 880,
       'offC frame ' + i + ': Exo1 sits at ' + left + ', outside the viewBox');
  });
}

// Branch C's whole point: the front crosses out of the repeats. Ku has to come
// with it, which is what the lower bound in paintDerived buys.
{
  window.selectStep('offC');
  const pC = doc.getElementById('p-offC');
  const shown = el => el && !el.classList.contains('gone') &&
                (!el.classList.contains('pending') || el.classList.contains('shown'));

  window.runAnimation('seek', ANIM.offC.frames.length - 1);
  for (let n = 1; n <= 4; n++) {
    ok(shown(pC.querySelector('#u0' + n + '-t')),
       'offC: u0' + n + ' lost its G-strand, but only the C-strand is degraded');
    ok(!shown(pC.querySelector('#u0' + n + '-b')),
       'offC: u0' + n + ' still has its C-strand at the last frame');
    ok(pC.querySelector('#z-u0' + n).getAttribute('class').includes('ov'),
       'offC: u0' + n + ' is not marked single-stranded once resected');
  }
  ok(shown(pC.querySelector('#rpa-u04')),
     'offC: the deepest unique repeat carries no RPA');
  // Crossing the boundary is the claim. Eating the chromosome is not, so the
  // front stops and everything beyond it stays duplex.
  for (let n = 5; n <= N_UNIQUE; n++) {
    const id = 'u' + String(n).padStart(2, '0');
    ok(shown(pC.querySelector('#' + id + '-b')),
       'offC: resection ran past its front and took ' + id);
  }

  // Ku tracks the junction across the boundary rather than parking on chunk 1.
  const kuAt = () => {
    const g = pC.querySelector('#actor-ku');
    const m = (g.getAttribute('transform') || 'translate(0,0)').match(/-?\d+(\.\d+)?/g);
    return parseFloat(g.getAttribute('data-basex')) + parseFloat(m[0]);
  };
  window.runAnimation('seek', 11);
  const beforeBoundary = kuAt();
  window.runAnimation('seek', 13);
  const afterBoundary = kuAt();
  ok(afterBoundary < 50,
     'offC: Ku stopped at ' + afterBoundary + ', which is still inside the array');
  ok(afterBoundary < beforeBoundary,
     'offC: Ku did not follow the front past chunk 1');

  // Once nothing in the drawn region is duplex there is no chunk to be flush
  // against, and the fallback has to put Ku somewhere the reader can see. The
  // failure this guards is silent: actor transforms are cleared every frame, so
  // declining to position Ku sends it back to its resting coordinate, which in
  // a panned panel is off the right edge.
  ANIM.offC.frames.forEach((f, i) => {
    window.runAnimation('seek', i);
    const onScreen = kuAt() + ((f.actors || {})['actor-camera'] || 0);
    ok(onScreen > -30 && onScreen < 880,
       'offC frame ' + i + ': Ku sits at ' + onScreen + ', outside the viewBox');
  });
}

// Branch E gains the checkpoint under a named condition. Without the strip the
// last frames read as the steady state continuing rather than as a shift.
{
  const F = ANIM.offE.frames;
  const on = (f, id) => (f.halves || {})[id] === 'present';
  const condFrames = F.map((f, i) => on(f, 'fx-condition') ? i : -1).filter(i => i >= 0);
  ok(condFrames.length === 3,
     'offE: condition strip shows on ' + condFrames.length + ' frames, expected 3');
  ok(condFrames[0] === F.length - 3, 'offE: the condition strip does not close the panel');
  F.forEach((f, i) => {
    if (on(f, 'fx-rad53') || on(f, 'fx-ddc2')) {
      ok(on(f, 'fx-condition'),
         'offE frame ' + i + ': checkpoint without a condition marker');
    }
  });
  // Nothing further happens to the DNA in those frames. The same lesion crosses
  // a threshold, which is the whole claim.
  const dnaOf = f => Object.keys(f.halves || {})
    .filter(id => /^(c\d\d|u\d\d)-/.test(id) || id.indexOf('rpa-') === 0)
    .sort().map(id => id + ':' + f.halves[id]).join('|');
  ok(dnaOf(F[F.length - 4]) === dnaOf(F[F.length - 1]),
     'offE: the DNA changes during the checkpoint frames');
  const pair = f => [(f.actors || {})['actor-exo1'], (f.actors || {})['actor-sgs1']];
  F.slice(-3).forEach((f, n) => ok(pair(f)[0] === -390 && pair(f)[1] === -390,
    'offE checkpoint frame ' + n + ': the nucleases snapped back'));
}

// The condition strip belongs to branch E alone. Branch C is one condition
// throughout, so a strip there would be marking a shift that never happens.
{
  ok(doc.querySelector('#p-offE #fx-condition'), 'offE has no condition strip');
  // Branch D is the second user: the degron is a shift like the temperature
  // shift is. The assertions above stay scoped to branch E, because branch E is
  // the panel where nothing on the DNA changes after the shift and branch D is
  // the panel where everything does.
  ok(doc.querySelector('#p-offD #fx-condition'), 'offD has no condition strip');
  ['offA', 'offC', 'step09'].forEach(k =>
    ok(!doc.querySelector('#p-' + k + ' #fx-condition'),
       k + ' carries a condition strip it has no use for'));
}

// --- 3' and 5' end marks

// Both ends are read off the same visibility everything else is read off, so
// they cannot disagree with the strand they mark. The rule is one line: the 3'
// end is the far side of the rightmost surviving G block, the 5' end the far
// side of the rightmost surviving C block.
{
  const edge = (i, dx) => 50 + i * 42 - 2 + dx;
  const read = (k, id) => {
    const e = doc.querySelector('#p-' + k + ' #' + id);
    return e ? { x: parseFloat(e.getAttribute('x')),
                 off: e.classList.contains('off') } : null;
  };
  // selectStep reloads the panel at frame 0, so it is called once per panel
  // here and never inside a seek loop.
  const marks = (k, frame) => {
    window.selectStep(k);
    if (frame !== undefined) { window.runAnimation('seek', frame); }
    return { three: read(k, 'end3'), five: read(k, 'end5') };
  };
  // Every other panel opens on a whole molecule. These two open on a fork
  // part-way through making one, so the strand being synthesised does not
  // exist yet and an end mark on it would be a claim about DNA that is not
  // there. Both are read at their last frame instead, which is the product.
  const SYNTH = { step01: true, lag01: true };
  const settled = k => (SYNTH[k] ? ANIM[k].frames.length - 1 : undefined);

  Object.keys(META).forEach(k => {
    const m = marks(k, settled(k));
    ok(m.three && m.five, k + ' is missing an end mark');
    ok(m.three && !m.three.off, k + ": the 3' mark is hidden on an intact strand");
    ok(m.five && !m.five.off, k + ": the 5' mark is hidden on an intact strand");
    // The 3' end is the outermost point of the molecule. It cannot be inside
    // the 5' end, in any panel, at any frame: that would be a negative overhang.
    ok(m.three.x >= m.five.x,
       k + ": the 3' mark sits inside the 5' mark");
    // Both ride the camera, because both are features of the molecule.
    const cam = doc.querySelector('#p-' + k + ' #actor-camera');
    if (cam) {
      ok(cam.querySelector('#end3') && cam.querySelector('#end5'),
         k + ': an end mark is outside the camera group');
    }
  });

  // A blunt terminus has both ends on the same chunk, and a resected or
  // elongated one does not.
  const blunt = marks('step01', settled('step01'));
  ok(blunt.three.x - blunt.five.x === 9,
     'step01 does not finish blunt: its two ends are on different chunks');
  // The lagging end is the opposite case and the reason the split exists: it
  // finishes with the 3' end one whole repeat past the 5' end, with no
  // resection having happened to it.
  const tail = marks('lag01', settled('lag01'));
  ok(tail.three.x - tail.five.x === 42 + 9,
     'lag01 should finish with a one-repeat overhang, got ' +
     (tail.three.x - tail.five.x));
  ok(marks('step09').three.x === edge(18, 8),
     "step09: the 3' end is not on the elongated terminus");
  ok(marks('step09').five.x === edge(17, -1),
     "step09: the 5' end is not on the last filled-in repeat");

  // Resection moves the 5' end and leaves the 3' end alone, which is the whole
  // point of drawing both. In branch C it ends up outside the repeat array.
  window.selectStep('offC');
  let prev = Infinity;
  ANIM.offC.frames.forEach((f, i) => {
    window.runAnimation('seek', i);
    const five = read('offC', 'end5'), three = read('offC', 'end3');
    ok(five.x <= prev,
       "offC frame " + i + ": the 5' end moved outward during resection");
    prev = five.x;
    ok(three.x === edge(18, 8),
       "offC frame " + i + ": the 3' end moved, but only the C-strand is degraded");
  });
  ok(prev < 50, "offC: the 5' end finished at " + prev + ', still inside the array');
}

// --- offshoots and numbering
window.selectStep('offB');
// Checked across caption and note together. The claim it protects is that the
// Rif2 competition is drawn as an absence rather than stated, which is drawing
// rationale, so a caption rewrite is expected to move this wording into the
// note rather than delete it. Either location satisfies the test; neither does
// not.
ok((doc.getElementById('cap').textContent +
    ' ' + doc.getElementById('note').textContent)
     .includes('no socket, no pole, no flag'),
   'offB caption and note both missing the displacement wording');
ok(doc.getElementById('hint').textContent.includes('Offshoot'), 'offB hint wrong');

// --- keyboard traversal covers all 8 main steps
window.selectStep('step01');
for (let i = 0; i < 7; i++) {
  doc.dispatchEvent(new window.KeyboardEvent('keydown', { key: 'ArrowDown', bubbles: true }));
}
ok(doc.getElementById('num').textContent === '8.',
   'arrow traversal ended at ' + doc.getElementById('num').textContent);

// --- the two resection tracks

// One fork passage, two daughter ends. The split at the top of the nav is not
// a decision, so it must not be drawn as one, and the old G1 decision and its
// panel are gone rather than relabelled.
{
  // The key offA is in use again, and by a different panel. The old one was the
  // G1 view that hung off the top of the chart with a "Cdk1 active?" decision in
  // front of it; the new one is the telomerase null, and it hangs off
  // elongation. What has to stay gone is the decision, not the letter.
  ok(META.offA && META.offA.phase === 'elongation',
     'offA is not the elongation offshoot, so the old G1 panel may have come back');
  ok(!doc.querySelector('#flow .split polygon'),
     'the split is drawn as a diamond, which asserts an exclusivity that is not there');
  ok(doc.querySelector('#flow .splitbar'), 'the split bar is missing');
  const decs = [...doc.querySelectorAll('#flow .dec')].map(d => d.dataset.dec);
  ok(decs.length === 1 && decs[0] === 'D1',
     'expected one decision after the restructure, got ' + decs.join(','));
}

// Resection blue names the blunt-end route. The lagging route is a different
// substrate reaching the same place, so it gets its own ground.
{
  const band = ph => doc.querySelector('#flow .band[data-phase="' + ph + '"]');
  const num = (el, a) => parseFloat(el.getAttribute(a));
  ok(band('lagging'), 'no band for the lagging track');
  const r = band('resection'), g = band('lagging');
  ok(num(r, 'x') + num(r, 'width') <= num(g, 'x'),
     'the resection band runs under the lagging column');
  const lagNodes = [...doc.querySelectorAll('#flow .node.lag')].map(n => n.dataset.key);
  ok(lagNodes.join(',') === 'lag01,lag03',
     'lagging track nodes are ' + lagNodes.join(',') + ', expected lag01,lag03');
  // No lag02, and the gap is the claim: that end needs no incision.
  ok(!META.lag02 && !doc.getElementById('p-lag02'),
     'a lag02 exists, which says the lagging end needs an incision');
}

// Leading synthesis starts with the template strand alone and finishes blunt.
{
  window.selectStep('step01');
  const p = doc.getElementById('p-step01');
  ok(p.querySelector('#c01-t').classList.contains('gone'),
     'step01 opens with a G-strand it has not made yet');
  ok(!p.querySelector('#c01-b').classList.contains('gone'),
     'step01 opens without the parental C-strand it is copying');
  ok(p.querySelector('#actor-repl'), 'step01 has no replisome');
  window.runAnimation('seek', ANIM.step01.frames.length - 1);
  for (let i = 1; i <= 14; i++) {
    ok(!p.querySelector('#c' + (i < 10 ? '0' + i : i) + '-t').classList.contains('gone'),
       'step01 finished with G-strand chunk ' + i + ' missing');
  }
  ok(p.querySelector('#actor-repl').classList.contains('gone'),
     'step01 leaves the fork parked on a finished end');
  ok(p.querySelector('#fx-ku01').classList.contains('shown'),
     'step01: Ku never arrives on the end it binds');
}

// Lagging synthesis is the other half of the same event, and ends one repeat
// short on the C-strand because the terminal primer is never replaced.
{
  window.selectStep('lag01');
  const p = doc.getElementById('p-lag01');
  ok(p.querySelector('#c01-b').classList.contains('gone'),
     'lag01 opens with a C-strand it has not made yet');
  ok(!p.querySelector('#c14-t').classList.contains('gone'),
     'lag01 opens without the parental G-strand it is copying');
  const last = ANIM.lag01.frames.length - 1;
  // One frame before the end: every fragment is down and the terminal primer
  // is still there, so the strand is briefly complete.
  window.runAnimation('seek', last - 1);
  ok(!p.querySelector('#c14-b').classList.contains('gone'),
     'lag01: the terminal fragment never got laid down');
  window.runAnimation('seek', last);
  ok(p.querySelector('#c14-b').classList.contains('gone'),
     'lag01: the terminal primer was removed but the gap got filled anyway');
  ok(!p.querySelector('#c13-b').classList.contains('gone'),
     'lag01: resection has crept into the synthesis panel');
  ['pr-c03','pr-c06','pr-c09','pr-c12','pr-c14'].forEach(id =>
    ok(p.querySelector('#' + id).classList.contains('gone'),
       'lag01: primer ' + id + ' survives to the last frame'));
  // The two primers are cleared to different ends, and the panel says so by
  // drawing one agent and withholding the other. Rad27 gets a protein box;
  // the terminal primer gets an arrow and no box, because which activity
  // removes it is not established in yeast. Asserting on fx-termprimer rather
  // than on a named nuclease is what keeps that distinction testable.
  ok(p.querySelector('#fx-rad27') && p.querySelector('#fx-termprimer'),
     'lag01: the two primer fates are not both drawn');
  ok(!p.querySelector('#fx-termprimer .prot'),
     'lag01: the terminal-primer step names an agent the model does not claim');
  ok(p.querySelector('#fx-cdc9'), 'lag01: Cdc9 is not drawn');
  ['fx-rad27', 'fx-cdc9', 'fx-termprimer'].forEach(id =>
    ok(p.querySelector('#' + id).classList.contains('shown'),
       'lag01: ' + id + ' is in the panel but no frame ever reveals it'));

  // The maturation arrows are vertical or steep, and a rotated label on one of
  // those is text the reader has to tilt their head to follow. Every label in
  // this panel stays horizontal, which means no arrowlab carries a rotate.
  p.querySelectorAll('.arrowlab').forEach(t =>
    ok(!(t.getAttribute('transform') || '').includes('rotate'),
       'lag01: an arrow label is rotated: ' + t.textContent));

  // Horizontal is only half of it. A label centred on a vertical arrow sits on
  // the line, so the side-placed ones have to be re-anchored as well or they
  // grow straight back across it.
  ['Primers removed', 'nicks sealed'].forEach(txt => {
    const t = Array.prototype.slice.call(p.querySelectorAll('.arrowlab'))
      .find(n => n.textContent === txt);
    ok(t && (t.classList.contains('lab-l') || t.classList.contains('lab-r')),
       'lag01: "' + txt + '" is beside its arrow but not anchored away from it');
  });

  // Nothing may sit outside the panel. VB_H is 300 and an element below that
  // does not render at all, which is silent: the text is in the file, in the
  // DOM, and on no screen.
  p.querySelectorAll('text').forEach(t => {
    const y = parseFloat(t.getAttribute('y'));
    if (!isNaN(y)) {
      ok(y <= 300, 'lag01: text below the viewBox at y=' + y + ': ' + t.textContent);
    }
  });

  // Pol alpha hands the fragment to Pol delta once per fragment, so the two
  // arrows have to move together. Drawn at a fixed coordinate the delta arrow
  // would line up on the first fragment and sit further behind on each one
  // after it, which is the failure the nested actor group exists to prevent.
  ANIM.lag01.frames.forEach((f, i) => {
    const a = (f.actors || {})['actor-lagpol'];
    const d = (f.actors || {})['actor-lagpold'];
    ok(a === d,
       'lag01 frame ' + i + ': Pol alpha at ' + a + ' but Pol delta at ' + d);
  });

  // and the handoff arrow must not outlive the polymerase that makes it
  {
    const tail = ANIM.lag01.frames[ANIM.lag01.frames.length - 1].halves || {};
    ok(tail['actor-lagpol'] === 'gone' && tail['fx-poldelta'] === 'gone',
       'lag01: a polymerase arrow survives onto the finished end');
  }
}

// Both resection panels converge on the same C-strand boundary, or step 4 is
// drawing a state neither branch actually reaches.
{
  const lastBot = k => {
    const p = doc.getElementById('p-' + k);
    let n = 0;
    for (let i = 1; i <= 18; i++) {
      const el = p.querySelector('#c' + (i < 10 ? '0' + i : i) + '-b');
      if (el && !el.classList.contains('gone') &&
          (!el.classList.contains('pending') || el.classList.contains('shown'))) { n = i; }
    }
    return n;
  };
  window.selectStep('step03');
  window.runAnimation('seek', ANIM.step03.frames.length - 1);
  const a = lastBot('step03');
  window.selectStep('lag03');
  window.runAnimation('seek', ANIM.lag03.frames.length - 1);
  const b = lastBot('lag03');
  ok(a === 10 && b === 10,
     'branches end at C-strand ' + a + ' and ' + b + ', so they do not converge on step 4');
}

// MRX does not track the resection front. It is bound at the end, it releases
// once the cut is made and the distal fragment cleared, and the complex drawn
// at the junction from step 4 onward is a separate binding event. The nick
// goes with it: once the 5' end has passed the incision site there is no
// discontinuity left to draw.
{
  const state = (k, id, f) => {
    window.selectStep(k);
    window.runAnimation('seek', f);
    return doc.querySelector('#p-' + k + ' #' + id).classList;
  };
  ok(state('step03', 'actor-mrx', 0).contains('shown'),
     'step03 should open with MRX on the end it is about to cut');
  ok(state('step03', 'actor-mrx', 2).contains('fading'),
     'step03 MRX should start leaving on the frame the distal fragment goes');
  ok(state('step03', 'actor-mrx', ANIM.step03.frames.length - 1).contains('gone'),
     'step03 leaves MRX parked on single-stranded DNA');
  ok(state('step03', 'fx-nick03', 2).contains('fading'),
     'step03 keeps the incision mark after the complex that made it has gone');
  ok(state('step03', 'fx-nick03', ANIM.step03.frames.length - 1).contains('gone'),
     'step03 ends with a cut in a strand that no longer reaches it');
  ok(state('lag03', 'actor-mrx', 0).contains('shown'),
     'lag03 should open with MRX at the junction, loading the nucleases');
  ok(state('lag03', 'actor-mrx', ANIM.lag03.frames.length - 1).contains('gone'),
     'lag03 leaves MRX parked on single-stranded DNA');
  // and MRX must not be an actor with an offset in the panels this argument
  // has been applied to: an offset is a trajectory, and the claim is that
  // there is not one.
  //
  // There is no exemption any more. Branch D used to hold one: it translated
  // MRX inward across eight frames while the terminal repeats eroded, which is
  // the slide this test exists to forbid. That erosion is now branch A's, it
  // runs twice as far, and branch A draws three complexes appearing and fading
  // at successive positions instead of one walking. The new branch D holds MRX
  // still on a junction that never moves. So every panel with the complex is in
  // the list.
  //
  // The check reaches any actor id beginning actor-mrx, because branch A has
  // three of them. The Mre11 lobes are excluded: step03 parts them on purpose,
  // and that is a claim about bidirectionality rather than about the complex
  // travelling.
  const NO_MRX_DRIFT = ['step01', 'step03', 'lag03', 'offA', 'offC', 'offD', 'offE'];
  NO_MRX_DRIFT.forEach(k => (ANIM[k] ? ANIM[k].frames : []).forEach((f, n) => {
    Object.keys(f.actors || {}).forEach(id => {
      if (id.indexOf('actor-mrx') !== 0 || id.indexOf('-lobe') !== -1) { return; }
      ok(false,
         k + ' frame ' + n + ': ' + id + ' carries an offset, which draws a trajectory');
    });
  }));
}


// --- citations
//
// Everything below is about the path from a \cite marker in src/data.js to a
// numbered link on the page. Three separate failure modes, and only the first
// announces itself: a key with no bibliography entry renders a visible [?], a
// backslash eaten by a JS string literal renders as harmless-looking prose,
// and a word processor's punctuation renders as a character that differs from
// the one beside it by a few pixels.

const BIB          = window.eval('BIB');
const CITE_LIST    = window.eval('CITE_LIST');
const CITE_NUMBERS = window.eval('CITE_NUMBERS');
const CITE_MISSING = window.eval('CITE_MISSING');
const CITE_SCOPE   = window.eval('CITE_SCOPE');
const PANEL_ORDER  = window.eval('PANEL_ORDER');
const citeKeysIn   = window.eval('citeKeysIn');
const citeHref     = window.eval('citeHref');

// the bibliography arrived and parsed
ok(Object.keys(BIB).length > 0, 'refs.bib parsed to nothing');

// every key any caption cites has an entry
ok(CITE_MISSING.length === 0,
   'cited with no refs.bib entry: ' + CITE_MISSING.join(', '));

// PANEL_ORDER is the numbering order and must cover META exactly, or a panel
// silently gets no numbers assigned and renders every reference as [?]
{
  const metaKeys = Object.keys(META).sort().join(',');
  const orderKeys = PANEL_ORDER.slice().sort().join(',');
  ok(metaKeys === orderKeys,
     'PANEL_ORDER and META disagree about which panels exist');
  ok(PANEL_ORDER.length === new Set(PANEL_ORDER).size,
     'PANEL_ORDER repeats a panel');
}

// PANEL_ORDER must equal KEYS in tools/make_shell.py. They are the same
// reading order kept in two languages; if they drift, the numbers a reader
// sees stop matching the order the panels are laid out in.
{
  const shell = fs.readFileSync('tools/make_shell.py', 'utf8');
  const block = shell.match(/KEYS\s*=\s*\[([\s\S]*?)\]/);
  ok(!!block, 'could not find KEYS in tools/make_shell.py');
  if (block) {
    const keys = (block[1].match(/"([^"]+)"/g) || []).map(s => s.slice(1, -1));
    ok(keys.join(',') === PANEL_ORDER.join(','),
       'PANEL_ORDER in data.js and KEYS in make_shell.py are in different orders');
  }
}

// the refs field is gone. It listed the keys backing a caption and nothing
// read it; now that the keys are in the prose, a second copy could only ever
// disagree with the first.
Object.keys(META).forEach(k => {
  ok(!META[k].hasOwnProperty('refs'),
     k + ' still carries a refs field, which is now a second source of truth');
});

// String.raw did its job. A caption written as an ordinary JS string loses the
// backslash silently, and "cite{key}" is what is left; there is no error and
// the text reads almost normally, so nothing else would catch this.
Object.keys(META).forEach(k => {
  ['caption', 'note'].forEach(field => {
    const raw = META[k][field];
    if (!raw) { return; }
    ok(!/(^|[^\\])cite\s*\{/.test(raw),
       k + '.' + field + ': a cite marker lost its backslash. The field must ' +
       'be a String.raw template literal.');
  });
});

// word-processor punctuation. Captions are pasted out of a word processor, and
// the figure already uses ASCII apostrophes for 3' and 5' in every panel SVG,
// so a curly one next to a straight one reads as a rendering fault. Em dashes
// are out by the prose rules the captions are written to.
{
  const BANNED = {
    '\u2018': 'left curly quote',
    '\u2019': 'right curly quote (use a straight apostrophe for 3\u0027 and 5\u0027)',
    '\u201c': 'left curly double quote',
    '\u201d': 'right curly double quote',
    '\u2013': 'en dash',
    '\u2014': 'em dash',
    '\u2026': 'ellipsis character (use three periods)',
    '\u00a0': 'non-breaking space'
  };
  Object.keys(META).forEach(k => {
    ['caption', 'note', 'title'].forEach(field => {
      const raw = META[k][field];
      if (!raw) { return; }
      Object.keys(BANNED).forEach(ch => {
        ok(raw.indexOf(ch) < 0,
           k + '.' + field + ' contains a ' + BANNED[ch] +
           ' at index ' + raw.indexOf(ch));
      });
    });
  });
}

// no marker survives into what the reader sees, in any panel, in either the
// caption or the note
PANEL_ORDER.forEach(k => {
  window.selectStep(k);
  ['cap', 'note'].forEach(id => {
    const text = doc.getElementById(id).textContent;
    ok(text.indexOf('\\cite') < 0, k + ': an unrendered cite marker is in #' + id);
    ok(text.indexOf('cite{') < 0, k + ': a bare cite{ is in #' + id);
  });
  ok(doc.getElementById('cap').querySelectorAll('p').length > 0,
     k + ': caption rendered no paragraphs');
  ok(doc.getElementById('cap').querySelectorAll('span.citemissing').length === 0,
     k + ': caption renders an unresolved reference');
});

// numbering: one number per key, no gaps, and the list under the panel matches
// the markers in its prose
PANEL_ORDER.forEach(k => {
  const keys = CITE_LIST[k] || [];
  const map = CITE_NUMBERS[k] || {};
  const inProse = citeKeysIn((META[k].caption || '') + '\n\n' + (META[k].note || ''));

  ok(keys.join(',') === inProse.join(','),
     k + ': CITE_LIST does not match the keys in the prose');

  const nums = keys.map(key => map[key]);
  ok(nums.every(n => typeof n === 'number'), k + ': a cited key got no number');
  ok(new Set(nums).size === nums.length, k + ': two keys share a number');

  if (CITE_SCOPE === 'panel') {
    ok(nums.join(',') === keys.map((_, i) => i + 1).join(','),
       k + ': panel-scoped numbers are not 1..n in order of first appearance');
  }
});

// under global scope a key must carry the same number in every panel that
// cites it, which is the entire reason for choosing that scope
if (CITE_SCOPE === 'global') {
  const seen = {};
  PANEL_ORDER.forEach(k => {
    (CITE_LIST[k] || []).forEach(key => {
      const n = CITE_NUMBERS[k][key];
      if (seen.hasOwnProperty(key)) {
        ok(seen[key] === n,
           key + ' is [' + seen[key] + '] in one panel and [' + n + '] in ' + k);
      } else {
        seen[key] = n;
      }
    });
  });
}

// the same key cited twice in one caption gets the same number both times
{
  window.selectStep('step04');
  const byNum = {};
  doc.getElementById('cap').querySelectorAll('a.citeref').forEach(a => {
    byNum[a.href] = byNum[a.href] || new Set();
    byNum[a.href].add(a.textContent);
  });
  Object.keys(byNum).forEach(href => {
    ok(byNum[href].size === 1,
       'step04: one reference rendered under two numbers (' + href + ')');
  });
}

// the reference list: shown when a panel cites something, hidden when it does
// not, and one entry per key plus the heading
PANEL_ORDER.forEach(k => {
  window.selectStep(k);
  const list = doc.getElementById('refs');
  const cited = (CITE_LIST[k] || []).length;

  ok(list.classList.contains('on') === (cited > 0),
     k + ': reference list visibility does not match whether it cites anything');

  if (cited > 0) {
    ok(list.querySelectorAll('li.refitem').length === cited,
       k + ': reference list has ' + list.querySelectorAll('li.refitem').length +
       ' entries for ' + cited + ' references');
    ok(list.querySelectorAll('li.refhead').length === 1,
       k + ': reference list is missing its heading');
    ok(list.querySelectorAll('li.refitem.broken').length === 0,
       k + ': reference list has an unresolved entry');
  }
});

// links leave the page rather than replacing the figure, and carry the opener
// protection that goes with target=_blank
PANEL_ORDER.forEach(k => {
  window.selectStep(k);
  doc.querySelectorAll('#cap a.citeref, #note a.citeref, #refs a').forEach(a => {
    ok(a.getAttribute('target') === '_blank', k + ': a citation link stays in the page');
    ok((a.getAttribute('rel') || '').includes('noopener'),
       k + ': a citation link has no noopener');
    ok(/^https?:\/\//.test(a.getAttribute('href') || ''),
       k + ': a citation link has no absolute href');
  });
});

// link tiers, in the same order as the \cite command in the dissertation
// preamble: doi, then url, then a Scholar search
Object.keys(BIB).forEach(key => {
  const e = BIB[key];
  const href = citeHref(key, e);
  if (e.doi) {
    ok(href.indexOf('https://doi.org/') === 0, key + ': has a doi but did not use it');
  } else if (e.url) {
    ok(href === e.url, key + ': has a url but did not use it');
  } else {
    ok(href.indexOf('https://scholar.google.com/') === 0,
       key + ': has neither doi nor url and did not fall back to Scholar');
    ok(href.indexOf(' ') < 0, key + ': Scholar fallback url is not encoded');
  }
});

// nothing in a caption can contain the two characters that would end a
// String.raw literal or start a substitution in it
Object.keys(META).forEach(k => {
  ['caption', 'note'].forEach(field => {
    const raw = META[k][field];
    if (!raw) { return; }
    ok(raw.indexOf('`') < 0, k + '.' + field + ' contains a backtick');
    ok(raw.indexOf('${') < 0, k + '.' + field + ' contains ${');
  });
});

// repainting the same panel twice must not accumulate anything
{
  window.selectStep('step01');
  const first = doc.getElementById('cap').querySelectorAll('a.citeref').length;
  const firstRefs = doc.getElementById('refs').querySelectorAll('li').length;
  window.selectStep('step02');
  window.selectStep('step01');
  ok(doc.getElementById('cap').querySelectorAll('a.citeref').length === first,
     'repainting step01 changed its citation count');
  ok(doc.getElementById('refs').querySelectorAll('li').length === firstRefs,
     'repainting step01 changed its reference list length');
}

// the drawing note: control shown only where there is a note, collapsed on
// first render, and empty behind the control where there is none
{
  window.selectStep('step01');
  ok(doc.getElementById('notewrap').classList.contains('has'),
     'step01 has a note but the disclosure is hidden');
  ok(!doc.getElementById('notewrap').classList.contains('open'),
     'the drawing note starts expanded');

  doc.getElementById('notetoggle').dispatchEvent(
    new window.MouseEvent('click', { bubbles: true }));
  ok(doc.getElementById('notewrap').classList.contains('open'),
     'clicking the note toggle did not expand it');
  ok(doc.getElementById('note').textContent.length > 0,
     'the expanded note is empty');

  // the open state is deliberately kept across panels: someone reading the
  // rationale is usually comparing panels
  window.selectStep('step02');
  ok(doc.getElementById('notewrap').classList.contains('open'),
     'the note collapsed on moving to another panel that has one');

  window.selectStep('step09');
  ok(!doc.getElementById('notewrap').classList.contains('has'),
     'step09 has no note but the disclosure is shown');
  ok(doc.getElementById('note').textContent.length === 0,
     'step09 shows another panel\u0027s note behind a hidden control');

  doc.getElementById('notetoggle').dispatchEvent(
    new window.MouseEvent('click', { bubbles: true }));
}

// report only, not a failure. The bibliography is still being built, so an
// entry that nothing cites is work in progress rather than a fault. Promote
// this to ok() once the captions are finished.
{
  const cited = new Set();
  PANEL_ORDER.forEach(k => (CITE_LIST[k] || []).forEach(key => cited.add(key)));
  const unused = Object.keys(BIB).filter(key => !cited.has(key)).sort();
  if (unused.length) {
    console.log('note: ' + unused.length + ' refs.bib entries are not cited yet: ' +
                unused.join(', '));
  }
}

// leave the figure where the rest of the suite expects to find it
window.selectStep('step01');


console.log(fails.length ? 'FAILURES:' : 'all behavioural tests passed');
fails.forEach(f => console.log('  - ' + f));
process.exit(fails.length ? 1 : 0);
// step09 closes the main line
ok(ORDER[ORDER.length - 1] === 'step09', 'step09 is not the end of the main line');