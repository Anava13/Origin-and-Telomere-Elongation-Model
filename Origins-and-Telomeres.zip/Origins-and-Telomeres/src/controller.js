/* Workflow controller. Panels are markup and know nothing about which step
   they are, so every navigation wire lives here. */

var CURRENT_KEY = null;
var CURRENT_PAGE = 'steps';

// === BASE CONTROLLER: initWorkflow ========================================

function initWorkflow() {
  loadResources(function () {
    wireNav();
    wireKeyboard();
    initTransport();
    selectStep(window.PANEL_ORDER[0]);
  });

  function loadResources(done) {
    // SUB-CONTROLLER: panels and bibliography. The distributable carries both
    // inline, so it needs no server. src/ fetches them, which is why src/
    // must be served over http.
    var keys = window.PANEL_ORDER || [];
    if (window.INLINE_PANELS) {
      useInline(keys);
      done();
      return;
    }
    var pending = keys.length + 1;
    var stage = document.getElementById('stage');

    keys.forEach(function (key) {
      fetch((key.indexOf('tw-') === 0 ? 'tw-panels/' : 'panels/') + key + '.svg').then(function (r) {
        if (!r.ok) { throw new Error(r.status); }
        return r.text();
      }).then(function (svg) {
        var holder = document.createElement('div');
        holder.innerHTML = svg;
        stage.appendChild(holder.firstChild);
        finish();
      }).catch(function () {
        reportProtocol('panel ' + key + ' did not load');
        finish();
      });
    });

    Promise.all(['refs.bib', 'telo-refs.bib'].map(function (name) {
      return fetch(name).then(function (r) {
        if (!r.ok) { throw new Error(r.status); }
        return r.text();
      });
    })).then(function (texts) {
      initCitations(texts.join('\n'));
      finish();
    }).catch(function () {
      reportProtocol('the bibliography did not load');
      finish();
    });

    function finish() {
      pending -= 1;
      if (pending === 0) { done(); }
    }

    function useInline(keys) {
      // SUB-CONTROLLER: take panels and bibliography from the inlined copies.
      var stage = document.getElementById('stage');
      keys.forEach(function (key) {
        var holder = document.createElement('div');
        holder.innerHTML = window.INLINE_PANELS[key] || '';
        if (holder.firstChild) { stage.appendChild(holder.firstChild); }
      });
      initCitations(window.INLINE_BIB || '');
    }

    function reportProtocol(what) {
      // VIEW: panels load with fetch, so the page must be served over http.
      var el = document.getElementById('loaderror');
      if (el) {
        el.textContent = what + '. Panels load with fetch, so serve this '
          + 'directory over http. Opening index.html from the file system gives '
          + 'empty panels and an empty bibliography.';
        el.hidden = false;
      }
    }
  }

  function wireNav() {
    // SUB-CONTROLLER: nav nodes, the badges on the steps chart, the page
    // tabs, and anything in a panel carrying data-goto.
    var nodes = document.querySelectorAll('#navwrap .navnode[data-key]');
    var i;
    for (i = 0; i < nodes.length; i += 1) {
      nodes[i].addEventListener('click', onNavClick);
    }
    var gotos = document.querySelectorAll('[data-goto]');
    for (i = 0; i < gotos.length; i += 1) {
      gotos[i].addEventListener('click', onGotoClick);
    }
    var tabs = document.querySelectorAll('#navtabs .navtab[data-page]');
    for (i = 0; i < tabs.length; i += 1) {
      tabs[i].addEventListener('click', onTab);
    }
    selectNavPage('steps');

    function onNavClick(ev) {
      selectStep(ev.currentTarget.getAttribute('data-key'));
    }

    function onGotoClick(ev) {
      selectStep(ev.currentTarget.getAttribute('data-goto'));
    }

    function onTab(ev) {
      selectNavPage(ev.currentTarget.getAttribute('data-page'));
    }
  }

  function wireKeyboard() {
    document.addEventListener('keydown', onKey);

    function onKey(ev) {
      var order = window.ORDER || [];
      var at = order.indexOf(CURRENT_KEY);
      if (ev.key === 'ArrowRight' && at >= 0 && at < order.length - 1) {
        selectStep(order[at + 1]);
      }
      if (ev.key === 'ArrowLeft' && at > 0) { selectStep(order[at - 1]); }
    }
  }
}

// === BASE CONTROLLER: selectNavPage =======================================

function selectNavPage(page) {
  // Shows one chart and marks its tab. The selected panel is left alone:
  // changing pages is a change of what the reader is looking through, not of
  // what they are looking at.
  //
  // Three pages need a control that says where the reader is, which a single
  // toggle naming the page it goes to cannot do once there are two other
  // pages to go to. Each chart has its own tab, and the tab of the chart on
  // show is the one marked.
  CURRENT_PAGE = page;
  showPage(page);
  markTab(page);

  function showPage(page) {
    // VIEW: exactly one chart visible (TERMINAL)
    var pages = document.querySelectorAll('#navwrap .navpage');
    var i;
    for (i = 0; i < pages.length; i += 1) {
      pages[i].classList.toggle('active',
        pages[i].getAttribute('data-page') === page);
    }
  }

  function markTab(page) {
    // VIEW: the tab of the chart on show is marked, for the eye and for a
    // screen reader (TERMINAL)
    var tabs = document.querySelectorAll('#navtabs .navtab[data-page]');
    var i, on;
    for (i = 0; i < tabs.length; i += 1) {
      on = tabs[i].getAttribute('data-page') === page;
      tabs[i].classList.toggle('active', on);
      tabs[i].setAttribute('aria-selected', on ? 'true' : 'false');
    }
  }
}

// === BASE CONTROLLER: selectStep ==========================================

function selectStep(key) {
  var meta = (window.META || {})[key];
  if (!meta) { return; }
  CURRENT_KEY = key;

  showPanel(key);
  buildStepView(key, meta);
  lightNav(key);
  runAnimation('reset', key);
  // A panel with its own controls (the live chromosome panel) shows them here.
  if (typeof window.onPanelSelected === 'function') { window.onPanelSelected(key); }

  function showPanel(key) {
    // VIEW: exactly one panel visible (TERMINAL)
    var panels = document.querySelectorAll('#stage svg.panelsvg');
    var i;
    for (i = 0; i < panels.length; i += 1) {
      panels[i].classList.toggle('active', panels[i].getAttribute('data-key') === key);
    }
  }

  function buildStepView(key, meta) {
    // SUB-CONTROLLER: title, kind chip, caption, references, note.
    var ledger = [];
    var title = document.getElementById('steptitle');
    title.innerHTML = meta.title
      + (meta.kind ? '<span class="chip ' + meta.kind + '">' + meta.kind + '</span>' : '');
    document.getElementById('captiontext').innerHTML = renderCitedText(meta.caption, ledger);
    document.getElementById('refs').innerHTML = renderReferenceList(ledger);
    setNote(meta);
  }

  function setNote(meta) {
    // VIEW: the disclosure keeps its open state across panels, because
    // someone reading drawing rationale is usually comparing panels.
    var wrap = document.getElementById('notewrap');
    var body = document.getElementById('note');
    if (meta.note) {
      var ledger = [];
      body.innerHTML = renderCitedText(meta.note, ledger);
      wrap.hidden = false;
    } else {
      body.innerHTML = '';
      wrap.hidden = true;
    }
  }

  function lightNav(key) {
    // SUB-CONTROLLER: light the node, and bring its page forward if the
    // reader arrived from a link on the other one.
    var nodes = document.querySelectorAll('#navwrap .navnode');
    var i, found = null;
    for (i = 0; i < nodes.length; i += 1) {
      var hit = nodes[i].getAttribute('data-key') === key;
      nodes[i].classList.toggle('selected', hit);
      if (hit) { found = nodes[i]; }
    }
    if (found) {
      var page = pageOf(found);
      if (page && page !== CURRENT_PAGE) { selectNavPage(page); }
    }

    function pageOf(node) {
      // MODEL: which chart a node sits on (TERMINAL)
      var el = node;
      while (el && el.getAttribute) {
        if (el.classList && el.classList.contains('navpage')) {
          return el.getAttribute('data-page');
        }
        el = el.parentNode;
      }
      return null;
    }
  }
}

if (typeof window !== 'undefined') {
  window.initWorkflow = initWorkflow;
  window.selectStep = selectStep;
  window.selectNavPage = selectNavPage;
}

if (typeof document !== 'undefined' && typeof window !== 'undefined'
    && !window.SUPPRESS_AUTOSTART) {
  document.addEventListener('DOMContentLoaded', initWorkflow);
}
