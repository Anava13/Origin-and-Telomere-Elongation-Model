/* Frames for the live chromosome panel, built from one run of the rule.

   buildChromFrames takes a schedule from CHROM_RULE.simulate and the geometry
   the panel was drawn with (CHROM_GEOM, written by tools/make_panels.py) and
   returns a frame table in the shape the engine plays: complete state per
   frame, as presence classes on .fx wrappers, actor offsets and text. Nothing
   here decides biology; every state is read off the schedule.

   Motion is translation only, as in the rest of the figure. A copied strip and
   its fork slide out by x_now - x_origin; a meter's fill slides up by the
   share of the threshold reached; a copy or a set moves by the difference
   between where it is dealt and where it rests. */

function buildChromFrames(sched, geom, focus, follow, interlude, pair, also) {
  // BASE CONTROLLER: the moments to show, the copy plan, then the state at each
  // also, when given, names more telomere ends whose steps are sampled once per
  // frame of their workflow panels, so a second close-up of the same run can
  // follow one of them frame for frame.
  // pair, when given, is a second run shown beside this one: both runs then
  // sample S on one clock, minutes after G1/S, at the same step and at each
  // other's events, so a frame of one has a frame of the other at its minute.

  // focus names an origin, or a telomere site (tel-L-s1 and so on); a
  // telomere focus puts that end in the close-up, and the origin-only
  // sequences (the firing interlude, a passive pass, termination) stay out.
  var eps = 1e-6;
  var telFocus = /^tel-[LR]-s[12]$/.test(focus || '');
  var origin = telFocus ? 'L1' : (focus || 'L1');
  var moments = sched.one ? listOneMoments(sched, (telFocus ? [focus] : []).concat(also || []))
    : listMoments(sched, pair, telFocus ? focus : null);
  var plans = planCopies(sched);
  var texts = describeTexts(sched, geom);
  var events = listCallouts(sched, moments);
  var frames = moments.map(function (m, i) {
    var f = frameAt(m, i, sched, geom, plans, texts, events);
    var tv = geom.tel ? telViewAt(m, sched, geom) : { fx: {}, actors: {}, text: {} };
    var id;
    for (id in tv.fx) { if (Object.prototype.hasOwnProperty.call(tv.fx, id)) { f.fx[id] = tv.fx[id]; } }
    for (id in tv.actors) { if (Object.prototype.hasOwnProperty.call(tv.actors, id)) { f.actors[id] = tv.actors[id]; } }
    for (id in tv.text) { if (Object.prototype.hasOwnProperty.call(tv.text, id)) { f.text[id] = tv.text[id]; } }
    f.tel = tv.sites;
    if (telFocus && geom.tel && tv.sites[focus]) {
      // The selection ring sits on the selected end: on its sister's row once
      // its fork has copied it, on the parental row before.
      f.actors['actor-tvsel'] = [geom.tel.ringDx[tv.sites[focus].side],
        Math.round(((tv.sites[focus].copied ? geom.tel.rows[String(tv.sites[focus].sister)] : geom.tel.rows.p)
          - geom.tel.rows['1']) * 100) / 100];
    }
    f.inset = telFocus ? telInsetAt(m, sched, focus, tv.sites[focus])
      : insetAt(m, sched, geom, origin, f.seen, follow || 'right');
    delete f.seen;
    return f;
  });
  if (!telFocus) {
    frames = insertInterlude(frames, moments, sched, origin, interlude || [], follow || 'right');
    frames = insertPassive(frames, moments, sched, origin);
    frames = insertTermination(frames, sched, geom, origin, follow || 'right');
  }
  countForkTravel(frames);
  return { fps: geom.fps, label: 'One chromosome through one cell cycle', frames: frames };

  function countForkTravel(frames) {
    // MODEL: how far the followed fork has gone, in step-panel positions, at each frame (TERMINAL)
    // Two positions per frame for each kb/min of fork speed, so a fork at
    // the normal 2 kb/min moves 4 positions a frame, as step 11 draws it.
    // The frame a mark lands carries its kinase arrow; Rad53's own mark
    // follows Mec1's by one frame.
    // The helicase also moves when the bare stretch behind it grows: that
    // stretch is template it has unwound ahead of the polymerases, so the
    // stalled new strands stay put while the fork moves on. A collapsed fork
    // without Rad53 runs on two positions a frame, its bare stretch growing.
    var u = 0, i, v, was = { mrcP: false, active: false, on: 0 }, bare = 0, cap = 30;
    for (i = 0; i < frames.length; i += 1) {
      v = frames[i].inset && frames[i].inset.view;
      if (v && v.kind === 'elong') {
        if (v.runOn) { v.bare = Math.min(cap, Math.max(v.bare, bare + 2)); v.speed = Math.max(v.speed, 1); }
        u += Math.round(2 * (v.runOn ? 0 : v.speed)) + Math.max(0, v.bare - bare);
        bare = v.bare;
        v.u = u;
        v.kmrc = v.mrcP && !was.mrcP;
        v.kr53 = v.active && !was.active;
        was.on = v.active ? was.on + 1 : 0;
        v.auto = was.on >= 2;
        was.mrcP = v.mrcP;
        was.active = v.active;
      } else {
        was = { mrcP: false, active: false, on: 0 };
        bare = 0;
      }
    }
  }

  function insertInterlude(frames, moments, sched, n, steps, follow) {
    // MODEL: slow motion at the selected origin's firing: steps 7 to 11 frame by frame (TERMINAL)
    // Model time stops: each inserted frame repeats the chromosome as it is at
    // the firing moment, and the close-up plays the step panels' own frames,
    // from the clasp seating on the marked pair to the two forks leaving, so
    // the origin's own close-up runs from initiation into elongation without
    // a cut. steps lists {key, frame, title, num} in playing order.
    var o = sched.origins[n], at = -1, out, i;
    if (!steps.length || o.fate !== 'fired' || follow === 'cen') { return frames; }
    for (i = 0; i < moments.length; i += 1) {
      if (moments[i].phase === 'S' && Math.abs(moments[i].t - o.time) < 1e-4) { at = i; }
    }
    if (at < 0) { return frames; }
    // The interlude stands in for the firing frame's close-up: it starts as the
    // set lands (step 7, first frame) and ends with the forks leaving (step 11).
    out = frames.slice(0, at);
    var tracking = follow === 'left' || follow === 'right';
    steps.forEach(function (st, k) {
      var f = JSON.parse(JSON.stringify(frames[at]));
      // In step 11 the camera rides the followed fork's CMG out of the origin,
      // with that fork's elongation panel under the step copy showing the DNA
      // past the step panel's end, so the last step frame is the first
      // elongation picture.
      var rides = tracking && st.key === 'step11';
      // A bob1 run plays the bob1 drawings of the steps; one fired by the
      // bypass plays them with no DDK marks and the NSD released.
      var b = !!sched.bob1;
      f.inset.view = { kind: 'step', key: st.key + (b ? 'b' : ''), b: b,
        table: b ? st.key + (o.route === 'bypass' ? 'x' : 'b') : st.key,
        frame: st.frame, track: rides ? follow : null, under: rides ? (follow === 'right' ? 'r' : 'l') : null };
      f.inset.fx['ci-leftcol'] = rides ? 'gone' : 'present';
      f.inset.text['ci-line1'] = n + ' fires: slow motion, model time paused (' + (k + 1) + ' of '
        + steps.length + ')';
      f.inset.text['ci-line2'] = 'step ' + st.num + ': ' + (o.route === 'bypass' && st.key === 'step07'
        ? 'Sld3-Sld7 clasps the pair; with no mark, its cleft stays empty' : st.title);
      f.inset.text['ci-line3'] = o.route === 'bypass' ? 'fired by the bob1 bypass: no DDK marks, NSD released'
        : 'the step panels\u2019 own frames, at this origin';
      out.push(f);
    });
    // After step 11 the frames already show the followed fork's elongation
    // panel, or the origin opened to both edges, which is the picture step
    // 11's last frame leaves.
    return out.concat(frames.slice(at + 1));
  }

  function insertTermination(frames, sched, geom, n, follow) {
    // MODEL: the followed fork meeting its partner, frame by frame, with model time paused (TERMINAL)
    // The two forks close the gap, their CMGs pass each other onto double-
    // stranded DNA, SCF-Dia2 ubiquitylates Mcm7, and Cdc48 extracts each CMG
    // (Maric et al. 2014). The sequence stands in for the frame the forks
    // meet on; every later frame that showed the replisome leaving shows the
    // finished stretch the sequence ends on.
    var f = null, at = -1, i, k, out, other = null, side, M, steps, last, base;
    if (follow !== 'left' && follow !== 'right') { return frames; }
    sched.forks.forEach(function (c) { if (c.id === n + '-' + follow) { f = c; } });
    if (!f || f.end !== 'meet') { return frames; }
    sched.terminations.forEach(function (t) {
      var j = t.forks.indexOf(f.id);
      if (j >= 0) { other = t.forks[1 - j].split('-')[0]; }
    });
    for (i = 0; i < frames.length; i += 1) {
      if (at < 0 && frames[i].inset.view.kind === 'elong' && frames[i].inset.view.leave) { at = i; }
    }
    if (at < 0) { return frames; }
    side = follow === 'right' ? 'r' : 'l';
    M = geom.ciTerm.m;
    base = { kind: 'term', side: side, b: !!sched.bob1, dntp: frames[at].inset.view.dntp,
      filled: false, dia2: false, ubq: false, cdc48: false, gone: false, moving: true };
    var mk = function (pL, pR, extra, words) {
      var v = JSON.parse(JSON.stringify(base)), key;
      v.pL = pL;
      v.pR = pR;
      for (key in extra) { if (Object.prototype.hasOwnProperty.call(extra, key)) { v[key] = extra[key]; } }
      v.words = words;
      return v;
    };
    steps = [
      mk(M - 8, M + 9, {}, 'the fork from ' + other + ' comes into view'),
      mk(M - 6, M + 7, {}, 'the two forks close the gap'),
      mk(M - 4, M + 5, {}, 'the two forks close the gap'),
      mk(M - 2, M + 3, {}, 'the last stretch of parental duplex unwinds'),
      mk(M, M + 1, {}, 'the forks meet'),
      mk(M + 2, M - 1, { filled: true }, 'the CMGs pass each other onto double-stranded DNA'),
      mk(M + 4, M - 3, { filled: true, moving: false }, 'each leading strand runs into the other fork\u2019s lagging strand'),
      mk(M + 4, M - 3, { filled: true, moving: false, dia2: true }, 'SCF-Dia2 binds each CMG'),
      mk(M + 4, M - 3, { filled: true, moving: false, dia2: true, ubq: true }, 'SCF-Dia2 ubiquitylates Mcm7'),
      mk(M + 4, M - 3, { filled: true, moving: false, dia2: true, ubq: true, cdc48: true }, 'Cdc48 binds the ubiquitin chain'),
      mk(M + 4, M - 3, { filled: true, moving: false, dia2: true, ubq: true, cdc48: true, gone: true },
        'Cdc48 extracts each CMG from the DNA'),
      mk(M + 4, M - 3, { filled: true, moving: false, gone: true }, 'the stretch between the two origins is copied')
    ];
    out = frames.slice(0, at);
    steps.forEach(function (v, j) {
      var fr = JSON.parse(JSON.stringify(frames[at]));
      fr.inset.view = v;
      fr.inset.text['ci-line1'] = n + '\u2019s ' + follow + ' fork meets the fork from ' + other
        + ': model time paused (' + (j + 1) + ' of ' + steps.length + ')';
      fr.inset.text['ci-line2'] = v.words;
      fr.inset.text['ci-line3'] = 'termination: CMG passing, Mcm7 ubiquitylation, extraction by Cdc48';
      out.push(fr);
    });
    last = steps[steps.length - 1];
    for (i = at; i < frames.length; i += 1) {
      if (frames[i].inset.view.kind === 'elong' && frames[i].inset.view.leave) {
        frames[i].inset.view = JSON.parse(JSON.stringify(last));
      }
      out.push(frames[i]);
    }
    return out;
  }

  function passiveView(o, sched, geom, k, look) {
    // MODEL: the passive panel at step k of a passing fork's crossing (TERMINAL)
    // The fork that copied the origin came from the side its id names: a
    // fork moving right comes in from the left. It enters off the page and
    // moves four positions a frame, as step 11's forks do, until it has left
    // the page on the other side; the panel keeps that last picture.
    var side = /right$/.test(String(o.copiedBy)) ? 'r' : 'l';
    var P = geom.ciPass, start = side === 'r' ? P.range[0] + 8 : P.range[1] - 8;
    var end = side === 'r' ? P.range[1] - 6 : P.range[0] + 6, p = side === 'r' ? start + 4 * k : start - 4 * k;
    if (side === 'r' ? p > end : p < end) { p = end; }
    // pm is how many of the pair's four tail marks it carries when the fork arrives.
    var pm = look === 'mark' ? 4 : (/^mark\d$/.test(look) ? +look.slice(4) : 0);
    return { kind: 'passive', side: side, b: !!sched.bob1, p: p, moving: p !== end, phos: pm > 0, pm: pm,
      nsd: look === 'bob' ? 'nsd-released' : (pm === 4 ? 'nsd-displaced' : 'nsd-seated'),
      steps: Math.ceil(Math.abs(end - start) / 4) + 1 };
  }

  function insertPassive(frames, moments, sched, n) {
    // MODEL: a passing fork's crossing, frame by frame, at the moment it copies the selected origin (TERMINAL)
    // Model time stops while the fork crosses, as it does for a firing.
    var o = sched.origins[n], at = -1, i, k, out, f, v0, look;
    if (o.fate !== 'passive') { return frames; }
    for (i = 0; i < moments.length; i += 1) {
      if (moments[i].phase === 'S' && Math.abs(moments[i].t - o.time) < 1e-4) { at = i; }
    }
    if (at < 1) { return frames; }
    v0 = frames[at - 1].inset.view;
    look = v0 && v0.kind === 'origin' ? v0.state : 'mark';
    var steps = passiveView(o, sched, geom, 0, look).steps;
    out = frames.slice(0, at);
    for (k = 0; k < steps; k += 1) {
      f = JSON.parse(JSON.stringify(frames[at]));
      f.inset.view = passiveView(o, sched, geom, k, look);
      f.inset.text['ci-line1'] = n + ' is copied passively: model time paused (' + (k + 1) + ' of ' + steps + ')';
      f.inset.text['ci-line2'] = 'a fork from ' + String(o.copiedBy).split('-')[0] + ' arrives before ' + n + ' fires';
      f.inset.text['ci-line3'] = 'the CMG pushes the unfired double hexamer; Rrm3 takes it off the DNA';
      out.push(f);
    }
    for (i = at + 1; i < frames.length; i += 1) {
      if (frames[i].inset.view.kind === 'passive') {
        frames[i].inset.view.look = look;
        frames[i].inset.view.phos = out[out.length - 1].inset.view.phos;
        frames[i].inset.view.pm = out[out.length - 1].inset.view.pm;
        frames[i].inset.view.nsd = out[out.length - 1].inset.view.nsd;
      }
    }
    return out.concat(frames.slice(at + 1));
  }

  // === MODEL ===

  function listMoments(sched, pair, site) {
    // MODEL: three moments before G1/S, then S sampled through every event, then two after (TERMINAL)
    // site, when the close-up follows a telomere end, samples each of that
    // end's steps once per frame of the step's telomere workflow panel, so the
    // close-up plays every frame of each panel in order, as the origin
    // close-up plays the step panels; a run followed at an origin is sampled
    // as before.
    var out = [{ phase: 'lateM' }, { phase: 'G1' }, { phase: 'lateG1' }];
    var times = [], seen = {}, t, step, add;
    if (!sched.viable) {
      out.push({ phase: 'stuck' });
      return out;
    }
    add = function (v) {
      var key = Math.round(v * 1e4) / 1e4;
      if (!seen[key]) { seen[key] = true; times.push(key); }
    };
    step = Math.max(2, (sched.sEnd + sched.onsetFromG1S) / 60);
    if (pair && pair.viable) { step = Math.max(step, (pair.sEnd + pair.onsetFromG1S) / 60); }
    for (t = -sched.onsetFromG1S; t <= sched.sEnd + 1e-9; t += step) { add(t); }
    sched.events.forEach(function (e) { if (e.t <= sched.sEnd + 1e-9) { add(e.t); } });
    sched.sets.forEach(function (b) { if (b.back <= sched.sEnd) { add(b.back); } });
    if (pair && pair.viable) {
      // The paired run's events, moved onto this run's clock.
      var shift = pair.onsetFromG1S - sched.onsetFromG1S;
      pair.events.forEach(function (e) {
        var v = e.t + shift;
        if (v >= -sched.onsetFromG1S - 1e-9 && v <= sched.sEnd + 1e-9) { add(v); }
      });
    }
    // The moment each fork's RPA first shows, so its stall gets a frame of its own.
    sched.forks.forEach(function (f) {
      var p, a, b;
      for (p = 0; p + 1 < (f.rpaPath || []).length; p += 1) {
        a = f.rpaPath[p];
        b = f.rpaPath[p + 1];
        if (b[1] >= 0.1 && a[1] < 0.1) { add(a[0] + (b[0] - a[0]) * (0.1 - a[1]) / (b[1] - a[1])); break; }
      }
    });
    // The start of each step a daughter end takes, so every step of the
    // telomere side has a frame of its own.
    var telStarts = [];
    ['TEL-L', 'TEL-R'].forEach(function (tel) {
      ((sched.telo && sched.telo[tel]) ? sched.telo[tel].daughters : []).forEach(function (d) {
        d.steps.forEach(function (st) { telStarts.push(st.t0); });
      });
    });
    if (site) {
      ['TEL-L', 'TEL-R'].forEach(function (tel) {
        ((sched.telo && sched.telo[tel]) ? sched.telo[tel].daughters : []).forEach(function (d) {
          if (d.id !== site) { return; }
          d.steps.forEach(function (st) {
            var n = (typeof window !== 'undefined' && window.TELO) ? window.TELO.frameTotal('tw-' + st.key) : 6, j;
            n = Math.max(2, n);
            for (j = 0; j < n; j += 1) { telStarts.push(st.t0 + (st.t1 - st.t0) * j / n); }
          });
        });
      });
    }
    telStarts.forEach(function (v) { if (v <= sched.sEnd + 1e-9) { add(v); } });
    add(sched.sEnd);
    times.sort(function (a, b) { return a - b; });
    times.forEach(function (v) { out.push({ phase: 'S', t: v }); });
    // A run that copies every stretch, in HU or not, goes on to G2, with the
    // copied chromosome as two sisters held together, for RULE.g2 min, which
    // the frames sample with the telomere steps that fall in it; anaphase then
    // parts the sisters over four frames as the spindle extends. A run that
    // ends on premature extension or still in S has no G2.
    if (sched.outcome === 'anaphase') {
      var ana = sched.anaphaseAt === null || sched.anaphaseAt === undefined ? sched.sEnd : sched.anaphaseAt;
      var g2 = [], gseen = {}, gstep = Math.max(1, (ana - sched.sEnd) / 8), gt;
      var addG = function (v) {
        var key = Math.round(v * 1e4) / 1e4;
        if (!gseen[key] && v >= sched.sEnd - 1e-9 && v < ana - 1e-9) { gseen[key] = true; g2.push(key); }
      };
      addG(sched.sEnd);
      for (gt = sched.sEnd + gstep; gt < ana - 1e-9; gt += gstep) { addG(gt); }
      telStarts.forEach(addG);
      g2.sort(function (a, b) { return a - b; });
      g2.forEach(function (v) { out.push({ phase: 'G2', ana: 0, t: v }); });
      out.push({ phase: 'A1', ana: 0.25, t: ana }, { phase: 'A2', ana: 0.5, t: ana },
        { phase: 'A3', ana: 0.75, t: ana }, { phase: 'G2M', ana: 1, t: ana });
    }
    return out;
  }

  function listOneMoments(sched, sites) {
    // MODEL: the moments of a one-origin run: G1, S coarsely up to the firing, the forks densely, each end's steps, G2, anaphase (TERMINAL)
    // The arms are sampled every quarter minute, the crossing of each end's
    // repeat in six steps and the replisome's slide off the tip in two, so
    // a fork moves about as far each frame wherever it is. A followed end's
    // steps are sampled once per frame of its workflow panel, as in
    // listMoments. Moments after the last tip is copied are G2.
    var out = [{ phase: 'lateM' }, { phase: 'G1' }, { phase: 'lateG1' }], times = [], seen = {}, one = sched.one, t, j;
    var ana = sched.anaphaseAt, add = function (v) {
      var key = Math.round(v * 1e4) / 1e4;
      if (!seen[key] && key >= 0 && key < ana - 1e-9) { seen[key] = true; times.push(key); }
    };
    for (t = 0; t < one.fireAt - 1e-9; t += 4) { add(t); }
    add(one.fireAt - 1);
    for (t = one.fireAt; t < sched.sEnd; t += 0.25) { add(t); }
    one.forks.forEach(function (f) {
      for (j = 0; j <= 6; j += 1) { add(f.tJ + (f.t1 - f.tJ) * j / 6); }
      add(f.t1 + 0.2);
      add(f.t1 + 0.4);
    });
    ['TEL-L', 'TEL-R'].forEach(function (tel) {
      sched.telo[tel].daughters.forEach(function (d) {
        d.steps.forEach(function (st) {
          var n = 1, k;
          if (sites.indexOf(d.id) >= 0) {
            n = (typeof window !== 'undefined' && window.TELO) ? window.TELO.frameTotal('tw-' + st.key) : 6;
            n = Math.max(2, n);
          }
          for (k = 0; k < n; k += 1) { add(st.t0 + (st.t1 - st.t0) * k / n); }
        });
      });
    });
    for (t = sched.sEnd; t < ana - 1e-9; t += Math.max(1, (ana - sched.sEnd) / 8)) { add(t); }
    times.sort(function (a, b) { return a - b; });
    times.forEach(function (v) { out.push(v <= sched.sEnd + 1e-9 ? { phase: 'S', t: v } : { phase: 'G2', ana: 0, t: v }); });
    out.push({ phase: 'A1', ana: 0.25, t: ana }, { phase: 'A2', ana: 0.5, t: ana },
      { phase: 'A3', ana: 0.75, t: ana }, { phase: 'G2M', ana: 1, t: ana });
    return out;
  }

  function planCopies(sched) {
    // MODEL: which copy sits in which dock slot during each marking segment (TERMINAL)
    // A copy stays at its origin while that origin keeps its share; freed copies
    // go home, and the origins that gained take the lowest-numbered copies at
    // home, left to right, so an origin's copies fill its first slots.
    var ids = { ddk: [], rif: [] }, held = { ddk: {}, rif: {} }, plans = [], i;
    var byPos = Object.keys(sched.origins).sort(function (a, b) {
      return sched.origins[a].position - sched.origins[b].position;
    });
    // The free Rif1 pool shrinks as forks copy the ends, so a segment can
    // only use the copies its pool still has: copies 1 to seg.rifPool.
    for (i = 1; i <= sched.pools.ddkActive; i += 1) { ids.ddk.push(i); }
    for (i = 1; i <= (sched.pools.rif1FreeMax || sched.pools.rif1Free); i += 1) { ids.rif.push(i); }
    sched.segments.forEach(function (seg) {
      var plan = { t0: seg.t0, t1: seg.t1, ddk: {}, rif: {} };
      [['ddk', seg.ddk], ['rif', seg.rifFree]].forEach(function (pair) {
        var kind = pair[0], counts = pair[1], kept = {}, busy = {}, home, name;
        var limit = kind === 'rif' && seg.rifPool !== undefined ? seg.rifPool : Infinity;
        for (name in held[kind]) {
          if (Object.prototype.hasOwnProperty.call(held[kind], name) && counts[name] !== undefined) {
            kept[name] = held[kind][name].filter(function (c) { return c <= limit; }).slice(0, counts[name]);
            kept[name].forEach(function (c) { busy[c] = true; });
          }
        }
        home = ids[kind].filter(function (c) { return !busy[c] && c <= limit; });
        byPos.forEach(function (n) {
          if (counts[n] === undefined) { return; }
          if (!kept[n]) { kept[n] = []; }
          while (kept[n].length < counts[n] && home.length) { kept[n].push(home.shift()); }
        });
        held[kind] = kept;
        for (name in kept) {
          if (Object.prototype.hasOwnProperty.call(kept, name)) {
            kept[name].forEach(function (c, j) { plan[kind][c] = [name, j]; });
          }
        }
      });
      plans.push(plan);
    });
    return plans;
  }

  function listCallouts(sched, moments) {
    // MODEL: each checkpoint event, where it shows and the frames it shows on (TERMINAL)
    // An event's words show on the first frame at or after it and the two
    // after that, so a reader stepping through sees each event as it happens.
    var out = [], first = function (t) {
      var i;
      for (i = 0; i < moments.length; i += 1) {
        if (moments[i].phase === 'S' && moments[i].t >= t - 1e-6) { return i; }
      }
      return -1;
    };
    var add = function (where, t, words) {
      var i = first(t);
      if (i >= 0) { out.push({ where: where, from: i, to: i + 2, t: t, words: words }); }
    };
    if (!sched.viable || !sched.hu) { return out; }
    sched.forks.forEach(function (f) {
      var p, a, b, tStall = null, origin = f.origin;
      for (p = 0; p + 1 < f.rpaPath.length && tStall === null; p += 1) {
        a = f.rpaPath[p];
        b = f.rpaPath[p + 1];
        if (b[1] >= 0.1 && a[1] < 0.1) { tStall = a[0] + (b[0] - a[0]) * (0.1 - a[1]) / (b[1] - a[1]); }
      }
      if (tStall !== null && f.id.indexOf('-left') > 0) { add(origin, tStall, 'RPA on ssDNA'); }
      (f.downs || []).forEach(function (d) { add(origin, d[0], 'fork collapses'); });
    });
    sched.events.forEach(function (e) {
      if (e.kind === 'restart') { add(e.fork.split('-')[0], e.t, 'fork restarts'); }
    });
    // A kinetochore losing its anchor, where it sits.
    (sched.anchors ? sched.anchors.sites : []).forEach(function (k) {
      if (k.lostAt !== null && (k.active || k.name === 'CEN')) {
        add(k.name, k.lostAt, k.name === 'CEN' ? 'CEN kinetochore lost' : 'AK kinetochore lost');
      }
    });
    if (sched.rad53At === null && sched.signal) {
      // No Rad53 to receive it: say so when the signal reaches the threshold.
      sched.signal.path.forEach(function (p, j) {
        var q = sched.signal.path[j + 1];
        if (q && p[1] < sched.signal.threshold && q[1] >= sched.signal.threshold) {
          add('rad53', p[0] + (q[0] - p[0]) * (sched.signal.threshold - p[1]) / (q[1] - p[1]),
            'Mec1 signal at threshold: no Rad53 to switch on');
        }
      });
    }
    if (sched.rad53At !== null) {
      add('rad53', sched.rad53At, 'Rad53 on: Mec1 signal from ' + sched.rad53Forks + ' stalled forks');
      if (sched.arms.dbf4) { add('ddk', sched.rad53At, ''); }
      Object.keys(sched.origins).forEach(function (n) {
        var live = sched.forks.some(function (f) {
          return f.origin === n && f.t0 <= sched.rad53At && f.t1 > sched.rad53At;
        });
        if (live) { add(n, sched.rad53At, 'Rad53 slows the forks'); }
      });
    }
    return out;
  }

  function describeTexts(sched, geom) {
    // MODEL: every word the run writes into the panel, the same on every frame (TERMINAL)
    var p = sched.pools, out = {}, fired, groups = [], last = null, order, passive;
    var sMax = Math.max(geom.sMax, sched.sEnd === null ? 0 : Math.ceil(sched.sEnd / 4) * 4);
    var fmt = function (v) { return String(Math.round(v * 10) / 10); };
    out['txt-label'] = sched.label;
    out['txt-lethal'] = sched.stuck ? 'Cannot enter S: ' + sched.stuck : ' ';
    out['txt-pools'] = 'DDK: ' + p.ddkActive + ' of ' + p.ddkTotal + ' active. '
      + (p.rif1Total > 0
        ? 'Rif1-PP1: ' + (p.rif1Total - p.rif1Free) + ' bound at the ends, ' + p.rif1Free + ' free'
        : 'Rif1 absent');
    var endAt = Math.round(sched.sEnd + sched.onsetFromG1S);
    out['txt-outcome'] = !sched.viable ? ' ' : (sched.outcome === 'anaphase'
      ? 'Copied in full ' + endAt + ' min after G1/S, anaphase at '
        + Math.round((sched.anaphaseAt === null || sched.anaphaseAt === undefined ? sched.sEnd : sched.anaphaseAt)
          + sched.onsetFromG1S) + ' min'
      : (sched.outcome === 'premature' ? 'Spindle extends ' + Math.round(sched.extStart + sched.onsetFromG1S)
        + ' min after G1/S with the chromosome partly copied; no anaphase'
        : 'Still in S ' + endAt + ' min after G1/S'));
    if (sched.one) {
      // The one-origin chromosome has no origin program, so its words name the
      // origin's firing, the ends' copying and anaphase.
      out['txt-pools'] = 'One origin, fired ' + fmt(sched.one.fireAt) + ' min after G1/S. '
        + (p.rif1Total > 0 ? 'Rif1-PP1: ' + (p.rif1Total - p.rif1Free) + ' bound at the ends, ' + p.rif1Free + ' free'
          : 'Rif1 absent');
      out['txt-outcome'] = 'TEL-R copied at ' + fmt(sched.telomeres['TEL-R'].t) + ' min, TEL-L at '
        + fmt(sched.telomeres['TEL-L'].t) + ' min; anaphase at ' + fmt(sched.anaphaseAt) + ' min';
    }
    out['txt-cond'] = [sched.hu ? 'In HU from G1/S' : '', sched.hu || sched.checkpoint !== 'wt' ? sched.checkpointLabel : '',
      sched.bob1 ? 'bob1 pairs permissive 1/30 of the time' : ''].filter(function (w) {
      return w;
    }).join('. ');
    geom.ticks.forEach(function (f, k) {
      out['txt-tick-' + k] = String(Math.round(sMax * f))
        + (k === geom.ticks.length - 1 ? ' min into S' : '');
    });
    Object.keys(sched.origins).forEach(function (n) {
      var o = sched.origins[n];
      out['txt-fate-' + n] = o.fate === 'fired'
        ? (o.route === 'bypass' ? 'bypass ' : 'fires ') + fmt(o.time)
        : o.fate === 'passive' ? 'passive ' + fmt(o.time)
          : o.fate === 'unlicensed' ? 'not licensed'
            : o.fate === 'unfired' ? 'not fired' : 'not copied';
    });
    ['L', 'R'].forEach(function (side) {
      var hit = sched.telomeres['TEL-' + side];
      out['txt-teldone-' + side] = hit ? 'copied at ' + fmt(hit.t) + ' min' : 'not copied';
    });
    fired = Object.keys(sched.origins).filter(function (n) { return sched.origins[n].fate === 'fired'; })
      .sort(function (a, b) {
        return (sched.origins[a].time - sched.origins[b].time)
          || (sched.origins[a].position - sched.origins[b].position);
      });
    fired.forEach(function (n) {
      var t = sched.origins[n].time;
      if (last !== null && Math.abs(t - last) < 1e-6) { groups[groups.length - 1].push(n); }
      else { groups.push([n]); }
      last = t;
    });
    order = groups.map(function (g) { return g.join(' = '); }).join(', ');
    passive = Object.keys(sched.origins).filter(function (n) { return sched.origins[n].fate === 'passive'; })
      .sort(function (a, b) { return sched.origins[a].position - sched.origins[b].position; });
    var unfired = Object.keys(sched.origins).filter(function (n) { return sched.origins[n].fate === 'unfired'; })
      .sort(function (a, b) { return sched.origins[a].position - sched.origins[b].position; });
    var collapsed = sched.forks.filter(function (f) { return f.end && f.end.indexOf('collapsed') === 0; }).length;
    var list = function (names) {
      return names.length > 1 ? names.slice(0, -1).join(', ') + ' and ' + names[names.length - 1] : names[0];
    };
    out['txt-order'] = 'Firing order: ' + (order || 'none')
      + (passive.length ? '; ' + list(passive) + ' copied passively' : '')
      + (unfired.length ? '; ' + list(unfired) + ' never fired' : '')
      + (collapsed ? '; ' + collapsed + (collapsed > 1 ? ' forks' : ' fork') + ' collapsed' : '')
      + (sched.hu ? '; spindle ' + fmt(sched.spindle.score.at.length) + ' \u00b5m at '
        + Math.round(sched.spindle.score.at.fromG1S + CHROM_RULE.RULE.g1Release) + ' min'
        + (sched.spindle.score.at.extended ? ', extended' : ', short') : '');
    if (sched.one) { out['txt-order'] = 'Hypothetical chromosome: one origin, the rest of the genome taken as copied'; }
    out.sMax = sMax;
    return out;
  }

  function frameAt(m, idx, sched, geom, plans, texts, events) {
    // MODEL: every fx state, actor offset and text on the panel at one moment (TERMINAL)
    var fx = {}, actors = {}, text = {}, k, id;
    var pre = m.phase === 'lateM' || m.phase === 'G1' || m.phase === 'lateG1' || m.phase === 'stuck';
    var post = m.ana !== undefined;
    var ana = post ? m.ana : 0;
    var now = post ? sched.sEnd : (m.phase === 'S' ? m.t : null);
    var onset = sched.onsetFromG1S, sMax = texts.sMax, theta = sched.rates.theta;
    var minScale = (geom.sX1 - geom.sX0) / sMax;
    var px, seg = null, plan = null, anyCtf = false, bob1 = sched.bob1;
    var kb = geom.kbScale;

    for (id in texts) {
      if (Object.prototype.hasOwnProperty.call(texts, id) && id !== 'sMax') { text[id] = texts[id]; }
    }
    // Playhead.
    px = { lateM: 70, G1: 110, lateG1: 150, stuck: 180, G2: 740, A1: 760, A2: 780, A3: 800, G2M: 820 }[m.phase];
    if (m.phase === 'G2' && m.t !== undefined && sched.anaphaseAt !== null && sched.anaphaseAt > sched.sEnd + eps) {
      // G2 runs from the end of S to anaphase, across the G2 band's first part.
      px = 722 + 28 * (m.t - sched.sEnd) / (sched.anaphaseAt - sched.sEnd);
    }
    if (px === undefined) {
      px = now < 0 ? (onset > 0 ? 160 + 40 * (now + onset) / onset : 200) : geom.sX0 + now * minScale;
    }
    actors['actor-playhead'] = Math.round((px - geom.playheadX) * 100) / 100;
    fx['fx-lethal'] = m.phase === 'stuck' ? 'present' : 'gone';
    var rad53On = !pre && sched.rad53At !== null && now >= sched.rad53At - eps;
    var dntp = 1;
    if (!pre && sched.hu) {
      dntp = sched.segments.length ? sched.segments[0].dntp : 1;
      sched.segments.forEach(function (g) { if (g.t0 - eps <= now) { dntp = g.dntp; } });
    }
    fx['fx-rad53'] = rad53On ? 'present' : 'fading';
    actors['actor-dntp'] = Math.round(-(1 - dntp) * geom.dntpW * 100) / 100;
    // The Mec1 signal: the RPA summed over the stalled forks, against the threshold.
    var sig = 0;
    if (!pre && sched.signal) {
      sched.signal.path.forEach(function (p, i) {
        var q = sched.signal.path[i + 1];
        if (p[0] <= now + eps) { sig = q && q[0] > now ? p[1] + (q[1] - p[1]) * (now - p[0]) / (q[0] - p[0]) : p[1]; }
      });
    }
    var sigFrac = rad53On ? 1 : Math.min(1, sig / (sched.signal ? sched.signal.threshold : 1));
    actors['actor-sig'] = Math.round(-(1 - sigFrac) * geom.sigW * 100) / 100;
    fx['fx-sigarrow'] = sig > 0 || rad53On ? 'present' : 'fading';
    fx['fx-out-sld3'] = rad53On && sched.arms.sld3 ? 'present' : 'fading';
    fx['fx-out-dbf4'] = rad53On && sched.arms.dbf4 ? 'present' : 'fading';
    fx['fx-out-dun1'] = rad53On && sched.arms.dun1 ? 'present' : 'fading';
    fx['fx-out-fork'] = rad53On && sched.arms.rad53 ? 'present' : 'fading';
    // Event words, each where its event happened, for the frames listCallouts set.
    fx['fx-ev-rad53'] = 'gone';
    fx['fx-ev-ddk'] = 'gone';
    geom.origins.forEach(function (go) { fx['fx-ev-' + go.name] = 'gone'; });
    fx['fx-ev-CEN'] = 'gone';
    fx['fx-ev-AK'] = 'gone';
    events.forEach(function (ev) {
      if (idx >= ev.from && idx <= ev.to) {
        fx['fx-ev-' + ev.where] = 'present';
        if (ev.where !== 'ddk' && !sched.origins[ev.where]) { text['txt-ev-' + ev.where] = ev.words; }
        if (sched.origins[ev.where]) {
          // An origin's words go on two rows, split where the rows come out most even.
          var parts = ev.words.split(' '), best = 1, k2;
          for (k2 = 1; k2 < parts.length; k2 += 1) {
            if (Math.abs(parts.slice(0, k2).join(' ').length - parts.slice(k2).join(' ').length)
              < Math.abs(parts.slice(0, best).join(' ').length - parts.slice(best).join(' ').length)) { best = k2; }
          }
          text['txt-ev-' + ev.where + '-a'] = parts.slice(0, best).join(' ');
          text['txt-ev-' + ev.where + '-b'] = parts.slice(best).join(' ');
        }
      }
    });
    if (m.phase === 'S') {
      sched.segments.forEach(function (g, i) {
        if (g.t0 - eps <= now && now < g.t1 - eps) { seg = g; plan = plans[i]; }
      });
    }
    // The Rif1 the ends hold and the copies left free, now: from the segment
    // in S, from G1/S before it, and from the last segment once S is over.
    // Copying an end doubles its array, so the free pool shrinks as forks
    // reach the ends.
    var rifTel = sched.pools.rif1Tel || { 'TEL-L': sched.pools.rif1Captured, 'TEL-R': sched.pools.rif1Captured };
    var rifPool = sched.pools.rif1Free;
    var lastSeg = sched.segments.length ? sched.segments[sched.segments.length - 1] : null;
    rifTel = JSON.parse(JSON.stringify(rifTel));
    if (seg && seg.rifPool !== undefined) { rifTel = JSON.parse(JSON.stringify(seg.rifTel)); rifPool = seg.rifPool; }
    else if ((post || (m.phase === 'S' && now >= sched.sEnd - eps)) && lastSeg && lastSeg.rifPool !== undefined) {
      rifTel = JSON.parse(JSON.stringify(lastSeg.rifTel));
      rifPool = lastSeg.rifPool;
      ['TEL-L', 'TEL-R'].forEach(function (tel) {
        var e = sched.telo && sched.telo[tel];
        if (e && e.daughters.length === 2) { rifTel[tel] = e.daughters[0].rif + e.daughters[1].rif; }
      });
      if (sched.pools.rif1Total > 0) {
        rifPool = Math.max(0, sched.pools.rif1Total - rifTel['TEL-L'] - rifTel['TEL-R']);
      }
    }
    for (k = 0; k < 2; k += 1) {
      fx['fx-rif1-' + (k ? 'R' : 'L')] = rifTel[k ? 'TEL-R' : 'TEL-L'] > 0 ? 'present' : 'gone';
    }
    text['txt-pools'] = 'DDK: ' + sched.pools.ddkActive + ' of ' + sched.pools.ddkTotal + ' active. '
      + (sched.pools.rif1Total > 0
        ? 'Rif1-PP1: ' + (rifTel['TEL-L'] + rifTel['TEL-R']) + ' bound at the ends, ' + rifPool + ' free'
        : 'Rif1 absent');

    // Origins.
    var forkIndex = 0, seen = {};
    geom.origins.forEach(function (go) {
      var n = go.name, o = sched.origins[n], tf = o.time, stage, marks = 0, frac, pm;
      var done = !pre && tf !== null && now >= tf - eps;
      var marking = !pre && !done && sched.viable && o.fate !== 'unlicensed';
      var perm = !!(seg && seg.perm[n]);
      var states = ['morc', 'mcdc6', 'mlic', 'mlicb', 'mmark1', 'mmark2', 'mmark3', 'mmark',
        'mmarkb1', 'mmarkb2', 'mmarkb3', 'mmarkb', 'mbob', 'mfire', 'mfirebm', 'mfireb', 'mspent'];
      if (!pre) {
        var upto = tf !== null ? Math.min(now, tf) : now;
        sched.segments.forEach(function (g) {
          if (g.marks0[n] !== undefined && g.t0 - eps <= upto) {
            var dt = Math.min(upto, g.t1) - g.t0;
            var add = sched.rates.kDdk * g.ddk[n];
            var kk = sched.rates.kPp1 * (g.rifFree[n] + g.rifCap[n]);
            var mInf;
            if (kk > 0) { mInf = add / kk; marks = mInf + (g.marks0[n] - mInf) * Math.exp(-kk * dt); }
            else { marks = g.marks0[n] + add * dt; }
          }
        });
      }
      var unlic = o.fate === 'unlicensed';
      if (m.phase === 'lateM') { stage = 'morc'; }
      else if (m.phase === 'G1') { stage = 'mcdc6'; }
      else if (unlic) { stage = 'morc'; }
      else if (m.phase === 'lateG1' || m.phase === 'stuck') { stage = bob1 ? 'mlicb' : 'mlic'; }
      else if (o.fate === 'fired' && Math.abs(now - tf) < eps) {
        stage = o.route === 'bypass' ? 'mfireb' : (bob1 ? 'mfirebm' : 'mfire');
      } else if (done) { stage = 'mspent'; }
      else if (perm) { stage = 'mbob'; }
      else {
        // The pair shows one tail mark for each quarter of the line's marks
        // (tools/make_panels.py MCM_MARK_ORDER); a ready origin shows all
        // four, the NSD moved off its seat so Sld3 can bind.
        pm = (seg && seg.ready[n]) || marks >= theta - eps ? 4 : Math.min(3, Math.floor(marks / (theta / 4) + eps));
        stage = (bob1 ? 'mmarkb' : 'mmark') + (pm === 4 ? '' : String(pm));
        if (pm === 0) { stage = bob1 ? 'mlicb' : 'mlic'; }
      }
      states.forEach(function (st) { fx['fx-' + st + '-' + n] = st === stage && ana === 0 ? 'present' : 'gone'; });
      seen[n] = { stage: stage, marks: marks, perm: perm, done: done, now: now, pre: pre, post: post,
        phase: m.phase, seg: seg, rad53On: rad53On };
      fx['fx-lock-' + n] = pre ? 'present' : 'gone';
      frac = Math.max(0, Math.min(1, marks / theta));
      actors['actor-mfill-' + n] = [0, Math.round(-geom.meterH * frac * 100) / 100];
      actors['actor-theta-' + n] = [0, perm && !done ? geom.meterH : 0];
      fx['fx-mfill-' + n] = done && o.fate === 'fired' ? 'fading' : 'present';
      fx['fx-mgrey-' + n] = done && o.fate === 'passive' ? 'present' : 'gone';
      fx['fx-pas-' + n] = done && o.fate === 'passive' && ana === 0 ? 'present' : 'gone';
      fx['fx-lablic-' + n] = m.phase !== 'lateM' && m.phase !== 'G1' && !done && !unlic ? 'present' : 'gone';
      fx['fx-labfate-' + n] = done || (unlic && m.phase !== 'lateM' && m.phase !== 'G1') ? 'present' : 'gone';
      if (go.recruiter === 'Fkh1/2') { fx['fx-rec-' + n] = marking ? 'present' : 'fading'; }
      if (go.recruiter === 'Ctf19' && marking) { anyCtf = true; }
      if (o.telomere !== null) {
        fx['fx-drain-' + n] = marking && sched.pools.rif1Captured > 0 ? 'present' : 'gone';
      }
      // Forks and the copied strips behind them.
      ['left', 'right'].forEach(function (side) {
        var fid = n + '-' + side, fork = null, off = 0, x = null, i, a, b, live = false, rpaNow = 0, down = false;
        sched.forks.forEach(function (c) { if (c.id === fid) { fork = c; } });
        fx['fx-chrfork-' + fid] = 'gone';
        if (fork && !pre && now >= fork.t0 - eps) {
          // Position from the fork's path, which bends wherever its speed changed.
          x = fork.path[fork.path.length - 1][1];
          for (i = 0; i + 1 < fork.path.length; i += 1) {
            a = fork.path[i];
            b = fork.path[i + 1];
            if (now >= a[0] - eps && now <= b[0] + eps) {
              x = b[0] - a[0] > 1e-9 ? a[1] + (b[1] - a[1]) * (now - a[0]) / (b[0] - a[0]) : b[1];
              break;
            }
          }
          off = (x - fork.x0) * kb;
          live = fork.t0 + eps < now && (now < fork.t1 - eps || fork.end === 'window'
            || fork.end === 'collapsed');
          down = (fork.downs || []).some(function (d) {
            return now >= d[0] - eps && (d[1] === null || now < d[1] - eps);
          });
          fx['fx-chrfork-' + fid] = !live ? 'gone' : (down ? 'fading' : 'present');
          // RPA level at this fork now, from its recorded path.
          rpaNow = 0;
          (fork.rpaPath || []).forEach(function (p, j) {
            var q = fork.rpaPath[j + 1];
            if (p[0] <= now + eps) { rpaNow = q && q[0] > now ? p[1] + (q[1] - p[1]) * (now - p[0]) / (q[0] - p[0]) : p[1]; }
          });
        }
        [1, 2, 3].forEach(function (k) {
          fx['fx-rpa' + k + '-' + fid] = rpaNow >= k - 0.9 ? 'present' : 'gone';
        });
        // A signal token flies from this fork's RPA up to the Mec1 gauge on a
        // three-frame cycle (appear at the fork, fly up, return unseen) while
        // the fork carries RPA and Rad53 is not yet on.
        var phase = (idx + forkIndex) % 3, sending = fork && live && sched.hu && !rad53On
          && rpaNow >= 0.1 && !down;
        var home = geom.tokenHome;
        var fxPos = geom.x0 + (x === null ? 0 : x) * kb - (fork ? fork.direction : 0) * geom.rpaTrail;
        fx['fx-sig-' + fid] = sending && phase !== 2 ? 'present' : 'gone';
        actors['actor-sig-' + fid] = sending && phase !== 1
          ? [Math.round((fxPos - home[0]) * 100) / 100, Math.round((geom.rpaY - home[1]) * 100) / 100]
          : [0, 0];
        forkIndex += 1;
        actors['actor-chrfork-' + fid] = Math.round(off * 100) / 100;
        actors['actor-copy-' + fid] = Math.round(off * 100) / 100;
      });
    });
    fx['fx-rec-CEN'] = anyCtf ? 'present' : 'fading';

    // Firing-factor sets: at an origin while it holds them, in the tray otherwise.
    geom.setRests.forEach(function (rest, i) {
      var off = [0, 0];
      if (!pre) {
        sched.sets.forEach(function (b) {
          if (b.set === i + 1 && b.out - eps <= now && now < b.back - eps) {
            var ox = geom.x0 + sched.origins[b.origin].position * kb;
            off = [Math.round((ox - rest[0]) * 100) / 100, Math.round((geom.dnaY - rest[1]) * 100) / 100];
          }
        });
      }
      actors['actor-bundle-' + (i + 1)] = off;
      // Rad53 marks Sld3 on a set at rest, and a marked set cannot leave.
      fx['fx-setmark-' + (i + 1)] = rad53On && sched.arms.sld3 && off[0] === 0 && off[1] === 0
        ? 'present' : 'gone';
    });
    // A home whose copies Rad53 holds is drawn with a solid outline.
    fx['fx-held-sets'] = !pre && rad53On && sched.arms.sld3 ? 'present' : 'gone';
    fx['fx-held-ddk'] = !pre && rad53On && sched.arms.dbf4 && sched.pools.ddkActive > 0 ? 'present' : 'gone';

    // DDK and Rif1-PP1 copies: docked during the segment that deals them,
    // home otherwise. DDK docks on the telomere side of the meter, Rif1-PP1 on
    // the centromere side. Inactive DDK copies are faded and never move.
    [['ddk', geom.ddkHomes, sched.pools.ddkActive], ['rif', geom.rifHomes, rifPool]]
      .forEach(function (job) {
        var kind = job[0];
        job[1].forEach(function (home, j) {
          var c = j + 1, off = [0, 0], spot, pos, x, side, cx, cy;
          if (kind === 'ddk') {
            fx['fx-ddk-' + c] = c <= job[2] ? 'present' : 'fading';
            // Rad53 marks Dbf4 on every active copy and holds them home.
            fx['fx-ddkmark-' + c] = rad53On && sched.arms.dbf4 && c <= job[2] ? 'present' : 'gone';
            // dbf4-m25: the site Rad53 would mark is filled, on every copy.
            fx['fx-ddkblock-' + c] = sched.dbf4Blocked ? 'present' : 'gone';
          }
          else { fx['fx-rif-' + c] = c <= job[2] ? 'present' : 'gone'; }
          if (plan && plan[kind][c]) {
            spot = plan[kind][c];
            pos = sched.origins[spot[0]].position;
            x = geom.x0 + pos * kb;
            side = pos < 120 ? 1 : -1;
            if (kind === 'ddk') {
              cx = x - side * (6 + geom.ddkCell * (spot[1] % geom.ddkCols + 0.5));
              cy = geom.dockTop + geom.ddkCell * Math.floor(spot[1] / geom.ddkCols);
            } else {
              cx = x + side * (6 + geom.rifCellW * (spot[1] % geom.rifCols + 0.5));
              cy = geom.dockTop + geom.rifCellH * Math.floor(spot[1] / geom.rifCols);
            }
            off = [Math.round((cx - home[0]) * 100) / 100, Math.round((cy - home[1]) * 100) / 100];
          }
          actors['actor-' + kind + '-' + c] = off;
        });
      });

    // The spindle: its length from the run's path, on the gauge and in words.
    var len = 0, U = CHROM_RULE.RULE;
    if (m.phase === 'S') { len = CHROM_RULE.spindleAt(sched, now); }
    else if (m.phase === 'G2' && m.t !== undefined) { len = CHROM_RULE.spindleAt(sched, m.t); }
    else if (post) {
      len = CHROM_RULE.spindleAt(sched, (sched.anaphaseAt !== null && sched.anaphaseAt !== undefined
        ? sched.anaphaseAt : sched.sEnd) + ana * (U.anaphaseLen - U.spindleShort) / U.anaphaseRate);
    }
    actors['actor-spl'] = [Math.round(Math.min(len, 10) * geom.splUm * 100) / 100, 0];
    actors['actor-spb2'] = [Math.round(Math.min(len, 10) * geom.splUm * 100) / 100, 0];
    // Red marks a spindle extended before anaphase, the phenotype; an
    // anaphase spindle is the normal colour.
    fx['fx-spl-short'] = len < U.spindleLine || post ? 'present' : 'gone';
    fx['fx-spl-ext'] = len >= U.spindleLine && !post ? 'present' : 'gone';
    text['txt-spl'] = len <= 0 ? 'spindle: pole bodies not yet separated'
      : 'spindle ' + (Math.round(len * 10) / 10).toFixed(1) + ' \u00b5m' + (ana > 0 ? ', anaphase'
        : (post ? ', metaphase' : (len >= U.spindleLine ? ', extended' : ', short')));
    // Kinetochores: each lets its microtubule go when resection reaches it.
    var sites = sched.anchors ? sched.anchors.sites : [], cen = null, ak = null;
    sites.forEach(function (k) { if (k.name === 'CEN') { cen = k; } else { ak = k; } });
    var gone = function (k) { return !!k && !pre && k.lostAt !== null && now >= k.lostAt - eps; };
    // The CEN is copied once any fork has passed it; from then the sister
    // kinetochore takes a microtubule from the other pole (biorientation).
    var cenX = 120, copiedCen = post || (!pre && sched.forks.some(function (f) {
      var x = f.path[f.path.length - 1][1], i, a, b;
      for (i = 0; i + 1 < f.path.length; i += 1) {
        a = f.path[i];
        b = f.path[i + 1];
        if (now >= a[0] - eps && now <= b[0] + eps) {
          x = b[0] - a[0] > 1e-9 ? a[1] + (b[1] - a[1]) * (now - a[0]) / (b[0] - a[0]) : b[1];
          break;
        }
      }
      return now >= f.t0 - eps && (f.x0 - cenX) * (x - cenX) <= 0 && f.x0 !== x;
    }));
    var pull = ana * geom.anaDy;
    fx['fx-kt-CEN'] = gone(cen) ? 'fading' : 'present';
    actors['actor-kmt-CEN'] = [0, gone(cen) ? -geom.kmtGone : -pull];
    actors['actor-kt1'] = [0, -pull];
    actors['actor-ctf'] = [0, -pull];
    fx['fx-kt2-CEN'] = copiedCen && !gone(cen) ? 'present' : 'gone';
    actors['actor-kt2'] = [0, pull];
    actors['actor-kmt2-CEN'] = [0, pull];
    // The sisters: shown from G2, parted in anaphase in a V led by the
    // centromere, the telomeres trailing at a quarter of its travel.
    fx['fx-dna'] = post ? 'gone' : 'present';
    fx['fx-sisters'] = post ? 'present' : 'gone';
    for (k = 0; k < geom.sisN; k += 1) {
      var mid = (k + 0.5) * geom.sisSegKb, lead = 1 - 0.75 * Math.abs(mid - cenX) / cenX;
      actors['actor-sis-t-' + k] = [0, Math.round(-pull * lead * 100) / 100];
      actors['actor-sis-b-' + k] = [0, Math.round(pull * lead * 100) / 100];
    }
    fx['fx-ak-site'] = ak && !post ? 'present' : 'gone';
    fx['fx-ak-on'] = ak && ak.active && !post ? 'present' : 'gone';
    fx['fx-kt-AK'] = gone(ak) ? 'fading' : 'present';
    actors['actor-kmt-AK'] = [0, gone(ak) ? geom.kmtGone : 0];
    // Resection: the stretch on each side of a collapsed fork grows at the
    // rule's rate up to its reach, with Exo1 at each front.
    geom.origins.forEach(function (go) {
      ['left', 'right'].forEach(function (side) {
        var fid = go.name + '-' + side, c = null, e = 0;
        (sched.collapses || []).forEach(function (q) { if (q.fork === fid) { c = q; } });
        var on = !!c && !pre && now >= c.t - eps && ana === 0;
        if (on) { e = Math.min(sched.anchors.reach, sched.anchors.rate * (now - c.t)) * kb; }
        fx['fx-res-' + fid] = on ? 'present' : 'gone';
        actors['actor-res-' + fid] = Math.round((on ? (c.x - go.position) * kb : 0) * 100) / 100;
        actors['actor-resclip-' + fid + '-l'] = Math.round(-e * 100) / 100;
        actors['actor-resclip-' + fid + '-r'] = Math.round(e * 100) / 100;
        actors['actor-exo-' + fid + '-l'] = Math.round(-e * 100) / 100;
        actors['actor-exo-' + fid + '-r'] = Math.round(e * 100) / 100;
      });
    });

    // Telomeres and the readout.
    ['L', 'R'].forEach(function (side) {
      var hit = sched.telomeres['TEL-' + side];
      var reached = !pre && hit && now >= hit.t - eps;
      fx['fx-telwait-' + side] = reached ? 'gone' : 'present';
      fx['fx-teldone-' + side] = reached ? 'present' : 'gone';
    });
    fx['fx-order'] = sched.viable && (post || (!pre && now >= sched.sEnd - eps)) ? 'present' : 'gone';
    // clock is the run's minute in every phase that has one; t only in S.
    return { fx: fx, actors: actors, text: text, seen: seen, phase: m.phase, t: m.phase === 'S' ? m.t : null,
      clock: m.t === undefined ? null : m.t };
  }

  function telViewAt(m, sched, geom) {
    // SUB-CONTROLLER: the telomere view at one moment: the forks, the parental duplex and the bubble, each end

    // The view draws the one-origin chromosome (sched.one). A run with no
    // one-origin chromosome draws it unreplicated, its ends capped.
    // Moments are rounded to 1e-4 min, so the view compares times at 1e-3.
    var G = geom.tel, fx = {}, actors = {}, text = {}, sites = {}, eps = 1e-3;
    var clock = readClock(m, sched);
    var forks = placeForks(clock, sched, G, fx, actors);
    drawEnds(clock, sched, G, forks, fx, actors, text, sites);
    countPools(clock, sched, fx, text);
    return { fx: fx, actors: actors, text: text, sites: sites };

    // === SUB-CONTROLLERS ===

    function readClock(m, sched) {
      // MODEL: the run's minute at this moment, and whether the cell is still before S (TERMINAL)
      var pre = m.phase === 'lateM' || m.phase === 'G1' || m.phase === 'lateG1' || m.phase === 'stuck';
      return { pre: pre, now: pre ? -Infinity : (m.t !== undefined ? m.t : sched.sEnd) };
    }

    function placeForks(clock, sched, G, fx, actors) {
      // MODEL: each fork's x, the clip edges it sets, its labels and whether it is still on the chromosome (TERMINAL)
      // Before the origin fires the two CMGs sit side by side on it. A fork
      // crosses its arm at fork speed and then the end's repeat, which it
      // crosses in the time its length takes; the drawing slows that crossing
      // down, because the frames sample it densely. At the tip the replisome
      // slides off over RULE-free drawing time, then is gone.
      var out = {}, one = sched.one, slideFor = 0.4, sep = 0;
      ['L', 'R'].forEach(function (side) {
        var d = side === 'L' ? -1 : 1, J = side === 'L' ? G.jl : G.jr, f = null, x = G.ori, t = clock.now;
        var bp = sched.telo['TEL-' + side].bp, state = 'present', gone = false, onEnd = false, k;
        if (one) { one.forks.forEach(function (c) { if (c.side === side) { f = c; } }); }
        if (f && t > f.t0 + eps) {
          if (t < f.tJ - eps) { x = G.ori + (J - G.ori) * (t - f.t0) / (f.tJ - f.t0); }
          else if (t < f.t1 - eps) { x = J + d * bp * G.s * (t - f.tJ) / (f.t1 - f.tJ); onEnd = true; }
          else {
            k = Math.min(1, (t - f.t1) / slideFor);
            x = J + d * (bp * G.s + G.slide * k);
            onEnd = true;
            gone = t >= f.t1 + slideFor - eps;
            state = gone ? 'gone' : (k > 0.5 ? 'fading' : 'present');
          }
        }
        out[side] = { x: x, f: f, fired: !!f && t > f.t0 + eps, gone: gone, onEnd: onEnd, past: !!f && t >= f.t1 - eps };
        fx['fx-tvfork-' + side] = state;
        fx['fx-tvforkb-' + side] = state;
        fx['fx-tvnick-' + side] = out[side].fired && !onEnd ? 'present' : 'gone';
        actors['actor-tvfork-' + side] = [round(x - G.ori), 0];
        actors['actor-tvforkb-' + side] = [round(x - G.ori), 0];
      });
      sep = out.R.x - out.L.x;
      ['L', 'R'].forEach(function (side) {
        var o = out[side], d = side === 'L' ? -1 : 1, edge;
        // Strand labels show once the bubble is wide enough for both forks' labels.
        fx['fx-tvslab-' + side] = o.fired && !o.past && sep >= 4 * G.labDx - 20 ? 'present' : 'gone';
        // The parental duplex ends at the fork; before firing it runs through the origin.
        edge = !o.fired ? G.ori : (o.past ? (side === 'L' ? G.jl : G.jr) + d * (G.maxBp * G.s + 100) : o.x);
        actors['actor-tvparclip-' + side.toLowerCase()] = [round(edge - G.ori), 0];
        fx['fx-tvdiag-' + side] = o.fired ? 'present' : 'gone';
        // The bubble starts behind the fork, and once the fork is off the tip it
        // opens past anything an end can grow to.
        edge = !o.fired ? G.ori - d * G.inset : (o.past ? o.x + d * 400 : o.x - d * G.inset);
        actors['actor-tvbubclip-' + side.toLowerCase()] = [round(edge - G.ori), 0];
      });
      fx['fx-tvori'] = out.L.fired ? 'gone' : 'present';
      fx['fx-tvsis'] = out.L.fired ? 'present' : 'gone';
      return out;
    }

    function drawEnds(clock, sched, G, forks, fx, actors, text, sites) {
      // MODEL: the parental ends, and each daughter end's strands, sites, Rif1, proteins and words (TERMINAL)
      // A daughter's strands are read off its steps: a leading-made end is
      // blunt until resection opens a 3' overhang of OH nt; a lagging-made
      // end starts with the short overhang the last Okazaki fragment leaves
      // and is resected to the same overhang; telomerase lengthens the
      // G-strand across step06; fill-in brings the C-strand back to a short
      // overhang across step08. Repeats telomerase adds and C-strand filled
      // in are new DNA, drawn light on either sister.
      var OH = 30, SHORT = 8, now = clock.now, busy = {};
      var pct = function (p) { return p < 0.005 ? 'under 1%' : Math.round(100 * p) + '%'; };
      ['L', 'R'].forEach(function (side) {
        var e = sched.telo['TEL-' + side], sx = side === 'L' ? -1 : 1, par = 'par-' + side;
        var copied = !clock.pre && e.copiedAt !== null && now >= e.copiedAt - eps;
        // Parts a clip hides are also drawn gone, so nothing hidden still
        // counts as drawn: the parental end once its fork has passed, and a
        // daughter end's sites before its fork reaches the repeat.
        var reached = forks[side].onEnd || copied;
        if (copied) { setEnd(par, sx, e.bp + SHORT, e.bp, null, null, 0, {}, true); }
        else { setEnd(par, sx, e.bp + SHORT, e.bp, null, null, e.rif, { cdc13: 'present', st: 'present' }); }
        [1, 2].forEach(function (k) {
          var site = 'tel-' + side + '-s' + k, d = null, st = null, p = 0, gbp, cbp, key, step, lab;
          var prot = {};
          e.daughters.forEach(function (x) { if (x.sister === k) { d = x; } });
          if (!d || !copied) {
            gbp = d ? d.bp0 : e.bp;
            cbp = gbp;
            key = 'step09';
            step = 'capped; not yet copied';
            lab = k === 1 ? 'TEL-' + side + ', parental end: ' + e.bp + ' bp, ' + e.sites + ' Rap1 sites, ' + e.rif + ' Rif1' : ' ';
            setEnd(site, sx, gbp, cbp, null, null, 0, {}, !reached);
          } else {
            d.steps.forEach(function (x) { if (x.t0 <= now + eps) { st = x; } });
            if (!st) { st = d.steps[0]; }
            p = st.t1 - st.t0 > eps ? Math.max(0, Math.min(1, (now - st.t0) / (st.t1 - st.t0))) : 1;
            key = st.key;
            gbp = d.bp0;
            cbp = d.bp0;
            if (key === 'lag01') { cbp = d.bp0 - SHORT; }
            else if (key === 'step03') { cbp = d.bp0 - OH * p; }
            else if (key === 'lag03') { cbp = d.bp0 - SHORT - (OH - SHORT) * p; }
            else if (key === 'step04' || key === 'step05') { cbp = d.bp0 - OH; }
            else if (key === 'step06') { cbp = d.bp0 - OH; gbp = d.bp0 + d.added * p; }
            else if (key === 'step07') { cbp = d.bp0 - OH; gbp = d.bp1; }
            else if (key === 'step08') { gbp = d.bp1; cbp = d.bp0 - OH + (d.bp1 - SHORT - (d.bp0 - OH)) * p; }
            else if (key === 'step09') { gbp = d.bp1; cbp = d.bp1 - SHORT; }
            if (/^step0[2-5]$/.test(key) && d.strand === 'leading') { prot.mrx = 'present'; }
            if (key === 'step05') { prot.mrx = 'present'; prot.tel1 = 'present'; prot.tert = 'arriving'; }
            if (/^step0[4-9]$/.test(key)) { prot.cdc13 = 'present'; }
            if (key === 'step06') { prot.tert = 'present'; }
            if (key === 'step07') { prot.tert = 'fading'; }
            if (key === 'step08') { prot.st = 'arriving'; prot.pola = 'present'; }
            if (key === 'step09') { prot.st = 'present'; }
            if (d.extended && d.copy && now >= d.extAt - eps && (key === 'step05' || key === 'step06')) { busy[d.copy] = true; }
            lab = 'sister ' + k + ', ' + d.strand + '-made end: ' + Math.round(gbp) + ' bp, ' + d.rif + ' Rif1';
            step = stepWords(key, d, pct);
            setEnd(site, sx, gbp, cbp, /^step0[6-9]$/.test(key) ? d.bp0 : null,
              key === 'step08' || key === 'step09' ? d.bp0 - OH : null, d.rif, prot);
          }
          text['txt-tvlab-' + site] = lab;
          sites[site] = { key: key, progress: p, copied: copied && !!d, gbp: gbp, cbp: cbp, step: step,
            lab: copied && d ? 'TEL-' + side + ', sister ' + k + ', ' + d.strand + '-made: ' + Math.round(gbp) + ' bp, '
              + Math.floor(Math.max(0, cbp) / G.bpPerRap1) + ' Rap1 sites, ' + d.rif + ' Rif1'
              : 'TEL-' + side + ', parental end: ' + e.bp + ' bp, ' + e.sites + ' Rap1 sites, ' + e.rif + ' Rif1',
            strand: d && copied ? d.strand : null, sister: k, side: side };
        });
      });
      [1, 2].forEach(function (c) {
        var est2 = !!(sched.alleles && sched.alleles.est2);
        fx['fx-tvtert-' + c] = est2 || c > ((sched.pools && sched.pools.telomerase) || 0) ? 'gone'
          : (busy[c] ? 'fading' : 'present');
      });

      function setEnd(site, sx, gbp, cbp, gFrom, cFrom, rif, prot, hidden) {
        // MODEL: one end's clip offsets, new-DNA pieces, Rap1 sites, Rif1 copies and proteins (TERMINAL)
        var j, n;
        gbp = Math.max(0, Math.min(G.maxBp, gbp));
        cbp = Math.max(0, Math.min(G.maxBp, cbp));
        actors['actor-tvGclip-' + site] = [round(sx * gbp * G.s), 0];
        actors['actor-tvCclip-' + site] = [round(sx * cbp * G.s), 0];
        actors['actor-tvtip-' + site] = [round(sx * gbp * G.s), 0];
        actors['actor-tvCend-' + site] = [round(sx * cbp * G.s), 0];
        if (!/^par-/.test(site)) {
          fx['fx-tvGadd-' + site] = gFrom === null ? 'gone' : 'present';
          fx['fx-tvCadd-' + site] = cFrom === null ? 'gone' : 'present';
          actors['actor-tvGadd-' + site] = [round(sx * (gFrom === null ? G.maxBp : gFrom) * G.s), 0];
          actors['actor-tvCadd-' + site] = [round(sx * (cFrom === null ? G.maxBp : cFrom) * G.s), 0];
        }
        n = hidden ? 0 : Math.floor(cbp / G.bpPerRap1);
        for (j = 0; j < G.rap1Slots; j += 1) { fx['fx-tvrap-' + site + '-' + j] = j < n ? 'present' : 'gone'; }
        for (j = 0; j < G.rifSlots; j += 1) { fx['fx-tvrif-' + site + '-' + j] = j < rif ? 'present' : 'gone'; }
        ['mrx', 'tel1', 'st', 'cdc13', 'tert', 'pola'].forEach(function (q) {
          fx['fx-tv' + q + '-' + site] = prot[q] || 'gone';
        });
      }
    }

    function stepWords(key, d, pct) {
      // MODEL: what an end is doing at a step, in words (TERMINAL)
      var words = {
        step01: 'copied by the leading strand: blunt end',
        lag01: 'copied by the lagging strand: short 3′ overhang',
        step02: 'Cdk1-phosphorylated Sae2 and MRX at the end',
        step03: 'resection opens the 3′ overhang',
        lag03: 'resection lengthens the overhang',
        step05: 'Tel1 marks the end; telomerase is recruited',
        step07: 'Pif1 and Ipl1 remove telomerase',
        step08: 'Stn1-Ten1 and Pol α fill in the C-strand'
      };
      if (words[key]) { return words[key]; }
      if (key === 'step04') {
        return 'Cdc13 on the overhang; ' + (d.why ? d.why : 'telomerase can come: ' + pct(d.pExtend) + ' chance this cycle');
      }
      if (key === 'step06') { return 'telomerase adds ' + d.added + ' nt'; }
      if (key === 'step09') {
        return 'capped at ' + d.bp1 + ' bp' + (d.extended ? ', ' + d.added + ' nt added' : ', not extended this cycle');
      }
      return key;
    }

    function countPools(clock, sched, fx, text) {
      // MODEL: the free Rif1-PP1 copies, the header's pool words and the telomerase reservoir's words (TERMINAL)
      // Each end holds its Rif1 by its sites; a copied end is two daughters,
      // each holding its own. The copies the ends do not hold are free.
      var free = 0, j, est2 = !!(sched.alleles && sched.alleles.est2);
      if (sched.pools && sched.pools.rif1Total > 0) {
        free = sched.pools.rif1Total;
        ['TEL-L', 'TEL-R'].forEach(function (tel) {
          var e = sched.telo[tel];
          var copied = !clock.pre && e.copiedAt !== null && clock.now >= e.copiedAt - eps && e.daughters.length === 2;
          free -= copied ? e.daughters[0].rif + e.daughters[1].rif : e.rif;
        });
        free = Math.max(0, free);
      }
      for (j = 1; j <= 10; j += 1) { fx['fx-tvfree-' + j] = j <= free ? 'present' : 'gone'; }
      if (sched.one) {
        text['txt-pools'] = 'One origin, fired ' + sched.one.fireAt + ' min after G1/S. '
          + (sched.pools.rif1Total > 0 ? 'Rif1-PP1: ' + (sched.pools.rif1Total - free) + ' bound at the ends, '
            + free + ' free' : 'Rif1 absent');
      }
      fx['fx-tvtertlab'] = est2 ? 'gone' : 'present';
      fx['fx-tvnotert'] = est2 ? 'present' : 'gone';
    }

    function round(v) { return Math.round(v * 100) / 100; }
  }

  function telInsetAt(m, sched, site, v) {
    // MODEL: the close-up for a telomere site: the telomere workflow panel of its step, and its words (TERMINAL)
    // The panel is the workflow's drawing of the step, at the workflow's own
    // lengths; the words carry this end's lengths.
    var fx = { 'ci-leftcol': 'gone', 'ci-set-held': 'gone', 'ci-set-wait': 'gone', 'ci-ddkstar': 'gone', 'ci-ddkblock': 'gone' };
    var phaseWords = { lateM: 'late M', G1: 'G1', lateG1: 'late G1', stuck: 'G1/S', G2: 'G2',
      A1: 'anaphase', A2: 'anaphase', A3: 'anaphase', G2M: 'anaphase' }[m.phase]
      || (m.t !== undefined ? (Math.round(m.t * 10) / 10) + ' min into S' : '');
    var text = {};
    if (!v) { v = { key: 'step09', progress: 1, lab: site, step: '', side: site.charAt(4), sister: +site.charAt(7) }; }
    text['ci-title'] = 'Telomere close-up: TEL-' + v.side + ', sister ' + v.sister
      + (v.strand ? ' (' + v.strand + '-made end)' : '');
    text['ci-line1'] = 'TEL-' + v.side + ', ' + phaseWords;
    text['ci-line2'] = v.step;
    text['ci-line3'] = v.lab.replace(/^TEL-[LR], (sister [12], )?/, '');
    return { fx: fx, actors: { 'ci-mfill': [0, 0], 'ci-theta': [0, 0] }, text: text,
      view: { kind: 'tw', key: 'tw-' + v.key, progress: v.progress } };
  }

  function insetAt(m, sched, geom, n, seen, follow) {
    // MODEL: the close-up's states, offsets and words for the selected origin at one moment (TERMINAL)
    var v = seen[n], o = sched.origins[n], fx = {}, actors = {}, text = {};
    var fmt = function (x) { return String(Math.round(x * 10) / 10); };
    // What the origin panel shows for each stage, and whether the stage
    // carries the bob1 double hexamer (the ciorigin-b panel).
    var looks = { morc: 'orc', mcdc6: 'cdc6', mlic: 'lic', mlicb: 'lic', mmark: 'mark', mmarkb: 'mark',
      mmark1: 'mark1', mmark2: 'mark2', mmark3: 'mark3', mmarkb1: 'mark1', mmarkb2: 'mark2', mmarkb3: 'mark3',
      mbob: 'bob', mfire: 'mark', mfirebm: 'mark', mfireb: 'bob', mspent: 'cleared' };
    var now = v.now, seg = v.seg, a = 0, p = 0, cap = 0, ready = false, setsOut = 0, theta = sched.rates.theta;
    var phaseWords, line2 = ' ', line3 = ' ', mInf, forks = {}, firing = false;
    if (seg && seg.ddk[n] !== undefined) {
      a = seg.ddk[n];
      p = seg.rifFree[n] + seg.rifCap[n];
      cap = seg.rifCap[n];
      ready = !!seg.ready[n];
    }
    if (!v.pre) {
      sched.sets.forEach(function (b) { if (b.out - 1e-6 <= now && now < b.back - 1e-6) { setsOut += 1; } });
    }
    var open = !v.pre && !v.done && sched.viable;
    var held = open && ready && v.rad53On && sched.arms.sld3;
    fx['ci-set-held'] = held ? 'present' : 'gone';
    fx['ci-set-wait'] = open && ready && !held && setsOut >= 2 ? 'present' : 'gone';
    fx['ci-ddkstar'] = open && v.rad53On && sched.arms.dbf4 ? 'present' : 'gone';
    fx['ci-ddkblock'] = sched.dbf4Blocked ? 'present' : 'gone';
    actors['ci-mfill'] = [0, Math.round(-geom.ciMeterH * Math.max(0, Math.min(1, v.marks / theta)) * 100) / 100];
    actors['ci-theta'] = [0, v.perm && !v.done ? geom.ciMeterH : 0];
    // Forks of this origin, as they leave, with RPA behind each.
    ['left', 'right'].forEach(function (side) {
      var f = null, live = false, lvl = 0, x = null;
      sched.forks.forEach(function (c) { if (c.id === n + '-' + side) { f = c; } });
      if (f && !v.pre && now > f.t0 + 1e-6) {
        live = now < f.t1 - 1e-6 || f.end === 'window' || f.end === 'collapsed';
        (f.rpaPath || []).forEach(function (q, j) {
          var r = f.rpaPath[j + 1];
          if (q[0] <= now + 1e-6) { lvl = r && r[0] > now ? q[1] + (r[1] - q[1]) * (now - q[0]) / (r[0] - q[0]) : q[1]; }
        });
        x = f.path[f.path.length - 1][1];
        f.path.forEach(function (q, j) {
          var r = f.path[j + 1];
          if (r && now >= q[0] - 1e-6 && now <= r[0] + 1e-6) {
            x = r[0] - q[0] > 1e-9 ? q[1] + (r[1] - q[1]) * (now - q[0]) / (r[0] - q[0]) : r[1];
          }
        });
      }
      forks[side] = { f: f, live: live, x: x };
    });
    firing = o.fate === 'fired' && !v.pre && Math.abs(now - o.time) < 1e-6;
    // Words.
    phaseWords = { lateM: 'late M', G1: 'G1', lateG1: 'late G1', stuck: 'G1/S' }[v.phase]
      || (v.post ? (v.phase === 'G2' ? 'G2, cohesin joins the sisters' : 'anaphase')
        : (now < 0 ? fmt(-now) + ' min before S' : fmt(now) + ' min into S'));
    text['ci-title'] = 'Origin close-up: ' + n + ' (' + o.position + ' kb)';
    text['ci-line1'] = n + ', ' + phaseWords;
    if (o.fate === 'unlicensed' && v.phase !== 'lateM' && v.phase !== 'G1') {
      line2 = 'not licensed: no Mcm2-7 pair was loaded (mcm allele)';
      line3 = 'it cannot fire; a passing fork copies it';
    } else if (v.phase === 'lateM') { line2 = 'ORC sits on the origin'; line3 = 'not yet licensed'; }
    else if (v.phase === 'G1') { line2 = 'Cdc6 joins ORC'; line3 = 'licensing begins'; }
    else if (v.phase === 'lateG1') { line2 = 'licensed: one Mcm2-7 pair loaded'; line3 = 'waits for S-CDK and DDK'; }
    else if (v.phase === 'stuck') { line2 = 'licensed, but no DDK and no bob1'; line3 = 'this origin cannot fire'; }
    else if (firing) {
      line2 = 'fires: a set lands, Sld3-Sld7 seats, Cdc45 joins';
      line3 = o.route === 'bypass' ? 'fired by the bob1 bypass, without marks' : 'fired at the line: ' + fmt(v.marks) + ' marks';
    } else if (o.fate === 'fired' && v.done) {
      line2 = 'fired at ' + fmt(o.time) + ' min' + (o.route === 'bypass' ? ' by the bob1 bypass' : '');
      line3 = ['left', 'right'].map(function (side) {
        var q = forks[side];
        if (!q.f) { return ''; }
        if (!q.live) { return side + ' fork done'; }
        if ((q.f.downs || []).some(function (d) { return now >= d[0] - 1e-6 && (d[1] === null || now < d[1] - 1e-6); })) {
          return side + ' fork collapsed at ' + fmt(q.x) + ' kb';
        }
        return side + ' fork at ' + fmt(q.x) + ' kb' + (v.rad53On && sched.arms.rad53 ? ', protected' : '');
      }).join('; ');
    } else if (o.fate === 'passive' && v.done) {
      line2 = 'copied passively at ' + fmt(o.time) + ' min by fork ' + o.copiedBy;
      line3 = 'never fired: ' + Math.round(100 * o.meter) + '% of the way to the line';
    } else {
      line2 = a + ' DDK vs ' + p + ' Rif1-PP1' + (cap ? ' (' + cap + ' from the telomere)' : '')
        + ': ' + fmt(v.marks) + ' of ' + theta + ' marks';
      if (v.perm) { line3 = 'bob1 permissive shape: ready without marks'; }
      if (ready) {
        line3 = held ? 'ready, but the sets stay home (Rad53 marked Sld3)'
          : (setsOut >= 2 ? 'ready: waiting for a free set' : (v.perm ? line3 : 'ready'));
      } else if (!v.perm) {
        mInf = p > 0 ? sched.rates.kDdk * a / (sched.rates.kPp1 * p) : null;
        if (v.rad53On && sched.arms.dbf4) { line3 = 'Rad53 sent its DDK home (Dbf4 marked): marks fade'; }
        else if (a === 0) { line3 = 'no DDK here: the copies are busy at other origins'; }
        else if (mInf !== null && mInf < theta) { line3 = 'marks level off at ' + Math.round(mInf) + ': needs more DDK'; }
        else { line3 = 'marking toward the line'; }
      }
      if (sched.hu && v.post === false && now >= sched.sEnd - 1e-6) { line3 = 'never fired in the HU window; ' + line3; }
    }
    text['ci-line2'] = line2;
    text['ci-line3'] = line3;
    // Rounded down, so the count reads 20 only once the pair is at the line.
    text['ci-marks'] = Math.floor(v.marks + 1e-6) + ' of ' + theta;
    text['ci-ddkn'] = a + ' DDK';
    text['ci-rifn'] = p + ' Rif1-PP1';
    text['ci-rifcap'] = cap ? cap + ' from telomere' : ' ';
    text['ci-rec'] = o.recruiter === 'none' ? 'no recruiter' : (o.recruiter === 'Ctf19' ? 'Ctf19 complex' : 'Fkh1/2');
    // The view. The origin panel shows the origin, its look set by its stage;
    // a copied origin is the origin opened to both edges, and a passively
    // copied one has its double hexamer pushed off by the passing fork. Once
    // the origin has fired and a fork is followed, that fork's elongation
    // panel carries the camera on: it moves while the fork does, collects RPA
    // behind a stalled fork, and loses its replisome when the fork ends.
    var look = looks[v.stage] || 'lic';
    var view = { kind: 'origin', panel: sched.bob1 ? 'ciorigin-b' : 'ciorigin', state: look };
    if (look === 'cleared' && o.fate === 'passive') {
      // Copied by a passing fork: the passive panel as that fork left it.
      view = passiveView(o, sched, geom, 9999, look);
    }
    var fol = (follow === 'left' || follow === 'right') ? forks[follow] : null;
    if (fol && fol.f && !v.pre && now > fol.f.t0 + 1e-6) {
      var f = fol.f, speed = 0, lvl = 0, collapsed = (f.downs || []).some(function (d) {
        return now >= d[0] - 1e-6 && (d[1] === null || now < d[1] - 1e-6);
      });
      var finished = !fol.live, other = null;
      f.path.forEach(function (q, j) {
        var r = f.path[j + 1];
        if (r && now >= q[0] - 1e-6 && now < r[0] - 1e-6 && r[0] - q[0] > 1e-9) {
          speed = Math.abs(r[1] - q[1]) / (r[0] - q[0]);
        }
      });
      (f.rpaPath || []).forEach(function (q, j) {
        var r = f.rpaPath[j + 1];
        if (q[0] <= now + 1e-6) { lvl = r && r[0] > now ? q[1] + (r[1] - q[1]) * (now - q[0]) / (r[0] - q[0]) : q[1]; }
      });
      if (collapsed || finished) { speed = 0; }
      sched.terminations.forEach(function (t) {
        var k = t.forks.indexOf(f.id);
        if (k >= 0) { other = t.forks[1 - k].split('-')[0]; }
      });
      // The checkpoint, read off this fork. In hydroxyurea the polymerases
      // fall behind the helicase, leaving bare template the model counts as
      // RPA level: one bare position per quarter level, each coated by RPA.
      // Ddc2 binds the coat and brings Mec1; Mec1 marks Mrc1; Rad53 docks on
      // the mark and is switched on when the chromosome's summed signal
      // crosses the line (the rule's Rad53 time). Without Rad53 the dock
      // stays empty and the fork later collapses: its replisome leaves.
      var dntp = seg ? seg.dntp : 1;
      var bare = sched.hu ? Math.max(0, Math.min(12, Math.round(4 * lvl))) : 0;
      // A collapsed fork: the replisome stays on the DNA but synthesis cannot
      // resume. Without Rad53 the helicase runs on ahead of the stalled
      // polymerases, and Exo1 resects the new strands from their ends, so the
      // single-stranded stretch behind the helicase is at its longest.
      // Without Rad53 the helicase of a collapsed fork runs on, unwinding
      // without synthesis: the frames count its travel and the bare stretch
      // grows with it (countForkTravel). With Rad53 the stalled fork holds.
      var runOn = collapsed && !sched.arms.rad53 && f.end !== 'collapsed-met';
      if (collapsed && !runOn) { bare = Math.max(bare, 12); }
      var mec = bare >= 2, mrcP = bare >= 3;
      view = { kind: 'elong', side: follow === 'right' ? 'r' : 'l', speed: speed, u: 0, b: !!sched.bob1,
        bare: bare, dntp: dntp, mec: mec, mrcP: mrcP,
        dock: mrcP && sched.arms.rad53, active: mrcP && sched.arms.rad53 && !!v.rad53On,
        nor53: mrcP && !sched.arms.rad53, leave: finished, collapsed: collapsed, runOn: runOn,
        exo: collapsed && !runOn };
      text['ci-line1'] = 'Following the ' + follow + ' fork of ' + n + ', ' + phaseWords;
      text['ci-line2'] = 'at ' + fmt(fol.x) + ' kb, moving ' + (Math.round(speed * 100) / 100) + ' kb/min'
        + (sched.hu ? '; dNTP pool ' + Math.round(100 * dntp) + '% of normal' : '');
      if (collapsed && f.end === 'collapsed-met') {
        text['ci-line3'] = 'collapsed: the replisome left; a fork from ' + other + ' later copied the stretch';
      } else if (collapsed && sched.arms.rad53) {
        text['ci-line3'] = 'collapsed with Rad53 on: synthesis has stopped and Exo1 resects; Rad53 lets it restart later';
      } else if (collapsed) {
        text['ci-line3'] = 'collapsed: the stalled polymerases cannot resume while the helicase runs on, leaving RPA-coated template; behind, out of frame, Exo1 resects the new strands';
      } else if (finished && f.end === 'meet') {
        text['ci-line3'] = 'met the fork from ' + other + ' at ' + fmt(f.x1) + ' kb: this stretch is copied';
      } else if (finished && f.end === 'telomere') {
        text['ci-line3'] = 'reached the chromosome end: the telomere is copied';
      } else if (view.active) {
        text['ci-line3'] = 'Rad53 marked by Mec1 and by itself: it slows the helicase and raises dNTPs through Dun1';
      } else if (view.dock) {
        text['ci-line3'] = 'Mec1 marks Mrc1; Rad53 docks on the mark';
      } else if (view.nor53) {
        text['ci-line3'] = 'Mec1 marks Mrc1, but there is no Rad53 to dock';
      } else if (mec) {
        text['ci-line3'] = 'RPA coats the bare template; Ddc2 binds it and brings Mec1';
      } else if (sched.hu && dntp < 0.99) {
        text['ci-line3'] = 'HU blocks RNR: few dNTPs, so the polymerases fall behind the helicase';
      } else {
        text['ci-line3'] = 'leading strand made continuously, lagging in Okazaki fragments';
      }
    }
    if (follow === 'cen') {
      view = cenView();
      text['ci-title'] = 'Centromere close-up (120 kb)';
      text['ci-line1'] = 'The centromere, ' + phaseWords;
      text['ci-line2'] = view.words2;
      text['ci-line3'] = view.words3;
    }

    function cenView() {
      // The centromere's state now: forks arriving, copied and held by
      // cohesin with both kinetochores attached, parted in anaphase, or a
      // collapsed fork's resection reaching it and its kinetochore lost.
      var cen = sched.anchors ? sched.anchors.sites[0] : null, lostAt = cen ? cen.lostAt : null;
      var c = null, d = Infinity, copiedAt = Infinity, st;
      (sched.collapses || []).forEach(function (q) {
        var dist = Math.abs(q.x - 120);
        if (lostAt !== null && dist <= sched.anchors.reach + 1e-9
            && Math.abs(q.t + dist / sched.anchors.rate - lostAt) < 1e-6) { c = q; }
      });
      sched.forks.forEach(function (f) {
        var i, a, b, x = null;
        for (i = 0; i + 1 < f.path.length; i += 1) {
          a = f.path[i];
          b = f.path[i + 1];
          if ((a[1] - 120) * (b[1] - 120) <= 0 && b[1] !== a[1]) {
            copiedAt = Math.min(copiedAt, a[0] + (b[0] - a[0]) * (120 - a[1]) / (b[1] - a[1]));
          }
          if (now >= a[0] - 1e-6 && now <= b[0] + 1e-6) {
            x = b[0] - a[0] > 1e-9 ? a[1] + (b[1] - a[1]) * (now - a[0]) / (b[0] - a[0]) : b[1];
          }
        }
        if (x !== null && now >= f.t0 && (120 - x) * f.direction > 0) { d = Math.min(d, Math.abs(120 - x)); }
      });
      if (v.pre) { st = 'single'; }
      else if (v.phase === 'A1' || v.phase === 'A2' || v.phase === 'A3' || v.phase === 'G2M') { st = 'anaphase'; }
      else if (v.post) { st = 'copied'; }
      else if (lostAt !== null && now >= lostAt - 1e-6) { st = 'lost'; }
      else if (c && now >= c.t - 1e-6) {
        st = (now - c.t) / Math.max(1e-6, lostAt - c.t) < 1 / 3 ? 'collapse'
          : ((now - c.t) / Math.max(1e-6, lostAt - c.t) < 2 / 3 ? 'resect1' : 'resect2');
      }
      else if (now >= copiedAt - 1e-6) { st = 'copied'; }
      else if (d <= 3) { st = 'near'; }
      else if (d <= 10) { st = 'forks'; }
      else { st = 'single'; }
      return { kind: 'cen', state: st, words2: {
        single: 'one kinetochore on the Cse4 nucleosome, attached to a microtubule from one pole',
        forks: 'forks approach from both sides', near: 'the forks are about to copy the centromere',
        copied: 'copied: cohesin joins the sisters; each kinetochore binds a microtubule from its own pole',
        anaphase: 'cohesin is cleaved and the sisters part toward the two poles',
        collapse: 'a fork beside the centromere has collapsed: its polymerases stop while its helicase runs on',
        resect1: 'the helicase unwinds toward the centromere; RPA coats it and Exo1 resects behind',
        resect2: 'nucleosomes come off ahead of the helicase as the single-stranded stretch nears the centromere',
        lost: 'the centromere is single-stranded: the Cse4 nucleosome is lost and the kinetochore lets go'
      }[st], words3: c && (st === 'collapse' || st === 'resect1' || st === 'resect2' || st === 'lost')
        ? 'the fork collapsed ' + fmt(Math.abs(c.x - 120)) + ' kb away; drawn closer than it is'
        : 'distances along the DNA are drawn closer than they are' };
    }

    // The dNTP source, shown while a fork is followed: RNR, blocked by HU,
    // raised again by Rad53 through Dun1.
    var el = view.kind === 'elong';
    fx['ci-rnr'] = el ? 'present' : 'gone';
    fx['ci-hu'] = el && sched.hu && view.dntp < 0.99 ? 'present' : 'gone';
    fx['ci-dun1'] = el && sched.hu && view.dntp > 0.15 && view.dntp < 0.99 ? 'present' : 'gone';
    fx['ci-leftcol'] = view.kind === 'elong' || view.kind === 'cen' || view.kind === 'term' ? 'gone' : 'present';
    // While a fork is followed, the dNTP pool it draws on takes the left column's place.
    var fork = view.kind === 'elong' || view.kind === 'term', pool = view.dntp === undefined ? 1 : view.dntp;
    fx['ci-dntpg'] = fork ? 'present' : 'gone';
    actors['ci-dfill'] = [0, Math.round(-geom.ciDntpH * Math.max(0, Math.min(1, fork ? pool : 0)) * 100) / 100];
    text['ci-dntpn'] = Math.round(100 * pool) + '% of normal';
    return { fx: fx, actors: actors, text: text, view: view };
  }
}

if (typeof window !== 'undefined') { window.buildChromFrames = buildChromFrames; }
if (typeof module !== 'undefined') { module.exports = buildChromFrames; }
