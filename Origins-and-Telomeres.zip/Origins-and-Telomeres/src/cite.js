/* Citations.

   CITE_SCOPE is "panel" or "global". Panel scope restarts at [1] in every
   panel and lists that panel's references under its caption, which is
   self-contained: a reader who only ever sees one panel never resolves a
   number against a list somewhere else. Changing the string is the whole
   switch.

   Link resolution is DOI, then URL, then a Scholar title-plus-author query,
   in that order, identical to the dissertation preamble. If the figure and
   the PDF resolved the same key differently, that would be a bug nobody
   would ever see.

   Ordering note. renderLatex ends by stripping every brace, which is correct
   for the fields it is given and fatal if it runs before the citation
   substitution: it turns \cite{key} into \citekey, the cite pattern then
   matches nothing, the ledger stays empty and every reference list renders
   blank. Citations are therefore substituted first and the remaining LaTeX is
   rendered on the surrounding text only. */

var CITE_SCOPE = 'panel';

var BIB = {};
var GLOBAL_NUMBERS = {};

// === BASE CONTROLLER: initCitations =======================================

function initCitations(bibText) {
  BIB = parseBib(bibText);
  if (CITE_SCOPE === 'global') { numberGlobally(); }
  return BIB;

  function numberGlobally() {
    // SUB-CONTROLLER: one number per work across the whole reading order.
    var order = window.PANEL_ORDER || [];
    var n = 0, i, keys, j;
    GLOBAL_NUMBERS = {};
    for (i = 0; i < order.length; i += 1) {
      keys = keysIn(textOf(order[i]));
      for (j = 0; j < keys.length; j += 1) {
        if (!GLOBAL_NUMBERS[keys[j]]) { n += 1; GLOBAL_NUMBERS[keys[j]] = n; }
      }
    }

    function textOf(key) {
      var m = (window.META || {})[key] || {};
      return (m.caption || '') + ' ' + (m.note || '');
    }
  }
}

// === BASE CONTROLLER: renderCitedText =====================================

function renderCitedText(text, ledger) {
  // Split on \cite{...}, render the LaTeX in the text between the citations,
  // and replace each citation with its markers. Splitting first is what keeps
  // the brace strip in renderLatex away from the citation braces.
  var re = /\\cite\{([^}]*)\}/g;
  var out = '';
  var last = 0;
  var m = re.exec(text);
  while (m) {
    out += renderLatex(text.slice(last, m.index));
    out += markersFor(m[1], ledger);
    last = m.index + m[0].length;
    m = re.exec(text);
  }
  out += renderLatex(text.slice(last));
  return out;

  function markersFor(group, ledger) {
    var keys = group.split(',').map(trim);
    return keys.map(function (k) {
      return '[' + numberFor(k, ledger) + ']';
    }).join('');
  }

  function numberFor(key, ledger) {
    if (CITE_SCOPE === 'global') {
      if (!GLOBAL_NUMBERS[key]) { return '?'; }
      if (ledger.indexOf(key) < 0) { ledger.push(key); }
      return GLOBAL_NUMBERS[key];
    }
    if (ledger.indexOf(key) < 0) { ledger.push(key); }
    return ledger.indexOf(key) + 1;
  }
}

// === BASE CONTROLLER: renderReferenceList =================================

function renderReferenceList(ledger) {
  var items = ledger.map(function (key) {
    var e = BIB[key];
    if (!e) { return '<li><span class="missingref">missing reference: ' + key + '</span></li>'; }
    return '<li>' + formatEntry(e) + '</li>';
  });
  return items.join('');

  function formatEntry(e) {
    // SUB-CONTROLLER: one reference line, linked.
    var label = renderLatex(e.author || '') + ' (' + (e.year || 'n.d.') + '). '
      + renderLatex(e.title || '') + '. ' + renderLatex(e.journal || e.booktitle || '');
    if (e.species) { label += ' [' + renderLatex(e.species) + ']'; }
    return '<a href="' + linkFor(e) + '" target="_blank" rel="noreferrer">'
      + label.trim() + '</a>';
  }
}

// === SHARED FUNCTIONS =====================================================

function linkFor(e) {
  if (e.doi) { return 'https://doi.org/' + e.doi; }
  if (e.url) { return e.url; }
  return 'https://scholar.google.com/scholar?q='
    + encodeURIComponent((e.title || '') + ' ' + (e.author || ''));
}

function keysIn(text) {
  var out = [], m;
  var re = /\\cite\{([^}]*)\}/g;
  m = re.exec(text);
  while (m) {
    m[1].split(',').map(trim).forEach(function (k) { if (out.indexOf(k) < 0) { out.push(k); } });
    m = re.exec(text);
  }
  return out;
}

function trim(s) { return String(s).replace(/^\s+|\s+$/g, ''); }

function parseBib(text) {
  // MODEL: BibTeX to a key-to-fields map. Brace matching is done by walking
  // the string, which is why this one is written as a scan and not as a
  // regular expression.
  var out = {}, i = 0, n = text.length;
  while (i < n) {
    if (text.charAt(i) !== '@') { i += 1; continue; }
    var open = text.indexOf('{', i);
    if (open < 0) { break; }
    var depth = 1, j = open + 1;
    while (j < n && depth > 0) {
      if (text.charAt(j) === '{') { depth += 1; }
      if (text.charAt(j) === '}') { depth -= 1; }
      j += 1;
    }
    var body = text.slice(open + 1, j - 1);
    var comma = body.indexOf(',');
    var key = trim(body.slice(0, comma));
    out[key] = parseFields(body.slice(comma + 1));
    i = j;
  }
  return out;

  function parseFields(body) {
    var fields = {}, k = 0, m = body.length;
    while (k < m) {
      var eq = body.indexOf('=', k);
      if (eq < 0) { break; }
      var name = trim(body.slice(k, eq)).toLowerCase();
      var p = eq + 1;
      while (p < m && ' \t\r\n'.indexOf(body.charAt(p)) >= 0) { p += 1; }
      var value = '';
      if (body.charAt(p) === '{') {
        var d = 1;
        var q = p + 1;
        while (q < m && d > 0) {
          if (body.charAt(q) === '{') { d += 1; }
          if (body.charAt(q) === '}') { d -= 1; }
          if (d > 0) { value += body.charAt(q); }
          q += 1;
        }
        p = q;
      } else {
        var end = body.indexOf(',', p);
        if (end < 0) { end = m; }
        value = body.slice(p, end);
        p = end;
      }
      fields[name] = trim(value);
      var nextComma = body.indexOf(',', p);
      k = nextComma < 0 ? m : nextComma + 1;
    }
    return fields;
  }
}

function renderLatex(text) {
  // MODEL: the subset that appears in captions and bibliography fields. This
  // never sees a \cite, because renderCitedText splits them out first.
  return String(text)
    .replace(/\\textit\{([^}]*)\}/g, '<em>$1</em>')
    .replace(/\\emph\{([^}]*)\}/g, '<em>$1</em>')
    .replace(/\\&/g, '&amp;')
    .replace(/\{?\\(["'`^~])\{?([A-Za-z])\}?\}?/g, function (all, mark, ch) {
      // BibTeX accents: \"u, {\'e}, \'{n} and the like, as the accented letter.
      var map = { '"': '\u0308', "'": '\u0301', '`': '\u0300', '^': '\u0302', '~': '\u0303' };
      return (ch + map[mark]).normalize('NFC');
    })
    .replace(/[{}]/g, '');
}

if (typeof window !== 'undefined') {
  window.initCitations = initCitations;
  window.renderCitedText = renderCitedText;
  window.renderReferenceList = renderReferenceList;
  window.keysIn = keysIn;
}
