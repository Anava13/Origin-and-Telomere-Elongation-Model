/* The replication rule of the model chromosome, run live in the page.

   This file is the single source of truth for the chromosome tab. The page
   runs it every time the reader asks for a run, and tools/test_engine.js runs
   it with fixed seeds. Nothing else computes the biology.

   THE RULE
   Three limited supplies decide when each origin fires.

   DDK. The cell has RULE.ddkTotal copies of DDK (Cdc7-Dbf4). A genotype sets
   how many are active: dbf4-1 leaves fewer, dbf4 deletion none. From G1/S the
   active copies are dealt to the origins still open (licensed, not yet fired,
   not yet copied) in proportion to each origin's recruiter weight: Ctf19
   complex 4, Fkh1/2 2, none 1. When an origin fires or is copied, its copies
   return and are dealt again, so DDK concentrates on the origins that are left.

   Rif1-PP1. The cell has RULE.rif1Total copies. Each telomere's Rap1 array
   captures copies in proportion to its Rap1 sites, RULE.rif1Captured at the
   wild-type length (see TELOMERES), and they act on the open origins within
   RULE.telomereReach kb of it. The copies no telomere holds are dealt evenly
   over every open origin. rif1 deletes both.

   Dealing. Copies are whole. Each origin takes the whole part of its share;
   leftovers go to the origins with the largest remainders, but only to a whole
   group of tied origins at once, and a group too large for the copies left
   leaves them in the reservoir. Equal claims always hold equal copies, and the
   panel draws exactly the copies the rule uses.

   Marks. At an open origin holding a DDK copies and p Rif1-PP1 copies,
       dm/dt = kDdk * a - kPp1 * p * m.
   Between two events the copies held do not change, so m follows the exact
   solution and the simulation steps from event to event with no time step.
   An origin whose marks reach theta becomes ready and stays ready.

   bob1. Each bob1 pair switches between two shapes at random, a mean of
   RULE.bob1On minutes in the permissive shape and RULE.bob1Off minutes out of
   it (Hoang et al. 2007: several conformations, one permissive). While
   permissive the origin is ready whatever its marks. Rif1 has no effect on the
   switching, so the rule does not explain why late origins suffer more in
   bypass cells.

   Firing. A ready origin fires when one of RULE.sets firing-factor sets is
   free. When more origins are ready than sets are free, each free set goes to
   one of them chosen at random. A set returns RULE.setReturn minutes after
   firing. A fork that reaches an origin before it fires copies it, and at one
   instant a fork arriving comes before anything else.

   HYDROXYUREA AND THE CHECKPOINT
   With HU the run starts at G1/S in HU and runs until the cell attempts
   anaphase: once every stretch is copied, the cell enters anaphase; once
   the spindle extends prematurely, the run shows RULE.extendShow minutes of
   it and stops with the chromosome partly copied; a cell that does neither
   by RULE.huMax minutes is shown still in S. HU blocks ribonucleotide reductase, so
   the dNTP pool falls to RULE.huDntp of normal and every moving fork moves at
   that share of RULE.forkSpeed. Starved of dNTPs, the polymerases fall behind
   the helicase and single-stranded DNA opens at each fork, which RPA coats.
   Each moving fork gains RPA at RULE.rpaRate levels per minute, scaled by the
   dNTP shortfall (1 - dNTP), up to RULE.rpaMax. Mec1-Ddc2 reads the RPA-coated
   DNA and Mrc1 in the replisome carries the signal to Rad53, drawn as one step:
   the signal is the RPA summed over every fork still in progress, and Rad53
   switches on when it reaches RULE.rad53Signal (Tercero et al. 2003: no forks,
   no Rad53 in HU). A fork that has met another or reached a telomere leaves no
   single-stranded DNA. Active Rad53 acts on three targets and keeps forks intact.
     Sld3: a marked set cannot bind an origin, so no origin fires, ready or not.
     Dbf4: marked DDK leaves the origins and stops marking.
     Dun1: Dun1 relieves the brakes on ribonucleotide reductase, and the dNTP
       pool recovers to RULE.dun1Dntp of normal.
   Forks in HU collapse at random. Every moving fork shares one hazard, which
   rises steeply with the load on the dNTP pool: the moving forks, scaled up
   as the pool falls, so firing more origins or keeping the pool low both raise it
   (Poli et al. 2012; Morafraile et al. 2015). Each fork counts for the
   origins of its class it stands for: in HU about 180 origins fire with
   the checkpoint and about 400 without it (Julius et al. 2019), so the four
   early origins stand for 180 and the two late ones, L3 and R3, for the
   other 220, and a late fork has load 2.4 to an early fork's 1. The pool enters
   weakly (RULE.poolExp), because dun1 deletion alone keeps spindles short
   while unchecked firing extends them. A cell with Rad53
   multiplies the hazard by RULE.rad53Protect, at every fork from its start,
   because Rad53 at the fork keeps it intact; a cell without Rad53 (rad53-21,
   drawn with no Rad53 activity) has the full hazard. A collapsed fork stops
   until it restarts: in a cell with Rad53 a collapsed fork resumes
   RULE.restartDelay minutes later with a fresh clock, and in a cell without
   Rad53 it never does (Lopes et al. 2001). A fork moving towards a collapsed
   one still meets it and finishes the stretch between them. Each fork draws one exponential clock at its start
   and collapses when the hazard it has accumulated reaches it, so the
   hazard can change at every event and the run stays exact. dbf4-m25
   sld3-38A removes the Rad53 sites on Sld3 and Dbf4, so firing goes on while
   Rad53 still protects forks. dun1 deletion, an allele on its own, leaves
   the dNTP pool low.

   THE CENTROMERE AND THE SPINDLE
   Exo1 resects from each collapsed fork in both directions at RULE.exoRate
   kb per minute, RULE.exo1Rate without Exo1, because other nucleases still
   act, and reaches RULE.resectReach kb each way. When resection reaches
   the centromere its kinetochore loses its anchor (Julius et al. 2019). The spindle forms RULE.spindleForm minutes
   after G1/S. While any active kinetochore keeps its anchor the spindle
   holds at RULE.spindleShort um. Once every active kinetochore has lost it,
   the spindle extends in cycles of extension and breakage, each to a peak
   drawn between 4 and 7 um. Without HU the spindle extends to anaphase
   length once every stretch is copied. The one centromere stands for the
   sixteen of the cell, and the one late artificial kinetochore for the four
   Julius and colleagues placed. Spindle peaks come from a second seeded
   stream, so they never change the replication of a run.

   TELOMERES
   Origins and telomeres sit on two sides of one boundary. The origin side is
   the rule above. The telomere side is each chromosome end: its length, the
   proteins on it and the steps that process it once a fork has copied it.
   Proteins cross the boundary only where RULE.crossing names them. Rif1 is
   the one protein that crosses now; every other telomere factor is drawn as
   its own supply, which is the claim that it is not limiting between origins
   and telomeres.

   Length. Each end starts at RULE.telomereBp (325 bp, Ray and Runge 1999) and
   is counted in Rap1 sites, one per RULE.bpPerRap1 bp of repeat, so a
   wild-type end holds 17 sites. The model chromosome stands for the genome,
   so its two ends stand for the 32 ends of the cell and the four daughter
   ends after copying for its 64; the length of each end is a real length.

   Rif1 crossing. A Rap1 array holds Rif1 in proportion to its sites (Rif1
   binds the Rap1 C-terminus, Hardy et al. 1992), so an end of n sites holds
   n * RULE.rif1Captured / 17 copies, rounded to whole copies because the rule
   deals whole copies. A wild-type end therefore holds 2, the 2 the origin
   side was tuned with. The copies the ends hold leave the free pool, so a
   longer or more numerous array leaves fewer copies for the origins (Hafner
   et al. 2018). When a fork copies an end, the end becomes two daughter ends,
   each with its own array, and each holds copies by its own length: copying
   an end doubles its pull on the pool. The copies an end holds act on the
   open origins within RULE.telomereReach kb of it; by the time a fork reaches
   an end it has passed every origin that close, so a copied end's copies act
   only by leaving the pool. Length added by telomerase in a cycle is counted
   from the next cycle: Rap1 binds the new repeats once the C-strand is filled
   in, at the end of G2.

   Daughter ends. The fork that copies an end always moves toward it, so the
   strand it copies continuously flips between the two ends. Sister 1, the
   sister copied from the top parental strand, carries the leading-made left
   end and the lagging-made right end; sister 2 carries the other two. Each
   daughter starts RULE.telomereLoss bp shorter than its parent, the average
   loss per end per generation without telomerase (Marcand et al. 1999). How
   that loss divides between the leading- and lagging-made ends (Soudet et al.
   2014) is left for a later pass, so both lose the same.

   Processing. A leading-made end starts blunt; Cdk1-phosphorylated Sae2 and
   MRX resect it (Frank et al. 2006) and Cdc13 loads on the overhang
   RULE.leadToCdc13 min after the fork arrives. A lagging-made end starts with
   an overhang and loads Cdc13 after RULE.lagToCdc13 min. From then until
   RULE.fillDur min before anaphase, telomerase can be recruited. Recruitment
   is a random event with hazard
       lambda(n) = kTel * exp(-n / s0) / (1 + cRif * r(n)),
   n the end's Rap1 sites and r(n) the Rif1 it holds, n * 2 / 17 as a smooth
   count. exp(-n / s0) is Tel1, which marks short ends (Sabourin et al. 2007)
   and which Rif2 keeps off long ones (Hirano et al. 2009); the denominator is
   Rif1's brake, cRif a drawing value. kTel and s0 are not chosen: they are
   solved so that over RULE.telWindowRef min, the mean window of a wild-type
   end in the model, an end of 300 bp is extended 7% of the time and an end of
   125 bp 39% of the time (Teixeira et al. 2004, as Chang et al. 2007 report
   them). A recruited telomerase holds one of RULE.telomeraseCopies copies, the
   29 TLC1 RNAs of a haploid cell (Mozdy and Cech 2006) shared over the 16
   real ends each model end stands for, while it adds repeats for
   RULE.extDur min; the repeats added are drawn from an exponential whose mean
   is 44 nt at ends of 200 bp or more and 102 nt at ends of 125 bp or less
   (Chang et al. 2007), straight between. Pif1 and Ipl1 then remove it, and
   Stn1-Ten1 with Pol alpha fills in the C-strand (Grossi et al. 2004) over
   RULE.fillDur min, leaving the end capped. An end telomerase does not reach
   is filled in at the close of its window. cdc13-2 cannot recruit Est1
   (Nugent et al. 1996), and est2 deletion leaves no telomerase, so neither
   extends any end. Telomere draws come from a third seeded stream, so they
   never change the replication of a run.

   G2. Anaphase begins RULE.g2 min after the last stretch is copied, so the
   ends copied last still have a window for telomerase (telomere addition
   continues into M-phase-arrested cells, Diede and Gottschling 1999).

   ONE-ORIGIN CHROMOSOME
   The telomere view follows a hypothetical chromosome with one origin and
   no origin program: the origin fires RULE.oneOrigin.fireAt min after G1/S,
   as the last stretch of a genome otherwise copied, and its two forks run at
   RULE.forkSpeed to the two ends, RULE.oneOrigin.leftKb and rightKb away, then
   through each end's repeat to its tip. The ends, their daughters, their Rif1
   and their processing follow the TELOMERES rules unchanged; the run has no
   DDK dealing, no firing factors and no checkpoint, because none of them acts
   on an end. Arm lengths are drawing values, set short so the forks reach the
   ends within a few minutes, and equal, so the two forks reach the two ends
   together and the four daughter ends start their steps at one moment.

   ALLELES
   dbf4-zn: the Ctf19 complex no longer concentrates DDK on the origins
   beside the centromere (weight 1), and fewer DDK copies are active, fewer
   still without Rad53; the paper calls that synergy unexplained.
   ctf19 or mcm21 deletion: weight 1 at the centromere origins.
   mcm2-1, mcm3-1, mcm5-1: each origin is licensed with probability
   RULE.licenseMcm; firing was not measured in these strains, so this is an
   inference.
   Late artificial kinetochore: a second kinetochore site RULE.akSite kb
   along, 20 kb from the unchecked origin L2; with ASK1-LacI it is active.
   cdc13-2 and est2 deletion: see TELOMERES.

   Every time in a schedule is minutes into S, where S onset is the first
   firing; onsetFromG1S records that firing after G1/S. The random draws come
   from one seeded generator, so a seed replays its run exactly.

   The supplies, rates, positions, threshold, switching times, dNTP shares,
   delays, fork speed, collapse hazard, resection rates and spindle lengths
   are drawing values. The threshold is a proposal. L1 and R1 sit 10 kb from
   the centromere, the closest the drawing allows; real centromere-flanking
   origins sit closer, and the resection rate is set for this distance.

   TUNING
   The rates were chosen so that each of these comes out of the rule:
     wild type fires the Ctf19 pair, then the Fkh1/2 pair, a fork copies R3,
     and L3 fires once R3's DDK reaches it;
     dbf4-1 leaves both telomere-side origins to be copied passively;
     with only L3 and R3 left open, their marks still reach the threshold,
     slowly, so in HU without Rad53, or with sld3-38A dbf4-4A, the late
     origins fire (Santocanale and Diffley 1998; Zegerman and Diffley 2010),
     while in normal S a fork reaches R3 first;
     the RPA from the Ctf19 pair's forks alone stays under the Rad53
     threshold until the Fkh1/2 pair has fired, so in HU the early origins
     fire and the late ones do not;
     bob1 alone keeps the Ctf19 pair firing first in most runs and ends S near
     wild type, and bob1 dbf4 deletion takes much longer with most origins
     copied passively (Hoang et al. 2007). A bob1 pair is permissive about a
     thirtieth of the time; a fifth gave the opposite of both phenotypes. */

var CHROM_RULE = (function () {

  var RULE = {
    chromosomeKb: 240,
    centromere: 120,
    telomeres: { 'TEL-L': 0, 'TEL-R': 240 },
    origins: [
      { name: 'L3', position: 15, recruiter: 'none', d: 1, load: 2.4 },
      { name: 'L2', position: 55, recruiter: 'Fkh1/2', d: 2, load: 1 },
      { name: 'L1', position: 110, recruiter: 'Ctf19', d: 4, load: 1 },
      { name: 'R1', position: 130, recruiter: 'Ctf19', d: 4, load: 1 },
      { name: 'R2', position: 185, recruiter: 'Fkh1/2', d: 2, load: 1 },
      { name: 'R3', position: 212, recruiter: 'none', d: 1, load: 2.4 }
    ],
    telomereReach: 30,   // kb over which a telomere's captured Rif1 acts
    ddkTotal: 10,        // DDK copies drawn in the reservoir
    rif1Total: 10,       // Rif1 copies in the cell
    rif1Captured: 2,     // Rif1 copies a wild-type telomere's Rap1 array holds
    rif1Free: 6,         // Rif1 copies left free with both ends at the wild-type length
    crossing: ['Rif1'],  // the proteins that cross between the origin and telomere sides
    telomereBp: 325,     // bp of repeat at each end at G1/S (Ray and Runge 1999)
    bpPerRap1: 19,       // bp of repeat per Rap1 site (Ray and Runge 1999)
    wtSites: 17,         // Rap1 sites of a wild-type end, floor(325 / 19)
    telomereLoss: 3,     // bp each daughter end starts shorter than its parent (Marcand et al. 1999)
    leadToCdc13: 4,      // min from the fork's arrival to Cdc13 on a leading-made end
    lagToCdc13: 2,       // min from the fork's arrival to Cdc13 on a lagging-made end
    teixeira: [[300, 0.07], [125, 0.39]],   // bp, share of ends extended per cycle (Teixeira et al. 2004)
    telWindowRef: 14,    // min, the mean telomerase window of a wild-type end in the model (1000 runs)
    cRif: 0.5,           // Rif1's brake on telomerase recruitment per copy held; a drawing value
    telomeraseCopies: 2, // 29 TLC1 RNAs (Mozdy and Cech 2006) over 16 real ends per model end
    extMean: [[200, 44], [125, 102]],       // bp, mean nt added per extension (Chang et al. 2007)
    extDur: 2,           // min telomerase stays on an end it extends
    releaseDur: 1,       // min Pif1 and Ipl1 take to remove it
    fillDur: 2,          // min Stn1-Ten1 and Pol alpha take to fill in the C-strand
    g2: 20,              // min from the last stretch copied to anaphase
    oneOrigin: { fireAt: 30, leftKb: 5, rightKb: 5 },   // the telomere view's chromosome; drawing values
    kDdk: 0.588,         // marks per min added by one DDK copy
    kPp1: 0.028,         // share of marks per min removed by one Rif1-PP1 copy
    theta: 20,           // marks needed to be ready
    sets: 2,             // Sld3-Sld7, Sld2 and Dpb11, drawn as one set
    setReturn: 4,        // min from firing until the set is free again
    forkSpeed: 2,        // kb per min with a full dNTP pool
    bob1On: 5,           // mean min a bob1 pair stays permissive
    bob1Off: 145,        // mean min it stays out of the permissive shape
    huMax: 240,          // min from G1/S after which a run in HU that has done neither is shown still in S
    extendShow: 30,      // min of premature spindle extension a run shows before it stops
    restartDelay: 40,    // min a collapsed fork waits before it resumes, in a cell with Rad53
    huDntp: 0.1,         // dNTP pool in HU, as a share of normal
    dun1Dntp: 0.25,      // dNTP pool in HU once Dun1 acts
    rpaRate: 0.1,        // RPA levels per min at a moving fork, times the dNTP shortfall
    rpaMax: 3,           // RPA levels a fork can carry, one wedge each on the panel
    rad53Signal: 4.5,    // summed RPA at which Mec1 and Mrc1 switch Rad53 on
    collapseK: 0.27,     // collapse hazard per min of a fork without Rad53 at the reference load
    collapseRef: 5.9,    // reference load: weighted moving forks times (HU pool / pool) ^ poolExp
    collapseN: 4.5,      // steepness of the hazard in the load
    poolExp: 0.45,       // how strongly the pool enters the load
    rad53Protect: 0.36,  // share of the hazard left at a fork in a cell with Rad53
    exoRate: 0.95,       // kb per min Exo1 resects from a collapsed fork, each way
    exo1Rate: 0.18,      // kb per min resection runs without Exo1
    resectReach: 6.6,    // kb resection reaches each way from a collapsed fork
    akSite: 75,          // kb position of the late artificial kinetochore site
    licenseMcm: 0.34,    // chance an origin is licensed in an mcm allele
    zfDdk: 7,            // active DDK copies in dbf4-zn with Rad53
    zfDdkNoRad53: 6,     // active DDK copies in dbf4-zn without Rad53
    g1Release: 30,       // min from release out of G1 to G1/S, for the scoring times
    spindleForm: 30,     // min after G1/S the spindle forms
    spindleShort: 1.5,   // um, a spindle held by its kinetochores
    spindleRate: 0.43,   // um per min an unanchored spindle extends
    spindlePeak: [4, 7], // um, the range one cycle of extension reaches before it breaks
    spindleDrop: 3.2,    // um a broken spindle falls back to; it stays in the extended range
    spindleLine: 3,      // um, the extended-spindle line
    anaphaseLen: 9,      // um, an anaphase spindle
    anaphaseRate: 0.8,   // um per min in anaphase
    scoreAt: 60,         // min after G1/S that a strain is scored, 90 min after release
    scoreEarly: 50,      // small buds, slide 6
    scoreLate: 75,       // large buds, slide 6
    maxEvents: 20000     // a run that needs more than this is reported, not looped
  };

  var GENOTYPES = [
    { key: 'wt', label: 'wild type', ddkActive: 10, rif1: true, needsBob1: false },
    { key: 'dbf4-1', label: 'dbf4-1, semi-permissive', ddkActive: 6, rif1: true, needsBob1: false },
    { key: 'dbf4', label: 'dbf4Δ', ddkActive: 0, rif1: true, needsBob1: true },
    { key: 'rif1', label: 'rif1Δ', ddkActive: 10, rif1: false, needsBob1: false },
    { key: 'dbf4-1-rif1', label: 'dbf4-1 rif1Δ', ddkActive: 6, rif1: false, needsBob1: false }
  ];

  // The checkpoint alleles. rad53: rad53-21, drawn with no Rad53 activity.
  // sites: Sld3 and Dbf4 carry no Rad53 sites, so the firing arms are gone and
  // the rest stays.
  var CHECKPOINTS = [
    { key: 'wt', label: 'Checkpoint intact', rad53: true, sld3Arm: true, dbf4Arm: true, dun1Arm: true },
    { key: 'rad53', label: 'rad53-21', rad53: false, sld3Arm: false, dbf4Arm: false, dun1Arm: false },
    { key: 'sites', label: 'dbf4-m25 sld3-38A', rad53: true, sld3Arm: false, dbf4Arm: false, dun1Arm: true }
  ];

  // Alleles that combine with any genotype and checkpoint.
  var ALLELES = [
    { key: 'dbf4zn', label: 'dbf4-zn' },
    { key: 'mcm', label: 'mcm2-1, mcm3-1 or mcm5-1' },
    { key: 'ctf19', label: 'ctf19\u0394 or mcm21\u0394' },
    { key: 'exo1', label: 'exo1\u0394' },
    { key: 'dun1', label: 'dun1\u0394' },
    { key: 'cdc13_2', label: 'cdc13-2' },
    { key: 'est2', label: 'est2\u0394' }
  ];

  var AK_CHOICES = [
    { key: 'none', label: 'no artificial kinetochore' },
    { key: 'vector', label: 'late AK site, vector' },
    { key: 'on', label: 'late AK site, ASK1-LacI' }
  ];

  // The strains of slides 2 to 6, each as the switches that draw it and the
  // share of cells with spindles of 3 um or more the papers report (Julius et
  // al. 2019; wild type, Gasparyan et al. 2022). when names the scoring time:
  // at, 90 min after release; early, small buds.
  var PRESETS = [
    { key: 's2-wt', slide: 2, label: 'wild type', checkpoint: 'wt', alleles: {}, ak: 'none', when: 'at', paper: '6%' },
    { key: 's2-rad53', slide: 2, label: 'rad53-21', checkpoint: 'rad53', alleles: {}, ak: 'none', when: 'at', paper: '53%' },
    { key: 's3-zn', slide: 3, label: 'rad53-21 dbf4-zn', checkpoint: 'rad53', alleles: { dbf4zn: true }, ak: 'none', when: 'at', paper: '4 to 11%' },
    { key: 's3-mcm', slide: 3, label: 'rad53-21 mcm2-1', checkpoint: 'rad53', alleles: { mcm: true }, ak: 'none', when: 'at', paper: '5%' },
    { key: 's4-sites', slide: 4, label: 'dbf4-m25 sld3-38A', checkpoint: 'sites', alleles: {}, ak: 'none', when: 'at', paper: '50%' },
    { key: 's4-dun1', slide: 4, label: 'dbf4-m25 sld3-38A dun1\u0394', checkpoint: 'sites', alleles: { dun1: true }, ak: 'none', when: 'at', paper: '72%' },
    { key: 's5-ctf19', slide: 5, label: 'rad53-21 ctf19\u0394', checkpoint: 'rad53', alleles: { ctf19: true }, ak: 'none', when: 'at', paper: '11%' },
    { key: 's5-akv', slide: 5, label: 'rad53-21 4\u00d7 LATE-AK + vector', checkpoint: 'rad53', alleles: {}, ak: 'vector', when: 'at', paper: '40%' },
    { key: 's5-ako', slide: 5, label: 'rad53-21 4\u00d7 LATE-AK + ASK1-LacI', checkpoint: 'rad53', alleles: {}, ak: 'on', when: 'at', paper: '10%' },
    { key: 's6-rad53', slide: 6, label: 'rad53-21, small buds', checkpoint: 'rad53', alleles: {}, ak: 'none', when: 'early', paper: '42%' },
    { key: 's6-exo1', slide: 6, label: 'rad53-21 exo1\u0394, small buds', checkpoint: 'rad53', alleles: { exo1: true }, ak: 'none', when: 'early', paper: '7%' },
    { key: 's6-exo1l', slide: 6, label: 'rad53-21 exo1\u0394, large buds', checkpoint: 'rad53', alleles: { exo1: true }, ak: 'none', when: 'late', paper: '32%' }
  ];

  // === BASE CONTROLLER: simulate ==========================================

  function simulate(genotypeKey, bob1, seed, opts) {
    // BASE CONTROLLER: one run of the rule for one genotype, condition and seed.

    var genotype = findGenotype(genotypeKey);
    var checkpoint = findCheckpoint((opts || {}).checkpoint);
    var alleles = readAlleles(opts || {});
    var state = startState(genotype, checkpoint, alleles, bob1, seed, !!(opts || {}).hu,
      (opts || {}).telomereBp);
    if ((opts || {}).oneOrigin) { runOneOrigin(state); }
    else if (state.viable) { runEvents(state); }
    var anchors = placeAnchors(state);
    var outcome = judgeOutcome(state, anchors);
    var spindle = buildSpindle(state, anchors, outcome);
    var ends = processTelomeres(state, outcome);
    return assembleSchedule(state, anchors, spindle, outcome, ends);

    // === SUB-CONTROLLERS ===

    function findGenotype(key) {
      // MODEL: the preset named by key, wild type if none (TERMINAL)
      var i;
      for (i = 0; i < GENOTYPES.length; i += 1) {
        if (GENOTYPES[i].key === key) { return GENOTYPES[i]; }
      }
      return GENOTYPES[0];
    }

    function findCheckpoint(key) {
      // MODEL: the checkpoint allele named by key, intact if none (TERMINAL)
      var i;
      for (i = 0; i < CHECKPOINTS.length; i += 1) {
        if (CHECKPOINTS[i].key === key) { return CHECKPOINTS[i]; }
      }
      return CHECKPOINTS[0];
    }

    function readAlleles(o) {
      // MODEL: the allele switches, every one present and false unless set (TERMINAL)
      var a = o.alleles || {}, out = {}, i;
      for (i = 0; i < ALLELES.length; i += 1) { out[ALLELES[i].key] = !!a[ALLELES[i].key]; }
      out.ak = o.ak === 'vector' || o.ak === 'on' ? o.ak : 'none';
      return out;
    }

    function startState(genotype, checkpoint, alleles, bob1, seed, hu, telBp) {
      // MODEL: G1/S: every licensed origin open with no marks, every set free,
      // each bob1 pair in a shape drawn from its long-run share, each end at
      // its starting length holding Rif1 by its Rap1 sites (TERMINAL)
      // telBp is one length for both ends, or { L: bp, R: bp }.
      var arms = { rad53: checkpoint.rad53, sld3Arm: checkpoint.sld3Arm, dbf4Arm: checkpoint.dbf4Arm,
        dun1Arm: checkpoint.dun1Arm && !alleles.dun1 };
      var ddk = genotype.ddkActive;
      if (alleles.dbf4zn) { ddk = Math.min(ddk, checkpoint.rad53 ? RULE.zfDdk : RULE.zfDdkNoRad53); }
      var s = {
        genotype: genotype, checkpoint: checkpoint, arms: arms, alleles: alleles, bob1: !!bob1, hu: hu,
        seed: seed >>> 0, rng: seed >>> 0, ddkActive: ddk,
        viable: true, stuck: null,
        t: 0, dntp: hu ? RULE.huDntp : 1, rad53At: null, firstFork: null, signal: 0,
        signalPath: [[0, 0]], rad53Forks: null, collapses: [],
        marks: {}, eligible: {}, perm: {}, nextSwitch: {}, fates: {}, weight: {},
        forks: [], setFreeAt: [], setLog: [], terminations: [], telomeres: {}, telo: {},
        events: [], segments: [], overflow: false, ended: false
      };
      var i, name, u, z, share, mean, licensed = 0, side, bp;
      for (i = 0; i < 2; i += 1) {
        side = i === 0 ? 'L' : 'R';
        bp = typeof telBp === 'number' ? telBp
          : (telBp && typeof telBp[side] === 'number' ? telBp[side] : RULE.telomereBp);
        bp = Math.max(0, Math.round(bp));
        s.telo['TEL-' + side] = { side: side, bp: bp, sites: Math.floor(bp / RULE.bpPerRap1),
          rif: genotype.rif1 ? Math.round(Math.floor(bp / RULE.bpPerRap1) * RULE.rif1Captured / RULE.wtSites) : 0,
          t: null, daughters: null };
      }
      for (i = 0; i < RULE.sets; i += 1) { s.setFreeAt.push(0); }
      share = RULE.bob1On / (RULE.bob1On + RULE.bob1Off);
      for (i = 0; i < RULE.origins.length; i += 1) {
        name = RULE.origins[i].name;
        s.marks[name] = 0;
        s.perm[name] = false;
        s.nextSwitch[name] = null;
        if (s.bob1) {
          // Two uniform draws: one for the shape, one for how long it lasts.
          s.rng = (s.rng + 0x6D2B79F5) | 0;
          z = Math.imul(s.rng ^ (s.rng >>> 15), 1 | s.rng);
          z = (z + Math.imul(z ^ (z >>> 7), 61 | z)) ^ z;
          u = ((z ^ (z >>> 14)) >>> 0) / 4294967296;
          s.perm[name] = u < share;
          s.rng = (s.rng + 0x6D2B79F5) | 0;
          z = Math.imul(s.rng ^ (s.rng >>> 15), 1 | s.rng);
          z = (z + Math.imul(z ^ (z >>> 7), 61 | z)) ^ z;
          u = ((z ^ (z >>> 14)) >>> 0) / 4294967296;
          mean = s.perm[name] ? RULE.bob1On : RULE.bob1Off;
          s.nextSwitch[name] = -mean * Math.log(1 - u);
        }
      }
      // Recruiter weights: the Ctf19 complex loses its pull in ctf19, mcm21 and dbf4-zn.
      for (i = 0; i < RULE.origins.length; i += 1) {
        s.weight[RULE.origins[i].name] = RULE.origins[i].recruiter === 'Ctf19'
          && (alleles.ctf19 || alleles.dbf4zn) ? 1 : RULE.origins[i].d;
      }
      // An mcm allele licenses each origin only some of the time; an origin
      // left unlicensed never opens and is copied by a passing fork.
      for (i = 0; i < RULE.origins.length; i += 1) {
        name = RULE.origins[i].name;
        if (alleles.mcm) {
          s.rng = (s.rng + 0x6D2B79F5) | 0;
          z = Math.imul(s.rng ^ (s.rng >>> 15), 1 | s.rng);
          z = (z + Math.imul(z ^ (z >>> 7), 61 | z)) ^ z;
          u = ((z ^ (z >>> 14)) >>> 0) / 4294967296;
          if (u >= RULE.licenseMcm) {
            s.fates[name] = { fate: 'unlicensed', t: null, meter: 0, by: null, route: null };
            s.nextSwitch[name] = null;
            s.perm[name] = false;
            continue;
          }
        }
        licensed += 1;
      }
      if (!licensed) { s.viable = false; s.stuck = 'no origin is licensed, so none can fire'; }
      else if (ddk <= 0 && !s.bob1) { s.viable = false; s.stuck = 'no DDK and no bob1: no origin can fire'; }
      return s;
    }

    function runOneOrigin(s) {
      // MODEL: the one-origin chromosome: one firing, two forks to the two tips, each end split at its tip (TERMINAL)
      // Every origin of the six-origin rule is marked unlicensed, so nothing
      // of the origin side runs. Times are minutes from G1/S.
      var one = RULE.oneOrigin, v = RULE.forkSpeed, t0 = one.fireAt;
      RULE.origins.forEach(function (o) {
        s.fates[o.name] = { fate: 'unlicensed', t: null, meter: 0, by: null, route: null };
      });
      s.viable = true;
      s.stuck = null;
      s.hu = false;
      s.oneOrigin = { fireAt: t0, leftKb: one.leftKb, rightKb: one.rightKb, speed: v, forks: [] };
      [['L', -1, one.leftKb], ['R', 1, one.rightKb]].forEach(function (f) {
        var tel = 'TEL-' + f[0], par = s.telo[tel];
        var tJ = t0 + f[2] / v, t1 = tJ + par.bp / 1000 / v;
        s.oneOrigin.forks.push({ side: f[0], direction: f[1], t0: t0, tJ: tJ, t1: t1 });
        s.telomeres[tel] = { t: t1, fork: 'one-' + (f[1] < 0 ? 'left' : 'right'), origin: 'the origin' };
        splitEnd(s, tel, t1);
      });
      s.t = Math.max(s.oneOrigin.forks[0].t1, s.oneOrigin.forks[1].t1);
    }

    function runEvents(s) {
      // SUB-CONTROLLER: deal, find the next event, advance marks and forks, apply it

      var held = dealFactors(s, endHolds(s));
      var h = forkHazard(s);
      var event = findNextEvent(s, held, h);
      var n = 0;
      while (event !== null && !s.ended) {
        n += 1;
        if (n > RULE.maxEvents) { s.overflow = true; return; }
        advanceState(s, held, h, event.t);
        applyEvent(s, event);
        held = dealFactors(s, endHolds(s));
        h = forkHazard(s);
        event = findNextEvent(s, held, h);
      }

      function endHolds(s) {
        // MODEL: the Rif1 copies each end holds now, and the copies left free (TERMINAL)
        // An end not yet copied holds by its own sites; a copied end is its
        // two daughters, each holding by its own sites.
        // Arrays that would hold more copies than the cell has share all of
        // them by their claims, whole copies, remainders to the left end first.
        var out = { tel: {}, free: 0 }, held = 0, tel, e, want = {}, total = RULE.rif1Total, left;
        ['TEL-L', 'TEL-R'].forEach(function (tel) {
          e = s.telo[tel];
          want[tel] = e.daughters ? e.daughters[0].rif + e.daughters[1].rif : e.rif;
          held += want[tel];
        });
        if (!s.genotype.rif1) { out.tel = { 'TEL-L': 0, 'TEL-R': 0 }; return out; }
        if (held <= total) {
          out.tel = want;
          out.free = total - held;
          return out;
        }
        left = total;
        ['TEL-L', 'TEL-R'].forEach(function (tel) {
          out.tel[tel] = Math.floor(total * want[tel] / held);
          left -= out.tel[tel];
        });
        ['TEL-L', 'TEL-R'].forEach(function (tel) {
          if (left > 0 && out.tel[tel] < want[tel]) { out.tel[tel] += 1; left -= 1; }
        });
        return out;
      }

      function forkHazard(s) {
        // MODEL: the collapse hazard each moving fork carries now (TERMINAL)
        // Load is the moving forks, each counted for the origins of its class
        // it stands for, times (HU pool / pool) to the power RULE.poolExp.
        var moving = s.forks.filter(function (f) { return f.status === 'moving'; }), load = 0, i, j;
        if (!s.hu || !moving.length || s.dntp >= 1) { return 0; }
        for (i = 0; i < moving.length; i += 1) {
          for (j = 0; j < RULE.origins.length; j += 1) {
            if (RULE.origins[j].name === moving[i].origin) { load += RULE.origins[j].load; }
          }
        }
        load = load * Math.pow(RULE.huDntp / s.dntp, RULE.poolExp);
        return RULE.collapseK * Math.pow(load / RULE.collapseRef, RULE.collapseN)
          * (s.arms.rad53 ? RULE.rad53Protect : 1);
      }

      function dealFactors(s, holds) {
        // MODEL: the copies each open origin holds now, by the dealing rule (TERMINAL)
        // Active Rad53 with its Dbf4 arm takes every DDK copy off the origins.
        // holds is the Rif1 the ends hold and the copies left free.
        var open = RULE.origins.filter(function (o) { return !s.fates[o.name]; });
        var ddkBlocked = s.rad53At !== null && s.arms.dbf4Arm;
        var jobs = [['ddk', ddkBlocked ? 0 : s.ddkActive,
          open.map(function (o) { return [o.name, s.weight[o.name]]; })]];
        var held = { ddk: {}, rifFree: {}, rifCap: {}, idle: {}, rifPool: holds.free,
          rifTel: JSON.parse(JSON.stringify(holds.tel)) };
        var j, k, job, total, quota, share, left, rems, r, group, bucket, tel, end;
        open.forEach(function (o) {
          held.ddk[o.name] = 0; held.rifFree[o.name] = 0; held.rifCap[o.name] = 0;
        });
        if (s.genotype.rif1) {
          jobs.push(['rifFree', holds.free, open.map(function (o) { return [o.name, 1]; })]);
          for (tel in RULE.telomeres) {
            if (Object.prototype.hasOwnProperty.call(RULE.telomeres, tel)) {
              end = RULE.telomeres[tel];
              jobs.push(['cap-' + tel, holds.tel[tel], open.filter(function (o) {
                return Math.abs(o.position - end) <= RULE.telomereReach;
              }).map(function (o) { return [o.name, 1]; })]);
            }
          }
        }
        for (j = 0; j < jobs.length; j += 1) {
          job = jobs[j];
          total = job[2].reduce(function (a, w) { return a + w[1]; }, 0);
          share = {};
          quota = {};
          left = job[1];
          job[2].forEach(function (w) { share[w[0]] = 0; });
          if (total > 0 && job[1] > 0) {
            job[2].forEach(function (w) {
              quota[w[0]] = job[1] * w[1] / total;
              share[w[0]] = Math.floor(quota[w[0]] + 1e-9);
            });
            left = job[1] - job[2].reduce(function (a, w) { return a + share[w[0]]; }, 0);
            rems = [];
            job[2].forEach(function (w) {
              r = Math.round((quota[w[0]] - share[w[0]]) * 1e9) / 1e9;
              if (rems.indexOf(r) < 0) { rems.push(r); }
            });
            rems.sort(function (a, b) { return b - a; });
            for (k = 0; k < rems.length; k += 1) {
              if (rems[k] <= 1e-9) { break; }
              group = job[2].filter(function (w) {
                return Math.abs(Math.round((quota[w[0]] - share[w[0]]) * 1e9) / 1e9 - rems[k]) < 1e-9;
              });
              if (group.length > left) { break; }
              group.forEach(function (w) { share[w[0]] += 1; });
              left -= group.length;
            }
          }
          bucket = job[0].indexOf('cap-') === 0 ? 'rifCap' : job[0];
          job[2].forEach(function (w) { held[bucket][w[0]] += share[w[0]]; });
          held.idle[job[0]] = left;
        }
        held.idle.ddkBlocked = ddkBlocked ? s.ddkActive : 0;
        return held;
      }

      function findNextEvent(s, held, h) {
        // MODEL: the earliest next event; ties break as the header says (TERMINAL)
        // Priority at one instant: passive 0, meet 1, telomere 2, a change of
        // readiness, Rad53 or a collapse 3, a firing 4, the end of the window 5.
        var t = s.t, theta = RULE.theta, v = RULE.forkSpeed * s.dntp;
        var cands = [], free, open, active, ready, i, o, m, add, k, mInf, wait;
        var fork, gap, tel, end, best, c, vi, vj;
        var fireBlocked = s.rad53At !== null && s.arms.sld3Arm;
        open = RULE.origins.filter(function (o) { return !s.fates[o.name]; });
        ready = open.filter(function (o) { return s.eligible[o.name] !== undefined || s.perm[o.name]; });
        if (ready.length && !fireBlocked) {
          free = Math.min.apply(null, s.setFreeAt);
          cands.push({ t: Math.max(t, free), p: 4, x: 0, e: { kind: 'fire' } });
        }
        if (s.hu) {
          cands.push({ t: Math.max(t, RULE.huMax), p: 5, x: 0, e: { kind: 'end' } });
          if (s.arms.rad53 && s.rad53At === null) {
            // The summed RPA grows linearly until some fork fills up, so the
            // crossing is exact unless a fork saturates first; then that
            // moment is an event of its own and the crossing is found after it.
            var g = RULE.rpaRate * (1 - s.dntp), growing = 0, sat = null;
            s.forks.forEach(function (f) {
              if (f.status === 'moving' && f.rpa < RULE.rpaMax - 1e-9) {
                growing += 1;
                if (g > 0) {
                  var ts = t + (RULE.rpaMax - f.rpa) / g;
                  if (sat === null || ts < sat) { sat = ts; }
                }
              }
            });
            if (s.signal >= RULE.rad53Signal - 1e-9) {
              cands.push({ t: t, p: 3, x: 0, e: { kind: 'rad53' } });
            } else if (growing > 0 && g > 0) {
              var tc = t + (RULE.rad53Signal - s.signal) / (growing * g);
              if (sat !== null && sat < tc - 1e-9) {
                cands.push({ t: sat, p: 3, x: 0, e: { kind: 'rpafull' } });
              } else {
                cands.push({ t: tc, p: 3, x: 0, e: { kind: 'rad53' } });
              }
            }
          }
        }
        for (i = 0; i < open.length; i += 1) {
          o = open[i];
          if (s.nextSwitch[o.name] !== null) {
            cands.push({ t: Math.max(t, s.nextSwitch[o.name]), p: 3, x: o.position,
              e: { kind: 'switch', origin: o.name } });
          }
          if (s.eligible[o.name] !== undefined) { continue; }
          m = s.marks[o.name];
          add = RULE.kDdk * held.ddk[o.name];
          k = RULE.kPp1 * (held.rifFree[o.name] + held.rifCap[o.name]);
          wait = null;
          if (m >= theta - 1e-9) {
            wait = 0;
          } else if (k > 0) {
            mInf = add / k;
            if (mInf > theta + 1e-12) { wait = -Math.log((mInf - theta) / (mInf - m)) / k; }
          } else if (add > 0) {
            wait = (theta - m) / add;
          }
          if (wait !== null) {
            cands.push({ t: t + wait, p: 3, x: o.position, e: { kind: 'eligible', origin: o.name } });
          }
        }
        active = s.forks.filter(function (f) { return f.status !== 'done'; });
        active.forEach(function (f) {
          if (f.status === 'collapsed' && f.restartAt !== null) {
            cands.push({ t: Math.max(t, f.restartAt), p: 3, x: f.x, e: { kind: 'restart', fork: f.id } });
          }
        });
        for (i = 0; i < active.length; i += 1) {
          fork = active[i];
          if (fork.status === 'moving' && v > 0) {
            open.forEach(function (o) {
              gap = (o.position - fork.x) * fork.direction;
              if (gap > 0) {
                cands.push({ t: t + gap / v, p: 0, x: o.position,
                  e: { kind: 'passive', fork: fork.id, origin: o.name } });
              }
            });
            tel = fork.direction < 0 ? 'TEL-L' : 'TEL-R';
            end = RULE.telomeres[tel];
            cands.push({ t: t + Math.abs(end - fork.x) / v, p: 2, x: end,
              e: { kind: 'telomere', fork: fork.id, telomere: tel } });
            if (h > 0) {
              cands.push({ t: t + Math.max(0, fork.E - fork.H) / h, p: 3, x: fork.x,
                e: { kind: 'collapse', fork: fork.id } });
            }
          }
          if (fork.direction > 0) {
            active.forEach(function (other) {
              if (other.direction < 0 && other.origin !== fork.origin && other.x > fork.x - 1e-9) {
                vi = fork.status === 'moving' ? v : 0;
                vj = other.status === 'moving' ? v : 0;
                if (vi + vj > 0) {
                  cands.push({ t: t + (other.x - fork.x) / (vi + vj), p: 1, x: fork.x,
                    e: { kind: 'meet', left: fork.id, right: other.id,
                      x: fork.x + vi * (other.x - fork.x) / (vi + vj) } });
                }
              }
            });
          }
        }
        if (!cands.length) { return null; }
        best = null;
        for (i = 0; i < cands.length; i += 1) {
          c = cands[i];
          c.r = Math.round(c.t * 1e9) / 1e9;
          if (best === null || c.r < best.r || (c.r === best.r && (c.p < best.p
              || (c.p === best.p && c.x < best.x)))) {
            best = c;
          }
        }
        best.e.t = Math.max(best.t, t);
        return best.e;
      }

      function advanceState(s, held, h, tNext) {
        // MODEL: record the segment up to tNext, move marks and forks there (TERMINAL)
        var dt = tNext - s.t, seg, open, i, n, m, add, k, mInf, v = RULE.forkSpeed * s.dntp;
        if (dt <= 1e-12) { return; }
        open = RULE.origins.filter(function (o) { return !s.fates[o.name]; });
        seg = { t0: s.t, t1: tNext, marks0: {}, ddk: {}, rifFree: {}, rifCap: {}, perm: {},
          ready: {}, idle: JSON.parse(JSON.stringify(held.idle)), dntp: s.dntp,
          rad53: s.rad53At !== null, rifPool: held.rifPool, rifTel: JSON.parse(JSON.stringify(held.rifTel)) };
        for (i = 0; i < open.length; i += 1) {
          n = open[i].name;
          seg.marks0[n] = s.marks[n];
          seg.ddk[n] = held.ddk[n];
          seg.rifFree[n] = held.rifFree[n];
          seg.rifCap[n] = held.rifCap[n];
          seg.perm[n] = s.perm[n];
          seg.ready[n] = s.eligible[n] !== undefined || s.perm[n];
          m = s.marks[n];
          add = RULE.kDdk * held.ddk[n];
          k = RULE.kPp1 * (held.rifFree[n] + held.rifCap[n]);
          if (k > 0) {
            mInf = add / k;
            s.marks[n] = mInf + (m - mInf) * Math.exp(-k * dt);
          } else {
            s.marks[n] = m + add * dt;
          }
        }
        s.signal = 0;
        s.forks.forEach(function (f) {
          if (f.status === 'moving') {
            f.x += f.direction * v * dt;
            f.path.push([tNext, f.x]);
            f.rpa = Math.min(RULE.rpaMax, f.rpa + RULE.rpaRate * (1 - s.dntp) * dt);
            f.rpaPath.push([tNext, f.rpa]);
            f.H += h * dt;
          }
          if (f.status !== 'done') { s.signal += f.rpa; }
        });
        s.signalPath.push([tNext, s.signal]);
        s.segments.push(seg);
        s.t = tNext;
      }

      function applyEvent(s, e) {
        // MODEL: update readiness, shapes, Rad53, forks, fates, sets and the log for one event (TERMINAL)
        var t = e.t, forks = {}, ready, pick, name, x, slot, back, u, z, mean, side, i, fork, clock;
        s.forks.forEach(function (f) { forks[f.id] = f; });
        if (e.kind === 'eligible') {
          s.eligible[e.origin] = t;
        } else if (e.kind === 'switch') {
          name = e.origin;
          s.perm[name] = !s.perm[name];
          s.rng = (s.rng + 0x6D2B79F5) | 0;
          z = Math.imul(s.rng ^ (s.rng >>> 15), 1 | s.rng);
          z = (z + Math.imul(z ^ (z >>> 7), 61 | z)) ^ z;
          u = ((z ^ (z >>> 14)) >>> 0) / 4294967296;
          mean = s.perm[name] ? RULE.bob1On : RULE.bob1Off;
          s.nextSwitch[name] = t - mean * Math.log(1 - u);
          e.perm = s.perm[name];
        } else if (e.kind === 'rad53') {
          s.rad53At = t;
          s.rad53Forks = s.forks.filter(function (f) { return f.status !== 'done' && f.rpa > 0; }).length;
          e.forks = s.rad53Forks;
          e.signal = s.signal;
          if (s.arms.dun1Arm) { s.dntp = RULE.dun1Dntp; }
        } else if (e.kind === 'rpafull') {
          e.signal = s.signal;
        } else if (e.kind === 'end') {
          s.ended = true;
        } else if (e.kind === 'collapse') {
          fork = forks[e.fork];
          fork.status = 'collapsed';
          if (fork.collapsedAt === null) { fork.collapsedAt = t; }
          fork.downs.push([t, null]);
          fork.restartAt = s.arms.rad53 ? t + RULE.restartDelay : null;
          s.collapses.push({ fork: fork.id, origin: fork.origin, x: fork.x, t: t });
        } else if (e.kind === 'restart') {
          // The fork resumes with a fresh collapse clock.
          fork = forks[e.fork];
          fork.status = 'moving';
          fork.restartAt = null;
          fork.downs[fork.downs.length - 1][1] = t;
          fork.path.push([t, fork.x]);
          fork.H = 0;
          s.rng = (s.rng + 0x6D2B79F5) | 0;
          z = Math.imul(s.rng ^ (s.rng >>> 15), 1 | s.rng);
          z = (z + Math.imul(z ^ (z >>> 7), 61 | z)) ^ z;
          u = ((z ^ (z >>> 14)) >>> 0) / 4294967296;
          fork.E = -Math.log(1 - u);
        } else if (e.kind === 'fire') {
          ready = RULE.origins.filter(function (o) {
            return !s.fates[o.name] && (s.eligible[o.name] !== undefined || s.perm[o.name]);
          });
          if (ready.length > 1) {
            s.rng = (s.rng + 0x6D2B79F5) | 0;
            z = Math.imul(s.rng ^ (s.rng >>> 15), 1 | s.rng);
            z = (z + Math.imul(z ^ (z >>> 7), 61 | z)) ^ z;
            u = ((z ^ (z >>> 14)) >>> 0) / 4294967296;
            pick = ready[Math.min(ready.length - 1, Math.floor(u * ready.length))];
            e.drawnFrom = ready.map(function (o) { return o.name; });
          } else {
            pick = ready[0];
          }
          name = pick.name;
          e.origin = name;
          e.route = s.eligible[name] !== undefined ? 'marks' : 'bypass';
          x = pick.position;
          slot = s.setFreeAt.indexOf(Math.min.apply(null, s.setFreeAt));
          back = t + RULE.setReturn;
          s.setFreeAt[slot] = back;
          s.setLog.push({ set: slot + 1, origin: name, out: t, back: back });
          s.fates[name] = { fate: 'fired', t: t, meter: s.marks[name] / RULE.theta, by: null,
            route: e.route };
          s.nextSwitch[name] = null;
          if (s.firstFork === null) { s.firstFork = t; }
          for (i = 0; i < 2; i += 1) {
            side = i === 0 ? 'left' : 'right';
            // The fork's collapse clock: one exponential draw, reached by the
            // hazard it accumulates while it moves.
            clock = Infinity;
            if (s.hu) {
              s.rng = (s.rng + 0x6D2B79F5) | 0;
              z = Math.imul(s.rng ^ (s.rng >>> 15), 1 | s.rng);
              z = (z + Math.imul(z ^ (z >>> 7), 61 | z)) ^ z;
              u = ((z ^ (z >>> 14)) >>> 0) / 4294967296;
              clock = -Math.log(1 - u);
            }
            s.forks.push({ id: name + '-' + side, origin: name, direction: i === 0 ? -1 : 1,
              x0: x, t0: t, x: x, status: 'moving', E: clock, H: 0, collapsedAt: null, downs: [], restartAt: null,
              x1: null, t1: null, end: null, path: [[t, x]], rpa: 0, rpaPath: [[t, 0]] });
          }
        } else if (e.kind === 'passive') {
          s.fates[e.origin] = { fate: 'passive', t: t, meter: s.marks[e.origin] / RULE.theta,
            by: e.fork, route: null };
          s.nextSwitch[e.origin] = null;
        } else if (e.kind === 'meet') {
          [e.left, e.right].forEach(function (id) {
            fork = forks[id];
            fork.x = e.x;
            fork.t1 = t;
            fork.x1 = e.x;
            fork.end = fork.status === 'collapsed' ? 'collapsed-met' : 'meet';
            if (fork.status === 'collapsed') { fork.downs[fork.downs.length - 1][1] = t; }
            fork.status = 'done';
            fork.restartAt = null;
            fork.path.push([t, e.x]);
            fork.rpa = 0;
            fork.rpaPath.push([t, 0]);
          });
          s.terminations.push({ t: t, x: e.x, forks: [e.left, e.right] });
        } else if (e.kind === 'telomere') {
          fork = forks[e.fork];
          fork.t1 = t;
          fork.x = RULE.telomeres[e.telomere];
          fork.x1 = fork.x;
          fork.end = 'telomere';
          fork.status = 'done';
          fork.path.push([t, fork.x]);
          fork.rpa = 0;
          fork.rpaPath.push([t, 0]);
          s.telomeres[e.telomere] = { t: t, fork: fork.id, origin: fork.origin };
          e.daughters = splitEnd(s, e.telomere, t);
        }
        s.events.push(JSON.parse(JSON.stringify(e)));
      }
    }

    function placeAnchors(s) {
      // MODEL: each kinetochore site, whether it is active, and when resection reaches it (TERMINAL)
      // Times are minutes from G1/S. Resection spreads both ways from every
      // collapsed fork; a site is lost the first time any front reaches it.
      var rate = s.alleles.exo1 ? RULE.exo1Rate : RULE.exoRate, sites = [], lost = null, all = true;
      sites.push({ name: 'CEN', site: RULE.centromere, active: true, lostAt: null });
      if (s.alleles.ak !== 'none') {
        sites.push({ name: 'AK', site: RULE.akSite, active: s.alleles.ak === 'on', lostAt: null });
      }
      sites.forEach(function (k) {
        s.collapses.forEach(function (c) {
          var d = Math.abs(c.x - k.site), at = c.t + d / rate;
          if (d <= RULE.resectReach + 1e-9 && at <= s.t + 1e-9 && (k.lostAt === null || at < k.lostAt)) { k.lostAt = at; }
        });
        if (k.active) {
          if (k.lostAt === null) { all = false; } else if (lost === null || k.lostAt > lost) { lost = k.lostAt; }
        }
      });
      return { rate: rate, reach: RULE.resectReach, sites: sites, lostAt: all ? lost : null };
    }

    function judgeOutcome(s, anchors) {
      // MODEL: how the run ends: anaphase RULE.g2 min after every stretch is
      // copied, premature extension once no kinetochore holds, or still in S at
      // the cap (TERMINAL)
      // Times are minutes from G1/S. stop is when S ends on the frames; a run
      // that reaches anaphase goes on through G2 to anaStart.
      var spans = [], reach = 0, complete = true, completeAt = 0, extStart = null, eps = 1e-6, out;
      s.forks.forEach(function (f) {
        spans.push([Math.min(f.x0, f.x), Math.max(f.x0, f.x)]);
        completeAt = Math.max(completeAt, f.path[f.path.length - 1][0]);
      });
      spans.sort(function (a, b) { return a[0] - b[0]; });
      spans.forEach(function (sp) { if (sp[0] > reach + eps) { complete = false; } reach = Math.max(reach, sp[1]); });
      if (reach < RULE.chromosomeKb - eps || !s.forks.length) { complete = false; }
      if (!s.viable) { return { outcome: 'stuck', complete: false, completeAt: null, extStart: null, stop: 0, anaStart: null }; }
      if (s.oneOrigin) {
        return { outcome: 'anaphase', complete: true, completeAt: s.t, extStart: null, stop: s.t,
          anaStart: s.t + RULE.g2 };
      }
      if (!s.hu) {
        return { outcome: 'anaphase', complete: complete, completeAt: completeAt, extStart: null, stop: completeAt,
          anaStart: completeAt + RULE.g2 };
      }
      if (anchors.lostAt !== null) { extStart = Math.max(anchors.lostAt, RULE.spindleForm + 5); }
      if (complete && (extStart === null || completeAt <= extStart)) {
        out = { outcome: 'anaphase', complete: true, completeAt: completeAt, extStart: null, stop: completeAt,
          anaStart: completeAt + RULE.g2 };
      } else if (extStart !== null && extStart < RULE.huMax) {
        out = { outcome: 'premature', complete: false, completeAt: null, extStart: extStart,
          stop: Math.min(RULE.huMax, extStart + RULE.extendShow), anaStart: null };
      } else {
        out = { outcome: 'arrested', complete: false, completeAt: null, extStart: null, stop: RULE.huMax, anaStart: null };
      }
      return out;
    }

    function buildSpindle(s, anchors, oc) {
      // MODEL: the spindle length through the run, as a path of [minutes from G1/S, um] (TERMINAL)
      // Short while an active kinetochore holds; cycles of extension and
      // breakage once none does; anaphase length once every stretch is
      // copied. The path runs past the frames' end to the latest scoring time,
      // so a strain's score does not depend on where its frames stop. Peaks
      // come from a second stream seeded from the run's seed.
      var r = (s.seed ^ 0x5BD1E995) >>> 0, z, u, t, len, peak, ramp;
      var form = RULE.spindleForm, held = form + 5, end, path = [[form, 0.8], [held, RULE.spindleShort]];
      if (oc.outcome === 'premature') {
        end = Math.max(oc.stop, RULE.scoreLate) + 1;
        t = oc.extStart;
        len = RULE.spindleShort;
        if (t > held) { path.push([t, len]); }
        while (t < end) {
          r = (r + 0x6D2B79F5) | 0;
          z = Math.imul(r ^ (r >>> 15), 1 | r);
          z = (z + Math.imul(z ^ (z >>> 7), 61 | z)) ^ z;
          u = ((z ^ (z >>> 14)) >>> 0) / 4294967296;
          peak = RULE.spindlePeak[0] + u * (RULE.spindlePeak[1] - RULE.spindlePeak[0]);
          t += (peak - len) / RULE.spindleRate;
          path.push([t, peak]);
          t += 1;
          len = RULE.spindleDrop;
          path.push([t, len]);
        }
      } else if (oc.outcome === 'anaphase') {
        // Pds1 is degraded once every stretch is copied and G2 has passed; the sisters part.
        t = Math.max(held, oc.anaStart);
        ramp = (RULE.anaphaseLen - RULE.spindleShort) / RULE.anaphaseRate;
        path.push([t, RULE.spindleShort]);
        path.push([t + ramp, RULE.anaphaseLen]);
        path.push([Math.max(t + ramp, RULE.scoreLate) + 5, RULE.anaphaseLen]);
      } else {
        path.push([Math.max(oc.stop, RULE.scoreLate) + 1, RULE.spindleShort]);
      }
      end = path[path.length - 1][0];
      return { form: form, lostAt: anchors.lostAt, path: path, end: end };
    }

    function processTelomeres(s, oc) {
      // SUB-CONTROLLER: each daughter end's steps, its telomerase decision and its new length

      var win = telomereWindow(s, oc);
      var law = recruitmentLaw();
      var ends = listDaughters(s, win);
      var plan = decideTelomerase(s, ends, win, law);
      return stepEnds(ends, plan, win);

      function telomereWindow(s, oc) {
        // MODEL: when the window for telomerase closes, and when the frames end (TERMINAL)
        // A run that reaches anaphase closes the window early enough for an
        // end recruited at the last moment to be extended, released and filled
        // in by anaphase. A run that ends in S closes nothing: its ends are
        // shown as they stand when the frames stop.
        var ana = oc.anaStart;
        return { ana: ana, stop: ana !== null ? ana : oc.stop, closes: ana !== null,
          recruitBy: ana !== null ? ana - (1 + RULE.extDur + RULE.releaseDur + RULE.fillDur) : oc.stop,
          fillAt: ana !== null ? ana - RULE.fillDur : null };
      }

      function recruitmentLaw() {
        // MODEL: kTel and s0, solved from the two Teixeira points over the reference window (TERMINAL)
        // lambda(n) = kTel exp(-n / s0) / (1 + cRif r(n)), r(n) = n * 2 / 17.1.
        // For two lengths, lambda2 / lambda1 = exp((n1 - n2) / s0) (1 + c r1) / (1 + c r2),
        // so exp((n1 - n2) / s0) = (lambda2 / lambda1) (1 + c r2) / (1 + c r1).
        var wt = RULE.telomereBp / RULE.bpPerRap1, c = RULE.cRif, W = RULE.telWindowRef;
        var p1 = RULE.teixeira[0], p2 = RULE.teixeira[1];
        var n1 = p1[0] / RULE.bpPerRap1, n2 = p2[0] / RULE.bpPerRap1;
        var r1 = n1 * RULE.rif1Captured / wt, r2 = n2 * RULE.rif1Captured / wt;
        var l1 = -Math.log(1 - p1[1]) / W, l2 = -Math.log(1 - p2[1]) / W;
        var s0 = (n1 - n2) / Math.log((l2 / l1) * (1 + c * r2) / (1 + c * r1));
        return { s0: s0, kTel: l1 * (1 + c * r1) * Math.exp(n1 / s0), wt: wt, c: c };
      }

      function listDaughters(s, win) {
        // MODEL: every daughter end in a fixed order, with its hazard and its window (TERMINAL)
        // A daughter's hazard comes from its own length. Rif1's brake goes with
        // rif1 deletion; cdc13-2 and est2 deletion recruit nothing.
        var out = [], tel, d, k, n, open, close;
        ['TEL-L', 'TEL-R'].forEach(function (tel) {
          if (!s.telo[tel].daughters) { return; }
          s.telo[tel].daughters.forEach(function (d0) {
            d = JSON.parse(JSON.stringify(d0));
            d.cdc13At = d.arriveAt + (d.strand === 'leading' ? RULE.leadToCdc13 : RULE.lagToCdc13);
            open = d.cdc13At;
            close = Math.max(open, win.recruitBy);
            d.window = [open, close];
            out.push(d);
          });
        });
        return out;
      }

      function decideTelomerase(s, ends, win, law) {
        // MODEL: which daughters telomerase reaches, when, and how many nt it adds (TERMINAL)
        // Two uniform draws per daughter in a fixed order from the run's third
        // stream: one for the recruitment clock, one for the repeats added.
        // Recruitments are served in time order by the free telomerase copies;
        // one that finds every copy busy waits for the first to come free.
        var r = (s.seed ^ 0x27D4EB2F) >>> 0, z, u, cands = [], busy = [], i, k, d, n, lam, start, mean, b, p;
        var copies = s.alleles.est2 ? 0 : RULE.telomeraseCopies, out = {};
        for (k = 0; k < copies; k += 1) { busy.push(-Infinity); }
        ends.forEach(function (d) {
          var draw = [];
          for (k = 0; k < 2; k += 1) {
            r = (r + 0x6D2B79F5) | 0;
            z = Math.imul(r ^ (r >>> 15), 1 | r);
            z = (z + Math.imul(z ^ (z >>> 7), 61 | z)) ^ z;
            draw.push(((z ^ (z >>> 14)) >>> 0) / 4294967296);
          }
          n = d.bp0 / RULE.bpPerRap1;
          lam = s.alleles.cdc13_2 || !copies ? 0
            : law.kTel * Math.exp(-n / law.s0) / (1 + (s.genotype.rif1 ? law.c * n * RULE.rif1Captured / law.wt : 0));
          b = d.bp0;
          p = [RULE.extMean[0], RULE.extMean[1]];
          mean = b >= p[0][0] ? p[0][1] : (b <= p[1][0] ? p[1][1]
            : p[1][1] + (p[0][1] - p[1][1]) * (b - p[1][0]) / (p[0][0] - p[1][0]));
          out[d.id] = { lambda: lam, pExtend: 1 - Math.exp(-lam * (d.window[1] - d.window[0])),
            extended: false, extAt: null, added: 0, mean: mean,
            why: s.alleles.cdc13_2 ? 'cdc13-2: Est1 is not recruited' : (!copies ? 'no telomerase' : null) };
          cands.push({ id: d.id, t: lam > 0 ? d.window[0] - Math.log(1 - draw[0]) / lam : Infinity,
            close: d.window[1], amount: Math.max(1, Math.round(-mean * Math.log(1 - draw[1]))) });
        });
        cands.sort(function (a, b) { return (a.t - b.t) || (a.id < b.id ? -1 : 1); });
        cands.forEach(function (c) {
          if (c.t === Infinity) { return; }
          i = busy.indexOf(Math.min.apply(null, busy));
          start = Math.max(c.t, busy[i]);
          if (start <= c.close + 1e-9) {
            busy[i] = start + 1 + RULE.extDur;
            out[c.id].extended = true;
            out[c.id].extAt = start;
            out[c.id].added = c.amount;
            out[c.id].copy = i + 1;
          }
        });
        return out;
      }

      function stepEnds(ends, plan, win) {
        // MODEL: each daughter's steps as the telomere workflow panels name them, and its length after (TERMINAL)
        // Leading-made: step01 blunt, step02 Sae2-P and MRX, step03 resection.
        // Lagging-made: lag01 overhang, lag03 resection. Both: step04 Cdc13
        // alone; then, if recruited, step05 Tel1, step06 Est2 copies, step07
        // removal; then step08 fill-in and step09 capped. A step that would run
        // past the frames' end is cut there.
        var stop = win.stop;
        return ends.map(function (d) {
          var p = plan[d.id], a = d.arriveAt, steps = [], t, add, fill;
          add = function (key, t0, t1) {
            if (t0 < stop - 1e-9) { steps.push({ key: key, t0: t0, t1: Math.min(t1, stop) }); }
          };
          if (d.strand === 'leading') {
            add('step01', a, a + 1);
            add('step02', a + 1, a + 2);
            add('step03', a + 2, d.cdc13At);
          } else {
            add('lag01', a, a + 1);
            add('lag03', a + 1, d.cdc13At);
          }
          if (p.extended) {
            t = p.extAt;
            add('step04', d.cdc13At, t);
            add('step05', t, t + 1);
            add('step06', t + 1, t + 1 + RULE.extDur);
            add('step07', t + 1 + RULE.extDur, t + 1 + RULE.extDur + RULE.releaseDur);
            fill = t + 1 + RULE.extDur + RULE.releaseDur;
          } else {
            fill = win.fillAt;
            add('step04', d.cdc13At, fill === null ? stop : fill);
          }
          if (fill !== null) {
            add('step08', fill, fill + RULE.fillDur);
            add('step09', fill + RULE.fillDur, Math.max(stop, fill + RULE.fillDur));
          }
          return { id: d.id, end: d.end, sister: d.sister, strand: d.strand, arriveAt: a, cdc13At: d.cdc13At,
            window: d.window, bp0: d.bp0, sites0: d.sites0, rif: d.rif,
            lambda: p.lambda, pExtend: p.pExtend, extended: p.extended, extAt: p.extAt, copy: p.copy || null,
            added: p.added, extMean: p.mean, why: p.why,
            decided: fill !== null || p.extended,
            capped: fill !== null && fill + RULE.fillDur <= stop + 1e-9,
            bp1: d.bp0 + p.added, sites1: Math.floor((d.bp0 + p.added) / RULE.bpPerRap1), steps: steps };
        });
      }
    }

    function assembleSchedule(s, anchors, spindle, oc, daughterEnds) {
      // MODEL: the run in the shape the frame builder reads, times into S (TERMINAL)
      var fires = s.events.filter(function (e) { return e.kind === 'fire'; });
      var onset = fires.length ? Math.min.apply(null, fires.map(function (e) { return e.t; })) : 0;
      var origins = {}, ends = [], label, telomeres = {}, tel, forks, shift, scores = {}, al = [];
      RULE.origins.forEach(function (o) {
        var f = s.fates[o.name] || { fate: s.hu ? 'unfired' : 'unreplicated', t: null,
          meter: s.marks[o.name] / RULE.theta, by: null, route: null };
        var near = null, tt;
        for (tt in RULE.telomeres) {
          if (Object.prototype.hasOwnProperty.call(RULE.telomeres, tt)
              && Math.abs(o.position - RULE.telomeres[tt]) <= RULE.telomereReach) { near = tt; }
        }
        origins[o.name] = {
          position: o.position, recruiter: o.recruiter, d: s.weight[o.name], telomere: near,
          eligibleAt: s.eligible[o.name] !== undefined ? s.eligible[o.name] - onset : null,
          fate: f.fate, time: f.t === null ? null : f.t - onset, meter: f.meter,
          copiedBy: f.by, route: f.route
        };
      });
      forks = s.forks.map(function (f) {
        var g = JSON.parse(JSON.stringify(f));
        g.t0 = f.t0 - onset;
        if (g.t1 === null) {
          // Still moving or collapsed when the window closed.
          g.t1 = s.t;
          g.x1 = f.x;
          g.end = f.status === 'collapsed' ? 'collapsed' : 'window';
        }
        g.t1 -= onset;
        g.collapsedAt = f.collapsedAt === null ? null : f.collapsedAt - onset;
        g.path = f.path.map(function (p) { return [p[0] - onset, p[1]]; });
        g.rpaPath = f.rpaPath.map(function (p) { return [p[0] - onset, p[1]]; });
        if (g.path[g.path.length - 1][0] < g.t1 - 1e-9) { g.path.push([g.t1, g.x1]); }
        ends.push(g.t1);
        delete g.E;
        delete g.H;
        delete g.restartAt;
        g.downs = f.downs.map(function (d) { return [d[0] - onset, d[1] === null ? null : d[1] - onset]; });
        return g;
      });
      shift = function (list, fields) {
        return list.map(function (item) {
          var g = JSON.parse(JSON.stringify(item));
          fields.forEach(function (k) { if (g[k] !== null && g[k] !== undefined) { g[k] -= onset; } });
          return g;
        });
      };
      for (tel in s.telomeres) {
        if (Object.prototype.hasOwnProperty.call(s.telomeres, tel)) {
          telomeres[tel] = { t: s.telomeres[tel].t - onset, fork: s.telomeres[tel].fork,
            origin: s.telomeres[tel].origin };
        }
      }
      // The ends: each parent's length and Rif1 at G1/S, and its daughters,
      // their steps and lengths, times into S.
      var telo = {};
      ['TEL-L', 'TEL-R'].forEach(function (tel) {
        var e = s.telo[tel];
        telo[tel] = { side: e.side, bp: e.bp, sites: e.sites, rif: e.rif,
          copiedAt: e.t === null ? null : e.t - onset,
          daughters: daughterEnds.filter(function (d) { return 'TEL-' + d.end === tel; }).map(function (d) {
            var g = JSON.parse(JSON.stringify(d));
            ['arriveAt', 'cdc13At', 'extAt'].forEach(function (k) { if (g[k] !== null) { g[k] -= onset; } });
            g.window = [g.window[0] - onset, g.window[1] - onset];
            g.steps.forEach(function (st) { st.t0 -= onset; st.t1 -= onset; });
            return g;
          }) };
      });
      // The spindle scored where the papers score it, by interpolating its path.
      [['at', RULE.scoreAt], ['early', RULE.scoreEarly], ['late', RULE.scoreLate]].forEach(function (w) {
        var p = spindle.path, len = 0, i;
        if (w[1] >= p[0][0]) { len = p[p.length - 1][1]; }
        for (i = 0; i + 1 < p.length; i += 1) {
          if (w[1] >= p[i][0] && w[1] <= p[i + 1][0]) {
            len = p[i + 1][0] - p[i][0] > 1e-9
              ? p[i][1] + (p[i + 1][1] - p[i][1]) * (w[1] - p[i][0]) / (p[i + 1][0] - p[i][0]) : p[i + 1][1];
            break;
          }
        }
        scores[w[0]] = { t: w[1] - onset, fromG1S: w[1], length: len, extended: len >= RULE.spindleLine };
      });
      ALLELES.forEach(function (a) { if (s.alleles[a.key]) { al.push(a.label); } });
      if (s.alleles.ak !== 'none') { al.push(s.alleles.ak === 'on' ? '4× LATE-AK + ASK1-LacI' : '4× LATE-AK + vector'); }
      label = (s.bob1 ? 'mcm5-bob1 ' : '') + s.genotype.label
        + (s.checkpoint.key !== 'wt' ? ' ' + s.checkpoint.label : '') + (al.length ? ' ' + al.join(' ') : '');
      label = label.replace(/^wild type (?=\S)/, '');
      return {
        key: s.genotype.key, label: label, bob1: s.bob1, hu: s.hu,
        checkpoint: s.checkpoint.key, checkpointLabel: s.checkpoint.label,
        alleles: JSON.parse(JSON.stringify(s.alleles)),
        arms: { rad53: s.arms.rad53, sld3: s.arms.sld3Arm, dbf4: s.arms.dbf4Arm, dun1: s.arms.dun1Arm },
        seed: s.seed, viable: s.viable, stuck: s.stuck, overflow: s.overflow,
        pools: { ddkTotal: RULE.ddkTotal, ddkActive: s.ddkActive,
          rif1Total: s.genotype.rif1 ? RULE.rif1Total : 0,
          rif1Free: s.genotype.rif1 ? Math.max(0, RULE.rif1Total - s.telo['TEL-L'].rif - s.telo['TEL-R'].rif) : 0,
          rif1Captured: s.genotype.rif1 ? Math.max(s.telo['TEL-L'].rif, s.telo['TEL-R'].rif) : 0,
          rif1Tel: { 'TEL-L': s.telo['TEL-L'].rif, 'TEL-R': s.telo['TEL-R'].rif },
          rif1FreeMax: s.segments.reduce(function (a, g) { return Math.max(a, g.rifPool); },
            s.genotype.rif1 ? Math.max(0, RULE.rif1Total - s.telo['TEL-L'].rif - s.telo['TEL-R'].rif) : 0),
          telomerase: s.alleles.est2 ? 0 : RULE.telomeraseCopies },
        rates: { kDdk: RULE.kDdk, kPp1: RULE.kPp1, theta: RULE.theta },
        onsetFromG1S: onset,
        rad53At: s.rad53At === null ? null : s.rad53At - onset,
        rad53Forks: s.rad53Forks,
        signal: { threshold: RULE.rad53Signal, rpaMax: RULE.rpaMax,
          path: s.signalPath.map(function (p) { return [p[0] - onset, p[1]]; }) },
        windowEnd: s.hu ? oc.stop - onset : null,
        outcome: oc.outcome, complete: oc.complete,
        completeAt: oc.completeAt === null ? null : oc.completeAt - onset,
        extStart: oc.extStart === null ? null : oc.extStart - onset,
        origins: origins,
        forks: forks,
        collapses: shift(s.collapses, ['t']),
        anchors: {
          rate: anchors.rate, reach: anchors.reach,
          lostAt: anchors.lostAt === null ? null : anchors.lostAt - onset,
          sites: shift(anchors.sites, ['lostAt'])
        },
        spindle: {
          form: spindle.form - onset, end: spindle.end - onset, line: RULE.spindleLine,
          path: spindle.path.map(function (p) { return [p[0] - onset, p[1]]; }),
          score: scores
        },
        terminations: shift(s.terminations, ['t']).sort(function (a, b) {
          return (Math.round(a.t * 1e6) - Math.round(b.t * 1e6)) || (a.x - b.x);
        }),
        telomeres: telomeres,
        telo: telo,
        sets: shift(s.setLog, ['out', 'back']),
        events: shift(s.events, ['t']),
        segments: shift(s.segments, ['t0', 't1']),
        sEnd: s.viable ? oc.stop - onset : null,
        g2: RULE.g2,
        one: s.oneOrigin ? JSON.parse(JSON.stringify(s.oneOrigin)) : null,
        anaphaseAt: s.viable && oc.anaStart !== null ? oc.anaStart - onset : null
      };
    }
  }

  // === SHARED FUNCTIONS ===================================================

  function splitEnd(s, tel, t) {
    // MODEL: a copied end becomes two daughter ends, and their ids (TERMINAL)
    // Sister 1 carries the leading-made left end and the lagging-made right end.
    var par = s.telo[tel], left = par.side === 'L', bp0 = Math.max(0, par.bp - RULE.telomereLoss);
    var sites0 = Math.floor(bp0 / RULE.bpPerRap1);
    var rif0 = s.genotype.rif1 ? Math.round(sites0 * RULE.rif1Captured / RULE.wtSites) : 0;
    par.t = t;
    par.daughters = [1, 2].map(function (k) {
      return { id: 'tel-' + par.side + '-s' + k, end: par.side, sister: k,
        strand: (k === 1) === left ? 'leading' : 'lagging', arriveAt: t, bp0: bp0, sites0: sites0, rif: rif0 };
    });
    return par.daughters.map(function (d) { return d.id; });
  }

  // === BASE CONTROLLER: checkSchedule =====================================

  function checkSchedule(s) {
    // MODEL: the biology and the bookkeeping every viable run must obey (TERMINAL)
    // A run in HU ends inside S, so it may leave stretches uncopied and
    // origins unfired; it must still copy nothing twice.
    var eps = 1e-6, bad = [], fired = [], spans = [], reach = 0, ends = {}, out;
    if (!s.viable) { return bad; }
    if (s.overflow) { bad.push('the run needed more than ' + RULE.maxEvents + ' events'); }
    s.events.forEach(function (e) {
      if (e.kind === 'fire') {
        if (fired.indexOf(e.origin) >= 0) { bad.push(e.origin + ' fires more than once'); }
        fired.push(e.origin);
        if (e.t < -eps) { bad.push(e.origin + ' fires before S onset'); }
        if (s.rad53At !== null && s.arms.sld3 && e.t > s.rad53At + eps) {
          bad.push(e.origin + ' fires after Rad53 blocks Sld3');
        }
      }
    });
    Object.keys(s.origins).forEach(function (n) {
      var o = s.origins[n];
      if (!s.hu && o.fate === 'unreplicated') { bad.push(n + ' is never copied'); }
      if (o.fate === 'fired' && o.route === 'marks' && o.meter < 1 - 1e-6) {
        bad.push(n + ' fired by marks below threshold');
      }
    });
    s.forks.forEach(function (f) {
      spans.push([Math.min(f.x0, f.x1), Math.max(f.x0, f.x1)]);
      ends[f.id] = f;
      if (!s.hu && f.end === 'window') { bad.push('fork ' + f.id + ' never stops'); }
      if (f.end && f.end.indexOf('collapsed') === 0 && !s.hu) {
        bad.push('fork ' + f.id + ' collapses without HU');
      }
    });
    spans.sort(function (a, b) { return a[0] - b[0]; });
    spans.forEach(function (sp) {
      if (sp[0] < reach - eps) { bad.push(sp[0].toFixed(3) + ' kb is copied twice'); }
      if (!s.hu && sp[0] > reach + eps) {
        bad.push(reach.toFixed(3) + ' to ' + sp[0].toFixed(3) + ' kb is never copied');
      }
      reach = Math.max(reach, sp[1]);
    });
    if (s.one) {
      // The one-origin chromosome: both forks leave the origin together and
      // reach their tips, and its ends are checked below like any run's.
      s.one.forks.forEach(function (f) {
        if (f.t0 !== s.one.fireAt || !(f.tJ > f.t0) || f.t1 < f.tJ - eps) { bad.push('one-origin fork ' + f.side + ' runs out of order'); }
        if (Math.abs(s.telo['TEL-' + f.side].copiedAt - f.t1) > eps) { bad.push('TEL-' + f.side + ' is copied off its fork'); }
      });
    } else if (!s.hu && Math.abs(reach - RULE.chromosomeKb) > eps) {
      bad.push('copying stops at ' + reach.toFixed(3) + ' kb');
    }
    s.terminations.forEach(function (m) {
      m.forks.forEach(function (id) {
        if (Math.abs(ends[id].x1 - m.x) > eps) { bad.push('fork ' + id + ' stops away from its meeting point'); }
      });
    });
    s.sets.forEach(function (b) {
      out = s.sets.filter(function (c) { return c.out <= b.out + eps && c.back > b.out + eps; });
      if (out.length > RULE.sets) { bad.push('more than ' + RULE.sets + ' sets out at ' + b.out.toFixed(3)); }
    });
    s.segments.forEach(function (g) {
      var ddk = 0, free = 0;
      Object.keys(g.ddk).forEach(function (n) {
        ddk += g.ddk[n];
        free += g.rifFree[n];
        if (g.marks0[n] < -eps) { bad.push(n + ' has negative marks'); }
        if (s.origins[n].time !== null && g.t0 >= s.origins[n].time - eps) {
          bad.push(n + ' holds copies after it closed');
        }
      });
      if (ddk + (g.idle.ddk || 0) + (g.idle.ddkBlocked || 0) !== s.pools.ddkActive) {
        bad.push('DDK copies lost at ' + g.t0.toFixed(3));
      }
      if (g.rad53 && s.arms.dbf4 && ddk > 0) { bad.push('DDK marks an origin while Rad53 blocks Dbf4'); }
      if (free + (g.idle.rifFree || 0) !== g.rifPool) { bad.push('free Rif1 copies lost at ' + g.t0.toFixed(3)); }
      // Every Rif1 copy is free or held by an end: none is made or lost at the boundary.
      if (s.pools.rif1Total > 0 && g.rifPool + g.rifTel['TEL-L'] + g.rifTel['TEL-R'] !== s.pools.rif1Total) {
        bad.push('Rif1 copies made or lost crossing to the telomeres at ' + g.t0.toFixed(3));
      }
      if (s.pools.rif1Total === 0 && (g.rifPool !== 0 || g.rifTel['TEL-L'] || g.rifTel['TEL-R'])) {
        bad.push('Rif1 copies in a rif1 deletion at ' + g.t0.toFixed(3));
      }
    });
    // The ends. A copied end has two daughters, one per sister, one made by
    // each strand, with sister 1 leading-made on the left and lagging-made on
    // the right; each starts RULE.telomereLoss bp short; telomerase acts only
    // inside a daughter's window, never with cdc13-2 or without Est2, and
    // never on more ends at once than there are copies.
    ['TEL-L', 'TEL-R'].forEach(function (tel) {
      var e = s.telo[tel], ds = e.daughters, ext = [];
      if (e.copiedAt === null) {
        if (ds.length) { bad.push(tel + ' has daughters but was never copied'); }
        return;
      }
      if (ds.length !== 2) { bad.push(tel + ' is copied into ' + ds.length + ' daughters'); return; }
      ds.forEach(function (d) {
        var lead = (d.sister === 1) === (e.side === 'L');
        if ((d.strand === 'leading') !== lead) { bad.push(d.id + ' is made by the wrong strand'); }
        if (d.bp0 !== Math.max(0, e.bp - RULE.telomereLoss)) { bad.push(d.id + ' does not start ' + RULE.telomereLoss + ' bp short'); }
        if (d.bp1 !== d.bp0 + d.added) { bad.push(d.id + ' length does not add up'); }
        if (d.extended) {
          if (s.alleles.cdc13_2 || s.alleles.est2) { bad.push(d.id + ' is extended without telomerase recruitment'); }
          if (d.extAt < d.window[0] - eps || d.extAt > d.window[1] + eps) { bad.push(d.id + ' is extended outside its window'); }
          if (d.added < 1) { bad.push(d.id + ' is extended by nothing'); }
          ext.push(d);
        } else if (d.added !== 0) { bad.push(d.id + ' gains length without telomerase'); }
        d.steps.forEach(function (st, k) {
          if (st.t1 < st.t0 - eps) { bad.push(d.id + ' step ' + st.key + ' ends before it starts'); }
          if (k && Math.abs(st.t0 - d.steps[k - 1].t1) > eps) { bad.push(d.id + ' has a gap before ' + st.key); }
        });
      });
    });
    var spans2 = [];
    ['TEL-L', 'TEL-R'].forEach(function (tel) {
      s.telo[tel].daughters.forEach(function (d) {
        if (d.extended) { spans2.push([d.extAt, d.extAt + 1 + RULE.extDur]); }
      });
    });
    spans2.forEach(function (a) {
      var on = spans2.filter(function (b) { return b[0] <= a[0] + eps && b[1] > a[0] + eps; }).length;
      if (on > s.pools.telomerase) { bad.push('more ends extended at once than telomerase copies at ' + a[0].toFixed(2)); }
    });
    if (s.outcome === 'anaphase' && s.anaphaseAt !== null && s.anaphaseAt < s.sEnd + RULE.g2 - eps) {
      bad.push('anaphase before G2 has passed');
    }
    // The spindle reaches the line only once every active kinetochore has
    // lost its anchor, or in anaphase once every stretch is copied.
    s.spindle.path.forEach(function (p) {
      var lost = s.anchors.lostAt !== null && p[0] >= s.anchors.lostAt - eps;
      var ana = s.outcome === 'anaphase' && p[0] >= s.sEnd - eps;
      if (p[1] >= RULE.spindleLine - eps && !lost && !ana) {
        bad.push('the spindle extends at ' + p[0].toFixed(2) + ' while a kinetochore holds and S goes on');
      }
    });
    if (s.outcome === 'anaphase' && !s.complete) { bad.push('anaphase with the chromosome partly copied'); }
    return bad;
  }

  function spindleAt(sched, t) {
    // MODEL: the spindle length at t minutes into S, 0 before it forms (TERMINAL)
    var p = sched.spindle.path, i;
    if (!p.length || t < p[0][0]) { return 0; }
    for (i = 0; i + 1 < p.length; i += 1) {
      if (t >= p[i][0] && t <= p[i + 1][0]) {
        return p[i + 1][0] - p[i][0] > 1e-9
          ? p[i][1] + (p[i + 1][1] - p[i][1]) * (t - p[i][0]) / (p[i + 1][0] - p[i][0]) : p[i + 1][1];
      }
    }
    return p[p.length - 1][1];
  }

  function medianRun(preset, n) {
    // MODEL: a preset's typical run: among n runs, the most common way a run
    // ends, and within those runs the one whose spindle at the scoring time is
    // closest to their median (TERMINAL)
    // Seeds are k times 7919 for k from 1 to n; a tie goes to the lowest k.
    var runs = [], count = {}, k, s, mode = null, group, sorted, mid, best = null, ext = 0;
    for (k = 1; k <= n; k += 1) {
      s = simulate('wt', false, k * 7919, { hu: true, checkpoint: preset.checkpoint,
        alleles: preset.alleles, ak: preset.ak });
      runs.push([k * 7919, s.spindle.score[preset.when].length, s.outcome]);
      count[s.outcome] = (count[s.outcome] || 0) + 1;
      if (s.spindle.score[preset.when].extended) { ext += 1; }
    }
    Object.keys(count).forEach(function (o) { if (mode === null || count[o] > count[mode]) { mode = o; } });
    group = runs.filter(function (r) { return r[2] === mode; });
    sorted = group.map(function (r) { return r[1]; }).sort(function (a, b) { return a - b; });
    mid = sorted[(sorted.length - 1) >> 1];
    group.forEach(function (r) {
      if (best === null || Math.abs(r[1] - mid) < Math.abs(best[1] - mid) - 1e-12) { best = r; }
    });
    return { seed: best[0], length: best[1], median: mid, share: ext / n, n: n,
      outcome: mode, outcomeShare: count[mode] / n };
  }

  function freshSeed() {
    // MODEL: a seed for a new run (TERMINAL)
    return Math.floor(Math.random() * 4294967296) >>> 0;
  }

  return { RULE: RULE, GENOTYPES: GENOTYPES, CHECKPOINTS: CHECKPOINTS, ALLELES: ALLELES,
    AK_CHOICES: AK_CHOICES, PRESETS: PRESETS, medianRun: medianRun, simulate: simulate, checkSchedule: checkSchedule, spindleAt: spindleAt,
    freshSeed: freshSeed };
}());

if (typeof window !== 'undefined') { window.CHROM_RULE = CHROM_RULE; }
if (typeof module !== 'undefined') { module.exports = CHROM_RULE; }
