/* Playback transport. Arms on an animated panel and disarms on a static one. */

// === BASE CONTROLLER: initTransport =======================================

function initTransport() {
  var bar = document.getElementById('transport');
  if (!bar) { return; }

  wireButtons(bar);
  window.onFrameChange = updateReadout;

  function wireButtons(bar) {
    // SUB-CONTROLLER: one handler per control.
    bar.querySelector('#playbtn').addEventListener('click', onPlay);
    bar.querySelector('#backbtn').addEventListener('click', onBack);
    bar.querySelector('#fwdbtn').addEventListener('click', onForward);
    bar.querySelector('#resetbtn').addEventListener('click', onReset);
    bar.querySelector('#scrub').addEventListener('input', onScrub);

    function onPlay() {
      if (bar.getAttribute('data-playing') === 'yes') {
        runAnimation('pause');
      } else {
        runAnimation('play');
      }
    }

    function onBack() { runAnimation('step', -1); }
    function onForward() { runAnimation('step', 1); }
    function onReset() { runAnimation('reset', window.CURRENT_ANIM_KEY); }
    function onScrub(ev) { runAnimation('goto', parseInt(ev.target.value, 10)); }
  }

  function updateReadout(key, frame, total, playing) {
    // VIEW: frame counter, scrub range, armed state (TERMINAL)
    window.CURRENT_ANIM_KEY = key;
    var table = (window.ANIM || {})[key];
    var scrub = bar.querySelector('#scrub');
    var count = bar.querySelector('#framecount');
    bar.classList.toggle('disarmed', !table);
    bar.setAttribute('data-playing', playing ? 'yes' : 'no');
    bar.querySelector('#playbtn').textContent = playing ? 'Pause' : 'Play';
    if (!table) {
      scrub.max = 0;
      scrub.value = 0;
      count.textContent = 'static panel';
      return;
    }
    scrub.max = String(total - 1);
    scrub.value = String(frame);
    count.textContent = table.label + ' ' + (frame + 1) + ' of ' + total;
  }
}
