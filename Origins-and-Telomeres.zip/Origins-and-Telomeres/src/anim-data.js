/* Frame tables.

   Each frame declares the complete state of every element it touches, and
   not a delta from the previous frame. Any single frame therefore renders
   correctly on its own, which matters when a frame is pulled out as a
   static figure. Frame 0 reproduces the panel markup, which is what lets
   the resting status indicator computed in Python be compared against the
   engine at frame 0.

   Nothing in the derived layer appears here.

   The frame-table syntax departs from the handbook in one place. A position
   track needs a value, a presence state and, on the strand track, a kink
   state at the same time, and the handbook's map holds one value per id.
   Frame tables here write compound strings:

       tracks: {
         "o05-s": "duplex:present:kink-fixed",
         "o08-c": "mcm2:present:gate-closed:nsd-displaced"
       }

   Each token is matched against the family it belongs to, so order inside the
   string does not matter. fx and actors are separate maps. Everything else is
   unchanged.

   A complex entry carries an NSD value for the same reason it carries a
   gate. nsd-na is the honest value for anything that is not a loaded pair:
   ORC, a lone hexamer and a CMG carry no Mcm4 NSD the model draws. The value
   is declared and not derived, and no frame names the NSD glyphs: the engine
   shows the seated, displaced or released form from the value on the track,
   so the frame that changes it is the frame the NSD swings off its seat.

   One use of the presence family here is not what the family usually means.
   From step05 onward the ARS positions read orc:fading and stay there: budding
   yeast ORC is not evicted, and no frame in any panel ever takes those
   positions to gone. What the dim carries is that the initiator has finished
   its job. It loaded the pair, the pair slid off it, and nothing downstream
   passes through it again: Yeeles et al. showed CMG assembles and forks
   establish with ORC washed away entirely. So the glyph stays where it is,
   because ORC stays where it is, and it goes quiet, because the reaction has
   left it behind. A reader who takes the dim for a departure has the wrong
   idea, and the captions from step06 on say so.

   step10 and step11 name no ARS complex track, so the dim reaches them from
   the panel markup, which tools/make_panels.py writes. The forks leave the
   frame past an ORC that does not.

   offDDK ends with the clasp stopped short of the pair. What the stop claims
   is that the Sld3 engagement at the Mcm4 site cannot form while the NSD is
   seated. An earlier table then took the clasp away, which claimed that
   Sld3-Sld7 cannot bind the unphosphorylated pair at all; Sld3 binding to
   the unphosphorylated pre-RC has been reported in solution, so the table no
   longer draws a release.

   Three wrappers carry nucleotide and gate-face events. fx-mcm2p in step07
   holds the Mcm2 marks until the clasp has seated, because in vivo Mcm2
   phosphorylation needs Sld3; it arrives in the frame Cdc45 does, since no
   measurement orders the two. fx-atpx in step09 arrives in the frame the pair
   splits, which is the ADP to ATP exchange that accompanies CMG formation.
   fx-atph in step10 arrives with melting, which is the ATP hydrolysis that
   drives further unwinding, and stays, because the helicase keeps
   hydrolysing ATP as it moves.

   The fx-kin-* wrappers are the phosphorylation arrows. Each is present on
   one frame only, the first on which its mark is no longer gone, and gone on
   every other: fx-kin-ddk-4 and fx-kin-ddk-6 with fx-phos in step06,
   fx-kin-sld2 with fx-sld2p and fx-kin-sld3 with fx-sld3p in step08. S-CDK
   stands an arrow's length off each substrate on the frame it marks it, and
   tools/make_panels.py draws each arrow from that offset, so audit_kinase()
   fails the build if an arrow moves to another frame or the offset changes
   without the generator. The Mcm2 marks in step07 take no arrow, because DDK
   has left the pair by then and the panel does not draw it. */

var ANIM = {
  "cstBOB1": {
    "fps": 1.0,
    "frames": [
      {
        "actors": {
          "actor-rad53mark": [
            0,
            0
          ],
          "actor-sld3": [
            0,
            90
          ]
        },
        "fx": {
          "fx-cst": "gone",
          "fx-dagger": "gone",
          "fx-kin-rad53": "gone",
          "fx-prop": "gone",
          "fx-rad53": "gone",
          "fx-rad53mark": "gone"
        }
      },
      {
        "actors": {
          "actor-rad53mark": [
            0,
            0
          ],
          "actor-sld3": [
            0,
            0
          ]
        },
        "fx": {
          "fx-cst": "gone",
          "fx-dagger": "gone",
          "fx-kin-rad53": "gone",
          "fx-prop": "gone",
          "fx-rad53": "gone",
          "fx-rad53mark": "gone"
        }
      },
      {
        "actors": {
          "actor-rad53mark": [
            0,
            0
          ],
          "actor-sld3": [
            0,
            0
          ]
        },
        "fx": {
          "fx-cst": "gone",
          "fx-dagger": "gone",
          "fx-kin-rad53": "gone",
          "fx-prop": "gone",
          "fx-rad53": "arriving",
          "fx-rad53mark": "gone"
        }
      },
      {
        "actors": {
          "actor-rad53mark": [
            0,
            0
          ],
          "actor-sld3": [
            0,
            0
          ]
        },
        "fx": {
          "fx-cst": "gone",
          "fx-dagger": "gone",
          "fx-kin-rad53": "present",
          "fx-prop": "gone",
          "fx-rad53": "present",
          "fx-rad53mark": "arriving"
        }
      },
      {
        "actors": {
          "actor-rad53mark": [
            0,
            0
          ],
          "actor-sld3": [
            0,
            0
          ]
        },
        "fx": {
          "fx-cst": "gone",
          "fx-dagger": "gone",
          "fx-kin-rad53": "gone",
          "fx-prop": "gone",
          "fx-rad53": "present",
          "fx-rad53mark": "present"
        }
      },
      {
        "actors": {
          "actor-rad53mark": [
            0,
            0
          ],
          "actor-sld3": [
            0,
            0
          ]
        },
        "fx": {
          "fx-cst": "arriving",
          "fx-dagger": "gone",
          "fx-kin-rad53": "gone",
          "fx-prop": "gone",
          "fx-rad53": "present",
          "fx-rad53mark": "present"
        }
      },
      {
        "actors": {
          "actor-rad53mark": [
            0,
            0
          ],
          "actor-sld3": [
            0,
            0
          ]
        },
        "fx": {
          "fx-cst": "present",
          "fx-dagger": "arriving",
          "fx-kin-rad53": "gone",
          "fx-prop": "gone",
          "fx-rad53": "present",
          "fx-rad53mark": "present"
        }
      },
      {
        "actors": {
          "actor-rad53mark": [
            0,
            0
          ],
          "actor-sld3": [
            0,
            0
          ]
        },
        "fx": {
          "fx-cst": "present",
          "fx-dagger": "present",
          "fx-kin-rad53": "gone",
          "fx-prop": "arriving",
          "fx-rad53": "present",
          "fx-rad53mark": "present"
        }
      },
      {
        "actors": {
          "actor-rad53mark": [
            0,
            0
          ],
          "actor-sld3": [
            0,
            0
          ]
        },
        "fx": {
          "fx-cst": "present",
          "fx-dagger": "present",
          "fx-kin-rad53": "gone",
          "fx-prop": "present",
          "fx-rad53": "present",
          "fx-rad53mark": "present"
        }
      },
      {
        "actors": {
          "actor-rad53mark": [
            0,
            -14
          ],
          "actor-sld3": [
            0,
            -14
          ]
        },
        "fx": {
          "fx-cst": "present",
          "fx-dagger": "present",
          "fx-kin-rad53": "gone",
          "fx-prop": "present",
          "fx-rad53": "present",
          "fx-rad53mark": "present"
        }
      },
      {
        "actors": {
          "actor-rad53mark": [
            0,
            -14
          ],
          "actor-sld3": [
            0,
            -14
          ]
        },
        "fx": {
          "fx-cst": "present",
          "fx-dagger": "present",
          "fx-kin-rad53": "gone",
          "fx-prop": "present",
          "fx-rad53": "present",
          "fx-rad53mark": "present"
        }
      }
    ],
    "label": "Conformation model without DDK"
  },
  "cstCDC7": {
    "fps": 1.0,
    "frames": [
      {
        "actors": {
          "actor-ddk": [
            60,
            -210
          ]
        },
        "fx": {
          "fx-bond": "gone",
          "fx-cst": "gone",
          "fx-kin-ddk-4": "gone",
          "fx-kin-ddk-6": "gone",
          "fx-phos": "gone",
          "fx-prop": "gone",
          "fx-rad53": "gone"
        },
        "tracks": {
          "o03-c": "orc:fading:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-fixed",
          "o04-c": "orc:fading:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-fixed",
          "o05-c": "orc:fading:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-fixed",
          "o06-c": "orc:fading:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm2:present:gate-closed:nsd-seated",
          "o08-c": "mcm2:present:gate-closed:nsd-seated",
          "o09-c": "mcm2:present:gate-closed:nsd-seated",
          "o10-c": "mcm2:present:gate-closed:nsd-seated",
          "o11-c": "mcm2:present:gate-closed:nsd-seated",
          "o12-c": "mcm2:present:gate-closed:nsd-seated"
        }
      },
      {
        "actors": {
          "actor-ddk": [
            60,
            -210
          ]
        },
        "fx": {
          "fx-bond": "gone",
          "fx-cst": "arriving",
          "fx-kin-ddk-4": "gone",
          "fx-kin-ddk-6": "gone",
          "fx-phos": "gone",
          "fx-prop": "gone",
          "fx-rad53": "gone"
        },
        "tracks": {
          "o03-c": "orc:fading:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-fixed",
          "o04-c": "orc:fading:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-fixed",
          "o05-c": "orc:fading:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-fixed",
          "o06-c": "orc:fading:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm2:present:gate-closed:nsd-seated",
          "o08-c": "mcm2:present:gate-closed:nsd-seated",
          "o09-c": "mcm2:present:gate-closed:nsd-seated",
          "o10-c": "mcm2:present:gate-closed:nsd-seated",
          "o11-c": "mcm2:present:gate-closed:nsd-seated",
          "o12-c": "mcm2:present:gate-closed:nsd-seated"
        }
      },
      {
        "actors": {
          "actor-ddk": 0
        },
        "fx": {
          "fx-bond": "gone",
          "fx-cst": "present",
          "fx-kin-ddk-4": "gone",
          "fx-kin-ddk-6": "gone",
          "fx-phos": "gone",
          "fx-prop": "gone",
          "fx-rad53": "gone"
        },
        "tracks": {
          "o03-c": "orc:fading:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-fixed",
          "o04-c": "orc:fading:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-fixed",
          "o05-c": "orc:fading:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-fixed",
          "o06-c": "orc:fading:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm2:present:gate-closed:nsd-seated",
          "o08-c": "mcm2:present:gate-closed:nsd-seated",
          "o09-c": "mcm2:present:gate-closed:nsd-seated",
          "o10-c": "mcm2:present:gate-closed:nsd-seated",
          "o11-c": "mcm2:present:gate-closed:nsd-seated",
          "o12-c": "mcm2:present:gate-closed:nsd-seated"
        }
      },
      {
        "actors": {
          "actor-ddk": -160
        },
        "fx": {
          "fx-bond": "arriving",
          "fx-cst": "present",
          "fx-kin-ddk-4": "gone",
          "fx-kin-ddk-6": "gone",
          "fx-phos": "gone",
          "fx-prop": "gone",
          "fx-rad53": "gone"
        },
        "tracks": {
          "o03-c": "orc:fading:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-fixed",
          "o04-c": "orc:fading:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-fixed",
          "o05-c": "orc:fading:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-fixed",
          "o06-c": "orc:fading:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm2:present:gate-closed:nsd-displaced",
          "o08-c": "mcm2:present:gate-closed:nsd-displaced",
          "o09-c": "mcm2:present:gate-closed:nsd-displaced",
          "o10-c": "mcm2:present:gate-closed:nsd-displaced",
          "o11-c": "mcm2:present:gate-closed:nsd-displaced",
          "o12-c": "mcm2:present:gate-closed:nsd-displaced"
        }
      },
      {
        "actors": {
          "actor-ddk": -160
        },
        "fx": {
          "fx-bond": "present",
          "fx-cst": "present",
          "fx-kin-ddk-4": "gone",
          "fx-kin-ddk-6": "gone",
          "fx-phos": "gone",
          "fx-prop": "gone",
          "fx-rad53": "arriving"
        },
        "tracks": {
          "o03-c": "orc:fading:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-fixed",
          "o04-c": "orc:fading:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-fixed",
          "o05-c": "orc:fading:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-fixed",
          "o06-c": "orc:fading:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm2:present:gate-closed:nsd-displaced",
          "o08-c": "mcm2:present:gate-closed:nsd-displaced",
          "o09-c": "mcm2:present:gate-closed:nsd-displaced",
          "o10-c": "mcm2:present:gate-closed:nsd-displaced",
          "o11-c": "mcm2:present:gate-closed:nsd-displaced",
          "o12-c": "mcm2:present:gate-closed:nsd-displaced"
        }
      },
      {
        "actors": {
          "actor-ddk": -160
        },
        "fx": {
          "fx-bond": "present",
          "fx-cst": "present",
          "fx-kin-ddk-4": "present",
          "fx-kin-ddk-6": "present",
          "fx-phos": "arriving",
          "fx-prop": "arriving",
          "fx-rad53": "present"
        },
        "tracks": {
          "o03-c": "orc:fading:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-fixed",
          "o04-c": "orc:fading:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-fixed",
          "o05-c": "orc:fading:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-fixed",
          "o06-c": "orc:fading:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm2:present:gate-closed:nsd-displaced",
          "o08-c": "mcm2:present:gate-closed:nsd-displaced",
          "o09-c": "mcm2:present:gate-closed:nsd-displaced",
          "o10-c": "mcm2:present:gate-closed:nsd-displaced",
          "o11-c": "mcm2:present:gate-closed:nsd-displaced",
          "o12-c": "mcm2:present:gate-closed:nsd-displaced"
        }
      },
      {
        "actors": {
          "actor-ddk": -160
        },
        "fx": {
          "fx-bond": "present",
          "fx-cst": "present",
          "fx-kin-ddk-4": "gone",
          "fx-kin-ddk-6": "gone",
          "fx-phos": "present",
          "fx-prop": "present",
          "fx-rad53": "present"
        },
        "tracks": {
          "o03-c": "orc:fading:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-fixed",
          "o04-c": "orc:fading:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-fixed",
          "o05-c": "orc:fading:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-fixed",
          "o06-c": "orc:fading:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm2:present:gate-closed:nsd-displaced",
          "o08-c": "mcm2:present:gate-closed:nsd-displaced",
          "o09-c": "mcm2:present:gate-closed:nsd-displaced",
          "o10-c": "mcm2:present:gate-closed:nsd-displaced",
          "o11-c": "mcm2:present:gate-closed:nsd-displaced",
          "o12-c": "mcm2:present:gate-closed:nsd-displaced"
        }
      }
    ],
    "label": "Cdc7-retention model"
  },
  "cstCONF": {
    "fps": 1.0,
    "frames": [
      {
        "actors": {
          "actor-ddk": [
            60,
            -210
          ]
        },
        "fx": {
          "fx-cst": "gone",
          "fx-kin-ddk-4": "gone",
          "fx-kin-ddk-6": "gone",
          "fx-phos": "gone",
          "fx-prop": "gone"
        },
        "tracks": {
          "o03-c": "orc:fading:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-fixed",
          "o04-c": "orc:fading:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-fixed",
          "o05-c": "orc:fading:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-fixed",
          "o06-c": "orc:fading:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm2:present:gate-closed:nsd-seated",
          "o08-c": "mcm2:present:gate-closed:nsd-seated",
          "o09-c": "mcm2:present:gate-closed:nsd-seated",
          "o10-c": "mcm2:present:gate-closed:nsd-seated",
          "o11-c": "mcm2:present:gate-closed:nsd-seated",
          "o12-c": "mcm2:present:gate-closed:nsd-seated"
        }
      },
      {
        "actors": {
          "actor-ddk": [
            60,
            -210
          ]
        },
        "fx": {
          "fx-cst": "arriving",
          "fx-kin-ddk-4": "gone",
          "fx-kin-ddk-6": "gone",
          "fx-phos": "gone",
          "fx-prop": "gone"
        },
        "tracks": {
          "o03-c": "orc:fading:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-fixed",
          "o04-c": "orc:fading:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-fixed",
          "o05-c": "orc:fading:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-fixed",
          "o06-c": "orc:fading:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm2:present:gate-closed:nsd-seated",
          "o08-c": "mcm2:present:gate-closed:nsd-seated",
          "o09-c": "mcm2:present:gate-closed:nsd-seated",
          "o10-c": "mcm2:present:gate-closed:nsd-seated",
          "o11-c": "mcm2:present:gate-closed:nsd-seated",
          "o12-c": "mcm2:present:gate-closed:nsd-seated"
        }
      },
      {
        "actors": {
          "actor-ddk": [
            60,
            -210
          ]
        },
        "fx": {
          "fx-cst": "present",
          "fx-kin-ddk-4": "gone",
          "fx-kin-ddk-6": "gone",
          "fx-phos": "gone",
          "fx-prop": "arriving"
        },
        "tracks": {
          "o03-c": "orc:fading:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-fixed",
          "o04-c": "orc:fading:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-fixed",
          "o05-c": "orc:fading:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-fixed",
          "o06-c": "orc:fading:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm2:present:gate-closed:nsd-seated",
          "o08-c": "mcm2:present:gate-closed:nsd-seated",
          "o09-c": "mcm2:present:gate-closed:nsd-seated",
          "o10-c": "mcm2:present:gate-closed:nsd-seated",
          "o11-c": "mcm2:present:gate-closed:nsd-seated",
          "o12-c": "mcm2:present:gate-closed:nsd-seated"
        }
      },
      {
        "actors": {
          "actor-ddk": 0
        },
        "fx": {
          "fx-cst": "present",
          "fx-kin-ddk-4": "gone",
          "fx-kin-ddk-6": "gone",
          "fx-phos": "gone",
          "fx-prop": "present"
        },
        "tracks": {
          "o03-c": "orc:fading:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-fixed",
          "o04-c": "orc:fading:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-fixed",
          "o05-c": "orc:fading:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-fixed",
          "o06-c": "orc:fading:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm2:present:gate-closed:nsd-seated",
          "o08-c": "mcm2:present:gate-closed:nsd-seated",
          "o09-c": "mcm2:present:gate-closed:nsd-seated",
          "o10-c": "mcm2:present:gate-closed:nsd-seated",
          "o11-c": "mcm2:present:gate-closed:nsd-seated",
          "o12-c": "mcm2:present:gate-closed:nsd-seated"
        }
      },
      {
        "actors": {
          "actor-ddk": -160
        },
        "fx": {
          "fx-cst": "present",
          "fx-kin-ddk-4": "gone",
          "fx-kin-ddk-6": "gone",
          "fx-phos": "gone",
          "fx-prop": "present"
        },
        "tracks": {
          "o03-c": "orc:fading:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-fixed",
          "o04-c": "orc:fading:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-fixed",
          "o05-c": "orc:fading:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-fixed",
          "o06-c": "orc:fading:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm2:present:gate-closed:nsd-displaced",
          "o08-c": "mcm2:present:gate-closed:nsd-displaced",
          "o09-c": "mcm2:present:gate-closed:nsd-displaced",
          "o10-c": "mcm2:present:gate-closed:nsd-displaced",
          "o11-c": "mcm2:present:gate-closed:nsd-displaced",
          "o12-c": "mcm2:present:gate-closed:nsd-displaced"
        }
      },
      {
        "actors": {
          "actor-ddk": -160
        },
        "fx": {
          "fx-cst": "present",
          "fx-kin-ddk-4": "present",
          "fx-kin-ddk-6": "present",
          "fx-phos": "arriving",
          "fx-prop": "present"
        },
        "tracks": {
          "o03-c": "orc:fading:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-fixed",
          "o04-c": "orc:fading:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-fixed",
          "o05-c": "orc:fading:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-fixed",
          "o06-c": "orc:fading:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm2:present:gate-closed:nsd-displaced",
          "o08-c": "mcm2:present:gate-closed:nsd-displaced",
          "o09-c": "mcm2:present:gate-closed:nsd-displaced",
          "o10-c": "mcm2:present:gate-closed:nsd-displaced",
          "o11-c": "mcm2:present:gate-closed:nsd-displaced",
          "o12-c": "mcm2:present:gate-closed:nsd-displaced"
        }
      },
      {
        "actors": {
          "actor-ddk": -160
        },
        "fx": {
          "fx-cst": "present",
          "fx-kin-ddk-4": "gone",
          "fx-kin-ddk-6": "gone",
          "fx-phos": "present",
          "fx-prop": "present"
        },
        "tracks": {
          "o03-c": "orc:fading:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-fixed",
          "o04-c": "orc:fading:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-fixed",
          "o05-c": "orc:fading:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-fixed",
          "o06-c": "orc:fading:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm2:present:gate-closed:nsd-displaced",
          "o08-c": "mcm2:present:gate-closed:nsd-displaced",
          "o09-c": "mcm2:present:gate-closed:nsd-displaced",
          "o10-c": "mcm2:present:gate-closed:nsd-displaced",
          "o11-c": "mcm2:present:gate-closed:nsd-displaced",
          "o12-c": "mcm2:present:gate-closed:nsd-displaced"
        }
      }
    ],
    "label": "Mcm2-7 conformation model"
  },
  "cstEJPR": {
    "fps": 1.2,
    "frames": [
      {
        "actors": {
          "actor-cst": [
            0.0,
            0.0
          ]
        },
        "fx": {
          "fx-atph": "gone",
          "fx-cst": "gone",
          "fx-mcm10": "gone"
        },
        "tracks": {
          "o03-s": "duplex:present:kink-fixed",
          "o04-s": "duplex:present:kink-fixed",
          "o05-s": "duplex:present:kink-fixed",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "cmg:present:gate-sealed:nsd-na",
          "o08-c": "cmg:present:gate-sealed:nsd-na",
          "o09-c": "cmg:present:gate-sealed:nsd-na",
          "o10-c": "cmg:present:gate-sealed:nsd-na",
          "o11-c": "cmg:present:gate-sealed:nsd-na",
          "o12-c": "cmg:present:gate-sealed:nsd-na"
        }
      },
      {
        "actors": {
          "actor-cst": [
            0.0,
            0.0
          ]
        },
        "fx": {
          "fx-atph": "gone",
          "fx-cst": "gone",
          "fx-mcm10": "arriving"
        },
        "tracks": {
          "o03-s": "duplex:present:kink-fixed",
          "o04-s": "duplex:present:kink-fixed",
          "o05-s": "duplex:present:kink-fixed",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "cmg:present:gate-sealed:nsd-na",
          "o08-c": "cmg:present:gate-sealed:nsd-na",
          "o09-c": "cmg:present:gate-sealed:nsd-na",
          "o10-c": "cmg:present:gate-sealed:nsd-na",
          "o11-c": "cmg:present:gate-sealed:nsd-na",
          "o12-c": "cmg:present:gate-sealed:nsd-na"
        }
      },
      {
        "actors": {
          "actor-cst": [
            0.0,
            0.0
          ]
        },
        "fx": {
          "fx-atph": "arriving",
          "fx-cst": "gone",
          "fx-mcm10": "present"
        },
        "tracks": {
          "o03-s": "duplex:present:kink-fixed",
          "o04-s": "duplex:present:kink-fixed",
          "o05-s": "duplex:present:kink-fixed",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "cmg:present:gate-sealed:nsd-na",
          "o08-c": "cmg:present:gate-sealed:nsd-na",
          "o09-c": "cmg:present:gate-sealed:nsd-na",
          "o09-s": "melted:present",
          "o10-c": "cmg:present:gate-sealed:nsd-na",
          "o10-s": "melted:present",
          "o11-c": "cmg:present:gate-sealed:nsd-na",
          "o12-c": "cmg:present:gate-sealed:nsd-na"
        }
      },
      {
        "actors": {
          "actor-cst": [
            0.0,
            0.0
          ]
        },
        "fx": {
          "fx-atph": "present",
          "fx-cst": "gone",
          "fx-mcm10": "present"
        },
        "tracks": {
          "o03-s": "duplex:present:kink-fixed",
          "o04-s": "duplex:present:kink-fixed",
          "o05-s": "duplex:present:kink-fixed",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "cmg:present:gate-sealed:nsd-na",
          "o08-c": "cmg:present:gate-sealed:nsd-na",
          "o08-s": "melted:present",
          "o09-c": "cmg:present:gate-sealed:nsd-na",
          "o09-s": "melted:present",
          "o10-c": "cmg:present:gate-sealed:nsd-na",
          "o10-s": "melted:present",
          "o11-c": "cmg:present:gate-sealed:nsd-na",
          "o11-s": "melted:present",
          "o12-c": "cmg:present:gate-sealed:nsd-na"
        }
      },
      {
        "actors": {
          "actor-cst": [
            0.0,
            0.0
          ]
        },
        "fx": {
          "fx-atph": "present",
          "fx-cst": "arriving",
          "fx-mcm10": "present"
        },
        "tracks": {
          "o03-s": "duplex:present:kink-fixed",
          "o04-s": "duplex:present:kink-fixed",
          "o05-s": "duplex:present:kink-fixed",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "cmg:present:gate-sealed:nsd-na",
          "o07-s": "melted:present",
          "o08-c": "cmg:present:gate-sealed:nsd-na",
          "o08-s": "melted:present",
          "o09-c": "cmg:present:gate-sealed:nsd-na",
          "o09-s": "melted:present",
          "o10-c": "cmg:present:gate-sealed:nsd-na",
          "o10-s": "melted:present",
          "o11-c": "cmg:present:gate-sealed:nsd-na",
          "o11-s": "melted:present",
          "o12-c": "cmg:present:gate-sealed:nsd-na",
          "o12-s": "melted:present"
        }
      },
      {
        "actors": {
          "actor-cst": [
            0.0,
            0.0
          ]
        },
        "fx": {
          "fx-atph": "present",
          "fx-cst": "present",
          "fx-mcm10": "present"
        },
        "tracks": {
          "o03-s": "duplex:present:kink-fixed",
          "o04-s": "duplex:present:kink-fixed",
          "o05-s": "duplex:present:kink-fixed",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "cmg:present:gate-sealed:nsd-na",
          "o07-s": "melted:present",
          "o08-c": "cmg:present:gate-sealed:nsd-na",
          "o08-s": "melted:present",
          "o09-c": "cmg:present:gate-sealed:nsd-na",
          "o09-s": "melted:present",
          "o10-c": "cmg:present:gate-sealed:nsd-na",
          "o10-s": "melted:present",
          "o11-c": "cmg:present:gate-sealed:nsd-na",
          "o11-s": "melted:present",
          "o12-c": "cmg:present:gate-sealed:nsd-na",
          "o12-s": "melted:present"
        }
      },
      {
        "actors": {
          "actor-cst": [
            -24.0,
            0.0
          ]
        },
        "fx": {
          "fx-atph": "present",
          "fx-cst": "fading",
          "fx-mcm10": "fading"
        },
        "tracks": {
          "o03-s": "duplex:present:kink-fixed",
          "o04-s": "duplex:present:kink-fixed",
          "o05-s": "duplex:present:kink-fixed",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "cmg:present:gate-sealed:nsd-na",
          "o07-s": "extruded:present",
          "o08-c": "cmg:present:gate-sealed:nsd-na",
          "o08-s": "extruded:present",
          "o09-c": "cmg:present:gate-sealed:nsd-na",
          "o09-s": "extruded:present",
          "o10-c": "cmg:present:gate-sealed:nsd-na",
          "o10-s": "extruded:present",
          "o11-c": "cmg:present:gate-sealed:nsd-na",
          "o11-s": "extruded:present",
          "o12-c": "cmg:present:gate-sealed:nsd-na",
          "o12-s": "extruded:present"
        }
      },
      {
        "actors": {
          "actor-cst": [
            -24.0,
            0.0
          ]
        },
        "fx": {
          "fx-atph": "present",
          "fx-cst": "gone",
          "fx-mcm10": "gone"
        },
        "tracks": {
          "o03-s": "duplex:present:kink-fixed",
          "o04-s": "duplex:present:kink-fixed",
          "o05-s": "duplex:present:kink-fixed",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "cmg:present:gate-sealed:nsd-na",
          "o07-s": "extruded:present",
          "o08-c": "cmg:present:gate-sealed:nsd-na",
          "o08-s": "extruded:present",
          "o09-c": "cmg:present:gate-sealed:nsd-na",
          "o09-s": "extruded:present",
          "o10-c": "cmg:present:gate-sealed:nsd-na",
          "o10-s": "extruded:present",
          "o11-c": "cmg:present:gate-sealed:nsd-na",
          "o11-s": "extruded:present",
          "o12-c": "cmg:present:gate-sealed:nsd-na",
          "o12-s": "extruded:present"
        }
      }
    ],
    "label": "Ejection, Stn1 C half"
  },
  "cstEJSS": {
    "fps": 1.2,
    "frames": [
      {
        "actors": {
          "actor-cst": [
            0.0,
            0.0
          ]
        },
        "fx": {
          "fx-atph": "gone",
          "fx-cst": "gone",
          "fx-eject-melt": "gone",
          "fx-eject-open": "gone",
          "fx-mcm10": "gone"
        },
        "tracks": {
          "o03-s": "duplex:present:kink-fixed",
          "o04-s": "duplex:present:kink-fixed",
          "o05-s": "duplex:present:kink-fixed",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "cmg:present:gate-sealed:nsd-na",
          "o08-c": "cmg:present:gate-sealed:nsd-na",
          "o09-c": "cmg:present:gate-sealed:nsd-na",
          "o10-c": "cmg:present:gate-sealed:nsd-na",
          "o11-c": "cmg:present:gate-sealed:nsd-na",
          "o12-c": "cmg:present:gate-sealed:nsd-na"
        }
      },
      {
        "actors": {
          "actor-cst": [
            0.0,
            0.0
          ]
        },
        "fx": {
          "fx-atph": "gone",
          "fx-cst": "gone",
          "fx-eject-melt": "gone",
          "fx-eject-open": "gone",
          "fx-mcm10": "arriving"
        },
        "tracks": {
          "o03-s": "duplex:present:kink-fixed",
          "o04-s": "duplex:present:kink-fixed",
          "o05-s": "duplex:present:kink-fixed",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "cmg:present:gate-sealed:nsd-na",
          "o08-c": "cmg:present:gate-sealed:nsd-na",
          "o09-c": "cmg:present:gate-sealed:nsd-na",
          "o10-c": "cmg:present:gate-sealed:nsd-na",
          "o11-c": "cmg:present:gate-sealed:nsd-na",
          "o12-c": "cmg:present:gate-sealed:nsd-na"
        }
      },
      {
        "actors": {
          "actor-cst": [
            0.0,
            0.0
          ]
        },
        "fx": {
          "fx-atph": "arriving",
          "fx-cst": "gone",
          "fx-eject-melt": "gone",
          "fx-eject-open": "gone",
          "fx-mcm10": "present"
        },
        "tracks": {
          "o03-s": "duplex:present:kink-fixed",
          "o04-s": "duplex:present:kink-fixed",
          "o05-s": "duplex:present:kink-fixed",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "cmg:present:gate-sealed:nsd-na",
          "o08-c": "cmg:present:gate-sealed:nsd-na",
          "o09-c": "cmg:present:gate-sealed:nsd-na",
          "o09-s": "melted:present",
          "o10-c": "cmg:present:gate-sealed:nsd-na",
          "o10-s": "melted:present",
          "o11-c": "cmg:present:gate-sealed:nsd-na",
          "o12-c": "cmg:present:gate-sealed:nsd-na"
        }
      },
      {
        "actors": {
          "actor-cst": [
            0.0,
            0.0
          ]
        },
        "fx": {
          "fx-atph": "present",
          "fx-cst": "gone",
          "fx-eject-melt": "gone",
          "fx-eject-open": "gone",
          "fx-mcm10": "present"
        },
        "tracks": {
          "o03-s": "duplex:present:kink-fixed",
          "o04-s": "duplex:present:kink-fixed",
          "o05-s": "duplex:present:kink-fixed",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "cmg:present:gate-sealed:nsd-na",
          "o08-c": "cmg:present:gate-sealed:nsd-na",
          "o08-s": "melted:present",
          "o09-c": "cmg:present:gate-sealed:nsd-na",
          "o09-s": "melted:present",
          "o10-c": "cmg:present:gate-sealed:nsd-na",
          "o10-s": "melted:present",
          "o11-c": "cmg:present:gate-sealed:nsd-na",
          "o11-s": "melted:present",
          "o12-c": "cmg:present:gate-sealed:nsd-na"
        }
      },
      {
        "actors": {
          "actor-cst": [
            0.0,
            0.0
          ]
        },
        "fx": {
          "fx-atph": "present",
          "fx-cst": "arriving",
          "fx-eject-melt": "arriving",
          "fx-eject-open": "gone",
          "fx-mcm10": "present"
        },
        "tracks": {
          "o03-s": "duplex:present:kink-fixed",
          "o04-s": "duplex:present:kink-fixed",
          "o05-s": "duplex:present:kink-fixed",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "cmg:present:gate-sealed:nsd-na",
          "o07-s": "melted:present",
          "o08-c": "cmg:present:gate-sealed:nsd-na",
          "o08-s": "melted:present",
          "o09-c": "cmg:present:gate-sealed:nsd-na",
          "o09-s": "melted:present",
          "o10-c": "cmg:present:gate-sealed:nsd-na",
          "o10-s": "melted:present",
          "o11-c": "cmg:present:gate-sealed:nsd-na",
          "o11-s": "melted:present",
          "o12-c": "cmg:present:gate-sealed:nsd-na",
          "o12-s": "melted:present"
        }
      },
      {
        "actors": {
          "actor-cst": [
            0.0,
            0.0
          ]
        },
        "fx": {
          "fx-atph": "present",
          "fx-cst": "present",
          "fx-eject-melt": "present",
          "fx-eject-open": "gone",
          "fx-mcm10": "present"
        },
        "tracks": {
          "o03-s": "duplex:present:kink-fixed",
          "o04-s": "duplex:present:kink-fixed",
          "o05-s": "duplex:present:kink-fixed",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "cmg:present:gate-sealed:nsd-na",
          "o07-s": "melted:present",
          "o08-c": "cmg:present:gate-sealed:nsd-na",
          "o08-s": "melted:present",
          "o09-c": "cmg:present:gate-sealed:nsd-na",
          "o09-s": "melted:present",
          "o10-c": "cmg:present:gate-sealed:nsd-na",
          "o10-s": "melted:present",
          "o11-c": "cmg:present:gate-sealed:nsd-na",
          "o11-s": "melted:present",
          "o12-c": "cmg:present:gate-sealed:nsd-na",
          "o12-s": "melted:present"
        }
      },
      {
        "actors": {
          "actor-cst": [
            -24.0,
            0.0
          ]
        },
        "fx": {
          "fx-atph": "present",
          "fx-cst": "fading",
          "fx-eject-melt": "gone",
          "fx-eject-open": "present",
          "fx-mcm10": "fading"
        },
        "tracks": {
          "o03-s": "duplex:present:kink-fixed",
          "o04-s": "duplex:present:kink-fixed",
          "o05-s": "duplex:present:kink-fixed",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "cmg:present:gate-sealed:nsd-na",
          "o07-s": "extruded:present",
          "o08-c": "cmg:present:gate-sealed:nsd-na",
          "o08-s": "extruded:present",
          "o09-c": "cmg:present:gate-sealed:nsd-na",
          "o09-s": "extruded:present",
          "o10-c": "cmg:present:gate-sealed:nsd-na",
          "o10-s": "extruded:present",
          "o11-c": "cmg:present:gate-sealed:nsd-na",
          "o11-s": "extruded:present",
          "o12-c": "cmg:present:gate-sealed:nsd-na",
          "o12-s": "extruded:present"
        }
      },
      {
        "actors": {
          "actor-cst": [
            -24.0,
            0.0
          ]
        },
        "fx": {
          "fx-atph": "present",
          "fx-cst": "gone",
          "fx-eject-melt": "gone",
          "fx-eject-open": "present",
          "fx-mcm10": "gone"
        },
        "tracks": {
          "o03-s": "duplex:present:kink-fixed",
          "o04-s": "duplex:present:kink-fixed",
          "o05-s": "duplex:present:kink-fixed",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "cmg:present:gate-sealed:nsd-na",
          "o07-s": "extruded:present",
          "o08-c": "cmg:present:gate-sealed:nsd-na",
          "o08-s": "extruded:present",
          "o09-c": "cmg:present:gate-sealed:nsd-na",
          "o09-s": "extruded:present",
          "o10-c": "cmg:present:gate-sealed:nsd-na",
          "o10-s": "extruded:present",
          "o11-c": "cmg:present:gate-sealed:nsd-na",
          "o11-s": "extruded:present",
          "o12-c": "cmg:present:gate-sealed:nsd-na",
          "o12-s": "extruded:present"
        }
      }
    ],
    "label": "Ejection, Stn1 N fold"
  },
  "cstPOLA": {
    "fps": 1.0,
    "frames": [
      {
        "actors": {
          "actor-polain-l": [
            0,
            260
          ],
          "actor-polain-r": [
            0,
            -260
          ]
        },
        "fx": {
          "fx-cst": "gone",
          "fx-cstc": "gone",
          "fx-prop": "gone"
        }
      },
      {
        "actors": {
          "actor-polain-l": [
            0,
            0
          ],
          "actor-polain-r": [
            0,
            0
          ]
        },
        "fx": {
          "fx-cst": "gone",
          "fx-cstc": "gone",
          "fx-prop": "gone"
        }
      },
      {
        "actors": {
          "actor-polain-l": [
            0,
            0
          ],
          "actor-polain-r": [
            0,
            0
          ]
        },
        "fx": {
          "fx-cst": "arriving",
          "fx-cstc": "gone",
          "fx-prop": "gone"
        }
      },
      {
        "actors": {
          "actor-polain-l": [
            0,
            0
          ],
          "actor-polain-r": [
            0,
            0
          ]
        },
        "fx": {
          "fx-cst": "present",
          "fx-cstc": "arriving",
          "fx-prop": "gone"
        }
      },
      {
        "actors": {
          "actor-polain-l": [
            0,
            0
          ],
          "actor-polain-r": [
            0,
            0
          ]
        },
        "fx": {
          "fx-cst": "present",
          "fx-cstc": "present",
          "fx-prop": "arriving"
        }
      },
      {
        "actors": {
          "actor-polain-l": [
            0,
            0
          ],
          "actor-polain-r": [
            0,
            0
          ]
        },
        "fx": {
          "fx-cst": "present",
          "fx-cstc": "present",
          "fx-prop": "present"
        }
      }
    ],
    "label": "Stn1 and Pol alpha"
  },
  "cstRIF1": {
    "fps": 1.0,
    "frames": [
      {
        "actors": {
          "actor-ddk": [
            60,
            -210
          ]
        },
        "fx": {
          "fx-cst": "gone",
          "fx-kin-ddk-4": "gone",
          "fx-kin-ddk-6": "gone",
          "fx-phos": "gone",
          "fx-prop": "gone",
          "fx-rif1": "gone"
        },
        "tracks": {
          "o03-c": "orc:fading:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-fixed",
          "o04-c": "orc:fading:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-fixed",
          "o05-c": "orc:fading:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-fixed",
          "o06-c": "orc:fading:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm2:present:gate-closed:nsd-seated",
          "o08-c": "mcm2:present:gate-closed:nsd-seated",
          "o09-c": "mcm2:present:gate-closed:nsd-seated",
          "o10-c": "mcm2:present:gate-closed:nsd-seated",
          "o11-c": "mcm2:present:gate-closed:nsd-seated",
          "o12-c": "mcm2:present:gate-closed:nsd-seated"
        }
      },
      {
        "actors": {
          "actor-ddk": 0
        },
        "fx": {
          "fx-cst": "gone",
          "fx-kin-ddk-4": "gone",
          "fx-kin-ddk-6": "gone",
          "fx-phos": "gone",
          "fx-prop": "gone",
          "fx-rif1": "gone"
        },
        "tracks": {
          "o03-c": "orc:fading:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-fixed",
          "o04-c": "orc:fading:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-fixed",
          "o05-c": "orc:fading:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-fixed",
          "o06-c": "orc:fading:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm2:present:gate-closed:nsd-seated",
          "o08-c": "mcm2:present:gate-closed:nsd-seated",
          "o09-c": "mcm2:present:gate-closed:nsd-seated",
          "o10-c": "mcm2:present:gate-closed:nsd-seated",
          "o11-c": "mcm2:present:gate-closed:nsd-seated",
          "o12-c": "mcm2:present:gate-closed:nsd-seated"
        }
      },
      {
        "actors": {
          "actor-ddk": -160
        },
        "fx": {
          "fx-cst": "gone",
          "fx-kin-ddk-4": "gone",
          "fx-kin-ddk-6": "gone",
          "fx-phos": "gone",
          "fx-prop": "gone",
          "fx-rif1": "gone"
        },
        "tracks": {
          "o03-c": "orc:fading:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-fixed",
          "o04-c": "orc:fading:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-fixed",
          "o05-c": "orc:fading:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-fixed",
          "o06-c": "orc:fading:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm2:present:gate-closed:nsd-displaced",
          "o08-c": "mcm2:present:gate-closed:nsd-displaced",
          "o09-c": "mcm2:present:gate-closed:nsd-displaced",
          "o10-c": "mcm2:present:gate-closed:nsd-displaced",
          "o11-c": "mcm2:present:gate-closed:nsd-displaced",
          "o12-c": "mcm2:present:gate-closed:nsd-displaced"
        }
      },
      {
        "actors": {
          "actor-ddk": -160
        },
        "fx": {
          "fx-cst": "gone",
          "fx-kin-ddk-4": "present",
          "fx-kin-ddk-6": "present",
          "fx-phos": "arriving",
          "fx-prop": "gone",
          "fx-rif1": "gone"
        },
        "tracks": {
          "o03-c": "orc:fading:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-fixed",
          "o04-c": "orc:fading:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-fixed",
          "o05-c": "orc:fading:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-fixed",
          "o06-c": "orc:fading:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm2:present:gate-closed:nsd-displaced",
          "o08-c": "mcm2:present:gate-closed:nsd-displaced",
          "o09-c": "mcm2:present:gate-closed:nsd-displaced",
          "o10-c": "mcm2:present:gate-closed:nsd-displaced",
          "o11-c": "mcm2:present:gate-closed:nsd-displaced",
          "o12-c": "mcm2:present:gate-closed:nsd-displaced"
        }
      },
      {
        "actors": {
          "actor-ddk": [
            -20,
            -200
          ]
        },
        "fx": {
          "fx-cst": "gone",
          "fx-kin-ddk-4": "gone",
          "fx-kin-ddk-6": "gone",
          "fx-phos": "present",
          "fx-prop": "gone",
          "fx-rif1": "arriving"
        },
        "tracks": {
          "o03-c": "orc:fading:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-fixed",
          "o04-c": "orc:fading:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-fixed",
          "o05-c": "orc:fading:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-fixed",
          "o06-c": "orc:fading:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm2:present:gate-closed:nsd-displaced",
          "o08-c": "mcm2:present:gate-closed:nsd-displaced",
          "o09-c": "mcm2:present:gate-closed:nsd-displaced",
          "o10-c": "mcm2:present:gate-closed:nsd-displaced",
          "o11-c": "mcm2:present:gate-closed:nsd-displaced",
          "o12-c": "mcm2:present:gate-closed:nsd-displaced"
        }
      },
      {
        "actors": {
          "actor-ddk": [
            -20,
            -200
          ]
        },
        "fx": {
          "fx-cst": "gone",
          "fx-kin-ddk-4": "gone",
          "fx-kin-ddk-6": "gone",
          "fx-phos": "present",
          "fx-prop": "gone",
          "fx-rif1": "present"
        },
        "tracks": {
          "o03-c": "orc:fading:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-fixed",
          "o04-c": "orc:fading:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-fixed",
          "o05-c": "orc:fading:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-fixed",
          "o06-c": "orc:fading:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm2:present:gate-closed:nsd-displaced",
          "o08-c": "mcm2:present:gate-closed:nsd-displaced",
          "o09-c": "mcm2:present:gate-closed:nsd-displaced",
          "o10-c": "mcm2:present:gate-closed:nsd-displaced",
          "o11-c": "mcm2:present:gate-closed:nsd-displaced",
          "o12-c": "mcm2:present:gate-closed:nsd-displaced"
        }
      },
      {
        "actors": {
          "actor-ddk": [
            -20,
            -200
          ]
        },
        "fx": {
          "fx-cst": "arriving",
          "fx-kin-ddk-4": "gone",
          "fx-kin-ddk-6": "gone",
          "fx-phos": "present",
          "fx-prop": "gone",
          "fx-rif1": "present"
        },
        "tracks": {
          "o03-c": "orc:fading:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-fixed",
          "o04-c": "orc:fading:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-fixed",
          "o05-c": "orc:fading:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-fixed",
          "o06-c": "orc:fading:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm2:present:gate-closed:nsd-displaced",
          "o08-c": "mcm2:present:gate-closed:nsd-displaced",
          "o09-c": "mcm2:present:gate-closed:nsd-displaced",
          "o10-c": "mcm2:present:gate-closed:nsd-displaced",
          "o11-c": "mcm2:present:gate-closed:nsd-displaced",
          "o12-c": "mcm2:present:gate-closed:nsd-displaced"
        }
      },
      {
        "actors": {
          "actor-ddk": [
            -20,
            -200
          ]
        },
        "fx": {
          "fx-cst": "present",
          "fx-kin-ddk-4": "gone",
          "fx-kin-ddk-6": "gone",
          "fx-phos": "present",
          "fx-prop": "arriving",
          "fx-rif1": "present"
        },
        "tracks": {
          "o03-c": "orc:fading:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-fixed",
          "o04-c": "orc:fading:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-fixed",
          "o05-c": "orc:fading:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-fixed",
          "o06-c": "orc:fading:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm2:present:gate-closed:nsd-displaced",
          "o08-c": "mcm2:present:gate-closed:nsd-displaced",
          "o09-c": "mcm2:present:gate-closed:nsd-displaced",
          "o10-c": "mcm2:present:gate-closed:nsd-displaced",
          "o11-c": "mcm2:present:gate-closed:nsd-displaced",
          "o12-c": "mcm2:present:gate-closed:nsd-displaced"
        }
      },
      {
        "actors": {
          "actor-ddk": [
            -20,
            -200
          ]
        },
        "fx": {
          "fx-cst": "present",
          "fx-kin-ddk-4": "gone",
          "fx-kin-ddk-6": "gone",
          "fx-phos": "present",
          "fx-prop": "present",
          "fx-rif1": "fading"
        },
        "tracks": {
          "o03-c": "orc:fading:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-fixed",
          "o04-c": "orc:fading:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-fixed",
          "o05-c": "orc:fading:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-fixed",
          "o06-c": "orc:fading:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm2:present:gate-closed:nsd-displaced",
          "o08-c": "mcm2:present:gate-closed:nsd-displaced",
          "o09-c": "mcm2:present:gate-closed:nsd-displaced",
          "o10-c": "mcm2:present:gate-closed:nsd-displaced",
          "o11-c": "mcm2:present:gate-closed:nsd-displaced",
          "o12-c": "mcm2:present:gate-closed:nsd-displaced"
        }
      }
    ],
    "label": "Rif1-PP1 inhibition model"
  },
  "offATP": {
    "fps": 1.2,
    "frames": [
      {
        "actors": {
          "actor-cdt1mcm": 0
        },
        "fx": {
          "fx-cond-restrict": "gone"
        }
      },
      {
        "actors": {
          "actor-cdt1mcm": -120
        },
        "fx": {
          "fx-cond-restrict": "present"
        }
      },
      {
        "actors": {
          "actor-cdt1mcm": -170
        },
        "fx": {
          "fx-cond-restrict": "present"
        }
      },
      {
        "actors": {
          "actor-cdt1mcm": -40
        },
        "fx": {
          "fx-cond-restrict": "present"
        }
      },
      {
        "actors": {
          "actor-cdt1mcm": 70
        },
        "fx": {
          "fx-cond-restrict": "present"
        }
      }
    ],
    "label": "Mutant conditions"
  },
  "offCDT1N": {
    "fps": 1.2,
    "frames": [
      {
        "fx": {
          "fx-cond-cdt1n": "gone",
          "fx-lost-activation": "gone"
        },
        "tracks": {
          "o03-s": "duplex:present:kink-fixed",
          "o04-s": "duplex:present:kink-fixed",
          "o05-s": "duplex:present:kink-fixed",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm2:present:gate-closed:nsd-seated",
          "o08-c": "mcm2:present:gate-closed:nsd-seated",
          "o09-c": "mcm2:present:gate-closed:nsd-seated",
          "o10-c": "mcm2:present:gate-closed:nsd-seated",
          "o11-c": "mcm2:present:gate-closed:nsd-seated",
          "o12-c": "mcm2:present:gate-closed:nsd-seated"
        }
      },
      {
        "fx": {
          "fx-cond-cdt1n": "present",
          "fx-lost-activation": "gone"
        },
        "tracks": {
          "o03-s": "duplex:present:kink-fixed",
          "o04-s": "duplex:present:kink-fixed",
          "o05-s": "duplex:present:kink-fixed",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm2:present:gate-closed:nsd-seated",
          "o08-c": "mcm2:present:gate-closed:nsd-seated",
          "o09-c": "mcm2:present:gate-closed:nsd-seated",
          "o10-c": "mcm2:present:gate-closed:nsd-seated",
          "o11-c": "mcm2:present:gate-closed:nsd-seated",
          "o12-c": "mcm2:present:gate-closed:nsd-seated"
        }
      },
      {
        "fx": {
          "fx-cond-cdt1n": "present",
          "fx-lost-activation": "arriving"
        },
        "tracks": {
          "o03-s": "duplex:present:kink-fixed",
          "o04-s": "duplex:present:kink-fixed",
          "o05-s": "duplex:present:kink-fixed",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm2:present:gate-closed:nsd-seated",
          "o08-c": "mcm2:present:gate-closed:nsd-seated",
          "o09-c": "mcm2:present:gate-closed:nsd-seated",
          "o10-c": "mcm2:present:gate-closed:nsd-seated",
          "o11-c": "mcm2:present:gate-closed:nsd-seated",
          "o12-c": "mcm2:present:gate-closed:nsd-seated"
        }
      },
      {
        "fx": {
          "fx-cond-cdt1n": "present",
          "fx-lost-activation": "present"
        },
        "tracks": {
          "o03-s": "duplex:present:kink-fixed",
          "o04-s": "duplex:present:kink-fixed",
          "o05-s": "duplex:present:kink-fixed",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm2:present:gate-closed:nsd-seated",
          "o08-c": "mcm2:present:gate-closed:nsd-seated",
          "o09-c": "mcm2:present:gate-closed:nsd-seated",
          "o10-c": "mcm2:present:gate-closed:nsd-seated",
          "o11-c": "mcm2:present:gate-closed:nsd-seated",
          "o12-c": "mcm2:present:gate-closed:nsd-seated"
        }
      }
    ],
    "label": "Condition shift"
  },
  "offDDK": {
    "fps": 1.1,
    "frames": [
      {
        "actors": {
          "actor-sld3": [
            -190.0,
            60.0
          ]
        },
        "fx": {
          "fx-blocklab": "gone",
          "fx-cond-ddk": "gone",
          "fx-lost-activation": "gone"
        },
        "tracks": {
          "o03-c": "orc:fading:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-fixed",
          "o04-c": "orc:fading:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-fixed",
          "o05-c": "orc:fading:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-fixed",
          "o06-c": "orc:fading:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm2:present:gate-closed:nsd-seated",
          "o08-c": "mcm2:present:gate-closed:nsd-seated",
          "o09-c": "mcm2:present:gate-closed:nsd-seated",
          "o10-c": "mcm2:present:gate-closed:nsd-seated",
          "o11-c": "mcm2:present:gate-closed:nsd-seated",
          "o12-c": "mcm2:present:gate-closed:nsd-seated"
        }
      },
      {
        "actors": {
          "actor-sld3": [
            -127.0,
            34.0
          ]
        },
        "fx": {
          "fx-blocklab": "gone",
          "fx-cond-ddk": "present",
          "fx-lost-activation": "gone"
        },
        "tracks": {
          "o03-c": "orc:fading:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-fixed",
          "o04-c": "orc:fading:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-fixed",
          "o05-c": "orc:fading:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-fixed",
          "o06-c": "orc:fading:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm2:present:gate-closed:nsd-seated",
          "o08-c": "mcm2:present:gate-closed:nsd-seated",
          "o09-c": "mcm2:present:gate-closed:nsd-seated",
          "o10-c": "mcm2:present:gate-closed:nsd-seated",
          "o11-c": "mcm2:present:gate-closed:nsd-seated",
          "o12-c": "mcm2:present:gate-closed:nsd-seated"
        }
      },
      {
        "actors": {
          "actor-sld3": [
            -40.0,
            20.0
          ]
        },
        "fx": {
          "fx-blocklab": "gone",
          "fx-cond-ddk": "present",
          "fx-lost-activation": "gone"
        },
        "tracks": {
          "o03-c": "orc:fading:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-fixed",
          "o04-c": "orc:fading:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-fixed",
          "o05-c": "orc:fading:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-fixed",
          "o06-c": "orc:fading:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm2:present:gate-closed:nsd-seated",
          "o08-c": "mcm2:present:gate-closed:nsd-seated",
          "o09-c": "mcm2:present:gate-closed:nsd-seated",
          "o10-c": "mcm2:present:gate-closed:nsd-seated",
          "o11-c": "mcm2:present:gate-closed:nsd-seated",
          "o12-c": "mcm2:present:gate-closed:nsd-seated"
        }
      },
      {
        "actors": {
          "actor-sld3": [
            0.0,
            16.0
          ]
        },
        "fx": {
          "fx-blocklab": "arriving",
          "fx-cond-ddk": "present",
          "fx-lost-activation": "arriving"
        },
        "tracks": {
          "o03-c": "orc:fading:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-fixed",
          "o04-c": "orc:fading:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-fixed",
          "o05-c": "orc:fading:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-fixed",
          "o06-c": "orc:fading:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm2:present:gate-closed:nsd-seated",
          "o08-c": "mcm2:present:gate-closed:nsd-seated",
          "o09-c": "mcm2:present:gate-closed:nsd-seated",
          "o10-c": "mcm2:present:gate-closed:nsd-seated",
          "o11-c": "mcm2:present:gate-closed:nsd-seated",
          "o12-c": "mcm2:present:gate-closed:nsd-seated"
        }
      },
      {
        "actors": {
          "actor-sld3": [
            0.0,
            16.0
          ]
        },
        "fx": {
          "fx-blocklab": "present",
          "fx-cond-ddk": "present",
          "fx-lost-activation": "present"
        },
        "tracks": {
          "o03-c": "orc:fading:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-fixed",
          "o04-c": "orc:fading:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-fixed",
          "o05-c": "orc:fading:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-fixed",
          "o06-c": "orc:fading:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm2:present:gate-closed:nsd-seated",
          "o08-c": "mcm2:present:gate-closed:nsd-seated",
          "o09-c": "mcm2:present:gate-closed:nsd-seated",
          "o10-c": "mcm2:present:gate-closed:nsd-seated",
          "o11-c": "mcm2:present:gate-closed:nsd-seated",
          "o12-c": "mcm2:present:gate-closed:nsd-seated"
        }
      }
    ],
    "label": "The clasp stops short"
  },
  "offQC": {
    "fps": 1.3,
    "frames": [
      {
        "actors": {
          "actor-reject": 0
        }
      },
      {
        "actors": {
          "actor-reject": 60
        }
      },
      {
        "actors": {
          "actor-reject": 150
        }
      }
    ],
    "label": "Ejection"
  },
  "step01": {
    "fps": 1.3,
    "frames": [
      {
        "actors": {
          "actor-search": -170
        },
        "fx": {
          "fx-kinklab": "gone",
          "fx-search": "present",
          "fx-searchlab": "present"
        },
        "tracks": {
          "o03-c": "naked:present:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-none",
          "o04-c": "naked:present:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-none",
          "o05-c": "naked:present:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-none",
          "o06-c": "naked:present:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-none"
        }
      },
      {
        "actors": {
          "actor-search": 0
        },
        "fx": {
          "fx-kinklab": "gone",
          "fx-search": "present",
          "fx-searchlab": "present"
        },
        "tracks": {
          "o03-c": "naked:present:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-none",
          "o04-c": "naked:present:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-none",
          "o05-c": "naked:present:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-none",
          "o06-c": "naked:present:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-none"
        }
      },
      {
        "actors": {
          "actor-search": 110
        },
        "fx": {
          "fx-kinklab": "gone",
          "fx-search": "present",
          "fx-searchlab": "present"
        },
        "tracks": {
          "o03-c": "naked:present:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-none",
          "o04-c": "naked:present:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-none",
          "o05-c": "naked:present:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-none",
          "o06-c": "naked:present:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-none"
        }
      },
      {
        "actors": {
          "actor-search": 226
        },
        "fx": {
          "fx-kinklab": "gone",
          "fx-search": "present",
          "fx-searchlab": "present"
        },
        "tracks": {
          "o03-c": "naked:present:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-none",
          "o04-c": "naked:present:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-none",
          "o05-c": "naked:present:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-none",
          "o06-c": "naked:present:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-none"
        }
      },
      {
        "actors": {
          "actor-search": 280
        },
        "fx": {
          "fx-kinklab": "gone",
          "fx-search": "fading",
          "fx-searchlab": "gone"
        },
        "tracks": {
          "o03-c": "orc:present:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-none",
          "o04-c": "orc:present:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-none",
          "o05-c": "orc:present:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-none",
          "o06-c": "orc:present:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-none"
        }
      },
      {
        "actors": {
          "actor-search": 280
        },
        "fx": {
          "fx-kinklab": "present",
          "fx-search": "gone",
          "fx-searchlab": "gone"
        },
        "tracks": {
          "o03-c": "orc:present:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-transient",
          "o04-c": "orc:present:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-transient",
          "o05-c": "orc:present:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-transient",
          "o06-c": "orc:present:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-transient"
        }
      },
      {
        "actors": {
          "actor-search": 280
        },
        "fx": {
          "fx-kinklab": "present",
          "fx-search": "gone",
          "fx-searchlab": "gone"
        },
        "tracks": {
          "o03-c": "orc:present:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-none",
          "o04-c": "orc:present:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-none",
          "o05-c": "orc:present:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-none",
          "o06-c": "orc:present:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-none"
        }
      },
      {
        "actors": {
          "actor-search": 280
        },
        "fx": {
          "fx-kinklab": "present",
          "fx-search": "gone",
          "fx-searchlab": "gone"
        },
        "tracks": {
          "o03-c": "orc:present:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-transient",
          "o04-c": "orc:present:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-transient",
          "o05-c": "orc:present:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-transient",
          "o06-c": "orc:present:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-transient"
        }
      }
    ],
    "label": "Search and engagement"
  },
  "step02": {
    "fps": 1.2,
    "frames": [
      {
        "fx": {
          "fx-cdc6": "gone",
          "fx-cdc6in": "present"
        },
        "tracks": {
          "o03-s": "duplex:present:kink-transient",
          "o04-s": "duplex:present:kink-transient",
          "o05-s": "duplex:present:kink-transient",
          "o06-s": "duplex:present:kink-transient"
        },
        "actors": {
          "actor-cdc6in": [
            -289,
            -275
          ]
        }
      },
      {
        "fx": {
          "fx-cdc6": "gone",
          "fx-cdc6in": "present"
        },
        "tracks": {
          "o03-s": "duplex:present:kink-transient",
          "o04-s": "duplex:present:kink-transient",
          "o05-s": "duplex:present:kink-transient",
          "o06-s": "duplex:present:kink-transient"
        },
        "actors": {
          "actor-cdc6in": [
            -170,
            -95
          ]
        }
      },
      {
        "fx": {
          "fx-cdc6": "gone",
          "fx-cdc6in": "present"
        },
        "tracks": {
          "o03-s": "duplex:present:kink-transient",
          "o04-s": "duplex:present:kink-transient",
          "o05-s": "duplex:present:kink-transient",
          "o06-s": "duplex:present:kink-transient"
        },
        "actors": {
          "actor-cdc6in": [
            -113.3,
            -42.2
          ]
        }
      },
      {
        "fx": {
          "fx-cdc6": "gone",
          "fx-cdc6in": "present"
        },
        "tracks": {
          "o03-s": "duplex:present:kink-transient",
          "o04-s": "duplex:present:kink-transient",
          "o05-s": "duplex:present:kink-transient",
          "o06-s": "duplex:present:kink-transient"
        },
        "actors": {
          "actor-cdc6in": [
            -56.7,
            -10.6
          ]
        }
      },
      {
        "fx": {
          "fx-cdc6": "gone",
          "fx-cdc6in": "present"
        },
        "tracks": {
          "o03-s": "duplex:present:kink-transient",
          "o04-s": "duplex:present:kink-transient",
          "o05-s": "duplex:present:kink-transient",
          "o06-s": "duplex:present:kink-transient"
        },
        "actors": {
          "actor-cdc6in": [
            0,
            0
          ]
        }
      },
      {
        "fx": {
          "fx-cdc6": "present",
          "fx-cdc6in": "present"
        },
        "tracks": {
          "o03-s": "duplex:present:kink-fixed",
          "o04-s": "duplex:present:kink-fixed",
          "o05-s": "duplex:present:kink-fixed",
          "o06-s": "duplex:present:kink-fixed"
        },
        "actors": {
          "actor-cdc6in": [
            0,
            0
          ]
        }
      },
      {
        "fx": {
          "fx-cdc6": "present",
          "fx-cdc6in": "gone"
        },
        "tracks": {
          "o03-s": "duplex:present:kink-fixed",
          "o04-s": "duplex:present:kink-fixed",
          "o05-s": "duplex:present:kink-fixed",
          "o06-s": "duplex:present:kink-fixed"
        },
        "actors": {
          "actor-cdc6in": [
            0,
            0
          ]
        }
      }
    ],
    "label": "Ring closure"
  },
  "step03": {
    "fps": 1.2,
    "frames": [
      {
        "actors": {
          "actor-hept": [
            258,
            -281
          ]
        },
        "fx": {
          "fx-cdc6": "present",
          "fx-cdc6out": "gone",
          "fx-cdt1out": "gone",
          "fx-heptin": "present",
          "fx-openlab": "present"
        },
        "tracks": {
          "o03-s": "duplex:present:kink-fixed",
          "o04-s": "duplex:present:kink-fixed",
          "o05-s": "duplex:present:kink-fixed",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "naked:present:gate-na:nsd-na",
          "o08-c": "naked:present:gate-na:nsd-na",
          "o09-c": "naked:present:gate-na:nsd-na"
        }
      },
      {
        "actors": {
          "actor-hept": [
            150.0,
            -95.0
          ]
        },
        "fx": {
          "fx-cdc6": "present",
          "fx-cdc6out": "gone",
          "fx-cdt1out": "gone",
          "fx-heptin": "present",
          "fx-openlab": "present"
        },
        "tracks": {
          "o03-s": "duplex:present:kink-fixed",
          "o04-s": "duplex:present:kink-fixed",
          "o05-s": "duplex:present:kink-fixed",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "naked:present:gate-na:nsd-na",
          "o08-c": "naked:present:gate-na:nsd-na",
          "o09-c": "naked:present:gate-na:nsd-na"
        }
      },
      {
        "actors": {
          "actor-hept": [
            100.0,
            -42.2
          ]
        },
        "fx": {
          "fx-cdc6": "present",
          "fx-cdc6out": "gone",
          "fx-cdt1out": "gone",
          "fx-heptin": "present",
          "fx-openlab": "present"
        },
        "tracks": {
          "o03-s": "duplex:present:kink-fixed",
          "o04-s": "duplex:present:kink-fixed",
          "o05-s": "duplex:present:kink-fixed",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "naked:present:gate-na:nsd-na",
          "o08-c": "naked:present:gate-na:nsd-na",
          "o09-c": "naked:present:gate-na:nsd-na"
        }
      },
      {
        "actors": {
          "actor-hept": [
            50.0,
            -10.6
          ]
        },
        "fx": {
          "fx-cdc6": "present",
          "fx-cdc6out": "gone",
          "fx-cdt1out": "gone",
          "fx-heptin": "present",
          "fx-openlab": "present"
        },
        "tracks": {
          "o03-s": "duplex:present:kink-fixed",
          "o04-s": "duplex:present:kink-fixed",
          "o05-s": "duplex:present:kink-fixed",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "naked:present:gate-na:nsd-na",
          "o08-c": "naked:present:gate-na:nsd-na",
          "o09-c": "naked:present:gate-na:nsd-na"
        }
      },
      {
        "actors": {
          "actor-hept": [
            0.0,
            0.0
          ]
        },
        "fx": {
          "fx-cdc6": "present",
          "fx-cdc6out": "gone",
          "fx-cdt1out": "gone",
          "fx-heptin": "gone",
          "fx-openlab": "gone"
        },
        "tracks": {
          "o03-s": "duplex:present:kink-fixed",
          "o04-s": "duplex:present:kink-fixed",
          "o05-s": "duplex:present:kink-fixed",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "occm:present:gate-open:nsd-na",
          "o08-c": "occm:present:gate-open:nsd-na",
          "o09-c": "occm:present:gate-open:nsd-na"
        }
      },
      {
        "actors": {
          "actor-hept": [
            0.0,
            0.0
          ],
          "actor-cdc6out": [
            102,
            102
          ]
        },
        "fx": {
          "fx-cdc6": "present",
          "fx-cdc6out": "present",
          "fx-cdt1out": "gone",
          "fx-heptin": "gone",
          "fx-openlab": "gone"
        },
        "tracks": {
          "o03-s": "duplex:present:kink-fixed",
          "o04-s": "duplex:present:kink-fixed",
          "o05-s": "duplex:present:kink-fixed",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "occm:present:gate-open:nsd-na",
          "o08-c": "occm:present:gate-open:nsd-na",
          "o09-c": "occm:present:gate-open:nsd-na"
        }
      },
      {
        "actors": {
          "actor-cdc6out": [
            40,
            20
          ],
          "actor-cdt1out": 0
        },
        "fx": {
          "fx-cdc6": "gone",
          "fx-cdc6out": "present",
          "fx-cdt1out": "gone",
          "fx-heptin": "gone",
          "fx-openlab": "gone"
        },
        "tracks": {
          "o03-s": "duplex:present:kink-fixed",
          "o04-s": "duplex:present:kink-fixed",
          "o05-s": "duplex:present:kink-fixed",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "occm:present:gate-open:nsd-na",
          "o08-c": "occm:present:gate-open:nsd-na",
          "o09-c": "occm:present:gate-open:nsd-na"
        }
      },
      {
        "actors": {
          "actor-cdc6out": [
            -40,
            -80
          ],
          "actor-cdt1out": 0
        },
        "fx": {
          "fx-cdc6": "gone",
          "fx-cdc6out": "present",
          "fx-cdt1out": "gone",
          "fx-heptin": "gone",
          "fx-openlab": "gone"
        },
        "tracks": {
          "o03-s": "duplex:present:kink-fixed",
          "o04-s": "duplex:present:kink-fixed",
          "o05-s": "duplex:present:kink-fixed",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "occm:present:gate-open:nsd-na",
          "o08-c": "occm:present:gate-open:nsd-na",
          "o09-c": "occm:present:gate-open:nsd-na"
        }
      },
      {
        "actors": {
          "actor-cdc6out": [
            -130,
            -210
          ],
          "actor-cdt1out": [
            -69.5,
            -32
          ]
        },
        "fx": {
          "fx-cdc6": "gone",
          "fx-cdc6out": "present",
          "fx-cdt1out": "present",
          "fx-heptin": "gone",
          "fx-openlab": "gone"
        },
        "tracks": {
          "o03-s": "duplex:present:kink-fixed",
          "o04-s": "duplex:present:kink-fixed",
          "o05-s": "duplex:present:kink-fixed",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm1:arriving:gate-open:nsd-na",
          "o08-c": "mcm1:arriving:gate-open:nsd-na",
          "o09-c": "mcm1:arriving:gate-open:nsd-na"
        }
      },
      {
        "actors": {
          "actor-cdc6out": [
            -130,
            -210
          ],
          "actor-cdt1out": [
            30,
            50
          ]
        },
        "fx": {
          "fx-cdc6": "gone",
          "fx-cdc6out": "present",
          "fx-cdt1out": "present",
          "fx-heptin": "gone",
          "fx-openlab": "gone"
        },
        "tracks": {
          "o03-s": "duplex:present:kink-fixed",
          "o04-s": "duplex:present:kink-fixed",
          "o05-s": "duplex:present:kink-fixed",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm1:present:gate-closed:nsd-na",
          "o08-c": "mcm1:present:gate-closed:nsd-na",
          "o09-c": "mcm1:present:gate-closed:nsd-na"
        }
      },
      {
        "actors": {
          "actor-cdc6out": [
            -130,
            -210
          ],
          "actor-cdt1out": [
            110,
            130
          ]
        },
        "fx": {
          "fx-cdc6": "gone",
          "fx-cdc6out": "present",
          "fx-cdt1out": "present",
          "fx-heptin": "gone",
          "fx-openlab": "gone"
        },
        "tracks": {
          "o03-s": "duplex:present:kink-fixed",
          "o04-s": "duplex:present:kink-fixed",
          "o05-s": "duplex:present:kink-fixed",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm1:present:gate-closed:nsd-na",
          "o08-c": "mcm1:present:gate-closed:nsd-na",
          "o09-c": "mcm1:present:gate-closed:nsd-na"
        }
      }
    ],
    "label": "Delivery and first load"
  },
  "step04": {
    "fps": 1.2,
    "frames": [
      {
        "actors": {
          "actor-cdc6in": [
            -289,
            -275
          ]
        },
        "fx": {
          "fx-cdc6": "gone",
          "fx-cdc6in": "present"
        },
        "tracks": {
          "o03-s": "duplex:present:kink-fixed",
          "o04-s": "duplex:present:kink-fixed",
          "o05-s": "duplex:present:kink-fixed",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm1:present:gate-closed:nsd-na",
          "o08-c": "mcm1:present:gate-closed:nsd-na",
          "o09-c": "mcm1:present:gate-closed:nsd-na"
        }
      },
      {
        "actors": {
          "actor-cdc6in": [
            -170.0,
            -95.0
          ]
        },
        "fx": {
          "fx-cdc6": "gone",
          "fx-cdc6in": "present"
        },
        "tracks": {
          "o03-s": "duplex:present:kink-fixed",
          "o04-s": "duplex:present:kink-fixed",
          "o05-s": "duplex:present:kink-fixed",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm1:present:gate-closed:nsd-na",
          "o08-c": "mcm1:present:gate-closed:nsd-na",
          "o09-c": "mcm1:present:gate-closed:nsd-na"
        }
      },
      {
        "actors": {
          "actor-cdc6in": [
            -113.3,
            -42.2
          ]
        },
        "fx": {
          "fx-cdc6": "gone",
          "fx-cdc6in": "present"
        },
        "tracks": {
          "o03-s": "duplex:present:kink-fixed",
          "o04-s": "duplex:present:kink-fixed",
          "o05-s": "duplex:present:kink-fixed",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm1:present:gate-closed:nsd-na",
          "o08-c": "mcm1:present:gate-closed:nsd-na",
          "o09-c": "mcm1:present:gate-closed:nsd-na"
        }
      },
      {
        "actors": {
          "actor-cdc6in": [
            -56.7,
            -10.6
          ]
        },
        "fx": {
          "fx-cdc6": "gone",
          "fx-cdc6in": "present"
        },
        "tracks": {
          "o03-s": "duplex:present:kink-fixed",
          "o04-s": "duplex:present:kink-fixed",
          "o05-s": "duplex:present:kink-fixed",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm1:present:gate-closed:nsd-na",
          "o08-c": "mcm1:present:gate-closed:nsd-na",
          "o09-c": "mcm1:present:gate-closed:nsd-na"
        }
      },
      {
        "actors": {
          "actor-cdc6in": [
            0.0,
            0.0
          ]
        },
        "fx": {
          "fx-cdc6": "arriving",
          "fx-cdc6in": "present"
        },
        "tracks": {
          "o03-s": "duplex:present:kink-fixed",
          "o04-s": "duplex:present:kink-fixed",
          "o05-s": "duplex:present:kink-fixed",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm1:present:gate-closed:nsd-na",
          "o08-c": "mcm1:present:gate-closed:nsd-na",
          "o09-c": "mcm1:present:gate-closed:nsd-na"
        }
      },
      {
        "actors": {
          "actor-cdc6in": [
            0.0,
            0.0
          ]
        },
        "fx": {
          "fx-cdc6": "present",
          "fx-cdc6in": "gone"
        },
        "tracks": {
          "o03-s": "duplex:present:kink-fixed",
          "o04-s": "duplex:present:kink-fixed",
          "o05-s": "duplex:present:kink-fixed",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm1:present:gate-closed:nsd-na",
          "o08-c": "mcm1:present:gate-closed:nsd-na",
          "o09-c": "mcm1:present:gate-closed:nsd-na"
        }
      }
    ],
    "label": "Cdc6 returns to the notch"
  },
  "step05": {
    "fps": 1.2,
    "frames": [
      {
        "actors": {
          "actor-mcm-2": [
            258,
            -281
          ]
        },
        "fx": {
          "fx-atp": "gone",
          "fx-cdc6": "present",
          "fx-cdc6out2": "gone",
          "fx-cdt1out2": "gone",
          "fx-cdt1pry": "gone",
          "fx-mcm2in": "present"
        },
        "tracks": {
          "o03-c": "orc:present:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-fixed",
          "o04-c": "orc:present:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-fixed",
          "o05-c": "orc:present:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-fixed",
          "o06-c": "orc:present:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm1:present:gate-closed:nsd-na",
          "o08-c": "mcm1:present:gate-closed:nsd-na",
          "o09-c": "mcm1:present:gate-closed:nsd-na"
        }
      },
      {
        "actors": {
          "actor-mcm-2": [
            150.0,
            -95.0
          ]
        },
        "fx": {
          "fx-atp": "gone",
          "fx-cdc6": "present",
          "fx-cdc6out2": "gone",
          "fx-cdt1out2": "gone",
          "fx-cdt1pry": "gone",
          "fx-mcm2in": "present"
        },
        "tracks": {
          "o03-c": "orc:present:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-fixed",
          "o04-c": "orc:present:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-fixed",
          "o05-c": "orc:present:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-fixed",
          "o06-c": "orc:present:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm1:present:gate-closed:nsd-na",
          "o08-c": "mcm1:present:gate-closed:nsd-na",
          "o09-c": "mcm1:present:gate-closed:nsd-na"
        }
      },
      {
        "actors": {
          "actor-mcm-2": [
            100.0,
            -42.2
          ]
        },
        "fx": {
          "fx-atp": "gone",
          "fx-cdc6": "present",
          "fx-cdc6out2": "gone",
          "fx-cdt1out2": "gone",
          "fx-cdt1pry": "gone",
          "fx-mcm2in": "present"
        },
        "tracks": {
          "o03-c": "orc:present:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-fixed",
          "o04-c": "orc:present:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-fixed",
          "o05-c": "orc:present:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-fixed",
          "o06-c": "orc:present:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm1:present:gate-closed:nsd-na",
          "o08-c": "mcm1:present:gate-closed:nsd-na",
          "o09-c": "mcm1:present:gate-closed:nsd-na"
        }
      },
      {
        "actors": {
          "actor-mcm-2": [
            50.0,
            -10.6
          ]
        },
        "fx": {
          "fx-atp": "gone",
          "fx-cdc6": "present",
          "fx-cdc6out2": "gone",
          "fx-cdt1out2": "gone",
          "fx-cdt1pry": "gone",
          "fx-mcm2in": "present"
        },
        "tracks": {
          "o03-c": "orc:present:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-fixed",
          "o04-c": "orc:present:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-fixed",
          "o05-c": "orc:present:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-fixed",
          "o06-c": "orc:present:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm1:present:gate-closed:nsd-na",
          "o08-c": "mcm1:present:gate-closed:nsd-na",
          "o09-c": "mcm1:present:gate-closed:nsd-na"
        }
      },
      {
        "actors": {
          "actor-mcm-2": [
            0.0,
            0.0
          ]
        },
        "fx": {
          "fx-atp": "gone",
          "fx-cdc6": "present",
          "fx-cdc6out2": "gone",
          "fx-cdt1out2": "gone",
          "fx-cdt1pry": "arriving",
          "fx-mcm2in": "gone"
        },
        "tracks": {
          "o03-c": "orc:present:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-fixed",
          "o04-c": "orc:present:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-fixed",
          "o05-c": "orc:present:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-fixed",
          "o06-c": "orc:present:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm2:arriving:gate-closed:nsd-seated",
          "o08-c": "mcm2:arriving:gate-closed:nsd-seated",
          "o09-c": "mcm2:arriving:gate-closed:nsd-seated",
          "o10-c": "mcm2:arriving:gate-closed:nsd-seated",
          "o11-c": "mcm2:arriving:gate-closed:nsd-seated",
          "o12-c": "mcm2:arriving:gate-closed:nsd-seated"
        }
      },
      {
        "actors": {
          "actor-mcm-2": [
            0.0,
            0.0
          ]
        },
        "fx": {
          "fx-atp": "gone",
          "fx-cdc6": "present",
          "fx-cdc6out2": "gone",
          "fx-cdt1out2": "gone",
          "fx-cdt1pry": "present",
          "fx-mcm2in": "gone"
        },
        "tracks": {
          "o03-c": "orc:present:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-fixed",
          "o04-c": "orc:present:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-fixed",
          "o05-c": "orc:present:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-fixed",
          "o06-c": "orc:present:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm2:present:gate-closed:nsd-seated",
          "o08-c": "mcm2:present:gate-closed:nsd-seated",
          "o09-c": "mcm2:present:gate-closed:nsd-seated",
          "o10-c": "mcm2:present:gate-closed:nsd-seated",
          "o11-c": "mcm2:present:gate-closed:nsd-seated",
          "o12-c": "mcm2:present:gate-closed:nsd-seated"
        }
      },
      {
        "actors": {
          "actor-mcm-2": [
            0.0,
            0.0
          ],
          "actor-cdc6out2": [
            102,
            102
          ]
        },
        "fx": {
          "fx-atp": "gone",
          "fx-cdc6": "present",
          "fx-cdc6out2": "present",
          "fx-cdt1out2": "gone",
          "fx-cdt1pry": "present",
          "fx-mcm2in": "gone"
        },
        "tracks": {
          "o03-c": "orc:present:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-fixed",
          "o04-c": "orc:present:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-fixed",
          "o05-c": "orc:present:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-fixed",
          "o06-c": "orc:present:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm2:present:gate-closed:nsd-seated",
          "o08-c": "mcm2:present:gate-closed:nsd-seated",
          "o09-c": "mcm2:present:gate-closed:nsd-seated",
          "o10-c": "mcm2:present:gate-closed:nsd-seated",
          "o11-c": "mcm2:present:gate-closed:nsd-seated",
          "o12-c": "mcm2:present:gate-closed:nsd-seated"
        }
      },
      {
        "actors": {
          "actor-cdc6out2": [
            40,
            20
          ]
        },
        "fx": {
          "fx-atp": "arriving",
          "fx-cdc6": "gone",
          "fx-cdc6out2": "present",
          "fx-cdt1out2": "gone",
          "fx-cdt1pry": "present",
          "fx-mcm2in": "gone"
        },
        "tracks": {
          "o03-c": "orc:fading:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-fixed",
          "o04-c": "orc:fading:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-fixed",
          "o05-c": "orc:fading:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-fixed",
          "o06-c": "orc:fading:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm2:present:gate-closed:nsd-seated",
          "o08-c": "mcm2:present:gate-closed:nsd-seated",
          "o09-c": "mcm2:present:gate-closed:nsd-seated",
          "o10-c": "mcm2:present:gate-closed:nsd-seated",
          "o11-c": "mcm2:present:gate-closed:nsd-seated",
          "o12-c": "mcm2:present:gate-closed:nsd-seated"
        }
      },
      {
        "actors": {
          "actor-cdc6out2": [
            -40,
            -80
          ]
        },
        "fx": {
          "fx-atp": "present",
          "fx-cdc6": "gone",
          "fx-cdc6out2": "present",
          "fx-cdt1out2": "gone",
          "fx-cdt1pry": "present",
          "fx-mcm2in": "gone"
        },
        "tracks": {
          "o03-c": "orc:fading:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-fixed",
          "o04-c": "orc:fading:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-fixed",
          "o05-c": "orc:fading:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-fixed",
          "o06-c": "orc:fading:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm2:present:gate-closed:nsd-seated",
          "o08-c": "mcm2:present:gate-closed:nsd-seated",
          "o09-c": "mcm2:present:gate-closed:nsd-seated",
          "o10-c": "mcm2:present:gate-closed:nsd-seated",
          "o11-c": "mcm2:present:gate-closed:nsd-seated",
          "o12-c": "mcm2:present:gate-closed:nsd-seated"
        }
      },
      {
        "actors": {
          "actor-cdc6out2": [
            -130,
            -210
          ],
          "actor-cdt1out2": [
            -26,
            -34.5
          ]
        },
        "fx": {
          "fx-atp": "present",
          "fx-cdc6": "gone",
          "fx-cdc6out2": "present",
          "fx-cdt1out2": "present",
          "fx-cdt1pry": "gone",
          "fx-mcm2in": "gone"
        },
        "tracks": {
          "o03-c": "orc:fading:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-fixed",
          "o04-c": "orc:fading:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-fixed",
          "o05-c": "orc:fading:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-fixed",
          "o06-c": "orc:fading:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm2:present:gate-closed:nsd-seated",
          "o08-c": "mcm2:present:gate-closed:nsd-seated",
          "o09-c": "mcm2:present:gate-closed:nsd-seated",
          "o10-c": "mcm2:present:gate-closed:nsd-seated",
          "o11-c": "mcm2:present:gate-closed:nsd-seated",
          "o12-c": "mcm2:present:gate-closed:nsd-seated"
        }
      },
      {
        "actors": {
          "actor-cdc6out2": [
            -130,
            -210
          ],
          "actor-cdt1out2": [
            30,
            50
          ]
        },
        "fx": {
          "fx-atp": "gone",
          "fx-cdc6": "gone",
          "fx-cdc6out2": "present",
          "fx-cdt1out2": "present",
          "fx-cdt1pry": "gone",
          "fx-mcm2in": "gone"
        },
        "tracks": {
          "o03-c": "orc:fading:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-fixed",
          "o04-c": "orc:fading:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-fixed",
          "o05-c": "orc:fading:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-fixed",
          "o06-c": "orc:fading:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm2:present:gate-closed:nsd-seated",
          "o08-c": "mcm2:present:gate-closed:nsd-seated",
          "o09-c": "mcm2:present:gate-closed:nsd-seated",
          "o10-c": "mcm2:present:gate-closed:nsd-seated",
          "o11-c": "mcm2:present:gate-closed:nsd-seated",
          "o12-c": "mcm2:present:gate-closed:nsd-seated"
        }
      },
      {
        "actors": {
          "actor-cdc6out2": [
            -130,
            -210
          ],
          "actor-cdt1out2": [
            110,
            130
          ]
        },
        "fx": {
          "fx-atp": "gone",
          "fx-cdc6": "gone",
          "fx-cdc6out2": "present",
          "fx-cdt1out2": "present",
          "fx-cdt1pry": "gone",
          "fx-mcm2in": "gone"
        },
        "tracks": {
          "o03-c": "orc:fading:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-fixed",
          "o04-c": "orc:fading:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-fixed",
          "o05-c": "orc:fading:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-fixed",
          "o06-c": "orc:fading:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm2:present:gate-closed:nsd-seated",
          "o08-c": "mcm2:present:gate-closed:nsd-seated",
          "o09-c": "mcm2:present:gate-closed:nsd-seated",
          "o10-c": "mcm2:present:gate-closed:nsd-seated",
          "o11-c": "mcm2:present:gate-closed:nsd-seated",
          "o12-c": "mcm2:present:gate-closed:nsd-seated"
        }
      }
    ],
    "label": "Second delivery, licensed origin"
  },
  "step06": {
    "fps": 1.3,
    "frames": [
      {
        "actors": {
          "actor-ddk": [
            60,
            -210
          ]
        },
        "fx": {
          "fx-kin-ddk-4": "gone",
          "fx-kin-ddk-6": "gone",
          "fx-nsdlab": "gone",
          "fx-phos": "gone"
        },
        "tracks": {
          "o03-c": "orc:fading:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-fixed",
          "o04-c": "orc:fading:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-fixed",
          "o05-c": "orc:fading:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-fixed",
          "o06-c": "orc:fading:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm2:present:gate-closed:nsd-seated",
          "o08-c": "mcm2:present:gate-closed:nsd-seated",
          "o09-c": "mcm2:present:gate-closed:nsd-seated",
          "o10-c": "mcm2:present:gate-closed:nsd-seated",
          "o11-c": "mcm2:present:gate-closed:nsd-seated",
          "o12-c": "mcm2:present:gate-closed:nsd-seated"
        }
      },
      {
        "actors": {
          "actor-ddk": 0
        },
        "fx": {
          "fx-kin-ddk-4": "gone",
          "fx-kin-ddk-6": "gone",
          "fx-nsdlab": "gone",
          "fx-phos": "gone"
        },
        "tracks": {
          "o03-c": "orc:fading:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-fixed",
          "o04-c": "orc:fading:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-fixed",
          "o05-c": "orc:fading:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-fixed",
          "o06-c": "orc:fading:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm2:present:gate-closed:nsd-seated",
          "o08-c": "mcm2:present:gate-closed:nsd-seated",
          "o09-c": "mcm2:present:gate-closed:nsd-seated",
          "o10-c": "mcm2:present:gate-closed:nsd-seated",
          "o11-c": "mcm2:present:gate-closed:nsd-seated",
          "o12-c": "mcm2:present:gate-closed:nsd-seated"
        }
      },
      {
        "actors": {
          "actor-ddk": -110
        },
        "fx": {
          "fx-kin-ddk-4": "gone",
          "fx-kin-ddk-6": "gone",
          "fx-nsdlab": "gone",
          "fx-phos": "gone"
        },
        "tracks": {
          "o03-c": "orc:fading:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-fixed",
          "o04-c": "orc:fading:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-fixed",
          "o05-c": "orc:fading:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-fixed",
          "o06-c": "orc:fading:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm2:present:gate-closed:nsd-seated",
          "o08-c": "mcm2:present:gate-closed:nsd-seated",
          "o09-c": "mcm2:present:gate-closed:nsd-seated",
          "o10-c": "mcm2:present:gate-closed:nsd-seated",
          "o11-c": "mcm2:present:gate-closed:nsd-seated",
          "o12-c": "mcm2:present:gate-closed:nsd-seated"
        }
      },
      {
        "actors": {
          "actor-ddk": -160
        },
        "fx": {
          "fx-kin-ddk-4": "gone",
          "fx-kin-ddk-6": "gone",
          "fx-nsdlab": "arriving",
          "fx-phos": "gone"
        },
        "tracks": {
          "o03-c": "orc:fading:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-fixed",
          "o04-c": "orc:fading:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-fixed",
          "o05-c": "orc:fading:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-fixed",
          "o06-c": "orc:fading:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm2:present:gate-closed:nsd-displaced",
          "o08-c": "mcm2:present:gate-closed:nsd-displaced",
          "o09-c": "mcm2:present:gate-closed:nsd-displaced",
          "o10-c": "mcm2:present:gate-closed:nsd-displaced",
          "o11-c": "mcm2:present:gate-closed:nsd-displaced",
          "o12-c": "mcm2:present:gate-closed:nsd-displaced"
        }
      },
      {
        "actors": {
          "actor-ddk": -160
        },
        "fx": {
          "fx-kin-ddk-4": "present",
          "fx-kin-ddk-6": "present",
          "fx-nsdlab": "present",
          "fx-phos": "arriving"
        },
        "tracks": {
          "o03-c": "orc:fading:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-fixed",
          "o04-c": "orc:fading:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-fixed",
          "o05-c": "orc:fading:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-fixed",
          "o06-c": "orc:fading:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm2:present:gate-closed:nsd-displaced",
          "o08-c": "mcm2:present:gate-closed:nsd-displaced",
          "o09-c": "mcm2:present:gate-closed:nsd-displaced",
          "o10-c": "mcm2:present:gate-closed:nsd-displaced",
          "o11-c": "mcm2:present:gate-closed:nsd-displaced",
          "o12-c": "mcm2:present:gate-closed:nsd-displaced"
        }
      },
      {
        "actors": {
          "actor-ddk": [
            -20,
            -200
          ]
        },
        "fx": {
          "fx-kin-ddk-4": "gone",
          "fx-kin-ddk-6": "gone",
          "fx-nsdlab": "present",
          "fx-phos": "present"
        },
        "tracks": {
          "o03-c": "orc:fading:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-fixed",
          "o04-c": "orc:fading:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-fixed",
          "o05-c": "orc:fading:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-fixed",
          "o06-c": "orc:fading:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm2:present:gate-closed:nsd-displaced",
          "o08-c": "mcm2:present:gate-closed:nsd-displaced",
          "o09-c": "mcm2:present:gate-closed:nsd-displaced",
          "o10-c": "mcm2:present:gate-closed:nsd-displaced",
          "o11-c": "mcm2:present:gate-closed:nsd-displaced",
          "o12-c": "mcm2:present:gate-closed:nsd-displaced"
        }
      }
    ],
    "label": "DDK displaces the NSD"
  },
  "step07": {
    "fps": 1.2,
    "frames": [
      {
        "actors": {
          "actor-sld3": [
            -400,
            266
          ],
          "actor-cdc45l": [
            -40,
            230
          ],
          "actor-cdc45r": [
            40,
            230
          ]
        },
        "fx": {
          "fx-cdc45": "present",
          "fx-mcm2p": "gone",
          "fx-phos": "present"
        },
        "tracks": {
          "o03-c": "orc:fading:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-fixed",
          "o04-c": "orc:fading:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-fixed",
          "o05-c": "orc:fading:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-fixed",
          "o06-c": "orc:fading:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm2:present:gate-closed:nsd-displaced",
          "o08-c": "mcm2:present:gate-closed:nsd-displaced",
          "o09-c": "mcm2:present:gate-closed:nsd-displaced",
          "o10-c": "mcm2:present:gate-closed:nsd-displaced",
          "o11-c": "mcm2:present:gate-closed:nsd-displaced",
          "o12-c": "mcm2:present:gate-closed:nsd-displaced"
        }
      },
      {
        "actors": {
          "actor-sld3": [
            -290,
            140
          ],
          "actor-cdc45l": [
            -40,
            230
          ],
          "actor-cdc45r": [
            40,
            230
          ]
        },
        "fx": {
          "fx-cdc45": "present",
          "fx-mcm2p": "gone",
          "fx-phos": "present"
        },
        "tracks": {
          "o03-c": "orc:fading:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-fixed",
          "o04-c": "orc:fading:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-fixed",
          "o05-c": "orc:fading:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-fixed",
          "o06-c": "orc:fading:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm2:present:gate-closed:nsd-displaced",
          "o08-c": "mcm2:present:gate-closed:nsd-displaced",
          "o09-c": "mcm2:present:gate-closed:nsd-displaced",
          "o10-c": "mcm2:present:gate-closed:nsd-displaced",
          "o11-c": "mcm2:present:gate-closed:nsd-displaced",
          "o12-c": "mcm2:present:gate-closed:nsd-displaced"
        }
      },
      {
        "actors": {
          "actor-sld3": [
            -190.0,
            60.0
          ],
          "actor-cdc45l": [
            -40,
            230
          ],
          "actor-cdc45r": [
            40,
            230
          ]
        },
        "fx": {
          "fx-cdc45": "present",
          "fx-mcm2p": "gone",
          "fx-phos": "present"
        },
        "tracks": {
          "o03-c": "orc:fading:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-fixed",
          "o04-c": "orc:fading:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-fixed",
          "o05-c": "orc:fading:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-fixed",
          "o06-c": "orc:fading:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm2:present:gate-closed:nsd-displaced",
          "o08-c": "mcm2:present:gate-closed:nsd-displaced",
          "o09-c": "mcm2:present:gate-closed:nsd-displaced",
          "o10-c": "mcm2:present:gate-closed:nsd-displaced",
          "o11-c": "mcm2:present:gate-closed:nsd-displaced",
          "o12-c": "mcm2:present:gate-closed:nsd-displaced"
        }
      },
      {
        "actors": {
          "actor-sld3": [
            -127.0,
            27.0
          ],
          "actor-cdc45l": [
            -40,
            230
          ],
          "actor-cdc45r": [
            40,
            230
          ]
        },
        "fx": {
          "fx-cdc45": "present",
          "fx-mcm2p": "gone",
          "fx-phos": "present"
        },
        "tracks": {
          "o03-c": "orc:fading:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-fixed",
          "o04-c": "orc:fading:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-fixed",
          "o05-c": "orc:fading:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-fixed",
          "o06-c": "orc:fading:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm2:present:gate-closed:nsd-displaced",
          "o08-c": "mcm2:present:gate-closed:nsd-displaced",
          "o09-c": "mcm2:present:gate-closed:nsd-displaced",
          "o10-c": "mcm2:present:gate-closed:nsd-displaced",
          "o11-c": "mcm2:present:gate-closed:nsd-displaced",
          "o12-c": "mcm2:present:gate-closed:nsd-displaced"
        }
      },
      {
        "actors": {
          "actor-sld3": [
            -63.0,
            7.0
          ],
          "actor-cdc45l": [
            -40,
            230
          ],
          "actor-cdc45r": [
            40,
            230
          ]
        },
        "fx": {
          "fx-cdc45": "present",
          "fx-mcm2p": "gone",
          "fx-phos": "present"
        },
        "tracks": {
          "o03-c": "orc:fading:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-fixed",
          "o04-c": "orc:fading:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-fixed",
          "o05-c": "orc:fading:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-fixed",
          "o06-c": "orc:fading:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm2:present:gate-closed:nsd-displaced",
          "o08-c": "mcm2:present:gate-closed:nsd-displaced",
          "o09-c": "mcm2:present:gate-closed:nsd-displaced",
          "o10-c": "mcm2:present:gate-closed:nsd-displaced",
          "o11-c": "mcm2:present:gate-closed:nsd-displaced",
          "o12-c": "mcm2:present:gate-closed:nsd-displaced"
        }
      },
      {
        "actors": {
          "actor-sld3": [
            0.0,
            0.0
          ],
          "actor-cdc45l": [
            -40,
            230
          ],
          "actor-cdc45r": [
            40,
            230
          ]
        },
        "fx": {
          "fx-cdc45": "present",
          "fx-mcm2p": "gone",
          "fx-phos": "present"
        },
        "tracks": {
          "o03-c": "orc:fading:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-fixed",
          "o04-c": "orc:fading:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-fixed",
          "o05-c": "orc:fading:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-fixed",
          "o06-c": "orc:fading:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm2:present:gate-closed:nsd-displaced",
          "o08-c": "mcm2:present:gate-closed:nsd-displaced",
          "o09-c": "mcm2:present:gate-closed:nsd-displaced",
          "o10-c": "mcm2:present:gate-closed:nsd-displaced",
          "o11-c": "mcm2:present:gate-closed:nsd-displaced",
          "o12-c": "mcm2:present:gate-closed:nsd-displaced"
        }
      },
      {
        "actors": {
          "actor-sld3": [
            0.0,
            0.0
          ],
          "actor-cdc45l": [
            -20,
            110
          ],
          "actor-cdc45r": [
            20,
            110
          ]
        },
        "fx": {
          "fx-cdc45": "present",
          "fx-mcm2p": "gone",
          "fx-phos": "present"
        },
        "tracks": {
          "o03-c": "orc:fading:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-fixed",
          "o04-c": "orc:fading:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-fixed",
          "o05-c": "orc:fading:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-fixed",
          "o06-c": "orc:fading:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm2:present:gate-closed:nsd-displaced",
          "o08-c": "mcm2:present:gate-closed:nsd-displaced",
          "o09-c": "mcm2:present:gate-closed:nsd-displaced",
          "o10-c": "mcm2:present:gate-closed:nsd-displaced",
          "o11-c": "mcm2:present:gate-closed:nsd-displaced",
          "o12-c": "mcm2:present:gate-closed:nsd-displaced"
        }
      },
      {
        "actors": {
          "actor-sld3": [
            0.0,
            0.0
          ],
          "actor-cdc45l": [
            0,
            0
          ],
          "actor-cdc45r": [
            0,
            0
          ]
        },
        "fx": {
          "fx-cdc45": "present",
          "fx-mcm2p": "present",
          "fx-phos": "present"
        },
        "tracks": {
          "o03-c": "orc:fading:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-fixed",
          "o04-c": "orc:fading:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-fixed",
          "o05-c": "orc:fading:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-fixed",
          "o06-c": "orc:fading:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm2:present:gate-closed:nsd-displaced",
          "o08-c": "mcm2:present:gate-closed:nsd-displaced",
          "o09-c": "mcm2:present:gate-closed:nsd-displaced",
          "o10-c": "mcm2:present:gate-closed:nsd-displaced",
          "o11-c": "mcm2:present:gate-closed:nsd-displaced",
          "o12-c": "mcm2:present:gate-closed:nsd-displaced"
        }
      }
    ],
    "label": "Clasp and Cdc45"
  },
  "step08": {
    "fps": 1.3,
    "frames": [
      {
        "actors": {
          "actor-scdk": [
            -40,
            -200
          ],
          "actor-sld2free": [
            -60,
            -210
          ]
        },
        "fx": {
          "fx-cdc45": "present",
          "fx-kin-sld2": "gone",
          "fx-kin-sld3": "gone",
          "fx-sld2p": "gone",
          "fx-sld3p": "gone"
        },
        "tracks": {
          "o03-c": "orc:fading:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-fixed",
          "o04-c": "orc:fading:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-fixed",
          "o05-c": "orc:fading:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-fixed",
          "o06-c": "orc:fading:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm2:present:gate-closed:nsd-displaced",
          "o08-c": "mcm2:present:gate-closed:nsd-displaced",
          "o09-c": "mcm2:present:gate-closed:nsd-displaced",
          "o10-c": "mcm2:present:gate-closed:nsd-displaced",
          "o11-c": "mcm2:present:gate-closed:nsd-displaced",
          "o12-c": "mcm2:present:gate-closed:nsd-displaced"
        }
      },
      {
        "actors": {
          "actor-scdk": [
            0.0,
            0.0
          ],
          "actor-sld2free": [
            0,
            0
          ]
        },
        "fx": {
          "fx-cdc45": "present",
          "fx-kin-sld2": "gone",
          "fx-kin-sld3": "gone",
          "fx-sld2p": "gone",
          "fx-sld3p": "gone"
        },
        "tracks": {
          "o03-c": "orc:fading:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-fixed",
          "o04-c": "orc:fading:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-fixed",
          "o05-c": "orc:fading:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-fixed",
          "o06-c": "orc:fading:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm2:present:gate-closed:nsd-displaced",
          "o08-c": "mcm2:present:gate-closed:nsd-displaced",
          "o09-c": "mcm2:present:gate-closed:nsd-displaced",
          "o10-c": "mcm2:present:gate-closed:nsd-displaced",
          "o11-c": "mcm2:present:gate-closed:nsd-displaced",
          "o12-c": "mcm2:present:gate-closed:nsd-displaced"
        }
      },
      {
        "actors": {
          "actor-scdk": [
            12.0,
            -6.0
          ],
          "actor-sld2free": [
            0,
            0
          ]
        },
        "fx": {
          "fx-cdc45": "present",
          "fx-kin-sld2": "present",
          "fx-kin-sld3": "gone",
          "fx-sld2p": "arriving",
          "fx-sld3p": "gone"
        },
        "tracks": {
          "o03-c": "orc:fading:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-fixed",
          "o04-c": "orc:fading:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-fixed",
          "o05-c": "orc:fading:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-fixed",
          "o06-c": "orc:fading:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm2:present:gate-closed:nsd-displaced",
          "o08-c": "mcm2:present:gate-closed:nsd-displaced",
          "o09-c": "mcm2:present:gate-closed:nsd-displaced",
          "o10-c": "mcm2:present:gate-closed:nsd-displaced",
          "o11-c": "mcm2:present:gate-closed:nsd-displaced",
          "o12-c": "mcm2:present:gate-closed:nsd-displaced"
        }
      },
      {
        "actors": {
          "actor-scdk": [
            12.0,
            -6.0
          ],
          "actor-sld2free": [
            0,
            0
          ]
        },
        "fx": {
          "fx-cdc45": "present",
          "fx-kin-sld2": "gone",
          "fx-kin-sld3": "gone",
          "fx-sld2p": "present",
          "fx-sld3p": "gone"
        },
        "tracks": {
          "o03-c": "orc:fading:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-fixed",
          "o04-c": "orc:fading:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-fixed",
          "o05-c": "orc:fading:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-fixed",
          "o06-c": "orc:fading:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm2:present:gate-closed:nsd-displaced",
          "o08-c": "mcm2:present:gate-closed:nsd-displaced",
          "o09-c": "mcm2:present:gate-closed:nsd-displaced",
          "o10-c": "mcm2:present:gate-closed:nsd-displaced",
          "o11-c": "mcm2:present:gate-closed:nsd-displaced",
          "o12-c": "mcm2:present:gate-closed:nsd-displaced"
        }
      },
      {
        "actors": {
          "actor-scdk": [
            150.0,
            -22.0
          ],
          "actor-sld2free": [
            0,
            0
          ]
        },
        "fx": {
          "fx-cdc45": "present",
          "fx-kin-sld2": "gone",
          "fx-kin-sld3": "gone",
          "fx-sld2p": "present",
          "fx-sld3p": "gone"
        },
        "tracks": {
          "o03-c": "orc:fading:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-fixed",
          "o04-c": "orc:fading:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-fixed",
          "o05-c": "orc:fading:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-fixed",
          "o06-c": "orc:fading:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm2:present:gate-closed:nsd-displaced",
          "o08-c": "mcm2:present:gate-closed:nsd-displaced",
          "o09-c": "mcm2:present:gate-closed:nsd-displaced",
          "o10-c": "mcm2:present:gate-closed:nsd-displaced",
          "o11-c": "mcm2:present:gate-closed:nsd-displaced",
          "o12-c": "mcm2:present:gate-closed:nsd-displaced"
        }
      },
      {
        "actors": {
          "actor-scdk": [
            275.0,
            -1.0
          ],
          "actor-sld2free": [
            0,
            0
          ]
        },
        "fx": {
          "fx-cdc45": "present",
          "fx-kin-sld2": "gone",
          "fx-kin-sld3": "present",
          "fx-sld2p": "present",
          "fx-sld3p": "arriving"
        },
        "tracks": {
          "o03-c": "orc:fading:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-fixed",
          "o04-c": "orc:fading:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-fixed",
          "o05-c": "orc:fading:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-fixed",
          "o06-c": "orc:fading:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm2:present:gate-closed:nsd-displaced",
          "o08-c": "mcm2:present:gate-closed:nsd-displaced",
          "o09-c": "mcm2:present:gate-closed:nsd-displaced",
          "o10-c": "mcm2:present:gate-closed:nsd-displaced",
          "o11-c": "mcm2:present:gate-closed:nsd-displaced",
          "o12-c": "mcm2:present:gate-closed:nsd-displaced"
        }
      },
      {
        "actors": {
          "actor-scdk": [
            275.0,
            -1.0
          ],
          "actor-sld2free": [
            0,
            0
          ]
        },
        "fx": {
          "fx-cdc45": "present",
          "fx-kin-sld2": "gone",
          "fx-kin-sld3": "gone",
          "fx-sld2p": "present",
          "fx-sld3p": "present"
        },
        "tracks": {
          "o03-c": "orc:fading:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-fixed",
          "o04-c": "orc:fading:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-fixed",
          "o05-c": "orc:fading:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-fixed",
          "o06-c": "orc:fading:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm2:present:gate-closed:nsd-displaced",
          "o08-c": "mcm2:present:gate-closed:nsd-displaced",
          "o09-c": "mcm2:present:gate-closed:nsd-displaced",
          "o10-c": "mcm2:present:gate-closed:nsd-displaced",
          "o11-c": "mcm2:present:gate-closed:nsd-displaced",
          "o12-c": "mcm2:present:gate-closed:nsd-displaced"
        }
      },
      {
        "actors": {
          "actor-scdk": [
            330,
            -200
          ],
          "actor-sld2free": [
            0,
            0
          ]
        },
        "fx": {
          "fx-cdc45": "present",
          "fx-kin-sld2": "gone",
          "fx-kin-sld3": "gone",
          "fx-sld2p": "present",
          "fx-sld3p": "present"
        },
        "tracks": {
          "o03-c": "orc:fading:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-fixed",
          "o04-c": "orc:fading:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-fixed",
          "o05-c": "orc:fading:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-fixed",
          "o06-c": "orc:fading:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm2:present:gate-closed:nsd-displaced",
          "o08-c": "mcm2:present:gate-closed:nsd-displaced",
          "o09-c": "mcm2:present:gate-closed:nsd-displaced",
          "o10-c": "mcm2:present:gate-closed:nsd-displaced",
          "o11-c": "mcm2:present:gate-closed:nsd-displaced",
          "o12-c": "mcm2:present:gate-closed:nsd-displaced"
        }
      }
    ],
    "label": "S-CDK"
  },
  "step09": {
    "fps": 1.2,
    "frames": [
      {
        "actors": {
          "actor-dpb11": [
            -319.0,
            -230.0
          ],
          "actor-ginsfree": [
            -319.0,
            -230.0
          ],
          "actor-sld2c": [
            -319.0,
            -36.0
          ],
          "actor-sld3": [
            0.0,
            0.0
          ],
          "actor-polefree": [
            -319.0,
            -230.0
          ],
          "actor-ginsfree2": [
            -300,
            150
          ],
          "actor-polefree2": [
            -300,
            150
          ]
        },
        "fx": {
          "fx-atpx": "gone",
          "fx-cdc45": "present",
          "fx-dpb11out": "present",
          "fx-ginsfree": "present",
          "fx-phos": "present",
          "fx-sld2out": "present",
          "fx-sld3p": "present",
          "fx-sldout": "present",
          "fx-polefree": "present",
          "fx-ginsfree2": "present",
          "fx-polefree2": "present"
        },
        "tracks": {
          "o03-c": "orc:fading:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-fixed",
          "o04-c": "orc:fading:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-fixed",
          "o05-c": "orc:fading:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-fixed",
          "o06-c": "orc:fading:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm2:present:gate-closed:nsd-displaced",
          "o08-c": "mcm2:present:gate-closed:nsd-displaced",
          "o09-c": "mcm2:present:gate-closed:nsd-displaced",
          "o10-c": "mcm2:present:gate-closed:nsd-displaced",
          "o11-c": "mcm2:present:gate-closed:nsd-displaced",
          "o12-c": "mcm2:present:gate-closed:nsd-displaced"
        }
      },
      {
        "actors": {
          "actor-dpb11": [
            -319.0,
            -135.0
          ],
          "actor-ginsfree": [
            -319.0,
            -135.0
          ],
          "actor-sld2c": [
            -319.0,
            -36.0
          ],
          "actor-sld3": [
            0.0,
            0.0
          ],
          "actor-polefree": [
            -319.0,
            -135.0
          ],
          "actor-ginsfree2": [
            -300,
            150
          ],
          "actor-polefree2": [
            -300,
            150
          ]
        },
        "fx": {
          "fx-atpx": "gone",
          "fx-cdc45": "present",
          "fx-dpb11out": "present",
          "fx-ginsfree": "present",
          "fx-phos": "present",
          "fx-sld2out": "present",
          "fx-sld3p": "present",
          "fx-sldout": "present",
          "fx-polefree": "present",
          "fx-ginsfree2": "present",
          "fx-polefree2": "present"
        },
        "tracks": {
          "o03-c": "orc:fading:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-fixed",
          "o04-c": "orc:fading:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-fixed",
          "o05-c": "orc:fading:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-fixed",
          "o06-c": "orc:fading:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm2:present:gate-closed:nsd-displaced",
          "o08-c": "mcm2:present:gate-closed:nsd-displaced",
          "o09-c": "mcm2:present:gate-closed:nsd-displaced",
          "o10-c": "mcm2:present:gate-closed:nsd-displaced",
          "o11-c": "mcm2:present:gate-closed:nsd-displaced",
          "o12-c": "mcm2:present:gate-closed:nsd-displaced"
        }
      },
      {
        "actors": {
          "actor-dpb11": [
            -319.0,
            -36.0
          ],
          "actor-ginsfree": [
            -319.0,
            -36.0
          ],
          "actor-sld2c": [
            -319.0,
            -36.0
          ],
          "actor-sld3": [
            0.0,
            0.0
          ],
          "actor-polefree": [
            -319.0,
            -36.0
          ],
          "actor-ginsfree2": [
            -300,
            150
          ],
          "actor-polefree2": [
            -300,
            150
          ]
        },
        "fx": {
          "fx-atpx": "gone",
          "fx-cdc45": "present",
          "fx-dpb11out": "present",
          "fx-ginsfree": "present",
          "fx-phos": "present",
          "fx-sld2out": "present",
          "fx-sld3p": "present",
          "fx-sldout": "present",
          "fx-polefree": "present",
          "fx-ginsfree2": "present",
          "fx-polefree2": "present"
        },
        "tracks": {
          "o03-c": "orc:fading:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-fixed",
          "o04-c": "orc:fading:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-fixed",
          "o05-c": "orc:fading:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-fixed",
          "o06-c": "orc:fading:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm2:present:gate-closed:nsd-displaced",
          "o08-c": "mcm2:present:gate-closed:nsd-displaced",
          "o09-c": "mcm2:present:gate-closed:nsd-displaced",
          "o10-c": "mcm2:present:gate-closed:nsd-displaced",
          "o11-c": "mcm2:present:gate-closed:nsd-displaced",
          "o12-c": "mcm2:present:gate-closed:nsd-displaced"
        }
      },
      {
        "actors": {
          "actor-dpb11": [
            -200.0,
            -24.0
          ],
          "actor-ginsfree": [
            -200.0,
            -24.0
          ],
          "actor-sld2c": [
            -200.0,
            -24.0
          ],
          "actor-sld3": [
            0.0,
            0.0
          ],
          "actor-polefree": [
            -200.0,
            -24.0
          ],
          "actor-ginsfree2": [
            -150,
            60
          ],
          "actor-polefree2": [
            -150,
            60
          ]
        },
        "fx": {
          "fx-atpx": "gone",
          "fx-cdc45": "present",
          "fx-dpb11out": "present",
          "fx-ginsfree": "present",
          "fx-phos": "present",
          "fx-sld2out": "present",
          "fx-sld3p": "present",
          "fx-sldout": "present",
          "fx-polefree": "present",
          "fx-ginsfree2": "present",
          "fx-polefree2": "present"
        },
        "tracks": {
          "o03-c": "orc:fading:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-fixed",
          "o04-c": "orc:fading:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-fixed",
          "o05-c": "orc:fading:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-fixed",
          "o06-c": "orc:fading:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm2:present:gate-closed:nsd-displaced",
          "o08-c": "mcm2:present:gate-closed:nsd-displaced",
          "o09-c": "mcm2:present:gate-closed:nsd-displaced",
          "o10-c": "mcm2:present:gate-closed:nsd-displaced",
          "o11-c": "mcm2:present:gate-closed:nsd-displaced",
          "o12-c": "mcm2:present:gate-closed:nsd-displaced"
        }
      },
      {
        "actors": {
          "actor-dpb11": [
            0.0,
            0.0
          ],
          "actor-ginsfree": [
            0.0,
            0.0
          ],
          "actor-sld2c": [
            0.0,
            0.0
          ],
          "actor-sld3": [
            0.0,
            0.0
          ],
          "actor-polefree": [
            0.0,
            0.0
          ],
          "actor-ginsfree2": [
            0,
            0
          ],
          "actor-polefree2": [
            0,
            0
          ]
        },
        "fx": {
          "fx-atpx": "gone",
          "fx-cdc45": "present",
          "fx-dpb11out": "present",
          "fx-ginsfree": "present",
          "fx-phos": "present",
          "fx-sld2out": "present",
          "fx-sld3p": "present",
          "fx-sldout": "present",
          "fx-polefree": "present",
          "fx-ginsfree2": "present",
          "fx-polefree2": "present"
        },
        "tracks": {
          "o03-c": "orc:fading:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-fixed",
          "o04-c": "orc:fading:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-fixed",
          "o05-c": "orc:fading:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-fixed",
          "o06-c": "orc:fading:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm2:present:gate-closed:nsd-displaced",
          "o08-c": "mcm2:present:gate-closed:nsd-displaced",
          "o09-c": "mcm2:present:gate-closed:nsd-displaced",
          "o10-c": "mcm2:present:gate-closed:nsd-displaced",
          "o11-c": "mcm2:present:gate-closed:nsd-displaced",
          "o12-c": "mcm2:present:gate-closed:nsd-displaced"
        }
      },
      {
        "actors": {
          "actor-dpb11": [
            0.0,
            0.0
          ],
          "actor-ginsfree": [
            -101,
            87
          ],
          "actor-sld2c": [
            0.0,
            0.0
          ],
          "actor-sld3": [
            0.0,
            0.0
          ],
          "actor-polefree": [
            -51,
            65
          ],
          "actor-ginsfree2": [
            0,
            0
          ],
          "actor-polefree2": [
            0,
            0
          ]
        },
        "fx": {
          "fx-atpx": "gone",
          "fx-cdc45": "present",
          "fx-dpb11out": "present",
          "fx-ginsfree": "present",
          "fx-phos": "present",
          "fx-sld2out": "present",
          "fx-sld3p": "present",
          "fx-sldout": "present",
          "fx-polefree": "present",
          "fx-ginsfree2": "present",
          "fx-polefree2": "present"
        },
        "tracks": {
          "o03-c": "orc:fading:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-fixed",
          "o04-c": "orc:fading:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-fixed",
          "o05-c": "orc:fading:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-fixed",
          "o06-c": "orc:fading:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "mcm2:present:gate-closed:nsd-displaced",
          "o08-c": "mcm2:present:gate-closed:nsd-displaced",
          "o09-c": "mcm2:present:gate-closed:nsd-displaced",
          "o10-c": "mcm2:present:gate-closed:nsd-displaced",
          "o11-c": "mcm2:present:gate-closed:nsd-displaced",
          "o12-c": "mcm2:present:gate-closed:nsd-displaced"
        }
      },
      {
        "actors": {
          "actor-dpb11": [
            0,
            0
          ],
          "actor-ginsfree": [
            -101,
            87
          ],
          "actor-sld2c": [
            0,
            0
          ],
          "actor-sld3": [
            0.0,
            0.0
          ],
          "actor-polefree": [
            -51,
            65
          ],
          "actor-ginsfree2": [
            0,
            0
          ],
          "actor-polefree2": [
            0,
            0
          ]
        },
        "fx": {
          "fx-atpx": "arriving",
          "fx-cdc45": "gone",
          "fx-dpb11out": "present",
          "fx-ginsfree": "present",
          "fx-phos": "present",
          "fx-sld2out": "present",
          "fx-sld3p": "present",
          "fx-sldout": "present",
          "fx-polefree": "present",
          "fx-ginsfree2": "present",
          "fx-polefree2": "present"
        },
        "tracks": {
          "o03-c": "orc:fading:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-fixed",
          "o04-c": "orc:fading:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-fixed",
          "o05-c": "orc:fading:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-fixed",
          "o06-c": "orc:fading:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "cmg:present:gate-sealed:nsd-na",
          "o08-c": "cmg:present:gate-sealed:nsd-na",
          "o09-c": "cmg:present:gate-sealed:nsd-na",
          "o10-c": "cmg:present:gate-sealed:nsd-na",
          "o11-c": "cmg:present:gate-sealed:nsd-na",
          "o12-c": "cmg:present:gate-sealed:nsd-na"
        }
      },
      {
        "actors": {
          "actor-dpb11": [
            90,
            -120
          ],
          "actor-ginsfree": [
            -101,
            87
          ],
          "actor-sld2c": [
            90,
            -120
          ],
          "actor-sld3": [
            -60,
            60
          ],
          "actor-polefree": [
            -51,
            65
          ],
          "actor-ginsfree2": [
            0,
            0
          ],
          "actor-polefree2": [
            0,
            0
          ]
        },
        "fx": {
          "fx-atpx": "present",
          "fx-cdc45": "gone",
          "fx-dpb11out": "present",
          "fx-ginsfree": "gone",
          "fx-phos": "present",
          "fx-sld2out": "present",
          "fx-sld3p": "present",
          "fx-sldout": "present",
          "fx-polefree": "gone",
          "fx-ginsfree2": "gone",
          "fx-polefree2": "gone"
        },
        "tracks": {
          "o03-c": "orc:fading:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-fixed",
          "o04-c": "orc:fading:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-fixed",
          "o05-c": "orc:fading:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-fixed",
          "o06-c": "orc:fading:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "cmg:present:gate-sealed:nsd-na",
          "o08-c": "cmg:present:gate-sealed:nsd-na",
          "o09-c": "cmg:present:gate-sealed:nsd-na",
          "o10-c": "cmg:present:gate-sealed:nsd-na",
          "o11-c": "cmg:present:gate-sealed:nsd-na",
          "o12-c": "cmg:present:gate-sealed:nsd-na"
        }
      },
      {
        "actors": {
          "actor-dpb11": [
            160,
            -260
          ],
          "actor-ginsfree": [
            -101,
            87
          ],
          "actor-sld2c": [
            160,
            -260
          ],
          "actor-sld3": [
            -120,
            270
          ],
          "actor-polefree": [
            -51,
            65
          ],
          "actor-ginsfree2": [
            0,
            0
          ],
          "actor-polefree2": [
            0,
            0
          ]
        },
        "fx": {
          "fx-atpx": "present",
          "fx-cdc45": "gone",
          "fx-dpb11out": "present",
          "fx-ginsfree": "gone",
          "fx-phos": "present",
          "fx-sld2out": "present",
          "fx-sld3p": "present",
          "fx-sldout": "present",
          "fx-polefree": "gone",
          "fx-ginsfree2": "gone",
          "fx-polefree2": "gone"
        },
        "tracks": {
          "o03-c": "orc:fading:gate-na:nsd-na",
          "o03-s": "duplex:present:kink-fixed",
          "o04-c": "orc:fading:gate-na:nsd-na",
          "o04-s": "duplex:present:kink-fixed",
          "o05-c": "orc:fading:gate-na:nsd-na",
          "o05-s": "duplex:present:kink-fixed",
          "o06-c": "orc:fading:gate-na:nsd-na",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "cmg:present:gate-sealed:nsd-na",
          "o08-c": "cmg:present:gate-sealed:nsd-na",
          "o09-c": "cmg:present:gate-sealed:nsd-na",
          "o10-c": "cmg:present:gate-sealed:nsd-na",
          "o11-c": "cmg:present:gate-sealed:nsd-na",
          "o12-c": "cmg:present:gate-sealed:nsd-na"
        }
      }
    ],
    "label": "CMG assembly"
  },
  "step10": {
    "fps": 1.2,
    "frames": [
      {
        "fx": {
          "fx-atph": "gone",
          "fx-atpx": "present"
        },
        "tracks": {
          "o03-s": "duplex:present:kink-fixed",
          "o04-s": "duplex:present:kink-fixed",
          "o05-s": "duplex:present:kink-fixed",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "cmg:present:gate-sealed:nsd-na",
          "o08-c": "cmg:present:gate-sealed:nsd-na",
          "o09-c": "cmg:present:gate-sealed:nsd-na",
          "o10-c": "cmg:present:gate-sealed:nsd-na",
          "o11-c": "cmg:present:gate-sealed:nsd-na",
          "o12-c": "cmg:present:gate-sealed:nsd-na"
        },
        "actors": {
          "actor-mcm10": [
            0,
            -200
          ]
        }
      },
      {
        "fx": {
          "fx-atph": "gone",
          "fx-atpx": "gone"
        },
        "tracks": {
          "o03-s": "duplex:present:kink-fixed",
          "o04-s": "duplex:present:kink-fixed",
          "o05-s": "duplex:present:kink-fixed",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "cmg:present:gate-sealed:nsd-na",
          "o08-c": "cmg:present:gate-sealed:nsd-na",
          "o09-c": "cmg:present:gate-sealed:nsd-na",
          "o10-c": "cmg:present:gate-sealed:nsd-na",
          "o11-c": "cmg:present:gate-sealed:nsd-na",
          "o12-c": "cmg:present:gate-sealed:nsd-na"
        },
        "actors": {
          "actor-mcm10": [
            0,
            0
          ]
        }
      },
      {
        "fx": {
          "fx-atph": "gone",
          "fx-atpx": "gone"
        },
        "tracks": {
          "o03-s": "duplex:present:kink-fixed",
          "o04-s": "duplex:present:kink-fixed",
          "o05-s": "duplex:present:kink-fixed",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "cmg:present:gate-sealed:nsd-na",
          "o08-c": "cmg:present:gate-sealed:nsd-na",
          "o09-c": "cmg:present:gate-sealed:nsd-na",
          "o10-c": "cmg:present:gate-sealed:nsd-na",
          "o11-c": "cmg:present:gate-sealed:nsd-na",
          "o12-c": "cmg:present:gate-sealed:nsd-na"
        },
        "actors": {
          "actor-mcm10": [
            0,
            0
          ]
        }
      },
      {
        "fx": {
          "fx-atph": "arriving",
          "fx-atpx": "gone"
        },
        "tracks": {
          "o03-s": "duplex:present:kink-fixed",
          "o04-s": "duplex:present:kink-fixed",
          "o05-s": "duplex:present:kink-fixed",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "cmg:present:gate-sealed:nsd-na",
          "o08-c": "cmg:present:gate-sealed:nsd-na",
          "o09-c": "cmg:present:gate-sealed:nsd-na",
          "o09-s": "melted:present",
          "o10-c": "cmg:present:gate-sealed:nsd-na",
          "o10-s": "melted:present",
          "o11-c": "cmg:present:gate-sealed:nsd-na",
          "o12-c": "cmg:present:gate-sealed:nsd-na"
        },
        "actors": {
          "actor-mcm10": [
            0,
            0
          ]
        }
      },
      {
        "fx": {
          "fx-atph": "present",
          "fx-atpx": "gone"
        },
        "tracks": {
          "o03-s": "duplex:present:kink-fixed",
          "o04-s": "duplex:present:kink-fixed",
          "o05-s": "duplex:present:kink-fixed",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "cmg:present:gate-sealed:nsd-na",
          "o08-c": "cmg:present:gate-sealed:nsd-na",
          "o08-s": "melted:present",
          "o09-c": "cmg:present:gate-sealed:nsd-na",
          "o09-s": "melted:present",
          "o10-c": "cmg:present:gate-sealed:nsd-na",
          "o10-s": "melted:present",
          "o11-c": "cmg:present:gate-sealed:nsd-na",
          "o11-s": "melted:present",
          "o12-c": "cmg:present:gate-sealed:nsd-na"
        },
        "actors": {
          "actor-mcm10": [
            0,
            0
          ]
        }
      },
      {
        "fx": {
          "fx-atph": "present",
          "fx-atpx": "gone"
        },
        "tracks": {
          "o03-s": "duplex:present:kink-fixed",
          "o04-s": "duplex:present:kink-fixed",
          "o05-s": "duplex:present:kink-fixed",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "cmg:present:gate-sealed:nsd-na",
          "o07-s": "melted:present",
          "o08-c": "cmg:present:gate-sealed:nsd-na",
          "o08-s": "melted:present",
          "o09-c": "cmg:present:gate-sealed:nsd-na",
          "o09-s": "melted:present",
          "o10-c": "cmg:present:gate-sealed:nsd-na",
          "o10-s": "melted:present",
          "o11-c": "cmg:present:gate-sealed:nsd-na",
          "o11-s": "melted:present",
          "o12-c": "cmg:present:gate-sealed:nsd-na",
          "o12-s": "melted:present"
        },
        "actors": {
          "actor-mcm10": [
            0,
            0
          ]
        }
      },
      {
        "fx": {
          "fx-atph": "present",
          "fx-atpx": "gone"
        },
        "tracks": {
          "o03-s": "duplex:present:kink-fixed",
          "o04-s": "duplex:present:kink-fixed",
          "o05-s": "duplex:present:kink-fixed",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "cmg:present:gate-sealed:nsd-na",
          "o07-s": "extruded:present",
          "o08-c": "cmg:present:gate-sealed:nsd-na",
          "o08-s": "extruded:present",
          "o09-c": "cmg:present:gate-sealed:nsd-na",
          "o09-s": "extruded:present",
          "o10-c": "cmg:present:gate-sealed:nsd-na",
          "o10-s": "extruded:present",
          "o11-c": "cmg:present:gate-sealed:nsd-na",
          "o11-s": "extruded:present",
          "o12-c": "cmg:present:gate-sealed:nsd-na",
          "o12-s": "extruded:present"
        },
        "actors": {
          "actor-mcm10": [
            0,
            -200
          ]
        }
      }
    ],
    "label": "Mcm10 and melting"
  },
  "step11": {
    "fps": 1.3,
    "frames": [
      {
        "actors": {
          "actor-polain-l": [
            0,
            260
          ],
          "actor-polain-r": [
            0,
            -260
          ],
          "actor-polein-l": [
            -69,
            89
          ],
          "actor-polein-r": [
            69,
            1
          ],
          "actor-rpain-l": [
            0,
            260
          ],
          "actor-rpain-r": [
            0,
            260
          ],
          "actor-mrcin-l": [
            0,
            -260
          ],
          "actor-mrcin-r": [
            0,
            -260
          ],
          "actor-dntpein-l": [
            0,
            -330
          ],
          "actor-dntpain-r": [
            0,
            -330
          ],
          "actor-dntpein-r": [
            0,
            330
          ],
          "actor-dntpain-l": [
            0,
            330
          ]
        },
        "fx": {
          "fx-atph": "present",
          "fx-nosynth": "present"
        },
        "tracks": {
          "o03-s": "duplex:present:kink-fixed",
          "o04-s": "duplex:present:kink-fixed",
          "o05-s": "duplex:present:kink-fixed",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "cmg:present:gate-sealed:nsd-na",
          "o07-s": "extruded:present",
          "o08-c": "cmg:present:gate-sealed:nsd-na",
          "o08-s": "extruded:present",
          "o09-c": "cmg:present:gate-sealed:nsd-na",
          "o09-s": "extruded:present",
          "o10-c": "cmg:present:gate-sealed:nsd-na",
          "o10-s": "extruded:present",
          "o11-c": "cmg:present:gate-sealed:nsd-na",
          "o11-s": "extruded:present",
          "o12-c": "cmg:present:gate-sealed:nsd-na",
          "o12-s": "extruded:present"
        }
      },
      {
        "actors": {
          "actor-polain-l": [
            0,
            0
          ],
          "actor-polain-r": [
            0,
            0
          ],
          "actor-polein-l": [
            0,
            0
          ],
          "actor-polein-r": [
            0,
            0
          ],
          "actor-rpain-l": [
            0,
            0
          ],
          "actor-rpain-r": [
            0,
            0
          ],
          "actor-mrcin-l": [
            0,
            0
          ],
          "actor-mrcin-r": [
            0,
            0
          ],
          "actor-dntpein-l": [
            0,
            -330
          ],
          "actor-dntpain-r": [
            0,
            -330
          ],
          "actor-dntpein-r": [
            0,
            330
          ],
          "actor-dntpain-l": [
            0,
            330
          ]
        },
        "fx": {
          "fx-atph": "gone",
          "fx-nosynth": "present"
        },
        "tracks": {
          "o03-s": "duplex:present:kink-fixed",
          "o04-s": "duplex:present:kink-fixed",
          "o05-s": "duplex:present:kink-fixed",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "cmg:present:gate-sealed:nsd-na",
          "o07-s": "extruded:present",
          "o08-c": "cmg:present:gate-sealed:nsd-na",
          "o08-s": "extruded:present",
          "o09-c": "cmg:present:gate-sealed:nsd-na",
          "o09-s": "extruded:present",
          "o10-c": "cmg:present:gate-sealed:nsd-na",
          "o10-s": "extruded:present",
          "o11-c": "cmg:present:gate-sealed:nsd-na",
          "o11-s": "extruded:present",
          "o12-c": "cmg:present:gate-sealed:nsd-na",
          "o12-s": "extruded:present"
        }
      },
      {
        "actors": {
          "actor-polain-l": [
            0,
            0
          ],
          "actor-polain-r": [
            0,
            0
          ],
          "actor-polein-l": [
            0,
            0
          ],
          "actor-polein-r": [
            0,
            0
          ],
          "actor-rpain-l": [
            0,
            0
          ],
          "actor-rpain-r": [
            0,
            0
          ],
          "actor-mrcin-l": [
            0,
            0
          ],
          "actor-mrcin-r": [
            0,
            0
          ],
          "actor-dntpein-l": [
            0,
            0
          ],
          "actor-dntpain-r": [
            0,
            0
          ],
          "actor-dntpein-r": [
            0,
            0
          ],
          "actor-dntpain-l": [
            0,
            0
          ]
        },
        "fx": {
          "fx-atph": "gone",
          "fx-nosynth": "gone"
        },
        "tracks": {
          "o03-s": "duplex:present:kink-fixed",
          "o04-s": "duplex:present:kink-fixed",
          "o05-s": "duplex:present:kink-fixed",
          "o06-s": "duplex:present:kink-fixed",
          "o07-c": "cmg:present:gate-sealed:nsd-na",
          "o07-s": "extruded:present",
          "o08-c": "cmg:present:gate-sealed:nsd-na",
          "o08-s": "extruded:present",
          "o09-c": "cmg:present:gate-sealed:nsd-na",
          "o09-s": "replicated:present",
          "o10-c": "cmg:present:gate-sealed:nsd-na",
          "o10-s": "replicated:present",
          "o11-c": "cmg:present:gate-sealed:nsd-na",
          "o11-s": "extruded:present",
          "o12-c": "cmg:present:gate-sealed:nsd-na",
          "o12-s": "extruded:present"
        }
      },
      {
        "actors": {
          "actor-polain-l": [
            0,
            0
          ],
          "actor-polain-r": [
            0,
            0
          ],
          "actor-polein-l": [
            0,
            0
          ],
          "actor-polein-r": [
            0,
            0
          ],
          "actor-rpain-l": [
            0,
            0
          ],
          "actor-rpain-r": [
            0,
            0
          ],
          "actor-mrcin-l": [
            0,
            0
          ],
          "actor-mrcin-r": [
            0,
            0
          ],
          "actor-dntpein-l": [
            0,
            0
          ],
          "actor-dntpain-r": [
            0,
            0
          ],
          "actor-dntpein-r": [
            0,
            0
          ],
          "actor-dntpain-l": [
            0,
            0
          ]
        },
        "tracks": {
          "o03-s": "duplex:present:kink-fixed",
          "o04-s": "duplex:present:kink-fixed",
          "o05-s": "duplex:present:kink-fixed",
          "o06-s": "extruded:present",
          "o07-c": "cmg:present:gate-sealed:nsd-na",
          "o07-s": "extruded:present",
          "o08-c": "cmg:present:gate-sealed:nsd-na",
          "o08-s": "extruded:present",
          "o09-c": "cmg:present:gate-sealed:nsd-na",
          "o09-s": "replicated:present",
          "o10-c": "cmg:present:gate-sealed:nsd-na",
          "o10-s": "replicated:present",
          "o11-c": "cmg:present:gate-sealed:nsd-na",
          "o11-s": "extruded:present",
          "o12-c": "cmg:present:gate-sealed:nsd-na",
          "o12-s": "extruded:present",
          "o13-s": "extruded:present"
        },
        "fx": {
          "fx-atph": "gone",
          "fx-nosynth": "gone"
        }
      },
      {
        "actors": {
          "actor-polain-l": [
            0,
            0
          ],
          "actor-polain-r": [
            0,
            0
          ],
          "actor-polein-l": [
            0,
            0
          ],
          "actor-polein-r": [
            0,
            0
          ],
          "actor-rpain-l": [
            0,
            0
          ],
          "actor-rpain-r": [
            0,
            0
          ],
          "actor-mrcin-l": [
            0,
            0
          ],
          "actor-mrcin-r": [
            0,
            0
          ],
          "actor-dntpein-l": [
            0,
            0
          ],
          "actor-dntpain-r": [
            0,
            0
          ],
          "actor-dntpein-r": [
            0,
            0
          ],
          "actor-dntpain-l": [
            0,
            0
          ]
        },
        "tracks": {
          "o03-s": "duplex:present:kink-fixed",
          "o04-s": "extruded:present",
          "o05-s": "extruded:present",
          "o06-s": "extruded:present",
          "o07-c": "cmg:present:gate-sealed:nsd-na",
          "o07-s": "extruded:present",
          "o08-c": "cmg:present:gate-sealed:nsd-na",
          "o08-s": "replicated:present",
          "o09-c": "cmg:present:gate-sealed:nsd-na",
          "o09-s": "replicated:present",
          "o10-c": "cmg:present:gate-sealed:nsd-na",
          "o10-s": "replicated:present",
          "o11-c": "cmg:present:gate-sealed:nsd-na",
          "o11-s": "replicated:present",
          "o12-c": "cmg:present:gate-sealed:nsd-na",
          "o12-s": "extruded:present",
          "o13-s": "extruded:present",
          "o14-s": "extruded:present",
          "o15-s": "extruded:present"
        },
        "fx": {
          "fx-atph": "gone",
          "fx-nosynth": "gone"
        }
      },
      {
        "actors": {
          "actor-polain-l": [
            0,
            0
          ],
          "actor-polain-r": [
            0,
            0
          ],
          "actor-polein-l": [
            0,
            0
          ],
          "actor-polein-r": [
            0,
            0
          ],
          "actor-rpain-l": [
            0,
            0
          ],
          "actor-rpain-r": [
            0,
            0
          ],
          "actor-mrcin-l": [
            0,
            0
          ],
          "actor-mrcin-r": [
            0,
            0
          ],
          "actor-dntpein-l": [
            0,
            0
          ],
          "actor-dntpain-r": [
            0,
            0
          ],
          "actor-dntpein-r": [
            0,
            0
          ],
          "actor-dntpain-l": [
            0,
            0
          ]
        },
        "tracks": {
          "o01-s": "extruded:present",
          "o02-s": "extruded:present",
          "o03-s": "extruded:present",
          "o04-s": "extruded:present",
          "o05-s": "replicated:present",
          "o06-s": "replicated:present",
          "o07-c": "cmg:present:gate-sealed:nsd-na",
          "o07-s": "replicated:present",
          "o08-c": "cmg:present:gate-sealed:nsd-na",
          "o08-s": "replicated:present",
          "o09-c": "cmg:present:gate-sealed:nsd-na",
          "o09-s": "replicated:present",
          "o10-c": "cmg:present:gate-sealed:nsd-na",
          "o10-s": "replicated:present",
          "o11-c": "cmg:present:gate-sealed:nsd-na",
          "o11-s": "replicated:present",
          "o12-c": "cmg:present:gate-sealed:nsd-na",
          "o12-s": "replicated:present",
          "o13-s": "replicated:present",
          "o14-s": "replicated:present",
          "o15-s": "extruded:present",
          "o16-s": "extruded:present",
          "o17-s": "extruded:present",
          "o18-s": "extruded:present"
        },
        "fx": {
          "fx-atph": "gone",
          "fx-nosynth": "gone"
        }
      },
      {
        "actors": {
          "actor-polain-l": [
            0,
            0
          ],
          "actor-polain-r": [
            0,
            0
          ],
          "actor-polein-l": [
            0,
            0
          ],
          "actor-polein-r": [
            0,
            0
          ],
          "actor-rpain-l": [
            0,
            0
          ],
          "actor-rpain-r": [
            0,
            0
          ],
          "actor-mrcin-l": [
            0,
            0
          ],
          "actor-mrcin-r": [
            0,
            0
          ],
          "actor-dntpein-l": [
            0,
            0
          ],
          "actor-dntpain-r": [
            0,
            0
          ],
          "actor-dntpein-r": [
            0,
            0
          ],
          "actor-dntpain-l": [
            0,
            0
          ]
        },
        "tracks": {
          "l01-s": "extruded:present",
          "l02-s": "extruded:present",
          "l03-s": "extruded:present",
          "l04-s": "extruded:present",
          "o01-s": "replicated:present",
          "o02-s": "replicated:present",
          "o03-s": "replicated:present",
          "o04-s": "replicated:present",
          "o05-s": "replicated:present",
          "o06-s": "replicated:present",
          "o07-c": "cmg:present:gate-sealed:nsd-na",
          "o07-s": "replicated:present",
          "o08-c": "cmg:present:gate-sealed:nsd-na",
          "o08-s": "replicated:present",
          "o09-c": "cmg:present:gate-sealed:nsd-na",
          "o09-s": "replicated:present",
          "o10-c": "cmg:present:gate-sealed:nsd-na",
          "o10-s": "replicated:present",
          "o11-c": "cmg:present:gate-sealed:nsd-na",
          "o11-s": "replicated:present",
          "o12-c": "cmg:present:gate-sealed:nsd-na",
          "o12-s": "replicated:present",
          "o13-s": "replicated:present",
          "o14-s": "replicated:present",
          "o15-s": "replicated:present",
          "o16-s": "replicated:present",
          "o17-s": "replicated:present",
          "o18-s": "replicated:present",
          "r01-s": "extruded:present",
          "r02-s": "extruded:present",
          "r03-s": "extruded:present",
          "r04-s": "extruded:present"
        },
        "fx": {
          "fx-atph": "gone",
          "fx-nosynth": "gone"
        }
      },
      {
        "actors": {
          "actor-polain-l": [
            0,
            0
          ],
          "actor-polain-r": [
            0,
            0
          ],
          "actor-polein-l": [
            0,
            0
          ],
          "actor-polein-r": [
            0,
            0
          ],
          "actor-rpain-l": [
            0,
            0
          ],
          "actor-rpain-r": [
            0,
            0
          ],
          "actor-mrcin-l": [
            0,
            0
          ],
          "actor-mrcin-r": [
            0,
            0
          ],
          "actor-dntpein-l": [
            0,
            0
          ],
          "actor-dntpain-r": [
            0,
            0
          ],
          "actor-dntpein-r": [
            0,
            0
          ],
          "actor-dntpain-l": [
            0,
            0
          ]
        },
        "tracks": {
          "l01-s": "replicated:present",
          "l02-s": "replicated:present",
          "l03-s": "replicated:present",
          "l04-s": "replicated:present",
          "l05-s": "extruded:present",
          "l06-s": "extruded:present",
          "l07-s": "extruded:present",
          "l08-s": "extruded:present",
          "o01-s": "replicated:present",
          "o02-s": "replicated:present",
          "o03-s": "replicated:present",
          "o04-s": "replicated:present",
          "o05-s": "replicated:present",
          "o06-s": "replicated:present",
          "o07-c": "cmg:present:gate-sealed:nsd-na",
          "o07-s": "replicated:present",
          "o08-c": "cmg:present:gate-sealed:nsd-na",
          "o08-s": "replicated:present",
          "o09-c": "cmg:present:gate-sealed:nsd-na",
          "o09-s": "replicated:present",
          "o10-c": "cmg:present:gate-sealed:nsd-na",
          "o10-s": "replicated:present",
          "o11-c": "cmg:present:gate-sealed:nsd-na",
          "o11-s": "replicated:present",
          "o12-c": "cmg:present:gate-sealed:nsd-na",
          "o12-s": "replicated:present",
          "o13-s": "replicated:present",
          "o14-s": "replicated:present",
          "o15-s": "replicated:present",
          "o16-s": "replicated:present",
          "o17-s": "replicated:present",
          "o18-s": "replicated:present",
          "r01-s": "replicated:present",
          "r02-s": "replicated:present",
          "r03-s": "replicated:present",
          "r04-s": "replicated:present",
          "r05-s": "extruded:present",
          "r06-s": "extruded:present",
          "r07-s": "extruded:present",
          "r08-s": "extruded:present"
        },
        "fx": {
          "fx-atph": "gone",
          "fx-nosynth": "gone"
        }
      },
      {
        "actors": {
          "actor-polain-l": [
            0,
            0
          ],
          "actor-polain-r": [
            0,
            0
          ],
          "actor-polein-l": [
            0,
            0
          ],
          "actor-polein-r": [
            0,
            0
          ],
          "actor-rpain-l": [
            0,
            0
          ],
          "actor-rpain-r": [
            0,
            0
          ],
          "actor-mrcin-l": [
            0,
            0
          ],
          "actor-mrcin-r": [
            0,
            0
          ],
          "actor-dntpein-l": [
            0,
            0
          ],
          "actor-dntpain-r": [
            0,
            0
          ],
          "actor-dntpein-r": [
            0,
            0
          ],
          "actor-dntpain-l": [
            0,
            0
          ]
        },
        "tracks": {
          "l01-s": "replicated:present",
          "l02-s": "replicated:present",
          "l03-s": "replicated:present",
          "l04-s": "replicated:present",
          "l05-s": "replicated:present",
          "l06-s": "replicated:present",
          "l07-s": "replicated:present",
          "l08-s": "extruded:present",
          "l09-s": "extruded:present",
          "l10-s": "extruded:present",
          "l11-s": "extruded:present",
          "o01-s": "replicated:present",
          "o02-s": "replicated:present",
          "o03-s": "replicated:present",
          "o04-s": "replicated:present",
          "o05-s": "replicated:present",
          "o06-s": "replicated:present",
          "o07-c": "cmg:present:gate-sealed:nsd-na",
          "o07-s": "replicated:present",
          "o08-c": "cmg:present:gate-sealed:nsd-na",
          "o08-s": "replicated:present",
          "o09-c": "cmg:present:gate-sealed:nsd-na",
          "o09-s": "replicated:present",
          "o10-c": "cmg:present:gate-sealed:nsd-na",
          "o10-s": "replicated:present",
          "o11-c": "cmg:present:gate-sealed:nsd-na",
          "o11-s": "replicated:present",
          "o12-c": "cmg:present:gate-sealed:nsd-na",
          "o12-s": "replicated:present",
          "o13-s": "replicated:present",
          "o14-s": "replicated:present",
          "o15-s": "replicated:present",
          "o16-s": "replicated:present",
          "o17-s": "replicated:present",
          "o18-s": "replicated:present",
          "r01-s": "replicated:present",
          "r02-s": "replicated:present",
          "r03-s": "replicated:present",
          "r04-s": "replicated:present",
          "r05-s": "replicated:present",
          "r06-s": "replicated:present",
          "r07-s": "replicated:present",
          "r08-s": "extruded:present",
          "r09-s": "extruded:present",
          "r10-s": "extruded:present",
          "r11-s": "extruded:present"
        },
        "fx": {
          "fx-atph": "gone",
          "fx-nosynth": "gone"
        }
      },
      {
        "actors": {
          "actor-polain-l": [
            0,
            0
          ],
          "actor-polain-r": [
            0,
            0
          ],
          "actor-polein-l": [
            0,
            0
          ],
          "actor-polein-r": [
            0,
            0
          ],
          "actor-rpain-l": [
            0,
            0
          ],
          "actor-rpain-r": [
            0,
            0
          ],
          "actor-mrcin-l": [
            0,
            0
          ],
          "actor-mrcin-r": [
            0,
            0
          ],
          "actor-dntpein-l": [
            0,
            0
          ],
          "actor-dntpain-r": [
            0,
            0
          ],
          "actor-dntpein-r": [
            0,
            0
          ],
          "actor-dntpain-l": [
            0,
            0
          ]
        },
        "tracks": {
          "l01-s": "replicated:present",
          "l02-s": "replicated:present",
          "l03-s": "replicated:present",
          "l04-s": "replicated:present",
          "l05-s": "replicated:present",
          "l06-s": "replicated:present",
          "l07-s": "replicated:present",
          "l08-s": "replicated:present",
          "l09-s": "replicated:present",
          "l10-s": "replicated:present",
          "l11-s": "extruded:present",
          "l12-s": "extruded:present",
          "l13-s": "extruded:present",
          "l14-s": "extruded:present",
          "o01-s": "replicated:present",
          "o02-s": "replicated:present",
          "o03-s": "replicated:present",
          "o04-s": "replicated:present",
          "o05-s": "replicated:present",
          "o06-s": "replicated:present",
          "o07-c": "cmg:present:gate-sealed:nsd-na",
          "o07-s": "replicated:present",
          "o08-c": "cmg:present:gate-sealed:nsd-na",
          "o08-s": "replicated:present",
          "o09-c": "cmg:present:gate-sealed:nsd-na",
          "o09-s": "replicated:present",
          "o10-c": "cmg:present:gate-sealed:nsd-na",
          "o10-s": "replicated:present",
          "o11-c": "cmg:present:gate-sealed:nsd-na",
          "o11-s": "replicated:present",
          "o12-c": "cmg:present:gate-sealed:nsd-na",
          "o12-s": "replicated:present",
          "o13-s": "replicated:present",
          "o14-s": "replicated:present",
          "o15-s": "replicated:present",
          "o16-s": "replicated:present",
          "o17-s": "replicated:present",
          "o18-s": "replicated:present",
          "r01-s": "replicated:present",
          "r02-s": "replicated:present",
          "r03-s": "replicated:present",
          "r04-s": "replicated:present",
          "r05-s": "replicated:present",
          "r06-s": "replicated:present",
          "r07-s": "replicated:present",
          "r08-s": "replicated:present",
          "r09-s": "replicated:present",
          "r10-s": "replicated:present",
          "r11-s": "extruded:present",
          "r12-s": "extruded:present",
          "r13-s": "extruded:present",
          "r14-s": "extruded:present"
        },
        "fx": {
          "fx-atph": "gone",
          "fx-nosynth": "gone"
        }
      }
    ],
    "label": "Replisome and fork travel"
  }
};

if (typeof window !== 'undefined') { window.ANIM = ANIM; }