/* Animation engine and the derived layer.

   Three things in this file are model specific: chunkId(), the geometry
   constants at the top, and the body of paintDerived. Every other function is
   generic.

   Nothing in the derived layer may appear in a frame table. A frame table
   that named a zone tint, a derived glyph position, or a status slot would
   give the panel a second source of truth for one fact. */

// === MODEL SPECIFIC: geometry, duplicated from tools/make_panels.py ========

var GEO = {
  X0: 26, CW: 18, LEFT_CTX: 14, ORIGIN_N: 18, RIGHT_CTX: 14,
  ROW_T: 148, ROW_B: 159, BAR_H: 5, MCM_W: 54,
  // The position the two forks part at, and the fragment length on the
  // lagging strand. Duplicated from FORK_SPLIT and OKAZAKI_N in
  // tools/make_panels.py, which cuts the pieces this file times.
  FORK_SPLIT: 23, OKAZAKI_N: 8,
  ARS_A: 'o03', ARS_B: 'o06'
};
GEO.NPOS = GEO.LEFT_CTX + GEO.ORIGIN_N + GEO.RIGHT_CTX;

function chunkId(i) {
  // Position id for linear index i. Three families, each counted outward
  // from its own start. Duplicated as chunk_id() in tools/make_panels.py.
  var pad = function (n) { return (n < 10 ? '0' : '') + n; };
  if (i <= GEO.LEFT_CTX) { return 'l' + pad(GEO.LEFT_CTX + 1 - i); }
  if (i <= GEO.LEFT_CTX + GEO.ORIGIN_N) { return 'o' + pad(i - GEO.LEFT_CTX); }
  return 'r' + pad(i - GEO.LEFT_CTX - GEO.ORIGIN_N);
}

function linOf(id) {
  // Linear index of a position id. Inverse of chunkId.
  var fam = id.charAt(0), n = parseInt(id.slice(1), 10);
  if (fam === 'l') { return GEO.LEFT_CTX + 1 - n; }
  if (fam === 'o') { return GEO.LEFT_CTX + n; }
  return GEO.LEFT_CTX + GEO.ORIGIN_N + n;
}

// === SHARED FUNCTIONS =====================================================

var STATES = ['gone', 'fading', 'arriving', 'present'];
// extruded and replicated are two different claims about one position.
// extruded says the parental strands are apart and single stranded, which is
// what RPA binds and what a polymerase has not reached. replicated says a
// daughter strand has been laid against each of them. Duplicated as
// STRAND_VALUES in tools/make_panels.py.
var STRAND_VALUES = ['duplex', 'melted', 'extruded', 'replicated'];
var CPX_VALUES = ['naked', 'orc', 'occm', 'mcm1', 'mcm2', 'cmg'];

// Kink is the third declared quantity on a position. It rides the strand
// group as its own class family, because whether the bend relaxes is a claim
// and not a consequence of the strand state. A frame writes it as a third
// compound field: "duplex:present:kink-fixed".
var KINK_VALUES = ['kink-none', 'kink-transient', 'kink-fixed'];

// Gate is the fourth declared quantity and rides the complex group as its own
// class family, for the same reason kink rides the strand group. Whether the
// Mcm2-Mcm5 ring is open is a claim about the step and not a consequence of
// what occupies the position: a hexamer arrives open, threads DNA, and closes.
// Sealed is separate from closed because Cdc45 and GINS across the gate is a
// different claim from Mcm2 and Mcm5 in contact.
var GATE_VALUES = ['gate-na', 'gate-open', 'gate-closed', 'gate-sealed'];

// The Mcm4 NSD is the fifth declared quantity and rides the complex group
// beside gate. Whether the NSD sits on its seat, has been displaced from it,
// has been released from it without a mark, or has been deleted is a claim
// about the step and not a consequence of what occupies the position: the
// pair is loaded with the NSD seated, Dbf4 displaces it, the mcm5-bob1 panel
// draws it released, and the Mcm4 N-terminal deletion removes it. Deriving it
// from the marks would make the deletion indistinguishable from the
// unphosphorylated origin it bypasses. Duplicated as NSD_VALUES in
// tools/make_panels.py.
var NSD_VALUES = ['nsd-na', 'nsd-seated', 'nsd-displaced', 'nsd-released',
  'nsd-absent'];

var ZONE_CLASSES = ['z-unlicensed', 'z-specified', 'z-licensed', 'z-activated',
  'z-melted', 'z-extruded', 'z-replicated'];
var CAP_SLOTS = ['specification', 'licensing', 'activation', 'fork'];
var CAP_STATES = ['on', 'thin', 'off', 'na', 'lost'];

// The rungs have the same shape in every slot and do not mean the same
// thing, so the words are per slot.
var CAP_WORDS = {
  specification: { na: 'no origin', off: 'naked ARS', thin: 'ORC, no Cdc6',
    on: 'ORC-Cdc6 ring', lost: 'ORC evicted' },
  licensing: { na: 'no ORC yet', off: 'no MCM', thin: 'single hexamer',
    on: 'double hexamer', lost: 'ejected' },
  activation: { na: 'not licensed', off: 'not competent', thin: 'competent',
    on: 'CMG complete', lost: 'activation dead' },
  fork: { na: 'not activated', off: 'CMG, duplex', thin: 'melted',
    on: 'bidirectional fork', lost: 'collapse' }
};

function panelRoot(key) {
  // Position ids repeat across panels on purpose, so every lookup is scoped
  // to the active panel. Never document.getElementById for a substrate id.
  return document.querySelector('#stage svg.panelsvg[data-key="' + key + '"]');
}

function pick(el, allowed) {
  var i;
  for (i = 0; i < allowed.length; i += 1) {
    if (el.classList.contains(allowed[i])) { return allowed[i]; }
  }
  return null;
}

function setOneOf(el, allowed, value) {
  var i;
  for (i = 0; i < allowed.length; i += 1) { el.classList.remove(allowed[i]); }
  if (value) { el.classList.add(value); }
}

function shown(el) {
  if (!el) { return false; }
  var s = pick(el, STATES);
  return s === 'present' || s === 'arriving';
}

function runsOf(values, want) {
  var out = [], start = -1, i;
  for (i = 1; i <= GEO.NPOS; i += 1) {
    if (values[i] === want) {
      if (start < 0) { start = i; }
    } else if (start > 0) { out.push([start, i - 1]); start = -1; }
  }
  if (start > 0) { out.push([start, GEO.NPOS]); }
  return out;
}

function runsOfAny(values, want) {
  // SHARED: the runs of positions holding any of several values.
  //
  // The opened region is extruded at the two forks and replicated between
  // them, so anything that follows the outer edge of what the helicases have
  // passed has to read both values. Asking for one of them puts the fork marks
  // and the CMGs on the boundary between unwound and copied, which is a
  // boundary neither of them sits on.
  var out = [], start = -1, i, hit;
  for (i = 1; i <= GEO.NPOS; i += 1) {
    hit = want.indexOf(values[i]) >= 0;
    if (hit) {
      if (start < 0) { start = i; }
    } else if (start > 0) { out.push([start, i - 1]); start = -1; }
  }
  if (start > 0) { out.push([start, GEO.NPOS]); }
  return out;
}

function nsdOf(t, runs) {
  // MODEL: the NSD value declared over one run (TERMINAL). Same contract as
  // gateOf: every position in a run carries the same value, so the first one
  // answers for all of them, and the test suite fails the build if a run ever
  // disagrees with itself.
  if (!runs.length) { return null; }
  return t.n[runs[0][0]];
}

function gateOf(t, runs) {
  // MODEL: the gate declared over one run (TERMINAL). Every position in a run
  // carries the same value, so the first one answers for all of them, and the
  // test suite fails the build if a run ever disagrees with itself.
  if (!runs.length) { return null; }
  return t.g[runs[0][0]];
}

function stateOf(t, runs) {
  // MODEL: the presence state declared over one run (TERMINAL).
  //
  // Same contract as gateOf and nsdOf, and it exists for the same reason they
  // do. Occupancy alone cannot say that a complex is bound but no longer part
  // of what the panel is showing, and ORC after the double hexamer forms is
  // exactly that: still at the ARS, no longer in the mechanistic path. Without
  // this the frame could declare the state on the track and the glyph the
  // reader actually sees would ignore it.
  if (!runs.length) { return null; }
  return t.p[runs[0][0]];
}

function midX(i) { return GEO.X0 + (i - 1) * GEO.CW + GEO.CW / 2; }

function runCentre(run) {
  return (GEO.X0 + (run[0] - 1) * GEO.CW + GEO.X0 + run[1] * GEO.CW) / 2;
}

// === BASE CONTROLLER: runAnimation ========================================

var ANIM_STATE = { key: null, frame: 0, timer: null, playing: false };

function runAnimation(command, arg) {
  // BASE CONTROLLER: every animation command enters here.

  if (command === 'reset') { resetPanel(arg); return; }
  if (command === 'goto') { gotoFrame(arg); return; }
  if (command === 'play') { startPlayback(); return; }
  if (command === 'pause') { stopPlayback(); return; }
  if (command === 'step') { stepFrame(arg); return; }

  function resetPanel(key) {
    // SUB-CONTROLLER: put a panel back to its markup state and repaint.
    stopPlayback();
    ANIM_STATE.key = key;
    ANIM_STATE.frame = 0;
    matchTransitions(key);
    clearPanel(key);
    if (window.ANIM && window.ANIM[key]) { applyFrame(key, 0); }
    paintDerived(key);
    reportFrame();
  }

  function gotoFrame(n) {
    stopPlayback();
    var total = frameCount(ANIM_STATE.key);
    ANIM_STATE.frame = Math.max(0, Math.min(n, total - 1));
    clearPanel(ANIM_STATE.key);
    applyFrame(ANIM_STATE.key, ANIM_STATE.frame);
    paintDerived(ANIM_STATE.key);
    reportFrame();
  }

  function stepFrame(delta) {
    gotoFrame(ANIM_STATE.frame + delta);
  }

  function startPlayback() {
    var table = window.ANIM && window.ANIM[ANIM_STATE.key];
    if (!table) { return; }
    stopPlayback();
    ANIM_STATE.playing = true;
    ANIM_STATE.timer = setInterval(function () {
      var total = frameCount(ANIM_STATE.key);
      var next = ANIM_STATE.frame + 1;
      if (next >= total) { stopPlayback(); return; }
      ANIM_STATE.frame = next;
      clearPanel(ANIM_STATE.key);
      applyFrame(ANIM_STATE.key, next);
      paintDerived(ANIM_STATE.key);
      reportFrame();
    }, 1000 / (table.fps || 1.3));
    reportFrame();
  }

  function stopPlayback() {
    if (ANIM_STATE.timer) { clearInterval(ANIM_STATE.timer); }
    ANIM_STATE.timer = null;
    ANIM_STATE.playing = false;
  }

  function reportFrame() {
    if (typeof window.onFrameChange === 'function') {
      window.onFrameChange(ANIM_STATE.key, ANIM_STATE.frame,
        frameCount(ANIM_STATE.key), ANIM_STATE.playing);
    }
  }
}

// === SHARED FUNCTIONS: frame application ==================================

function matchTransitions(key, rootOverride) {
  // VIEW: stretch every transition on a panel to one frame interval (TERMINAL)
  //
  // Frames are keyframes, and the stylesheet's transitions interpolate between
  // them. A transition shorter than the frame interval moves and then holds,
  // which reads as a jump each frame; one that lasts exactly the interval
  // moves continuously from frame to frame, the way the presentation player
  // shows a step. So each panel takes its own frame rate's interval as the
  // length of every fade, move and travel.
  var root = rootOverride || panelRoot(key);
  var table = window.ANIM && window.ANIM[key];
  var ms;
  if (!root || !table) { return; }
  ms = Math.round(1000 / (table.fps || 1.3));
  root.style.setProperty('--t-fade', ms + 'ms');
  root.style.setProperty('--t-move', ms + 'ms');
  root.style.setProperty('--t-travel', ms + 'ms');
}

function frameCount(key) {
  var table = window.ANIM && window.ANIM[key];
  return table ? table.frames.length : 0;
}

function clearPanel(key, rootOverride) {
  // The reset strips every actor transform and restores the markup classes
  // of every track and effect. An element a frame fades must carry .fx, or
  // its faded state would survive this and smear into the next scrub.
  // rootOverride paints a copy of a panel elsewhere on the page (the origin
  // close-up plays steps 7 to 11 in its own copies of those panels).
  var root = rootOverride || panelRoot(key);
  if (!root) { return; }
  // A telomere panel keeps the engine it was drawn for (src/telo-engine.js).
  if (window.TELO && window.TELO.owns(key)) { window.TELO.clear(root); return; }
  var i, el, els;
  els = root.querySelectorAll('.strand, .cpx, .fx');
  for (i = 0; i < els.length; i += 1) {
    el = els[i];
    if (el.dataset.base === undefined) { el.dataset.base = el.getAttribute('class'); }
    el.setAttribute('class', el.dataset.base);
  }
  els = root.querySelectorAll('[id^="actor-"]');
  for (i = 0; i < els.length; i += 1) {
    els[i].removeAttribute('transform');
    els[i].classList.remove('off');
    // A derived glyph now carries a presence state as well as a position, and
    // neither is in its markup. paintDerived rewrites both on every frame, so
    // this is belt and braces rather than load bearing, but a state class left
    // on an actor by a panel the reader has scrubbed away from is exactly the
    // kind of smear the track reset above exists to prevent.
    setOneOf(els[i], STATES, null);
  }
}

function applyFrame(key, index, rootOverride) {
  var root = rootOverride || panelRoot(key);
  var table = window.ANIM && window.ANIM[key];
  if (!root || !table) { return; }
  if (window.TELO && window.TELO.owns(key)) { window.TELO.apply(root, key, index); return; }
  var frame = table.frames[index];
  if (!frame) { return; }
  var id, el, parts, k, tok;
  for (id in frame.tracks || {}) {
    if (Object.prototype.hasOwnProperty.call(frame.tracks, id)) {
      el = findId(root, id);
      if (el) {
        // A position track needs a value, a presence state and, on the strand
        // track, a kink state at the same time, and the handbook's map holds
        // one value per id. Frame tables write compound strings, and each
        // token is matched against the family it belongs to, so the order in
        // the string does not matter and an unknown token is ignored rather
        // than silently written as a class.
        parts = String(frame.tracks[id]).split(':');
        for (k = 0; k < parts.length; k += 1) {
          tok = parts[k];
          if (STATES.indexOf(tok) >= 0) { setOneOf(el, STATES, tok); }
          else if (KINK_VALUES.indexOf(tok) >= 0) { setOneOf(el, KINK_VALUES, tok); }
          else if (GATE_VALUES.indexOf(tok) >= 0) { setOneOf(el, GATE_VALUES, tok); }
          else if (NSD_VALUES.indexOf(tok) >= 0) { setOneOf(el, NSD_VALUES, tok); }
          else if (STRAND_VALUES.indexOf(tok) >= 0) { setOneOf(el, STRAND_VALUES, tok); }
          else if (CPX_VALUES.indexOf(tok) >= 0) { setOneOf(el, CPX_VALUES, tok); }
        }
      }
    }
  }
  for (id in frame.fx || {}) {
    if (Object.prototype.hasOwnProperty.call(frame.fx, id)) {
      // The far half of a split glyph answers to the same name with -b on the
      // end, so one frame entry moves and shows both halves of one object.
      [id, id + '-b'].forEach(function (name) {
        var target = findId(root, name);
        if (target) { setOneOf(target, STATES, frame.fx[id]); }
      });
    }
  }
  for (id in frame.actors || {}) {
    if (Object.prototype.hasOwnProperty.call(frame.actors, id)) {
      shiftActor(root, id, frame.actors[id]);
    }
  }
  // A live panel writes words that depend on the run (a firing time, the
  // firing order). Each frame that writes text writes all of it, so no reset
  // is needed for text.
  for (id in frame.text || {}) {
    if (Object.prototype.hasOwnProperty.call(frame.text, id)) {
      el = findId(root, id);
      if (el) { el.textContent = frame.text[id]; }
    }
  }
}

var ID_INDEX = (typeof WeakMap !== 'undefined') ? new WeakMap() : null;

function findId(root, id) {
  // SHARED: the first element under root with this id, as root.querySelector
  // would return it, from an index built once per root.
  //
  // A live chromosome frame names several hundred ids, and resolving each one
  // by walking the panel made a frame take seconds in jsdom. The index is
  // rebuilt whenever an element it holds has left its root, so a panel that is
  // mounted again is read afresh.
  var map = ID_INDEX ? ID_INDEX.get(root) : null, el, all, i;
  if (map) {
    el = map[id];
    if (el === undefined) { return null; }
    if (root.contains(el)) { return el; }
  }
  if (!ID_INDEX) { return root.querySelector('#' + id); }
  map = Object.create(null);
  all = root.querySelectorAll('[id]');
  for (i = 0; i < all.length; i += 1) {
    if (map[all[i].id] === undefined) { map[all[i].id] = all[i]; }
  }
  ID_INDEX.set(root, map);
  return map[id] === undefined ? null : map[id];
}

function companions(root, id) {
  // SHARED: an actor and its far-layer twin.
  //
  // A hexamer is a ring seen edge on, so its two arcs go into different layers
  // and one glyph needs two actor groups. They are one object and must never
  // hold two positions, so every write goes through here and the test suite
  // fails if the two ever carry different transforms.
  var out = [], i, el, ids = [id, id + '-b'];
  for (i = 0; i < ids.length; i += 1) {
    el = findId(root, ids[i]);
    if (el) { out.push(el); }
  }
  return out;
}

function shiftActor(root, id, off) {
  // VIEW: translate an actor and its twin by a declared offset (TERMINAL)
  //
  // A number is a slide along the substrate. A pair is a move off it, which is
  // what an arrival out of the nucleoplasm needs: the frames sample a curve and
  // the transition draws the chords between the samples.
  var els = companions(root, id), i;
  var dx = (off && off.length) ? off[0] : off;
  var dy = (off && off.length) ? off[1] : 0;
  for (i = 0; i < els.length; i += 1) {
    els[i].setAttribute('transform', 'translate(' + dx + ' ' + dy + ')');
  }
}

function moveActor(root, id, x) {
  // VIEW: put an actor and its twin at a derived x, or hide both (TERMINAL)
  var els = companions(root, id), i, base;
  for (i = 0; i < els.length; i += 1) {
    if (x === null) {
      els[i].classList.add('off');
      els[i].setAttribute('transform', 'translate(0 0)');
    } else {
      els[i].classList.remove('off');
      base = parseFloat(els[i].dataset.basex || '0');
      els[i].setAttribute('transform', 'translate(' + (x - base).toFixed(1) + ' 0)');
    }
  }
}

function setState(root, id, value) {
  // VIEW: write the declared presence state onto the pair (TERMINAL)
  //
  // The class lands on the actor groups themselves and the stylesheet works
  // the opacity from there, which is the same division of labour setNsd uses
  // for the forms of the NSD. A null clears the family, which is what a glyph
  // with no run on the track gets; .off then hides it regardless.
  var els = companions(root, id), i;
  for (i = 0; i < els.length; i += 1) { setOneOf(els[i], STATES, value); }
}

function setNsd(root, id, value) {
  // VIEW: write the declared NSD onto the pair and show its one form (TERMINAL)
  //
  // The class lands on the two .mcmdh groups. The pair carries three forms of
  // the NSD, each in its own .fx wrapper, and at most one of them is shown:
  // the seated form for nsd-seated, the displaced form for nsd-displaced, the
  // released form for nsd-released, and none for nsd-absent or nsd-na. The
  // wrappers are .fx so the reset puts them back to their markup state before
  // every frame, and no frame table names them, so this is the only writer.
  var els = companions(root, id), i, k, pairs, forms, f;
  if (!value) { return; }
  forms = [['.nsdseat', 'nsd-seated'], ['.nsdfree', 'nsd-displaced'],
    ['.nsdrel', 'nsd-released']];
  for (i = 0; i < els.length; i += 1) {
    pairs = els[i].querySelectorAll('.mcmdh');
    for (k = 0; k < pairs.length; k += 1) { setOneOf(pairs[k], NSD_VALUES, value); }
    for (k = 0; k < forms.length; k += 1) {
      f = els[i].querySelector(forms[k][0]);
      if (f) { setOneOf(f, STATES, value === forms[k][1] ? 'present' : 'gone'); }
    }
  }
}

function setGate(root, id, value) {
  // VIEW: write the declared gate onto both arcs of one hexamer (TERMINAL)
  var els = companions(root, id), i, k, arcs;
  if (!value) { return; }
  for (i = 0; i < els.length; i += 1) {
    arcs = els[i].querySelectorAll('.mcmarc');
    for (k = 0; k < arcs.length; k += 1) { setOneOf(arcs[k], GATE_VALUES, value); }
  }
}

// === MODEL SPECIFIC: the derived layer ====================================

function paintDerived(key, rootOverride) {
  // BASE CONTROLLER: everything computable from the declared layer is
  // computed here, on every frame, and never written into a frame table.
  var root = rootOverride || panelRoot(key);
  if (!root) { return; }
  if (window.TELO && window.TELO.owns(key)) { window.TELO.derive(root); return; }

  var tracks = readTracks(root);
  paintZones(root, tracks);
  paintOccupancy(root, tracks);
  paintForkLayer(root, tracks);
  paintLagging(root, tracks);
  paintStatus(root, tracks);

  function paintLagging(root, t) {
    // SUB-CONTROLLER: when each lagging piece has been laid.
    //
    // Leading synthesis runs with the fork, so a leading piece can follow its
    // own position's strand state. Lagging synthesis runs against the fork: a
    // fragment is primed where the fork is and then extended backward toward
    // the origin, finishing about the time the fork has travelled one more
    // fragment. No per-position value can carry that, because the order the
    // pieces are laid in is the reverse of the order the fork reaches them.
    // So the timing is derived here from how far the fork has gone, and the
    // stylesheet shows a piece once this marks it laid.
    //
    // The consequence is visible and correct: the stretch just behind each
    // fork carries a leading strand and no lagging one, and the last fragment
    // on each side is still unfinished when the fork leaves the frame.
    var reach = forkReach(t);
    var i;
    for (i = 1; i <= GEO.NPOS; i += 1) {
      markPieces(root, i, laidAt(i, reach));
    }

    function forkReach(t) {
      // MODEL: how far each fork has gone, counted outward from the origin in
      // positions (TERMINAL). Returns [left, right], zero where nothing has
      // opened on that side.
      var lo = 0, hi = 0, j;
      for (j = 1; j <= GEO.NPOS; j += 1) {
        if (t.s[j] && t.s[j] !== 'duplex') {
          if (!lo) { lo = j; }
          hi = j;
        }
      }
      if (!lo) { return [0, 0]; }
      return [GEO.FORK_SPLIT - lo + 1, hi - GEO.FORK_SPLIT];
    }

    function laidAt(i, reach) {
      // MODEL: whether the lagging piece at one position has been laid yet
      // (TERMINAL).
      //
      // d counts outward from the origin, so the fragment holding d spans
      // d - k + 1 to d - k + OKAZAKI_N, where k is the index within it. The
      // fragment is primed when the fork passes its outermost position and
      // fills inward from there, one position per position of fork travel.
      // That puts the piece at k in place once the fork has reached
      // d + 2 * (OKAZAKI_N - k), which is d itself for the primer at the
      // outer end and d + 2 * (OKAZAKI_N - 1) for the piece that closes the
      // fragment against the one before it.
      var left = i <= GEO.FORK_SPLIT;
      var d = left ? GEO.FORK_SPLIT - i + 1 : i - GEO.FORK_SPLIT;
      var k = (d - 1) % GEO.OKAZAKI_N + 1;
      return (left ? reach[0] : reach[1]) >= d + 2 * (GEO.OKAZAKI_N - k);
    }

    function markPieces(root, i, laid) {
      // VIEW: carry the answer onto the lagging pieces at one position
      // (TERMINAL).
      var els = root.querySelectorAll('#' + chunkId(i) + '-s .nasc.lag');
      var j;
      for (j = 0; j < els.length; j += 1) {
        els[j].classList.toggle('laid', laid);
      }
    }
  }

  function readTracks(root) {
    var s = {}, c = {}, g = {}, n = {}, p = {}, i, el;
    for (i = 1; i <= GEO.NPOS; i += 1) {
      el = findId(root, chunkId(i) + '-s');
      s[i] = el ? pick(el, STRAND_VALUES) : null;
      el = findId(root, chunkId(i) + '-c');
      c[i] = el ? pick(el, CPX_VALUES) : null;
      g[i] = el ? pick(el, GATE_VALUES) : null;
      n[i] = el ? pick(el, NSD_VALUES) : null;
      p[i] = el ? pick(el, STATES) : null;
    }
    return { s: s, c: c, g: g, n: n, p: p };
  }

  function paintZones(root, t) {
    // SUB-CONTROLLER: one tint per position, computed from both tracks.
    var i, el;
    for (i = 1; i <= GEO.NPOS; i += 1) {
      el = findId(root, chunkId(i) + '-z');
      if (el) { setOneOf(el, ZONE_CLASSES, zoneClass(t.s[i], t.c[i])); }
    }

    function zoneClass(s, c) {
      // MODEL: tint for one position (TERMINAL)
      if (s === 'replicated') { return 'z-replicated'; }
      if (s === 'extruded') { return 'z-extruded'; }
      if (s === 'melted') { return 'z-melted'; }
      if (c === 'cmg') { return 'z-activated'; }
      if (c === 'mcm1' || c === 'mcm2' || c === 'occm') { return 'z-licensed'; }
      if (c === 'orc') { return 'z-specified'; }
      return 'z-unlicensed';
    }
  }

  function paintOccupancy(root, t) {
    // SUB-CONTROLLER: position every glyph whose place follows from the
    // complex track, carry the declared gate and presence onto it, and hide
    // every nucleosome whose span is occupied.
    place(root, 'actor-orc', runsOf(t.c, 'orc'));
    place(root, 'actor-occm', runsOf(t.c, 'occm'));
    place(root, 'actor-mcm1', runsOf(t.c, 'mcm1'));
    place(root, 'actor-dh', runsOf(t.c, 'mcm2'));
    paintNucleosomes(root, t);

    function place(root, id, runs) {
      // SUB-CONTROLLER: one derived glyph, its position, its presence, its
      // gate, and the NSD of the pair. A glyph that is not a pair carries no
      // .mcmdh and no NSD forms, and the NSD write finds nothing to do.
      moveActor(root, id, runs.length ? runCentre(runs[0]) : null);
      setState(root, id, stateOf(t, runs));
      setGate(root, id, gateOf(t, runs));
      setNsd(root, id, nsdOf(t, runs));
    }

    function paintNucleosomes(root, t) {
      // VIEW: a nucleosome survives only where its whole span is naked duplex.
      //
      // Two things take one off. A factor bound over the span covers it, which
      // is what keeps a nucleosome from ever being drawn under a loaded
      // hexamer. A fork arriving anywhere in the span displaces it, which is
      // what the last panel shows: the octamer comes off ahead of the
      // helicase, and the span goes back to duplex nowhere, so nothing puts it
      // back within a run. The rule writes both ways so that scrubbing
      // backward through a panel restores what scrubbing forward removed. No
      // frame table names a nucleosome, so nothing else owns the class.
      var els = root.querySelectorAll('.nuc'), i, j, span, a, b, gone;
      for (i = 0; i < els.length; i += 1) {
        span = (els[i].getAttribute('data-span') || '').split(' ');
        a = linOf(span[0]);
        b = linOf(span[1]);
        gone = false;
        for (j = a; j <= b; j += 1) {
          if (t.c[j] !== 'naked' || (t.s[j] && t.s[j] !== 'duplex')) { gone = true; }
        }
        els[i].classList.toggle('gone', gone);
      }
    }
  }

  function paintForkLayer(root, t) {
    // SUB-CONTROLLER: the CMGs, the fork marks, RPA and the polymerases all
    // follow from the strand track. None of them has a resting place that
    // means anything, so each is given a defined position in the empty state.
    var cmgRuns = runsOf(t.c, 'cmg');
    // What the helicase has passed, unwound or unwound and copied. What RPA
    // sits on is the first of those two on its own.
    var copied = runsOfAny(t.s, ['extruded', 'replicated']);
    var extruded = runsOf(t.s, 'extruded');
    var opened = openBounds(t);
    var half = GEO.MCM_W / 2 + 3;
    var xl = null, xr = null;

    if (cmgRuns.length) {
      if (copied.length) {
        xl = GEO.X0 + (copied[0][0] - 1) * GEO.CW;
        xr = GEO.X0 + copied[copied.length - 1][1] * GEO.CW;
      } else if (cmgRuns.length > 1) {
        xl = runCentre(cmgRuns[0]);
        xr = runCentre(cmgRuns[cmgRuns.length - 1]);
      } else {
        xl = runCentre(cmgRuns[0]) - half;
        xr = runCentre(cmgRuns[0]) + half;
      }
    }
    offset(root, 'actor-cmg-l', xl);
    offset(root, 'actor-cmg-r', xr);
    setGate(root, 'actor-cmg-l', gateOf(t, cmgRuns));
    setGate(root, 'actor-cmg-r', gateOf(t, cmgRuns));

    offset(root, 'actor-fork-l', opened ? opened[0] : null);
    offset(root, 'actor-fork-r', opened ? opened[1] : null);
    offset(root, 'actor-rpa-l', extruded.length ? runCentre(extruded[0]) : null);
    offset(root, 'actor-rpa-r',
      extruded.length ? runCentre(extruded[extruded.length - 1]) : null);
    // The polymerases hang off the CMG positions, so they are drawn only when
    // there is a CMG position to hang off. Reading xl here when no cmg run
    // exists would translate them by NaN. Pol epsilon runs at the front of its
    // helicase on the leading template; Pol alpha works behind the fork on the
    // lagging one, which is why the two take opposite signs on one fork. The
    // 70 is POLA_DX in tools/make_panels.py, where the CST firing model for Pol
    // alpha places the Stn1 C half against this glyph; the suite holds the two
    // equal.
    offset(root, 'actor-pole-l', (xl !== null && copied.length) ? xl - 40 : null);
    offset(root, 'actor-pola-l', (xl !== null && copied.length) ? xl + 70 : null);
    offset(root, 'actor-pole-r', (xr !== null && copied.length) ? xr + 40 : null);
    offset(root, 'actor-pola-r', (xr !== null && copied.length) ? xr - 70 : null);
    // Mrc1 with Tof1-Csm3 rides the front of each CMG, and each fork's dNTP
    // streams hang off it; both are drawn at the CMG's own base, so they take
    // the CMG's position.
    offset(root, 'actor-mrc-l', (xl !== null && copied.length) ? xl : null);
    offset(root, 'actor-mrc-r', (xr !== null && copied.length) ? xr : null);
    offset(root, 'actor-dntp-l', (xl !== null && copied.length) ? xl : null);
    offset(root, 'actor-dntp-r', (xr !== null && copied.length) ? xr : null);

    function openBounds(t) {
      // MODEL: outer edges of the run of positions that are not duplex
      // (TERMINAL). Returns null when nothing has opened.
      var lo = 0, hi = 0, i;
      for (i = 1; i <= GEO.NPOS; i += 1) {
        if (t.s[i] && t.s[i] !== 'duplex') {
          if (!lo) { lo = i; }
          hi = i;
        }
      }
      if (!lo) { return null; }
      return [GEO.X0 + (lo - 1) * GEO.CW, GEO.X0 + hi * GEO.CW];
    }

    function offset(root, id, x) {
      // VIEW: translate a derived actor and its twin, or hide both (TERMINAL)
      moveActor(root, id, x);
    }
  }

  function paintStatus(root, t) {
    // SUB-CONTROLLER: four slots, every panel, every frame.
    var flags = readFlags(root);
    var caps = deriveCaps(t, flags);
    var i, slot, el, word;
    for (i = 0; i < CAP_SLOTS.length; i += 1) {
      slot = CAP_SLOTS[i];
      el = root.querySelector('#cap-' + slot);
      if (el) {
        setOneOf(el, CAP_STATES, caps[slot]);
        word = el.querySelector('.capword');
        if (word) { word.textContent = CAP_WORDS[slot][caps[slot]]; }
      }
    }

    function readFlags(root) {
      // MODEL: read the declared layer for the marks the slots depend on
      // (TERMINAL). Nothing here is a second source of truth: each flag is
      // the visibility of one declared effect.
      var lost = {}, i, slot;
      for (i = 0; i < CAP_SLOTS.length; i += 1) {
        slot = CAP_SLOTS[i];
        lost[slot] = shown(root.querySelector('#fx-lost-' + slot));
      }
      return {
        cdc6: shown(root.querySelector('#fx-cdc6')),
        phos: shown(root.querySelector('#fx-phos')),
        cdc45: shown(root.querySelector('#fx-cdc45')),
        lost: lost
      };
    }
  }
}

function deriveCaps(t, flags) {
  // MODEL: the four derived slots. Mirrored exactly by derive_caps() in
  // tools/make_panels.py, and the test suite compares the two. The axis is
  // epistemic: a slot reports the highest level the evidence establishes at
  // that step, not a molecular count.
  //
  // The presence state on the complex track is deliberately not read here. A
  // dimmed ORC is still bound to the ARS, so Specification still reports
  // ORC-Cdc6 or ORC alone; what the dim says is that the initiator has no
  // further job in the reaction, and that is a statement about the mechanism
  // and not about what the evidence establishes at the origin.
  var vals = [], strands = [], nsds = [], i;
  for (i = 1; i <= GEO.NPOS; i += 1) {
    vals.push(t.c[i]);
    strands.push(t.s[i]);
    nsds.push(t.n[i]);
  }
  var has = function (a, v) { return a.indexOf(v) >= 0; };
  var hasOrc = has(vals, 'orc');
  var hasOccm = has(vals, 'occm');
  var hasM1 = has(vals, 'mcm1');
  var hasM2 = has(vals, 'mcm2');
  var hasCmg = has(vals, 'cmg');
  var melted = has(strands, 'melted');
  // A replicated position is an extruded one that has been copied, so both
  // report the same slot. Mirrored in derive_caps().
  var extruded = has(strands, 'extruded') || has(strands, 'replicated');
  // A pair is competent once the NSD inhibition is relieved or Cdc45 is on the
  // origin. A pair whose NSD has been deleted has nothing to relieve, and a
  // released NSD is the figure's picture of the inhibition lifted without a
  // mark, so both count with no mark on them; a displaced NSD alone does not,
  // because the inhibition is relieved by phosphorylation and not by Dbf4
  // binding. Mirrored in derive_caps().
  var relieved = has(nsds, 'nsd-absent') || has(nsds, 'nsd-released');
  var out = {};

  out.specification = (hasOrc && flags.cdc6) ? 'on' : (hasOrc ? 'thin' : 'off');

  if (hasM2 || hasCmg) { out.licensing = 'on'; }
  else if (hasM1 || hasOccm) { out.licensing = 'thin'; }
  else if (hasOrc) { out.licensing = 'off'; }
  else { out.licensing = 'na'; }

  if (hasCmg) { out.activation = 'on'; }
  else if (hasM2 && (relieved || flags.phos || flags.cdc45)) { out.activation = 'thin'; }
  else if (hasM1 || hasM2 || hasOccm) { out.activation = 'off'; }
  else { out.activation = 'na'; }

  if (extruded) { out.fork = 'on'; }
  else if (melted) { out.fork = 'thin'; }
  else if (hasCmg) { out.fork = 'off'; }
  else { out.fork = 'na'; }

  for (i = 0; i < CAP_SLOTS.length; i += 1) {
    if (flags.lost && flags.lost[CAP_SLOTS[i]]) { out[CAP_SLOTS[i]] = 'lost'; }
  }
  return out;
}

if (typeof window !== 'undefined') {
  window.GEO = GEO;
  window.chunkId = chunkId;
  window.linOf = linOf;
  window.deriveCaps = deriveCaps;
  window.GATE_VALUES = GATE_VALUES;
  window.NSD_VALUES = NSD_VALUES;
  window.STATES = STATES;
  window.runAnimation = runAnimation;
  window.paintDerived = paintDerived;
  window.applyFrame = applyFrame;
  window.clearPanel = clearPanel;
  window.matchTransitions = matchTransitions;
}