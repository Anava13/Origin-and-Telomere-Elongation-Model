/* The live chromosome panel: the genotype picker, the bob1 switch, and the
   run buttons. Each run calls CHROM_RULE.simulate with a seed, builds its
   frames with buildChromFrames and installs them as ANIM.chrLIVE, so the
   engine plays a live run exactly as it plays a hand-written table. "Replay
   this run" reuses the seed, so the same run plays again; "New run" draws a
   fresh one. The first run is installed when this script loads, so the panel
   has a frame table before the workflow selects it. */

// The origin panel's states, in the order its frame table lists them.
var CI_ORIGIN_STATES = ['orc', 'cdc6', 'lic', 'mark', 'bob', 'opened', 'cleared', 'passiveR', 'passiveL',
  'mark1', 'mark2', 'mark3'];

// The pair's four tail marks in the order DDK places them, as
// tools/make_panels.py MCM_MARK_ORDER names their wrappers (fx-pm-<site>).
var MARK_ORDER = ['l6', 'r6', 'l4', 'nsd'];

var CHROM_LIVE = { key: 'chrLIVE', genotype: 'wt', bob1: false, hu: false, checkpoint: 'wt',
  alleles: {}, ak: 'none', preset: null, presetRun: null,
  focus: 'L1', follow: 'right', seed: null, sched: null, cruiseTimer: null,
  view: 'chrom', telFocus: 'tel-R-s2', telBp: null };

// === BASE CONTROLLER: runChromLive ========================================

function runChromLive(command, arg) {
  // BASE CONTROLLER: every change to the live run enters here.

  if (command === 'genotype') { setChoice('genotype', arg); startRun(null, false); return; }
  if (command === 'bob1') { setChoice('bob1', !!arg); startRun(null, false); return; }
  if (command === 'hu') { setChoice('hu', !!arg); startRun(null, false); return; }
  if (command === 'checkpoint') { setChoice('checkpoint', arg); startRun(null, false); return; }
  if (command === 'allele') { setAllele(arg[0], !!arg[1]); startRun(null, false); return; }
  if (command === 'ak') { setChoice('ak', arg); startRun(null, false); return; }
  if (command === 'preset') { choosePreset(arg); return; }
  if (command === 'new') { startRun(null, true); return; }
  if (command === 'replay') { startRun(CHROM_LIVE.seed, true); return; }
  if (command === 'install') { startRun(null, false); return; }
  if (command === 'focus') { setChoice('focus', arg); refocus(); return; }
  if (command === 'telfocus') { CHROM_LIVE.telFocus = arg; refocus(); return; }
  if (command === 'view') {
    // The telomere view plays its own run, the one-origin chromosome, so a
    // change of view recomputes the run with the same seed.
    var was = CHROM_LIVE.view;
    CHROM_LIVE.view = arg === 'tel' ? 'tel' : 'chrom';
    showView2();
    if (was !== CHROM_LIVE.view && CHROM_LIVE.sched) { startRun(CHROM_LIVE.seed, false); } else { refocus(); }
    return;
  }
  if (command === 'telbp') { setChoice('telBp', arg); startRun(null, false); return; }

  function showView2() {
    // VIEW: the panel and the close-up show the chosen view, and its button is marked (TERMINAL)
    if (typeof document === 'undefined') { return; }
    var panel = document.querySelector('#stage svg.panelsvg[data-key="' + CHROM_LIVE.key + '"]');
    var wrap = document.getElementById('chrinsetwrap');
    var buttons = document.querySelectorAll('#chrview button'), i;
    if (panel) { panel.setAttribute('data-view', CHROM_LIVE.view); }
    if (wrap) { wrap.setAttribute('data-view', CHROM_LIVE.view); }
    for (i = 0; i < buttons.length; i += 1) {
      buttons[i].classList.toggle('on', buttons[i].getAttribute('data-view') === CHROM_LIVE.view);
    }
  }
  if (command === 'follow') { setChoice('follow', arg); refocus(); markFollow(); return; }

  function markFollow() {
    // VIEW: the camera button for the current choice is marked (TERMINAL)
    if (typeof document === 'undefined') { return; }
    var buttons = document.querySelectorAll('#chrfollow button'), i;
    for (i = 0; i < buttons.length; i += 1) {
      buttons[i].classList.toggle('on', buttons[i].getAttribute('data-follow') === CHROM_LIVE.follow);
    }
  }
  if (command === 'inset') { paintInset(arg); return; }
  if (command === 'cruise') { cruise(arg); return; }
  if (command === 'insetInto') { paintInsetInto(arg.root, arg.table, arg.frame); return; }

  function cruise(from) {
    // SUB-CONTROLLER: keep the followed fork's close-up moving past the run's frames, or stop it
    // A guided lesson uses this to hold a fork's steady state on screen: the
    // view of frame 'from' is carried on, one step per frame interval, the
    // fork moving and stripping nucleosomes ahead of it for as long as it runs.
    // false stops it; the next frame the engine paints takes over.

    var table = window.ANIM && window.ANIM[CHROM_LIVE.key], root, state, ms;
    if (CHROM_LIVE.cruiseTimer) { clearInterval(CHROM_LIVE.cruiseTimer); CHROM_LIVE.cruiseTimer = null; }
    if (from === false || from === null || from === undefined || typeof document === 'undefined') { return; }
    root = document.getElementById('chrinset');
    state = startState(table && table.frames[from] && table.frames[from].inset.view);
    if (!root || !state) { return; }
    ms = Math.round(1000 / (table.fps || 2));
    CHROM_LIVE.cruiseTimer = setInterval(function () {
      stepState(state);
      showView(root, state, +(root.dataset.ciframe || 0) + 1);
    }, ms);

    function startState(v) {
      // MODEL: a copy of an elongation view that can move on, or null (TERMINAL)
      if (!v || v.kind !== 'elong' || v.leave || (v.collapsed && !v.runOn)) { return null; }
      var c = JSON.parse(JSON.stringify(v));
      c.kmrc = false;
      c.kr53 = false;
      return c;
    }

    function stepState(v) {
      // MODEL: one frame interval on: the fork moves, and a runaway helicase leaves more bare template (TERMINAL)
      if (v.runOn) { v.bare = Math.min(30, v.bare + 2); v.u += 2; }
      else { v.u += Math.max(1, Math.round(2 * v.speed)); }
    }
  }

  function refocus() {
    // SUB-CONTROLLER: rebuild the run's frames for the new origin, keep the frame, repaint

    rebuildFrames();
    moveRing();
    showSameMoment();

    function showSameMoment() {
      // VIEW: the rebuilt run may have a different number of frames (the
      // firing interlude moves with the selected origin), so keep the frame
      // index inside the table and repaint the panel and the close-up (TERMINAL)
      var table = window.ANIM && window.ANIM[CHROM_LIVE.key];
      var frame = window.ANIM_STATE ? window.ANIM_STATE.frame : 0;
      if (!table) { return; }
      frame = Math.max(0, Math.min(frame, table.frames.length - 1));
      if (window.ANIM_STATE && window.ANIM_STATE.key === CHROM_LIVE.key && typeof window.runAnimation === 'function') {
        window.runAnimation('goto', frame);
      } else {
        paintInset(frame);
      }
    }

    function rebuildFrames() {
      // MODEL: the same run's frames with close-up states for the selected origin (TERMINAL)
      if (!CHROM_LIVE.sched) { return; }
      window.ANIM[CHROM_LIVE.key] = buildChromFrames(CHROM_LIVE.sched, CHROM_GEOM, liveFocus(),
        CHROM_LIVE.follow, interludeSteps(), CHROM_LIVE.pair || null, CHROM_LIVE.alsoSites || null);
    }

    function moveRing() {
      // VIEW: the dashed ring sits on the selected origin (TERMINAL)
      if (typeof document === 'undefined') { return; }
      var ring = document.getElementById('chrsel'), i, x = null;
      for (i = 0; i < CHROM_GEOM.origins.length; i += 1) {
        if (CHROM_GEOM.origins[i].name === CHROM_LIVE.focus) {
          x = CHROM_GEOM.x0 + CHROM_GEOM.origins[i].position * CHROM_GEOM.kbScale;
        }
      }
      if (ring && x !== null) {
        ring.setAttribute('transform', 'translate(' + (x - parseFloat(ring.dataset.basex)).toFixed(1) + ' 0)');
      }
    }
  }

  function trackFork(copy, track) {
    // VIEW: slide a step-panel copy so the followed fork's CMG sits where the fork scene draws it (TERMINAL)
    // The copy's camera group carries a transitioned transform, so the camera
    // glides with the fork as step 11 plays and ends exactly on the picture the
    // fork scene opens with.
    var cam = copy.querySelector('.cistepcam'), cmg, base, m, dx = 0;
    if (!cam) { return; }
    if (track) {
      cmg = findId(copy, 'actor-cmg-' + (track === 'right' ? 'r' : 'l'));
      if (cmg) {
        base = parseFloat(cmg.getAttribute('data-basex') || '0');
        m = /translate\(\s*(-?[\d.]+)/.exec(cmg.getAttribute('transform') || '');
        dx = CHROM_GEOM.ciStepX0 + CHROM_GEOM.ciFx / CHROM_GEOM.ciS - (base + (m ? parseFloat(m[1]) : 0));
      }
    }
    cam.setAttribute('transform', 'translate(' + dx.toFixed(1) + ' 0)');
  }

  function stepCopy(root, key) {
    // VIEW: the close-up's copy of one step panel, made on first use (TERMINAL)
    // Its definitions (clip paths, patterns, markers) are renamed so nothing
    // in the copy points into the hidden original; every other id is kept,
    // because the engine paints the copy by the panel's own ids.
    var found = root.querySelector('svg.cistep[data-step="' + key + '"]');
    var src, copy, defsIds, html, holder, pre = (root.getAttribute('data-ciprefix') || '') + 'ci-' + key + '-';
    if (found) { return found; }
    src = document.querySelector('#stage svg.panelsvg[data-key="' + key + '"]');
    if (!src) { return null; }
    html = src.outerHTML;
    defsIds = [];
    Array.prototype.forEach.call(src.querySelectorAll('clipPath[id], pattern[id], marker[id], linearGradient[id], radialGradient[id], mask[id], filter[id]'),
      function (d) { defsIds.push(d.id); });
    defsIds.forEach(function (id) {
      var safe = id.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      html = html.replace(new RegExp('id="' + safe + '"', 'g'), 'id="' + pre + id + '"')
        .replace(new RegExp('url\\(#' + safe + '\\)', 'g'), 'url(#' + pre + id + ')')
        .replace(new RegExp('href="#' + safe + '"', 'g'), 'href="#' + pre + id + '"');
    });
    holder = document.createElementNS('http://www.w3.org/2000/svg', 'g');
    holder.innerHTML = html;
    copy = holder.firstChild;
    // A telomere workflow panel keeps its scope class, so its own sheet styles it.
    copy.setAttribute('class', /^tw-/.test(key) ? 'cistep telo' : 'cistep');
    copy.removeAttribute('data-key');
    copy.setAttribute('data-step', key);
    copy.setAttribute('x', '0');
    copy.setAttribute('y', '0');
    copy.setAttribute('width', String(CHROM_GEOM.ciW));
    copy.setAttribute('height', String(CHROM_GEOM.ciH));
    copy.setAttribute('viewBox', /^tw-/.test(key) ? CHROM_GEOM.twView : CHROM_GEOM.ciStepView);
    // The copy takes the close-up's timing, not the step panel's, and gets a
    // camera group so it can follow a fork.
    copy.removeAttribute('style');
    var camg = document.createElementNS('http://www.w3.org/2000/svg', 'g');
    camg.setAttribute('class', 'cistepcam');
    while (copy.firstChild) { camg.appendChild(copy.firstChild); }
    copy.appendChild(camg);
    copy.style.opacity = '0';
    root.insertBefore(copy, root.querySelector('#ci-leftcol'));
    return copy;
  }

  function paintInset(frameIndex) {
    // VIEW: write one frame's close-up states, offsets and words into the close-up (TERMINAL)
    if (typeof document === 'undefined') { return; }
    paintInsetInto(document.getElementById('chrinset'), window.ANIM && window.ANIM[CHROM_LIVE.key], frameIndex);
  }

  function paintInsetInto(root, table, frameIndex) {
    // VIEW: one frame of a run's close-up, painted into a given close-up root (TERMINAL)
    // The live close-up is one root; a guided lesson can keep a second root
    // (a copy of the close-up whose definitions carry their own prefix) and
    // paint another run's close-up into it, frame by frame.
    var frame = table && table.frames[frameIndex];
    var inset = frame && frame.inset, id, el, k, names, states = ['gone', 'fading', 'arriving', 'present'];
    if (!root || !inset) { return; }
    for (id in inset.fx) {
      if (Object.prototype.hasOwnProperty.call(inset.fx, id)) {
        names = [id, id + '-b'];
        for (k = 0; k < names.length; k += 1) {
          el = findId(root, names[k]);
          if (el) {
            states.forEach(function (st) { el.classList.remove(st); });
            el.classList.add(inset.fx[id]);
          }
        }
      }
    }
    for (id in inset.actors) {
      if (Object.prototype.hasOwnProperty.call(inset.actors, id)) {
        el = findId(root, id);
        if (el) { el.setAttribute('transform', 'translate(' + inset.actors[id][0] + ' ' + inset.actors[id][1] + ')'); }
      }
    }
    for (id in inset.text) {
      if (Object.prototype.hasOwnProperty.call(inset.text, id)) {
        el = findId(root, id);
        if (el && id === 'ci-line3') { wrapLine(root, el, inset.text[id]); }
        else if (el) { el.textContent = inset.text[id]; }
      }
    }
    // Every change takes one frame interval, the chromosome panel's, so the
    // close-up moves between frames as the panels do.
    // Moves run a little past the interval, so a frame that lands late
    // finds the actors still moving.
    var ms = Math.round(1000 / (table.fps || 2));
    root.style.setProperty('--t-fade', ms + 'ms');
    root.style.setProperty('--t-move', Math.round(ms * 1.1) + 'ms');
    root.style.setProperty('--t-travel', Math.round(ms * 1.1) + 'ms');
    showView(root, inset.view, frameIndex);
  }

  // === SHARED FUNCTIONS: the close-up's panels ===

  function wrapLine(root, el, words) {
    // VIEW: the third status line, on a second row when it is wider than the close-up (TERMINAL)
    // The header's background grows to hold the second row. Without text
    // measurement (outside a browser) the line stays on one row.
    var max = 388, ns = 'http://www.w3.org/2000/svg', bg = findId(root, 'ci-headbg'), x = el.getAttribute('x');
    var parts = String(words).split(' '), rows = [''], i, t, probe;
    el.textContent = words;
    if (typeof el.getComputedTextLength !== 'function' || el.getComputedTextLength() <= max) {
      if (bg) { bg.setAttribute('height', '56'); }
      return;
    }
    el.textContent = '';
    probe = document.createElementNS(ns, 'tspan');
    el.appendChild(probe);
    for (i = 0; i < parts.length; i += 1) {
      t = rows[rows.length - 1] ? rows[rows.length - 1] + ' ' + parts[i] : parts[i];
      probe.textContent = t;
      if (probe.getComputedTextLength() > max && rows[rows.length - 1] && rows.length < 2) { rows.push(parts[i]); }
      else { rows[rows.length - 1] = t; }
    }
    el.textContent = '';
    rows.forEach(function (r, k) {
      var sp = document.createElementNS(ns, 'tspan');
      sp.setAttribute('x', x);
      if (k) { sp.setAttribute('dy', '12'); }
      sp.textContent = r;
      el.appendChild(sp);
    });
    if (bg) { bg.setAttribute('height', String(56 + 12 * (rows.length - 1))); }
  }

  function showView(root, v, frameIndex) {
    // SUB-CONTROLLER: show and paint the panel this frame's view names.
    // A frame that does not follow the last one shown (a scrub, a new run, a
    // new origin) is painted at once. A change of panel happens between two
    // frames that show the same picture, so it too is made at once; a fork's
    // elongation panel taking over from step 11 is first shown as it stood
    // under step 11, and then moves on.
    var jump = root.dataset.ciframe !== String(frameIndex - 1);
    var target = viewPanel(root, v), under = null, key, from, handover;
    if (!v || !target) { return; }
    root.dataset.ciframe = String(frameIndex);
    if (v.kind === 'step' && v.under) { under = stepCopy(root, 'cielong-' + v.under + (v.b ? '-b' : '')); }
    key = target.getAttribute('data-step');
    from = root.dataset.ciview || '';
    handover = !jump && /^step11/.test(from) && (v.kind === 'origin' || target.dataset.p !== undefined);
    if (jump || from !== key) {
      // The new panel is shown at once in this frame's state, with the
      // camera where the last panel's was; the camera then moves on, so a
      // step that starts riding a fork glides there from where it was.
      snap(root, function () {
        var cam = jump ? null : +(root.dataset.cicam || 0);
        if (handover && v.kind === 'elong') { drawElong(target, v.side, +target.dataset.p, null, false, +target.dataset.ext); }
        else if (handover) { paintPanel(root, target, { kind: 'origin', panel: v.panel, state: 'opened' }, true); }
        else { paintPanel(root, target, v, true); }
        if (under) { paintUnder(root, under, v); }
        if (cam !== null && !handover) { setCam(target, cam); if (under) { setCam(under, cam); } }
        if (jump) { trackFork(target, trackOf(v)); if (under) { trackFork(under, trackOf(v)); } }
        showOnly(root, target, under);
      });
      root.dataset.ciview = key;
      if (!handover) {
        trackFork(target, trackOf(v));
        if (under) { trackFork(under, trackOf(v)); }
        root.dataset.cicam = String(camOf(target));
        return;
      }
    }
    paintPanel(root, target, v, false);
    if (under) { paintUnder(root, under, v); }
    trackFork(target, trackOf(v));
    if (under) { trackFork(under, trackOf(v)); }
    root.dataset.cicam = String(camOf(target));
  }

  function trackOf(v) {
    // MODEL: which fork, if any, the camera rides in a view (TERMINAL)
    if (v.kind === 'elong' || v.kind === 'term') { return v.side === 'r' ? 'right' : 'left'; }
    return v.kind === 'step' ? v.track : null;
  }

  function camOf(copy) {
    // MODEL: where a panel's camera stands (TERMINAL)
    var cam = copy.querySelector('.cistepcam');
    var m = cam ? /translate\(\s*(-?[\d.]+)/.exec(cam.getAttribute('transform') || '') : null;
    return m ? parseFloat(m[1]) : 0;
  }

  function setCam(copy, dx) {
    // VIEW: stand a panel's camera at dx (TERMINAL)
    var cam = copy.querySelector('.cistepcam');
    if (cam) { cam.setAttribute('transform', 'translate(' + dx.toFixed(1) + ' 0)'); }
  }

  function viewPanel(root, v) {
    // MODEL: the close-up panel a view is shown on (TERMINAL)
    if (!v) { return null; }
    if (v.kind === 'origin') { return stepCopy(root, v.panel); }
    if (v.kind === 'elong') { return stepCopy(root, 'cielong-' + v.side + (v.b ? '-b' : '')); }
    if (v.kind === 'passive') { return stepCopy(root, 'cipass-' + v.side + (v.b ? '-b' : '')); }
    if (v.kind === 'term') { return stepCopy(root, 'citerm' + (v.b ? '-b' : '')); }
    if (v.kind === 'cen') { return stepCopy(root, 'cicen'); }
    return stepCopy(root, v.key);
  }

  function twFrame(v) {
    // MODEL: the frame of a telomere workflow panel a telomere view's progress lands on (TERMINAL)
    // A step sampled n times lands on frames 0 to n - 1 in turn.
    var n = window.TELO ? window.TELO.frameTotal(v.key) : 1;
    // Frame times are rounded to 1e-4 min, so the sample is taken to the nearest frame.
    return Math.max(0, Math.min(n - 1, Math.round((v.progress || 0) * n)));
  }

  function paintPanel(root, copy, v, instant) {
    // VIEW: one panel to this frame's state, by the engine's own functions (TERMINAL)
    var key;
    if (v.kind === 'elong') { paintElong(root, copy, v, instant); return; }
    if (v.kind === 'passive') { drawPassive(copy, v); return; }
    if (v.kind === 'term') { drawTerm(copy, v); return; }
    if (v.kind === 'cen') { window.applyFrame('cicen', CHROM_GEOM.ciCenStates.indexOf(v.state), copy); return; }
    if (v.kind === 'tw') {
      window.clearPanel(v.key, copy);
      window.applyFrame(v.key, twFrame(v), copy);
      window.paintDerived(v.key, copy);
      return;
    }
    key = v.kind === 'origin' ? v.panel : (v.table || v.key);
    window.clearPanel(key, copy);
    window.applyFrame(key, v.kind === 'origin' ? CI_ORIGIN_STATES.indexOf(v.state) : v.frame, copy);
    window.paintDerived(key, copy);
  }

  function paintUnder(root, under, v) {
    // VIEW: the followed fork's elongation panel under step 11, clipped to the DNA past the step panel's end (TERMINAL)
    // It takes the fork's place from the step copy just painted, so the DNA
    // ahead of the fork in it lines up with the step panel's own.
    var copy = stepCopy(root, v.key), i, el, st, ends = [], ext = 0;
    for (i = 1; i <= GEO.NPOS; i += 1) {
      el = findId(copy, chunkId(i) + '-s');
      st = el ? pick(el, STRAND_VALUES) : 'duplex';
      if (st && st !== 'duplex') { ends.push([i, st]); }
    }
    if (!ends.length) { return; }
    var tip = v.under === 'r' ? ends[ends.length - 1][0] : ends[0][0];
    ends.forEach(function (e) { if (e[1] === 'extruded' && Math.abs(e[0] - tip) < 12) { ext += 1; } });
    drawElong(under, v.under, tip, null, true, Math.max(1, Math.min(ext, 6)));
  }

  function paintElong(root, copy, v, instant) {
    // VIEW: a fork's elongation panel to this frame, moving its strip back one fragment when the fork reaches the window's end (TERMINAL)
    // The strip repeats every fragment, so the fork stepped back one fragment
    // is the same picture; that step is drawn at once and the frame's move
    // then runs from it.
    var E = CHROM_GEOM.ciElong, side = v.side, p = elongPos(side, v.u), prev = copy.dataset.p;
    var n = E.okazaki;
    if (!instant && prev !== undefined && ((side === 'r' && p < +prev) || (side === 'l' && p > +prev))) {
      snap(root, function () {
        drawElong(copy, side, side === 'r' ? +prev - n : +prev + n, v, false, +copy.dataset.ext);
        trackFork(copy, side === 'r' ? 'right' : 'left');
      });
    }
    drawElong(copy, side, p, v, false, null);
  }

  function elongPos(side, u) {
    // MODEL: where the followed fork stands on its elongation panel after u positions of travel (TERMINAL)
    var E = CHROM_GEOM.ciElong, w = E.wrap[side], n = E.okazaki, q;
    if (side === 'r') {
      q = E.start.r + u;
      return q < w[1] ? q : w[0] + ((q - w[0]) % n);
    }
    q = E.start.l - u;
    return q >= w[0] ? q : w[1] - ((w[1] - q) % n);
  }

  function drawElong(copy, side, p, v, under, extOver) {
    // VIEW: paint a fork's elongation panel with its fork at position p (TERMINAL)
    // The strand, tint, lagging and nucleosome rules are the step panels'
    // (paintZones, paintLagging, paintNucleosomes, paintForkLayer), written
    // for this panel's positions, which run past the step panels' 46. A
    // stalled fork's bare positions lie next to the helicase: unwound, no new
    // strand, one RPA each. Everything that leaves goes off the page: the
    // replisome up when the fork ends, its dNTP streams back where they came
    // from; RPA and Mec1 stay on the single strands a collapsed fork leaves.
    var E = CHROM_GEOM.ciElong, w = v || {}, bare = w.bare || 0;
    var ext = extOver || (E.ext + bare), el;
    paintStrip(copy, { lo: E.range[side][0], hi: E.range[side][1], side: side, p: p, ext: ext, bare: bare,
      split: E.split, zone: function (i, st) {
        if (under && (side === 'r' ? i <= GEO.NPOS : i >= 1)) { return null; }
        return st === 'replicated' ? 'z-replicated' : (st === 'extruded' ? 'z-extruded' : 'z-unlicensed');
      } });
    placeFork(copy, side, p, w, bare);
    copy.classList.toggle('ci-moving', !under && (w.speed || 0) > 1e-6 && !w.leave);
    el = copy.querySelector('.ciclip');
    if (el) {
      if (under) { el.setAttribute('clip-path', 'url(#cielong-' + side + '-ahead)'); }
      else { el.removeAttribute('clip-path'); }
    }
    copy.dataset.p = String(p);
    copy.dataset.ext = String(ext);
  }

  function drawPassive(copy, v) {
    // VIEW: a fork from a neighbouring origin crossing this one: it pushes the double hexamer ahead and Rrm3 lifts it off (TERMINAL)
    var P = CHROM_GEOM.ciPass, E = CHROM_GEOM.ciElong, side = v.side, p = v.p, sgn = side === 'r' ? 1 : -1;
    var xf = side === 'r' ? E.x0 + p * E.cw : E.x0 + (p - 1) * E.cw;
    var dx = side === 'r' ? Math.max(0, xf - P.dhLeft) : Math.min(0, xf - P.dhRight);
    var gone = Math.abs(dx) > 60, push = gone ? sgn * 64 : dx, i, el;
    paintStrip(copy, { lo: P.range[0], hi: P.range[1], side: side, p: p, ext: E.ext, bare: 0,
      split: P.split[side], zone: function (i, st) {
        if (st === 'replicated') { return 'z-replicated'; }
        if (st === 'extruded') { return 'z-extruded'; }
        if (i >= P.ars[0] && i <= P.ars[1]) { return 'z-specified'; }
        if (!gone && i >= P.dh[0] && i <= P.dh[1]) { return 'z-licensed'; }
        return 'z-unlicensed';
      } });
    for (i = P.ars[0]; i <= P.dh[1]; i += 1) {
      el = findId(copy, elongId(i) + '-c');
      if (!el) { continue; }
      if (i <= P.ars[1]) { setOneOf(el, CPX_VALUES, 'orc'); setOneOf(el, STATES, 'fading'); }
      else { setOneOf(el, CPX_VALUES, gone ? 'naked' : 'mcm2'); }
    }
    ['actor-dhpush', 'actor-dhpush-b'].forEach(function (id) {
      var g = findId(copy, id);
      if (g) { g.setAttribute('transform', 'translate(' + push.toFixed(1) + ' ' + (gone ? -300 : 0) + ')'); }
    });
    setNsd(copy, 'actor-dh', v.nsd || 'nsd-displaced');
    fxState(copy, 'fx-phos', !!v.phos);
    MARK_ORDER.forEach(function (site, j) { fxState(copy, 'fx-pm-' + site, j < (v.pm === undefined ? 4 : v.pm)); });
    placeFork(copy, side, p, v, 0);
    place(copy, 'actor-rrm3-' + side, xf, 0);
    copy.classList.toggle('ci-moving', !!v.moving);
    copy.dataset.p = String(p);
  }

  function drawTerm(copy, v) {
    // VIEW: two forks meeting: the gap closes, the CMGs pass, SCF-Dia2 and Cdc48 end them (TERMINAL)
    // Each half of the panel is painted as its own fork paints it: the left
    // half by the fork moving right, the right half by the fork moving left.
    // Once the CMGs have passed, every position is copied on both strands.
    var T = CHROM_GEOM.ciTerm, E = CHROM_GEOM.ciElong, M = T.m;
    var zone = function (i, st) {
      return st === 'replicated' ? 'z-replicated' : (st === 'extruded' ? 'z-extruded' : 'z-unlicensed');
    };
    var w = { dntp: v.dntp, leave: !!v.gone };
    paintStrip(copy, { lo: T.range[0], hi: M, side: 'r', p: v.filled ? M + 40 : v.pL, ext: E.ext, bare: 0,
      split: T.split.l, zone: zone });
    paintStrip(copy, { lo: M + 1, hi: T.range[1], side: 'l', p: v.filled ? M + 1 - 40 : v.pR, ext: E.ext, bare: 0,
      split: T.split.r, zone: zone });
    placeFork(copy, 'r', v.pL, w, 0);
    placeFork(copy, 'l', v.pR, w, 0);
    [['r', E.x0 + v.pL * E.cw], ['l', E.x0 + (v.pR - 1) * E.cw]].forEach(function (q) {
      var up = v.gone ? -300 : 0;
      place(copy, 'actor-dia2-' + q[0], q[1], v.dia2 ? up : -300);
      place(copy, 'actor-cdc48-' + q[0], q[1], v.cdc48 ? up : -300);
      place(copy, 'actor-ubq-' + q[0], q[1], up);
      fxState(copy, 'fx-ubq-' + q[0], !!v.ubq);
    });
    copy.classList.toggle('ci-moving', !!v.moving && !v.gone);
  }

  function paintStrip(copy, o) {
    // VIEW: strand state, tint, lagging pieces and nucleosomes along a close-up strip (TERMINAL)
    var i, el, st, d, k, laid, j, states = {}, pieces, nucs, a, b, gone, n = CHROM_GEOM.ciElong.okazaki;
    var reach = o.side === 'r' ? o.p - o.split : o.split - o.p + 1;
    for (i = o.lo; i <= o.hi; i += 1) {
      if (o.side === 'r') { st = i <= o.p - o.ext ? 'replicated' : (i <= o.p ? 'extruded' : 'duplex'); }
      else { st = i >= o.p + o.ext ? 'replicated' : (i >= o.p ? 'extruded' : 'duplex'); }
      states[i] = st;
      el = findId(copy, elongId(i) + '-s');
      if (el) {
        setOneOf(el, STRAND_VALUES, st);
        el.classList.toggle('bare', st === 'extruded' && Math.abs(i - o.p) < o.bare);
      }
      el = findId(copy, elongId(i) + '-z');
      if (el) { setOneOf(el, ZONE_CLASSES, o.zone(i, st)); }
      d = o.side === 'r' ? i - o.split : o.split - i + 1;
      k = (d - 1) % n + 1;
      laid = d >= 1 && reach >= d + 2 * (n - k) && Math.abs(i - o.p) >= o.bare;
      pieces = copy.querySelectorAll('#' + elongId(i) + '-s .nasc.lag');
      for (j = 0; j < pieces.length; j += 1) { pieces[j].classList.toggle('laid', laid); }
    }
    nucs = copy.querySelectorAll('.nuc');
    for (j = 0; j < nucs.length; j += 1) {
      a = +nucs[j].getAttribute('data-i0');
      b = +nucs[j].getAttribute('data-i1');
      gone = false;
      for (i = a; i <= b; i += 1) { if (states[i] && states[i] !== 'duplex') { gone = true; } }
      nucs[j].classList.toggle('gone', gone);
    }
  }

  function placeFork(copy, side, p, w, bare) {
    // VIEW: the fork's machinery at position p, its streams, its RPA, its checkpoint (TERMINAL)
    var E = CHROM_GEOM.ciElong, leave = !!w.leave, sgn = side === 'r' ? 1 : -1, j, el;
    var xf = side === 'r' ? E.x0 + p * E.cw : E.x0 + (p - 1) * E.cw, dyUp = leave ? -300 : 0;
    var dntp = w.dntp === undefined ? 1 : w.dntp;
    var flow = leave ? 'flow-off' : (dntp >= 0.9 ? 'flow-full' : (dntp >= 0.2 ? 'flow-mid' : 'flow-low'));
    var x0r = xf - sgn * (bare + E.ext) * E.cw, x1r = xf - sgn * bare * E.cw;
    var rpaOff = leave && !w.collapsed ? 260 : 0;
    // The fork's own RPA coats the lagging template its stretch leaves bare
    // (the positions just behind the helicase, past any bare ones). Behind a
    // stalled fork, where new strands already cover that whole stretch the DNA
    // there is double-stranded, so the RPA leaves; otherwise it sits over the
    // uncopied gap.
    var gap = [], lo = side === 'r' ? p - bare - E.ext + 1 : p + bare, i, lag;
    for (i = lo; i < lo + E.ext; i += 1) {
      lag = copy.querySelectorAll('#' + elongId(i) + '-s .nasc.lag');
      if (lag.length && !Array.prototype.some.call(lag, function (q) { return q.classList.contains('laid'); })) {
        gap.push(E.x0 + (i - 0.5) * E.cw);
      }
    }
    place(copy, 'actor-cmg-' + side, xf, dyUp);
    place(copy, 'actor-mrc-' + side, xf, dyUp);
    place(copy, 'actor-fork-' + side, xf, 0);
    el = findId(copy, 'actor-fork-' + side);
    if (el) { setOneOf(el, STATES, leave ? 'gone' : null); }
    place(copy, 'actor-pole-' + side, xf + sgn * 40, dyUp);
    place(copy, 'actor-pola-' + side, xf - sgn * 70, dyUp);
    place(copy, 'actor-dntp-' + side, xf, 0);
    streams(copy, side, flow);
    // A moving fork keeps its RPA where it always sits; only a stalled fork's moves onto the gap or leaves.
    place(copy, 'actor-rpa-' + side, bare > 0 && gap.length
      ? gap.reduce(function (a, b) { return a + b; }, 0) / gap.length : (x0r + x1r) / 2,
      bare > 0 && !gap.length ? 260 : rpaOff);
    for (j = 1; j <= E.rpa; j += 1) {
      place(copy, 'actor-rpa' + (j + 1) + '-' + side, j <= bare ? xf - sgn * (j - 0.5) * E.cw : xf,
        j <= bare ? rpaOff : 260);
    }
    checkpoint(copy, side, xf, w, leave);
    fxState(copy, 'fx-mrcp-' + side, !!w.mrcP);
    // Exo1 at the far end of the single-stranded stretch, where the new strands now end.
    place(copy, 'actor-exo-' + side, w.exo ? xf - sgn * (bare + E.ext) * E.cw : xf, w.exo ? 0 : -330);
  }

  function streams(copy, side, flow) {
    // VIEW: one fork's dNTP streams flowing at a level, or drawn back off the page (TERMINAL)
    var off = flow === 'flow-off';
    var above = { dntpe: side === 'l', dntpa: side === 'r' };
    ['dntpe', 'dntpa'].forEach(function (name) {
      var g = findId(copy, 'actor-' + name + 'in-' + side), col;
      if (!g) { return; }
      g.setAttribute('transform', 'translate(0 ' + (off ? (above[name] ? -330 : 330) : 0) + ')');
      col = g.querySelector('.dntp');
      if (col) { ['flow-off', 'flow-low', 'flow-mid', 'flow-full'].forEach(function (c) { col.classList.toggle(c, c === flow); }); }
    });
  }

  function checkpoint(copy, side, xf, w, leave) {
    // VIEW: Mec1-Ddc2 on the coat, the marks it places, Rad53 docked or missing (TERMINAL)
    place(copy, 'actor-chk-' + side, xf, 0);
    inner(copy, 'actor-mecin-' + side, w.mec ? 0 : 260);
    fxState(copy, 'fx-kmrc-' + side, !!w.kmrc && !leave);
    fxState(copy, 'fx-kr53-' + side, !!w.kr53 && !leave);
    fxState(copy, 'fx-nor53-' + side, !!w.nor53 && !leave);
    inner(copy, 'actor-r53in-' + side, w.dock && !leave ? 0 : -300);
    inner(copy, 'actor-r53x-' + side, w.active ? -330 : 0);
    fxState(copy, 'fx-r53p1-' + side, !!w.active);
    fxState(copy, 'fx-r53p2-' + side, !!w.auto);
  }

  function inner(copy, id, dy) {
    // VIEW: slide one inner group off the DNA by dy (TERMINAL)
    var el = findId(copy, id);
    if (el) { el.setAttribute('transform', 'translate(0 ' + dy + ')'); }
  }

  function fxState(copy, id, on) {
    // VIEW: show or hide one wrapper (TERMINAL)
    var el = findId(copy, id);
    if (el) { setOneOf(el, STATES, on ? 'present' : 'gone'); }
  }

  function place(copy, id, x, dy) {
    // VIEW: put an actor and its far-layer twin at x, dy off the DNA (TERMINAL)
    [id, id + '-b'].forEach(function (name) {
      var el = findId(copy, name);
      if (!el) { return; }
      el.setAttribute('transform', 'translate(' + (x - parseFloat(el.dataset.basex || '0')).toFixed(1)
        + ' ' + dy + ')');
    });
  }

  function elongId(i) {
    // MODEL: an elongation panel's id for position index i, as tools/make_panels.py writes it (TERMINAL)
    var v = String(i + 100);
    while (v.length < 3) { v = '0' + v; }
    return 'e' + v;
  }

  function showOnly(root, target, under) {
    // VIEW: only the panel this frame shows, and the one under it, are visible (TERMINAL)
    var all = root.querySelectorAll('svg.cistep'), i;
    for (i = 0; i < all.length; i += 1) {
      all[i].style.opacity = (all[i] === target || all[i] === under) ? '1' : '0';
      // Only the panels on show run their looping animations.
      all[i].classList.toggle('cion', all[i] === target || all[i] === under);
    }
  }

  function snap(root, paint) {
    // VIEW: make a change at once, with every transition in the close-up off for that instant (TERMINAL)
    root.classList.add('cisnap');
    paint();
    root.getBoundingClientRect();
    root.classList.remove('cisnap');
  }

  function setChoice(field, value) {
    // MODEL: record the reader's choice; any change leaves the slide strain (TERMINAL)
    CHROM_LIVE[field] = value;
    CHROM_LIVE.preset = null;
    CHROM_LIVE.presetRun = null;
  }

  function setAllele(key, on) {
    // MODEL: switch one allele; any change leaves the slide strain (TERMINAL)
    CHROM_LIVE.alleles[key] = on;
    CHROM_LIVE.preset = null;
    CHROM_LIVE.presetRun = null;
  }

  function choosePreset(key) {
    // SUB-CONTROLLER: set the switches a slide strain names, find its median run, play it

    var preset = findPreset(key);
    if (!preset) { return; }
    applyPreset(preset);
    startRun(CHROM_LIVE.presetRun.seed, true);

    function findPreset(key) {
      // MODEL: the slide strain named by key (TERMINAL)
      var i;
      for (i = 0; i < CHROM_RULE.PRESETS.length; i += 1) {
        if (CHROM_RULE.PRESETS[i].key === key) { return CHROM_RULE.PRESETS[i]; }
      }
      return null;
    }

    function applyPreset(p) {
      // MODEL: the strain's switches, in HU, and the run of 301 whose spindle is the median (TERMINAL)
      CHROM_LIVE.genotype = 'wt';
      CHROM_LIVE.bob1 = false;
      CHROM_LIVE.hu = true;
      CHROM_LIVE.checkpoint = p.checkpoint;
      CHROM_LIVE.alleles = JSON.parse(JSON.stringify(p.alleles));
      CHROM_LIVE.ak = p.ak;
      CHROM_LIVE.preset = p;
      CHROM_LIVE.presetRun = CHROM_RULE.medianRun(p, 301);
    }
  }

  function startRun(seed, play) {
    // SUB-CONTROLLER: compute the run, install its frames, refresh the controls, show it

    var run = computeRun(seed);
    installFrames(run);
    showControls(run.sched);
    showRun(play);

    function computeRun(seed) {
      // MODEL: one schedule and its frame table for the current choices (TERMINAL)
      var s = seed === null ? CHROM_RULE.freshSeed() : seed;
      var sched = CHROM_RULE.simulate(CHROM_LIVE.genotype, CHROM_LIVE.bob1, s,
        { hu: CHROM_LIVE.hu, checkpoint: CHROM_LIVE.checkpoint, alleles: CHROM_LIVE.alleles,
          ak: CHROM_LIVE.ak, telomereBp: CHROM_LIVE.telBp === null ? undefined : CHROM_LIVE.telBp,
          oneOrigin: CHROM_LIVE.view === 'tel' });
      return { seed: s, sched: sched,
        table: buildChromFrames(sched, CHROM_GEOM, liveFocus(), CHROM_LIVE.follow, interludeSteps(),
          CHROM_LIVE.pair || null, CHROM_LIVE.alsoSites || null) };
    }

    function installFrames(run) {
      // MODEL: make the run the one the engine plays (TERMINAL)
      CHROM_LIVE.seed = run.seed;
      CHROM_LIVE.sched = run.sched;
      window.ANIM = window.ANIM || {};
      window.ANIM[CHROM_LIVE.key] = run.table;
    }

    function showControls(sched) {
      // VIEW: the picker, the switch and the run readout match the run (TERMINAL)
      if (typeof document === 'undefined') { return; }
      var geno = document.getElementById('chrgeno');
      var bob1 = document.getElementById('chrbob1');
      var hu = document.getElementById('chrhu');
      var cp = document.getElementById('chrcheck');
      var seedEl = document.getElementById('chrseed');
      var ak = document.getElementById('chrak');
      var preset = document.getElementById('chrpreset');
      var p = CHROM_LIVE.preset, r = CHROM_LIVE.presetRun, boxes, i;
      if (geno) { geno.value = CHROM_LIVE.genotype; }
      if (bob1) { bob1.checked = CHROM_LIVE.bob1; }
      if (hu) { hu.checked = CHROM_LIVE.hu; }
      if (cp) { cp.value = CHROM_LIVE.checkpoint; }
      if (ak) { ak.value = CHROM_LIVE.ak; }
      if (preset) { preset.value = p && r && r.seed === sched.seed ? p.key : ''; }
      boxes = document.querySelectorAll('#chralleles input[data-allele]');
      for (i = 0; i < boxes.length; i += 1) {
        boxes[i].checked = !!CHROM_LIVE.alleles[boxes[i].getAttribute('data-allele')];
      }
      if (seedEl) {
        seedEl.textContent = !sched.viable ? sched.stuck
          : (p && r && r.seed === sched.seed
            ? 'run ' + sched.seed + ': the typical run of ' + r.n + ', ending as ' + Math.round(100 * r.outcomeShare)
              + '% do (' + ({ anaphase: 'copied in full, then anaphase', premature: 'premature spindle extension',
                arrested: 'still in S' }[r.outcome] || r.outcome) + '); '
              + Math.round(100 * r.share) + '% extended at scoring (slide ' + p.slide + ': ' + p.paper + ')'
            : 'run ' + sched.seed);
      }
    }

    function showRun(play) {
      // VIEW: reset the panel to the new run's first frame, and play it if asked (TERMINAL)
      if (typeof window.runAnimation !== 'function' || window.CURRENT_KEY !== CHROM_LIVE.key) {
        paintInset(0);
        return;
      }
      window.runAnimation('reset', CHROM_LIVE.key);
      if (play) { window.runAnimation('play'); }
    }
  }
}

// === SHARED FUNCTIONS =====================================================

function liveFocus() {
  // MODEL: what the close-up follows: the selected origin, or in the telomere view the selected end (TERMINAL)
  return CHROM_LIVE.view === 'tel' ? CHROM_LIVE.telFocus : CHROM_LIVE.focus;
}

function interludeSteps() {
  // MODEL: the step panels' frames, step 7 to step 11 in order, for the firing interlude (TERMINAL)
  var keys = ['step07', 'step08', 'step09', 'step10', 'step11'], out = [];
  keys.forEach(function (key, k) {
    var table = (typeof window !== 'undefined' && window.ANIM) ? window.ANIM[key] : null;
    var meta = (typeof window !== 'undefined' && window.META) ? window.META[key] : null;
    var j;
    if (!table) { return; }
    for (j = 0; j < table.frames.length; j += 1) {
      out.push({ key: key, frame: j, num: 7 + k, title: meta ? meta.title : key });
    }
  });
  return out;
}

// === BASE CONTROLLER: initChromLive =======================================

function initChromLive() {
  // BASE CONTROLLER: fill the picker, wire the controls, show them with the panel.

  var bar = document.getElementById('chrcontrols');
  if (!bar) { return; }
  fillPicker(bar);
  wireControls(bar);
  wireClose();
  window.onPanelSelected = showForPanel;
  runChromLive('install');
  runChromLive('focus', CHROM_LIVE.focus);

  function wireClose() {
    // SUB-CONTROLLER: a click on an origin selects it; every frame change repaints the close-up.
    var stage = document.getElementById('stage');
    var previous = window.onFrameChange;
    if (stage) { stage.addEventListener('click', onClick); }
    var follow = document.getElementById('chrfollow');
    if (follow) {
      follow.addEventListener('click', function (ev) {
        var v = ev.target.getAttribute && ev.target.getAttribute('data-follow');
        if (v) { runChromLive('follow', v); }
      });
    }
    window.onFrameChange = onFrame;

    function onClick(ev) {
      var el = ev.target;
      while (el && el !== stage) {
        if (el.getAttribute && el.getAttribute('data-origin')) {
          runChromLive('focus', el.getAttribute('data-origin'));
          return;
        }
        if (el.getAttribute && el.getAttribute('data-telsite')) {
          runChromLive('telfocus', el.getAttribute('data-telsite'));
          return;
        }
        el = el.parentNode;
      }
    }

    function onFrame(key, frame, total, playing) {
      if (typeof previous === 'function') { previous(key, frame, total, playing); }
      if (key === CHROM_LIVE.key) { runChromLive('inset', frame); }
    }
  }

  function fillPicker(bar) {
    // VIEW: one option per genotype, checkpoint allele, kinetochore site and slide strain; one switch per allele (TERMINAL)
    var sel = bar.querySelector('#chrgeno');
    var cp = bar.querySelector('#chrcheck');
    var ak = bar.querySelector('#chrak');
    var pre = bar.querySelector('#chrpreset');
    var al = bar.querySelector('#chralleles');
    if (ak) {
      ak.innerHTML = CHROM_RULE.AK_CHOICES.map(function (c) {
        return '<option value="' + c.key + '">' + c.label + '</option>';
      }).join('');
      ak.value = CHROM_LIVE.ak;
    }
    if (pre) {
      pre.innerHTML = '<option value="">choose one</option>' + CHROM_RULE.PRESETS.map(function (q) {
        return '<option value="' + q.key + '">slide ' + q.slide + ': ' + q.label + '</option>';
      }).join('');
    }
    if (al) {
      al.innerHTML = CHROM_RULE.ALLELES.map(function (a) {
        return '<label><input type="checkbox" data-allele="' + a.key + '"> ' + a.label + '</label>';
      }).join(' ');
    }
    sel.innerHTML = CHROM_RULE.GENOTYPES.map(function (g) {
      return '<option value="' + g.key + '">' + g.label + '</option>';
    }).join('');
    sel.value = CHROM_LIVE.genotype;
    cp.innerHTML = CHROM_RULE.CHECKPOINTS.map(function (c) {
      return '<option value="' + c.key + '">' + c.label + '</option>';
    }).join('');
    cp.value = CHROM_LIVE.checkpoint;
  }

  function wireControls(bar) {
    // SUB-CONTROLLER: one handler per control.
    bar.querySelector('#chrgeno').addEventListener('change', onGenotype);
    bar.querySelector('#chrbob1').addEventListener('change', onBob1);
    bar.querySelector('#chrhu').addEventListener('change', onHu);
    bar.querySelector('#chrcheck').addEventListener('change', onCheckpoint);
    bar.querySelector('#chrnew').addEventListener('click', onNew);
    if (bar.querySelector('#chrak')) { bar.querySelector('#chrak').addEventListener('change', onAk); }
    if (bar.querySelector('#chrpreset')) { bar.querySelector('#chrpreset').addEventListener('change', onPreset); }
    if (bar.querySelector('#chralleles')) { bar.querySelector('#chralleles').addEventListener('change', onAllele); }
    bar.querySelector('#chrreplay').addEventListener('click', onReplay);
    if (bar.querySelector('#chrtelbp')) { bar.querySelector('#chrtelbp').addEventListener('change', onTelBp); }
    var views = document.getElementById('chrview');
    if (views) { views.addEventListener('click', onView); }

    function onTelBp(ev) {
      var v = parseInt(ev.target.value, 10);
      runChromLive('telbp', isNaN(v) ? null : Math.max(0, Math.min(1000, v)));
    }
    function onView(ev) {
      var v = ev.target.getAttribute && ev.target.getAttribute('data-view');
      if (v) { runChromLive('view', v); }
    }

    function onGenotype(ev) { runChromLive('genotype', ev.target.value); }
    function onBob1(ev) { runChromLive('bob1', ev.target.checked); }
    function onHu(ev) { runChromLive('hu', ev.target.checked); }
    function onCheckpoint(ev) { runChromLive('checkpoint', ev.target.value); }
    function onNew() { runChromLive('new'); }
    function onAk(ev) { runChromLive('ak', ev.target.value); }
    function onPreset(ev) { if (ev.target.value) { runChromLive('preset', ev.target.value); } }
    function onAllele(ev) {
      var key = ev.target.getAttribute && ev.target.getAttribute('data-allele');
      if (key) { runChromLive('allele', [key, ev.target.checked]); }
    }
    function onReplay() { runChromLive('replay'); }
  }

  function showForPanel(key) {
    // VIEW: the controls show only with the live panel (TERMINAL)
    bar.hidden = key !== CHROM_LIVE.key;
  }
}

function registerOriginPanels() {
  // MODEL: the close-up's origin panels get frame tables, one frame per state, so the engine paints them (TERMINAL)
  if (typeof window === 'undefined' || typeof CHROM_GEOM === 'undefined' || !CHROM_GEOM.ciOrigin) { return; }
  window.ANIM = window.ANIM || {};
  window.ANIM.cicen = { fps: 2, label: 'centromere close-up',
    frames: CHROM_GEOM.ciCenStates.map(function (st) { return CHROM_GEOM.ciCen[st]; }) };
  ['ciorigin', 'ciorigin-b'].forEach(function (key) {
    window.ANIM[key] = { fps: 2, label: 'origin close-up',
      frames: CI_ORIGIN_STATES.map(function (st) { return CHROM_GEOM.ciOrigin[st]; }) };
  });
  // The bob1 drawings of steps 7 to 11 play the steps' own frames; a pair
  // fired by the bypass plays them with the NSD released and no DDK marks.
  ['step07', 'step08', 'step09', 'step10', 'step11'].forEach(function (key) {
    var src = window.ANIM[key], x;
    if (!src) { return; }
    window.ANIM[key + 'b'] = src;
    x = JSON.parse(JSON.stringify(src).replace(/nsd-displaced/g, 'nsd-released'));
    x.frames.forEach(function (f) {
      f.fx = f.fx || {};
      f.fx['fx-phos'] = 'gone';
      f.fx['fx-mcm2p'] = 'gone';
    });
    window.ANIM[key + 'x'] = x;
  });
}

registerOriginPanels();
runChromLive('install');

if (typeof window !== 'undefined') {
  window.CHROM_LIVE = CHROM_LIVE;
  window.runChromLive = runChromLive;
  window.initChromLive = initChromLive;
}

if (typeof document !== 'undefined' && typeof window !== 'undefined'
    && !window.SUPPRESS_AUTOSTART) {
  document.addEventListener('DOMContentLoaded', initChromLive);
}
